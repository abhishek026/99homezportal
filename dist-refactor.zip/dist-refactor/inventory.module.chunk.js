webpackJsonp(["inventory.module"],{

/***/ "./src/app/components/inventory/inventory-category/inventory-category.component.html":
/***/ (function(module, exports) {

module.exports = "<div id=\"divCategory\" class=\"c-lg-12 c-md-12 c-sm-12\">\r\n  <section>\r\n    <div class=\"clearFix add-edit\">\r\n      <a (click)=\"toggleCreateNewSlot()\">\r\n        <i id=\"showAddBtn\" class=\"addBtnClass\" style=\"border: none\">+</i>\r\n        <i id=\"showCloseBtn\" style=\"display:none; border:none;\" class=\"closeBtnClass\">-</i>\r\n        <span>Add Category</span>\r\n      </a>\r\n    </div>\r\n    <div class=\"clearFix create-standard-form\" *ngIf=\"createNewCategory\" style=\"margin-top: 5px;margin-bottom: 10px;\">\r\n      <div class=\"c-sm-3\">\r\n        <div class=\"field-wrapper\">\r\n          <label for=\"ctgryName\">Category Name\r\n            <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <input id=\"ctgryName\" type=\"text\" #categoryName class=\"form-ctrl\" name=\"label\" >\r\n\r\n        </div>\r\n      </div>\r\n      <div class=\"c-sm-3\">\r\n        <div class=\"field-wrapper\">\r\n            <label for=\"ctgrydesc\">Category Description\r\n              </label>\r\n          <input id=\"ctgrydesc\" type=\"text\" #categoryDesc class=\"form-ctrl\" name=\"label\" >\r\n          \r\n        </div>\r\n        <div>\r\n        </div>\r\n      </div>\r\n      <div class=\"c-sm-3\" style=\"padding-top: 10px; margin-top:16px;\">\r\n        <button class=\"btn fullBlue\" (click)=\"addNewCategoryRow(categoryName ,categoryDesc )\">Add</button>\r\n      </div>\r\n      <div class=\"c-sm-3\">\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <section>\r\n    <div id=\"category-table\">\r\n      <div class=\"table-scroll-wrapper\">\r\n        <div class=\"table table-responsive\">\r\n          <table id=\"tbLCategory\">\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  Category Name\r\n                </th>\r\n                <th>\r\n                  Category Description\r\n                </th>\r\n                <th>\r\n                  Action\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody id=\"tbodyCategory\">\r\n              <tr id=\"row{{i}}\" class=\"displayComp\" *ngFor=\"let row of categoryList; \r\n              let i = index;\">\r\n                <td class=\"view-comp\">\r\n                  {{row.category_name}}\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper\">\r\n                    <input type=\"text\" class=\"form-ctrl editCellInput\" [(ngModel)]=\"row.category_name\" name=\"label\">\r\n                  </div>\r\n                </td>\r\n                <td class=\"view-comp\">\r\n                  {{row.desc}}\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper\">\r\n                    <input type=\"text\" class=\"form-ctrl editCellInput\" [(ngModel)]=\"row.desc\" name=\"label\">\r\n                  </div>\r\n                </td>\r\n                <td class=\"view-comp\">\r\n                  <a style=\"cursor:pointer\" (click)=\"editRow(i)\">\r\n                    <i class=\"edit-icon\" aria-hidden=\"true\" title=\"Edit\"></i>Edit\r\n                  </a>\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <a style=\"cursor:pointer ; margin-right:10px\" (click)=\"updateTableRow(row , i)\">\r\n                    <i class=\"fas fa-check\" style=\"font-family: FontAwesome ;font-size: 19px;\" title=\"Update\"></i>\r\n                  </a>\r\n                  <a style=\"cursor:pointer\" (click)=\"cancelTableRow(row)\">\r\n                    <i class=\"fas fa fa-times\" style=\"font-family: FontAwesome ;font-size: 19px;\" title=\"Cancel\"></i>\r\n                  </a>\r\n                </td>\r\n              </tr>\r\n              <tr *ngIf=\"categoryList.length == 0\">\r\n                <td colspan=\"3\" style=\"text-align: center\">\r\n                  No data found\r\n                </td>\r\n              </tr>\r\n\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n    <!-- Paginator Here -->\r\n    <div class=\"row filter-res pagination\" style=\"width:100%\">\r\n      <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n        <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n          [page]=\"PageIndex\" [perPage]=\"studentdisplaysize\" [count]=\"totalRow\">\r\n        </pagination>\r\n      </div>\r\n    </div>\r\n  </section>\r\n</div>"

/***/ }),

/***/ "./src/app/components/inventory/inventory-category/inventory-category.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\ntable thead tr th {\n  padding-top: 10px;\n  padding-bottom: 10px; }\ntable tbody tr td {\n  padding-top: 10px;\n  padding-bottom: 10px; }\ntable tbody tr td .editOptions li {\n    display: inline-block; }\ntable tbody tr .field-wrapper {\n  padding: 0px !important; }\ntable tbody tr .field-wrapper .form-ctrl {\n    display: block;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 0px 0px 0px 5px;\n    outline: none;\n    border: 0;\n    height: 26px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 25px;\n    background: transparent;\n    width: 80px;\n    text-align: center;\n    border-bottom: 1px solid #ccc; }\ntable tbody .displayComp .view-comp {\n  padding: 6px 6px; }\ntable tbody .displayComp .edit-comp {\n  padding: 6px 6px;\n  display: none; }\ntable tbody .editComp .view-comp {\n  display: none; }\n@media screen and (max-width: 995px), screen and (max-height: 768px) {\n  #category-table {\n    margin-left: 0px !important;\n    margin-top: 15px;\n    margin-right: 15px !important;\n    max-height: 480px;\n    overflow: hidden;\n    width: 100%; }\n    #category-table .table-scroll-wrapper {\n      max-height: 430px; }\n    #category-table ::-webkit-scrollbar {\n      display: block;\n      width: 7px;\n      height: 7px; } }\n.addNewButton {\n  text-decoration: none;\n  color: #0084f6; }\ninput[type=number]::-webkit-inner-spin-button,\ninput[type=number]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0; }\n.editCellInput {\n  margin: auto;\n  display: block; }\n.add-edit {\n  margin-bottom: 15px;\n  margin-top: 15px; }\n.add-edit i {\n    border: 1px solid #0084f6;\n    display: inline-block;\n    width: 17px;\n    height: 17px;\n    border-radius: 50%;\n    line-height: 16px;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle;\n    margin-right: 4px; }\n.add-edit span {\n    display: inline-block; }\n.add-edit .expend-box i {\n    line-height: 12px;\n    font-size: 22px; }\n.add-edit a {\n    cursor: pointer; }\n.closeBtnClass {\n  line-height: 11px !important; }\n.create-standard-form {\n  margin: 10px 0;\n  padding: 10px 20px 20px;\n  background: #efefef;\n  border-top: 1px solid #d8d8d8; }\n.create-standard-form .form-ctrl {\n    background: transparent;\n    border-bottom: solid 1px #cccccc; }\n#category-table {\n  max-height: 340px;\n  margin-bottom: 0px;\n  padding-bottom: 0px;\n  overflow: auto; }\n"

/***/ }),

/***/ "./src/app/components/inventory/inventory-category/inventory-category.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return InventoryCategoryComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/utils/facade/browser.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_inventory_services_inventory_category_service__ = __webpack_require__("./src/app/services/inventory-services/inventory-category.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__app_component__ = __webpack_require__("./src/app/app.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var InventoryCategoryComponent = /** @class */ (function () {
    function InventoryCategoryComponent(categoryService, appC) {
        this.categoryService = categoryService;
        this.appC = appC;
        this.newCategory = {};
        this.categoryList = [];
        this.dataSourceCategory = [];
        this.totalRow = 0;
        this.studentdisplaysize = 10;
        this.PageIndex = 1;
        this.sizeArr = [10, 25, 50, 100];
        this.displayBatchSize = 10;
        this.createNewCategory = false;
    }
    InventoryCategoryComponent.prototype.ngOnInit = function () {
        this.getAllCategoryList();
        this.switchActiveView('category');
    };
    InventoryCategoryComponent.prototype.addNewCategoryRow = function (categoryElement, descriptionElement) {
        this.newCategory.category_name = categoryElement.value;
        this.newCategory.desc = descriptionElement.value;
        this.addTableRow(this.newCategory);
    };
    //  Add Row Of Table
    InventoryCategoryComponent.prototype.addTableRow = function (data) {
        var _this = this;
        if (data.category_name == "" || data.category_name == null) {
            var data_1 = {
                type: 'error',
                title: '',
                body: "Please fill Category Name."
            };
            this.appC.popToast(data_1);
            return;
        }
        this.categoryService.setNewCategory(data).subscribe(function (data) {
            _this.getAllCategoryList();
            __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('ctgryName').value = "";
            __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('ctgrydesc').value = "";
            var msg = {
                type: 'success',
                title: "",
                body: "New Category Added."
            };
            _this.appC.popToast(msg);
        }, function (error) {
            var msg = {
                type: "error",
                title: "",
                body: error.error.message
            };
            _this.appC.popToast(msg);
        });
    };
    // Cancel
    InventoryCategoryComponent.prototype.cancelTableRow = function (event) {
        this.getAllCategoryList();
    };
    // edit perticular row
    InventoryCategoryComponent.prototype.editRow = function (id) {
        __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(("row" + id).toString()).classList.remove('displayComp');
        __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(("row" + id).toString()).classList.add('editComp');
    };
    // update the current table row
    InventoryCategoryComponent.prototype.updateTableRow = function (rowData, id) {
        var _this = this;
        __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(("row" + id).toString()).classList.remove('editComp');
        __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(("row" + id).toString()).classList.add('displayComp');
        var data = {};
        data.category_id = rowData.category_id;
        data.category_name = rowData.category_name;
        data.desc = rowData.desc;
        data.institution_id = rowData.institution_id;
        this.categoryService.updateExisting(data).subscribe(function (data) {
            var msg = {
                type: 'success',
                title: "",
                body: "Category Updated."
            };
            _this.appC.popToast(msg);
        }, function (error) {
            var msg = {
                type: "error",
                title: "",
                body: error.error.message
            };
            _this.appC.popToast(msg);
        });
    };
    // to fetch all category items 
    InventoryCategoryComponent.prototype.getAllCategoryList = function () {
        var _this = this;
        this.categoryService.getCategoryList().subscribe(function (data) {
            _this.totalRow = data.length;
            _this.dataSourceCategory = data;
            _this.fetchTableDataByPage(_this.PageIndex);
        }, function (err) {
            var msg = {
                type: "error",
                title: "",
                body: "An Error Occured"
            };
            _this.appC.popToast(msg);
        });
    };
    InventoryCategoryComponent.prototype.toggleCreateNewSlot = function () {
        if (this.createNewCategory == false) {
            this.createNewCategory = true;
            __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('showCloseBtn').style.display = '';
            __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('showAddBtn').style.display = 'none';
        }
        else {
            this.createNewCategory = false;
            __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('showCloseBtn').style.display = 'none';
            __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('showAddBtn').style.display = '';
        }
    };
    // pagination functions 
    InventoryCategoryComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.categoryList = this.getDataFromDataSource(startindex);
    };
    InventoryCategoryComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    InventoryCategoryComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    InventoryCategoryComponent.prototype.getDataFromDataSource = function (startindex) {
        var t = this.dataSourceCategory.slice(startindex, startindex + this.displayBatchSize);
        return t;
    };
    InventoryCategoryComponent.prototype.switchActiveView = function (tabName) {
        __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('item').classList.remove('active');
        __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('category').classList.remove('active');
        __WEBPACK_IMPORTED_MODULE_1_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(tabName).classList.add('active');
    };
    InventoryCategoryComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-inventory-category',
            template: __webpack_require__("./src/app/components/inventory/inventory-category/inventory-category.component.html"),
            styles: [__webpack_require__("./src/app/components/inventory/inventory-category/inventory-category.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_inventory_services_inventory_category_service__["a" /* InventoryCategoryService */],
            __WEBPACK_IMPORTED_MODULE_3__app_component__["a" /* AppComponent */]])
    ], InventoryCategoryComponent);
    return InventoryCategoryComponent;
}());



/***/ }),

/***/ "./src/app/components/inventory/inventory-home/inventory-home.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\"\r\n  *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n<section class=\"middle-section clearFix\">\r\n  <div class=\"boxPadding15\">\r\n    <aside class=\"middle-full row\">\r\n      <!-- Header and Navigation -->\r\n      <section class=\"clearFix\">\r\n\r\n\r\n        <!-- Export and Toggler Here -->\r\n        <div class=\"row\" style=\"margin-top: -5px;margin-bottom: 5px;\">\r\n          <div class=\"c-lg-6 c-md-6 c-sm-6 align-left\">\r\n          </div>\r\n          <div class=\"c-lg-6 c-md-6 c-sm-6 align-left\">\r\n            <div class=\"field-wrapper\">\r\n              <div class=\"btnWrapper\">\r\n                <button class=\"btn pull-right\" (click)=\"addItemDetails()\">\r\n                  <div class=\"option-wrap\">\r\n                    <img src=\"assets/images/plus.png\" alt=\"Add Item\" style=\"vertical-align: -webkit-baseline-middle;\">\r\n                    <span class=\"tooltip tooltipSpan\">\r\n                      Add Item\r\n                    </span>\r\n                  </div>\r\n                </button>\r\n              </div>\r\n\r\n            </div>\r\n            <div class=\"search-filter-wrapper\">\r\n              <input #search type=\"text\" class=\"normal-field pull-right\" placeholder=\"Search\"\r\n                style=\"font-size:12px; margin: 0px 5px 2px -5px;width: 30%\" id=\"search\" name=\"searchData\"\r\n                (keyup)=\"searchDatabase(search)\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <!-- Enquiry DataTable -->\r\n        <div class=\"table table-responsive inventory-table\" #ActionInv>\r\n          <table id=\"item-Table\" class=\"align-center\">\r\n            <thead>\r\n              <tr id=\"table-header\" class=\"displayComp\">\r\n                <th>\r\n                  <label>\r\n                    <a class=\"cursor-icon\" >{{header.inventory_item.title}}</a>\r\n                  </label>\r\n                </th>\r\n\r\n                <th>\r\n                  <label>\r\n                    <a class=\"cursor-icon\" >{{header.category.title}}</a>\r\n                  </label>\r\n                </th>\r\n\r\n                <th>\r\n                  <label>\r\n                    <a class=\"cursor-icon\">{{header.description.title}}</a>\r\n                  </label>\r\n                </th>\r\n\r\n                <th>\r\n                  <label>\r\n                    <a class=\"cursor-icon\" >{{header.total_units.title}}</a>\r\n                  </label>\r\n                </th>\r\n\r\n                <th>\r\n                  <label>\r\n                    <a class=\"cursor-icon\" >{{header.available.title}}</a>\r\n                  </label>\r\n                </th>\r\n\r\n                <th>\r\n                  <label>\r\n                    <a class=\"cursor-icon\" >{{header.cost.title}}</a>\r\n                  </label>\r\n                </th>\r\n\r\n                <th>\r\n                  <label>\r\n                    <a class=\"cursor-icon\">Low Stock Indicator Units</a>\r\n                  </label>\r\n                </th>\r\n\r\n                <th *ngIf=\"enable_eLearn_feature_flag\">\r\n                  <label>\r\n                    <a class=\"cursor-icon\">Status</a>\r\n                  </label>\r\n                </th>\r\n\r\n\r\n                <th>\r\n                  <label>\r\n                    <a class=\"cursor-icon\">Manage Unit</a>\r\n                  </label>\r\n                </th>\r\n\r\n                <th>\r\n                  <label>\r\n                    <a class=\"cursor-icon\" >{{header.edit.title}}</a>\r\n                  </label>\r\n                </th>\r\n\r\n              </tr>\r\n            </thead>\r\n            <tbody class=\"\" *ngIf=\"itemList.length != 0\">\r\n              <tr id=\"row{{i}}\" class=\"displayComp\" *ngFor=\"let row of itemList; let i = index; trackBy: i;\">\r\n\r\n                <td class=\"view-comp\">\r\n                  {{row.item_name}}\r\n                </td>\r\n                <td class=\"edit-comp \">\r\n                  <div class=\"field-wrapper editCellAllignment\">\r\n                    <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"row.item_name\" name=\"label\">\r\n                  </div>\r\n                </td>\r\n\r\n                <td class=\"view-comp\">\r\n                  {{row.category_name}}\r\n                </td>\r\n                <td class=\"edit-comp \">\r\n                  <div class=\"field-wrapper editCellAllignment\">\r\n                    <select id=\"\" class=\"form-ctrl\" name=\"row.category_id\" [(ngModel)]=\"row.category_id\">\r\n                      <option *ngFor=\"let opt of categoryList\" [value]=\"opt.category_id\">\r\n                        {{opt.category_name}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </td>\r\n\r\n                <td class=\"view-comp \">\r\n                  <div class=\"field-wrapper\">\r\n                    {{row.desc}}\r\n                  </div>\r\n                </td>\r\n                <td class=\"edit-comp editCellAllignment\">\r\n                  <div class=\"field-wrapper\">\r\n                    <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"row.desc\" name=\"label\">\r\n                  </div>\r\n                </td>\r\n\r\n                <td>\r\n                  {{row.alloted_units}}\r\n                </td>\r\n                <td [ngClass]=\"{lowquantity : row.available_units <= row.out_of_stock_indicator_units}\">\r\n                  {{row.available_units}}\r\n                </td>\r\n\r\n                <td class=\"view-comp\">\r\n                  <div class=\"field-wrapper\">\r\n                    {{row.unit_cost}}\r\n                  </div>\r\n                </td>\r\n                <td class=\"edit-comp editCellAllignment\">\r\n                  <div class=\"field-wrapper\">\r\n                    <input type=\"number\" class=\"form-ctrl\" [(ngModel)]=\"row.unit_cost\" name=\"label\">\r\n                  </div>\r\n                </td>\r\n\r\n\r\n                <td class=\"view-comp\">\r\n                  <div class=\"field-wrapper\">\r\n                    {{row.out_of_stock_indicator_units}}\r\n                  </div>\r\n                </td>\r\n                <td class=\"edit-comp editCellAllignment\">\r\n                  <div class=\"field-wrapper\">\r\n                    <input type=\"number\" class=\"form-ctrl\" style=\"margin:auto\" [(ngModel)]=\"row.out_of_stock_indicator_units\" name=\"label\">\r\n                  </div>\r\n                </td>\r\n\r\n                <td class=\"view-comp\" *ngIf=\"enable_eLearn_feature_flag\">\r\n                  <div class=\"field-wrapper\">\r\n                    {{row.is_offline_or_online}}\r\n                  </div>\r\n                </td>\r\n                <td class=\"edit-comp editCellAllignment\" >\r\n                  <div class=\"field-wrapper\">\r\n                    <select id=\"is_offline_or_online\" class=\"form-ctrl\" name=\"is_offline_or_online\"\r\n                      [(ngModel)]=\"row.is_offline_or_online\" style=\"margin: auto;\">\r\n                      <option value=\"Online\">Online</option>\r\n                      <option value=\"Offline\">Offline</option>\r\n                      <option value=\"Both\">Both</option>\r\n                    </select>\r\n                  </div>\r\n                </td>\r\n\r\n                <td class=\"view-comp\">\r\n                  <div class=\"displayAddItem\" id=\"add-item{{i}}\">\r\n                    <a class=\"view-addItem\" (click)=\"addItemsEnable(i)\" style=\"cursor: pointer;\">\r\n                      <img src=\"assets/images/plus.png\" title=\"Add Quantity\">\r\n                    </a>\r\n                    <a class=\"view-addItem\" (click)=\"subtractItemsEnable(i)\" style=\"cursor: pointer;\">\r\n                      <i class=\"fas fa-minus\" style=\"font-family: FontAwesome;size: 19px\" title=\"Subtract Quantity\"></i>\r\n                    </a>\r\n                    <div class=\"field-wrapper edit-addItem\">\r\n                      <input type=\"number\" class=\"form-ctrl addQuantityInput\" style=\"display: inline-block\"\r\n                        [(ngModel)]=\"row.units_added\" name=\"label\">\r\n                      <a style=\"cursor:pointer ; margin-right:10px; display: inline-block\"\r\n                        (click)=\"addItemsQuantity(row)\">\r\n                        <i class=\"fas fa-check\"\r\n                          style=\"font-family: FontAwesome ;font-size: 19px; display: inline-block;\" title=\"Update\"></i>\r\n                      </a>\r\n                      <a style=\"cursor:pointer\" (click)=\"cancelItem(i)\">\r\n                        <i class=\"fas fa fa-times\"\r\n                          style=\"font-family: FontAwesome ;font-size: 19px;  display: inline-block;\" title=\"Cancel\"></i>\r\n                      </a>\r\n                    </div>\r\n                  </div>\r\n                </td>\r\n                <td class=\"edit-comp\" *ngIf=\"!isAddUnit\">\r\n                </td>\r\n                <td class=\"edit-comp\" *ngIf=\"isAddUnit\">\r\n                  <div class=\"field-wrapper\">\r\n                    <input type=\"number\" class=\"form-ctrl\" [(ngModel)]=\"row.unit_cost\" name=\"label\">\r\n                  </div>\r\n                </td>\r\n                <td class=\"table-action edit-comp\">\r\n                  <a style=\"cursor:pointer\" (click)=\"updateRow(row , i)\">\r\n                    <i class=\"fas fa-check\" style=\"font-family: FontAwesome ;font-size: 19px;\" title=\"Update\"></i>\r\n                  </a>\r\n                  <a style=\"cursor:pointer\" (click)=\"cancelRow(i)\">\r\n                    <i class=\"fas fa fa-times\" style=\"font-family: FontAwesome ;font-size: 19px;\" title=\"Cancel\"></i>\r\n                  </a>\r\n                </td>\r\n                <td class=\"enquiry-action table-action view-comp\">\r\n                  <div>\r\n                    <button aria-expanded=\"true\" class=\"dropdown-trigger\" (click)=\"openMenu(i)\">\r\n                      <span class=\"svg-icon-wrap\">\r\n                        <span class=\"visually-hidden\"></span>\r\n                        <div aria-hidden=\"true\" type=\"ellipsis-horizontal-icon\">\r\n                          <svg viewBox=\"0 0 24 24\" width=\"24px\" height=\"24px\" x=\"0\" y=\"0\"\r\n                            preserveAspectRatio=\"xMinYMin meet\" class=\"artdeco-icon\" focusable=\"false\">\r\n                            <path d=\"M2,10H6v4H2V10Zm8,4h4V10H10v4Zm8-4v4h4V10H18Z\" class=\"large-icon\"\r\n                              style=\"fill: currentColor\"></path>\r\n                          </svg>\r\n                        </div>\r\n                      </span>\r\n                    </button>\r\n\r\n                    <div id=\"menuList{{i}}\" class=\"dd-list-container hide\">\r\n                      <div class=\"dropdown-list\">\r\n                        <div class=\"dd-list-inner\">\r\n                          <ul class=\"actions-menu\">\r\n                            <li class=\"action-item \" (click)=\"editRow(i,row.item_id)\">\r\n                              <span class=\"textContent\">\r\n                                Edit Details\r\n                              </span>\r\n                            </li>\r\n                            <li class=\"action-item\" (click)=\"deleteRow(row, i)\">\r\n                              <span class=\"textContent\">\r\n                                Delete Entry\r\n                              </span>\r\n                            </li>\r\n                            <li class=\"action-item\" (click)=\"allocationDetails(row , i)\">\r\n                              <span class=\"textContent\">\r\n                                Allocation History\r\n                              </span>\r\n                            </li>\r\n                            <li class=\"action-item\" *ngIf=\"showAllocateOption\"\r\n                              (click)=\"allocateQuantityToSubBranches(row)\">\r\n                              <span class=\"textContent\">\r\n                                Allocate To Sub Branches\r\n                              </span>\r\n                            </li>\r\n                          </ul>\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n\r\n                  </div>\r\n                </td>\r\n\r\n              </tr>\r\n            </tbody>\r\n            <tbody *ngIf=\"itemList.length == 0\">\r\n              <tr>\r\n                <td colspan=\"10\" style=\"text-align: center\">\r\n                  No data found\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n\r\n\r\n        <!-- Paginator Here -->\r\n        <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n          <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n            <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\"\r\n              [pagesToShow]=\"10\" [page]=\"PageIndex\" [perPage]=\"studentdisplaysize\" [count]=\"totalRow\">\r\n            </pagination>\r\n          </div>\r\n        </div>\r\n\r\n      </section>\r\n    </aside>\r\n  </div>\r\n</section>\r\n\r\n<!-- Delete PopUp -->\r\n<!-- =============================================================================== -->\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"deleteItemPopUp\">\r\n  <div class=\"popup pos-abs\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closeDeletePopup()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n          <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n            <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\"\r\n                transform=\"translate(992.81 305.77) rotate(45)\" />\r\n              <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\"\r\n                transform=\"translate(978.81 305.77) rotate(45)\" />\r\n            </g>\r\n            <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\"\r\n              transform=\"translate(1012 297)\" />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content\">\r\n        <h2>Delete Inventory Item - Item Name: {{deleteRowDetails.item_name}}</h2>\r\n        <div class=\"update-enquiry-form overflowHidden\">\r\n          <div class=\"enquiry-update-history\">\r\n            <h4>Are you Sure you wish to delete this data, it cannot be recovered later.</h4>\r\n          </div>\r\n          <div class=\"\">\r\n            <div class=\"clearfix\">\r\n              <aside class=\"pull-right popup-btn\">\r\n                <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closeDeletePopup()\">\r\n                <input type=\"button\" value=\"Delete\" class=\"redBtn btn\" (click)=\"deleteStudent()\">\r\n              </aside>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n<!-- Create Item Pop Up -->\r\n<!-- =============================================================================== -->\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"createItemPopUp\">\r\n  <div class=\"popup pos-abs popup-body-container\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closeCreatePopup()\">\r\n        <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\"\r\n          viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n          <path _ngcontent-c11=\"\" class=\"large-icon\"\r\n            d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\"\r\n            style=\"fill: currentColor\"></path>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content\">\r\n        <div class=\"\">\r\n          <h2>Add Inventory Item</h2>\r\n          <button class=\"btn pull-right\" routerLink=\"/view/inventory/category\">Add Category</button>\r\n        </div>\r\n\r\n        <div class=\"row\">\r\n          <form [formGroup]=\"addItemForm\" novalidate (ngSubmit)=\"saveItemDetails()\">\r\n\r\n\r\n            <div class=\"row\">\r\n              <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\" style=\"margin-top: 25px;\">\r\n                <div class=\"field-wrapper\">\r\n                  <label for=\"In\">Item Name\r\n                    <span class=\"text-danger\">*</span>\r\n                  </label>\r\n                  <input type=\"text\" class=\"form-ctrl\" formControlName=\"item_name\" id=\"In\" name=\"item\">\r\n\r\n                  <div\r\n                    *ngIf=\"addItemForm.controls['item_name'].invalid && (addItemForm.controls['item_name'].dirty || addItemForm.controls['item_name'].touched)\"\r\n                    class=\"alert alert-danger\">\r\n                    <div *ngIf=\"addItemForm.controls['item_name'].hasError('required')\">\r\n                      Item Name is required.\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\" style=\"top:-10px\">\r\n                <div class=\"field-wrapper\">\r\n                  <label for=\"label\">Item Description\r\n                  </label>\r\n                  <input type=\"text\" class=\"form-ctrl\" formControlName=\"desc\" id=\"label\" name=\"label\">\r\n\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"row\">\r\n              <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n                <div class=\"field-wrapper\">\r\n                  <label for=\"cat\">Category\r\n                    <span class=\"text-danger\">*</span>\r\n                  </label>\r\n                  <select id=\"cat\" class=\"form-ctrl\" formControlName=\"categoryDet\">\r\n                    <option value=\"-1\"></option>\r\n                    <option *ngFor=\"let opt of categoryList\" [value]=\"opt.category_id\">\r\n                      {{opt.category_name}}\r\n                    </option>\r\n                  </select>\r\n\r\n                  <div\r\n                    *ngIf=\"addItemForm.controls['categoryDet'].invalid && (addItemForm.controls['categoryDet'].dirty || addItemForm.controls['categoryDet'].touched)\"\r\n                    class=\"alert alert-danger\">\r\n                    <div *ngIf=\"addItemForm.controls['categoryDet'].hasError('required')\">\r\n                      Category Name is required.\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n                <div class=\"field-wrapper\">\r\n                  <label for=\"Unit\">Available Unit\r\n                    <span class=\"text-danger\">*</span>\r\n                  </label>\r\n                  <input type=\"number\" class=\"form-ctrl\" formControlName=\"alloted_units\" id=\"Unit\" name=\"Unit\">\r\n\r\n                  <div\r\n                    *ngIf=\"addItemForm.controls['alloted_units'].invalid && (addItemForm.controls['alloted_units'].dirty || addItemForm.controls['alloted_units'].touched)\"\r\n                    class=\"alert alert-danger\">\r\n                    <div *ngIf=\"addItemForm.controls['alloted_units'].hasError('required')\">\r\n                      Units is required.\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"row\">\r\n              <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n                <div class=\"field-wrapper\">\r\n                  <label for=\"master\" *ngIf=\"isProfessional\">Master Course </label>\r\n                  <label for=\"master\" *ngIf=\"!isProfessional\">Standard </label>\r\n                  <select id=\"master\" class=\"form-ctrl\" formControlName=\"standardDet\" (change)=\"masterCourseSelected()\">\r\n                    <option value=\"-1\"></option>\r\n                    <option *ngFor=\"let opt of masterCategoryList\" [value]=\"opt.standard_id\">\r\n                      {{opt.standard_name}}\r\n                    </option>\r\n                  </select>\r\n\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n                <div class=\"field-wrapper\">\r\n                  <label for=\"course\" *ngIf=\"isProfessional\">Course </label>\r\n                  <label for=\"course\" *ngIf=\"!isProfessional\">Subject </label>\r\n                  <select id=\"course\" class=\"form-ctrl\" formControlName=\"subjectDet\">\r\n                    <option value=\"-1\"></option>\r\n                    <option *ngFor=\"let opt of courseList\" [value]=\"opt.subject_id\">\r\n                      {{opt.subject_name}}\r\n                    </option>\r\n                  </select>\r\n\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"row\">\r\n              <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n                <div class=\"field-wrapper\">\r\n                  <label for=\"UnitCost\">Unit Cost\r\n                  </label>\r\n                  <input type=\"number\" class=\"form-ctrl\" min=\"0\" id=\"UnitCost\" formControlName=\"unit_cost\"\r\n                    name=\"UnitCost\">\r\n\r\n                </div>\r\n              </div>\r\n              <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6 madeDate\" style=\"margin-top:0px;\">\r\n                <div class=\"field-wrapper datePickerBox\">\r\n                  <label for=\"followupdate\">Date\r\n                  </label>\r\n                  <input type=\"text\" value=\"\" id=\"followupdate\" class=\"form-ctrl\" formControlName=\"created_date\"\r\n                    style=\"cursor: pointer;\" name=\"createdDate\" readonly=\"true\" bsDatepicker />\r\n                  <span class=\"date-clear\" name=\"createdDate\" (click)=\"clearDate($event)\"></span>\r\n                </div>\r\n\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"row\">\r\n              <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n                <div class=\"field-wrapper\">\r\n                  <label for=\"lowUnit\">Low Stock Indicator Units\r\n                  </label>\r\n                  <input type=\"number\" class=\"form-ctrl\" formControlName=\"out_of_stock_indicator_units\" id=\"lowUnit\"\r\n                    name=\"lowUnit\">\r\n\r\n                </div>\r\n              </div>\r\n\r\n\r\n              <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\" *ngIf=\"enable_eLearn_feature_flag\">\r\n                <div class=\"field-wrapper\">\r\n                  <br>\r\n                  <input type=\"radio\" class=\"form-ctrl\" name=\"is_offline_or_online\" value=\"Online\"\r\n                    formControlName=\"is_offline_or_online\" id=\"is_offline_or_online\"><label\r\n                    class=\"online_offline_label\">Online</label>\r\n                  <input type=\"radio\" class=\"form-ctrl\" name=\"is_offline_or_online\" value=\"Offline\"\r\n                    formControlName=\"is_offline_or_online\" id=\"is_offline_or_online\"><label\r\n                    class=\"online_offline_label\">Offline</label>\r\n                  <input type=\"radio\" class=\"form-ctrl\" name=\"is_offline_or_online\" value=\"Both\"\r\n                    formControlName=\"is_offline_or_online\" id=\"is_offline_or_online\"><label\r\n                    class=\"online_offline_label\">Both</label>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"row pull-right\" style=\"margin-right:40px\">\r\n              <button [disabled]='!addItemForm.valid' id=\"btnSave\" class=\"btn fullBlue\" type=\"submit\"> Save </button>\r\n            </div>\r\n          </form>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n\r\n<!-- Allocate Item Sub Branch -->\r\n<!-- =============================================================================== -->\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"showAllocationBranchPopUp\">\r\n  <div class=\"popup pos-abs popup-body-container\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closeAllocateSubBranchPopup()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n          <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n            <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\"\r\n                transform=\"translate(992.81 305.77) rotate(45)\" />\r\n              <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\"\r\n                transform=\"translate(978.81 305.77) rotate(45)\" />\r\n            </g>\r\n            <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\"\r\n              transform=\"translate(1012 297)\" />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content\">\r\n        <div class=\"row\">\r\n          <div class=\"c-lg-6 c-md-6 c-sm-6\">\r\n            <h2>Item Name : {{allocateItemRowClicked.item_name}} </h2>\r\n          </div>\r\n          <div>\r\n            <h2>Available Unit : {{allocateItemRowClicked.available_units}}</h2>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"\">\r\n          <h3>Allocate Inventory Item To Sub Branch</h3>\r\n        </div>\r\n\r\n        <form [formGroup]=\"allocateItemForm\" novalidate (ngSubmit)=\"allocateItemToBranches()\">\r\n          <div class=\"row \">\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n              <div class=\"field-wrapper has-value\">\r\n                <label for=\"item\">Sub Branch\r\n                  <span class=\"text-danger\">*</span>\r\n                </label>\r\n                <select id=\"\" class=\"form-ctrl\" formControlName=\"sub_branch_id\" (change)=\"onSubBranchSelection()\">\r\n                  <option value=\"-1\"></option>\r\n                  <option *ngFor=\"let opt of subBranchList\" [value]=\"opt.institute_id\">\r\n                    {{opt.institute_name}}\r\n                  </option>\r\n                </select>\r\n\r\n                <div\r\n                  *ngIf=\"allocateItemForm.controls['sub_branch_id'].invalid && (allocateItemForm.controls['sub_branch_id'].dirty || allocateItemForm.controls['sub_branch_id'].touched)\"\r\n                  class=\"alert alert-danger\">\r\n                  <div *ngIf=\"allocateItemForm.controls['sub_branch_id'].hasError('required')\">\r\n                    Sub Branch Name is required.\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"label\">Sub Branch Item\r\n                  <span class=\"text-danger\">*</span>\r\n                </label>\r\n                <select id=\"\" class=\"form-ctrl\" formControlName=\"sub_branch_item_id\" (click)=\"onSelectSubBranchItem()\">\r\n                  <option *ngFor=\"let opt of subBranchItemList\" [value]=\"opt.item_id\">\r\n                    {{opt.item_name}}({{opt.category_name}})\r\n                  </option>\r\n                </select>\r\n\r\n                <span *ngIf=\"showAvailableUnits\">Units available in Sub Branch: {{availabelItemCount}}</span>\r\n                <div\r\n                  *ngIf=\"allocateItemForm.controls['sub_branch_item_id'].invalid && (allocateItemForm.controls['sub_branch_item_id'].dirty || allocateItemForm.controls['sub_branch_item_id'].touched)\"\r\n                  class=\"alert alert-danger\">\r\n                  <div *ngIf=\"allocateItemForm.controls['sub_branch_item_id'].hasError('required')\">\r\n                    Sub Branch Item is required.\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n\r\n          <div class=\"row \">\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"item\">Allocate Unit\r\n                  <span class=\"text-danger\">*</span>\r\n                </label>\r\n                <input type=\"number\" class=\"form-ctrl\" formControlName=\"alloted_units\" name=\"item\">\r\n\r\n                <div\r\n                  *ngIf=\"allocateItemForm.controls['alloted_units'].invalid && (allocateItemForm.controls['alloted_units'].dirty || allocateItemForm.controls['alloted_units'].touched)\"\r\n                  class=\"alert alert-danger\">\r\n                  <div *ngIf=\"allocateItemForm.controls['alloted_units'].hasError('required')\">\r\n                    Alloted Unit is required.\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"label\">Transport\r\n                </label>\r\n                <input type=\"text\" class=\"form-ctrl\" formControlName=\"transport\" name=\"label\">\r\n\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n\r\n          <div class=\"row \">\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"item\">Challan No.\r\n                </label>\r\n                <input type=\"number\" class=\"form-ctrl\" formControlName=\"challan_no\" name=\"item\">\r\n\r\n              </div>\r\n            </div>\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n              <div class=\"field-wrapper datePickerBox\">\r\n                <label for=\"createdDate\">Challan Date</label>\r\n                <input type=\"text\" value=\"\" id=\"followupdate\" class=\"form-ctrl\" formControlName=\"challan_date\"\r\n                  style=\"cursor: pointer;\" name=\"createdDate\" readonly=\"true\" bsDatepicker />\r\n\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"row\">\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"item\">Challan Amount (Rs)\r\n                </label>\r\n                <input type=\"number\" class=\"form-ctrl\" formControlName=\"challan_amount\" name=\"item\">\r\n\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"row pull-right\" style=\"margin-right:40px\">\r\n            <button id=\"btnSave\" class=\"btn fullBlue\" type=\"submit\"> Allocate </button>\r\n          </div>\r\n\r\n        </form>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n\r\n<!-- Allocation Item History -->\r\n<!-- =============================================================================== -->\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"showAllocationHistoryPopUp\">\r\n  <div class=\"popup pos-abs popup-body-container\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closeAllocationItemHistoryPopup()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n          <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n            <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\"\r\n                transform=\"translate(992.81 305.77) rotate(45)\" />\r\n              <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\"\r\n                transform=\"translate(978.81 305.77) rotate(45)\" />\r\n            </g>\r\n            <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\"\r\n              transform=\"translate(1012 297)\" />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content\">\r\n        <div>\r\n          <h2>Inventory Item Transaction History</h2>\r\n        </div>\r\n        <div>\r\n          <h3>Item Name : {{itemName}} </h3>\r\n        </div>\r\n\r\n        <div style=\"margin-top: 15px;max-height: 250px;overflow: scroll;\">\r\n          <table>\r\n            <thead>\r\n              <th>\r\n                S No.\r\n              </th>\r\n              <th>\r\n                Date\r\n              </th>\r\n              <th>\r\n                From/To\r\n              </th>\r\n              <th>\r\n                Contact No.\r\n              </th>\r\n              <th>\r\n                Quantity\r\n              </th>\r\n              <th>\r\n                IN/OUT\r\n              </th>\r\n              <th>\r\n                Others\r\n              </th>\r\n            </thead>\r\n            <tbody>\r\n              <tr id=\"row{{i}}\" *ngFor=\"let row of allocationHistoryList; let i = index; trackBy: i;\">\r\n                <td>\r\n                  {{i + 1}}\r\n                </td>\r\n                <td>\r\n                  {{row.created_date}}\r\n                </td>\r\n                <td>\r\n                  {{row.user_name}}\r\n                </td>\r\n                <td>\r\n                  {{row.contact_no}}\r\n                </td>\r\n                <td>\r\n                  {{row.alloted_units}}\r\n                </td>\r\n                <td>\r\n                  <span *ngIf=\"(row.inventory_type == 1)\"> IN </span>\r\n                  <span *ngIf=\"(row.inventory_type == 2)\"> OUT </span>\r\n                </td>\r\n                <td>\r\n                  <span [innerHTML]=\"row.other_details\" style=\"float: left; text-align: left\"></span>\r\n                </td>\r\n              </tr>\r\n              <tr *ngIf=\"(allocationHistoryList.length == 0)\">\r\n                <td colspan=\"7\">\r\n                  No data found\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>"

/***/ }),

/***/ "./src/app/components/inventory/inventory-home/inventory-home.component.scss":
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.inventory-table {\n  max-height: 400px;\n  overflow: visible; }\n.inventory-table #item-Table {\n    max-height: 400px;\n    overflow-x: hidden;\n    overflow-y: auto; }\n.dropdown-trigger {\n  background: transparent;\n  padding: 8px 8px 0px 8px;\n  border-radius: 50%; }\n.dropdown-trigger:hover {\n    background: #dadada; }\n.svg-icon-wrap {\n  display: inline-block; }\n.visually-hidden {\n  display: block;\n  border: 0;\n  clip: rect(0 0 0 0);\n  height: 1px;\n  margin: -1px;\n  overflow: hidden;\n  padding: 0;\n  position: absolute;\n  white-space: nowrap;\n  width: 1px; }\n.dd-list-container {\n  position: absolute;\n  border: 1px solid rgba(119, 119, 119, 0.29);\n  right: 10px;\n  z-index: 100;\n  bottom: 0px;\n  width: 180px;\n  height: auto;\n  background: white;\n  -webkit-box-shadow: 0px 0px 2px 0px rgba(0, 0, 0, 0.611765);\n          box-shadow: 0px 0px 2px 0px rgba(0, 0, 0, 0.611765); }\n.actions-menu {\n  list-style-type: none;\n  padding-left: 0;\n  margin-top: 0;\n  padding: 5px; }\n.actions-menu .action-item {\n    padding: 10px;\n    background: white;\n    display: -webkit-box !important;\n    display: -ms-flexbox !important;\n    display: flex !important;\n    margin: 0 !important;\n    cursor: pointer; }\n.actions-menu .action-item span {\n      padding: 5px 10px;\n      font-size: 14px;\n      font-weight: 600; }\n.actions-menu .action-item img {\n      max-width: 100%;\n      height: auto;\n      margin-right: 8px; }\n.actions-menu .action-item:hover {\n      background: #eff1f5; }\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.search-filter-wrapper .normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  width: 50%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  height: 35px;\n  font-size: 14px; }\n.search-filter-wrapper .field-wrapper {\n  position: relative;\n  padding-top: 0px !important;\n  width: 30%;\n  float: left !important; }\n.search-filter-wrapper .field-wrapper .form-ctrl {\n    font: 400 12px \"Open sans\", sans-serif;\n    border-top: none !important;\n    border-right: none !important;\n    border-left: none !important; }\n.search-filter-wrapper .field-wrapper label {\n  position: absolute !important;\n  left: 10% !important;\n  top: 1% !important; }\n.search-filter-wrapper .field-wrapper label:after {\n    left: 85% !important;\n    top: 10px !important; }\n.normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  width: 74%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  border-right: 0;\n  height: 35px;\n  font-size: 14px; }\n.middle-top h1 {\n  margin-top: 8px;\n  margin-bottom: 10px;\n  float: none; }\n.middle-top aside {\n  float: left; }\n/*=======================filter type==============*/\n.filter-res label {\n  font-size: 14px;\n  font-weight: 600; }\n.pagination .first:before {\n  content: \"« \";\n  font-size: 16px;\n  font-weight: 800; }\n.pagination .last:after {\n  content: \" »\";\n  font-size: 16px;\n  font-weight: 800; }\n.pagination .batch-size {\n  font-size: 16px;\n  font-weight: 800;\n  border-bottom: 1px solid black; }\n.pagination li {\n  border-right: 1px solid #ccc;\n  padding: 0px 7px;\n  margin: 0;\n  line-height: 10px;\n  font-weight: 800;\n  cursor: pointer; }\n.pagination li a {\n    line-height: 10px;\n    font-size: 16px;\n    font-weight: 800;\n    border: none;\n    padding: 0px 14px; }\n.pagination li:last-child {\n  border-right: 0;\n  padding-right: 0; }\n/*===========================================action tooltip of table===================*/\n/**===============================search data=========================*/\n.search-data th {\n  padding: 10px 20px;\n  font-weight: 500; }\n.search-data td {\n  font-size: 14px;\n  line-height: normal;\n  padding: 6px 5px; }\n.search-data tr th:first-child,\n.search-data tr td:first-child {\n  padding: 15px 2px; }\n.search-data tr th:first-child .field-checkbox-wrapper,\n  .search-data tr td:first-child .field-checkbox-wrapper {\n    background: transparent; }\n.search-data tr th:last-child {\n  padding: 0; }\n/*=====================================mobile head menu css===========================*/\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 850px;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n/*=========================================registration popup form css==================*/\n/*=======================================confirmation =========================*/\n.popup-btn {\n  margin-top: 20px; }\n.popup-btn .btn {\n    font-size: 14px;\n    height: 30px;\n    color: #333; }\n.popup-btn .btn.redBtn {\n      color: #fff;\n      min-width: 160px; }\ntable thead tr th {\n  padding-top: 10px;\n  padding-bottom: 10px; }\ntable thead .displayComp .edit-comp {\n  display: none; }\ntable thead .editComp .view-comp {\n  display: none; }\ntable tbody tr td {\n  padding: 0px 0px !important; }\ntable tbody tr td .editOptions li {\n    display: inline-block; }\ntable tbody tr td .field-wrapper {\n    padding: 0px !important; }\ntable tbody tr td .field-wrapper .form-ctrl {\n      display: block;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      padding: 0px 0px 0px 5px;\n      outline: none;\n      border: 0;\n      height: 26px;\n      -webkit-box-shadow: none;\n              box-shadow: none;\n      border-radius: 0;\n      line-height: 25px;\n      background: transparent;\n      width: 80px;\n      text-align: center;\n      border-bottom: 1px solid #ccc; }\ntable tbody .displayComp .view-comp .displayAddItem .edit-addItem {\n  display: none; }\ntable tbody .displayComp .view-comp .editAddItem .view-addItem {\n  display: none; }\ntable tbody .displayComp .edit-comp {\n  display: none; }\ntable tbody .editComp .view-comp {\n  display: none; }\n.table-action ul li {\n  display: inline-block;\n  margin: 0px 5px; }\n.table-action ul li a {\n    cursor: pointer; }\n.row.extraMargin {\n  margin: 10px 0px 25px 0px; }\n.btn.fullBlue {\n  background: #0084f6;\n  border: 1px solid #0084f6;\n  color: #fff; }\ninput[type=\"number\"]::-webkit-inner-spin-button,\ninput[type=\"number\"]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0; }\n/*===========================================action tooltip of table===================*/\n.enquiry-action {\n  position: relative;\n  cursor: pointer; }\n.enquiry-action .cls-1,\n  .enquiry-action .cls-2 {\n    fill: none;\n    stroke: transparent; }\n.enquiry-action svg {\n    width: 18px; }\n.enquiry-action .cls-2 {\n    stroke: #7d7f80;\n    stroke-miterlimit: 10; }\n.enquiry-action:hover .action-icon svg .cls-2 {\n    stroke: #0084f6;\n    stroke-miterlimit: 10; }\n.action-menu {\n  position: absolute;\n  background: #fff;\n  width: 200px;\n  border-radius: 0;\n  border: 1px solid #ccc;\n  bottom: 15px;\n  -webkit-box-shadow: 0px 2px 4px 1px #ccc;\n          box-shadow: 0px 2px 4px 1px #ccc;\n  -webkit-transform: translateX(-50%);\n          transform: translateX(-50%);\n  left: 50%;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.6s;\n  transition: all 0.6s; }\n.madeDate .field-wrapper {\n  margin: 0px 0; }\n.madeDate .field-wrapper.datePickerBox:after {\n    content: \"\";\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    right: 5px;\n    top: 33px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.enquiry-action:hover .action-menu {\n  visibility: visible;\n  opacity: 1;\n  bottom: 8px; }\n.action-menu-inner ul {\n  font-size: 0;\n  position: relative; }\n.action-menu-inner ul:after {\n  content: \"\";\n  position: absolute;\n  right: 0;\n  left: 0;\n  bottom: -15px;\n  margin: auto;\n  border-top: 8px solid #fff;\n  border-bottom: 8px solid transparent;\n  border-right: 8px solid transparent;\n  border-left: 8px solid transparent;\n  width: 0;\n  height: 0; }\n.action-menu-inner ul li {\n  display: inline-block;\n  text-align: center;\n  vertical-align: top;\n  font-size: 12px;\n  padding: 0 8px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  cursor: pointer;\n  width: 18%; }\n.action-menu-inner ul li:last-child {\n    width: 28%; }\n.action-menu-inner ul li:last-child svg {\n      width: 33px; }\n.action-menu-inner ul li.edit-detail-icon svg * {\n    fill: none;\n    stroke: #8b8b8b; }\n.action-menu-inner ul li.edit-detail-icon svg .cls-1 {\n    stroke: none;\n    /* stroke: #8b8b8b; */ }\n.action-menu-inner ul li:hover {\n    color: #0084f6; }\n.action-menu-inner ul li:hover .cls-2,\n    .action-menu-inner ul li:hover .cls-3 {\n      fill: none;\n      stroke: #0084f6; }\n.action-menu-inner ul li span {\n  display: block;\n  font-size: 9px;\n  text-align: center;\n  line-height: 10px; }\n.action-menu-inner .close {\n  position: absolute;\n  right: 4px;\n  top: 2px; }\n.action-menu-inner i {\n  display: block;\n  height: 32px; }\n.enquiry-action li svg {\n  width: 28px; }\n.listClasses {\n  height: 50px;\n  width: 25%; }\n.listClasses .imageContent {\n    height: 25px; }\n.listClasses .textContent {\n    font-weight: 700; }\n.boxPadding15 {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 0 15px; }\n.editCellAllignment {\n  text-align: center;\n  margin-left: 30px; }\n.btnWrapper .btn {\n  padding: 2px 7px 0px 7px;\n  border: none;\n  height: 35px;\n  width: 35px;\n  border-radius: 50%; }\n.btnWrapper .btn .tooltip {\n    position: relative;\n    top: -30px;\n    right: -30px;\n    min-width: 100px;\n    font-size: 12px;\n    padding: 6px;\n    height: 35px;\n    border-radius: 5px;\n    background: rgba(0, 0, 0, 0.541);\n    color: white;\n    visibility: hidden;\n    opacity: 0; }\n.btnWrapper .btn:hover {\n    background: #d8d6d6; }\n.btnWrapper .btn:hover .tooltip {\n      position: relative;\n      top: -30px;\n      right: 120px;\n      min-width: 100px;\n      padding: 6px;\n      border-radius: 5px;\n      font-size: 12px;\n      height: 35px;\n      background: rgba(0, 0, 0, 0.541);\n      color: white;\n      visibility: visible;\n      opacity: 1;\n      -webkit-transition: all 0.2s;\n      transition: all 0.2s; }\n.btnWrapper .btn:focus {\n    outline: none; }\n.btnWrapper .btn:active {\n    -webkit-box-shadow: none;\n            box-shadow: none; }\n.tooltipSpan {\n  height: 30px !important;\n  top: -60px !important;\n  min-width: 75px !important;\n  right: 30px !important; }\n.addQuantityInput {\n  max-width: 35px;\n  text-align: center;\n  margin-left: 30px; }\n.lowquantity {\n  color: red; }\ninput[type=\"radio\"] {\n  -webkit-appearance: radio;\n  width: 5%;\n  margin-top: 0;\n  float: left; }\n.online_offline_label {\n  float: left;\n  margin-right: 5%; }\n"

/***/ }),

/***/ "./src/app/components/inventory/inventory-home/inventory-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_rxjs_Rx__ = __webpack_require__("./node_modules/rxjs/_esm5/Rx.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_inventory_services_inventory_service__ = __webpack_require__("./src/app/services/inventory-services/inventory.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var HomeComponent = /** @class */ (function () {
    function HomeComponent(inventoryApi, fb, msg, auth) {
        this.inventoryApi = inventoryApi;
        this.fb = fb;
        this.msg = msg;
        this.auth = auth;
        this.courseList = [];
        this.itemTableDatasource = [];
        this.itemList = [];
        this.categoryList = [];
        this.masterCategoryList = [];
        this.subBranchList = [];
        this.searchData = [];
        this.selectedRow = "";
        this.operationFlag = "";
        this.itemName = "";
        this.PageIndex = 1;
        this.studentdisplaysize = 10;
        this.totalRow = 0;
        this.isAddUnit = false;
        this.subtractFlag = false;
        this.deleteItemPopUp = false;
        this.createItemPopUp = false;
        this.showAllocateOption = false;
        this.showAllocationBranchPopUp = false;
        this.showAvailableUnits = false;
        this.isProfessional = false;
        this.showAllocationHistoryPopUp = false;
        this.searchDataFlag = false;
        this.isRippleLoad = false;
        this.showMenu = false;
        this.enable_eLearn_feature_flag = false;
        this.header = {
            inventory_item: { id: 'inventory_item', title: 'Inventory Item', filter: false, show: true },
            category: { id: 'category', title: 'Category', filter: false, show: true },
            description: { id: 'description', title: 'Description', filter: false, show: true },
            master_course: { id: 'master_course', title: 'Master Course', filter: false, show: true },
            course: { id: 'course', title: 'Course', filter: false, show: true },
            total_units: { id: 'total_units', title: 'Total Units', filter: false, show: true },
            available: { id: 'available', title: 'Available Units', filter: false, show: true },
            edit: { id: 'edit', title: 'Action', filter: false, show: true },
            add_units: { id: 'add_units', title: 'Add Units', filter: false, show: true },
            cost: { id: 'cost', title: 'Unit Cost', filter: false, show: true },
        };
    }
    HomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.checkMainBranchOrSubBranch();
        this.loadTableDatatoSource();
        this.loadItemCategories();
        this.loadItemCategoryMaster();
        this.checkEnableElearnFeature();
    };
    HomeComponent.prototype.checkEnableElearnFeature = function () {
        var enable_eLearn_feature;
        enable_eLearn_feature = sessionStorage.getItem('enable_eLearn_feature');
        if (enable_eLearn_feature == 1) {
            this.enable_eLearn_feature_flag = true;
        }
    };
    HomeComponent.prototype.checkMainBranchOrSubBranch = function () {
        var sessionData = sessionStorage.getItem('is_main_branch');
        if (sessionData == "Y") {
            this.showAllocateOption = true;
        }
        else {
            this.showAllocateOption = false;
        }
    };
    HomeComponent.prototype.loadTableDatatoSource = function () {
        var _this = this;
        this.itemList = [];
        this.isRippleLoad = true;
        this.itemTableDatasource = [];
        this.inventoryApi.fetchAllItems().subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.totalRow = data.length;
            _this.itemTableDatasource = data;
            _this.fetchTableDataByPage(_this.PageIndex);
            _this.selectedRow = "";
        }, function (error) {
            _this.isRippleLoad = false;
            //console.log(error);
        });
    };
    HomeComponent.prototype.loadItemCategories = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.inventoryApi.fetchAllCategories().subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.categoryList = data;
        }, function (error) {
            _this.isRippleLoad = false;
            //console.log(error)
        });
    };
    HomeComponent.prototype.loadItemCategoryMaster = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.inventoryApi.fetchAllMasterCategoryItem().subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.masterCategoryList = data;
        }, function (error) {
            _this.isRippleLoad = false;
            //console.log(error);
        });
    };
    HomeComponent.prototype.editRow = function (row_no, item_id) {
        //console.log(row_no)
        this.isAddUnit = false;
        if (this.selectedRow !== "") {
            //console.log(this.selectedRow);
            document.getElementById(("row" + this.selectedRow).toString()).classList.add('displayComp');
            document.getElementById(("row" + this.selectedRow).toString()).classList.remove('editComp');
        }
        this.selectedRow = row_no;
        document.getElementById(("table-header").toString()).classList.remove('displayComp');
        document.getElementById(("table-header").toString()).classList.add('editComp');
        document.getElementById(("row" + row_no).toString()).classList.remove('displayComp');
        document.getElementById(("row" + row_no).toString()).classList.add('editComp');
    };
    HomeComponent.prototype.cancelRow = function (row_no) {
        this.isAddUnit = false;
        this.loadTableDatatoSource();
        document.getElementById(("table-header").toString()).classList.add('displayComp');
        document.getElementById(("table-header").toString()).classList.remove('editComp');
        document.getElementById(("row" + row_no).toString()).classList.add('displayComp');
        document.getElementById(("row" + row_no).toString()).classList.remove('editComp');
    };
    HomeComponent.prototype.addItemsEnable = function (i) {
        document.getElementById(("add-item" + i).toString()).classList.add('editAddItem');
        document.getElementById(("add-item" + i).toString()).classList.remove('displayAddItem');
    };
    HomeComponent.prototype.subtractItemsEnable = function (i) {
        document.getElementById(("add-item" + i).toString()).classList.add('editAddItem');
        document.getElementById(("add-item" + i).toString()).classList.remove('displayAddItem');
        this.subtractFlag = true;
    };
    HomeComponent.prototype.addItemsQuantity = function (row) {
        var _this = this;
        if (row.units_added > 0) {
            var data = {};
            data.item_id = row.item_id;
            if (this.subtractFlag) {
                data.units_added = "-" + Math.floor(row.units_added);
            }
            else {
                data.units_added = Math.floor(row.units_added);
            }
            this.isRippleLoad = true;
            this.inventoryApi.addQuantityInStock(data).subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.loadTableDatatoSource();
                _this.subtractFlag = false;
            }, function (error) {
                _this.isRippleLoad = false;
                _this.subtractFlag = false;
                _this.msg.showErrorMessage("error", '', error.error.message);
                _this.loadTableDatatoSource();
                //console.log('Add Stock Error', error);
            });
        }
    };
    HomeComponent.prototype.cancelItem = function (i) {
        document.getElementById(("add-item" + i).toString()).classList.add('displayAddItem');
        document.getElementById(("add-item" + i).toString()).classList.remove('editAddItem');
        this.fetchTableDataByPage(this.PageIndex);
        this.totalRow = this.itemTableDatasource.length;
    };
    HomeComponent.prototype.updateRow = function (row, i) {
        var _this = this;
        var postdata = {
            category_id: row.category_id,
            desc: row.desc,
            institution_id: "",
            item_id: row.item_id.toString(),
            item_name: row.item_name,
            standard_id: row.standard_id.toString(),
            subject_id: row.subject_id.toString(),
            unit_cost: row.unit_cost.toString(),
            out_of_stock_indicator_units: row.out_of_stock_indicator_units.toString(),
            is_offline_or_online: row.is_offline_or_online
        };
        this.isRippleLoad = true;
        this.inventoryApi.updateInventoryItem(postdata).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.loadTableDatatoSource();
            document.getElementById(("row" + i).toString()).classList.add('displayComp');
            document.getElementById(("row" + i).toString()).classList.remove('editComp');
        }, function (error) {
            _this.isRippleLoad = false;
            _this.msg.showErrorMessage("error", '', error.error.message);
        });
    };
    HomeComponent.prototype.deleteRow = function (row, index) {
        this.deleteItemPopUp = true;
        this.deleteRowDetails = row;
    };
    HomeComponent.prototype.closeDeletePopup = function () {
        this.deleteItemPopUp = false;
    };
    HomeComponent.prototype.deleteStudent = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.inventoryApi.deleteRowFromItem(this.deleteRowDetails.item_id).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.loadTableDatatoSource();
            _this.deleteItemPopUp = false;
            _this.msg.showErrorMessage("success", "", "Inventory Deleted Successfully");
        }, function (error) {
            _this.isRippleLoad = false;
            _this.msg.showErrorMessage("error", '', error.error.message);
        });
    };
    HomeComponent.prototype.allocationDetails = function (row, i) {
        var _this = this;
        //console.log(i);
        this.itemName = row.item_name;
        this.isRippleLoad = true;
        this.inventoryApi.getInventoryItemHistory(row.item_id).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.showAllocationHistoryPopUp = true;
            _this.allocationHistoryList = data;
        }, function (error) {
            _this.isRippleLoad = false;
            _this.msg.showErrorMessage("error", '', error.error.message);
        });
    };
    HomeComponent.prototype.closeAllocationItemHistoryPopup = function () {
        this.showAllocationHistoryPopUp = false;
    };
    HomeComponent.prototype.searchDatabase = function (element) {
        if (element.value != "" && element.value != undefined && element.value != null) {
            var searchData = this.itemTableDatasource.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(element.value.toLowerCase()); });
            });
            this.searchData = searchData;
            this.totalRow = searchData.length;
            this.searchDataFlag = true;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchDataFlag = false;
            this.fetchTableDataByPage(this.PageIndex);
            this.totalRow = this.itemTableDatasource.length;
        }
    };
    // pagination functions 
    HomeComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.studentdisplaysize * (index - 1);
        this.itemList = Array.from(this.getDataFromDataSource(startindex));
        //console.log(this.itemList);
    };
    HomeComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    HomeComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    HomeComponent.prototype.getDataFromDataSource = function (startindex) {
        var data = [];
        if (this.searchDataFlag) {
            data = this.searchData.slice(startindex, startindex + this.studentdisplaysize);
        }
        else {
            data = this.itemTableDatasource.slice(startindex, startindex + this.studentdisplaysize);
        }
        return data;
    };
    //// Add Item Form
    HomeComponent.prototype.createAddItemForm = function () {
        this.addItemForm = this.fb.group({
            item_name: ['', [__WEBPACK_IMPORTED_MODULE_2__angular_forms__["Validators"].required]],
            desc: [''],
            categoryDet: ['', [__WEBPACK_IMPORTED_MODULE_2__angular_forms__["Validators"].required]],
            alloted_units: ['', __WEBPACK_IMPORTED_MODULE_2__angular_forms__["Validators"].required],
            standardDet: [''],
            subjectDet: [''],
            unit_cost: [''],
            created_date: [__WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-DD")],
            out_of_stock_indicator_units: [''],
            is_offline_or_online: ['']
        });
    };
    ///// To add a Item 
    HomeComponent.prototype.addItemDetails = function () {
        this.createAddItemForm();
        this.createItemPopUp = true;
    };
    //// Add Item Pop Up Function
    HomeComponent.prototype.closeCreatePopup = function () {
        this.createItemPopUp = false;
    };
    HomeComponent.prototype.masterCourseSelected = function () {
        var _this = this;
        var courseId = this.addItemForm.value.standardDet;
        this.isRippleLoad = true;
        this.inventoryApi.getCourseOnBasisOfMasterCourse(courseId).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.courseList = data;
        }, function (error) {
            _this.isRippleLoad = false;
            //console.log('', error);
        });
    };
    HomeComponent.prototype.saveItemDetails = function () {
        var _this = this;
        var data = {};
        data.alloted_units = this.addItemForm.value.alloted_units.toString();
        data.category_id = this.addItemForm.value.categoryDet;
        if (data.category_id == -1) {
            this.msg.showErrorMessage("error", '', "Please enter category");
            return;
        }
        data.created_date = this.addItemForm.value.created_date;
        data.desc = this.addItemForm.value.desc;
        data.item_name = this.addItemForm.value.item_name;
        data.standard_id = this.addItemForm.value.standardDet;
        if (data.standard_id == null || data.standard_id == "") {
            data.standard_id = -1;
        }
        data.subject_id = this.addItemForm.value.subjectDet;
        if (data.subject_id == null || data.subject_id == "") {
            data.subject_id = -1;
        }
        data.unit_cost = this.addItemForm.value.unit_cost.toString();
        data.out_of_stock_indicator_units = this.addItemForm.value.out_of_stock_indicator_units;
        data.is_offline_or_online = this.addItemForm.value.is_offline_or_online;
        this.isRippleLoad = true;
        this.inventoryApi.addItemDetailsInCategory(data).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.loadTableDatatoSource();
            _this.createItemPopUp = false;
        }, function (error) {
            _this.isRippleLoad = false;
            _this.msg.showErrorMessage("error", '', error.error.message);
        });
    };
    /////// Multi Branch Data And Function Check Point
    HomeComponent.prototype.allocateQuantityToSubBranches = function (row) {
        //console.log(row);
        this.allocateItemRowClicked = row;
        this.showAllocationBranchPopUp = true;
        this.createAllocationForm();
        this.getItemInformation(row.item_id);
        this.getAllSubBranchesInformation();
    };
    HomeComponent.prototype.createAllocationForm = function () {
        this.allocateItemForm = this.fb.group({
            transport: [''],
            challan_no: [''],
            challan_amount: [''],
            alloted_units: ['', [__WEBPACK_IMPORTED_MODULE_2__angular_forms__["Validators"].required]],
            challan_date: [''],
            sub_branch_id: ['', [__WEBPACK_IMPORTED_MODULE_2__angular_forms__["Validators"].required]],
            sub_branch_item_id: ['', [__WEBPACK_IMPORTED_MODULE_2__angular_forms__["Validators"].required]],
            item_id: ['']
        });
    };
    HomeComponent.prototype.getItemInformation = function (rowId) {
        var _this = this;
        this.isRippleLoad = true;
        this.inventoryApi.getItemDetailsForSubBranches(rowId).subscribe(function (data) {
            _this.isRippleLoad = false;
            //console.log("getItemInfo", data);
            _this.allocateItemDetails = data;
        }, function (error) {
            _this.isRippleLoad = false;
            _this.msg.showErrorMessage("error", '', error.error.message);
        });
    };
    HomeComponent.prototype.getAllSubBranchesInformation = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.inventoryApi.getAllSubBranchesInfo().subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.subBranchList = data;
            //console.log('All Branches', data);
        }, function (error) {
            _this.isRippleLoad = false;
            //console.log(error);
        });
    };
    HomeComponent.prototype.onSubBranchSelection = function () {
        var _this = this;
        var data_id = this.allocateItemForm.value.sub_branch_id;
        if (data_id != "-1") {
            this.isRippleLoad = true;
            this.inventoryApi.getSubBranchItemInfo(data_id).subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.subBranchItemList = data;
            }, function (error) {
                _this.isRippleLoad = false;
                console.log('', error);
            });
        }
        else {
            this.subBranchItemList = [];
        }
    };
    HomeComponent.prototype.onSelectSubBranchItem = function () {
        var _this = this;
        var subBranchItemId = this.allocateItemForm.value.sub_branch_item_id;
        this.subBranchItemList.forEach(function (element) {
            if (element.item_id == subBranchItemId) {
                _this.showAvailableUnits = true;
                _this.availabelItemCount = element.available_units;
            }
        });
    };
    /* open action menu on click */
    HomeComponent.prototype.openMenu = function (index) {
        this.selectedRow = index;
        var len = this.itemList.length;
        for (var i = 0; i < len; i++) {
            if (i == index) {
                document.getElementById('menuList' + i).classList.toggle('hide');
            }
            else if (i != index) {
                document.getElementById('menuList' + i).classList.add('hide');
            }
        }
    };
    /* close action menu on events  */
    HomeComponent.prototype.closeMenu = function () {
        document.getElementById('menuList' + this.selectedRow).classList.add('hide');
    };
    HomeComponent.prototype.onWindowClick = function (event) {
        if (this.ActionInv.nativeElement.contains(event.target)) {
            //console.log("clicked inside table");
        }
        else {
            if (document.getElementById('menuList' + this.selectedRow) != null) {
                document.getElementById('menuList' + this.selectedRow).classList.add('hide');
            }
        }
    };
    HomeComponent.prototype.validateMandatoryFields = function () {
        if (this.allocateItemForm.value.sub_branch_id == "" || this.allocateItemForm.value.sub_branch_id == null || this.allocateItemForm.value.sub_branch_id == '-1') {
            this.msg.showErrorMessage("error", '', "Please enter sub branch");
            return false;
        }
        if (this.allocateItemForm.value.sub_branch_item_id == "" || this.allocateItemForm.value.sub_branch_item_id == null) {
            this.msg.showErrorMessage("error", '', "Please enter sub branch item");
            return false;
        }
        if (this.allocateItemForm.value.alloted_units == "" || this.allocateItemForm.value.alloted_units == null) {
            this.msg.showErrorMessage("error", '', "Please enter no of allocation units");
            return false;
        }
        return true;
    };
    HomeComponent.prototype.allocateItemToBranches = function () {
        var _this = this;
        var check = this.validateMandatoryFields();
        if (check == false) {
            return;
        }
        var data = {};
        data.alloted_units = this.allocateItemForm.value.alloted_units;
        data.challan_amount = this.allocateItemForm.value.challan_amount;
        data.challan_date = this.allocateItemForm.value.challan_date;
        data.challan_no = this.allocateItemForm.value.challan_no;
        data.transport = this.allocateItemForm.value.transport;
        data.sub_branch_item_id = this.allocateItemForm.value.sub_branch_item_id;
        data.sub_branch_id = this.allocateItemForm.value.sub_branch_id;
        data.item_id = this.allocateItemRowClicked.item_id.toString();
        this.inventoryApi.allocateItemToSubBranch(data).subscribe(function (data) {
            _this.msg.showErrorMessage("success", '', "Successfully allocated to sub branch");
            _this.showAllocationBranchPopUp = false;
            _this.loadTableDatatoSource();
        }, function (error) {
            //console.log("Allocate Item", error);
            _this.msg.showErrorMessage("error", '', error.error.message);
        });
    };
    HomeComponent.prototype.closeAllocateSubBranchPopup = function () {
        this.showAllocationBranchPopUp = false;
        this.showAvailableUnits = false;
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('ActionInv'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], HomeComponent.prototype, "ActionInv", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["HostListener"])("document:click", ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], HomeComponent.prototype, "onWindowClick", null);
    HomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-home',
            template: __webpack_require__("./src/app/components/inventory/inventory-home/inventory-home.component.html"),
            styles: [__webpack_require__("./src/app/components/inventory/inventory-home/inventory-home.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_4__services_inventory_services_inventory_service__["a" /* InventoryService */],
            __WEBPACK_IMPORTED_MODULE_2__angular_forms__["FormBuilder"],
            __WEBPACK_IMPORTED_MODULE_5__services_message_show_service__["a" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_6__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ }),

/***/ "./src/app/components/inventory/inventory-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return InventoryRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__inventory_component__ = __webpack_require__("./src/app/components/inventory/inventory.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__inventory_home_inventory_home_component__ = __webpack_require__("./src/app/components/inventory/inventory-home/inventory-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__inventory_category_inventory_category_component__ = __webpack_require__("./src/app/components/inventory/inventory-category/inventory-category.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var InventoryRoutingModule = /** @class */ (function () {
    function InventoryRoutingModule() {
    }
    InventoryRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__inventory_component__["a" /* InventoryComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                redirectTo: 'item'
                            },
                            {
                                path: 'item',
                                component: __WEBPACK_IMPORTED_MODULE_3__inventory_home_inventory_home_component__["a" /* HomeComponent */]
                            },
                            {
                                path: 'category',
                                component: __WEBPACK_IMPORTED_MODULE_4__inventory_category_inventory_category_component__["a" /* InventoryCategoryComponent */]
                            }
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], InventoryRoutingModule);
    return InventoryRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/inventory/inventory.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"middle-section clearFix\">\r\n    <section class=\"middle-top mb0 clearFix\" style=\"margin-bottom: 10px;\">\r\n        <h1 class=\"pull-left\">\r\n            Manage Inventory\r\n        </h1>\r\n    </section>\r\n\r\n    <section class=\"middle-main clearFix\">\r\n        <div class=\"common-tab\">\r\n            <ul>\r\n                <li id=\"item\" (click)=\"switchActiveView('item')\" class=\"active\">\r\n                    <a routerLink=\"/view/inventory/item\">Item</a>\r\n                </li>\r\n                <li id=\"category\" (click)=\"switchActiveView('category')\" class=\"\">\r\n                    <a routerLink=\"/view/inventory/category\">Category</a>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n\r\n        <div class=\"router-container\">\r\n            <router-outlet></router-outlet>\r\n        </div>\r\n    </section>\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/components/inventory/inventory.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.router-container {\n  border: 1px solid #deeaee;\n  width: 100%; }\n.common-tab {\n  padding-top: 5px; }\n.common-tab ul {\n    font-size: 0;\n    border-bottom: 1px solid #f1f1f1; }\n.common-tab ul li {\n      margin-right: 1px;\n      display: inline-block;\n      width: 10%;\n      max-width: 158px;\n      cursor: pointer; }\n.common-tab ul li a {\n        display: block;\n        padding: 10px 5px;\n        background: #eff7ff;\n        border: 1px solid #cccdcd;\n        color: #0084f6;\n        text-align: center;\n        font-size: 14px;\n        font-weight: 600; }\n.common-tab ul li:hover a, .common-tab ul li.active a {\n        background: #0084f6;\n        color: #fff;\n        border-color: #0084f6;\n        font-weight: normal; }\n@media only screen and (max-width: 420px) {\n  .common-tab ul li {\n    width: auto; }\n    .common-tab ul li a {\n      font-size: 10px; }\n  .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 12px; } }\n@media only screen and (max-width: 767px) {\n  .common-tab ul li {\n    margin-right: 0;\n    width: 20%; }\n    .common-tab ul li a {\n      padding: 5px 5px;\n      font-size: 12px; } }\n.boxPadding15 {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 0 15px; }\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n"

/***/ }),

/***/ "./src/app/components/inventory/inventory.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return InventoryComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var InventoryComponent = /** @class */ (function () {
    function InventoryComponent(router) {
        this.router = router;
    }
    InventoryComponent.prototype.ngOnInit = function () {
        if (this.router.url.includes('category')) {
            this.switchActiveView('category');
        }
        else {
            this.switchActiveView('item');
        }
    };
    InventoryComponent.prototype.switchActiveView = function (tabName) {
        document.getElementById('item').classList.remove('active');
        document.getElementById('category').classList.remove('active');
        document.getElementById(tabName).classList.add('active');
    };
    InventoryComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-inventory',
            template: __webpack_require__("./src/app/components/inventory/inventory.component.html"),
            styles: [__webpack_require__("./src/app/components/inventory/inventory.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"]])
    ], InventoryComponent);
    return InventoryComponent;
}());



/***/ }),

/***/ "./src/app/components/inventory/inventory.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InventoryModule", function() { return InventoryModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__inventory_component__ = __webpack_require__("./src/app/components/inventory/inventory.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__inventory_routing_module__ = __webpack_require__("./src/app/components/inventory/inventory-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_primeng_primeng__ = __webpack_require__("./node_modules/primeng/primeng.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_primeng_primeng___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_primeng_primeng__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_hammerjs__ = __webpack_require__("./node_modules/hammerjs/hammer.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_hammerjs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8_hammerjs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__inventory_home_inventory_home_component__ = __webpack_require__("./src/app/components/inventory/inventory-home/inventory-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__inventory_category_inventory_category_component__ = __webpack_require__("./src/app/components/inventory/inventory-category/inventory-category.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__services_inventory_services_inventory_category_service__ = __webpack_require__("./src/app/services/inventory-services/inventory-category.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__services_inventory_services_inventory_service__ = __webpack_require__("./src/app/services/inventory-services/inventory.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










//import { HomeComponent } from './home/home.component';




var InventoryModule = /** @class */ (function () {
    function InventoryModule() {
    }
    InventoryModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_4__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_4__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_3__inventory_routing_module__["a" /* InventoryRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_5_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_6_primeng_primeng__["FileUploadModule"],
                __WEBPACK_IMPORTED_MODULE_6_primeng_primeng__["SplitButtonModule"],
                __WEBPACK_IMPORTED_MODULE_6_primeng_primeng__["MenuModule"],
                __WEBPACK_IMPORTED_MODULE_10__shared_shared_module__["a" /* SharedModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_2__inventory_component__["a" /* InventoryComponent */],
                __WEBPACK_IMPORTED_MODULE_9__inventory_home_inventory_home_component__["a" /* HomeComponent */],
                __WEBPACK_IMPORTED_MODULE_11__inventory_category_inventory_category_component__["a" /* InventoryCategoryComponent */]
            ],
            entryComponents: [],
            providers: [
                __WEBPACK_IMPORTED_MODULE_13__services_inventory_services_inventory_service__["a" /* InventoryService */],
                __WEBPACK_IMPORTED_MODULE_12__services_inventory_services_inventory_category_service__["a" /* InventoryCategoryService */]
            ]
        })
    ], InventoryModule);
    return InventoryModule;
}());



/***/ }),

/***/ "./src/app/services/inventory-services/inventory-category.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return InventoryCategoryService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var InventoryCategoryService = /** @class */ (function () {
    function InventoryCategoryService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_2__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    // Getting all category list from server
    InventoryCategoryService.prototype.getCategoryList = function () {
        var institution_id = parseInt(this.institute_id);
        var url = this.baseUrl + '/api/v1/inventory/category/all/' + institution_id;
        return this.http.get(url, { headers: this.headers }).map(function (success) {
            return success;
        }, function (err) {
            return err;
        });
    };
    // Add new category to the category list
    InventoryCategoryService.prototype.setNewCategory = function (data) {
        data.institution_id = parseInt(this.institute_id);
        var url = this.baseUrl + '/api/v1/inventory/category';
        return this.http.post(url, data, { headers: this.headers }).map(function (success) {
            return success;
        }, function (err) {
            return err;
        });
    };
    // to update the existing row
    InventoryCategoryService.prototype.updateExisting = function (data) {
        var url = this.baseUrl + '/api/v1/inventory/category';
        return this.http.put(url, data, { headers: this.headers }).map(function (success) {
            return success;
        }, function (err) {
            return err;
        });
    };
    InventoryCategoryService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__angular_common_http__["a" /* HttpClient */],
            __WEBPACK_IMPORTED_MODULE_1__authenticator_service__["a" /* AuthenticatorService */]])
    ], InventoryCategoryService);
    return InventoryCategoryService;
}());



/***/ }),

/***/ "./src/app/services/inventory-services/inventory.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return InventoryService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var InventoryService = /** @class */ (function () {
    function InventoryService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = "";
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    InventoryService.prototype.fetchAllItems = function () {
        var url = this.baseUrl + "/api/v1/inventory/item/all/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService.prototype.fetchAllCategories = function () {
        var url = this.baseUrl + "/api/v1/inventory/category/all/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService.prototype.updateInventoryItem = function (data) {
        data.institution_id = this.institute_id;
        var url = this.baseUrl + "/api/v1/inventory/item";
        return this.http.put(url, data, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService.prototype.fetchAllMasterCategoryItem = function () {
        var url = this.baseUrl + "/api/v1/standards/all/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService.prototype.deleteRowFromItem = function (rowID) {
        this.url = this.baseUrl + "/api/v1/inventory/item/" + rowID;
        return this.http.delete(this.url, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService.prototype.getCourseOnBasisOfMasterCourse = function (data_id) {
        var url = this.baseUrl + "/api/v1/subjects/standards/" + data_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService.prototype.addItemDetailsInCategory = function (data) {
        data.institution_id = this.institute_id;
        var url = this.baseUrl + "/api/v1/inventory/item";
        return this.http.post(url, data, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService.prototype.addQuantityInStock = function (data) {
        data.institution_id = this.institute_id;
        var url = this.baseUrl + "/api/v1/inventory/item/stockUpdate/";
        return this.http.put(url, data, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService.prototype.getItemDetailsForSubBranches = function (item_id) {
        var url = this.baseUrl + "/api/v1/inventory/item/" + this.institute_id + "/" + item_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService.prototype.getAllSubBranchesInfo = function () {
        var url = this.baseUrl + '/api/v1/institutes/all/subBranches/' + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService.prototype.getSubBranchItemInfo = function (dataId) {
        var url = this.baseUrl + '/api/v1/inventory/item/all/' + dataId;
        return this.http.get(url, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService.prototype.allocateItemToSubBranch = function (data) {
        data.institution_id = this.institute_id;
        var url = this.baseUrl + '/api/v1/inventory/item/allocate/subBranch';
        return this.http.post(url, data, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService.prototype.getInventoryItemHistory = function (item_id) {
        var url = this.baseUrl + "/api/v1/inventory/item/txHistory/" + item_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) { return data; }, function (err) { return err; });
    };
    InventoryService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */],
            __WEBPACK_IMPORTED_MODULE_2__authenticator_service__["a" /* AuthenticatorService */]])
    ], InventoryService);
    return InventoryService;
}());



/***/ })

});
//# sourceMappingURL=inventory.module.chunk.js.map