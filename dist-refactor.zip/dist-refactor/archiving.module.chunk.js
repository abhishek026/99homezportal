webpackJsonp(["archiving.module"],{

/***/ "./src/app/components/course-module/Archiving/archiving-home/archiving-home.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"middle-section\">\r\n  <section class=\"header-section\">\r\n    <div>\r\n      <div class=\"header-title\">\r\n        <h2>\r\n          <a routerLink=\"/view/{{type}}\" style=\"color: #0084f6;\">\r\n            {{ type | titlecase }}\r\n          </a>\r\n          <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i> Archiving\r\n        </h2>\r\n      </div>\r\n    </div>\r\n  </section>\r\n  <div class=\"course-menu-section-container\">\r\n\r\n      <div class=\"course-menu-item\" *ngIf=\"isProfessional\"  routerLink=\"./batches\">\r\n        <div class=\"menu-title\">\r\n          <img src=\"./assets/images/course/create-course.svg\" alt=\"create course\">\r\n          <span>  Batches</span>\r\n        </div>\r\n        <div class=\"menu-description\">\r\n          <span>  Select and archive the batches.</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"course-menu-item\" *ngIf=\"isProfessional\" routerLink=\"./batchesArchivedReport\">\r\n        <div class=\"menu-title\">\r\n          <img src=\"./assets/images/course/create-course.svg\" alt=\"create course\">\r\n          <span>  Batches Archived Status Report</span>\r\n        </div>\r\n        <div class=\"menu-description\">\r\n          <span>  Get the report of archived batches.</span>\r\n        </div>\r\n      </div>\r\n\r\n    <div class=\"course-menu-item\" *ngIf=\"!isProfessional\" routerLink=\"./courses\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/course/create-course.svg\" alt=\"create course\">\r\n        <span>  Courses</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>  Select and archive the courses.</span>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"course-menu-item\" *ngIf=\"!isProfessional\" routerLink=\"./coursesArchivedReport\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/course/create-course.svg\" alt=\"create course\">\r\n        <span>Courses Archived Status Report</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span> Get the report of archived courses.</span>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n</section>"

/***/ }),

/***/ "./src/app/components/course-module/Archiving/archiving-home/archiving-home.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/** these css for gear icon download options\r\n* created by laxmi\r\n*/\nsvg:hover #gearIcon {\n  fill: #0084f6; }\n.asHover:hover {\n  color: #0084f6 !important; }\n.download:hover {\n  cursor: pointer; }\n.made-in {\n  font-size: 17px;\n  font-weight: bold;\n  text-align: left; }\n.dropdown > ul {\n  background: #fff;\n  padding: 10px 20px;\n  border: 1px solid #eaeaeb;\n  border-top: 0;\n  margin-top: 3px;\n  -webkit-box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 6px 10px 0 rgba(0, 0, 0, 0.12);\n          box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 6px 10px 0 rgba(0, 0, 0, 0.12); }\n.dropdown > ul li {\n    color: #333; }\n.dropdown > ul li strong {\n      font-weight: 600;\n      display: block; }\n.dropdown > ul li a {\n      display: block;\n      color: #333; }\n.login-tube nav > ul > li {\n  display: inline-block;\n  position: relative; }\n.login-tube nav > ul > li > a {\n  color: #333;\n  text-decoration: none;\n  padding: 5px 10px;\n  display: block;\n  -webkit-transition: all .4s;\n  transition: all .4s; }\n.login-tube nav > ul > li > a:hover,\n.login-tube nav > ul > li:hover > a {\n  text-decoration: none;\n  background: #ccc; }\n.login-tube nav > ul > li .dropdown {\n  position: absolute;\n  visibility: hidden;\n  right: 0;\n  top: 100%;\n  min-width: 200px;\n  border-top: 0;\n  opacity: 0;\n  -webkit-transition: all 0.1s cubic-bezier(0.55, 0, 0.55, 0.2);\n  transition: all 0.1s cubic-bezier(0.55, 0, 0.55, 0.2);\n  -webkit-transition-duration: .25s;\n  transition-duration: .2s;\n  -webkit-transform: scale(0.5);\n          transform: scale(0.5); }\n.login-tube nav > ul > li .dropdown > ul li {\n    line-height: normal; }\n.login-tube nav > ul > li .dropdown > ul li a {\n      display: block;\n      margin: 5px 0; }\n.login-tube nav > ul > li .dropdown > ul li a:hover {\n        color: #0084f6; }\n.login-tube nav > ul > li .dropdown > ul ul {\n    padding-left: 15px;\n    padding-top: 10px; }\n.login-tube nav > ul > li .dropdown > ul ul ul {\n      padding-top: 0; }\n.login-tube nav > ul > li:hover .dropdown {\n  visibility: visible;\n  position: absolute;\n  opacity: 1;\n  right: 0;\n  top: 100%;\n  -webkit-transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);\n  transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);\n  -webkit-transition-duration: .5s;\n  transition-duration: .5s;\n  -webkit-transform: scale(1);\n          transform: scale(1); }\n.span-button {\n  border: 1px solid #0084f6;\n  padding: 4px 8px;\n  color: #0084f6;\n  font-size: .9em;\n  border-radius: 2px;\n  font-weight: 600;\n  cursor: pointer; }\n.span-button svg {\n    margin: -3px 0;\n    height: 14px; }\nlogin-nav > li {\n  display: inline-block;\n  padding: 0 7px;\n  cursor: pointer;\n  vertical-align: text-bottom; }\nlogin-nav > li .dropdown {\n    position: absolute;\n    right: 0;\n    top: 100%;\n    padding-top: 10px; }\nlogin-nav > li .icons {\n    width: 35px;\n    height: 35px;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    border-radius: 50%;\n    padding-top: 3px;\n    -webkit-transition: all 0.1s;\n    transition: all 0.1s;\n    border: 1px solid transparent; }\nlogin-nav > li .icons svg {\n      width: 25px;\n      color: #034979; }\nlogin-nav > li .icons svg .cls-1 {\n        stroke: #034979;\n        stroke-linejoin: unset;\n        border: none; }\nlogin-nav > li .user-info {\n    white-space: nowrap;\n    margin-right: 40px;\n    width: auto;\n    display: block;\n    position: relative; }\nlogin-nav > li .user-info > .icons {\n      display: inline-block;\n      vertical-align: middle; }\nlogin-nav > li .user-info > span {\n      vertical-align: middle;\n      display: inline-block; }\nlogin-nav > li .user-info:after {\n      display: inline-block;\n      font: normal normal normal 14px/1 FontAwesome;\n      font-size: inherit;\n      text-rendering: auto;\n      -webkit-font-smoothing: antialiased;\n      content: \"\\f107\";\n      font-size: 17px;\n      position: absolute;\n      right: -20px;\n      top: 10px; }\n/**\r\n  this css is for report section css for cards\r\n  added by laxmi\r\n*/\n.report-box {\n  width: 100%;\n  height: 100%;\n  padding: 10px; }\n.report-box ul.card-box li.card-row {\n    margin: 10px 0px; }\n.report-box ul.card {\n    padding: 15px 10px;\n    border: 1px solid #efefef;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 10px 0px;\n    -webkit-box-shadow: 0px 0px 2px 0px;\n            box-shadow: 0px 0px 2px 0px; }\n.report-box ul.card li {\n      padding: 5px; }\n.report-box ul.card li:first-child {\n        font-size: 14px;\n        font-weight: 600;\n        padding: 10px 5px; }\n.report-box ul.card li:nth-child(2n) {\n        font-size: 12px; }\n.disabled {\n  cursor: not-allowed;\n  background: lightgrey; }\n.middle-section {\n  padding: 1%; }\n.header-section .header-title {\n  text-align: left;\n  font-size: 14px;\n  font-weight: 600; }\n.course-menu-section-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  padding-top: 10px;\n  margin-top: 10px;\n  border-top: 1px solid rgba(10, 10, 10, 0.5);\n  width: 100%; }\n.course-menu-section-container .course-menu-item {\n    padding: 15px 10px;\n    width: 31%;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 1%;\n    -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24);\n    box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24); }\n.course-menu-section-container .course-menu-item .menu-title {\n      width: 100%;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start;\n      font-size: 14px;\n      font-weight: 600;\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row; }\n.course-menu-section-container .course-menu-item .menu-title img {\n        width: 25px;\n        height: 25px; }\n.course-menu-section-container .course-menu-item .menu-title span {\n        margin-left: 10px;\n        margin-top: 5px; }\n.course-menu-section-container .course-menu-item .menu-description {\n      padding: 10px;\n      font-size: 12px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/Archiving/archiving-home/archiving-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ArchivingHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var ArchivingHomeComponent = /** @class */ (function () {
    function ArchivingHomeComponent(auth) {
        this.auth = auth;
        this.type = '';
    }
    ArchivingHomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isProfessional = true;
                _this.type = 'batch';
            }
            else {
                _this.isProfessional = false;
                _this.type = 'course';
            }
        });
    };
    ArchivingHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-archiving-home',
            template: __webpack_require__("./src/app/components/course-module/Archiving/archiving-home/archiving-home.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/Archiving/archiving-home/archiving-home.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], ArchivingHomeComponent);
    return ArchivingHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/Archiving/archiving-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ArchivingRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__archiving_component__ = __webpack_require__("./src/app/components/course-module/Archiving/archiving.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__archiving_home_archiving_home_component__ = __webpack_require__("./src/app/components/course-module/Archiving/archiving-home/archiving-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__batches_batches_component__ = __webpack_require__("./src/app/components/course-module/Archiving/batches/batches.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__batches_archived_report_batches_archived_report_component__ = __webpack_require__("./src/app/components/course-module/Archiving/batches-archived-report/batches-archived-report.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__courses_courses_component__ = __webpack_require__("./src/app/components/course-module/Archiving/courses/courses.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__courses_archived_report_courses_archived_report_component__ = __webpack_require__("./src/app/components/course-module/Archiving/courses-archived-report/courses-archived-report.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








var ArchivingRoutingModule = /** @class */ (function () {
    function ArchivingRoutingModule() {
    }
    ArchivingRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_2__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_0__archiving_component__["a" /* ArchivingComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                component: __WEBPACK_IMPORTED_MODULE_3__archiving_home_archiving_home_component__["a" /* ArchivingHomeComponent */]
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_3__archiving_home_archiving_home_component__["a" /* ArchivingHomeComponent */]
                            },
                            {
                                path: 'batches',
                                component: __WEBPACK_IMPORTED_MODULE_4__batches_batches_component__["a" /* BatchesComponent */]
                            },
                            {
                                path: 'batchesArchivedReport',
                                component: __WEBPACK_IMPORTED_MODULE_5__batches_archived_report_batches_archived_report_component__["a" /* BatchesArchivedReportComponent */]
                            },
                            {
                                path: 'courses',
                                component: __WEBPACK_IMPORTED_MODULE_6__courses_courses_component__["a" /* CoursesComponent */]
                            },
                            {
                                path: 'coursesArchivedReport',
                                component: __WEBPACK_IMPORTED_MODULE_7__courses_archived_report_courses_archived_report_component__["a" /* CoursesArchivedReportComponent */]
                            }
                        ]
                    }
                ])
            ]
        })
    ], ArchivingRoutingModule);
    return ArchivingRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/Archiving/archiving.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>"

/***/ }),

/***/ "./src/app/components/course-module/Archiving/archiving.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/course-module/Archiving/archiving.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ArchivingComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ArchivingComponent = /** @class */ (function () {
    function ArchivingComponent() {
    }
    ArchivingComponent.prototype.ngOnInit = function () {
    };
    ArchivingComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-archiving',
            template: __webpack_require__("./src/app/components/course-module/Archiving/archiving.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/Archiving/archiving.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], ArchivingComponent);
    return ArchivingComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/Archiving/archiving.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ArchivingModule", function() { return ArchivingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap_custome__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__archiving_routing_module__ = __webpack_require__("./src/app/components/course-module/Archiving/archiving-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__archiving_component__ = __webpack_require__("./src/app/components/course-module/Archiving/archiving.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__batches_batches_component__ = __webpack_require__("./src/app/components/course-module/Archiving/batches/batches.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__archiving_home_archiving_home_component__ = __webpack_require__("./src/app/components/course-module/Archiving/archiving-home/archiving-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__batches_archived_report_batches_archived_report_component__ = __webpack_require__("./src/app/components/course-module/Archiving/batches-archived-report/batches-archived-report.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__services_archiving_service_courses_service_service__ = __webpack_require__("./src/app/services/archiving-service/courses-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__courses_courses_component__ = __webpack_require__("./src/app/components/course-module/Archiving/courses/courses.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__courses_archived_report_courses_archived_report_component__ = __webpack_require__("./src/app/components/course-module/Archiving/courses-archived-report/courses-archived-report.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};














var ArchivingModule = /** @class */ (function () {
    function ArchivingModule() {
    }
    ArchivingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_4__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_9__angular_router__["RouterModule"],
                __WEBPACK_IMPORTED_MODULE_0__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_0__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap_custome__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_3__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_5__archiving_routing_module__["a" /* ArchivingRoutingModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_6__archiving_component__["a" /* ArchivingComponent */],
                __WEBPACK_IMPORTED_MODULE_7__batches_batches_component__["a" /* BatchesComponent */],
                __WEBPACK_IMPORTED_MODULE_8__archiving_home_archiving_home_component__["a" /* ArchivingHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_10__batches_archived_report_batches_archived_report_component__["a" /* BatchesArchivedReportComponent */],
                __WEBPACK_IMPORTED_MODULE_12__courses_courses_component__["a" /* CoursesComponent */],
                __WEBPACK_IMPORTED_MODULE_13__courses_archived_report_courses_archived_report_component__["a" /* CoursesArchivedReportComponent */],
            ],
            entryComponents: [
                __WEBPACK_IMPORTED_MODULE_6__archiving_component__["a" /* ArchivingComponent */],
                __WEBPACK_IMPORTED_MODULE_7__batches_batches_component__["a" /* BatchesComponent */],
                __WEBPACK_IMPORTED_MODULE_8__archiving_home_archiving_home_component__["a" /* ArchivingHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_10__batches_archived_report_batches_archived_report_component__["a" /* BatchesArchivedReportComponent */],
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_11__services_archiving_service_courses_service_service__["a" /* CoursesServiceService */]
            ]
        })
    ], ArchivingModule);
    return ArchivingModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/Archiving/batches-archived-report/batches-archived-report.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n<div class=\"report-wrapper clearFix\">\r\n  <aside class=\"middle-full\">\r\n    <section class=\"middle-main clearFix\">\r\n\r\n      <div class=\"middle-top mb0 clearFix header\">\r\n        <div class=\"report-header\" style=\"padding-bottom:1% ; height:7vh;\">\r\n          <h2 style=\"padding: 5px;\" class=\"pull-left\">\r\n            <a routerLink=\"/view/batch\">\r\n              Batch\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n            <a routerLink=\"/view/batch/archiving\">\r\n              Archiving\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" *ngIf=\"!isProfessional\"></i>\r\n            <span *ngIf=\"!isProfessional\">Courses Archived Report</span>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" *ngIf=\"isProfessional\"></i>\r\n            <span *ngIf=\"isProfessional\">Batches Archived Report</span>\r\n          </h2>\r\n        </div>\r\n      </div>\r\n    </section>\r\n\r\n    <section>\r\n      <div class=\"filter-box clearFix\" style=\"margin: 6px 0px 6px 6px;float: right;\">\r\n        <div id=\"basic-search\" class=\"search-filter-wrapper\">\r\n          <input #search type=\"text\" class=\"search-field\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\" (keyup)=\"searchDatabase()\"\r\n            style=\"padding: 10px;\">\r\n        </div>\r\n      </div>\r\n      <div class=\"table table-responsive\" style=\"margin-top:5vh;\">\r\n        <table>\r\n          <thead>\r\n            <tr>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('course_name') \">\r\n                Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('course_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('course_name') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('batch_name') \">\r\n                Batch &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('batch_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('batch_name') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: left;\" (click)=\"sortedData('standard_name') \" *ngIf=\"isProfessional\">\r\n                Master Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('standard_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('standard_name') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: left;\" (click)=\"sortedData('master_course') \" *ngIf=\"!isProfessional\">\r\n                Master Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('master_course') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('master_course') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('standard_name') \">\r\n                Standard  &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('standard_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('standard_name') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('subject_name') \">\r\n                Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('subject_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('subject_name') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('subjects') \">\r\n                Subjects &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('subjects') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('subjects') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: right;\"  (click)=\"sortedData('start_date') \">\r\n                Start Date &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('start_date') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('start_date') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: right;\" (click)=\"sortedData('end_date') \">\r\n                End Date &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('end_date') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('end_date') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: left;\">\r\n                Status\r\n              </th>\r\n              <th style=\"text-align: right;\" (click)=\"sortedData('archived_date') \">\r\n                Archived Date Time &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('archived_date') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('archived_date') && direction != 1\"></i>\r\n              </th>\r\n            </tr>\r\n          </thead>\r\n          <tbody>\r\n            <tr *ngFor=\"let i of newPaginated\">\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.course_name}}\r\n              </td>\r\n              <td *ngIf=\"isProfessional\" style=\"text-align: left;\">\r\n                {{i.batch_name}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.master_course}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.standard_name}}\r\n              </td>\r\n              <td *ngIf=\"isProfessional\" style=\"text-align: left;\">\r\n                {{i.standard_name}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.subjects}}\r\n              </td>\r\n              <td *ngIf=\"isProfessional\" style=\"text-align: left;\">\r\n                {{i.subject_name}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: right;\">\r\n                {{i.start_date}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: right;\">\r\n                {{i.end_date}}\r\n              </td>\r\n              <td style=\"text-align: left;\">\r\n                {{i.status}}\r\n              </td>\r\n              <td style=\"text-align: right;\">\r\n                {{i.archived_date}}\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n          <tbody *ngIf=\"newPaginated.length == 0 && dataStatus === true && isProfessional\">\r\n            <tr *ngFor=\"let dummy of dummyArr\">\r\n              <td *ngFor=\"let c of columnMaps\" style=\"padding:10px;\">\r\n                <div class=\"skeleton\">\r\n                </div>\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n          <tbody *ngIf=\"newPaginated.length == 0 && dataStatus === true && !isProfessional\">\r\n            <tr *ngFor=\"let dummy of dummyArr\">\r\n              <td *ngFor=\"let c of columnMaps2\" style=\"padding:10px;\">\r\n                <div class=\"skeleton\">\r\n                </div>\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n          <tbody *ngIf=\"newPaginated.length == 0 && dataStatus === false\" class=\"records\">\r\n            <tr>\r\n              <td colspan=\"6\" class=\"records\">\r\n                No Records Found\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n        </table>\r\n      </div>\r\n      <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n        <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n          <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n            [page]=\"PageIndex\" [perPage]=\"pagedisplaysize\" [count]=\"totalRow\">\r\n          </pagination>\r\n        </div>\r\n      </div>\r\n    </section>\r\n  </aside>\r\n</div>"

/***/ }),

/***/ "./src/app/components/course-module/Archiving/batches-archived-report/batches-archived-report.component.scss":
/***/ (function(module, exports) {

module.exports = ".skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 80%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n  .skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n"

/***/ }),

/***/ "./src/app/components/course-module/Archiving/batches-archived-report/batches-archived-report.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BatchesArchivedReportComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_archiving_service_courses_service_service__ = __webpack_require__("./src/app/services/archiving-service/courses-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__app_component__ = __webpack_require__("./src/app/app.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var BatchesArchivedReportComponent = /** @class */ (function () {
    function BatchesArchivedReportComponent(course, auth, appc) {
        this.course = course;
        this.auth = auth;
        this.appc = appc;
        this.archivedData = [];
        this.PageIndex = 1;
        this.PageIndexPopup = 1;
        this.pagedisplaysize = 10;
        this.pagedisplaysizePopup = 10;
        this.totalRow = 0;
        this.newPaginated = [];
        this.searchText = "";
        this.searchData = [];
        this.searchflag = false;
        this.dummyArr = [0, 1, 2, 0, 1, 2];
        this.columnMaps = [0, 1, 2, 3, 4, 5];
        this.columnMaps2 = [0, 1, 2, 3, 4, 5, 6, 7];
        this.sortedenabled = true;
        this.sortedBy = "";
        this.direction = 0;
    }
    BatchesArchivedReportComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.getCoursesArchived();
    };
    BatchesArchivedReportComponent.prototype.getCoursesArchived = function () {
        var _this = this;
        this.dataStatus = true;
        this.isRippleLoad = true;
        if (this.isProfessional) {
            this.course.batchArchiveStatus().subscribe(function (data) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                _this.archivedData = data;
                _this.totalRow = data.length;
                _this.PageIndex = 1;
                _this.fetchTableDataByPage(_this.PageIndex);
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
        else {
            this.isRippleLoad = true;
            this.course.courseArchiveStatus().subscribe(function (data) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                _this.archivedData = data;
                _this.totalRow = data.length;
                _this.PageIndex = 1;
                _this.fetchTableDataByPage(_this.PageIndex);
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
    };
    BatchesArchivedReportComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            this.PageIndex = 1;
            var searchRes = void 0;
            searchRes = this.archivedData.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.searchData = searchRes;
            this.totalRow = searchRes.length;
            this.searchflag = true;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchflag = false;
            this.fetchTableDataByPage(this.PageIndex);
            this.totalRow = this.archivedData.length;
        }
    };
    BatchesArchivedReportComponent.prototype.sortedData = function (ev) {
        var _this = this;
        this.sortedenabled = true;
        if (this.sortedenabled) {
            (this.direction == 0 || this.direction == -1) ? (this.direction = 1) : (this.direction = -1);
            this.sortedBy = ev;
            this.archivedData = this.archivedData.sort(function (a, b) {
                if (a[ev] < b[ev]) {
                    return -1 * _this.direction;
                }
                else if (a[ev] > b[ev]) {
                    return _this.direction;
                }
                else {
                    return 0;
                }
            });
            this.PageIndex = 1;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    BatchesArchivedReportComponent.prototype.getCaretVisiblity = function (e) {
        if (this.sortedenabled && this.sortedBy == e) {
            return true;
        }
        else {
            return false;
        }
    };
    BatchesArchivedReportComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.pagedisplaysize * (index - 1);
        this.newPaginated = this.getDataFromDataSource(startindex);
    };
    BatchesArchivedReportComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    BatchesArchivedReportComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    BatchesArchivedReportComponent.prototype.getDataFromDataSource = function (startindex) {
        if (this.searchflag) {
            var t = this.searchData.slice(startindex, startindex + this.pagedisplaysize);
            return t;
        }
        else {
            var t = this.archivedData.slice(startindex, startindex + this.pagedisplaysize);
            return t;
        }
    };
    BatchesArchivedReportComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-batches-archived-report',
            template: __webpack_require__("./src/app/components/course-module/Archiving/batches-archived-report/batches-archived-report.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/Archiving/batches-archived-report/batches-archived-report.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_archiving_service_courses_service_service__["a" /* CoursesServiceService */],
            __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_3__app_component__["a" /* AppComponent */]])
    ], BatchesArchivedReportComponent);
    return BatchesArchivedReportComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/Archiving/batches/batches.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n<div class=\"report-wrapper clearFix\">\r\n  <aside class=\"middle-full\">\r\n    <section class=\"middle-main clearFix\">\r\n\r\n      <div class=\"middle-top mb0 clearFix header\">\r\n        <div class=\"report-header\" style=\"padding-bottom:1%\">\r\n          <h2 style=\"padding: 5px;\" class=\"pull-left\">\r\n            <a routerLink=\"/view/batch\">\r\n              Batch\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n            <a routerLink=\"/view/batch/archiving\">\r\n              Archiving\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" *ngIf=\"!isProfessional\"></i>\r\n            <span *ngIf=\"!isProfessional\">Courses</span>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" *ngIf=\"isProfessional\"></i>\r\n            <span *ngIf=\"isProfessional\">Batches</span>\r\n          </h2>\r\n          <div class=\"row\">\r\n            <div class=\"c-lg-12\">\r\n              <h2 *ngIf=\"!isProfessional\">\r\n                Courses List\r\n              </h2>\r\n              <h2 *ngIf=\"isProfessional\">\r\n                Batches List\r\n              </h2>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </section>\r\n    <div class=\"filter-box clearFix\" style=\"margin: 6px 0px 6px 6px;float: right;\">\r\n      <div id=\"basic-search\" class=\"search-filter-wrapper\">\r\n        <input #search type=\"text\" class=\"search-field\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\" (keyup)=\"searchDatabase()\"\r\n          style=\"padding: 10px;\">\r\n      </div>\r\n    </div>\r\n    <section>\r\n\r\n      <div class=\"table table-responsive table-made\">\r\n        <table>\r\n          <thead>\r\n            <tr>\r\n              <th style=\"text-align: left;\" *ngIf=\"!isProfessional\" (click)=\"sortedData('course_name') \">\r\n               # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('course_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('course_name') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: left;\" *ngIf=\"isProfessional\" (click)=\"sortedData('batch_name') \">\r\n               # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Batch &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('batch_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('batch_name') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: left;\" (click)=\"sortedData('standard_name') \" *ngIf=\"isProfessional\">\r\n                Master Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('standard_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('standard_name') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: left;\" (click)=\"sortedData('master_course') \" *ngIf=\"!isProfessional\">\r\n                Master Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('master_course') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('master_course') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('standard_name') \">\r\n                Standard &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('standard_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('standard_name') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('subject_name') \">\r\n                Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('subject_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('subject_name') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('subjects') \">\r\n                Subjects &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('subjects') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('subjects') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: right;\" (click)=\"sortedData('start_date') \">\r\n                Start Date &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('start_date') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('start_date') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: right;\" (click)=\"sortedData('end_date') \">\r\n                End Date &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('end_date') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('end_date') && direction != 1\"></i>\r\n              </th>\r\n            </tr>\r\n          </thead>\r\n          <tbody *ngIf=\"newPaginated?.length!=0\">\r\n            <tr *ngFor=\"let i of newPaginated ; let j=index;\">\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;  padding:5px 0px 10px 5px; \">\r\n                <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;margin-top: 5px; height:16px; margin-right: 10px;\">\r\n                  <input type=\"checkbox\" class=\"form-checkbox\" name={{i.course_id}} id={{i.course_id}} [(ngModel)]=\"i.status\" (ngModelChange)=\"notifyMe(j)\" style=\"height:15px; margin-right: 10px;\">\r\n                  <label for={{i.course_id}}></label>\r\n                </div>\r\n                {{i.course_name}}\r\n              </td>\r\n              <td *ngIf=\"isProfessional\" style=\"text-align: left; padding:5px 0px 10px 5px; \">\r\n                <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;margin-top: 5px; height:16px; margin-right: 10px;\">\r\n                  <input type=\"checkbox\" class=\"form-checkbox\" name={{i.batch_id}} id={{i.batch_id}} [(ngModel)]=\"i.status\" (ngModelChange)=\"notifyMe(j)\" >\r\n                  <label for={{i.batch_id}}></label>\r\n                </div>\r\n                {{i.batch_name}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.master_course}}\r\n              </td>\r\n              <td *ngIf=\"isProfessional\" style=\"text-align: left;\">\r\n                {{i.standard_name}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.standard_name}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.subjects}}\r\n              </td>\r\n              <td *ngIf=\"isProfessional\" style=\"text-align: left;\">\r\n                {{i.subject_name}}\r\n              </td>\r\n              <td style=\"text-align: right;\">\r\n                {{i.start_date}}\r\n              </td>\r\n              <td style=\"text-align: right;\">\r\n                {{i.end_date}}\r\n              </td>\r\n            </tr>\r\n            <tr *ngIf=\"isProfessional\">\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n                <input type=\"button\" class=\"btn fullBlue\" value=\"Archive\" (click)=\"archiveData($event)\" style=\"float: right;\">\r\n              </td>\r\n\r\n            </tr>\r\n            <tr *ngIf=\"!isProfessional\">\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n                <input type=\"button\" class=\"btn fullBlue\" value=\"Archive\" (click)=\"archiveData($event)\" style=\"float: right;\">\r\n              </td>\r\n\r\n            </tr>\r\n          </tbody>\r\n          <tbody *ngIf=\"newPaginated.length == 0 && dataStatus === true\">\r\n            <tr *ngFor=\"let dummy of dummyArr\">\r\n              <td *ngFor=\"let c of columnMaps\" style=\"padding:10px;\">\r\n                <div class=\"skeleton\">\r\n                </div>\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n          <tbody *ngIf=\"newPaginated.length == 0 && dataStatus === false\" class=\"records\">\r\n            <tr>\r\n              <td colspan=\"6\" class=\"records\">\r\n                No Records Found\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n        </table>\r\n      </div>\r\n      <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n        <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n          <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n            [page]=\"PageIndex\" [perPage]=\"pagedisplaysize\" [count]=\"totalRow\">\r\n          </pagination>\r\n        </div>\r\n      </div>\r\n    </section>\r\n  </aside>\r\n</div>"

/***/ }),

/***/ "./src/app/components/course-module/Archiving/batches/batches.component.scss":
/***/ (function(module, exports) {

module.exports = ".skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 80%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n  .skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n"

/***/ }),

/***/ "./src/app/components/course-module/Archiving/batches/batches.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BatchesComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_archiving_service_courses_service_service__ = __webpack_require__("./src/app/services/archiving-service/courses-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var BatchesComponent = /** @class */ (function () {
    function BatchesComponent(auth, batch, appc, router) {
        this.auth = auth;
        this.batch = batch;
        this.appc = appc;
        this.router = router;
        this.isProfessional = false;
        this.isRippleLoad = false;
        this.getCourses = [];
        this.PageIndex = 1;
        this.PageIndexPopup = 1;
        this.pagedisplaysize = 10;
        this.pagedisplaysizePopup = 10;
        this.totalRow = 0;
        this.newPaginated = [];
        this.searchText = "";
        this.searchData = [];
        this.searchflag = false;
        this.sendPayload = {
            courseIds: "",
            archived: false
        };
        this.sendPayloadBatch = {
            batchIds: "",
            archived: false
        };
        this.courseIds = [];
        this.getArr = [];
        this.getId = [];
        this.dummyArr = [0, 1, 2, 0, 1, 2];
        this.columnMaps = [0, 1, 2, 3, 4, 5];
        this.columnMaps2 = [0, 1, 2, 3, 4, 5, 6, 7];
        this.sortedenabled = true;
        this.sortedBy = "";
        this.direction = 0;
    }
    BatchesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.getCoursesList();
    };
    BatchesComponent.prototype.getCoursesList = function () {
        var _this = this;
        this.dataStatus = true;
        if (this.isProfessional) {
            this.batch.getBatches().subscribe(function (data) {
                _this.dataStatus = false;
                _this.getCourses = data;
                _this.getCourses.map(function (ele) {
                    ele.status = false;
                });
                _this.totalRow = data.length;
                _this.PageIndex = 1;
                _this.fetchTableDataByPage(_this.PageIndex);
            }, function (error) {
                _this.dataStatus = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
        else {
            this.dataStatus = true;
            this.batch.getCoursesList().subscribe(function (data) {
                _this.dataStatus = false;
                _this.getCourses = data;
                _this.getCourses.map(function (ele) {
                    ele.status = false;
                });
                _this.totalRow = data.length;
                _this.PageIndex = 1;
                _this.fetchTableDataByPage(_this.PageIndex);
            }, function (error) {
                _this.dataStatus = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
    };
    BatchesComponent.prototype.notifyMe = function (e) {
        var _this = this;
        var str = "";
        if (!this.isProfessional) {
            if (this.newPaginated[e].status == true) {
                this.getArr.push(this.newPaginated[e].course_id);
            }
            else {
                this.getArr = this.getArr.filter(function (ele) {
                    if (ele == _this.newPaginated[e].course_id) {
                        return false;
                    }
                    else {
                        return true;
                    }
                });
            }
            str = this.getArr.join(',');
            this.sendPayload.courseIds = str;
        }
        else {
            if (this.newPaginated[e].status) {
                this.getArr.push(this.newPaginated[e].batch_id);
            }
            else {
                this.getArr = this.getArr.filter(function (ele) {
                    if (ele == _this.newPaginated[e].batch_id) {
                        return false;
                    }
                    else {
                        return true;
                    }
                });
            }
            str = this.getArr.join(',');
            this.sendPayloadBatch.batchIds = str;
        }
    };
    BatchesComponent.prototype.archiveData = function (event) {
        var _this = this;
        if (!this.isProfessional) {
            if (this.sendPayload.courseIds == "" || this.sendPayload.courseIds == null) {
                var msg = {
                    type: "error",
                    body: "At least one course should be selected"
                };
                this.appc.popToast(msg);
            }
            else {
                if (confirm('Are you sure, you want to Archive?')) {
                    this.batch.courses(this.sendPayload).subscribe(function (data) {
                        _this.router.navigateByUrl("/view/activity/archiving/batchesArchivedReport");
                        var msg = {
                            type: "success",
                            body: "Course(s) archived successfully"
                        };
                        _this.appc.popToast(msg);
                    }, function (error) {
                        var msg = {
                            type: "error",
                            body: error.error.message
                        };
                        _this.appc.popToast(msg);
                    });
                }
            }
        }
        else {
            if (this.sendPayloadBatch.batchIds == "" || this.sendPayloadBatch.batchIds == null) {
                var msg = {
                    type: "error",
                    body: "At least one Batch should be selected"
                };
                this.appc.popToast(msg);
            }
            else {
                if (confirm('Are you sure, you want to Archive?')) {
                    this.batch.batches(this.sendPayloadBatch).subscribe(function (data) {
                        if (data.status_code == 202) {
                            if (confirm(data.message)) {
                                _this.sendPayloadBatch.archived = true;
                                _this.batch.batches(_this.sendPayloadBatch).subscribe(function (data) {
                                    _this.router.navigateByUrl("/view/activity/archiving/batchesArchivedReport");
                                    var msg = {
                                        type: "success",
                                        body: "Batch(s) archived successfully"
                                    };
                                    _this.appc.popToast(msg);
                                }, function (error) {
                                    var msg = {
                                        type: "error",
                                        body: error.error.message
                                    };
                                    _this.appc.popToast(msg);
                                });
                            }
                        }
                        else {
                            _this.router.navigateByUrl("/view/activity/archiving/batchesArchivedReport");
                            var msg = {
                                type: "success",
                                body: "Batch(s) archived successfully"
                            };
                            _this.appc.popToast(msg);
                        }
                    }, function (error) {
                        if (error.error.message.includes("Batch Already assigned with active Student")) {
                            if (confirm(error.error.message)) {
                                _this.sendPayloadBatch.archived = true;
                                _this.batch.batches(_this.sendPayloadBatch).subscribe(function (data) {
                                    _this.router.navigateByUrl("/view/activity/archiving/batchesArchivedReport");
                                    var msg = {
                                        type: "success",
                                        body: "Batch(s) archived successfully"
                                    };
                                    _this.appc.popToast(msg);
                                }, function (error) {
                                    var msg = {
                                        type: "error",
                                        body: error.error.message
                                    };
                                    _this.appc.popToast(msg);
                                });
                            }
                        }
                        else {
                            var msg = {
                                type: "error",
                                body: error.error.message
                            };
                            _this.appc.popToast(msg);
                        }
                    });
                }
            }
        }
    };
    BatchesComponent.prototype.sortedData = function (ev) {
        var _this = this;
        this.sortedenabled = true;
        if (this.sortedenabled) {
            (this.direction == 0 || this.direction == -1) ? (this.direction = 1) : (this.direction = -1);
            this.sortedBy = ev;
            this.getCourses = this.getCourses.sort(function (a, b) {
                if (a[ev] < b[ev]) {
                    return -1 * _this.direction;
                }
                else if (a[ev] > b[ev]) {
                    return _this.direction;
                }
                else {
                    return 0;
                }
            });
            this.PageIndex = 1;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    BatchesComponent.prototype.getCaretVisiblity = function (e) {
        if (this.sortedenabled && this.sortedBy == e) {
            return true;
        }
        else {
            return false;
        }
    };
    BatchesComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.pagedisplaysize * (index - 1);
        this.newPaginated = this.getDataFromDataSource(startindex);
    };
    BatchesComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    BatchesComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    BatchesComponent.prototype.getDataFromDataSource = function (startindex) {
        if (this.searchflag) {
            var t = this.searchData.slice(startindex, startindex + this.pagedisplaysize);
            return t;
        }
        else {
            var t = this.getCourses.slice(startindex, startindex + this.pagedisplaysize);
            return t;
        }
    };
    BatchesComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            this.PageIndex = 1;
            var searchRes = void 0;
            searchRes = this.getCourses.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.searchData = searchRes;
            this.totalRow = searchRes.length;
            this.searchflag = true;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchflag = false;
            this.fetchTableDataByPage(this.PageIndex);
            this.totalRow = this.getCourses.length;
        }
    };
    BatchesComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-batches',
            template: __webpack_require__("./src/app/components/course-module/Archiving/batches/batches.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/Archiving/batches/batches.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_2__services_archiving_service_courses_service_service__["a" /* CoursesServiceService */],
            __WEBPACK_IMPORTED_MODULE_3__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_4__angular_router__["Router"]])
    ], BatchesComponent);
    return BatchesComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/Archiving/courses-archived-report/courses-archived-report.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n<div class=\"report-wrapper clearFix\">\r\n  <aside class=\"middle-full\">\r\n    <section class=\"middle-main clearFix\">\r\n\r\n      <div class=\"middle-top mb0 clearFix header\">\r\n        <div class=\"report-header\" style=\"padding-bottom:1% ; height:7vh;\">\r\n          <h2 style=\"padding: 5px;\" class=\"pull-left\">\r\n            <a routerLink=\"/view/course\">\r\n              Course\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n            <a routerLink=\"/view/course/archiving\">\r\n              Archiving\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" *ngIf=\"!isProfessional\"></i>\r\n            <span *ngIf=\"!isProfessional\">Courses Archived Report</span>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" *ngIf=\"isProfessional\"></i>\r\n            <span *ngIf=\"isProfessional\">Batches Archived Report</span>\r\n          </h2>\r\n        </div>\r\n      </div>\r\n    </section>\r\n\r\n    <section>\r\n      <div class=\"filter-box clearFix\" style=\"margin: 6px 0px 6px 6px;float: right;\">\r\n        <div id=\"basic-search\" class=\"search-filter-wrapper\">\r\n          <input #search type=\"text\" class=\"search-field\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\" (keyup)=\"searchDatabase()\"\r\n            style=\"padding: 10px;\">\r\n        </div>\r\n      </div>\r\n      <div class=\"table table-responsive\" style=\"margin-top:5vh;\">\r\n        <table>\r\n          <thead>\r\n            <tr>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('course_name') \">\r\n                Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('course_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('course_name') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('batch_name') \">\r\n                Batch &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('batch_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('batch_name') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: left;\" (click)=\"sortedData('standard_name') \" *ngIf=\"isProfessional\">\r\n                Master Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('standard_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('standard_name') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: left;\" (click)=\"sortedData('master_course') \" *ngIf=\"!isProfessional\">\r\n                Master Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('master_course') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('master_course') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('standard_name') \">\r\n                Standard  &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('standard_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('standard_name') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('subject_name') \">\r\n                Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('subject_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('subject_name') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('subjects') \">\r\n                Subjects &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('subjects') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('subjects') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: right;\"  (click)=\"sortedData('start_date') \">\r\n                Start Date &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('start_date') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('start_date') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: right;\" (click)=\"sortedData('end_date') \">\r\n                End Date &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('end_date') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('end_date') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: left;\">\r\n                Status\r\n              </th>\r\n              <th style=\"text-align: right;\" (click)=\"sortedData('archived_date') \">\r\n                Archived Date Time &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('archived_date') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('archived_date') && direction != 1\"></i>\r\n              </th>\r\n            </tr>\r\n          </thead>\r\n          <tbody>\r\n            <tr *ngFor=\"let i of newPaginated\">\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.course_name}}\r\n              </td>\r\n              <td *ngIf=\"isProfessional\" style=\"text-align: left;\">\r\n                {{i.batch_name}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.master_course}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.standard_name}}\r\n              </td>\r\n              <td *ngIf=\"isProfessional\" style=\"text-align: left;\">\r\n                {{i.standard_name}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.subjects}}\r\n              </td>\r\n              <td *ngIf=\"isProfessional\" style=\"text-align: left;\">\r\n                {{i.subject_name}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: right;\">\r\n                {{i.start_date}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: right;\">\r\n                {{i.end_date}}\r\n              </td>\r\n              <td style=\"text-align: left;\">\r\n                {{i.status}}\r\n              </td>\r\n              <td style=\"text-align: right;\">\r\n                {{i.archived_date}}\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n          <tbody *ngIf=\"newPaginated.length == 0 && dataStatus === true && isProfessional\">\r\n            <tr *ngFor=\"let dummy of dummyArr\">\r\n              <td *ngFor=\"let c of columnMaps\" style=\"padding:10px;\">\r\n                <div class=\"skeleton\">\r\n                </div>\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n          <tbody *ngIf=\"newPaginated.length == 0 && dataStatus === true && !isProfessional\">\r\n            <tr *ngFor=\"let dummy of dummyArr\">\r\n              <td *ngFor=\"let c of columnMaps2\" style=\"padding:10px;\">\r\n                <div class=\"skeleton\">\r\n                </div>\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n          <tbody *ngIf=\"newPaginated.length == 0 && dataStatus === false\" class=\"records\">\r\n            <tr>\r\n              <td colspan=\"8\" *ngIf=\"!isProfessional\" class=\"records\">\r\n                No Records Found\r\n              </td>\r\n              <td colspan=\"6\" *ngIf=\"isProfessional\" class=\"records\">\r\n                No Records Found\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n        </table>\r\n      </div>\r\n      <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n        <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n          <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n            [page]=\"PageIndex\" [perPage]=\"pagedisplaysize\" [count]=\"totalRow\">\r\n          </pagination>\r\n        </div>\r\n      </div>\r\n    </section>\r\n  </aside>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/Archiving/courses-archived-report/courses-archived-report.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/course-module/Archiving/courses-archived-report/courses-archived-report.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CoursesArchivedReportComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_archiving_service_courses_service_service__ = __webpack_require__("./src/app/services/archiving-service/courses-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__app_component__ = __webpack_require__("./src/app/app.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var CoursesArchivedReportComponent = /** @class */ (function () {
    function CoursesArchivedReportComponent(course, auth, appc) {
        this.course = course;
        this.auth = auth;
        this.appc = appc;
        this.archivedData = [];
        this.PageIndex = 1;
        this.PageIndexPopup = 1;
        this.pagedisplaysize = 10;
        this.pagedisplaysizePopup = 10;
        this.totalRow = 0;
        this.newPaginated = [];
        this.searchText = "";
        this.searchData = [];
        this.searchflag = false;
        this.dummyArr = [0, 1, 2, 0, 1, 2];
        this.columnMaps = [0, 1, 2, 3, 4, 5];
        this.columnMaps2 = [0, 1, 2, 3, 4, 5, 6, 7];
        this.sortedenabled = true;
        this.sortedBy = "";
        this.direction = 0;
    }
    CoursesArchivedReportComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.getCoursesArchived();
    };
    CoursesArchivedReportComponent.prototype.getCoursesArchived = function () {
        var _this = this;
        this.dataStatus = true;
        this.isRippleLoad = true;
        if (this.isProfessional) {
            this.course.batchArchiveStatus().subscribe(function (data) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                _this.archivedData = data;
                _this.totalRow = data.length;
                _this.PageIndex = 1;
                _this.fetchTableDataByPage(_this.PageIndex);
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
        else {
            this.isRippleLoad = true;
            this.course.courseArchiveStatus().subscribe(function (data) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                _this.archivedData = data;
                _this.totalRow = data.length;
                _this.PageIndex = 1;
                _this.fetchTableDataByPage(_this.PageIndex);
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
    };
    CoursesArchivedReportComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            this.PageIndex = 1;
            var searchRes = void 0;
            searchRes = this.archivedData.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.searchData = searchRes;
            this.totalRow = searchRes.length;
            this.searchflag = true;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchflag = false;
            this.fetchTableDataByPage(this.PageIndex);
            this.totalRow = this.archivedData.length;
        }
    };
    CoursesArchivedReportComponent.prototype.sortedData = function (ev) {
        var _this = this;
        this.sortedenabled = true;
        if (this.sortedenabled) {
            (this.direction == 0 || this.direction == -1) ? (this.direction = 1) : (this.direction = -1);
            this.sortedBy = ev;
            this.archivedData = this.archivedData.sort(function (a, b) {
                if (a[ev] < b[ev]) {
                    return -1 * _this.direction;
                }
                else if (a[ev] > b[ev]) {
                    return _this.direction;
                }
                else {
                    return 0;
                }
            });
            this.PageIndex = 1;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    CoursesArchivedReportComponent.prototype.getCaretVisiblity = function (e) {
        if (this.sortedenabled && this.sortedBy == e) {
            return true;
        }
        else {
            return false;
        }
    };
    CoursesArchivedReportComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.pagedisplaysize * (index - 1);
        this.newPaginated = this.getDataFromDataSource(startindex);
    };
    CoursesArchivedReportComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    CoursesArchivedReportComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    CoursesArchivedReportComponent.prototype.getDataFromDataSource = function (startindex) {
        if (this.searchflag) {
            var t = this.searchData.slice(startindex, startindex + this.pagedisplaysize);
            return t;
        }
        else {
            var t = this.archivedData.slice(startindex, startindex + this.pagedisplaysize);
            return t;
        }
    };
    CoursesArchivedReportComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-courses-archived-report',
            template: __webpack_require__("./src/app/components/course-module/Archiving/courses-archived-report/courses-archived-report.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/Archiving/courses-archived-report/courses-archived-report.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_archiving_service_courses_service_service__["a" /* CoursesServiceService */],
            __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_3__app_component__["a" /* AppComponent */]])
    ], CoursesArchivedReportComponent);
    return CoursesArchivedReportComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/Archiving/courses/courses.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n\r\n<div class=\"report-wrapper clearFix\">\r\n  <aside class=\"middle-full\">\r\n    <section class=\"middle-main clearFix\">\r\n\r\n      <div class=\"middle-top mb0 clearFix header\">\r\n        <div class=\"report-header\" style=\"padding-bottom:2%\">\r\n          <h2 style=\"padding: 5px;\" class=\"pull-left\">\r\n            <a routerLink=\"/view/course\">\r\n              Course\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n            <a routerLink=\"/view/course/archiving\">\r\n              Archiving\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" *ngIf=\"!isProfessional\"></i>\r\n            <span *ngIf=\"!isProfessional\">Courses</span>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" *ngIf=\"isProfessional\"></i>\r\n            <span *ngIf=\"isProfessional\">Batches</span>\r\n          </h2>\r\n        </div>\r\n      </div>\r\n    </section>\r\n    <div class=\"filter-box clearFix\" style=\"margin: 6px 0px 6px 6px;float: right;\">\r\n      <div id=\"basic-search\" class=\"search-filter-wrapper\">\r\n        <input #search type=\"text\" class=\"search-field\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\" (keyup)=\"searchDatabase()\"\r\n          style=\"padding: 10px;\">\r\n      </div>\r\n    </div>\r\n    <section>\r\n\r\n      <div class=\"table table-responsive table-made\">\r\n        <table>\r\n          <thead>\r\n            <tr>\r\n              <th style=\"text-align: left;\" *ngIf=\"!isProfessional\" (click)=\"sortedData('course_name') \">\r\n               # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('course_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('course_name') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: left;\" *ngIf=\"isProfessional\" (click)=\"sortedData('batch_name') \">\r\n               # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Batch &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('batch_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('batch_name') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: left;\" (click)=\"sortedData('standard_name') \" *ngIf=\"isProfessional\">\r\n                Master Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('standard_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('standard_name') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: left;\" (click)=\"sortedData('master_course') \" *ngIf=\"!isProfessional\">\r\n                Master Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('master_course') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('master_course') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('standard_name') \">\r\n                Standard &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('standard_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('standard_name') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('subject_name') \">\r\n                Course &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('subject_name') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('subject_name') && direction != 1\"></i>\r\n              </th>\r\n              <th *ngIf=\"!isProfessional\" style=\"text-align: left;\" (click)=\"sortedData('subjects') \">\r\n                Subjects &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('subjects') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('subjects') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: right;\" (click)=\"sortedData('start_date') \">\r\n                Start Date &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('start_date') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('start_date') && direction != 1\"></i>\r\n              </th>\r\n              <th style=\"text-align: right;\" (click)=\"sortedData('end_date') \">\r\n                End Date &nbsp;\r\n                <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('end_date') && direction == 1\"></i>\r\n                <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('end_date') && direction != 1\"></i>\r\n              </th>\r\n            </tr>\r\n          </thead>\r\n          <tbody *ngIf=\"newPaginated.length!=0\">\r\n            <tr *ngFor=\"let i of newPaginated ; let j=index;\">\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;  padding:5px 0px 10px 5px; \">\r\n                <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;margin-top: 5px; height:16px; margin-right: 10px;\">\r\n                  <input type=\"checkbox\" class=\"form-checkbox\" name={{i.course_id}} id={{i.course_id}} [(ngModel)]=\"i.status\" (ngModelChange)=\"notifyMe(j)\" style=\"height:15px; margin-right: 10px;\">\r\n                  <label for={{i.course_id}}></label>\r\n                </div>\r\n                {{i.course_name}}\r\n              </td>\r\n              <td *ngIf=\"isProfessional\" style=\"text-align: left; padding:5px 0px 10px 5px; \">\r\n                <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;margin-top: 5px; height:16px; margin-right: 10px;\">\r\n                  <input type=\"checkbox\" class=\"form-checkbox\" name={{i.batch_id}} id={{i.batch_id}} [(ngModel)]=\"i.status\" (ngModelChange)=\"notifyMe(j)\" >\r\n                  <label for={{i.batch_id}}></label>\r\n                </div>\r\n                {{i.batch_name}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.master_course}}\r\n              </td>\r\n              <td *ngIf=\"isProfessional\" style=\"text-align: left;\">\r\n                {{i.standard_name}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.standard_name}}\r\n              </td>\r\n              <td *ngIf=\"!isProfessional\" style=\"text-align: left;\">\r\n                {{i.subjects}}\r\n              </td>\r\n              <td *ngIf=\"isProfessional\" style=\"text-align: left;\">\r\n                {{i.subject_name}}\r\n              </td>\r\n              <td style=\"text-align: right;\">\r\n                {{i.start_date}}\r\n              </td>\r\n              <td style=\"text-align: right;\">\r\n                {{i.end_date}}\r\n              </td>\r\n            </tr>\r\n            <tr *ngIf=\"isProfessional\">\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n                <input type=\"button\" class=\"btn fullBlue\" value=\"Archive\" (click)=\"archiveData($event)\" style=\"float: right;\">\r\n              </td>\r\n\r\n            </tr>\r\n            <tr *ngIf=\"!isProfessional\">\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n\r\n              </td>\r\n              <td>\r\n                <input type=\"button\" class=\"btn fullBlue\" value=\"Archive\" (click)=\"archiveData($event)\" style=\"float: right;\">\r\n              </td>\r\n\r\n            </tr>\r\n          </tbody>\r\n          <tbody *ngIf=\"newPaginated.length == 0 && dataStatus === true\">\r\n            <tr *ngFor=\"let dummy of dummyArr\">\r\n              <td *ngFor=\"let c of columnMaps\" style=\"padding:10px;\">\r\n                <div class=\"skeleton\">\r\n                </div>\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n          <tbody *ngIf=\"newPaginated.length == 0 && dataStatus === false\" class=\"records\">\r\n            <tr>\r\n              <td colspan=\"6\" class=\"records\">\r\n                No Records Found\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n        </table>\r\n      </div>\r\n      <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n        <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n          <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n            [page]=\"PageIndex\" [perPage]=\"pagedisplaysize\" [count]=\"totalRow\">\r\n          </pagination>\r\n        </div>\r\n      </div>\r\n    </section>\r\n  </aside>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/Archiving/courses/courses.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/course-module/Archiving/courses/courses.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CoursesComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_archiving_service_courses_service_service__ = __webpack_require__("./src/app/services/archiving-service/courses-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var CoursesComponent = /** @class */ (function () {
    function CoursesComponent(auth, batch, appc, router) {
        this.auth = auth;
        this.batch = batch;
        this.appc = appc;
        this.router = router;
        this.isProfessional = false;
        this.getCourses = [];
        this.PageIndex = 1;
        this.PageIndexPopup = 1;
        this.pagedisplaysize = 10;
        this.pagedisplaysizePopup = 10;
        this.totalRow = 0;
        this.newPaginated = [];
        this.searchText = "";
        this.searchData = [];
        this.searchflag = false;
        this.sendPayload = {
            courseIds: "",
            archived: false
        };
        this.sendPayloadBatch = {
            batchIds: "",
            archived: false
        };
        this.courseIds = [];
        this.getArr = [];
        this.getId = [];
        this.dummyArr = [0, 1, 2, 0, 1, 2];
        this.columnMaps = [0, 1, 2, 3, 4, 5];
        this.columnMaps2 = [0, 1, 2, 3, 4, 5, 6, 7];
        this.isRippleLoad = false;
        this.sortedenabled = true;
        this.sortedBy = "";
        this.direction = 0;
    }
    CoursesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.getCoursesList();
    };
    CoursesComponent.prototype.getCoursesList = function () {
        var _this = this;
        this.dataStatus = true;
        this.isRippleLoad = true;
        if (this.isProfessional) {
            this.batch.getBatches().subscribe(function (data) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                _this.getCourses = data;
                _this.getCourses.map(function (ele) {
                    ele.status = false;
                });
                _this.totalRow = data.length;
                _this.PageIndex = 1;
                _this.fetchTableDataByPage(_this.PageIndex);
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
        else {
            this.dataStatus = true;
            this.isRippleLoad = true;
            this.batch.getCoursesList().subscribe(function (data) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                _this.getCourses = data;
                _this.getCourses.map(function (ele) {
                    ele.status = false;
                });
                _this.totalRow = data.length;
                _this.PageIndex = 1;
                _this.fetchTableDataByPage(_this.PageIndex);
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
    };
    CoursesComponent.prototype.notifyMe = function (e) {
        var _this = this;
        var str = "";
        if (!this.isProfessional) {
            if (this.newPaginated[e].status == true) {
                this.getArr.push(this.newPaginated[e].course_id);
            }
            else {
                this.getArr = this.getArr.filter(function (ele) {
                    if (ele == _this.newPaginated[e].course_id) {
                        return false;
                    }
                    else {
                        return true;
                    }
                });
            }
            str = this.getArr.join(',');
            this.sendPayload.courseIds = str;
        }
        else {
            if (this.newPaginated[e].status) {
                this.getArr.push(this.newPaginated[e].batch_id);
            }
            else {
                this.getArr = this.getArr.filter(function (ele) {
                    if (ele == _this.newPaginated[e].batch_id) {
                        return false;
                    }
                    else {
                        return true;
                    }
                });
            }
            str = this.getArr.join(',');
            this.sendPayloadBatch.batchIds = str;
        }
    };
    CoursesComponent.prototype.archiveData = function (event) {
        var _this = this;
        if (!this.isProfessional) {
            if (this.sendPayload.courseIds == "" || this.sendPayload.courseIds == null) {
                var msg = {
                    type: "error",
                    body: "At least one course should be selected"
                };
                this.appc.popToast(msg);
            }
            else {
                this.sendPayload.archived = false;
                if (confirm('Are you sure, you want to Archive?')) {
                    this.batch.courses(this.sendPayload).subscribe(function (data) {
                        if (data.status_code == 202) {
                            if (confirm(data.message)) {
                                _this.sendPayload.archived = true;
                                _this.batch.courses(_this.sendPayload).subscribe(function (data) {
                                    _this.router.navigateByUrl("/view/course/archiving/coursesArchivedReport");
                                    var msg = {
                                        type: "success",
                                        body: "Course(s) archived successfully"
                                    };
                                    _this.appc.popToast(msg);
                                }, function (error) {
                                    var msg = {
                                        type: "error",
                                        body: error.error.message
                                    };
                                    _this.appc.popToast(msg);
                                });
                            }
                        }
                        else {
                            _this.router.navigateByUrl("/view/activity/archiving/coursesArchivedReport");
                            var msg = {
                                type: "success",
                                body: "Course(s) archived successfully"
                            };
                            _this.appc.popToast(msg);
                        }
                    }, function (error) {
                        var msg = {
                            type: "error",
                            body: error.error.message
                        };
                        _this.appc.popToast(msg);
                    });
                }
            }
        }
        else {
            if (this.sendPayloadBatch.batchIds == "" || this.sendPayloadBatch.batchIds == null) {
                var msg = {
                    type: "error",
                    body: "At least one Batch should be selected"
                };
                this.appc.popToast(msg);
            }
            else {
                if (confirm('Are you sure, you want to Archive?')) {
                    this.batch.batches(this.sendPayloadBatch).subscribe(function (data) {
                        if (data.status_code == 202) {
                            if (confirm(data.message)) {
                                _this.sendPayloadBatch.archived = true;
                                _this.batch.batches(_this.sendPayloadBatch).subscribe(function (data) {
                                    _this.router.navigateByUrl("/view/activity/archiving/batchesArchivedReport");
                                    var msg = {
                                        type: "success",
                                        body: "Batch(s) archived successfully"
                                    };
                                    _this.appc.popToast(msg);
                                }, function (error) {
                                    var msg = {
                                        type: "error",
                                        body: error.error.message
                                    };
                                    _this.appc.popToast(msg);
                                });
                            }
                        }
                        else {
                            _this.router.navigateByUrl("/view/activity/archiving/batchesArchivedReport");
                            var msg = {
                                type: "success",
                                body: "Batch(s) archived successfully"
                            };
                            _this.appc.popToast(msg);
                        }
                    }, function (error) {
                        if (error.error.message.includes("Batch Already assigned with active Student")) {
                            if (confirm(error.error.message)) {
                                _this.sendPayloadBatch.archived = true;
                                _this.batch.batches(_this.sendPayloadBatch).subscribe(function (data) {
                                    _this.router.navigateByUrl("/view/activity/archiving/batchesArchivedReport");
                                    var msg = {
                                        type: "success",
                                        body: "Batch(s) archived successfully"
                                    };
                                    _this.appc.popToast(msg);
                                }, function (error) {
                                    var msg = {
                                        type: "error",
                                        body: error.error.message
                                    };
                                    _this.appc.popToast(msg);
                                });
                            }
                        }
                        else {
                            var msg = {
                                type: "error",
                                body: error.error.message
                            };
                            _this.appc.popToast(msg);
                        }
                    });
                }
            }
        }
    };
    CoursesComponent.prototype.sortedData = function (ev) {
        var _this = this;
        this.sortedenabled = true;
        if (this.sortedenabled) {
            (this.direction == 0 || this.direction == -1) ? (this.direction = 1) : (this.direction = -1);
            this.sortedBy = ev;
            this.getCourses = this.getCourses.sort(function (a, b) {
                if (a[ev] < b[ev]) {
                    return -1 * _this.direction;
                }
                else if (a[ev] > b[ev]) {
                    return _this.direction;
                }
                else {
                    return 0;
                }
            });
            this.PageIndex = 1;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    CoursesComponent.prototype.getCaretVisiblity = function (e) {
        if (this.sortedenabled && this.sortedBy == e) {
            return true;
        }
        else {
            return false;
        }
    };
    CoursesComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.pagedisplaysize * (index - 1);
        this.newPaginated = this.getDataFromDataSource(startindex);
    };
    CoursesComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    CoursesComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    CoursesComponent.prototype.getDataFromDataSource = function (startindex) {
        if (this.searchflag) {
            var t = this.searchData.slice(startindex, startindex + this.pagedisplaysize);
            return t;
        }
        else {
            var t = this.getCourses.slice(startindex, startindex + this.pagedisplaysize);
            return t;
        }
    };
    CoursesComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            this.PageIndex = 1;
            var searchRes = void 0;
            searchRes = this.getCourses.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.searchData = searchRes;
            this.totalRow = searchRes.length;
            this.searchflag = true;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchflag = false;
            this.fetchTableDataByPage(this.PageIndex);
            this.totalRow = this.getCourses.length;
        }
    };
    CoursesComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-courses',
            template: __webpack_require__("./src/app/components/course-module/Archiving/courses/courses.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/Archiving/courses/courses.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_2__services_archiving_service_courses_service_service__["a" /* CoursesServiceService */],
            __WEBPACK_IMPORTED_MODULE_3__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_4__angular_router__["Router"]])
    ], CoursesComponent);
    return CoursesComponent;
}());



/***/ })

});
//# sourceMappingURL=archiving.module.chunk.js.map