webpackJsonp(["reports.module"],{

/***/ "./src/app/components/course-module/reports/attendance-report/attendanceReport.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"clear-fix\">\r\n    <aside class=\"middle-full\">\r\n        <section class=\"middle-main clearFix attendance-container\">\r\n\r\n            <section class=\"middle-top mb0 clearFix sms-header\">\r\n                <h2 class=\"pull-left\">\r\n                  <a routerLink=\"/view/course\" *ngIf=\"!isProfessional\">\r\n                      Course\r\n                  </a>\r\n                  <a routerLink=\"/view/batch\" *ngIf=\"isProfessional\">\r\n                    Batch\r\n                </a>\r\n                  <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n                  <a routerLink=\"/view/course/reports\">\r\n                      Reports\r\n                  </a>\r\n                  <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i> Attendance Report\r\n                </h2>\r\n                <aside class=\"pull-right\">\r\n                </aside>\r\n            </section>\r\n\r\n            <section class=\"filter-form\">\r\n                <div class=\"row\">\r\n\r\n                    <!-- Master Course / Standard  -->\r\n                    <div class=\"c-lg-4\">\r\n                        <div class=\"form-wrapper\" *ngIf=!isProfessional>\r\n                            <label>Master Course</label>\r\n                            <select class=\"side-form-ctrl\" [(ngModel)]=\"attendanceFetchForm.master_course_name\" (ngModelChange)=\"getCourseData($event)\"\r\n                                name=\"masterCourse\">\r\n                                <option value=-1></option>\r\n                                <option *ngFor=\"let i of masterCourses\" [value]=\"i.master_course\">{{i.master_course}}</option>\r\n                            </select>\r\n                        </div>\r\n                        <div class=\"form-wrapper\" *ngIf=isProfessional>\r\n                            <label>Master Course</label>\r\n                            <select class=\"side-form-ctrl\" [(ngModel)]=\"queryParams.standard_id\" (ngModelChange)=\"getCourseData($event)\" name=\"masterCourse\">\r\n                                <option value=-1></option>\r\n                                <option *ngFor=\"let i of masterCoursePro\" [value]=\"i.standard_id\">{{i.standard_name}}</option>\r\n                            </select>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <!-- Standard/ Subject -->\r\n                    <div class=\"c-lg-4\">\r\n                        <div class=\"form-wrapper\" *ngIf=!isProfessional>\r\n                            <label> Course</label>\r\n                            <select class=\"side-form-ctrl\" [(ngModel)]=\"attendanceFetchForm.course_id\" (ngModelChange)=\"getSubjectData($event)\">\r\n                                <option value=-1></option>\r\n                                <option *ngFor=\"let i of courses\" [value]=\"i.course_id\" name=\"subjectCourse\">{{i.course_name}}</option>\r\n                            </select>\r\n                        </div>\r\n                        <div class=\"form-wrapper\" *ngIf=\"isProfessional\">\r\n                            <label> Course</label>\r\n\r\n                            <select class=\"side-form-ctrl\" [(ngModel)]=\"queryParams.subject_id\" (ngModelChange)=\"getSubjectData($event)\">\r\n                                <option value=-1></option>\r\n                                <option *ngFor=\"let i of subjectPro\" [value]=\"i.subject_id\" name=\"subjectCourse\">{{i.subject_name}}</option>\r\n                            </select>\r\n                        </div>\r\n\r\n                    </div>\r\n\r\n                    <div class=\"c-lg-4\">\r\n                        <div class=\"form-wrapper\" *ngIf=!isProfessional>\r\n                            <label>Subject</label>\r\n                            <select class=\"side-form-ctrl\" [(ngModel)]=\"attendanceFetchForm.batch_id\" (ngModelChange)=\"getBatchData($event)\">\r\n                                <option value=-1></option>\r\n                                <option *ngFor=\"let i of batchCourses\" [value]=\"i.batch_id\" name=\"batchCourse\">{{i.batch_name}}</option>\r\n                            </select>\r\n                        </div>\r\n                        <div class=\"form-wrapper\" *ngIf=isProfessional>\r\n                            <label>Batch Name</label>\r\n                            <select class=\"side-form-ctrl\" [(ngModel)]=\"queryParams.batch_id\" (ngModelChange)=\"isShowDownloadReport()\">\r\n                                <option value=-1></option>\r\n                                <option *ngFor=\"let i of batchPro\" [value]=\"i.batch_id\" name=\"batchCourse\">{{i.batch_name}}</option>\r\n                            </select>\r\n                        </div>\r\n                    </div>\r\n\r\n                </div>\r\n\r\n                <div class=\"row\">\r\n\r\n                    <div class=\"c-lg-4\">\r\n                        <div class=\"form-date form-wrapper datePickerBox\" *ngIf=\"!isProfessional\">\r\n                            <label>From date</label>\r\n                            <input type=\"text\" class=\"side-form-ctrl  bsDatepicker\" [(ngModel)]=\"attendanceFetchForm.from_date\" (ngModelChange)=\"futureDateValid($event)\"\r\n                                bsDatepicker/>\r\n                            <i style=\"float:right; color:blue;\" (click)=\"clearFromDate()\" class=\"showCursor\">Clear</i>\r\n                        </div>\r\n\r\n                        <div class=\"form-date form-wrapper datePickerBox\" *ngIf=\"isProfessional\">\r\n                            <label>From date</label>\r\n                            <input type=\"text\" class=\"side-form-ctrl  bsDatepicker\" [(ngModel)]=\"queryParams.from_date\" (ngModelChange)=\"futureDateValid($event)\"\r\n                                bsDatepicker/>\r\n                            <i style=\"float:right; color:blue;\" (click)=\"clearFromDate()\" class=\"showCursor\">Clear</i>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"c-lg-4\">\r\n                        <div class=\"form-date form-wrapper datePickerBox\" *ngIf=\"!isProfessional\">\r\n                            <label>To date</label>\r\n                            <input type=\"text\" class=\"side-form-ctrl  bsDatepicker\" [(ngModel)]=\"attendanceFetchForm.to_date\" (ngModelChange)=\"futureDateValid($event)\"\r\n                                bsDatepicker/>\r\n                            <i style=\"float:right;  color:blue;\" (click)=\"clearToDate()\" class=\"showCursor\">Clear</i>\r\n                        </div>\r\n\r\n                        <div class=\"form-date form-wrapper datePickerBox\" *ngIf=\"isProfessional\">\r\n                            <label>To date</label>\r\n                            <input type=\"text\" class=\"side-form-ctrl  bsDatepicker\" [(ngModel)]=\"queryParams.to_date\" (ngModelChange)=\"futureDateValid($event)\"\r\n                                bsDatepicker/>\r\n                            <i style=\"float:right;  color:blue;\" (click)=\"clearToDate()\" class=\"showCursor\">Clear</i>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"c-lg-4 inner-main\">\r\n                        <div class=\"form-btn\">\r\n                            <div *ngIf=\"!isProfessional\">\r\n                                <div class=\"c-lg-6 inner-btn\">\r\n                                    <button class=\"btn fullBlue\" (click)=\"getPostData()\">Go</button>\r\n                                </div>\r\n                            </div>\r\n                            <div *ngIf=\"isProfessional\">\r\n                                <div class=\"c-lg-6 inner-btn\">\r\n                                    <button class=\"btn fullBlue\" (click)=\"getPostData()\">Go</button>\r\n                                </div>\r\n                            </div>\r\n                            <div *ngIf=\"isProfessional\">\r\n                                <div class=\"c-lg-6 outer-btn\">\r\n                                    <button class=\"btn fullBlue\" (click)=\"postDetails()\">Detail Report</button>\r\n                                </div>\r\n                            </div>\r\n                            <div *ngIf=\"!isProfessional\">\r\n                                <div class=\"c-lg-6 outer-btn\">\r\n                                    <button class=\"btn fullBlue\" (click)=\"postDetails()\">Detail Report</button>\r\n                                </div>\r\n                            </div>\r\n                            <div *ngIf=\"showDownloadReport\">\r\n                                <div class=\"c-lg-6 outer-btn\" style=\"padding-right: 0;\">\r\n                                    <button class=\"btn fullBlue\" (click)=\"downloadReport()\" style=\"background: #fff;color: #0084f6;\"><i class=\"fa fa-download\"> </i> PDF</button>\r\n                                    <a id=\"downloadFileClick\"></a>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                </div>\r\n\r\n            </section>\r\n\r\n            <div class=\"table-body\" *ngIf=\"SummaryReports\">\r\n                <div class=\"filter-box clearFix\" *ngIf=\"isProfessional\">\r\n                    <div id=\"basic-search\" class=\"search-filter-wrapper\">\r\n                        <input #search type=\"text\" class=\"search-field\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\" (keyup)=\"searchDatabase()\">\r\n                    </div>\r\n                </div>\r\n                <div class=\"filter-box clearFix\" *ngIf=\"!isProfessional\">\r\n                    <div id=\"basic-search\" class=\"search-filter-wrapper\">\r\n                        <input #search type=\"text\" class=\"search-field\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\" (keyup)=\"searchDatabase()\">\r\n                    </div>\r\n                </div>\r\n                <div class=\"table-content\">\r\n                    <div class=\"table-heading\">\r\n                        <div *ngIf=!isProfessional>\r\n                            <proctur-table [records]=\"pagedPostData\" (sortData)=\"sortedData($event)\" [tableName]=\"'sms'\" [settings]=\"projectSettings\"\r\n                                [dataStatus]=\"dataStatus\" [sortingEnabled]=\"sortingEnabled\" [columnMap]=\"columnMaps\" [dummyArr]=\"dummyArr\"\r\n                                [direction]=\"direction\" [loaderState]=\"isRippleLoad\">\r\n                            </proctur-table>\r\n                        </div>\r\n                        <div *ngIf=isProfessional>\r\n                            <proctur-table [records]=\"pagedPostDataPro\" [tableName]=\"'sms'\" [settings]=\"projectSettings\" [dataStatus]=\"dataStatus\" [columnMap]=\"columnMaps\"\r\n                                (sortData)=\"sortedData($event)\" [dummyArr]=\"dummyArr\" [direction]=\"direction\" [sortingEnabled]=\"sortingEnabled\" [loaderState]=\"isRippleLoad\">\r\n                            </proctur-table>\r\n\r\n                        </div>\r\n                    </div>\r\n                    <!-- Paginator Here -->\r\n                    <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n                        <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                            <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n                                [page]=\"PageIndex\" [perPage]=\"pagedisplaysize\" [count]=\"totalRow\">\r\n                            </pagination>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\r\n        </section>\r\n    </aside>\r\n\r\n\r\n\r\n    <proctur-popup [sizeWidth]=\"'large'\" *ngIf=\"addReportPopUp\">\r\n\r\n        <span class=\"closePopup pos-abs fbold show\" (click)=\"closeReportPopup()\" close-button>\r\n            <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n                <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n                    <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n                        <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n                        <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n                    </g>\r\n                    <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n                    />\r\n                </g>\r\n            </svg>\r\n        </span>\r\n\r\n        <div popup-header class=\"popup-header-content\" *ngIf=!isProfessional>\r\n            <h2>Date Wise Attendance Report</h2>\r\n            <h5>({{attendanceIndex0.class_date}} to {{attendanceIndexiOf.class_date}})</h5>\r\n        </div>\r\n        <div popup-header class=\"popup-header-content\" *ngIf=isProfessional>\r\n            <h2>Date Wise Attendance Report</h2>\r\n            <h5>({{attendanceIndex0Pro.class_date}} to {{attendanceIndexiOfPro.class_date}})</h5>\r\n        </div>\r\n        <div popup-content class=\"main-student-table\" *ngIf=!isProfessional>\r\n            <a class=\"fa fa-file-excel-o\" style=\"font-size:30px; padding-bottom:10px; float:right;display:inline-block;\" (click)=\"DownloadJsonToCsv()\"></a>\r\n            <a class=\"hide\" #xlsDownloader></a>\r\n\r\n            <div class=\"table table-responsive student-table madeAttendance\">\r\n                <table>\r\n                    <thead>\r\n                        <tr>\r\n                            <th>\r\n                                ID\r\n                            </th>\r\n                            <th>\r\n                                Name\r\n                            </th>\r\n                            <th *ngFor=\"let k of typeAttendance\">\r\n                                <div>\r\n                                    {{k.class_date | date:\"dd MMM\"}}\r\n                                    <br>\r\n                                    <span *ngIf=\"k.start_date != null || k.end_time != null\" class=\"madeDate\">\r\n                                        {{k.start_time}} - {{k.end_time}}\r\n                                    </span>\r\n                                    <br>\r\n                                </div>\r\n                            </th>\r\n                            <th>\r\n                                Present\r\n                            </th>\r\n\r\n                            <th>\r\n                                Absent\r\n                            </th>\r\n                            <th>\r\n                                Leave\r\n                            </th>\r\n\r\n                            <th>\r\n                                Percentage\r\n                            </th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody *ngIf=\"pageDetailedData.length != 0\">\r\n\r\n                        <tr *ngFor=\"let i of pageDetailedData; let j=index\">\r\n\r\n                            <td>\r\n                                {{i.student_disp_id}}\r\n\r\n                            </td>\r\n                            <td>\r\n                                {{i.student_name}}\r\n\r\n                            </td>\r\n\r\n                            <td *ngFor=\"let k of i.attendanceDateType\" [style.color]=\"getColor(k.status)\">\r\n                                {{k.status}}\r\n                            </td>\r\n                            <td>\r\n                                {{i.total_attended}}\r\n                            </td>\r\n                            <td style=\"color:red;\">\r\n                                {{i.total_absent}}\r\n                            </td>\r\n                            <td style=\"color:blue;\">\r\n                                {{i.total_leave}}\r\n                            </td>\r\n                            <td style=\"color:blue;\">\r\n                                {{i.spent_percentage}}%\r\n                            </td>\r\n                        </tr>\r\n\r\n                    </tbody>\r\n                    <tbody *ngIf=\"pageDetailedData.length == 0 && dataStatus === false\" class=\"records\">\r\n                        <tr>\r\n                            <td colspan=\"7\" class=\"records\">\r\n                                No Records Found\r\n                            </td>\r\n                        </tr>\r\n                    </tbody>\r\n                    <tbody *ngIf=\"pageDetailedData.length == 0 && dataStatus === true\">\r\n                        <tr *ngFor=\"let dummy of dummyArr\">\r\n                            <td *ngFor=\"let c of columnMaps\" style=\"padding:10px;\">\r\n                                <div class=\"skeleton\">\r\n                                </div>\r\n                            </td>\r\n                        </tr>\r\n                    </tbody>\r\n                </table>\r\n            </div>\r\n            <div class=\"table table-responsive student-table\" class=\"hide\">\r\n                <table #attendanceTable>\r\n                    <thead>\r\n                        <tr>\r\n                            <th>\r\n                                ID\r\n                            </th>\r\n                            <th>\r\n                                Name\r\n                            </th>\r\n                            <th *ngFor=\"let k of typeAttendance\">\r\n                                <div>\r\n                                    {{k.class_date | date:\"dd MMM\"}}\r\n                                    <br>\r\n                                    <span *ngIf=\"k.start_date != null || k.end_time != null\">\r\n                                        {{k.start_time}} - {{k.end_time}}\r\n                                    </span>\r\n                                    <br>\r\n                                </div>\r\n                            </th>\r\n                            <th>\r\n                                Present\r\n                            </th>\r\n\r\n                            <th>\r\n                                Absent\r\n                            </th>\r\n                            <th>\r\n                                Leave\r\n                            </th>\r\n\r\n                            <th>\r\n                                Percentage\r\n                            </th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n\r\n                        <tr *ngFor=\"let i of dateWiseAttendance; let j=index\">\r\n\r\n                            <td>\r\n                                {{i.student_disp_id}}\r\n\r\n                            </td>\r\n                            <td>\r\n                                {{i.student_name}}\r\n\r\n                            </td>\r\n\r\n                            <td *ngFor=\"let k of i.attendanceDateType\" [style.color]=\"getColor(k.status)\">\r\n                                {{k.status}}\r\n                            </td>\r\n                            <td>\r\n                                {{i.total_attended}}\r\n                            </td>\r\n                            <td style=\"color:red;\">\r\n                                {{i.total_absent}}\r\n                            </td>\r\n                            <td style=\"color:blue;\">\r\n                                {{i.total_leave}}\r\n                            </td>\r\n                            <td style=\"color:blue;\">\r\n                                {{i.spent_percentage}}%\r\n                            </td>\r\n                        </tr>\r\n                        <tr *ngIf=\"dateWiseAttendance.length == 0\" class=\"records\">\r\n                            <td colspan=\"7\" class=\"records\">\r\n                                No Records Found\r\n                            </td>\r\n                        </tr>\r\n                    </tbody>\r\n                </table>\r\n            </div>\r\n            <div class=\"row filter-res pagination\" style=\"width: 100%;\" *ngIf=!isProfessional>\r\n                <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                    <pagination (goPage)=\"fetchTableDataByPagePopup($event)\" (goNext)=\"fetchNextPopupRange()\" (goPrev)=\"fetchPreviousPopup()\"\r\n                        [pagesToShow]=\"10\" [page]=\"PageIndexPopup\" [perPage]=\"pagedisplaysizePopup\" [count]=\"totalRowPopup\">\r\n                    </pagination>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n        <div popup-content class=\"main-student-table\" *ngIf=isProfessional>\r\n            <a class=\"fa fa-file-excel-o\" style=\"font-size:30px; padding-bottom:10px; float:right;display:inline-block;\" (click)=\"DownloadJsonToCsv()\"></a>\r\n            <a class=\"hide\" #xlsDownloader></a>\r\n\r\n            <div class=\"table table-responsive student-table madeAttendance\">\r\n                <table>\r\n                    <thead>\r\n                        <tr>\r\n                            <th>\r\n                                ID\r\n                            </th>\r\n                            <th>\r\n                                Name\r\n                            </th>\r\n                            <th *ngFor=\"let k of typeAttendancePro\">\r\n                                <div>\r\n                                    {{k.class_date | date:\"dd MMM\"}}\r\n                                    <br>\r\n                                    <span *ngIf=\"k.start_date != null || k.end_time != null\" class=\"madeDate\">\r\n                                        {{k.start_time}} - {{k.end_time}}\r\n                                    </span>\r\n                                    <br>\r\n                                </div>\r\n                            </th>\r\n                            <th>\r\n                                Total Present\r\n                            </th>\r\n\r\n                            <th>\r\n                                Total absent\r\n                            </th>\r\n                            <th>\r\n                                Total leave\r\n                            </th>\r\n\r\n                            <th>\r\n                                Percentage\r\n                            </th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n\r\n                        <tr *ngFor=\"let i of pageDetailedDataPro; let j=index\">\r\n                            <td>\r\n                                {{i.student_disp_id}}\r\n                            </td>\r\n                            <td>\r\n                                {{i.student_name}}\r\n                            </td>\r\n                            <td *ngFor=\"let k of i.attendanceDateType\" [style.color]=\"getColor(k.status)\">\r\n                                {{k.status}}\r\n                            </td>\r\n                            <td>\r\n                                {{i.total_attended}}\r\n                            </td>\r\n                            <td style=\"color:red;\">\r\n                                {{i.total_absent}}\r\n                            </td>\r\n                            <td style=\"color:blue;\">\r\n                                {{i.total_leave}}\r\n                            </td>\r\n\r\n                            <td style=\"color:blue;\">\r\n                                {{i.spent_percentage}}%\r\n                            </td>\r\n                        </tr>\r\n\r\n                    </tbody>\r\n                    <tbody *ngIf=\"pageDetailedDataPro.length == 0 && dataStatus === false\" class=\"records\">\r\n                        <tr>\r\n                            <td colspan=\"7\" class=\"records\">\r\n                                No Records Found\r\n                            </td>\r\n                        </tr>\r\n                    </tbody>\r\n                    <tbody *ngIf=\"pageDetailedDataPro.length == 0 && dataStatus === true\">\r\n                        <tr *ngFor=\"let dummy of dummyArr\">\r\n                            <td *ngFor=\"let c of columnMaps\" style=\"padding:10px;\">\r\n                                <div class=\"skeleton\">\r\n                                </div>\r\n                            </td>\r\n                        </tr>\r\n                    </tbody>\r\n                </table>\r\n            </div>\r\n            <div class=\"table table-responsive student-table madeAttendance\" class=\"hide\">\r\n                <table #attendanceTable>\r\n                    <thead>\r\n                        <tr>\r\n                            <th>\r\n                                ID\r\n                            </th>\r\n                            <th>\r\n                                Name\r\n                            </th>\r\n                            <th *ngFor=\"let k of typeAttendancePro\">\r\n                                <div>\r\n                                    {{k.class_date | date:\"dd MMM\"}}\r\n                                    <br>\r\n                                    <span *ngIf=\"k.start_date != null || k.end_time != null\" class=\"madeDate\">\r\n                                        {{k.start_time}} - {{k.end_time}}\r\n                                    </span>\r\n                                </div>\r\n                            </th>\r\n                            <th>\r\n                                Total Present\r\n                            </th>\r\n\r\n                            <th>\r\n                                Total absent\r\n                            </th>\r\n                            <th>\r\n                                Total leave\r\n                            </th>\r\n\r\n                            <th>\r\n                                Percentage\r\n                            </th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n\r\n                        <tr *ngFor=\"let i of dateWiseAttendancePro; let j=index\">\r\n                            <td>\r\n                                {{i.student_disp_id}}\r\n                            </td>\r\n                            <td>\r\n                                {{i.student_name}}\r\n                            </td>\r\n                            <td *ngFor=\"let k of i.attendanceDateType\" [style.color]=\"getColor(k.status)\">\r\n                                {{k.status}}\r\n                            </td>\r\n                            <td>\r\n                                {{i.total_attended}}\r\n                            </td>\r\n                            <td style=\"color:red;\">\r\n                                {{i.total_absent}}\r\n                            </td>\r\n                            <td style=\"color:blue;\">\r\n                                {{i.total_leave}}\r\n                            </td>\r\n\r\n                            <td style=\"color:blue;\">\r\n                                {{i.spent_percentage}}%\r\n                            </td>\r\n                        </tr>\r\n                        <tr *ngIf=\"dateWiseAttendancePro.length == 0\">\r\n                            <td class=\"records\" colspan=\"7\">\r\n                                No Records Found\r\n                            </td>\r\n                        </tr>\r\n                    </tbody>\r\n                </table>\r\n            </div>\r\n            <div class=\"row filter-res pagination\" style=\"width: 100%;\" *ngIf=isProfessional>\r\n                <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                    <pagination (goPage)=\"fetchTableDataByPagePopup($event)\" (goNext)=\"fetchNextPopupRange()\" (goPrev)=\"fetchPreviousPopup()\"\r\n                        [pagesToShow]=\"10\" [page]=\"PageIndexPopup\" [perPage]=\"pagedisplaysizePopup\" [count]=\"totalRowPopup\">\r\n                    </pagination>\r\n                </div>\r\n            </div>\r\n\r\n        </div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/attendance-report/attendanceReport.component.scss":
/***/ (function(module, exports) {

module.exports = ".madeAttendance table thead tr {\n  padding: 5px; }\n  .madeAttendance table thead tr th {\n    padding: 5px; }\n  .madeAttendance .madeDate {\n  font-size: 12px; }\n  .skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 100%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n  .skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n  .showCursor:hover {\n  cursor: pointer; }\n  .attendance-container {\n  background: #efefef;\n  padding: 5px;\n  overflow: auto; }\n  .filter-form {\n  background: #fff;\n  -webkit-box-shadow: 0px 0px 2px 2px #dadada;\n          box-shadow: 0px 0px 2px 2px #dadada;\n  border-radius: 10px;\n  /*popup scss*/ }\n  .filter-form .row {\n    margin: 5px 15px; }\n  .filter-form .form-wrapper {\n    position: relative; }\n  .filter-form .form-wrapper.datePickerBox .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent; }\n  .filter-form .form-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 0;\n      top: 20px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n  .filter-form .form-wrapper {\n    padding: 10px 5px; }\n  .filter-form .form-wrapper label {\n      width: 100%;\n      display: block; }\n  .filter-form .form-wrapper .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent;\n      width: 100%;\n      padding: 3px;\n      display: block;\n      border: 1px solid #dadada; }\n  .filter-form .form-wrapper {\n    padding: 10px 5px;\n    position: relative; }\n  .filter-form .form-wrapper.datePickerBox .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent;\n      width: 100%;\n      padding: 5px;\n      display: block;\n      border: 1px solid #dadada; }\n  .filter-form .form-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 10px;\n      top: 30px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n  .filter-form .popup-content {\n    position: relative;\n    left: 5%;\n    overflow-x: hidden; }\n  .filter-form .popup-content table {\n      overflow-y: auto;\n      overflow-x: auto;\n      width: 95%; }\n  .filter-form .popup-content h5 {\n      font-weight: 200px;\n      text-align: center; }\n  .filter-form .popup-content h2 {\n      text-align: center; }\n  .filter-form .main-student-table ::-webkit-scrollbar {\n    display: block; }\n  .filter-form .main-student-table .student-table {\n    overflow-x: auto;\n    height: 400px; }\n  .filter-form .btn {\n    display: inline-block; }\n  .filter-form .inner-main {\n    display: inline;\n    padding: 25px 0px 12px 0px; }\n  .filter-form .inner-main .form-btn .btn {\n      margin: 0px 10px;\n      margin: 0px; }\n  .filter-form .inner-main .inner-btn {\n      display: inline-block;\n      width: auto;\n      padding-left: 20px;\n      padding-right: 20px; }\n  .filter-form .inner-main .outer-btn {\n      display: inline-block;\n      width: auto;\n      padding-left: 20px;\n      padding-right: 20px; }\n  .filter-form .records {\n    font-size: 20px;\n    font-weight: bold;\n    text-align: center; }\n  .filter-form .form-field {\n    display: inline-block;\n    width: 80%; }\n  .filter-form .form-date {\n    display: inline-block;\n    width: 100%; }\n  .filter-form .table-content {\n    height: 350px; }\n  .filter-form .table-content ::-webkit-scrollbar {\n      display: block; }\n  .filter-form .table-content .table-heading {\n      overflow-x: auto;\n      height: 350px; }\n  .filter-form .filter-box {\n    padding: 10px 0px;\n    margin-bottom: 5px;\n    background: #efefef; }\n  .filter-form .form-wrapper .datePickerBox {\n    padding-right: 10px;\n    padding-bottom: 10px;\n    width: 10%; }\n  .filter-form .popup-header-content h2 {\n    text-align: center;\n    margin-top: 10px;\n    margin-bottom: 10px; }\n  .filter-form .popup-header-content h5 {\n    text-align: center;\n    margin-top: 10px;\n    margin-bottom: 10px; }\n  .filter-form .middle-section {\n    padding: 5px 15px;\n    width: 100%;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box; }\n  .filter-form .middle-section .middle-top h2 {\n      color: black;\n      font-weight: unset;\n      padding-top: 20px; }\n  .filter-form .middle-section .form-wrapper {\n      background: transparent;\n      margin: 25px 0px;\n      -ms-flex-line-pack: center;\n          align-content: center; }\n  .filter-form .middle-section .form-wrapper .btn {\n        margin-top: -3px;\n        width: 70%; }\n  .filter-form .middle-section .form-wrapper label {\n        padding-left: 10px;\n        font-size: 12px;\n        font-weight: 400;\n        color: 0084f6;\n        text-decoration: none;\n        text-transform: uppercase;\n        -webkit-font-smoothing: antialiased;\n        width: 100%; }\n  .filter-form .middle-section .form-wrapper .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        padding-left: 10px;\n        margin-left: 10px;\n        height: 30px;\n        padding: 0px 5px;\n        font-weight: 600;\n        font-size: 14px;\n        color: black; }\n  .filter-form .middle-section .form-wrapper .side-form-ctrl.bsDatepicker {\n          padding-left: 10px;\n          margin-left: 10px;\n          width: 100%; }\n  .filter-form .popupWrapper {\n    position: fixed;\n    width: 100%;\n    height: 100%;\n    bottom: 0;\n    top: 0px;\n    right: 0;\n    left: 0px;\n    background: rgba(230, 230, 230, 0.5);\n    z-index: 100;\n    visibility: hidden;\n    opacity: 0;\n    -webkit-transition: all 0.5s ease-in;\n    transition: all 0.5s ease-in; }\n  .filter-form .popupWrapper .popup {\n      max-width: 100%;\n      width: 100%;\n      height: auto;\n      left: 0;\n      right: 0;\n      top: 5%;\n      bottom: 0;\n      margin: auto; }\n  .filter-form .popup-wrapper {\n    padding: 20px 20px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n            box-shadow: 1px 8px 20px 5px #9c9c9c;\n    -webkit-transition: unset;\n    transition: unset;\n    background: #fff; }\n  .filter-form .popup-wrapper span {\n      font-weight: 300;\n      display: inline-block; }\n  .filter-form .popup-wrapper h2 {\n      margin-bottom: 15px;\n      font-size: 14px; }\n  .filter-form .popup-wrapper h4 {\n      margin: 25px 0 15px;\n      font-weight: 600; }\n  .filter-form .closePopup {\n    right: 10px;\n    top: 10px;\n    font-size: 18px;\n    cursor: pointer;\n    line-height: 20px;\n    width: 26px;\n    height: 26px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    text-align: center;\n    padding-top: 3px;\n    display: none; }\n  .filter-form .closePopup.bottomRight {\n      bottom: 2px;\n      top: auto;\n      left: auto;\n      right: 0; }\n  .filter-form .closePopup.topLeft {\n      left: 0;\n      right: auto;\n      top: 1px;\n      bottom: auto; }\n  .filter-form .closePopup.bottomLeft {\n      left: 0;\n      right: auto;\n      bottom: 2px;\n      top: auto; }\n  .filter-form .closePopup svg {\n      width: 16px; }\n  .filter-form .closePopup svg .cls-1 {\n        stroke: #c1c1c1;\n        stroke-width: 2px; }\n  .filter-form .popup-content {\n    height: 100%;\n    overflow: hidden;\n    visibility: visible; }\n  .filter-form .fadeIn {\n    opacity: 1;\n    visibility: visible; }\n  .filter-form .popupWrapperMob {\n    position: fixed;\n    width: 100%;\n    height: 100%;\n    bottom: 0;\n    top: 0;\n    right: 0;\n    left: 0;\n    z-index: 100;\n    background: rgba(0, 0, 0, 0.5);\n    visibility: hidden;\n    -webkit-transition: all 0.5s ease-in;\n    transition: all 0.5s ease-in; }\n  .filter-form .popupWrapperMob .closePopup {\n      right: -25px;\n      top: -27px;\n      display: block; }\n  .filter-form .popup-mob {\n    left: 0;\n    width: 100%;\n    max-height: 70%;\n    background: #fff;\n    padding: 30px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    height: 100%;\n    overflow: auto;\n    z-index: 1;\n    bottom: -70%;\n    -webkit-transition: all 0.5s ease-in;\n    transition: all 0.5s ease-in; }\n  .filter-form .popupWrapperMob.showPopupMob {\n    z-index: 100;\n    visibility: visible;\n    opacity: 1; }\n  .filter-form .popupWrapperMob.showPopupMob .popup-mob {\n    bottom: 0; }\n  .filter-form .popup-content ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n  .search-filter-wrapper {\n  margin: 10px 5px 10px 5px;\n  float: right; }\n  .search-filter-wrapper .search-field {\n    font-size: 12px;\n    padding: 7px 10px;\n    width: 200px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    float: right;\n    height: 35px;\n    font-size: 14px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/attendance-report/attendanceReport.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AttendanceReportComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_attendance_report_service_service__ = __webpack_require__("./src/app/components/course-module/services/attendance-report-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_http_service__ = __webpack_require__("./src/app/services/http.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6____ = __webpack_require__("./src/app/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var AttendanceReportComponent = /** @class */ (function () {
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    function AttendanceReportComponent(reportService, appc, auth, _httpService, msgService, commonService) {
        this.reportService = reportService;
        this.appc = appc;
        this.auth = auth;
        this._httpService = _httpService;
        this.msgService = msgService;
        this.commonService = commonService;
        this.masterCourses = [];
        this.postData = [];
        this.pagedPostData = [];
        this.courses = [];
        this.batchCourses = [];
        this.SummaryReports = false;
        this.PageIndex = 1;
        this.PageIndexPopup = 1;
        this.pagedisplaysize = 10;
        this.pagedisplaysizePopup = 10;
        this.addReportPopUp = false;
        this.dateWiseAttendance = [];
        this.dateWiseAttendancePro = [];
        this.pageDetailedData = [];
        this.dataTypeAttendance = [];
        this.dataTypeAttendancePro = [];
        this.typeAttendance = [];
        this.attendanceIndex0 = [];
        this.attendanceIndex0Pro = [];
        this.attendanceIndexiOf = [];
        this.attendanceIndexiOfPro = [];
        this.isProfessional = true;
        this.masterCoursePro = [];
        this.subjectPro = [];
        this.batchPro = [];
        this.typeAttendancePro = [];
        this.pagedPostDataPro = [];
        this.queryParamsPro = [];
        this.pageDetailedDataPro = [];
        this.property = "";
        this.direction = 0;
        this.sortingEnabled = true;
        this.dummyArr = [0, 1, 2, 0, 1, 2];
        this.columnMaps = [0, 1, 2, 3, 4, 5, 6, 7, 8];
        this.columnMaps2 = [0, 1, 2, 3, 4, 5];
        this.dataStatus = false;
        this.isRippleLoad = false;
        this.projectSettings = [
            { primaryKey: 'student_disp_id', header: 'Student id' },
            { primaryKey: 'student_name', header: 'Student name' },
            { primaryKey: 'student_phone', header: 'Contact no' },
            { primaryKey: 'doj', header: 'Joining date' },
            { primaryKey: 'total_classes', header: 'Total classes' },
            { primaryKey: 'total_attended', header: 'Present' },
            { primaryKey: 'total_absent', header: 'Absent' },
            { primaryKey: 'total_leave', header: 'Leave' },
            { primaryKey: 'spent_percentage', header: 'Attendance(%)' }
        ];
        this.attendanceFetchForm = {
            standard_id: "",
            subject_id: "",
            institution_id: sessionStorage.getItem('institute_id'),
            course_id: "-1",
            batch_id: "-1",
            master_course_name: "",
            from_date: __WEBPACK_IMPORTED_MODULE_4_moment__(new Date()).format('YYYY-MM-DD'),
            to_date: __WEBPACK_IMPORTED_MODULE_4_moment__(new Date()).format('YYYY-MM-DD')
        };
        /*for professional*/
        this.queryParams = {
            standard_id: "",
            subject_id: "-1",
            institution_id: sessionStorage.getItem('institute_id'),
            course_id: -1,
            batch_id: "-1",
            master_course_name: "",
            from_date: __WEBPACK_IMPORTED_MODULE_4_moment__(new Date()).format('YYYY-MM-DD'),
            to_date: __WEBPACK_IMPORTED_MODULE_4_moment__(new Date()).format('YYYY-MM-DD')
        };
        this.searchText = "";
        this.searchflag = false;
        this.showDownloadReport = false;
        this.searchData = [];
        //console.log(moment(moment().format('DD-MM-YYYY')).diff(moment('03-02-2018'),'months'));
    }
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.getMasterCourseData();
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    /* this is ussed to fetch details for dropdown for master course/ Standard */
    AttendanceReportComponent.prototype.getMasterCourseData = function () {
        var _this = this;
        this.isRippleLoad = true;
        if (this.isProfessional) {
            this.reportService.fetchMasterCourseProfessional(this.queryParams).subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.masterCoursePro = data.standardLi;
                _this.batchPro = data.batchLi;
            }, function (error) {
                _this.isRippleLoad = false;
                _this.dataStatus = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
                return error;
            });
        }
        else {
            this.reportService.getMasterCourse().subscribe(function (data) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                _this.masterCourses = data;
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
                return error;
            });
        }
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.getCourseData = function (i) {
        var _this = this;
        this.attendanceFetchForm.batch_id = "-1";
        this.queryParams.batch_id = "-1";
        this.isShowDownloadReport();
        this.isRippleLoad = true;
        this.dataStatus = true;
        this.queryParams.standard_id = i;
        this.queryParams.subject_id = "-1";
        this.queryParams.batch_id = "-1";
        if (this.isProfessional) {
            this.reportService.fetchMasterCourseProfessional(this.queryParams).subscribe(function (data) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                _this.subjectPro = data.subjectLi;
                _this.batchPro = data.batchLi;
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
                return error;
            });
            this.batchPro = [];
            this.subjectPro = [];
        }
        else {
            this.dataStatus = true;
            this.isRippleLoad = true;
            this.attendanceFetchForm.batch_id = "";
            this.attendanceFetchForm.course_id = "";
            this.reportService.getCourses(i).subscribe(function (data) {
                _this.dataStatus = false;
                _this.attendanceFetchForm.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.attendanceFetchForm.from_date).format('YYYY-MM-DD');
                _this.attendanceFetchForm.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.attendanceFetchForm.to_date).format('YYYY-MM-DD');
                _this.queryParams.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.queryParams.from_date).format('YYYY-MM-DD');
                _this.queryParams.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.queryParams.to_date).format('YYYY-MM-DD');
                _this.isRippleLoad = false;
                _this.courses = data.coursesList;
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
                return error;
            });
            this.courses = [];
            this.batchCourses = [];
        }
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.getSubjectData = function (i) {
        var _this = this;
        this.isShowDownloadReport();
        this.isRippleLoad = true;
        this.dataStatus = true;
        this.queryParams.standard_id = this.queryParams.standard_id;
        if (this.isProfessional) {
            this.reportService.fetchMasterCourseProfessional(this.queryParams).subscribe(function (data) {
                _this.dataStatus = false;
                _this.attendanceFetchForm.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.attendanceFetchForm.from_date).format('YYYY-MM-DD');
                _this.attendanceFetchForm.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.attendanceFetchForm.to_date).format('YYYY-MM-DD');
                _this.queryParams.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.queryParams.from_date).format('YYYY-MM-DD');
                _this.queryParams.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.queryParams.to_date).format('YYYY-MM-DD');
                _this.isRippleLoad = false;
                _this.batchPro = data.batchLi;
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
                return error;
            });
            this.batchPro = [];
        }
        else {
            this.attendanceFetchForm.batch_id = "";
            this.reportService.getSubject(i).subscribe(function (data) {
                _this.dataStatus = false;
                _this.attendanceFetchForm.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.attendanceFetchForm.from_date).format('YYYY-MM-DD');
                _this.attendanceFetchForm.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.attendanceFetchForm.to_date).format('YYYY-MM-DD');
                _this.queryParams.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.queryParams.from_date).format('YYYY-MM-DD');
                _this.queryParams.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.queryParams.to_date).format('YYYY-MM-DD');
                _this.isRippleLoad = false;
                _this.batchCourses = data.batchesList;
                // this.getPostData();
            });
            this.batchCourses = [];
        }
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.getBatchData = function (i) {
        var _this = this;
        this.isShowDownloadReport();
        this.dataStatus = true;
        this.isRippleLoad = true;
        this.queryParams.standard_id = this.queryParams.standard_id;
        this.queryParams.batch_id = this.queryParams.batch_id;
        if (this.isProfessional) {
            this.reportService.postDataToTablePro(this.queryParams).subscribe(function (data) {
                _this.dataStatus = false;
                _this.attendanceFetchForm.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.attendanceFetchForm.from_date).format('YYYY-MM-DD');
                _this.attendanceFetchForm.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.attendanceFetchForm.to_date).format('YYYY-MM-DD');
                _this.queryParams.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.queryParams.from_date).format('YYYY-MM-DD');
                _this.queryParams.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.queryParams.to_date).format('YYYY-MM-DD');
                _this.isRippleLoad = false;
                // this.getPostData();
            });
        }
        else {
            this.reportService.postDataToTable(this.attendanceFetchForm).subscribe(function (data) {
                _this.dataStatus = false;
                _this.attendanceFetchForm.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.attendanceFetchForm.from_date).format('YYYY-MM-DD');
                _this.attendanceFetchForm.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.attendanceFetchForm.to_date).format('YYYY-MM-DD');
                _this.queryParams.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.queryParams.from_date).format('YYYY-MM-DD');
                _this.queryParams.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(_this.queryParams.to_date).format('YYYY-MM-DD');
                _this.isRippleLoad = false;
                // this.getPostData();
            });
        }
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.getPostData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.SummaryReports = true;
        this.dataStatus = true;
        this.PageIndex = 1;
        if (this.isProfessional) {
            this.reportService.postDataToTablePro(this.queryParams).subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.dataStatus = false;
                _this.queryParamsPro = data;
                _this.totalRow = data.length;
                _this.PageIndex = 1;
                _this.fetchTableDataByPage(_this.PageIndex);
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
                return error;
            });
        }
        else {
            if (this.attendanceFetchForm.from_date == "Invalid date") {
                this.attendanceFetchForm.from_date = "";
            }
            if (this.attendanceFetchForm.to_date == "Invalid date") {
                this.attendanceFetchForm.to_date = "";
            }
            this.reportService.postDataToTable(this.attendanceFetchForm).subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.dataStatus = false;
                _this.postData = data;
                _this.totalRow = data.length;
                _this.PageIndex = 1;
                _this.fetchTableDataByPage(_this.PageIndex);
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
                return error;
            });
        }
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.postDetails = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.dataStatus = true;
        this.queryParams.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(this.queryParams.from_date).format('YYYY-MM-DD');
        this.queryParams.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(this.queryParams.to_date).format('YYYY-MM-DD');
        var diff = __WEBPACK_IMPORTED_MODULE_4_moment__(this.queryParams.from_date).diff(__WEBPACK_IMPORTED_MODULE_4_moment__(this.queryParams.to_date), 'months');
        var futureDate = __WEBPACK_IMPORTED_MODULE_4_moment__(this.queryParams.to_date).add('days', 1).format('YYYY-MM-DD');
        if (this.isProfessional) {
            if (this.queryParams.from_date == "" || this.queryParams.to_date == "" || this.queryParams.batch_id == "-1" || this.queryParams.batch_id == " " || this.queryParams.subject_id == "" || this.queryParams.standard_id == "-1") {
                var msg = {
                    type: "error",
                    title: "Incorrect Details",
                    body: "All fields Are required"
                };
                this.appc.popToast(msg);
                this.dataStatus = false;
                this.isRippleLoad = false;
            }
            else if (this.queryParams.from_date > this.queryParams.to_date) {
                var msg = {
                    type: "error",
                    title: "Incorrect Details",
                    body: "From Date Must Be less than to date"
                };
                this.appc.popToast(msg);
                this.dataStatus = false;
                this.isRippleLoad = false;
            }
            else if (diff < -4) {
                var msg = {
                    type: "error",
                    title: "Incorrect Details",
                    body: "You cannot select more than 120 days"
                };
                this.appc.popToast(msg);
                this.dataStatus = false;
                this.isRippleLoad = false;
            }
            else {
                this.pageDetailedDataPro = [];
                this.typeAttendancePro = [];
                this.reportService.postDetailedData(this.queryParams).subscribe(function (data) {
                    _this.isRippleLoad = false;
                    _this.dataStatus = false;
                    if (data.length) {
                        _this.dataStatus = false;
                        _this.dateWiseAttendancePro = data;
                        _this.dataTypeAttendancePro = data.map(function (ele) {
                            _this.typeAttendancePro = ele.attendanceDateType;
                        });
                        _this.attendanceIndex0Pro = _this.typeAttendancePro[0];
                        _this.attendanceIndexiPro = _this.typeAttendancePro.length;
                        _this.attendanceIndexiOfPro = _this.typeAttendancePro[_this.attendanceIndexiPro - 1];
                        _this.addReportPopUp = true;
                        _this.totalRowPopup = data.length;
                        _this.PageIndexPopup = 1;
                        _this.fetchTableDataByPagePopup(_this.PageIndexPopup);
                    }
                    else {
                        var msg = {
                            type: "info",
                            title: "No data found",
                            body: "We did not find any attendance marked for the selected dates "
                        };
                        _this.appc.popToast(msg);
                        _this.isRippleLoad = false;
                        _this.dataStatus = false;
                    }
                }, function (error) {
                    _this.isRippleLoad = false;
                    _this.dataStatus = false;
                    var msg = {
                        type: "error",
                        body: error.error.message
                    };
                    _this.appc.popToast(msg);
                    return error;
                });
            }
        }
        else {
            this.attendanceFetchForm.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(this.attendanceFetchForm.from_date).format('YYYY-MM-DD');
            this.attendanceFetchForm.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(this.attendanceFetchForm.to_date).format('YYYY-MM-DD');
            var diff_1 = __WEBPACK_IMPORTED_MODULE_4_moment__(this.attendanceFetchForm.from_date).diff(__WEBPACK_IMPORTED_MODULE_4_moment__(this.attendanceFetchForm.to_date), 'months');
            var futureDate_1 = __WEBPACK_IMPORTED_MODULE_4_moment__(this.attendanceFetchForm.to_date).add('days', 1).format('YYYY-MM-DD');
            this.isRippleLoad = true;
            if (this.attendanceFetchForm.master_course_name == "" || this.attendanceFetchForm.course_id == "" || this.attendanceFetchForm.batch_id == "" || this.attendanceFetchForm.from_date == "" || this.attendanceFetchForm.to_date == "") {
                var msg = {
                    type: "error",
                    title: "Incorrect Details",
                    body: "All fields Are required"
                };
                this.appc.popToast(msg);
                this.dataStatus = false;
                this.isRippleLoad = false;
            }
            else if (this.attendanceFetchForm.from_date > this.attendanceFetchForm.to_date) {
                var msg = {
                    type: "error",
                    title: "Incorrect Details",
                    body: "From Date Must Be less than to date"
                };
                this.appc.popToast(msg);
                this.dataStatus = false;
                this.isRippleLoad = false;
            }
            else if (diff_1 < -4) {
                var msg = {
                    type: "error",
                    title: "Incorrect Details",
                    body: "You cannot select more than 120 days"
                };
                this.appc.popToast(msg);
                this.dataStatus = false;
                this.isRippleLoad = false;
            }
            else {
                this.dataStatus = true;
                this.typeAttendance = [];
                this.pageDetailedData = [];
                this.reportService.postDetailedData(this.attendanceFetchForm).subscribe(function (data) {
                    if (data.length) {
                        _this.addReportPopUp = true;
                        _this.isRippleLoad = false;
                        _this.dataStatus = false;
                        _this.dateWiseAttendance = data;
                        _this.dataTypeAttendance = _this.dateWiseAttendance.map(function (ele) {
                            _this.typeAttendance = ele.attendanceDateType;
                        });
                        _this.attendanceIndex0 = _this.typeAttendance[0];
                        _this.attendanceIndexi = _this.typeAttendance.length;
                        _this.attendanceIndexiOf = _this.typeAttendance[_this.attendanceIndexi - 1];
                        _this.totalRowPopup = data.length;
                        _this.PageIndexPopup = 1;
                        _this.fetchTableDataByPagePopup(_this.PageIndexPopup);
                    }
                    else {
                        var msg = {
                            type: "info",
                            title: "No data found",
                            body: "We did not find any attendance marked for the selected dates "
                        };
                        _this.appc.popToast(msg);
                        _this.isRippleLoad = false;
                        _this.dataStatus = false;
                    }
                }, function (error) {
                    _this.isRippleLoad = false;
                    _this.dataStatus = false;
                    var msg = {
                        type: "error",
                        body: error.error.message
                    };
                    _this.appc.popToast(msg);
                    return error;
                });
            }
        }
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.closeReportPopup = function () {
        this.addReportPopUp = false;
    };
    // pagination functions
    //for summary report
    AttendanceReportComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.pagedisplaysize * (index - 1);
        if (this.isProfessional) {
            this.pagedPostDataPro = this.getDataFromDataSource(startindex);
        }
        else {
            this.pagedPostData = this.getDataFromDataSource(startindex);
        }
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.getDataFromDataSource = function (startindex) {
        if (this.isProfessional) {
            if (this.searchflag) {
                var t = this.searchData.slice(startindex, startindex + this.pagedisplaysize);
                return t;
            }
            else {
                var t = this.queryParamsPro.slice(startindex, startindex + this.pagedisplaysize);
                return t;
            }
        }
        else {
            if (this.searchflag) {
                var t = this.searchData.slice(startindex, startindex + this.pagedisplaysize);
                return t;
            }
            else {
                var t = this.postData.slice(startindex, startindex + this.pagedisplaysize);
                return t;
            }
        }
    };
    //for detailed report
    AttendanceReportComponent.prototype.fetchTableDataByPagePopup = function (index) {
        this.PageIndexPopup = index;
        var startindex = this.pagedisplaysizePopup * (index - 1);
        if (this.isProfessional) {
            this.pageDetailedDataPro = this.getDataFromDataSourcePopup(startindex);
        }
        else {
            this.pageDetailedData = this.getDataFromDataSourcePopup(startindex);
        }
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.fetchNextPopupRange = function () {
        this.PageIndexPopup++;
        this.fetchTableDataByPagePopup(this.PageIndexPopup);
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.fetchPreviousPopup = function () {
        if (this.PageIndexPopup != 1) {
            this.PageIndexPopup--;
            this.fetchTableDataByPagePopup(this.PageIndexPopup);
        }
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.getDataFromDataSourcePopup = function (startindex) {
        if (this.isProfessional) {
            var d = this.dateWiseAttendancePro.slice(startindex, startindex + this.pagedisplaysizePopup);
            return d;
        }
        else {
            var d = this.dateWiseAttendance.slice(startindex, startindex + this.pagedisplaysizePopup);
            return d;
        }
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.sortedData = function (ev) {
        var _this = this;
        this.sortingEnabled = true;
        (this.direction == 0 || this.direction == -1) ? (this.direction = 1) : (this.direction = -1);
        if (this.isProfessional) {
            this.queryParamsPro = this.queryParamsPro.sort(function (a, b) {
                if (a[ev] < b[ev]) {
                    return -1 * _this.direction;
                }
                else if (a[ev] > b[ev]) {
                    return _this.direction;
                }
                else {
                    return 0;
                }
            });
        }
        else {
            this.postData = this.postData.sort(function (a, b) {
                if (a[ev] < b[ev]) {
                    return -1 * _this.direction;
                }
                else if (a[ev] > b[ev]) {
                    return _this.direction;
                }
                else {
                    return 0;
                }
            });
        }
        this.PageIndex = 1;
        this.fetchTableDataByPage(this.PageIndex);
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.getColor = function (status) {
        switch (status) {
            case 'A': return 'red';
            case 'L': return 'blue';
        }
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.DownloadJsonToCsv = function () {
        //console.log(this.attendanceTable.nativeElement.innerHtml);
        var link = this.xlsDownloader.nativeElement;
        var outer = this.attendanceTable.nativeElement.outerHTML.replace(/ /g, '%20');
        var data_type = 'data:application/vnd.ms-excel';
        var file_name = '';
        if (this.isProfessional) {
            for (var i = 0; i <= this.batchPro.length; i++) {
                if (this.queryParams.batch_id == this.batchPro[i].batch_id) {
                    file_name = this.batchPro[i].batch_name;
                    break;
                }
            }
            file_name = file_name + '(' + __WEBPACK_IMPORTED_MODULE_4_moment__(this.queryParams.from_date).format('DD-MMM-YYYY') + " to "
                + __WEBPACK_IMPORTED_MODULE_4_moment__(this.queryParams.to_date).format('DD-MMM-YYYY') + ')';
        }
        else {
            for (var i = 0; i <= this.batchCourses.length; i++) {
                if (this.attendanceFetchForm.batch_id == this.batchCourses[i].batch_id) {
                    file_name = this.batchCourses[i].batch_name;
                    break;
                }
            }
            file_name = file_name + '(' + __WEBPACK_IMPORTED_MODULE_4_moment__(this.attendanceFetchForm.from_date).format('DD-MMM-YYYY') + " to "
                + __WEBPACK_IMPORTED_MODULE_4_moment__(this.attendanceFetchForm.to_date).format('DD-MMM-YYYY') + ')';
        }
        link.setAttribute('href', data_type + ',' + outer);
        link.setAttribute('download', file_name + '.xls');
        link.click();
    };
    /* ================================================================================================================================ */
    /* ================================================================================================================================ */
    AttendanceReportComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            this.PageIndex = 1;
            var searchRes = void 0;
            if (!this.isProfessional) {
                searchRes = this.postData.filter(function (item) {
                    return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
                });
            }
            else {
                searchRes = this.queryParamsPro.filter(function (item) {
                    return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
                });
            }
            this.searchData = searchRes;
            this.totalRow = searchRes.length;
            this.searchflag = true;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchflag = false;
            this.fetchTableDataByPage(this.PageIndex);
            if (this.isProfessional) {
                this.totalRow = this.queryParamsPro.length;
            }
            else {
                this.totalRow = this.postData.length;
            }
        }
    };
    AttendanceReportComponent.prototype.futureDateValid = function (selectDate) {
        if (__WEBPACK_IMPORTED_MODULE_4_moment__(selectDate).diff(__WEBPACK_IMPORTED_MODULE_4_moment__()) > 0) {
            var msg = {
                type: "info",
                body: "You cannot select future date"
            };
            this.appc.popToast(msg);
            this.isRippleLoad = false;
            this.attendanceFetchForm.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__().format('YYYY-MM-DD');
            this.attendanceFetchForm.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__().format('YYYY-MM-DD');
            this.queryParams.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__().format('YYYY-MM-DD');
            this.queryParams.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__().format('YYYY-MM-DD');
        }
    };
    AttendanceReportComponent.prototype.clearFromDate = function () {
        this.attendanceFetchForm.from_date = "";
        this.queryParams.from_date = "";
    };
    AttendanceReportComponent.prototype.clearToDate = function () {
        this.attendanceFetchForm.to_date = "";
        this.queryParams.to_date = "";
    };
    AttendanceReportComponent.prototype.isShowDownloadReport = function () {
        this.showDownloadReport = false;
        if (this.isProfessional) {
            if ((this.queryParams.standard_id != '-1' && this.queryParams.subject_id != '-1') || (this.queryParams.batch_id != '-1')) {
                this.showDownloadReport = true;
            }
        }
        else {
            if ((this.attendanceFetchForm.master_course_name != '-1' && this.attendanceFetchForm.course_id != '-1') || (this.attendanceFetchForm.batch_id != '-1' && this.attendanceFetchForm.batch_id != "")) {
                this.showDownloadReport = true;
            }
        }
    };
    AttendanceReportComponent.prototype.downloadReport = function () {
        var _this = this;
        this.isRippleLoad = true;
        var obj;
        if (this.isProfessional) {
            obj = this.queryParams;
        }
        else {
            obj = this.attendanceFetchForm;
        }
        console.log(obj);
        var url = '/api/v1/reports/attendance/downloadAttendanceReport';
        this._httpService.postData(url, obj).subscribe(function (res) {
            _this.isRippleLoad = false;
            if (res) {
                var resp = res;
                if (resp.document != "") {
                    var byteArr = _this.commonService.convertBase64ToArray(resp.document);
                    var fileName = 'attenance_report.pdf'; //res.docTitle;
                    var file = new Blob([byteArr], { type: 'application/pdf;charset=utf-8;' });
                    var url_1 = URL.createObjectURL(file);
                    var dwldLink = document.getElementById('downloadFileClick');
                    dwldLink.setAttribute("href", url_1);
                    dwldLink.setAttribute("download", fileName);
                    document.body.appendChild(dwldLink);
                    dwldLink.click();
                }
                else {
                    _this.msgService.showErrorMessage('info', '', "Document does not have any data!");
                }
            }
            else {
                _this.msgService.showErrorMessage('info', '', "Document does not have any data!");
            }
        }, function (err) {
            _this.msgService.showErrorMessage('error', '', err.error.message);
            _this.isRippleLoad = false;
        });
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('attendanceTable'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], AttendanceReportComponent.prototype, "attendanceTable", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('xlsDownloader'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], AttendanceReportComponent.prototype, "xlsDownloader", void 0);
    AttendanceReportComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-attendance-report',
            template: __webpack_require__("./src/app/components/course-module/reports/attendance-report/attendanceReport.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/reports/attendance-report/attendanceReport.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_attendance_report_service_service__["a" /* AttendanceReportServiceService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_5__services_http_service__["a" /* HttpService */],
            __WEBPACK_IMPORTED_MODULE_6____["h" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_7__services_common_service__["a" /* CommonServiceFactory */]])
    ], AttendanceReportComponent);
    return AttendanceReportComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/biometric/biometric.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"clear-fix background\">\r\n  <aside class=\"middle-full\">\r\n    <section class=\"middle-main clearFix\">\r\n\r\n      <section class=\"middle-top mb0 clearFix sms-header\">\r\n        <h2 class=\"pull-left\">\r\n          <a routerLink=\"/view/course\">\r\n            Course\r\n          </a>\r\n          <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n          <a routerLink=\"/view/course/reports\">\r\n            Reports\r\n          </a>\r\n          <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i> Biometric Reports\r\n        </h2>\r\n        <div class=\"c-lg-2\" *ngIf=\"showButton\" style=\"float:right;\">\r\n          <button class=\"btn btn-sm fullBlue\" (click)=\"fetchAbsentiesReport()\">Send SMS to Absenties</button>\r\n        </div>\r\n        <aside class=\"pull-right\">\r\n        </aside>\r\n        <section class=\"filter-form \">\r\n\r\n          <div class=\"filterSectionWrapper\" style=\"padding-top: 1%;  padding-bottom: 2%;\">\r\n\r\n            <div class=\"row\" *ngIf=\"showNameFilter\" style=\"margin-left: 0;margin-right: 0;\">\r\n              <div class=\"c-lg-12\">\r\n                <div class=\"c-lg-10\">\r\n                  <div class=\"c-lg-12\">\r\n                    <div class=\"c-lg-4\">\r\n                      <div class=\"field-wrapper\" style=\"padding-left:none; margin-left:none\">\r\n                        <label>Role</label>\r\n                        <select class=\"form-ctrl\" [(ngModel)]=\"getData.user_Type\" (ngModelChange)=\"showMaster($event)\">\r\n                          <option selected [value]=\"1\">Students</option>\r\n                          <option [value]=\"3\">Teachers</option>\r\n                          <option [value]=\"0\">Custom</option>\r\n                          <option [value]=\"1000\">Others</option>\r\n                          <option [value]=\"100\">Admin</option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"c-lg-4 dateBox\">\r\n                      <div class=\"field-wrapper datePickerBox\">\r\n                        <label> Select Date</label>\r\n                        <input type=\"text\" class=\"form-ctrl bsDatepicker\" bsDatepicker [(ngModel)]=\"getData.biometric_attendance_date\" (ngModelChange)=\"dateValidationForFuture($event)\">\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"c-lg-4 field-wrapper\">\r\n                      <label> Name</label>\r\n                      <input type=\"text\" placeholder=\"Name\" class=\"form-ctrl\" (change)=\"courseEmpty()\" [(ngModel)]=\"getData.name\" [value]=\"getData.is_active_status\">\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"c-lg-1\">\r\n                  <button class=\"btn fullBlue\" (click)=\"fetchDataByName()\" style=\"margin-top: 27px;\">GO</button>\r\n                </div>\r\n                <div class=\"c-lg-1 form\" style=\"margin-top: 2%\" (click)=\"switchFilter()\" *ngIf=\"showCourseFilter\">\r\n                  <a *ngIf=\"!isProfessional\">Show Course Filter</a>\r\n                  <a *ngIf=\"isProfessional\">Show Batch Filter</a>\r\n                </div>\r\n              </div>\r\n\r\n\r\n            </div>\r\n\r\n            <div class=\"row\" *ngIf=\"masterCourseNames\" style=\"margin-right: 0;margin-right: 0;\">\r\n              <div class=\"c-lg-12\">\r\n                <div class=\"c-lg-3\" style=\"margin-left:15px;\" *ngIf=\"masterCourseNames  && !isProfessional\">\r\n                  <div class=\"field-wrapper\">\r\n                    <label>Master Course</label>\r\n                    <select class=\"form-ctrl\" [(ngModel)]=\"getData.master_course_name\" (ngModelChange)=\"getCourses($event)\">\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let i of masterCourse\" [value]=\"i.master_course\">\r\n                        {{i.master_course}}\r\n                      </option>\r\n                    </select>\r\n\r\n                  </div>\r\n                </div>\r\n                <div class=\"c-lg-3\" style=\"padding-left:5px;\" *ngIf=\"masterCourseNames  && !isProfessional\">\r\n                  <div class=\"field-wrapper\">\r\n                    <label> Course</label>\r\n                    <select class=\"form-ctrl\" (click)=\"courseChange()\" [(ngModel)]=\"getData.course_id\">\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let i of courses\" [value]=\"i.course_id\">\r\n                        {{i.course_name}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </div>\r\n                <div class=\"c-lg-3\" style=\"margin-left:15px;\" *ngIf=\"masterCourseNames && isProfessional\">\r\n                  <div class=\"field-wrapper\">\r\n                    <label>Master Course</label>\r\n                    <select class=\"form-ctrl\" [(ngModel)]=\"getData.standard_id\" (ngModelChange)=\"getCourses($event)\">\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let i of masterCoursePro\" [value]=\"i.standard_id\">\r\n                        {{i.standard_name}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </div>\r\n                <div class=\"c-lg-3\" style=\"padding-left:5px;\" *ngIf=\"masterCourseNames && isProfessional\">\r\n                  <div class=\"field-wrapper\">\r\n                    <label> Course</label>\r\n                    <select class=\"form-ctrl\" (click)=\"courseChange()\" [(ngModel)]=\"getData.subject_id\">\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let i of coursePro\" [value]=\"i.subject_id\">\r\n                        {{i.subject_name}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </div>\r\n                <div class=\"c-lg-3\" style=\"padding-left:5px;\" *ngIf=\"masterCourseNames && isProfessional\">\r\n                  <div class=\"field-wrapper\">\r\n                    <label>Batch</label>\r\n                    <select class=\"form-ctrl\" [(ngModel)]=\"getData.batch_id\">\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let i of batchPro\" [value]=\"i.batch_id\">\r\n                        {{i.batch_name}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </div>\r\n                <button class=\"btn fullBlue\" (click)=\"fetchDataByName()\" style=\"display: inline-block; margin-top: 2%;\" *ngIf=\"isProfessional\">GO</button>\r\n                <button class=\"btn fullBlue\" (click)=\"fetchDataByName()\" style=\"display: inline-block; margin-top: 2%;\" *ngIf=\"!isProfessional\">GO</button>\r\n                <a (click)=\"showNameWiseFilter()\" style=\"float: right;\r\n                margin-top: 2%;\r\n                margin-right: 1%; display: inline-block;\" class=\"form\">Show Name Filter\r\n                </a>\r\n\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"common-field\" *ngIf=\"showTeachersTable\">\r\n\r\n            <div class=\"table table-responsive student-table\">\r\n              <div class=\"filter-box\">\r\n                <div id=\"basic-search\">\r\n                  <input #search type=\"text\" class=\"search-field searchName\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\"\r\n                    (keyup)=\"searchDatabase()\" style=\"padding:7px 10px; width:200px; height:35px;\">\r\n                </div>\r\n              </div>\r\n              <div class=\"common-elements\">\r\n                <table>\r\n                  <thead>\r\n                    <tr>\r\n                      <th (click)=\"sortedData('teacher_id') \">\r\n                        Teacher id &nbsp;\r\n                        <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('teacher_id') && direction == 1\"></i>\r\n                        <i class=\"fa fa-caret-down caret\" *ngIf=\"getCaretVisiblity('teacher_id') && direction != 1\"></i>\r\n                      </th>\r\n                      <th (click)=\"sortedData('teacher_name') \">\r\n                        Teacher Name &nbsp;\r\n                        <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('teacher_name') && direction == 1\"></i>\r\n                        <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('teacher_name') && direction != 1\"></i>\r\n                      </th>\r\n                      <th (click)=\"sortedData('teacher_phone') \">\r\n                        Mobile &nbsp;\r\n                        <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('teacher_phone') && direction == 1\"></i>\r\n                        <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('teacher_phone') && direction != 1\"></i>\r\n                      </th>\r\n                      <th>\r\n                        Is active\r\n                      </th>\r\n                      <th>\r\n                        In time\r\n                      </th>\r\n                      <th>\r\n                        Out Time\r\n                      </th>\r\n                      <th>\r\n                        View Older Records\r\n                      </th>\r\n                    </tr>\r\n                  </thead>\r\n                  <tbody *ngIf=\"studentsDisplayData.length != 0 \">\r\n\r\n                    <tr *ngFor=\"let i of studentsDisplayData\">\r\n                      <td>\r\n                        {{i.teacher_id}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.teacher_name}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.teacher_phone}}\r\n                      </td>\r\n\r\n                      <td>\r\n\r\n                        {{i.is_active}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.in_time}}\r\n                      </td>\r\n                      <td>\r\n                        {{out_time}}\r\n                      </td>\r\n                      <td>\r\n                        <button class=\"btn fullBlue btnStudent\" (click)=\"viewOlderRecords(i)\">View</button>\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                  <tbody *ngIf=\"studentsDisplayData.length == 0 && dataStatus === true\">\r\n                    <tr *ngFor=\"let dummy of dummyArr\">\r\n                      <td *ngFor=\"let c of columnMaps\" style=\"padding:10px;\">\r\n                        <div class=\"skeleton\">\r\n                        </div>\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                  <tbody *ngIf=\"studentsDisplayData.length == 0 && dataStatus === false\" class=\"records\">\r\n                    <tr>\r\n                      <td colspan=\"7\" class=\"records\">\r\n                        No Records Found\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                </table>\r\n              </div>\r\n            </div>\r\n            <!-- Paginator Here -->\r\n            <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n              <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n                  [page]=\"PageIndex\" [perPage]=\"pagedisplaysize\" [count]=\"totalRow\">\r\n                </pagination>\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"students\" *ngIf=\"showStudentTable\">\r\n            <div class=\"table table-responsive student-table\">\r\n              <div class=\"filter-box\">\r\n                <div id=\"basic-search\">\r\n                  <input #search type=\"text\" class=\"search-field searchName\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\"\r\n                    (keyup)=\"searchDatabase()\">\r\n                </div>\r\n              </div>\r\n              <div class=\"student-elements\">\r\n                <table>\r\n                  <thead>\r\n                    <tr>\r\n                      <th (click)=\"sortedData('student_disp_id') \">\r\n\r\n                        Student Id &nbsp;\r\n                        <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('student_disp_id') && direction == 1\"></i>\r\n                        <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('student_disp_id') && direction != 1\"></i>\r\n                      </th>\r\n                      <th (click)=\"sortedData('student_name')\">\r\n\r\n                        Student Name &nbsp;\r\n                        <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('student_name') && direction == 1 \"></i>\r\n                        <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('student_name') && direction != 1 \"></i>\r\n                      </th>\r\n                      <th (click)=\"sortedData('student_phone')\">\r\n\r\n                        Mobile &nbsp;\r\n                        <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('student_phone') && direction == 1  \"></i>\r\n                        <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('student_phone') && direction != 1\"></i>\r\n                      </th>\r\n                      <th>\r\n                        Is active\r\n                      </th>\r\n                      <th>\r\n                        In time\r\n                      </th>\r\n                      <th>\r\n                        Out time\r\n                      </th>\r\n                      <th>\r\n                        View Older Records\r\n                      </th>\r\n                    </tr>\r\n                  </thead>\r\n                  <tbody *ngIf=\"studentsDisplayData.length != 0 \">\r\n\r\n                    <tr *ngFor=\"let i of studentsDisplayData\">\r\n                      <td>\r\n                        {{i.student_disp_id}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.student_name}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.student_phone}}\r\n                      </td>\r\n\r\n                      <td>\r\n                        {{i.is_active}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.in_time}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.out_time}}\r\n                      </td>\r\n                      <td>\r\n                        <button class=\"btn fullBlue btnStudent\" (click)=\"viewOlderRecords(i)\">View</button>\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                  <tbody *ngIf=\"studentsDisplayData.length == 0 && dataStatus === true\">\r\n                    <tr *ngFor=\"let dummy of dummyArr\">\r\n                      <td *ngFor=\"let c of columnMaps\" style=\"padding:10px;\">\r\n                        <div class=\"skeleton\">\r\n                        </div>\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                  <tbody *ngIf=\"studentsDisplayData.length == 0 && dataStatus === false\" class=\"records\">\r\n                    <tr>\r\n                      <td colspan=\"7\" class=\"records\">\r\n                        No Records Found\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                </table>\r\n              </div>\r\n            </div>\r\n            <!-- Paginator Here -->\r\n            <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n              <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n                  [page]=\"PageIndex\" [perPage]=\"pagedisplaysize\" [count]=\"totalRow\">\r\n                </pagination>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"common-field\" *ngIf=\"showCustomTable\">\r\n            <div class=\"table table-responsive student-table\">\r\n              <div class=\"filter-box box\">\r\n                <div id=\"basic-search\">\r\n                  <input #search type=\"text\" class=\"search-field searchName\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\"\r\n                    (keyup)=\"searchDatabase()\">\r\n                </div>\r\n              </div>\r\n              <div class=\"common-elements\">\r\n                <table>\r\n                  <thead>\r\n                    <tr>\r\n                      <th (click)=\"sortedData('userid') \">\r\n                        Id &nbsp;\r\n                        <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('userid') && direction == 1\"></i>\r\n                        <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('userid') && direction != 1\"></i>\r\n                      </th>\r\n                      <th (click)=\"sortedData('name') \">\r\n                        Name &nbsp;\r\n                        <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('name') && direction == 1\"></i>\r\n                        <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('name') && direction != 1\"></i>\r\n                      </th>\r\n                      <th (click)=\"sortedData('username') \">\r\n                        Contact No. &nbsp;\r\n                        <i class=\"fa fa-caret-up\" *ngIf=\"getCaretVisiblity('username') && direction == 1\"></i>\r\n                        <i class=\"fa fa-caret-down\" *ngIf=\"getCaretVisiblity('username') && direction != 1\"></i>\r\n                      </th>\r\n                      <th>\r\n                        Is active\r\n                      </th>\r\n                      <th>\r\n                        In time\r\n                      </th>\r\n                      <th>\r\n                        Out Time\r\n                      </th>\r\n                      <th>\r\n                        View Older Records\r\n                      </th>\r\n                    </tr>\r\n                  </thead>\r\n                  <tbody *ngIf=\"studentsDisplayData.length != 0 \">\r\n\r\n                    <tr *ngFor=\"let i of studentsDisplayData\">\r\n                      <td>\r\n                        {{i.userid}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.name}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.username}}\r\n                      </td>\r\n\r\n                      <td>\r\n                        {{i.is_active}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.in_time}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.out_time}}\r\n                      </td>\r\n                      <td>\r\n                        <button class=\"btn fullBlue btnStudent\" (click)=\"viewOlderRecords(i)\">View</button>\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                  <tbody *ngIf=\"studentsDisplayData.length == 0 && dataStatus == true\">\r\n                    <tr *ngFor=\"let dummy of dummyArr\">\r\n                      <td *ngFor=\"let c of columnMaps\" style=\"padding:10px;\">\r\n                        <div class=\"skeleton\">\r\n                        </div>\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                  <tbody *ngIf=\"studentsDisplayData.length == 0 && dataStatus == false\" class=\"records\">\r\n                    <tr>\r\n                      <td colspan=\"7\" class=\"records\">\r\n                        No Records Found\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                </table>\r\n              </div>\r\n            </div>\r\n            <!-- Paginator Here -->\r\n            <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n              <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n                  [page]=\"PageIndex\" [perPage]=\"pagedisplaysize\" [count]=\"totalRow\">\r\n                </pagination>\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n\r\n          <proctur-popup [sizeWidth]=\"'medium'\" *ngIf=\"addReportPopUp\">\r\n\r\n            <span class=\"closePopup pos-abs fbold show\" (click)=\"closeReportPopup()\" close-button>\r\n              <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n                <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n                  <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n                    <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n                    <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n                  </g>\r\n                  <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n                  />\r\n                </g>\r\n              </svg>\r\n            </span>\r\n\r\n            <div popup-header class=\"popup-header-content\">\r\n            </div>\r\n            <div popup-content class=\"main-student-table\">\r\n              <div class=\"row\" style=\" text-align: left;\">\r\n                <div class=\"c-lg-3\">\r\n                  <div class=\"form-field field-wrapper\">\r\n                    <label>Select Filter</label>\r\n                    <select class=\"form-ctrl\" [(ngModel)]=\"popupCtrl\" (ngModelChange)=\"getPopupEvent($event)\">\r\n                      <option [value]=\"0\">Previous Month</option>\r\n                      <option [value]=\"1\">Previous Week </option>\r\n                      <option [value]=\"2\">By Range</option>\r\n                    </select>\r\n                  </div>\r\n                </div>\r\n                <div class=\"c-lg-8 form-date\" *ngIf=\"showRangeValue\" style=\"width:60%; margin-left: -8%;\">\r\n                  <div class=\"c-lg-12\">\r\n                    <div class=\"c-lg-6 field-wrapper datePickerBox\">\r\n                      <label>From Date</label>\r\n                      <input class=\"form-ctrl\" bsDatepicker readonly=\"true\" [(ngModel)]=\"getAllData.from_date\">\r\n                    </div>\r\n                    <div class=\"c-lg-6 field-wrapper datePickerBox\">\r\n                      <label>To Date</label>\r\n                      <input class=\"form-ctrl\" bsDatepicker readonly=\"true\" [(ngModel)]=\"getAllData.to_date\">\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"c-lg-1\" style=\"margin-top: 29px;\r\n                margin-left: -38px;\">\r\n                  <button class=\"btn fullBlue\" style=\"margin-top:-3px;\" (click)=\"popupCtrlChange(popupCtrl)\">Go</button>\r\n                </div>\r\n              </div>\r\n              <div class=\"table table-responsive\" *ngIf=\"showTableEvent\" style=\"margin-top:2%\">\r\n                <span *ngIf=\"getData.user_Type == 1\">\r\n                  <span style=\"font-size: 17px; font-weight: bold;\"> {{studentName}} </span>\r\n                  <span style=\"font-size: 12px;\">#{{studentId}}</span>\r\n                </span>\r\n                <span *ngIf=\"getData.user_Type == 3\">\r\n                  <span style=\"font-size: 17px; font-weight: bold;\"> {{teacherName}} </span>\r\n                  <span style=\"font-size: 12px;\">#{{teacherId}}</span>\r\n                </span>\r\n                <span *ngIf=\"getData.user_Type == 0 || getData.user_Type == 1000 || getData.user_Type == 100\">\r\n                  <span style=\"font-size: 17px; font-weight: bold;\"> {{customName}} </span>\r\n                  <span style=\"font-size: 12px;\">#{{customId}}</span>\r\n                </span>\r\n                <div style=\"margin-left: 10px;display: inline-block; float: right;\">\r\n                  <a (click)=\"exportToExcel()\" class=\"form\">Download To Excel</a>\r\n                  <span class=\"fa fa-cloud-download\">\r\n                  </span>\r\n                </div>\r\n                <table>\r\n                  <thead>\r\n                    <tr>\r\n                      <th>\r\n                        Date\r\n                      </th>\r\n                      <th>\r\n                        In Time\r\n                      </th>\r\n                      <th>\r\n                        Out Time\r\n                      </th>\r\n                    </tr>\r\n                  </thead>\r\n                  <tbody *ngIf=\"range.length!=0\">\r\n                    <tr *ngFor=\"let i of range\">\r\n                      <td>\r\n                        {{i.attendance_date}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.in_time}}\r\n                      </td>\r\n                      <td>\r\n                        {{i.out_time}}\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                  <tbody *ngIf=\"range.length==0 && dataStatus == false\">\r\n                    <tr>\r\n                      <td colspan=\"3\">\r\n                        No Records Found\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                  <tbody *ngIf=\"range.length == 0 && dataStatus == true\">\r\n                    <tr *ngFor=\"let dummy of dummyArr\">\r\n                      <td *ngFor=\"let c of columnMapRecords\" style=\"padding:10px;\">\r\n                        <div class=\"skeleton\">\r\n                        </div>\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                </table>\r\n              </div>\r\n            </div>\r\n\r\n          </proctur-popup>\r\n\r\n        </section>\r\n      </section>\r\n    </section>\r\n  </aside>\r\n</div>\r\n\r\n<!-- Create absent student filter Pop Up -->\r\n<!-- =============================================================================== -->\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"absentStudentPopUp\">\r\n  <div class=\"popup pos-abs popup-body-container\" style=\"    max-width: 87%\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closeAbsentiesPopup()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n          <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n            <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n              <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n            </g>\r\n            <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n            />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div>\r\n        <div class=\"text-center\">\r\n          <h2>SMS To Absent Students</h2>\r\n        </div>\r\n\r\n        <div class=\"row\">\r\n\r\n          <div class=\"row extraMargin\">\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"master\">Master Course\r\n                </label>\r\n                <select class=\"form-ctrl\" [(ngModel)]=\"getAbsentiesData.master_course_name\" (change)=\"getCourses($event.target.value)\">\r\n                    <option value=\"-1\">Master Course</option>\r\n                  <option *ngFor=\"let i of masterCourse\" [value]=\"i.master_course\">\r\n                    {{i.master_course}}\r\n                  </option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"course\">Course\r\n                </label>\r\n                <select class=\"form-ctrl\" [(ngModel)]=\"getAbsentiesData.course_id\" (change)=\"getSubjects($event.target.value)\">\r\n                    <option value=\"-1\">Course</option>\r\n                  <option *ngFor=\"let i of courses\" [value]=\"i.course_id\">\r\n                    {{i.course_name}}\r\n                  </option>>\r\n                </select>\r\n\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"row extraMargin\">\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"course\">Subject\r\n                </label>\r\n                <select id=\"course\" class=\"form-ctrl\" [(ngModel)]=\"getAbsentiesData.subject_id\">\r\n                  <option value=\"-1\">Subject</option>\r\n                  <option *ngFor=\"let opt of subjects\" [value]=\"opt.subject_id\">\r\n                    {{opt.subject_name}}\r\n                  </option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6 c-xs-6\">\r\n              <div class=\"field-wrapper datePickerBox\">\r\n                <label>Date</label>\r\n                <input type=\"text\" class=\"form-ctrl bsDatepicker\" bsDatepicker [(ngModel)]=\"getAbsentiesData.from_date\" (change)=\"dateValidationForFuture($event)\">\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <br>\r\n          <div class=\"row text-center\">\r\n            <button id=\"btnSave\" class=\"btn fullBlue\" type=\"submit\" (click)=\"fetchAbsentsStudentsData()\"> View </button>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"table table-responsive\" style=\"height: 250px;\">\r\n          <table>\r\n            <thead>\r\n\r\n              <tr>\r\n                <th>Action</th>\r\n                <th>\r\n                  Student ID\r\n                </th>\r\n                <th>\r\n                  Student Name\r\n                </th>\r\n                <th>\r\n                  Joining Date\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody *ngIf=\"absendStudentData.length==0\">\r\n\r\n              <tr>\r\n                <td colspan=\"4\">\r\n                  No Records Found\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n            <tbody *ngIf=\"absendStudentData.length>0\">\r\n              <tr *ngFor=\"let obj of absendStudentData\">\r\n                <td class=\"checkBoxCss\">\r\n                  <div class=\"field-checkbox-wrapper\">\r\n                    <input type=\"checkbox\" class=\"form-checkbox\" [value]=\"obj.student_id\"  (change)=\"toggleCheckbox($event.target.value)\"\r\n                      [id]=\"'checkbox-'+i\">\r\n                    <label [for]=\"'checkbox-'+i\"></label>\r\n                  </div>\r\n                </td>\r\n                <td *ngFor=\"let key of displayKeys\" style=\"padding:10px;\">\r\n                  {{obj[key]}}\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n        <div class=\"row text-center\" *ngIf=\"absendStudentData.length>0\">\r\n            <button id=\"btnSave\" class=\"btn fullBlue\" type=\"submit\" (click)=\"sendSMSToAbsenties()\"> Send SMS </button>\r\n          </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>"

/***/ }),

/***/ "./src/app/components/course-module/reports/biometric/biometric.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.filter-form {\n  padding-top: 40px; }\np {\n  font-weight: 300; }\n.caret {\n  font-family: FontAwesome; }\n.excel {\n  font-family: FontAwesome; }\n.userDisplay {\n  font-weight: 100;\n  font-size: 19px;\n  color: blue; }\n.userIdDisplay {\n  font-weight: 80;\n  font-size: 13px;\n  color: blue; }\n.searchName {\n  height: 35px;\n  width: 200px;\n  padding: 7px 10px;\n  float: right;\n  margin-bottom: 5px;\n  margin-top: -30px; }\n.btnStudent {\n  margin: 5px; }\n.popup-content {\n  position: relative;\n  left: 5%; }\n.popup-content table {\n    overflow-y: auto;\n    width: 95%; }\n.popup-content h5 {\n    font-weight: 200px;\n    text-align: center; }\n.popup-content h2 {\n    text-align: center; }\n.main-student-table ::-webkit-scrollbar {\n  display: block; }\n.main-student-table .student-table {\n  overflow-x: auto;\n  height: 400px; }\n.main-student-table .tablePopup {\n  overflow: hidden;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  height: auto;\n  background: #EEEEF4; }\n.main-student-table .tablePopup .absentView {\n    overflow: auto;\n    position: relative;\n    top: 0px;\n    height: 330px;\n    margin: 10px;\n    padding-bottom: 10px; }\n.main-student-table .tablePopup .absentView .field-checkbox-wrapper {\n      width: 22px !important;\n      overflow: hidden;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      height: 22px !important;\n      padding-left: 17px !important;\n      margin-bottom: 0;\n      margin-left: 5px;\n      background: transparent;\n      border-radius: 2px;\n      margin-top: 5px;\n      margin-right: 5px;\n      border: 2px solid darkgray; }\n.main-student-table .tablePopup .absentView .field-checkbox-wrapper .form-checkbox {\n      opacity: 0;\n      position: absolute;\n      left: 0;\n      top: 0;\n      width: 22px;\n      height: 22px;\n      z-index: 1; }\n.btn {\n  display: inline-block; }\n.inner-main {\n  display: inline;\n  padding: 12px 0px; }\n.inner-main .inner-btn {\n    display: inline-block; }\n.inner-main .outer-btn {\n    float: right; }\n.form-date .field-wrapper {\n  position: relative; }\n.form-date .field-wrapper.datePickerBox .form-ctrl {\n    cursor: pointer;\n    position: relative;\n    z-index: 1;\n    background: transparent; }\n.form-date .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    right: 21px;\n    top: 31px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.form:hover {\n  cursor: pointer; }\n.change .field-wrapper {\n  position: relative; }\n.change .field-wrapper.datePickerBox .form-ctrl:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    right: 21px;\n    top: 31px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.dateBox .field-wrapper {\n  position: relative; }\n.dateBox .field-wrapper.datePickerBox .form-ctrl:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    right: 21px;\n    top: 32px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.main {\n  margin-top: -25px; }\n.main .form-wrapper {\n    position: relative; }\n.main .form-wrapper.datePickerBox .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent; }\n.main .form-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 0;\n      top: 27px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n.form-field {\n  display: inline-block;\n  width: 80%; }\n.form-date {\n  display: inline-block;\n  width: 40%; }\n.table-content {\n  height: 350px; }\n.table-content ::-webkit-scrollbar {\n    display: block; }\n.table-content .table-heading {\n    overflow-x: auto;\n    height: 350px; }\n.filter-box {\n  margin-bottom: 7px;\n  /* background: #efefef; */\n  margin-top: 40px; }\n.search-filter-wrapper .normal-field {\n  padding: 7px 10px;\n  width: 20%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin-right: 10px;\n  float: right;\n  height: 35px;\n  font-size: 14px; }\n.form-wrapper .datePickerBox {\n  padding-right: 10px;\n  padding-bottom: 10px;\n  width: 10%; }\n.records {\n  font-size: 20px;\n  font-weight: bold;\n  text-align: center; }\n.popup-header-content h2 {\n  text-align: center;\n  margin-top: 10px;\n  margin-bottom: 10px; }\n.popup-header-content h5 {\n  text-align: center;\n  margin-top: 10px;\n  margin-bottom: 10px; }\n.filterSectionWrapper {\n  background: white;\n  -webkit-box-shadow: 0px 0px 2px 2px #dadada;\n          box-shadow: 0px 0px 2px 2px #dadada;\n  border-radius: 10px;\n  margin-bottom: 10px; }\n.background {\n  background: #efefef;\n  height: 100%;\n  padding: 5px;\n  overflow: auto; }\n.background ::-webkit-scrollbar {\n    display: block; }\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.middle-section .middle-top h2 {\n    color: black;\n    font-weight: unset;\n    padding-top: 20px; }\n.form-wrapper {\n  background: transparent;\n  margin: 15px 0px;\n  -ms-flex-line-pack: center;\n      align-content: center; }\n.form-wrapper .btn {\n    margin-top: -15px;\n    width: 70%; }\n.form-wrapper label {\n    padding-left: 10px;\n    font-size: 12px;\n    font-weight: 400;\n    color: 0084f6;\n    text-decoration: none;\n    text-transform: uppercase;\n    -webkit-font-smoothing: antialiased;\n    width: 100%; }\n.form-wrapper .side-form-ctrl {\n    background: white;\n    border: 1px solid rgba(119, 119, 119, 0.419608);\n    width: 100%;\n    padding-left: 10px;\n    margin-left: 10px;\n    height: 30px;\n    padding: 0px 5px;\n    font-weight: 600;\n    font-size: 14px;\n    color: black; }\n.form-wrapper .side-form-ctrl.bsDatepicker {\n      padding-left: 10px;\n      margin-left: 10px;\n      width: 100%; }\n/*popup scss*/\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 100%;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff;\n  margin-left: 10%; }\n.popup-wrapper span {\n    font-weight: 300;\n    display: inline-block; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.prepare {\n  margin-top: -25px; }\n.prepare .form-wrapper {\n    position: relative; }\n.prepare .form-wrapper.datePickerBox .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent; }\n.prepare .form-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 0;\n      top: 20px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n.borderWithText :horizontal {\n  display: block; }\n.common-field {\n  margin-top: 0px;\n  height: 500px;\n  background-color: #efefef; }\n.common-field .student-table {\n    height: 450px;\n    overflow: hidden; }\n.common-field .student-table ::-webkit-scrollbar {\n      display: block; }\n.common-field .student-table table thead tr th {\n      padding: 13px 0px; }\n.common-field .student-table table tbody tr td {\n      padding: 0px 0px; }\n.common-field .student-table .common-elements {\n      position: relative;\n      top: 2%;\n      left: 10px;\n      bottom: 10%;\n      width: 99%;\n      height: 380px;\n      overflow-y: auto; }\n.students {\n  background-color: #efefef; }\n.students .student-table ::-webkit-scrollbar {\n    display: block; }\n.students .student-table table thead tr th {\n    padding: 13px 0px; }\n.students .student-table table tbody tr td {\n    padding: 0px 0px; }\n.students .student-table .common-elements {\n    height: 450px;\n    overflow-y: auto; }\n.students .student-table .student-elements {\n    position: relative;\n    top: 10%;\n    left: 0px;\n    bottom: 10%;\n    width: 100%;\n    overflow-y: auto; }\n.tablePopup table thead tr th {\n  padding: 13px 0px; }\n.records {\n  font-size: 20px;\n  font-weight: bold;\n  text-align: center; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n.popup-content ::-webkit-scrollbar {\n  display: block;\n  width: 7px;\n  height: 7px; }\n.skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 80%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n.skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n.form-wrapper {\n  position: relative; }\n.form-wrapper.datePickerBox .side-form-ctrl {\n    cursor: pointer;\n    position: relative;\n    z-index: 1;\n    background: transparent; }\n.form-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    right: 0;\n    top: 20px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.extraMargin {\n  margin-left: -3px !important;\n  margin-right: -3px !important; }\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/biometric/biometric.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BiometricComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_biometric_service_biometric_service_service__ = __webpack_require__("./src/app/services/biometric-service/biometric-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3____ = __webpack_require__("./src/app/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_excel_service__ = __webpack_require__("./src/app/services/excel.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var BiometricComponent = /** @class */ (function () {
    function BiometricComponent(reportService, appc, auth, excelService) {
        this.reportService = reportService;
        this.appc = appc;
        this.auth = auth;
        this.excelService = excelService;
        this.masterCourse = [];
        this.studentsData = [];
        this.monthAttendance = [];
        this.courses = [];
        this.othersData = [];
        this.weekAttendance = [];
        this.studentsDisplayData = [];
        this.range = [];
        this.masters = [];
        this.subjects = [];
        this.absentiesRecords = [];
        this.findName = [];
        this.masterCoursePro = [];
        this.batchPro = [];
        this.coursePro = [];
        this.nameOfPeople = [];
        this.absendStudentData = [];
        this.dummyArr = [0, 1, 2, 0, 1, 2];
        this.columnMaps = [0, 1, 2, 3, 4, 5, 6];
        this.columnMapRecords = [0, 1, 2];
        this.searchData = [];
        this.studentArray = [];
        //need for selected keys 
        this.displayKeys = ['student_id', 'student_name', 'doj'];
        this.master = "";
        this.students = "";
        this.popupCtrl = "";
        this.PageIndex = 1;
        this.pagedisplaysize = 10;
        this.direction = 0;
        this.searchText = "";
        this.sortedBy = "";
        this.studentName = "";
        this.teacherName = "";
        this.customName = "";
        this.studentId = "";
        this.teacherId = "";
        this.customId = "";
        this.masterCourseNames = false;
        this.isProfessional = true;
        this.addReportPopUp = false;
        this.addAcademicPopUp = false;
        this.isRippleLoad = true;
        this.showStudentTable = false;
        this.showTeachersTable = false;
        this.showCustomTable = false;
        this.showTable = false;
        this.showMonth = false;
        this.addAbsentiesPopup = false;
        this.showButton = true;
        this.showRange = false;
        this.showWeek = false;
        this.absentTable = false;
        this.dataStatus = false;
        this.showTeacherButton = true;
        this.searchflag = false;
        this.sortedenabled = true;
        this.showTableEvent = false;
        this.showRangeValue = false;
        this.showNameFilter = true;
        this.showCourseFilter = true;
        this.absentStudentPopUp = false;
        this.getData = {
            school_id: -1,
            name: "",
            is_active_status: 1,
            standard_id: -1,
            batch_id: -1,
            master_course_name: "",
            course_id: -1,
            subject_id: -1,
            user_Type: 1,
            biometric_attendance_date: __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD')
        };
        this.getAbsentiesData = {
            batch_id: -1,
            course_id: -1,
            from_date: __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD'),
            institution_id: this.reportService.institute_id,
            master_course_name: -1,
            standard_id: -1,
            subject_id: -1
        };
        this.getAllData = {
            from_date: "",
            institute_id: this.reportService.institute_id,
            to_date: "",
            user_id: ""
        };
    }
    BiometricComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.getMasterCourses();
    };
    BiometricComponent.prototype.fetchAbsentiesReport = function () {
        this.absentStudentPopUp = true;
    };
    BiometricComponent.prototype.toggleCheckbox = function (value) {
        console.log(value);
        var index = this.studentArray.indexOf(value);
        if (index == -1) {
            this.studentArray.push(value);
        }
        else {
            this.studentArray.splice(index, value);
        }
    };
    BiometricComponent.prototype.sendSMSToAbsenties = function () {
        var _this = this;
        if (confirm("Are u sure, you want to send sms to Absent students?")) {
            this.isRippleLoad = true;
            var obj = {
                "from_date": this.getAbsentiesData.from_date,
                "institution_id": sessionStorage.getItem('institute_id'),
                "studentArray": this.studentArray
            };
            this.reportService.sendSMSToAbsenties(obj).subscribe(function (data) {
                _this.isRippleLoad = false;
                if (data.statusCode == 200) {
                    var obj_1 = {
                        type: 'success',
                        title: '',
                        body: "SMS sent successfully !"
                    };
                    _this.appc.popToast(obj_1);
                }
            }, function (error) {
                _this.isRippleLoad = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
    };
    BiometricComponent.prototype.closeAbsentiesPopup = function () {
        this.absentStudentPopUp = false;
    };
    BiometricComponent.prototype.getMasterCourses = function () {
        var _this = this;
        this.getData.biometric_attendance_date = __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD');
        this.dataStatus = true;
        this.batchPro = [];
        this.masterCoursePro = [];
        if (this.isProfessional) {
            this.reportService.fetchMasterCourseProfessional(this.getData).subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.masterCoursePro = data.standardLi;
                _this.batchPro = data.batchLi;
            }, function (error) {
                _this.isRippleLoad = false;
                _this.dataStatus = false;
                return error;
            });
        }
        this.getMasterCourse();
    };
    BiometricComponent.prototype.getMasterCourse = function () {
        var _this = this;
        this.reportService.getAllData().subscribe(function (data) {
            _this.getData.master_course_name = "";
            _this.getData.course_id = -1;
            _this.masterCourse = data;
            _this.isRippleLoad = false;
        }, function (error) {
            _this.isRippleLoad = false;
            return error;
        });
    };
    BiometricComponent.prototype.switchFilter = function () {
        this.studentsData = [];
        this.getData.name = "";
        this.masterCourseNames = true;
        this.showNameFilter = false;
        this.totalRow = this.studentsData.length;
        this.PageIndex = 1;
        this.fetchTableDataByPage(this.PageIndex);
    };
    BiometricComponent.prototype.showNameWiseFilter = function () {
        this.studentsData = [];
        this.getData.standard_id = -1;
        this.getData.master_course_name = "";
        this.getData.course_id = -1;
        this.masterCourseNames = false;
        this.showNameFilter = true;
        this.totalRow = this.studentsData.length;
        this.PageIndex = 1;
        this.fetchTableDataByPage(this.PageIndex);
    };
    BiometricComponent.prototype.getCourses = function (i) {
        var _this = this;
        this.dataStatus = true;
        this.getData.name = "";
        this.getData.subject_id = -1;
        this.getAbsentiesData.course_id = -1;
        this.getAbsentiesData.subject_id = -1;
        // this.batchPro = [];
        this.coursePro = [];
        if (this.isProfessional) {
            this.reportService.fetchCourseProfessional(i).subscribe(function (data) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                _this.coursePro = data;
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                return error;
            });
        }
        else {
            this.reportService.getCourses(i).subscribe(function (data) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                _this.courses = data.coursesList;
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                return error;
            });
        }
    };
    BiometricComponent.prototype.getSubjects = function (i) {
        var _this = this;
        this.dataStatus = true;
        this.reportService.getSubjects(i).subscribe(function (data) {
            _this.dataStatus = false;
            _this.isRippleLoad = false;
            _this.subjects = data.batchesList;
        }, function (error) {
            _this.dataStatus = false;
            _this.isRippleLoad = false;
            return error;
        });
    };
    BiometricComponent.prototype.fetchDataByName = function () {
        var _this = this;
        this.showTeacherButton = true;
        if (this.getData.user_Type == 1) {
            this.studentsDisplayData = [];
            this.showTeacherButton = true;
            this.showStudentTable = true;
            this.showTeachersTable = false;
            this.showCustomTable = false;
            this.dataStatus = true;
            if (this.isProfessional) {
                this.reportService.getAttendanceReport(this.getData).subscribe(function (data) {
                    _this.isRippleLoad = false;
                    _this.dataStatus = false;
                    _this.studentsData = data;
                    _this.totalRow = data.length;
                    _this.PageIndex = 1;
                    _this.fetchTableDataByPage(_this.PageIndex);
                }, function (error) {
                    _this.dataStatus = false;
                    _this.isRippleLoad = false;
                    return error;
                });
            }
            else {
                this.reportService.getAttendanceReport(this.getData).subscribe(function (data) {
                    _this.isRippleLoad = false;
                    _this.dataStatus = false;
                    _this.studentsData = data;
                    _this.totalRow = data.length;
                    _this.PageIndex = 1;
                    _this.fetchTableDataByPage(_this.PageIndex);
                }, function (error) {
                    _this.dataStatus = false;
                    _this.isRippleLoad = false;
                    return error;
                });
            }
        }
        else if (this.getData.user_Type == 3) {
            this.dataStatus = true;
            this.showTeacherButton = true;
            this.showTeachersTable = true;
            this.showStudentTable = false;
            this.showCustomTable = false;
            this.reportService.getAttendanceReportTeachers(this.getData).subscribe(function (data) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                _this.studentsData = data;
                _this.totalRow = data.length;
                _this.PageIndex = 1;
                _this.fetchTableDataByPage(_this.PageIndex);
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                return error;
            });
        }
        else {
            this.showTeacherButton = true;
            this.showStudentTable = false;
            this.showTeachersTable = false;
            this.showCustomTable = true;
            this.reportService.getAttendanceReportOthers(this.getData).subscribe(function (data) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                _this.studentsData = data;
                _this.totalRow = data.length;
                _this.PageIndex = 1;
                _this.fetchTableDataByPage(_this.PageIndex);
            }, function (error) {
                _this.dataStatus = false;
                _this.isRippleLoad = false;
                return error;
            });
        }
    };
    BiometricComponent.prototype.viewOlderRecords = function (i) {
        var _this = this;
        this.studentName = i.student_name;
        this.teacherName = i.teacher_name;
        this.customName = i.name;
        this.studentId = i.student_disp_id;
        this.teacherId = i.teacher_id;
        this.customId = i.userid;
        console.log(this.teacherName);
        this.getAllData.user_id = i.user_id;
        this.addReportPopUp = true;
        this.dataStatus = true;
        this.reportService.getAllFinalReport(this.getAllData).subscribe(function (data) {
            _this.dataStatus = false;
            _this.isRippleLoad = false;
        }, function (error) {
            _this.dataStatus = false;
            _this.isRippleLoad = false;
            return error;
        });
    };
    BiometricComponent.prototype.showAttendanceReport = function () {
        this.showMonth = false;
        this.showWeek = false;
        this.showRange = false;
        this.addReportPopUp = true;
    };
    BiometricComponent.prototype.closeReportPopup = function () {
        this.addReportPopUp = false;
        this.range = [];
    };
    BiometricComponent.prototype.showMaster = function (i) {
        if (i == 1) {
            this.showCourseFilter = true;
            this.studentsData = [];
        }
        else {
            this.getData.standard_id = -1;
            this.getData.subject_id = -1;
            this.getData.batch_id = -1;
            this.showCourseFilter = false;
            this.studentsData = [];
        }
    };
    BiometricComponent.prototype.fetchAbsentsStudentsData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.getAbsentiesData.from_date = __WEBPACK_IMPORTED_MODULE_1_moment__(this.getAbsentiesData.from_date).format('YYYY-MM-DD');
        this.reportService.fetchAbsentiesData(this.getAbsentiesData).subscribe(function (data) {
            console.log(data);
            if (data != null) {
                _this.absendStudentData = data;
            }
            else {
                _this.absendStudentData = [];
            }
            _this.isRippleLoad = false;
        }, function (error) {
            _this.isRippleLoad = false;
            return error;
        });
    };
    BiometricComponent.prototype.futureDateValid = function (selectDate) {
        if (__WEBPACK_IMPORTED_MODULE_1_moment__(selectDate).diff(__WEBPACK_IMPORTED_MODULE_1_moment__()) > 0) {
            var msg = {
                type: "info",
                body: "You cannot select future date"
            };
            this.appc.popToast(msg);
            this.isRippleLoad = false;
            this.getData.biometric_attendance_date = __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD');
            this.getAllData.from_date = __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD');
        }
    };
    BiometricComponent.prototype.courseChange = function () {
        if ((this.getData.master_course_name == "" && !this.isProfessional) || (this.getData.standard_id == -1 && this.isProfessional)) {
            var msg = {
                type: "info",
                body: "Select Master Course First !"
            };
            this.appc.popToast(msg);
            this.isRippleLoad = false;
        }
    };
    BiometricComponent.prototype.courseEmpty = function () {
        if (this.getData.name != "") {
            this.getData.standard_id = -1;
            this.getData.batch_id = -1;
            this.getData.subject_id = -1;
        }
    };
    BiometricComponent.prototype.sortedData = function (ev) {
        var _this = this;
        this.sortedenabled = true;
        if (this.sortedenabled) {
            (this.direction == 0 || this.direction == -1) ? (this.direction = 1) : (this.direction = -1);
            this.sortedBy = ev;
            this.studentsData = this.studentsData.sort(function (a, b) {
                if (a[ev] < b[ev]) {
                    return -1 * _this.direction;
                }
                else if (a[ev] > b[ev]) {
                    return _this.direction;
                }
                else {
                    return 0;
                }
            });
            this.PageIndex = 1;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    BiometricComponent.prototype.getCaretVisiblity = function (e) {
        if (this.sortedenabled && this.sortedBy == e) {
            return true;
        }
        else {
            return false;
        }
    };
    BiometricComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            this.PageIndex = 1;
            var searchData = void 0;
            searchData = this.studentsData.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.searchData = searchData;
            this.totalRow = searchData.length;
            this.searchflag = true;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchflag = false;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    //pagination functions
    BiometricComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.pagedisplaysize * (index - 1);
        this.studentsDisplayData = this.getDataFromDataSource(startindex);
    };
    BiometricComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    BiometricComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    BiometricComponent.prototype.getDataFromDataSource = function (startindex) {
        if (this.searchflag) {
            var t = this.searchData.slice(startindex, startindex + this.pagedisplaysize);
            return t;
        }
        else {
            var d = this.studentsData.slice(startindex, startindex + this.pagedisplaysize);
            return d;
        }
    };
    BiometricComponent.prototype.dateValidationForFuture = function (e) {
        //console.log(e);
        var today = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date);
        var selected = __WEBPACK_IMPORTED_MODULE_1_moment__(e);
        var diff = __WEBPACK_IMPORTED_MODULE_1_moment__(selected.diff(today))['_i'];
        if (diff <= 0) {
        }
        else {
            this.getData.biometric_attendance_date = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date).format('YYYY-MM-DD');
            this.getAllData.to_date = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date).format('YYYY-MM-DD');
            this.getAllData.from_date = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date).format('YYYY-MM-DD');
            var msg = {
                type: "info",
                body: "Future date is not allowed"
            };
            this.isRippleLoad = false;
            this.dataStatus = false;
            this.appc.popToast(msg);
        }
    };
    // ====================================================================================================================
    BiometricComponent.prototype.getAllDataService = function (from_date, to_date) {
        var _this = this;
        this.range = [];
        this.dataStatus = true;
        this.showTableEvent = false;
        var diff = __WEBPACK_IMPORTED_MODULE_1_moment__(this.getAllData.from_date).diff(__WEBPACK_IMPORTED_MODULE_1_moment__(this.getAllData.to_date), 'months');
        if (this.getAllData.from_date == "" || this.getAllData.from_date == null || this.getAllData.to_date == "" || this.getAllData.to_date == null) {
            var msg = {
                type: "Info",
                body: "Please select date range"
            };
            this.appc.popToast(msg);
        }
        else if (diff < -2) {
            var msg = {
                type: "error",
                title: "Incorrect Details",
                body: "Range should not be more than 2 months"
            };
            this.appc.popToast(msg);
        }
        else {
            this.reportService.getAllFinalReport(this.getAllData).subscribe(function (data) {
                _this.showTableEvent = true;
                if (data != null) {
                    _this.range = data;
                    _this.dataStatus = false;
                }
                else {
                    _this.range = [];
                    _this.dataStatus = false;
                }
            }, function (error) {
                _this.dataStatus = false;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
    };
    BiometricComponent.prototype.popupCtrlChange = function (event) {
        if (event == 0) {
            this.getAllData.from_date = __WEBPACK_IMPORTED_MODULE_1_moment__().subtract('months', 1).format('YYYY-MM-DD');
            this.getAllData.to_date = __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD');
            this.getAllDataService(this.getAllData.from_date, this.getAllData.to_date);
            this.showRangeValue = false;
        }
        else if (event == 1) {
            this.getAllData.from_date = __WEBPACK_IMPORTED_MODULE_1_moment__().subtract('days', 7).format('YYYY-MM-DD');
            this.getAllData.to_date = __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD');
            this.getAllDataService(this.getAllData.from_date, this.getAllData.to_date);
            this.showRangeValue = false;
        }
        else if (event == 2) {
            this.getAllDataService(this.getAllData.from_date, this.getAllData.to_date);
        }
    };
    BiometricComponent.prototype.getPopupEvent = function (event) {
        if (event == 2) {
            this.showRangeValue = true;
        }
        else {
            this.showRangeValue = false;
        }
    };
    BiometricComponent.prototype.exportToExcel = function (event) {
        var arr = [];
        this.range.map(function (ele) {
            var json = {
                "Date": ele.attendance_date,
                "In Time": ele.in_time,
                "Out Time": ele.out_time
            };
            arr.push(json);
        });
        this.excelService.exportAsExcelFile(arr, 'biometric');
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('biometricTable'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], BiometricComponent.prototype, "biometricTable", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('xlsDownloader'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], BiometricComponent.prototype, "xlsDownloader", void 0);
    BiometricComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-biometric',
            template: __webpack_require__("./src/app/components/course-module/reports/biometric/biometric.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/reports/biometric/biometric.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_biometric_service_biometric_service_service__["a" /* BiometricServiceService */],
            __WEBPACK_IMPORTED_MODULE_3____["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_3____["b" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__services_excel_service__["a" /* ExcelService */]])
    ], BiometricComponent);
    return BiometricComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/exam-report-main/exam-report.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"middle-section clear-fix\">\r\n    <aside class=\"middle-full\">\r\n        <section class=\"middle-main clearFix attendance-container\">\r\n            <section class=\"middle-top mb0 clearFix sms-header\">\r\n                <h2 class=\"pull-left\" style=\"font-weight: bold;\">\r\n                        <a routerLink=\"/view/course\" *ngIf=\"!isProfessional\">\r\n                            Course\r\n                          </a>\r\n                          <a routerLink=\"/view/batch\" *ngIf=\"isProfessional\">\r\n                            Batch\r\n                          </a>\r\n                <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n                    <a routerLink=\"/view/course/reports\" style=\"padding:0px; \">\r\n                        Report\r\n                        <!-- <i style=\"font-family: 'FontAwesome';font-size: 24px; cursor: pointer;\" class=\"fas fa-home\"></i> -->\r\n                    </a>\r\n                    <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n                    Exam Report\r\n                </h2>\r\n                <aside class=\"pull-right\">\r\n                </aside>\r\n            </section>\r\n            <section class=\"filter-form\">\r\n                <div class=\"row\">\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3 field-wrapper\" *ngIf=\"!isProfessional\">\r\n                        <label>Master Course</label>\r\n                        <select class=\"form-ctrl\" id=\"one\" [(ngModel)]=\"fetchFieldData.standard_id\" (ngModelChange)=\"getCourseData($event)\" name=\"masterCourse\">\r\n                            <option></option>\r\n                            <option *ngFor=\"let i of masterCourses\" [value]=\"i.master_course\">{{i.master_course}}</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3 field-wrapper\" *ngIf=\"isProfessional\">\r\n                        <label>Master Course</label>\r\n                        <select class=\"form-ctrl\" id=\"one\" [(ngModel)]=\"queryParam.standard_id\" (ngModelChange)=\"getCourseData($event)\" name=\"masterCourse\">\r\n                            <option value=\"-1\"></option>\r\n                            <option *ngFor=\"let i of batchExamRepo\" [value]=\"i.standard_id\">{{i.standard_name}}</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3 field-wrapper\" *ngIf=\"!isProfessional\">\r\n                        <label> Course</label>\r\n                        <select class=\"form-ctrl\" id=\"two\" [(ngModel)]=\"fetchFieldData.subject_id\" (ngModelChange)=\"getSubData($event)\">\r\n                            <option></option>\r\n                            <option *ngFor=\"let i of courseData\" [value]=\"i.course_id\" name=\"Course\">{{i.course_name}}</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3 field-wrapper\" *ngIf=\"isProfessional\">\r\n                        <label> Course</label>\r\n                        <select class=\"form-ctrl\" id=\"two\" [(ngModel)]=\"queryParam.subject_id\">\r\n                            <option value=\"-1\"></option>\r\n                            <option *ngFor=\"let i of batchCourseData\" [value]=\"i.subject_id\" name=\"Course\">{{i.subject_name}}</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3 field-wrapper\" *ngIf=\"!isProfessional\">\r\n                        <label>Subject</label>\r\n                        <select class=\"form-ctrl\" id=\"three\" [(ngModel)]=\"fetchFieldData.batch_id\" (ngModelChange)=\"getExamScheduleData($event)\">\r\n                            <option></option>\r\n                            <option *ngFor=\"let i of subjectData\" [value]=\"i.batch_id\" name=\"Subject\">{{i.subject_name}}</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3  field-wrapper\" *ngIf=\"isProfessional\">\r\n                        <label>Batch</label>\r\n                        <select class=\"form-ctrl\" id=\"three\" [(ngModel)]=\" fetchFieldData.batch_id\" (ngModelChange)=\"getExamScheduleData($event)\">\r\n                            <option></option>\r\n                            <option *ngFor=\"let i of getSubjectData\" [value]=\"i.batch_id\" name=\"Subject\">{{i.batch_name}}</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3 field-wrapper\">\r\n                        <label>Exam Schedule</label>\r\n                        <select class=\"form-ctrl\" id=\"four\" [(ngModel)]=\"fetchFieldData.exam_schd_id\">\r\n                            <option></option>\r\n                            <option *ngFor=\"let i of exam_Sch_Data\" [value]=\"i.schd_id\" name=\"Exam Schedule\">{{i.exam_date}}({{i.start_time}}-{{i.end_time}})</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"master\" *ngIf=\"!isProfessional\">\r\n                        <input type=\"button\" class=\"normal-btn fullBlue btn\" value=\"View\" (click)=\"fetchExamReport()\" />\r\n                        <input type=\"button\" class=\"normal-btn fullBlue btn\" value=\"DetailReport\" (click)=\"fetchDetailReport()\" />\r\n                    </div>\r\n\r\n                    <div class=\"master\" *ngIf=\"isProfessional\">\r\n                        <input type=\"button\" class=\"normal-btn fullBlue btn\" value=\"View\" (click)=\"fetchExamReport()\" />\r\n                        <input type=\"button\" class=\"normal-btn fullBlue btn\" value=\"DetailReport\" (click)=\"fetchDetailReport()\" />\r\n                    </div>\r\n\r\n                </div>\r\n            </section>\r\n            <div class=\"table table-responsive student-table stdnt-table table-overflow\" *ngIf=\"!isProfessional && Tdata\">\r\n                <div class=\"search-filter-wrapper\" id=\"adFilterExitVisible\">\r\n                    <input #search type=\"text\" class=\"normal-field\" [(ngModel)]=\"searchText\" style=\"font-size:12px\" placeholder=\"Search\" (keyup)=\"searchDatabase()\">\r\n                </div>\r\n\r\n                <div class=\"poor\">\r\n\r\n                    <proctur-table [records]=\"pagedExamSource | filter:pagedExamSource.student_name :pagedExamSource.student_id:pagedExamSource.student_phone:pagedExamSource.doj\"\r\n                        [tableName]=\"'Exam'\" [settings]=\"projectSettings\" (sortData)=\"sortedData($event)\" [direction]=\"direction\"\r\n                        [sortingEnabled]=\"sortingEnabled\" [loaderState]=\"isRippleLoad\">\r\n                    </proctur-table>\r\n                </div>\r\n                <div class=\"row filter-res pagination\" style=\"width: 100%;\" *ngIf=\"!isProfessional\">\r\n                    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                        <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n                            [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRecords\">\r\n                        </pagination>\r\n                    </div>\r\n                </div>\r\n                <ul style=\"list-style-type:none; text-align:center; font-weight:bold;\" *ngIf=\"!isProfessional && examSource.length !=0 && examSource[0].grade==''\">\r\n                    <li>\r\n                        Highest Marks : {{HighestMarks}}\r\n                    </li>\r\n                    <li>\r\n                        Lowest Marks : {{LowestMarks}}\r\n                    </li>\r\n                    <li>\r\n                        Average Marks : {{AverageMarks}}\r\n                    </li>\r\n                </ul>\r\n            </div>\r\n\r\n\r\n            <div class=\"table table-responsive student-table stdnt-table \" *ngIf=\"isProfessional && Tdata\">\r\n                <div class=\"search-filter-wrapper\" id=\"adFilterExitVisible\">\r\n                    <input #search type=\"text\" class=\"normal-field\" [(ngModel)]=\"searchText\" style=\"font-size:12px\" placeholder=\"Search\" (keyup)=\"searchDatabase()\">\r\n                </div>\r\n\r\n                <div class=\"poor\">\r\n                    <proctur-table [records]=\"pagedExamSource | filter:pagedExamSource.student_name:pagedExamSource.student_id:pagedExamSource.student_phone:pagedExamSource.doj\"\r\n                        [tableName]=\"'Exam'\" [settings]=\"projectSettings\" [text]=\"examDesc\" [viewText]=\"showTitle\" (sortData)=\"sortedData($event)\"\r\n                        [direction]=\"direction\" [sortingEnabled]=\"sortingEnabled\"[loaderState]=\"isRippleLoad\">\r\n                    </proctur-table>\r\n                </div>\r\n\r\n                <div class=\"row filter-res pagination\" style=\"width: 100%;\" *ngIf=\"isProfessional\">\r\n                    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                        <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n                            [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRecords\">\r\n                        </pagination>\r\n                    </div>\r\n                </div>\r\n\r\n                <ul style=\"list-style-type:none; text-align:center; font-weight:bold;\" *ngIf=\" isProfessional && examSource.length !=0 && examSource[0].grade==''\">\r\n                    <li>\r\n                        Highest Marks : {{HighestMarks}}\r\n                    </li>\r\n                    <li>\r\n                        Lowest Marks : {{LowestMarks}}\r\n                    </li>\r\n                    <li>\r\n                        Average Marks : {{AverageMarks}}\r\n                    </li>\r\n                </ul>\r\n\r\n            </div>\r\n\r\n        </section>\r\n\r\n    </aside>\r\n</div>\r\n\r\n<proctur-popup [sizeWidth]=\"'large'\" *ngIf=\"addReportPopup\">\r\n    <span class=\"closePopup pos-abs fbold show\" (click)=\"closeReportPopup()\" close-button>\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n            <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n                <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n                    <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n                    <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n                </g>\r\n                <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n                />\r\n            </g>\r\n        </svg>\r\n    </span>\r\n\r\n    <h2 popup-header>DateWise Exam Report ({{selectedSubject}})</h2>\r\n    <div class=\"stu-table\" popup-content>\r\n\r\n        <div *ngIf=\"!isProfessional\" style=\"height:402px;\">\r\n            <i class=\"fa fa-file-excel-o\" (click)=\" downloadJsonToCSV()\" style=\"color:blue; height:39px; float:right; font-size:31px\"></i>\r\n            <a class=\"hide\" #xlsDownloader></a>\r\n\r\n            <div class=\"table table-responsive student-table made\" style=\"overflow:Hidden\">\r\n                <table #examTable>\r\n                    <thead>\r\n                        <tr>\r\n                            <th style=\"text-align:right;\">\r\n                                Student Id\r\n                            </th>\r\n                            <th style=\"text-align:left;\">\r\n                                Student Name\r\n                            </th>\r\n                            <th class=\"marks\" *ngFor=\"let date of dateStore\">\r\n                                {{date.exam_date}}\r\n                                <br>\r\n                                <span style=\"font-size:12px;\">{{date.start_time}}</span>\r\n                            </th>\r\n\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                        <tr *ngFor='let det of detailSource'>\r\n                            <td style=\"text-align:right;\">{{det.student_display_id}}</td>\r\n                            <td style=\"text-align:left;\">{{det.student_name}}</td>\r\n\r\n                            <td class=\"marks\" *ngFor=\"let marks of det.detailExamReportList\" [style.color]=\"getColor(marks.student_marks_obtained)\">\r\n                                <!-- <label *ngIf=\"marks.grade == 'Leave'||(marks.grade=='Absent' && marks.isBatchExamGrade == 1)\">{{marks.grade | uppercase}}</label> -->\r\n                                <!-- <label *ngIf=\"marks.grade != 'Leave'&& marks.grade!='Absent' && marks.isBatchExamGrade == 1\">{{marks.grade | uppercase}}</label>\r\n                                <label *ngIf=\"marks.grade != 'Leave'&& marks.grade!='Absent' && marks.isBatchExamGrade == 0\">{{getMark(marks.student_marks_obtained)}}\r\n                                    <span *ngIf=\"marks.student_marks_obtained!=null\">/&nbsp;{{marks.total_marks}}</span>\r\n                                </label> -->\r\n                                <label *ngIf=\"marks.isBatchExamGrade == 1\">{{marks.grade | uppercase}}</label>\r\n                                <label *ngIf=\"marks.isBatchExamGrade == 0\">{{getMark(marks.student_marks_obtained)}}\r\n                                    <label *ngIf=\"marks.student_marks_obtained!=null && marks.student_marks_obtained!='Absent' &&marks.student_marks_obtained!='Leave' && marks.student_marks_obtained!=0\">\r\n                                        <span *ngIf=\"marks.student_marks_obtained!=null\">/&nbsp;{{marks.total_marks}}</span>\r\n                                    </label>\r\n                                </label>\r\n                            </td>\r\n\r\n                        </tr>\r\n                        <tr *ngIf='detailSource.length==0'>No Students Founds</tr>\r\n                    </tbody>\r\n\r\n                </table>\r\n                <!--   <div class=\"row filter-res pagination\" style=\"width: 100%;\" *ngIf=\"!isProfessional\">\r\n                    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                        <pagination (goPage)=\"fetchTableDataByPagePopup($event)\" (goNext)=\"fetchNextPopup()\" (goPrev)=\"fetchPreviousPopup()\" [pagesToShow]=\"10\"\r\n                            [page]=\"pageIndexPopup\" [perPage]=\"displayBatchSize\" [count]=\"totalRecords\">\r\n                        </pagination>\r\n                    </div>\r\n                </div>-->\r\n            </div>\r\n        </div>\r\n\r\n        <div *ngIf=\"isProfessional\">\r\n            <i class=\"fa fa-file-excel-o\" (click)=\" downloadJsonToCSV()\" style=\"color:blue; height:39px; float:right; font-size:31px\"></i>\r\n\r\n            <a class=\"hide\" #xlsDownloader></a>\r\n            <div class=\"table table-responsive student-table stu-table made\">\r\n                <table #examTable>\r\n                    <thead>\r\n                        <tr>\r\n                            <th style=\"text-align:right;\">\r\n                                Student Id\r\n                            </th>\r\n                            <th style=\"text-align:left;\">\r\n                                Student Name\r\n                            </th>\r\n                            <th class=\"marks\" *ngFor=\"let date of dateStore\">\r\n                                {{date.exam_date}}\r\n                                <br>\r\n                                <span style=\"font-size:12px;\">{{date.start_time}}</span>\r\n                            </th>\r\n\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                        <tr *ngFor='let det of detailSource'>\r\n\r\n                            <td style=\"text-align:right;\">{{det.student_display_id}}</td>\r\n                            <td style=\"text-align:left;\">{{det.student_name}}</td>\r\n\r\n                            <td class=\"marks\" *ngFor=\"let marks of det.detailExamReportList\" [style.color]=\"getColor(marks.student_marks_obtained)\">\r\n                                <!-- <label *ngIf=\"marks.grade == 'Leave'||marks.grade=='Absent' || isExamGrade == '1'\">{{marks.grade | uppercase}}</label>\r\n                                <label *ngIf=\"marks.grade == 'Leave'||marks.grade=='Absent' || isExamGrade == '1'\">{{marks.grade | uppercase}}</label>\r\n                                <label *ngIf=\"marks.grade != 'Leave' && marks.grade!='Absent' \">{{marks.grade | uppercase}}</label>\r\n                                <label *ngIf=\"marks.grade == '' || isExamGrade == '0'\">{{marks.student_marks_obtained}}</label> -->\r\n                                <label *ngIf=\"marks.isBatchExamGrade == 1\">{{marks.grade | uppercase}}</label>\r\n                                <label *ngIf=\"marks.isBatchExamGrade == 0\">{{getMark(marks.student_marks_obtained)}}\r\n                                    <label *ngIf=\"marks.student_marks_obtained!=null && marks.student_marks_obtained!='Absent' &&marks.student_marks_obtained!='Leave' && marks.student_marks_obtained!=0\">\r\n                                        <span *ngIf=\"marks.student_marks_obtained!=null\">/&nbsp;{{marks.total_marks}}</span>\r\n                                    </label>\r\n                                </label>\r\n\r\n                            </td>\r\n\r\n                        </tr>\r\n                        <tr *ngIf='detailSource.length==0'>No Students Founds</tr>\r\n                    </tbody>\r\n                </table>\r\n                <!--  <div class=\"row filter-res pagination\" style=\"width: 100%;\" *ngIf=\"isProfessional\">\r\n                    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                        <pagination (goPage)=\"fetchTableDataByPagePopup($event)\" (goNext)=\"fetchNextPopup()\" (goPrev)=\"fetchPreviousPopup()\" [pagesToShow]=\"10\"\r\n                            [page]=\"pageIndexPopup\" [perPage]=\"displayBatchSize\" [count]=\"totalRecords\">\r\n                        </pagination>\r\n                    </div>\r\n                </div>-->\r\n            </div>\r\n        </div>\r\n\r\n    </div>\r\n\r\n    <div class=\"\" popup-footer>\r\n        <div class=\"clearfix\">\r\n            <aside class=\"pull-right popup-btn\">\r\n                <input type=\"button\" value=\"Close\" class=\"btn\" style=\"margin-right:10px;margin-top:0px\" (click)=\"closeReportPopup()\">\r\n            </aside>\r\n        </div>\r\n    </div>\r\n\r\n</proctur-popup>"

/***/ }),

/***/ "./src/app/components/course-module/reports/exam-report-main/exam-report.component.scss":
/***/ (function(module, exports) {

module.exports = "body {\n  background: #EEEEF4;\n  color: #999; }\n\nh1 {\n  font-weight: 100;\n  font-size: 27pt;\n  color: #E43; }\n\np {\n  font-weight: 300; }\n\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n\n.middle-section .middle-top h2 {\n    color: black;\n    font-weight: unset;\n    padding-top: 20px; }\n\n.middle-section .form-wrapper {\n    background: transparent;\n    margin: 25px 0px; }\n\n.middle-section .form-wrapper .btn {\n      margin-top: 10px;\n      width: 30%; }\n\n.middle-section .form-wrapper label {\n      padding-left: 25px;\n      font-size: 12px;\n      font-weight: 400;\n      color: 0084f6;\n      text-decoration: none;\n      text-transform: uppercase;\n      -webkit-font-smoothing: antialiased;\n      width: 100%; }\n\n.middle-section .form-wrapper .side-form-ctrl {\n      background: white;\n      border: 1px solid rgba(119, 119, 119, 0.419608);\n      width: 85%;\n      padding-left: 10px;\n      margin-left: 10px;\n      height: 30px;\n      padding: 0px 5px;\n      font-weight: 600;\n      font-size: 14px;\n      color: black; }\n\n.middle-section .form-wrapper .side-form-ctrl.bsDatepicker {\n        padding-left: 10px;\n        margin-left: 25px;\n        width: 60%; }\n\n.master {\n  margin-top: 10px;\n  float: right;\n  margin-bottom: 10px;\n  margin-right: 16px; }\n\n.attendance-container {\n  background: #efefef;\n  padding: 5px;\n  overflow: auto; }\n\n.filter-form {\n  background: #fff;\n  -webkit-box-shadow: 0px 0px 2px 2px #dadada;\n          box-shadow: 0px 0px 2px 2px #dadada;\n  border-radius: 10px;\n  /*popup scss*/ }\n\n.filter-form .row {\n    margin: 5px 15px; }\n\n.filter-form .form-wrapper {\n    position: relative; }\n\n.filter-form .form-wrapper.datePickerBox .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent; }\n\n.filter-form .form-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 0;\n      top: 20px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n\n.filter-form .form-wrapper {\n    padding: 10px 5px; }\n\n.filter-form .form-wrapper label {\n      width: 100%;\n      display: block; }\n\n.filter-form .form-wrapper .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent;\n      width: 100%;\n      padding: 3px;\n      display: block;\n      border: 1px solid #dadada; }\n\n.filter-form .form-wrapper {\n    padding: 10px 5px;\n    position: relative; }\n\n.filter-form .form-wrapper.datePickerBox .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent;\n      width: 100%;\n      padding: 5px;\n      display: block;\n      border: 1px solid #dadada; }\n\n.filter-form .form-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 10px;\n      top: 30px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n\n.filter-form .popup-content {\n    position: relative;\n    left: 5%;\n    overflow-x: hidden; }\n\n.filter-form .popup-content table {\n      overflow-y: auto;\n      overflow-x: auto;\n      width: 95%; }\n\n.filter-form .popup-content h5 {\n      font-weight: 200px;\n      text-align: center; }\n\n.filter-form .popup-content h2 {\n      text-align: center; }\n\n.filter-form .main-student-table ::-webkit-scrollbar {\n    display: block; }\n\n.filter-form .main-student-table .student-table {\n    overflow-x: auto;\n    height: 400px; }\n\n.filter-form .btn {\n    display: inline-block; }\n\n.filter-form .inner-main {\n    display: inline;\n    padding: 20px 0px 12px 0px; }\n\n.filter-form .inner-main .inner-btn {\n      display: inline-block; }\n\n.filter-form .inner-main .outer-btn {\n      display: inline-block; }\n\n.filter-form .records {\n    font-size: 20px;\n    font-weight: bold;\n    text-align: center; }\n\n.filter-form .form-field {\n    display: inline-block;\n    width: 80%; }\n\n.filter-form .form-date {\n    display: inline-block;\n    width: 100%; }\n\n.filter-form .table-content {\n    height: 350px; }\n\n.filter-form .table-content ::-webkit-scrollbar {\n      display: block; }\n\n.filter-form .table-content .table-heading {\n      overflow-x: auto;\n      height: 350px; }\n\n.filter-form .filter-box {\n    padding: 10px 0px;\n    margin-bottom: 5px;\n    background: #efefef; }\n\n.filter-form .form-wrapper .datePickerBox {\n    padding-right: 10px;\n    padding-bottom: 10px;\n    width: 10%; }\n\n.filter-form .popup-header-content h2 {\n    text-align: center;\n    margin-top: 10px;\n    margin-bottom: 10px; }\n\n.filter-form .popup-header-content h5 {\n    text-align: center;\n    margin-top: 10px;\n    margin-bottom: 10px; }\n\n.filter-form .middle-section {\n    padding: 5px 15px;\n    width: 100%;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box; }\n\n.filter-form .middle-section .middle-top h2 {\n      color: black;\n      font-weight: unset;\n      padding-top: 20px; }\n\n.filter-form .middle-section .form-wrapper {\n      background: transparent;\n      margin: 25px 0px;\n      -ms-flex-line-pack: center;\n          align-content: center; }\n\n.filter-form .middle-section .form-wrapper .btn {\n        margin-top: -3px;\n        width: 70%; }\n\n.filter-form .middle-section .form-wrapper label {\n        padding-left: 10px;\n        font-size: 12px;\n        font-weight: 400;\n        color: 0084f6;\n        text-decoration: none;\n        text-transform: uppercase;\n        -webkit-font-smoothing: antialiased;\n        width: 100%; }\n\n.filter-form .middle-section .form-wrapper .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        padding-left: 10px;\n        margin-left: 10px;\n        height: 30px;\n        padding: 0px 5px;\n        font-weight: 600;\n        font-size: 14px;\n        color: black; }\n\n.filter-form .middle-section .form-wrapper .side-form-ctrl.bsDatepicker {\n          padding-left: 10px;\n          margin-left: 10px;\n          width: 100%; }\n\n.filter-form .popupWrapper {\n    position: fixed;\n    width: 100%;\n    height: 100%;\n    bottom: 0;\n    top: 0px;\n    right: 0;\n    left: 0px;\n    background: rgba(230, 230, 230, 0.5);\n    z-index: 100;\n    visibility: hidden;\n    opacity: 0;\n    -webkit-transition: all 0.5s ease-in;\n    transition: all 0.5s ease-in; }\n\n.filter-form .popupWrapper .popup {\n      max-width: 100%;\n      width: 100%;\n      height: auto;\n      left: 0;\n      right: 0;\n      top: 5%;\n      bottom: 0;\n      margin: auto; }\n\n.filter-form .popup-wrapper {\n    padding: 32px 15px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n            box-shadow: 1px 8px 20px 5px #9c9c9c;\n    -webkit-transition: unset;\n    transition: unset;\n    background: #fff; }\n\n.filter-form .popup-wrapper span {\n      font-weight: 300;\n      display: inline-block; }\n\n.filter-form .popup-wrapper h2 {\n      margin-bottom: 15px;\n      font-size: 22px; }\n\n.filter-form .popup-wrapper h4 {\n      margin: 25px 0 15px;\n      font-weight: 600; }\n\n.filter-form .closePopup {\n    right: 10px;\n    top: 10px;\n    font-size: 18px;\n    cursor: pointer;\n    line-height: 20px;\n    width: 26px;\n    height: 26px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    text-align: center;\n    padding-top: 3px;\n    display: none; }\n\n.filter-form .closePopup.bottomRight {\n      bottom: 2px;\n      top: auto;\n      left: auto;\n      right: 0; }\n\n.filter-form .closePopup.topLeft {\n      left: 0;\n      right: auto;\n      top: 1px;\n      bottom: auto; }\n\n.filter-form .closePopup.bottomLeft {\n      left: 0;\n      right: auto;\n      bottom: 2px;\n      top: auto; }\n\n.filter-form .closePopup svg {\n      width: 16px; }\n\n.filter-form .closePopup svg .cls-1 {\n        stroke: #c1c1c1;\n        stroke-width: 2px; }\n\n.filter-form .popup-content {\n    height: 100%;\n    overflow: hidden;\n    visibility: visible; }\n\n.filter-form .fadeIn {\n    opacity: 1;\n    visibility: visible; }\n\n.filter-form .popupWrapperMob {\n    position: fixed;\n    width: 100%;\n    height: 100%;\n    bottom: 0;\n    top: 0;\n    right: 0;\n    left: 0;\n    z-index: 100;\n    background: rgba(0, 0, 0, 0.5);\n    visibility: hidden;\n    -webkit-transition: all 0.5s ease-in;\n    transition: all 0.5s ease-in; }\n\n.filter-form .popupWrapperMob .closePopup {\n      right: -25px;\n      top: -27px;\n      display: block; }\n\n.filter-form .popup-mob {\n    left: 0;\n    width: 100%;\n    max-height: 70%;\n    background: #fff;\n    padding: 30px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    height: 100%;\n    overflow: auto;\n    z-index: 1;\n    bottom: -70%;\n    -webkit-transition: all 0.5s ease-in;\n    transition: all 0.5s ease-in; }\n\n.filter-form .popupWrapperMob.showPopupMob {\n    z-index: 100;\n    visibility: visible;\n    opacity: 1; }\n\n.filter-form .popupWrapperMob.showPopupMob .popup-mob {\n    bottom: 0; }\n\n.filter-form .popup-content ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n\n.details-wrapper {\n  max-height: 450px;\n  overflow-x: auto;\n  overflow-y: auto; }\n\n.details-wrapper ::-webkit-scrollbar {\n    display: block; }\n\n.details-wrapper tr th {\n    padding: 10px; }\n\n.details-wrapper tr th.marks {\n      min-width: 185px;\n      height: 83px; }\n\n.details-wrapper tr td.marks {\n    min-width: 185px; }\n\n.btn-sms-search {\n  margin-top: 35px;\n  text-align: center;\n  margin-left: 280px;\n  width: 100%; }\n\n.search-filter-wrapper .normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  width: 15%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin-right: 10px;\n  margin-bottom: 5px;\n  float: right;\n  height: 35px;\n  font-size: 14px; }\n\n.pop-header {\n  padding-bottom: 12px; }\n\n.pull-right {\n  margin-right: 12px;\n  padding-bottom: 10px; }\n\n.stdnt-table {\n  height: 500px;\n  overflow: hidden !important; }\n\n.stdnt-table ::-webkit-scrollbar {\n    display: block; }\n\n.stdnt-table .poor {\n    background: white;\n    margin-top: 41px;\n    margin-left: 5px;\n    margin-right: 5px;\n    height: 300px;\n    overflow-y: auto;\n    overflow-x: auto; }\n\n.stu-table {\n  height: 500px; }\n\n.stu-table ::-webkit-scrollbar {\n    display: block; }\n\n.stu-table table tbody {\n    height: 450px;\n    overflow-x: auto;\n    overflow-y: auto; }\n\n.table-overflow {\n  overflow: hidden; }\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/exam-report-main/exam-report.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ExamReportMainComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_report_services_exam_service__ = __webpack_require__("./src/app/services/report-services/exam.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2____ = __webpack_require__("./src/app/index.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ExamReportMainComponent = /** @class */ (function () {
    function ExamReportMainComponent(examdata, appC, auth) {
        this.examdata = examdata;
        this.appC = appC;
        this.auth = auth;
        this.isProfessional = true;
        this.pageIndex = 1;
        this.getSubjectData = [];
        this.batchExamRepo = [];
        this.totalRecords = 0;
        this.dateSource = [];
        this.dateStore = [];
        this.displayBatchSize = 10;
        this.Tdata = false;
        this.courseData = [];
        this.pagedDetailExamSource = [];
        this.batchCourseData = [];
        this.isRippleLoad = false;
        this.selectedSubject = '';
        this.subjectData = [];
        this.masterCourses = [];
        this.addReportPopup = false;
        this.examTypeEntry = [];
        this.showTitle = false;
        this.exam_Sch_Data = [];
        this.examSource = [];
        this.detailSource = [];
        this.pagedExamSource = [];
        this.pageIndexPopup = 1;
        this.fetchApiData = [];
        this.dataExamIndex = [];
        this.typeDataForm = [];
        this.projectSettings = [
            { primaryKey: 'student_disp_id', header: 'Student ID' },
            { primaryKey: 'student_name', header: 'Student Name' },
            { primaryKey: 'student_phone', header: 'Contact No.' },
            { primaryKey: 'doj', header: 'Joining Date' },
            { primaryKey: 'grade', header: 'Grade' }
        ];
        this.HighestMarks = "";
        this.LowestMarks = "";
        this.AverageMarks = "";
        this.queryParam = {
            standard_id: -1,
            subject_id: -1,
            assigned: "N",
        };
        this.fetchFieldData = {
            institution_id: parseInt(sessionStorage.getItem('institute_id')),
            standard_id: '',
            subject_id: '',
            batch_id: '',
            exam_schd_id: ''
        };
        this.searchText = "";
        this.searchflag = false;
        this.searchData = [];
        this.property = "";
        this.direction = 0;
        this.sortingEnabled = true;
        this.switchActiveView('exam');
    }
    ExamReportMainComponent.prototype.professionalChecker = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
    };
    ExamReportMainComponent.prototype.ngOnInit = function () {
        this.isExamGrade = sessionStorage.getItem('is_exam_grad_feature');
        this.professionalChecker();
        if (this.isProfessional) {
            this.showTitle = true;
            this.projectSettings = [
                { primaryKey: 'student_disp_id', header: 'Student ID' },
                { primaryKey: 'student_name', header: 'Student Name' },
                { primaryKey: 'student_phone', header: 'Contact No.' },
                { primaryKey: 'doj', header: 'Joining Date' },
                { primaryKey: 'grade', header: 'Grade' }
            ];
        }
        else {
            this.showTitle = false;
            this.projectSettings = [
                { primaryKey: 'student_disp_id', header: 'Student Id' },
                { primaryKey: 'student_name', header: 'Student Name' },
                { primaryKey: 'student_phone', header: 'Contact No.' },
                { primaryKey: 'doj', header: 'Joining Date' },
                { primaryKey: 'total_marks', header: 'Total Marks' },
                { primaryKey: 'marks_obtained', header: 'Marks Obtained' },
                { primaryKey: 'rank', header: 'Rank' },
            ];
        }
        this.fetchExamData();
        this.pageIndex = 1;
    };
    ExamReportMainComponent.prototype.closeReportPopup = function () {
        this.addReportPopup = false;
    };
    /* select exam repo fill master courses==================================================================================
    ================================================================================== */
    ExamReportMainComponent.prototype.fetchExamData = function () {
        var _this = this;
        this.isRippleLoad = true;
        if (this.isProfessional) {
            this.isRippleLoad = false;
            this.batchExamRepo = [];
            this.subjectData = [];
            this.queryParam.subject_id = -1;
            this.queryParam.standard_id = -1;
            this.examdata.batchExamReport(this.queryParam).subscribe(function (res) {
                {
                    _this.batchExamRepo = res.standardLi;
                    _this.getSubjectData = res.batchLi;
                }
            });
        }
        else {
            this.examdata.ExamReport().subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.masterCourses = data;
                console.log(_this.masterCourses);
            });
        }
    };
    /*======================================================================================================
  ======================================================================================================== */
    ExamReportMainComponent.prototype.getCourseData = function (i) {
        var _this = this;
        this.isRippleLoad = true;
        if (this.isProfessional) {
            this.batchCourseData = [];
            this.fetchFieldData.exam_schd_id = "";
            this.queryParam.subject_id = -1;
            this.examdata.batchExamReport(this.queryParam).subscribe(function (res) {
                _this.isRippleLoad = false;
                console.log(res.subjectLi);
                _this.batchCourseData = res.subjectLi;
                _this.getSubjectData = res.batchLi;
                if (_this.batchCourseData == null) {
                    var obj = {
                        type: "info",
                        title: "No exam schedule found",
                        body: ""
                    };
                    _this.appC.popToast(obj);
                    _this.isRippleLoad = false;
                }
            });
        }
        else {
            this.fetchFieldData.exam_schd_id = "";
            this.fetchFieldData.batch_id = "";
            this.fetchFieldData.subject_id = "";
            this.examdata.getCourses(i).subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.courseData = data.coursesList;
                if (_this.courseData == null) {
                    var obj = {
                        type: "info",
                        title: "No exam schedule found",
                        body: ""
                    };
                    _this.appC.popToast(obj);
                    _this.isRippleLoad = false;
                }
            }, function (error) {
                _this.isRippleLoad = false;
                var obj = {
                    type: "error",
                    title: "",
                    body: "Please check your internet connection and if the issue persist contact support@proctur.com"
                };
                _this.appC.popToast(obj);
            });
        }
    };
    /*==================================================================================================
    ===================================================================================================== */
    ExamReportMainComponent.prototype.getSubData = function (i) {
        var _this = this;
        this.isRippleLoad = true;
        console.log(i);
        if (this.isProfessional) {
            this.fetchFieldData.exam_schd_id = "";
            this.examdata.batchExamReport(this.queryParam).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.getSubjectData = res.batchLi;
                if (_this.getSubjectData == null) {
                    var obj = {
                        type: "info",
                        title: "No exam schedule found",
                        body: ""
                    };
                    _this.appC.popToast(obj);
                    _this.isRippleLoad = false;
                }
            });
        }
        else {
            this.fetchFieldData.exam_schd_id = "";
            this.fetchFieldData.batch_id = "";
            this.examdata.getSubject(i).subscribe(function (data) {
                _this.subjectData = data.batchesList;
                _this.isRippleLoad = false;
                if (_this.subjectData == null) {
                    var obj = {
                        type: "info",
                        title: "No exam schedule found",
                        body: ""
                    };
                    _this.appC.popToast(obj);
                    _this.isRippleLoad = false;
                }
            });
        }
    };
    /*=======================================================================================
    ========================================================================================== */
    ExamReportMainComponent.prototype.getExamScheduleData = function (i) {
        var _this = this;
        console.log(i);
        if (this.isProfessional) {
            this.selectedSubject = this.getSubjectData.filter(function (item) { return item.batch_id == i; })[0].batch_name;
        }
        else {
            this.selectedSubject = this.subjectData.filter(function (item) { return item.batch_id == i; })[0].subject_name;
        }
        this.isRippleLoad = true;
        this.fetchFieldData.exam_schd_id = "";
        console.log(i);
        this.examdata.getExamSchedule(i).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.exam_Sch_Data = data.otherSchd;
            if (_this.exam_Sch_Data == null) {
                var obj = {
                    type: "info",
                    title: "No exam schedule found",
                    body: ""
                };
                _this.appC.popToast(obj);
                _this.isRippleLoad = false;
            }
        });
    };
    ExamReportMainComponent.prototype.getData = function (i) {
        console.log(i);
    };
    ExamReportMainComponent.prototype.fetchExamReport = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.examSource = [];
        if (this.isProfessional) {
            if (this.fetchFieldData.batch_id == "" || this.fetchFieldData.exam_schd_id == "") {
                var msg = {
                    type: "error",
                    title: "",
                    body: "All field(s) are required "
                };
                this.appC.popToast(msg);
                this.isRippleLoad = false;
            }
            else {
                var o = {
                    batch_id: this.fetchFieldData.batch_id,
                    exam_schd_id: this.fetchFieldData.exam_schd_id,
                    institution_id: this.fetchFieldData.institution_id,
                    standard_id: '',
                    subject_id: ''
                };
                this.examdata.viewExamData(o).subscribe(function (res) {
                    if (res.length) {
                        _this.examSource = res;
                        _this.Tdata = true;
                        _this.HighestMarks = _this.examSource[0].highest_marks;
                        _this.LowestMarks = _this.examSource[0].lowest_marks;
                        _this.AverageMarks = _this.examSource[0].average_marks;
                        _this.totalRecords = _this.examSource.length;
                        _this.fetchTableDataByPage(_this.pageIndex);
                        _this.isRippleLoad = false;
                        if (_this.examSource[0].isBatchExamGrade == 0) {
                            _this.projectSettings = [
                                { primaryKey: 'student_disp_id', header: 'Student Id' },
                                { primaryKey: 'student_name', header: 'Student Name' },
                                { primaryKey: 'student_phone', header: 'Contact No.' },
                                { primaryKey: 'doj', header: 'Joining Date' },
                                { primaryKey: 'total_marks', header: 'Total Marks' },
                                { primaryKey: 'student_marks_obtained', header: 'Marks Obtained' },
                                { primaryKey: 'student_rank', header: 'Rank' },
                            ];
                        }
                        else {
                            _this.projectSettings =
                                [{ primaryKey: 'student_disp_id', header: 'Student Id' },
                                    { primaryKey: 'student_name', header: 'Student Name' },
                                    { primaryKey: 'student_phone', header: 'Contact No.' },
                                    { primaryKey: 'doj', header: 'Joining Date' },
                                    { primaryKey: 'grade', header: 'Grade' },
                                ];
                        }
                    }
                    else {
                        var msg = {
                            type: "info",
                            body: "No data found"
                        };
                        _this.examSource = [];
                        _this.totalRecords = _this.examSource.length;
                        _this.fetchTableDataByPage(_this.pageIndex);
                        _this.appC.popToast(msg);
                        _this.isRippleLoad = false;
                    }
                }, function (err) {
                    _this.isRippleLoad = false;
                    console.log(err);
                });
            }
        }
        else {
            if (this.fetchFieldData.subject_id == "" || this.fetchFieldData.standard_id == "" || this.fetchFieldData.batch_id == "" ||
                this.fetchFieldData.exam_schd_id == "") {
                var msg = {
                    type: "error",
                    title: "",
                    body: "All field(s) are required"
                };
                this.appC.popToast(msg);
                this.isRippleLoad = false;
            }
            else {
                var o = {
                    batch_id: this.fetchFieldData.batch_id,
                    exam_schd_id: this.fetchFieldData.exam_schd_id,
                    institution_id: this.fetchFieldData.institution_id,
                    standard_id: '',
                    subject_id: ''
                };
                this.examdata.viewExamData(o).subscribe(function (res) {
                    if (res.length) {
                        console.log(res);
                        _this.examSource = res;
                        _this.Tdata = true;
                        _this.HighestMarks = _this.examSource[0].highest_marks;
                        _this.LowestMarks = _this.examSource[0].lowest_marks;
                        _this.AverageMarks = _this.examSource[0].average_marks;
                        _this.totalRecords = _this.examSource.length;
                        _this.fetchTableDataByPage(_this.pageIndex);
                        _this.isRippleLoad = false;
                        if (_this.examSource[0].grade == "" || _this.examSource[0].isBatchExamGrade == 0) {
                            _this.projectSettings = [
                                { primaryKey: 'student_disp_id', header: 'Student Id' },
                                { primaryKey: 'student_name', header: 'Student Name' },
                                { primaryKey: 'student_phone', header: 'Contact No.' },
                                { primaryKey: 'doj', header: 'Joining Date' },
                                { primaryKey: 'total_marks', header: 'Total Marks' },
                                { primaryKey: 'student_marks_obtained', header: 'Marks Obtained' },
                                { primaryKey: 'student_rank', header: 'Rank' },
                            ];
                        }
                        else {
                            _this.projectSettings =
                                [{ primaryKey: 'student_disp_id', header: 'Student Id' },
                                    { primaryKey: 'student_name', header: 'Student Name' },
                                    { primaryKey: 'student_phone', header: 'Contact No.' },
                                    { primaryKey: 'doj', header: 'Joining Date' },
                                    { primaryKey: 'grade', header: 'Grade' },
                                ];
                        }
                        console.log(res);
                    }
                    else {
                        var msg = {
                            type: "info",
                            body: "No data found"
                        };
                        _this.examSource = [];
                        _this.totalRecords = _this.examSource.length;
                        _this.fetchTableDataByPage(_this.pageIndex);
                        _this.appC.popToast(msg);
                        _this.isRippleLoad = false;
                    }
                }, function (err) {
                    _this.isRippleLoad = false;
                    console.log(err);
                });
            }
        }
    };
    ExamReportMainComponent.prototype.fetchDetailReport = function () {
        var _this = this;
        this.isRippleLoad = true;
        if (this.isProfessional) {
            if (this.fetchFieldData.batch_id == "") {
                var msg = {
                    type: "error",
                    body: "All field(s) are required "
                };
                this.appC.popToast(msg);
                this.isRippleLoad = false;
            }
            else {
                this.examdata.viewDetailData(this.fetchFieldData.batch_id)
                    .subscribe(function (res) {
                    if (res.length) {
                        _this.detailSource = res;
                        _this.dateSource = _this.detailSource.map(function (store) {
                            _this.dateStore = store.detailExamReportList;
                            _this.isRippleLoad = false;
                            //   this.totalRecords = this.detailSource.length;
                            //  this.fetchTableDataByPagePopup(this.pageIndexPopup);
                        });
                        _this.addReportPopup = true;
                    }
                    else {
                        var msg = {
                            type: "info",
                            title: "No data found",
                            body: ""
                        };
                        _this.appC.popToast(msg);
                        _this.isRippleLoad = false;
                    }
                }, function (err) {
                    _this.isRippleLoad = false;
                });
            }
        }
        else {
            if (this.fetchFieldData.standard_id == "" || this.fetchFieldData.subject_id == "" || this.fetchFieldData.batch_id == "") {
                var msg = {
                    type: "error",
                    body: "All Field must be filled"
                };
                this.isRippleLoad = false;
                this.appC.popToast(msg);
            }
            else {
                this.examdata.viewDetailData(this.fetchFieldData.batch_id)
                    .subscribe(function (res) {
                    if (res.length) {
                        _this.detailSource = res;
                        _this.dateSource = _this.detailSource.map(function (store) {
                            _this.dateStore = store.detailExamReportList;
                            _this.isRippleLoad = false;
                            // this.totalRecords = this.detailSource.length;
                            //this.fetchTableDataByPagePopup(this.pageIndexPopup);
                        });
                        _this.addReportPopup = true;
                    }
                    else {
                        var msg = {
                            type: "info",
                            title: "No data found",
                            body: ""
                        };
                        _this.appC.popToast(msg);
                        _this.isRippleLoad = false;
                    }
                }, function (err) {
                    _this.isRippleLoad = false;
                });
            }
        }
    };
    ExamReportMainComponent.prototype.getColor = function (status) {
        switch (status) {
            case 'Leave': return 'blue';
            case 'Absent': return 'red';
        }
    };
    ExamReportMainComponent.prototype.getMark = function (value) {
        if (value == null || value == "" || value == "0") {
            return '-';
        }
        else {
            return value;
        }
    };
    ExamReportMainComponent.prototype.fetchTableDataByPage = function (index) {
        this.pageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.pagedExamSource = this.getDataFromDataSource(startindex);
    };
    ExamReportMainComponent.prototype.fetchNext = function () {
        this.pageIndex++;
        this.fetchTableDataByPage(this.pageIndex);
    };
    ExamReportMainComponent.prototype.fetchPrevious = function () {
        if (this.pageIndex != 1) {
            this.pageIndex--;
            this.fetchTableDataByPage(this.pageIndex);
        }
    };
    ExamReportMainComponent.prototype.getDataFromDataSource = function (startindex) {
        if (this.searchflag) {
            var t = this.searchData.slice(startindex, startindex + this.displayBatchSize);
            return t;
        }
        else {
            var t = this.examSource.slice(startindex, startindex + this.displayBatchSize);
            return t;
        }
    };
    ExamReportMainComponent.prototype.fetchTableDataByPagePopup = function (index) {
        this.pageIndexPopup = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.pagedDetailExamSource = this.getDataFromDataSourcePopup(startindex);
    };
    ExamReportMainComponent.prototype.fetchNextPopup = function () {
        this.pageIndexPopup++;
        this.fetchTableDataByPagePopup(this.pageIndexPopup);
    };
    ExamReportMainComponent.prototype.fetchPreviousPopup = function () {
        if (this.pageIndexPopup != 1) {
            this.pageIndexPopup--;
            this.fetchTableDataByPagePopup(this.pageIndexPopup);
        }
    };
    ExamReportMainComponent.prototype.getDataFromDataSourcePopup = function (startindex) {
        var t = this.detailSource.slice(startindex, startindex + this.displayBatchSize);
        return t;
    };
    ExamReportMainComponent.prototype.closeExamReport = function () {
        this.addReportPopup = false;
    };
    ExamReportMainComponent.prototype.downloadJsonToCSV = function () {
        console.log(this.xlsDownloader);
        var link = this.xlsDownloader.nativeElement;
        var outer = this.examTable.nativeElement.outerHTML.replace(/ /g, '%20');
        var data_type = 'data:application/vnd.ms-excel';
        link.setAttribute('href', data_type + ',' + outer);
        link.setAttribute('download', 'ExamReport.xls');
        link.click();
    };
    // changed by laxmi
    ExamReportMainComponent.prototype.switchActiveView = function (id) {
        var classArray = ['home', 'attendance', 'sms', 'fee', 'exam', 'report', 'time', 'email', 'profit'];
        classArray.forEach(function (classname) {
            document.getElementById(classname) && document.getElementById(classname).classList.remove('active');
        });
        document.getElementById(id) && document.getElementById(id).classList.add('active');
    };
    ExamReportMainComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            this.pageIndex = 1;
            var searchRes = void 0;
            searchRes = this.examSource.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.searchData = searchRes;
            this.totalRecords = searchRes.length;
            this.searchflag = true;
            this.fetchTableDataByPage(this.pageIndex);
        }
        else {
            this.searchflag = false;
            this.fetchTableDataByPage(this.pageIndex);
            this.totalRecords = this.examSource.length;
        }
    };
    ExamReportMainComponent.prototype.sortedData = function (ev) {
        var _this = this;
        this.sortingEnabled = true;
        (this.direction == 0 || this.direction == -1) ? (this.direction = 1) : (this.direction = -1);
        {
            this.examSource = this.examSource.sort(function (a, b) {
                if (a[ev] < b[ev]) {
                    return -1 * _this.direction;
                }
                else if (a[ev] > b[ev]) {
                    return _this.direction;
                }
                else {
                    return 0;
                }
            });
        }
        this.pageIndex = 1;
        this.fetchTableDataByPage(this.pageIndex);
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('examTable'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], ExamReportMainComponent.prototype, "examTable", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('xlsDownloader'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], ExamReportMainComponent.prototype, "xlsDownloader", void 0);
    ExamReportMainComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-exam-report',
            template: __webpack_require__("./src/app/components/course-module/reports/exam-report-main/exam-report.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/reports/exam-report-main/exam-report.component.scss")],
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_report_services_exam_service__["a" /* ExamService */],
            __WEBPACK_IMPORTED_MODULE_2____["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_2____["b" /* AuthenticatorService */]])
    ], ExamReportMainComponent);
    return ExamReportMainComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/exam-report-main/filter.pipe.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FilterPipe; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var FilterPipe = /** @class */ (function () {
    function FilterPipe() {
    }
    FilterPipe.prototype.transform = function (value, args) {
        if (!value)
            return null;
        if (!args)
            return value;
        args = args.toLowerCase();
        return value.filter(function (item) {
            return JSON.stringify(item).toLowerCase().includes(args);
        });
    };
    FilterPipe = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Pipe"])({ name: 'filter' })
    ], FilterPipe);
    return FilterPipe;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/report-home/report-home.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"middle-section\">\r\n  <section class=\"header-section\">\r\n    <div>\r\n      <div class=\"header-title\">\r\n        <h2>\r\n          <a routerLink=\"/view/{{type}}\" style=\"color: #0084f6;\">\r\n            {{ type | titlecase }}\r\n          </a>\r\n          <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i> Report\r\n        </h2>\r\n      </div>\r\n    </div>\r\n  </section>\r\n  <div class=\"course-menu-section-container\">\r\n    <div class=\"course-menu-item\" *ngIf=\"JsonFlags.isShowAttendanceReport\" routerLink=\"/view/{{type}}/reports/attendance\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/course/create-course.svg\" alt=\"create course\">\r\n        <span>Attendance Report </span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>Attendance report for students.</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"course-menu-item\" *ngIf=\"JsonFlags.isShowExamReport\" routerLink=\"/view/{{type}}/reports/exam\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/course/create-course.svg\" alt=\"create course\">\r\n        <span>Exam Report</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>Exam report of student as per their performance.</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"course-menu-item hide\" *ngIf=\"JsonFlags.isShowExamReport\" routerLink=\"/view/{{type}}/reports/new-exam\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/course/create-course.svg\" alt=\"create course\">\r\n        <span>new Exam Report</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>Exam report of student as per their performance.</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"course-menu-item\"   routerLink=\"/view/{{type}}/reports/biometric\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/course/reports.svg\" alt=\"reports\">\r\n        <span>    Biometric Attendance</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>Report for attendance report with institute that has biometric system installed.</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/report-home/report-home.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/** these css for gear icon download options\r\n* created by laxmi\r\n*/\nsvg:hover #gearIcon {\n  fill: #0084f6; }\n.asHover:hover {\n  color: #0084f6 !important; }\n.download:hover {\n  cursor: pointer; }\n.made-in {\n  font-size: 17px;\n  font-weight: bold;\n  text-align: left; }\n.dropdown > ul {\n  background: #fff;\n  padding: 10px 20px;\n  border: 1px solid #eaeaeb;\n  border-top: 0;\n  margin-top: 3px;\n  -webkit-box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 6px 10px 0 rgba(0, 0, 0, 0.12);\n          box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 6px 10px 0 rgba(0, 0, 0, 0.12); }\n.dropdown > ul li {\n    color: #333; }\n.dropdown > ul li strong {\n      font-weight: 600;\n      display: block; }\n.dropdown > ul li a {\n      display: block;\n      color: #333; }\n.login-tube nav > ul > li {\n  display: inline-block;\n  position: relative; }\n.login-tube nav > ul > li > a {\n  color: #333;\n  text-decoration: none;\n  padding: 5px 10px;\n  display: block;\n  -webkit-transition: all .4s;\n  transition: all .4s; }\n.login-tube nav > ul > li > a:hover,\n.login-tube nav > ul > li:hover > a {\n  text-decoration: none;\n  background: #ccc; }\n.login-tube nav > ul > li .dropdown {\n  position: absolute;\n  visibility: hidden;\n  right: 0;\n  top: 100%;\n  min-width: 200px;\n  border-top: 0;\n  opacity: 0;\n  -webkit-transition: all 0.1s cubic-bezier(0.55, 0, 0.55, 0.2);\n  transition: all 0.1s cubic-bezier(0.55, 0, 0.55, 0.2);\n  -webkit-transition-duration: .25s;\n  transition-duration: .2s;\n  -webkit-transform: scale(0.5);\n          transform: scale(0.5); }\n.login-tube nav > ul > li .dropdown > ul li {\n    line-height: normal; }\n.login-tube nav > ul > li .dropdown > ul li a {\n      display: block;\n      margin: 5px 0; }\n.login-tube nav > ul > li .dropdown > ul li a:hover {\n        color: #0084f6; }\n.login-tube nav > ul > li .dropdown > ul ul {\n    padding-left: 15px;\n    padding-top: 10px; }\n.login-tube nav > ul > li .dropdown > ul ul ul {\n      padding-top: 0; }\n.login-tube nav > ul > li:hover .dropdown {\n  visibility: visible;\n  position: absolute;\n  opacity: 1;\n  right: 0;\n  top: 100%;\n  -webkit-transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);\n  transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);\n  -webkit-transition-duration: .5s;\n  transition-duration: .5s;\n  -webkit-transform: scale(1);\n          transform: scale(1); }\n.span-button {\n  border: 1px solid #0084f6;\n  padding: 4px 8px;\n  color: #0084f6;\n  font-size: .9em;\n  border-radius: 2px;\n  font-weight: 600;\n  cursor: pointer; }\n.span-button svg {\n    margin: -3px 0;\n    height: 14px; }\nlogin-nav > li {\n  display: inline-block;\n  padding: 0 7px;\n  cursor: pointer;\n  vertical-align: text-bottom; }\nlogin-nav > li .dropdown {\n    position: absolute;\n    right: 0;\n    top: 100%;\n    padding-top: 10px; }\nlogin-nav > li .icons {\n    width: 35px;\n    height: 35px;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    border-radius: 50%;\n    padding-top: 3px;\n    -webkit-transition: all 0.1s;\n    transition: all 0.1s;\n    border: 1px solid transparent; }\nlogin-nav > li .icons svg {\n      width: 25px;\n      color: #034979; }\nlogin-nav > li .icons svg .cls-1 {\n        stroke: #034979;\n        stroke-linejoin: unset;\n        border: none; }\nlogin-nav > li .user-info {\n    white-space: nowrap;\n    margin-right: 40px;\n    width: auto;\n    display: block;\n    position: relative; }\nlogin-nav > li .user-info > .icons {\n      display: inline-block;\n      vertical-align: middle; }\nlogin-nav > li .user-info > span {\n      vertical-align: middle;\n      display: inline-block; }\nlogin-nav > li .user-info:after {\n      display: inline-block;\n      font: normal normal normal 14px/1 FontAwesome;\n      font-size: inherit;\n      text-rendering: auto;\n      -webkit-font-smoothing: antialiased;\n      content: \"\\f107\";\n      font-size: 17px;\n      position: absolute;\n      right: -20px;\n      top: 10px; }\n/**\r\n  this css is for report section css for cards\r\n  added by laxmi\r\n*/\n.report-box {\n  width: 100%;\n  height: 100%;\n  padding: 10px; }\n.report-box ul.card-box li.card-row {\n    margin: 10px 0px; }\n.report-box ul.card {\n    padding: 15px 10px;\n    border: 1px solid #efefef;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 10px 0px;\n    -webkit-box-shadow: 0px 0px 2px 0px;\n            box-shadow: 0px 0px 2px 0px; }\n.report-box ul.card li {\n      padding: 5px; }\n.report-box ul.card li:first-child {\n        font-size: 14px;\n        font-weight: 600;\n        padding: 10px 5px; }\n.report-box ul.card li:nth-child(2n) {\n        font-size: 12px; }\n.disabled {\n  cursor: not-allowed;\n  background: lightgrey; }\n.middle-section {\n  padding: 1%; }\n.header-section .header-title {\n  text-align: left;\n  font-size: 14px;\n  font-weight: 600; }\n.course-menu-section-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  padding-top: 10px;\n  margin-top: 10px;\n  border-top: 1px solid rgba(10, 10, 10, 0.5);\n  width: 100%; }\n.course-menu-section-container .course-menu-item {\n    padding: 15px 10px;\n    width: 31%;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 1%;\n    -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24);\n    box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24); }\n.course-menu-section-container .course-menu-item .menu-title {\n      width: 100%;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start;\n      font-size: 14px;\n      font-weight: 600;\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row; }\n.course-menu-section-container .course-menu-item .menu-title img {\n        width: 25px;\n        height: 25px; }\n.course-menu-section-container .course-menu-item .menu-title span {\n        margin-left: 10px;\n        margin-top: 5px; }\n.course-menu-section-container .course-menu-item .menu-description {\n      padding: 10px;\n      font-size: 12px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/report-home/report-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReportHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var ReportHomeComponent = /** @class */ (function () {
    function ReportHomeComponent(auth) {
        this.auth = auth;
        this.type = '';
        this.JsonFlags = {
            biometricAttendanceEnable: false,
            isShowAttendanceReport: false,
            isShowExamReport: false
        };
    }
    ReportHomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.JsonFlags.biometricAttendanceEnable = sessionStorage.getItem('biometric_attendance_feature') == '1';
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.type = 'batch';
            }
            else {
                _this.type = 'course';
            }
        });
        this.fetchAndUpdatePermissions();
    };
    ReportHomeComponent.prototype.fetchAndUpdatePermissions = function () {
        var permissions = sessionStorage.getItem('permissions');
        /* Admin Account Detected */
        if (permissions == '' || permissions == null || permissions == undefined) {
            if (sessionStorage.getItem('userType') == '0') {
                this.JsonFlags.isShowExamReport = true;
                this.JsonFlags.isShowAttendanceReport = true;
            }
            else if (sessionStorage.getItem('userType') == '3') {
                this.JsonFlags.isShowExamReport = true;
                this.JsonFlags.isShowAttendanceReport = true;
            }
        }
        else {
            var perm = JSON.parse(permissions);
            /* attendance */
            if (perm.indexOf('201') != -1 || perm.indexOf('101') != -1) {
                this.JsonFlags.isShowAttendanceReport = true;
            }
            if (perm.indexOf('203') != -1) {
                this.JsonFlags.isShowExamReport = true;
            }
        }
    };
    ReportHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-report-home',
            template: __webpack_require__("./src/app/components/course-module/reports/report-home/report-home.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/reports/report-home/report-home.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], ReportHomeComponent);
    return ReportHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/reports-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReportsRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__reports_component__ = __webpack_require__("./src/app/components/course-module/reports/reports.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__report_home_report_home_component__ = __webpack_require__("./src/app/components/course-module/reports/report-home/report-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__attendance_report_attendanceReport_component__ = __webpack_require__("./src/app/components/course-module/reports/attendance-report/attendanceReport.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__exam_report_main_exam_report_component__ = __webpack_require__("./src/app/components/course-module/reports/exam-report-main/exam-report.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__biometric_biometric_component__ = __webpack_require__("./src/app/components/course-module/reports/biometric/biometric.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var routes = [];
var ReportsRoutingModule = /** @class */ (function () {
    function ReportsRoutingModule() {
    }
    ReportsRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__reports_component__["a" /* ReportsComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                component: __WEBPACK_IMPORTED_MODULE_3__report_home_report_home_component__["a" /* ReportHomeComponent */],
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_3__report_home_report_home_component__["a" /* ReportHomeComponent */],
                                pathMatch: 'prefix',
                            },
                            {
                                path: 'attendance',
                                component: __WEBPACK_IMPORTED_MODULE_4__attendance_report_attendanceReport_component__["a" /* AttendanceReportComponent */]
                            },
                            {
                                path: 'exam',
                                component: __WEBPACK_IMPORTED_MODULE_5__exam_report_main_exam_report_component__["a" /* ExamReportMainComponent */]
                            },
                            {
                                path: 'biometric',
                                component: __WEBPACK_IMPORTED_MODULE_6__biometric_biometric_component__["a" /* BiometricComponent */],
                                pathMatch: 'prefix',
                            },
                            {
                                path: 'new-exam',
                                loadChildren: 'app/components/course-module/reports/new-exam-report/exam-report.module#ExamReportModule',
                                pathMatch: 'prefix'
                            },
                        ]
                    }
                ])],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]]
        })
    ], ReportsRoutingModule);
    return ReportsRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/reports.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/reports.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/course-module/reports/reports.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReportsComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ReportsComponent = /** @class */ (function () {
    function ReportsComponent() {
    }
    ReportsComponent.prototype.ngOnInit = function () {
    };
    ReportsComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-reports',
            template: __webpack_require__("./src/app/components/course-module/reports/reports.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/reports/reports.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], ReportsComponent);
    return ReportsComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/reports.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportsModule", function() { return ReportsModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__reports_component__ = __webpack_require__("./src/app/components/course-module/reports/reports.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__reports_routing_module__ = __webpack_require__("./src/app/components/course-module/reports/reports-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__report_home_report_home_component__ = __webpack_require__("./src/app/components/course-module/reports/report-home/report-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__attendance_report_attendanceReport_component__ = __webpack_require__("./src/app/components/course-module/reports/attendance-report/attendanceReport.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_timepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/timepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_primeng_primeng__ = __webpack_require__("./node_modules/primeng/primeng.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_primeng_primeng___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9_primeng_primeng__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__services_attendance_report_service_service__ = __webpack_require__("./src/app/components/course-module/services/attendance-report-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__services_report_services_exam_service__ = __webpack_require__("./src/app/services/report-services/exam.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__exam_report_main_exam_report_component__ = __webpack_require__("./src/app/components/course-module/reports/exam-report-main/exam-report.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__exam_report_main_filter_pipe__ = __webpack_require__("./src/app/components/course-module/reports/exam-report-main/filter.pipe.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__services_excel_service__ = __webpack_require__("./src/app/services/excel.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__services_biometric_service_biometric_service_service__ = __webpack_require__("./src/app/services/biometric-service/biometric-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__biometric_biometric_component__ = __webpack_require__("./src/app/components/course-module/reports/biometric/biometric.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






/* Modules */






// import { ExamReportComponent } from './exam-report/exam-report.component';






var ReportsModule = /** @class */ (function () {
    function ReportsModule() {
    }
    ReportsModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_3__reports_routing_module__["a" /* ReportsRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_6__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_7_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_timepicker__["a" /* TimepickerModule */],
                __WEBPACK_IMPORTED_MODULE_9_primeng_primeng__["FileUploadModule"],
                __WEBPACK_IMPORTED_MODULE_9_primeng_primeng__["SplitButtonModule"],
                __WEBPACK_IMPORTED_MODULE_9_primeng_primeng__["MenuModule"],
                __WEBPACK_IMPORTED_MODULE_10__shared_shared_module__["a" /* SharedModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_2__reports_component__["a" /* ReportsComponent */],
                __WEBPACK_IMPORTED_MODULE_4__report_home_report_home_component__["a" /* ReportHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_5__attendance_report_attendanceReport_component__["a" /* AttendanceReportComponent */],
                __WEBPACK_IMPORTED_MODULE_13__exam_report_main_exam_report_component__["a" /* ExamReportMainComponent */],
                __WEBPACK_IMPORTED_MODULE_14__exam_report_main_filter_pipe__["a" /* FilterPipe */],
                __WEBPACK_IMPORTED_MODULE_17__biometric_biometric_component__["a" /* BiometricComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_12__services_report_services_exam_service__["a" /* ExamService */],
                __WEBPACK_IMPORTED_MODULE_15__services_excel_service__["a" /* ExcelService */],
                __WEBPACK_IMPORTED_MODULE_16__services_biometric_service_biometric_service_service__["a" /* BiometricServiceService */],
                __WEBPACK_IMPORTED_MODULE_11__services_attendance_report_service_service__["a" /* AttendanceReportServiceService */]
            ],
        })
    ], ReportsModule);
    return ReportsModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/services/attendance-report-service.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AttendanceReportServiceService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AttendanceReportServiceService = /** @class */ (function () {
    function AttendanceReportServiceService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        // this.institute_id = this.auth.getInstituteId();
        // this.Authorization = this.auth.getAuthToken();
        //console.log(this.institute_id);
        this.baseUrl = this.auth.getBaseUrl();
        //this.headers = new HttpHeaders({ "Content-Type": "application/json", "Authorization": this.Authorization });
    }
    AttendanceReportServiceService.prototype.getMasterCourse = function () {
        var url = this.baseUrl + "/api/v1/courseMaster/fetch/" + this.institute_id + "/all";
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    AttendanceReportServiceService.prototype.getCourses = function (obj) {
        var url = this.baseUrl + "/api/v1/courseMaster/fetch/" + this.institute_id + "/" + obj;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    AttendanceReportServiceService.prototype.getSubject = function (obj) {
        var url = this.baseUrl + "/api/v1/courseMaster/fetch/courses/" + this.institute_id + "/" + obj;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    AttendanceReportServiceService.prototype.postDataToTable = function (obj) {
        obj.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__(obj.from_date).format('YYYY-MM-DD');
        obj.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__(obj.to_date).format('YYYY-MM-DD');
        if (obj.from_date == "Invalid date") {
            obj.from_date = "";
        }
        if (obj.to_date == "Invalid date") {
            obj.to_date = "";
        }
        var url = this.baseUrl + "/api/v1/reports/attendance";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    AttendanceReportServiceService.prototype.postDataToTablePro = function (obj) {
        obj.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__(obj.from_date).format('YYYY-MM-DD');
        obj.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__(obj.to_date).format('YYYY-MM-DD');
        if (obj.from_date == "Invalid date") {
            obj.from_date = "";
        }
        if (obj.to_date == "Invalid date") {
            obj.to_date = "";
        }
        var url = this.baseUrl + "/api/v1/reports/attendance";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    AttendanceReportServiceService.prototype.postDetailedData = function (obj) {
        var url = this.baseUrl + "/api/v1/reports/attendance/monthlyAttendanceReport";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    /* =========================================================================== */
    /* =========================================================================== */
    /*for professional*/
    AttendanceReportServiceService.prototype.fetchMasterCourseProfessional = function (obj) {
        var url = this.baseUrl + "/api/v1/batches/fetchCombinedBatchData/" + this.institute_id + "?standard_id=" + obj.standard_id + "&subject_id=" + obj.subject_id + "&assigned=N";
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    AttendanceReportServiceService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */], __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], AttendanceReportServiceService);
    return AttendanceReportServiceService;
}());



/***/ }),

/***/ "./src/app/services/biometric-service/biometric-service.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BiometricServiceService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var BiometricServiceService = /** @class */ (function () {
    function BiometricServiceService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    BiometricServiceService.prototype.getAllData = function () {
        var url = this.baseUrl + "/api/v1/courseMaster/fetch/" + this.institute_id + "/all";
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    BiometricServiceService.prototype.getCourses = function (obj) {
        var url = this.baseUrl + "/api/v1/courseMaster/fetch/" + this.institute_id + "/" + obj;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    BiometricServiceService.prototype.getSubjects = function (obj) {
        var url = this.baseUrl + "/api/v1/courseMaster/fetch/courses/" + this.institute_id + "/" + obj;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    BiometricServiceService.prototype.sendSMSToAbsenties = function (obj) {
        obj.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__(obj.from_date).format('YYYY-MM-DD');
        var url = this.baseUrl + "/api/v1/attendance/sendSMSToAbsenties";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    BiometricServiceService.prototype.getAttendanceReport = function (obj) {
        obj.biometric_attendance_date = __WEBPACK_IMPORTED_MODULE_3_moment__(obj.biometric_attendance_date).format('YYYY-MM-DD');
        var url = this.baseUrl + "/api/v1/students/manage/" + this.institute_id;
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    BiometricServiceService.prototype.getAttendanceReportTeachers = function (obj) {
        obj.biometric_attendance_date = __WEBPACK_IMPORTED_MODULE_3_moment__(obj.biometric_attendance_date).format('YYYY-MM-DD');
        var url = this.baseUrl + "/api/v1/teachers/manage/" + this.institute_id;
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    BiometricServiceService.prototype.getAttendanceReportOthers = function (obj) {
        obj.biometric_attendance_date = __WEBPACK_IMPORTED_MODULE_3_moment__(obj.biometric_attendance_date).format('YYYY-MM-DD');
        var isActive = obj.is_active_status == 1 ? "Y" : "N";
        var url = this.baseUrl + "/api/v1/profiles/all/" + this.institute_id + "?active=" + isActive;
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    BiometricServiceService.prototype.getAllFinalReport = function (obj) {
        var url = this.baseUrl + "/api/v1/biometricAttendance/report";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    BiometricServiceService.prototype.fetchAbsentiesData = function (obj) {
        obj.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__(obj.from_date).format('YYYY-MM-DD');
        var url = this.baseUrl + "/api/v1/attendance/fetchAbsentsStudentsData";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    BiometricServiceService.prototype.fetchMasterCourseProfessional = function (obj) {
        var url = this.baseUrl + "/api/v1/batches/fetchCombinedBatchData/" + this.institute_id + "?standard_id=" + obj.standard_id + "&subject_id=" + obj.subject_id + "&assigned=N";
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    BiometricServiceService.prototype.fetchCourseProfessional = function (standardId) {
        var url = this.baseUrl + "/api/v1/subjects/standards/" + standardId;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    BiometricServiceService.prototype.fetchAbsenteesListProfessional = function (obj) {
        var url = this.baseUrl + "/api/v1/attendance/fetchAbsentsStudentsData/";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    BiometricServiceService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */], __WEBPACK_IMPORTED_MODULE_2__authenticator_service__["a" /* AuthenticatorService */]])
    ], BiometricServiceService);
    return BiometricServiceService;
}());



/***/ })

});
//# sourceMappingURL=reports.module.chunk.js.map