webpackJsonp(["component.module"],{

/***/ "./src/app/components/change-password/change-password.component.html":
/***/ (function(module, exports) {

module.exports = "<proctur-popup class=\"popupData\" [sizeWidth]=\"'small'\">\r\n  <span class=\"closePopup pos-abs fbold show\" (click)=\"closeChangePasswordPopup()\" close-button>\r\n    <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n      <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" style=\"fill: currentColor\"></path>\r\n    </svg>\r\n\r\n  </span>\r\n\r\n  <h2 popup-header>Change Password</h2>\r\n\r\n  <div class=\"content-wrapper\" popup-content>\r\n    <div class=\"row\">\r\n      <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n        <div class=\"field-wrapper\">\r\n          <label for=\"nameUser\">Alternate Login Email ID</label>\r\n          <input type=\"text\" readonly=\"true\" class=\"form-ctrl\" [(ngModel)]=\"changePass.username\" id=\"nameUser\" name=\"nameUser\">\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"row\">\r\n      <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n        <div class=\"field-wrapper\">\r\n          <label for=\"oldPass\">Old Password<span class=\"text-danger\">*</span></label>\r\n          <input type=\"password\" class=\"form-ctrl\" [(ngModel)]=\"changePass.oldPassword\" id=\"oldPass\" name=\"oldPass\">\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"row\">\r\n      <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n        <div class=\"field-wrapper\">\r\n          <label for=\"newPass\">New Password<span class=\"text-danger\">*</span></label>\r\n          <input type=\"password\" class=\"form-ctrl\" [(ngModel)]=\"changePass.newPassword\" id=\"newPass\" name=\"newPass\">\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"row\">\r\n      <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n        <div class=\"field-wrapper\">\r\n          <label for=\"cnfmPass\">Confirm Password<span class=\"text-danger\">*</span></label>\r\n          <input type=\"password\" class=\"form-ctrl\" [(ngModel)]=\"changePass.confirmPassword\" id=\"cnfmPass\" name=\"cnfmPass\">\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"row\">\r\n      <div class=\"\" style=\"margin: 5px 0px 0px 15px;\">\r\n        <h5>You will be logged out after changing the password</h5>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n\r\n  <div class=\"\" popup-footer>\r\n    <div class=\"clearfix\">\r\n      <aside class=\"pull-right popup-btn\">\r\n        <input type=\"button\" value=\"Close\" class=\"btn\" (click)=\"closeChangePasswordPopup()\">\r\n        <input type=\"button\" value=\"Change\" class=\"btn fullBlue\" (click)=\"changeUserPassword()\">\r\n      </aside>\r\n    </div>\r\n  </div>\r\n\r\n</proctur-popup>\r\n"

/***/ }),

/***/ "./src/app/components/change-password/change-password.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/change-password/change-password.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ChangePasswordComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_login_services_login_service__ = __webpack_require__("./src/app/services/login-services/login.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ChangePasswordComponent = /** @class */ (function () {
    function ChangePasswordComponent(router, log, msgService) {
        this.router = router;
        this.log = log;
        this.msgService = msgService;
        this.close = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.changePass = {
            username: '',
            oldPassword: '',
            newPassword: '',
            confirmPassword: '',
        };
    }
    ChangePasswordComponent.prototype.ngOnChanges = function () {
        var emailId = sessionStorage.getItem('alternate_email_id');
        if (emailId != "" && emailId != null && emailId != undefined && emailId != 'undefined') {
            this.changePass.username = emailId;
        }
        this.changePass.oldPassword = '';
        this.changePass.newPassword = '';
        this.changePass.confirmPassword = '';
    };
    ChangePasswordComponent.prototype.changeUserPassword = function () {
        var _this = this;
        if (this.changePass.oldPassword.trim() == "" || this.changePass.oldPassword.trim() == null) {
            this.messageNotifier(this.msgService.toastTypes.error, '', 'Please enter old password');
            return true;
        }
        if (this.changePass.newPassword.trim() == "" || this.changePass.newPassword.trim() == null) {
            this.messageNotifier(this.msgService.toastTypes.error, '', 'Please enter new password');
            return true;
        }
        if (this.changePass.confirmPassword.trim() == "" || this.changePass.confirmPassword == null) {
            this.messageNotifier(this.msgService.toastTypes.error, '', 'Please enter password in confirm password');
            return true;
        }
        if (this.changePass.newPassword.trim() != this.changePass.confirmPassword.trim()) {
            this.messageNotifier(this.msgService.toastTypes.error, '', 'Please check password provided in confirm password field');
            return true;
        }
        var userId = sessionStorage.getItem('userid') + '|' + sessionStorage.getItem('userType');
        var dataToSend = {
            username: userId,
            userid: sessionStorage.getItem('userid'),
            oldPassword: this.changePass.oldPassword,
            newPassword: this.changePass.newPassword,
            institute_id: this.institute_id,
        };
        this.log.changePasswordService(dataToSend).subscribe(function (res) {
            _this.messageNotifier(_this.msgService.toastTypes.success, '', 'Password changed successfully');
            _this.closeChangePasswordPopup();
            if (_this.log.logoutUser()) {
                _this.router.navigateByUrl('/authPage');
            }
        }, function (err) {
            console.log(err);
            _this.messageNotifier(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ChangePasswordComponent.prototype.closeChangePasswordPopup = function () {
        this.changePass = {
            username: sessionStorage.getItem('alternate_email_id'),
            oldPassword: '',
            newPassword: '',
            confirmPassword: '',
        };
        this.close.emit('true');
    };
    ChangePasswordComponent.prototype.messageNotifier = function (type, title, message) {
        this.msgService.showErrorMessage(type, title, message);
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Number)
    ], ChangePasswordComponent.prototype, "institute_id", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], ChangePasswordComponent.prototype, "close", void 0);
    ChangePasswordComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-change-password',
            template: __webpack_require__("./src/app/components/change-password/change-password.component.html"),
            styles: [__webpack_require__("./src/app/components/change-password/change-password.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_2__services_login_services_login_service__["a" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__["a" /* MessageShowService */]])
    ], ChangePasswordComponent);
    return ChangePasswordComponent;
}());



/***/ }),

/***/ "./src/app/components/component-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ComponentRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_component__ = __webpack_require__("./src/app/components/components.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__ = __webpack_require__("./src/app/guards/auth.guard.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__training_video_training_video_component__ = __webpack_require__("./src/app/components/training-video/training-video.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var ComponentRoutingModule = /** @class */ (function () {
    function ComponentRoutingModule() {
    }
    ComponentRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__components_component__["a" /* ComponentsComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                redirectTo: 'home', pathMatch: 'full'
                            },
                            {
                                path: 'admin',
                                redirectTo: 'home', pathMatch: 'full'
                            },
                            {
                                path: 'home',
                                loadChildren: 'app/components/homepage-dashboard/homepage-dashboard.module#HomepageDashboardModule'
                            },
                            {
                                path: 'SMS',
                                loadChildren: 'app/components/allocate-sms/allocate-sms.module#AllocateSmsModule'
                            },
                            {
                                path: 'formField',
                                loadChildren: 'app/components/custom-common/custom-common.module#CustomCommonModule',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            },
                            {
                                path: 'teacher',
                                loadChildren: 'app/components/teacher/teacher.module#TeacherModule',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            },
                            {
                                path: 'leads',
                                loadChildren: 'app/components/leads/leads.module#LeadsModule',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            },
                            {
                                path: 'online-exam',
                                loadChildren: 'app/components/online-exam-module/online-exam.module#OnlineExamModule',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            },
                            {
                                path: 'employee',
                                loadChildren: 'app/components/employee-home/employee-home.module#EmployeeHomeModule',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            },
                            {
                                path: 'inventory',
                                loadChildren: 'app/components/inventory/inventory.module#InventoryModule',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            },
                            {
                                path: 'fee',
                                loadChildren: 'app/components/fee-module/fee.module#FeeModule',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            },
                            {
                                path: 'communicate',
                                loadChildren: 'app/components/communicate/communicate.module#CommunicateModule',
                            },
                            {
                                path: 'course',
                                loadChildren: 'app/components/course-module/course-module.module#CourseModule2',
                            },
                            {
                                path: 'batch',
                                loadChildren: 'app/components/course-module/course-module.module#CourseModule2',
                            },
                            {
                                path: 'help',
                                loadChildren: 'app/components/help-home/help-home.module#HelpHomeModule',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            },
                            {
                                path: 'master',
                                loadChildren: 'app/components/master/master.module#ManageExamModule',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            },
                            {
                                path: 'setting',
                                loadChildren: 'app/components/institute-settings/institutes-setting.module#InstituteSettingModule',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            },
                            {
                                path: 'account',
                                loadChildren: 'app/components/institute-details/institute-details.module#InstituteDetailsModule',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            },
                            {
                                path: 'manage',
                                loadChildren: 'app/components/users-management/users-management.module#UserManagementModule',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            },
                            {
                                path: 'library',
                                loadChildren: 'app/components/library-management/library-management.module#LibraryManagementModule',
                            },
                            {
                                path: 'e-store',
                                loadChildren: 'app/components/eStore-module/estore.module#EstoreModule'
                            },
                            {
                                path: 'training-video',
                                component: __WEBPACK_IMPORTED_MODULE_4__training_video_training_video_component__["a" /* TrainingVideoComponent */],
                            },
                            {
                                path: 'live-classes',
                                loadChildren: 'app/components/live-classes-module/live-classes.module#LiveClassesModule'
                            },
                            {
                                path: 'students',
                                loadChildren: 'app/components/student-module/student-module.module#StudentModule2',
                                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                            }
                        ]
                    },
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], ComponentRoutingModule);
    return ComponentRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/component.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComponentModule", function() { return ComponentModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__component_routing_module__ = __webpack_require__("./src/app/components/component-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_component__ = __webpack_require__("./src/app/components/components.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__overlay_menu_overlay_menu_component__ = __webpack_require__("./src/app/components/overlay-menu/overlay-menu.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__core_core_sidednav_core_sidednav_component__ = __webpack_require__("./src/app/components/core/core-sidednav/core-sidednav.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__change_password_change_password_component__ = __webpack_require__("./src/app/components/change-password/change-password.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__global_search_popup_global_search_popup_component__ = __webpack_require__("./src/app/components/global-search-popup/global-search-popup.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__core_search_box_search_box_component__ = __webpack_require__("./src/app/components/core/search-box/search-box.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__services_course_services_course_list_service__ = __webpack_require__("./src/app/services/course-services/course-list.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__core_side_bar_side_bar_component__ = __webpack_require__("./src/app/components/core/side-bar/side-bar.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__student_module_student_fee_service__ = __webpack_require__("./src/app/components/student-module/student_fee.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__training_video_training_video_component__ = __webpack_require__("./src/app/components/training-video/training-video.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
















var ComponentModule = /** @class */ (function () {
    function ComponentModule() {
    }
    ComponentModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_2__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_3__component_routing_module__["a" /* ComponentRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_6_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */].forRoot(),
                __WEBPACK_IMPORTED_MODULE_5__components_shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_1__angular_forms__["FormsModule"],
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_4__components_component__["a" /* ComponentsComponent */],
                __WEBPACK_IMPORTED_MODULE_8__core_core_sidednav_core_sidednav_component__["a" /* CoreSidednavComponent */],
                __WEBPACK_IMPORTED_MODULE_7__overlay_menu_overlay_menu_component__["a" /* OverlayMenuComponent */],
                __WEBPACK_IMPORTED_MODULE_9__change_password_change_password_component__["a" /* ChangePasswordComponent */],
                __WEBPACK_IMPORTED_MODULE_9__change_password_change_password_component__["a" /* ChangePasswordComponent */],
                __WEBPACK_IMPORTED_MODULE_10__global_search_popup_global_search_popup_component__["a" /* GlobalSearchPopupComponent */],
                __WEBPACK_IMPORTED_MODULE_11__core_search_box_search_box_component__["a" /* SearchBoxComponent */],
                __WEBPACK_IMPORTED_MODULE_13__core_side_bar_side_bar_component__["a" /* SideBarComponent */],
                __WEBPACK_IMPORTED_MODULE_15__training_video_training_video_component__["a" /* TrainingVideoComponent */]
            ],
            entryComponents: [],
            providers: [
                __WEBPACK_IMPORTED_MODULE_14__student_module_student_fee_service__["a" /* StudentFeeService */],
                __WEBPACK_IMPORTED_MODULE_12__services_course_services_course_list_service__["a" /* CourseListService */]
            ],
            exports: []
        })
    ], ComponentModule);
    return ComponentModule;
}());



/***/ }),

/***/ "./src/app/components/components.component.html":
/***/ (function(module, exports) {

module.exports = "<overlay-menu *ngIf=\"isMenuVisible\"></overlay-menu>\r\n\r\n<!-- <core-header (changePassword)=\"changePasswordPopUp()\" (enquiryUpdateAction)=\"updateEnquiryPopUp($event)\" (hideSearchPopup)=\"searchViewMore($event)\"\r\n    (searchViewMore)=\"searchViewMore($event)\"></core-header> -->\r\n\r\n\r\n<!-- <core-sidednav (changePassword)=\"changePasswordPopUp()\" (enquiryUpdateAction)=\"updateEnquiryPopUp($event)\" (hideSearchPopup)=\"searchViewMore($event)\"\r\n    (searchViewMore)=\"searchViewMore($event)\"></core-sidednav> -->\r\n\r\n<app-side-bar (changePassword)=\"changePasswordPopUp()\" (enquiryUpdateAction)=\"updateEnquiryPopUp($event)\" (hideSearchPopup)=\"searchViewMore($event)\"\r\n    (searchViewMore)=\"searchViewMore($event)\"></app-side-bar>\r\n\r\n<router-outlet></router-outlet>\r\n\r\n<!-- Change Password Popup Component -->\r\n\r\n<app-change-password *ngIf=\"changePasswordComp\" [institute_id]=\"institute_id\" (close)=\"closeChangePasswordPopup($event)\"></app-change-password>\r\n\r\n\r\n<!-- Enquiry update popup -->\r\n\r\n<app-enquiry-update-popup *ngIf=\"enquiryUpdateComp\" [enqData]=\"enquiryInfo\" (closePopUp)=\"closeEnquiryPopUp($event)\"></app-enquiry-update-popup>\r\n\r\n<!-- Global Search View More Component  -->\r\n\r\n<app-global-search-popup *ngIf=\"isSearchMoreComp\" [eventData]=\"searchMoreData\" (closeViewMorePopUp)=\"closeViewMorePopUp($event)\"\r\n    (enquiryUpdateAction)=\"updateEnquiryPopUp($event)\"></app-global-search-popup>\r\n"

/***/ }),

/***/ "./src/app/components/components.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ComponentsComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__ = __webpack_require__("./src/app/services/login-services/login.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__node_modules_angular_platform_browser__ = __webpack_require__("./node_modules/@angular/platform-browser/esm5/platform-browser.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var ComponentsComponent = /** @class */ (function () {
    function ComponentsComponent(log, auth, commonService, title) {
        this.log = log;
        this.auth = auth;
        this.commonService = commonService;
        this.title = title;
        this.isMenuVisible = false;
        this.isloggedInAdmin = false;
        this.changePasswordComp = false;
        this.institute_id = 0;
        this.enquiryUpdateComp = false;
        this.enquiryInfo = "";
        this.isSearchMoreComp = false;
        this.searchMoreData = "";
    }
    ComponentsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.log.currentMenuState.subscribe(function (el) {
            _this.isMenuVisible = el;
        });
        this.isloggedInAdmin = this.commonService.checkUserIsAdmin();
        this.auth.currentInstituteId.subscribe(function (id) {
            if (id != null && id != "") {
                _this.institute_id = id;
            }
        });
        this.checkTitleAndFavIcon();
        this.checkInternetConnection();
    };
    // Change Password Pop up Section///
    ComponentsComponent.prototype.changePasswordPopUp = function () {
        this.changePasswordComp = true;
    };
    ComponentsComponent.prototype.closeChangePasswordPopup = function (event) {
        this.changePasswordComp = false;
    };
    /// Enquiry Update Pop Up Section////
    // Show Enquiry Update Pop Up
    ComponentsComponent.prototype.updateEnquiryPopUp = function (event) {
        this.enquiryUpdateComp = true;
        this.enquiryInfo = event.data.id;
    };
    // Close Enquiry Pop Up
    ComponentsComponent.prototype.closeEnquiryPopUp = function (event) {
        if (event == true) {
            this.enquiryUpdateComp = false;
        }
        this.enquiryInfo = null;
    };
    // Global Search Pop Up
    // Show All Search Data Pop UP
    ComponentsComponent.prototype.searchViewMore = function (e) {
        if (e != null) {
            this.isSearchMoreComp = true;
            this.searchMoreData = e;
        }
        else {
            this.isSearchMoreComp = false;
        }
    };
    // Close ALl data pop up
    ComponentsComponent.prototype.closeViewMorePopUp = function (event) {
        if (event == true) {
            this.isSearchMoreComp = false;
        }
        this.searchMoreData = null;
    };
    // Change Title once user refresh
    ComponentsComponent.prototype.checkTitleAndFavIcon = function () {
        var title = sessionStorage.getItem('institute_title_web');
        if (title != undefined && title != "" && title != null) {
            this.title.setTitle(title);
        }
    };
    // Internet Issue
    ComponentsComponent.prototype.checkInternetConnection = function () {
        var _this = this;
        this.auth.checkInternetConnection().subscribe(function (res) {
            if (!res) {
                _this.commonService.showErrorMessage('error', 'Internet Connectivity Issue', 'Please check your internet connection');
            }
        });
    };
    ComponentsComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-components',
            template: __webpack_require__("./src/app/components/components.component.html")
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__["a" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_3__services_common_service__["a" /* CommonServiceFactory */],
            __WEBPACK_IMPORTED_MODULE_4__node_modules_angular_platform_browser__["Title"]])
    ], ComponentsComponent);
    return ComponentsComponent;
}());



/***/ }),

/***/ "./src/app/components/core/core-sidednav/core-sidednav.component.html":
/***/ (function(module, exports) {

module.exports = "<aside class=\"common-nav\" id=\"commonLeftNav\">\r\n  <div class=\"search_container\">\r\n    <svg *ngIf=\"!searchBar\" xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" class=\"search-icon\"\r\n      (click)=\"showSearchBar()\">\r\n      <rect width=\"24\" height=\"24\" fill=\"none\" />\r\n      <path d=\"M920.5-1404h-.794l-.276-.274A6.469,6.469,0,0,0,921-1408.5a6.5,6.5,0,0,0-6.5-6.5,6.5,6.5,0,0,0-6.5,6.5,6.5,6.5,0,0,0,6.5,6.5,6.47,6.47,0,0,0,4.225-1.566l.276.274v.792l5,4.991L925.49-1399l-4.988-5Zm-6,0a4.5,4.5,0,0,1-4.5-4.5,4.5,4.5,0,0,1,4.5-4.5,4.5,4.5,0,0,1,4.5,4.5,4.5,4.5,0,0,1-4.5,4.5Z\"\r\n        transform=\"translate(-905 1418)\" fill=\"#fff\" fill-rule=\"evenodd\" />\r\n    </svg>\r\n    <svg class=\"search-icon\" (click)=\"closeSearchBar()\" *ngIf=\"searchBar\" xmlns=\"http://www.w3.org/2000/svg\" width=\"30.098\" height=\"30.098\"\r\n      viewBox=\"0 0 30.098 30.098\">\r\n      <g transform=\"translate(-7 -7)\">\r\n        <g transform=\"translate(4.41 4.41)\">\r\n          <g transform=\"translate(32.607 2.67) rotate(90)\">\r\n            <path d=\"M21.167,12.1H12.1v9.072H9.072V12.1H0V9.072H9.072V0H12.1V9.072h9.072Z\" transform=\"translate(14.967 0) rotate(45)\"\r\n              fill=\"#fff\" />\r\n          </g>\r\n        </g>\r\n        <rect width=\"30.098\" height=\"30.098\" transform=\"translate(7 7)\" fill=\"none\" />\r\n      </g>\r\n    </svg>\r\n  </div>\r\n  <nav>\r\n    <ul class=\"nav-list\">\r\n      <li routerLink=\"/view/home\" class=\"\" id=\"lizero\" (click)=\"toggler('lizero')\">\r\n        <i class=\"icon\" id=\"li0\">\r\n          <svg id=\"li0\" xmlns=\"http://www.w3.org/2000/svg\" width=\"15.729\" height=\"15.603\" viewBox=\"0 0 15.729 15.603\">\r\n            <g transform=\"translate(0.319 0.308)\">\r\n              <g transform=\"translate(0.024 0)\">\r\n                <g transform=\"translate(0 0)\">\r\n                  <path d=\"M14.626,14.163H13.3v-6.3a1.322,1.322,0,0,0,1.3-2.251L8.406.32a1.315,1.315,0,0,0-1.72,0L.486,5.608a1.322,1.322,0,0,0,1.3,2.25v6.3H.465a.441.441,0,1,0,0,.881H14.626a.441.441,0,1,0,0-.881ZM1.634,6.946a.441.441,0,0,1-.575-.668L7.258.989a.439.439,0,0,1,.575,0l6.2,5.288a.441.441,0,1,1-.575.668l-5.625-4.8C7.667,2.009,1.8,6.8,1.634,6.946Zm10.789,7.216H7.1c.011-.03-3.483,0-3.526,0H2.668V7.222L7.545,3.064l4.877,4.159v6.94Z\"\r\n                    transform=\"translate(-0.024 0)\" fill=\"#fff\" stroke=\"#fff\" stroke-width=\"0.5\" />\r\n                </g>\r\n              </g>\r\n            </g>\r\n          </svg>\r\n        </i>\r\n        <span id=\"li0\">Home</span>\r\n      </li>\r\n      <li routerLink=\"/view/enquiry\" class=\"hide\" id=\"lione\" (click)=\"toggler('lione')\">\r\n        <i class=\"icon\" id=\"li1\">\r\n          <svg id=\"li1\" xmlns=\"http://www.w3.org/2000/svg\" width=\"20.996\" height=\"20.996\" viewBox=\"0 0 20.996 20.996\">\r\n            <g transform=\"translate(-21.999 -115.997)\">\r\n              <path d=\"M18.707.18a.615.615,0,0,0-.87,0L13.1,4.921H2.346A1.847,1.847,0,0,0,.5,6.766v8.611a1.847,1.847,0,0,0,1.845,1.845H3v3.158a.615.615,0,0,0,1.055.43l3.51-3.588h7.164a1.847,1.847,0,0,0,1.845-1.845V8.4L21.317,3.66a.615.615,0,0,0,0-.87Zm-5.655,10-1.74-1.74,5.22-5.219,1.74,1.74Zm-2.4-.655,1.311,1.311-2.246.936Zm4.688,5.849a.616.616,0,0,1-.615.615H7.308a.615.615,0,0,0-.44.185L4.233,18.872V16.608a.615.615,0,0,0-.615-.615H2.346a.616.616,0,0,1-.615-.615V6.766a.616.616,0,0,1,.615-.615h9.52L10.008,8.009a.629.629,0,0,0-.136.206L8.17,12.3H4.848a.615.615,0,1,0,0,1.23H8.58a.622.622,0,0,0,.242-.049l4.461-1.858a.625.625,0,0,0,.206-.136l1.858-1.858Zm3.8-11.283L17.4,2.355l.87-.87,1.74,1.74Zm0,0\"\r\n                transform=\"translate(21.498 115.997)\" fill=\"#fff\" />\r\n              <line x2=\"5.5\" transform=\"translate(26 125.5)\" fill=\"none\" stroke=\"#fff\" stroke-linecap=\"round\" stroke-width=\"1\"\r\n              />\r\n            </g>\r\n          </svg>\r\n        </i>\r\n        <span id=\"li1\">Enquiry</span>\r\n      </li>\r\n      <li routerLink=\"/view/students\" class=\"hide\" id=\"litwo\" (click)=\"toggler('litwo')\">\r\n        <i class=\"icon\" id=\"li2\">\r\n          <svg id=\"li2\" xmlns=\"http://www.w3.org/2000/svg\" width=\"19.589\" height=\"20.9\" viewBox=\"0 0 19.589 20.9\">\r\n            <g transform=\"translate(0 0)\">\r\n              <path d=\"M187.512,287.317a.612.612,0,0,0-.837.223,1.356,1.356,0,0,1-2.348,0,.612.612,0,0,0-1.06.613,2.581,2.581,0,0,0,4.468,0,.612.612,0,0,0-.223-.837Zm0,0\"\r\n                transform=\"translate(-175.706 -275.509)\" fill=\"#fff\" />\r\n              <path d=\"M177.78,235.975a.613.613,0,1,0-.433.179A.617.617,0,0,0,177.78,235.975Zm0,0\" transform=\"translate(-169.52 -225.339)\"\r\n                fill=\"#fff\" />\r\n              <path d=\"M273.745,234.93a.613.613,0,1,0,.433.18A.616.616,0,0,0,273.745,234.93Zm0,0\" transform=\"translate(-261.983 -225.34)\"\r\n                fill=\"#fff\" />\r\n              <path d=\"M19.084,1.649,9.9.009a.61.61,0,0,0-.215,0L.5,1.649a.612.612,0,0,0,0,1.206l2.775.5v7.1a6.522,6.522,0,0,0,3.578,5.814q-.268.1-.53.216l-.023.01a8.4,8.4,0,0,0-.812.42,8.53,8.53,0,0,0-3.046,3.071.612.612,0,0,0,.53.919H16.611a.612.612,0,0,0,.53-.919A8.53,8.53,0,0,0,14.1,16.911a8.423,8.423,0,0,0-.814-.422l-.02-.009q-.261-.117-.53-.216a6.522,6.522,0,0,0,3.578-5.814V3.35l2.055-.367V10.45a.612.612,0,0,0,1.225,0v-8.2a.612.612,0,0,0-.5-.6Zm-9.29-.415,5.7,1.018-5.7,1.018-5.7-1.018ZM9.182,18.81,7.661,17.289a7.226,7.226,0,0,1,1.521-.3Zm1.225-1.818a7.225,7.225,0,0,1,1.521.3L10.406,18.81Zm-3.972.8,1.882,1.881H4.138a7.294,7.294,0,0,1,2.3-1.881Zm9.016,1.881H11.272l1.881-1.882a7.3,7.3,0,0,1,2.3,1.882ZM9.794,15.741A5.3,5.3,0,0,1,4.5,10.45V7.783H15.084V10.45a5.3,5.3,0,0,1-5.291,5.29Zm5.291-9.182H4.5V3.569l5.183.926a.61.61,0,0,0,.215,0l5.183-.926Zm0,0\"\r\n                transform=\"translate(0.001 0)\" fill=\"#fff\" />\r\n            </g>\r\n          </svg>\r\n        </i>\r\n        <span id=\"li2\">Student</span>\r\n      </li>\r\n      <li routerLink=\"/view/course\" class=\"hide\" id=\"lithree\" (click)=\"toggler('lithree')\">\r\n        <i class=\"icon\" id=\"li3\">\r\n          <svg id=\"li3\" xmlns=\"http://www.w3.org/2000/svg\" width=\"22.82\" height=\"14.541\" viewBox=\"0 0 22.82 14.541\">\r\n            <g transform=\"translate(0 0)\">\r\n              <g transform=\"translate(0 0)\">\r\n                <path d=\"M26.735,32.522V26.847a1.115,1.115,0,0,0,.152-.405.735.735,0,0,0-.431-.684l-9.449-4.23a2.837,2.837,0,0,0-2.229,0L5.3,25.758a.735.735,0,0,0-.405.684.659.659,0,0,0,.481.633L8.85,28.266V35.11a.684.684,0,0,0,.3.583.735.735,0,0,0,.659.076,17.328,17.328,0,0,1,12.159,0l.253.051a.836.836,0,0,0,.405-.127.735.735,0,0,0,.3-.583V28.266l2.381-.811v5.066a1.723,1.723,0,0,0,.709,3.318,1.748,1.748,0,0,0,.709-3.318Zm-5.218,1.6a18.544,18.544,0,0,0-11.248,0V28.215a17.125,17.125,0,0,1,11.247,0Zm.76-7.148a18.822,18.822,0,0,0-12.793,0l-1.951-.659,7.8-3.5a1.368,1.368,0,0,1,1.089,0l7.8,3.5Zm3.749,7.448a.317.317,0,1,1,0-.633.317.317,0,0,1,0,.633Z\"\r\n                  transform=\"translate(-4.898 -21.3)\" fill=\"#fff\" />\r\n              </g>\r\n            </g>\r\n          </svg>\r\n        </i>\r\n        <span *ngIf=\"isLangInstitute\" id=\"li3\">Batch</span>\r\n        <span *ngIf=\"!isLangInstitute\" id=\"li3\">Course</span>\r\n      </li>\r\n      <li routerLink=\"/view/activity\" class=\"hide\" id=\"lifour\" (click)=\"toggler('lifour')\">\r\n        <i class=\"icon\" id=\"li4\">\r\n          <img src=\"./assets/images/sidebar/White/activity.svg\" alt=\"activity\" style=\"width:16px;\">\r\n        </i>\r\n        <span id=\"li4\">Activity</span>\r\n      </li>\r\n      <li routerLink=\"/view/employee\" class=\"hide\" id=\"lifive\" (click)=\"toggler('lifive')\" style=\"display: none;\">\r\n        <i class=\"icon\" id=\"li5\">\r\n          <!-- <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"-29 119 28 24\" id=\"li5\">\r\n\r\n                        <g id=\"Group_1187\" data-name=\"Group 1187\" transform=\"translate(-46 -16)\">\r\n                            <g id=\"Group_1176\" data-name=\"Group 1176\" transform=\"translate(1)\">\r\n                                <path id=\"Path_252\" data-name=\"Path 252\" class=\"cls-1\" d=\"M14.084,14.529c-1.647,0-3.588-1.824-4.353-4.412-.647,0-1.176-.765-1.235-1.647a1.765,1.765,0,0,1,.882-1.824C9.555,3.118,10.555,1,14.084,1s4.529,2.118,4.706,5.647c.588.118.941.882.882,1.824s-.588,1.647-1.235,1.647C17.673,12.706,15.731,14.529,14.084,14.529Z\"\r\n                                    transform=\"translate(15.916 136)\" />\r\n                                <path id=\"Path_253\" data-name=\"Path 253\" class=\"cls-1\" d=\"M14.529,20.5C18.294,21.382,21,23.324,21,27.265a25.487,25.487,0,0,1-10,1.765A25.487,25.487,0,0,1,1,27.265c0-3.941,2.706-5.882,6.471-6.765\"\r\n                                    transform=\"translate(19 127.971)\" />\r\n                            </g>\r\n                            <rect id=\"Rectangle_669\" data-name=\"Rectangle 669\" class=\"cls-2\" width=\"28\" height=\"24\" transform=\"translate(17 135)\" />\r\n                        </g>\r\n                    </svg> -->\r\n        </i>\r\n        <span id=\"li5\">Employee</span>\r\n      </li>\r\n      <li routerLink=\"/view/reports\" class=\"hide\" id=\"lisix\" (click)=\"toggler('lisix')\">\r\n        <i class=\"icon\" id=\"li6\">\r\n          <svg id=\"li6\" xmlns=\"http://www.w3.org/2000/svg\" width=\"16.325\" height=\"19.012\" viewBox=\"0 0 16.325 19.012\">\r\n            <g transform=\"translate(0 0)\">\r\n              <path d=\"M3.785,337.465H.557a.557.557,0,0,0-.557.557v5.367a.557.557,0,0,0,.557.557H3.785a.557.557,0,0,0,.557-.557v-5.367A.557.557,0,0,0,3.785,337.465Zm-.557,5.367H1.114v-4.253H3.228v4.253Zm0,0\"\r\n                transform=\"translate(0 -324.934)\" fill=\"#fff\" />\r\n              <path d=\"M165.133,256.676H161.9a.557.557,0,0,0-.557.557V265.6a.557.557,0,0,0,.557.557h3.229a.557.557,0,0,0,.557-.557v-8.367A.557.557,0,0,0,165.133,256.676Zm-.557,8.367h-2.115V257.79h2.115Zm0,0\"\r\n                transform=\"translate(-155.356 -247.145)\" fill=\"#fff\" />\r\n              <path d=\"M326.481,134.66h-3.229a.557.557,0,0,0-.557.557v12.9a.557.557,0,0,0,.557.557h3.229a.557.557,0,0,0,.557-.557v-12.9A.557.557,0,0,0,326.481,134.66Zm-.557,12.9H323.81V135.774h2.115Zm0,0\"\r\n                transform=\"translate(-310.713 -129.66)\" fill=\"#fff\" />\r\n              <path d=\"M1.534,7a.555.555,0,0,0,.259-.064L7.61,3.88l2.316,1.2a.557.557,0,0,0,.528-.008l5.159-2.879-.2.524a.557.557,0,1,0,1.042.395l.737-1.946a.578.578,0,0,0,.034-.24.555.555,0,0,0-.516-.517l-2-.4A.557.557,0,0,0,14.5,1.1l.576.115-4.9,2.735-2.308-1.2a.557.557,0,0,0-.516,0L1.274,5.953A.557.557,0,0,0,1.534,7Zm0,0\"\r\n                transform=\"translate(-0.94 0)\" fill=\"#fff\" />\r\n            </g>\r\n          </svg>\r\n        </i>\r\n        <span id=\"li6\">Reports</span>\r\n      </li>\r\n      <li routerLink=\"/view/inventory\" class=\"hide\" id=\"liseven\" (click)=\"toggler('liseven')\">\r\n        <i class=\"icon\" id=\"li7\">\r\n\r\n          <svg id=\"li7\" xmlns=\"http://www.w3.org/2000/svg\" width=\"20.214\" height=\"14.199\" viewBox=\"0 0 20.214 14.199\">\r\n            <g transform=\"translate(0 0)\">\r\n              <g transform=\"translate(0 0)\">\r\n                <path d=\"M16.8,76.168H3.415A3.419,3.419,0,0,0,0,79.583v9.928a.858.858,0,0,0,.857.857h18.5a.858.858,0,0,0,.857-.857V79.583A3.419,3.419,0,0,0,16.8,76.168ZM2.823,89.183H1.184V82.7H2.823v6.483Zm0-7.667H1.184V79.583a2.235,2.235,0,0,1,1.639-2.151v4.084Zm1.184-4.164h12.2v4.164H12.37a2.339,2.339,0,0,0-4.526,0H4.007V77.352Zm7.255,4.756a1.155,1.155,0,1,1-1.155-1.155A1.156,1.156,0,0,1,11.262,82.108Zm4.945,7.075H4.007V82.7H7.844a2.339,2.339,0,0,0,4.526,0h3.837Zm2.823,0H17.391V82.7H19.03Zm0-7.667H17.391V77.432a2.235,2.235,0,0,1,1.639,2.151Z\"\r\n                  transform=\"translate(0 -76.168)\" fill=\"#fff\" />\r\n              </g>\r\n            </g>\r\n          </svg>\r\n        </i>\r\n        <span id=\"li7\">Inventory</span>\r\n      </li>\r\n      <li routerLink=\"/view/expense\" class=\"hide\" id=\"lieight\" (click)=\"toggler('lieight')\" style=\"display: none;\">\r\n        <i class=\"icon\" id=\"li8\">\r\n          <!-- <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"-29 484 28 24\" id=\"li8\">\r\n                        <g id=\"Group_1181\" data-name=\"Group 1181\" transform=\"translate(-46 -16)\">\r\n                            <line id=\"Line_203\" data-name=\"Line 203\" class=\"cls-1\" x2=\"0.976\" transform=\"translate(30.5 512.5)\" />\r\n                            <line id=\"Line_179\" data-name=\"Line 179\" class=\"cls-1\" x2=\"0.976\" transform=\"translate(30.5 512.5)\" />\r\n                            <g id=\"Group_1168\" data-name=\"Group 1168\" transform=\"translate(1)\">\r\n                                <line id=\"Line_180\" data-name=\"Line 180\" class=\"cls-1\" x2=\"0.976\" transform=\"translate(20 522)\" />\r\n                                <rect id=\"Rectangle_507\" data-name=\"Rectangle 507\" class=\"cls-1\" width=\"3.902\" height=\"10.244\" transform=\"translate(35.122 511.756)\"\r\n                                />\r\n                                <rect id=\"Rectangle_508\" data-name=\"Rectangle 508\" class=\"cls-1\" width=\"3.902\" height=\"3.415\" transform=\"translate(23.415 518.585)\"\r\n                                />\r\n                                <rect id=\"Rectangle_509\" data-name=\"Rectangle 509\" class=\"cls-1\" width=\"3.902\" height=\"5.854\" transform=\"translate(29.269 516.146)\"\r\n                                />\r\n                                <line id=\"Line_181\" data-name=\"Line 181\" class=\"cls-1\" x1=\"19.024\" transform=\"translate(21.951 522)\" />\r\n                                <path id=\"Path_279\" data-name=\"Path 279\" class=\"cls-1\" d=\"M20.034,1H15.4l1.122,1.122L10.766,7.878,7.741,4.854,1.4,11.2l2.2,2.2L7.449,9.537l3.024,3.024,8.293-8.244,1.268,1.171Z\"\r\n                                    transform=\"translate(18.99 501)\" />\r\n                            </g>\r\n                            <rect id=\"Rectangle_675\" data-name=\"Rectangle 675\" class=\"cls-2\" width=\"28\" height=\"24\" transform=\"translate(17 500)\" />\r\n                        </g>\r\n                    </svg> -->\r\n        </i>\r\n        <span id=\"li8\">Expense</span>\r\n      </li>\r\n      <li routerLink=\"/view/campaign\" class=\"hide\" id=\"linine\" (click)=\"toggler('linine')\">\r\n        <i class=\"icon\" id=\"li9\">\r\n          <!-- <svg id=\"li9\" xmlns=\"http://www.w3.org/2000/svg\" width=\"20.214\" height=\"14.199\" viewBox=\"0 0 20.214 14.199\"><g transform=\"translate(0 0)\"><g transform=\"translate(0 0)\"><path d=\"M16.8,76.168H3.415A3.419,3.419,0,0,0,0,79.583v9.928a.858.858,0,0,0,.857.857h18.5a.858.858,0,0,0,.857-.857V79.583A3.419,3.419,0,0,0,16.8,76.168ZM2.823,89.183H1.184V82.7H2.823v6.483Zm0-7.667H1.184V79.583a2.235,2.235,0,0,1,1.639-2.151v4.084Zm1.184-4.164h12.2v4.164H12.37a2.339,2.339,0,0,0-4.526,0H4.007V77.352Zm7.255,4.756a1.155,1.155,0,1,1-1.155-1.155A1.156,1.156,0,0,1,11.262,82.108Zm4.945,7.075H4.007V82.7H7.844a2.339,2.339,0,0,0,4.526,0h3.837Zm2.823,0H17.391V82.7H19.03Zm0-7.667H17.391V77.432a2.235,2.235,0,0,1,1.639,2.151Z\" transform=\"translate(0 -76.168)\" fill=\"#fff\"/></g></g></svg> -->\r\n          <svg id=\"li9\" xmlns=\"http://www.w3.org/2000/svg\" width=\"22.997\" height=\"18.037\" viewBox=\"0 0 22.997 18.037\">\r\n            <g transform=\"translate(0 0)\">\r\n              <path d=\"M.731,69.21A.731.731,0,0,0,0,69.94v5.7a.731.731,0,0,0,1.461,0v-5.7A.731.731,0,0,0,.731,69.21Z\" transform=\"translate(0 -64.949)\"\r\n                fill=\"#fff\" />\r\n              <path d=\"M36,25.459H32.957a.731.731,0,0,0-.731.73v.66l-9.783,2.9a.731.731,0,0,0-.523.7v5.7a.73.73,0,0,0,.009.11l0,.02a.733.733,0,0,0,.022.09l2.071,6.613a.73.73,0,0,0,.915.479l3.016-.943a.731.731,0,0,0,.479-.915l-1.026-3.279,4.817,1.429v.66a.731.731,0,0,0,.731.73H36a.731.731,0,0,0,.731-.73V26.189A.73.73,0,0,0,36,25.459ZM26.823,41.344l-1.621.507-1.443-4.608,1.963.582Zm-.308-4.808-.006,0-3.126-.927V31l8.844-2.623V38.23Zm8.752,3.147H33.687V26.92h1.578Z\"\r\n                transform=\"translate(-19.786 -25.459)\" fill=\"#fff\" />\r\n              <path d=\"M185.872,132.6l-3.161-1.581a.731.731,0,1,0-.653,1.307l3.161,1.581a.731.731,0,0,0,.653-1.307Z\" transform=\"translate(-163.96 -120.672)\"\r\n                fill=\"#fff\" />\r\n              <path d=\"M182.385,52.823a.727.727,0,0,0,.326-.077l3.161-1.581a.73.73,0,1,0-.653-1.307l-3.161,1.581a.731.731,0,0,0,.327,1.384Z\"\r\n                transform=\"translate(-163.96 -47.412)\" fill=\"#fff\" />\r\n              <path d=\"M197.38,98.48h-2.639a.73.73,0,0,0,0,1.461h2.639a.73.73,0,1,0,0-1.461Z\" transform=\"translate(-175.113 -91.368)\"\r\n                fill=\"#fff\" />\r\n            </g>\r\n          </svg>\r\n        </i>\r\n        <span id=\"li9\">Campaign </span>\r\n      </li>\r\n      <li routerLink=\"/view/library\" class=\"hide\" id=\"liten\" (click)=\"toggler('liten')\">\r\n        <i class=\"icon\" id=\"li10\">\r\n          <svg id=\"li10\" xmlns=\"http://www.w3.org/2000/svg\" width=\"18.95\" height=\"18.949\" viewBox=\"0 0 18.95 18.949\">\r\n            <g transform=\"translate(0 0)\">\r\n              <path d=\"M17.84,10.132V8.371a.555.555,0,0,0-.555-.555,16.748,16.748,0,0,0-3.226.294A5.013,5.013,0,0,0,11.974,6.9a3.886,3.886,0,1,0-5,0A5.013,5.013,0,0,0,4.892,8.11a16.751,16.751,0,0,0-3.226-.294.555.555,0,0,0-.555.555v1.761A1.668,1.668,0,0,0,0,11.7v1.11a1.668,1.668,0,0,0,1.11,1.57v1.761a.555.555,0,0,0,.555.555,12.92,12.92,0,0,1,7.5,2.164.557.557,0,0,0,.616,0,12.92,12.92,0,0,1,7.5-2.164.555.555,0,0,0,.555-.555V14.382a1.668,1.668,0,0,0,1.11-1.57V11.7A1.668,1.668,0,0,0,17.84,10.132ZM6.7,3.929A2.776,2.776,0,1,1,9.475,6.705,2.8,2.8,0,0,1,6.7,3.929ZM1.665,13.367a.556.556,0,0,1-.555-.555V11.7a.555.555,0,0,1,1.11,0v1.11A.556.556,0,0,1,1.665,13.367ZM8.92,17.4a13.891,13.891,0,0,0-6.7-1.809V14.382a1.668,1.668,0,0,0,1.11-1.57V11.7a1.668,1.668,0,0,0-1.11-1.57v-1.2a12.549,12.549,0,0,1,6.7,1.958ZM9.475,9.93a13.194,13.194,0,0,0-3.23-1.485,3.894,3.894,0,0,1,2.12-.63h2.221a3.894,3.894,0,0,1,2.12.63A13.194,13.194,0,0,0,9.475,9.93ZM16.729,15.6a13.892,13.892,0,0,0-6.7,1.809V10.893a12.548,12.548,0,0,1,6.7-1.959v1.2a1.668,1.668,0,0,0-1.11,1.57v1.11a1.668,1.668,0,0,0,1.11,1.57Zm1.11-2.784a.555.555,0,0,1-1.11,0V11.7a.555.555,0,0,1,1.11,0Z\"\r\n                transform=\"translate(0 -0.006)\" fill=\"#fff\" />\r\n            </g>\r\n          </svg>\r\n        </i>\r\n        <span id=\"li10\">Library</span>\r\n      </li>\r\n      <li routerLink=\"/view/e-store/home\" class=\"hide\"  id=\"lieleone\" (click)=\"toggler('lieleone')\">\r\n        <i class=\"fa fa-stack-exchange icon\"  id=\"li11\" aria-hidden=\"true\" style=\"font-size: 1.6rem;\"></i>\r\n        <span id=\"li11\">estore</span>\r\n      </li>\r\n      <li routerLink=\"/view/live-classes\"  id=\"litwelve\">\r\n        <i class=\"icon\" id=\"li12\">\r\n          <img src=\"./assets/images/activity/live_classes.svg\" alt=\"\">\r\n        </i>\r\n        <span id=\"li12\">Live</span>\r\n      </li>\r\n    </ul>\r\n  </nav>\r\n\r\n  <nav class=\"down-side-bar\">\r\n    <ul>\r\n      <li>\r\n        <svg (click)=\"showHelpMenu()\" xmlns=\"http://www.w3.org/2000/svg\" width=\"18\" height=\"18\" viewBox=\"0 0 18 18\">\r\n          <g transform=\"translate(-0.001)\">\r\n            <path d=\"M8.881,0A9,9,0,1,0,18,8.879,9,9,0,0,0,8.881,0ZM8.854,14.478H8.8a1.31,1.31,0,0,1,.031-2.62H8.88a1.31,1.31,0,1,1-.026,2.62Zm3.219-6.39A5.95,5.95,0,0,1,11,9.05l-.549.379A1.493,1.493,0,0,0,9.9,10.1a1.391,1.391,0,0,0-.085.563v.088h-2.1l.006-.177a2.293,2.293,0,0,1,.346-1.513A8.906,8.906,0,0,1,9.632,7.8,1.651,1.651,0,0,0,10,7.425a1.333,1.333,0,0,0,.318-.777,1.514,1.514,0,0,0-.288-.9,1.2,1.2,0,0,0-1.038-.39,1.131,1.131,0,0,0-1.049.485,1.947,1.947,0,0,0-.318,1.047v.089H5.466l0-.093a3.286,3.286,0,0,1,1.4-2.834,3.7,3.7,0,0,1,2.034-.534,4.391,4.391,0,0,1,2.624.755,2.62,2.62,0,0,1,1.062,2.261A2.587,2.587,0,0,1,12.073,8.088Z\"\r\n              transform=\"translate(0 0)\" fill=\"#eaf3ff\" />\r\n          </g>\r\n        </svg>\r\n      </li>\r\n      <li>\r\n        <svg (click)=\"showMenu()\" xmlns=\"http://www.w3.org/2000/svg\" width=\"25.41\" height=\"25.543\" viewBox=\"0 0 17.41 19.543\">\r\n          <path d=\"M-17990.3-3575.457a1.794,1.794,0,0,1-.9-.24l-6.9-3.984a1.817,1.817,0,0,1-.9-1.563v-7.968a1.817,1.817,0,0,1,.9-1.563l6.9-3.984a1.805,1.805,0,0,1,.9-.24,1.827,1.827,0,0,1,.9.24l6.9,3.984a1.817,1.817,0,0,1,.9,1.563v7.968a1.817,1.817,0,0,1-.9,1.563l-6.9,3.984A1.827,1.827,0,0,1-17990.3-3575.457Zm-.682-9.157v4.115h1.369v-4.115h4.115v-1.369h-4.115v-4.115h-1.369v4.115h-4.115v1.369Z\"\r\n            transform=\"translate(17999.002 3595)\" fill=\"#fff\" />\r\n        </svg>\r\n      </li>\r\n    </ul>\r\n  </nav>\r\n\r\n</aside>\r\n\r\n<aside class=\"\" *ngIf=\"helpMenu\">\r\n  <div class=\"help-menu-container\">\r\n    <!-- <div class=\"help-menu-item\">\r\n      <div class=\"help-menu-icon-container\">\r\n        <img src=\"./assets/images/sidebar/sideMenu/whtasnew.svg\" alt=\"new\">\r\n      </div>\r\n      <div class=\"help-menu-name\">\r\n        <span>Whats New</span>\r\n      </div>\r\n    </div> -->\r\n    <div class=\"help-menu-item\" (click)=\"openInNewTab('https://procturhelp.freshdesk.com/support/home')\">\r\n      <div class=\"help-menu-icon-container\">\r\n        <img src=\"./assets/images/sidebar/sideMenu/proctur.svg\" alt=\"faqs\">\r\n      </div>\r\n      <div class=\"help-menu-name\">\r\n        <span>FAQs</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"help-menu-item\" (click)=\"openInNewTab('https://procturhelp.freshdesk.com/support/tickets/new')\">\r\n      <div class=\"help-menu-icon-container\">\r\n        <img src=\"./assets/images/sidebar/sideMenu/support.svg\" alt=\"ticket\">\r\n      </div>\r\n      <div class=\"help-menu-name\">\r\n        <span>Create Support Ticket</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"help-menu-item\" (click)=\"openInNewTab('https://anydesk.com/en/downloads/')\">\r\n      <div class=\"help-menu-icon-container\">\r\n        <img src=\"./assets/images/sidebar/sideMenu/download.svg\" alt=\"download\">\r\n      </div>\r\n      <div class=\"help-menu-name\">\r\n        <span>Download Anydesk</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"help-menu-item\">\r\n      <div class=\"help-menu-icon-container\">\r\n        <img src=\"./assets/images/sidebar/sideMenu/call.svg\" alt=\"phone\">\r\n      </div>\r\n      <div class=\"help-menu-name\">\r\n        <span>+91 9971839153</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</aside>\r\n\r\n<!-- SEARCH BAR AND RESULT-->\r\n<aside class=\"search-bar-container\" [hidden]=\"!searchBar\">\r\n  <div class=\"search-bar-input-container\">\r\n    <form autocomplete=\"off\" #form=\"ngForm\">\r\n      <input type=\"text\" id=\"search_bar\" [(ngModel)]=\"userInput\" name=\"userInput\" #searchInput [ngClass]=\"{'has-focus': isResultDisplayed}\"\r\n        autofocus (focus)=\"triggerSearchBox($event)\" autocomplete=\"off\" maxlength=\"20\" placeholder=\"Search Enquiry/Student by Name or Contact\"\r\n        class=\"search-input searchbox form-ctrl-head search-item\">\r\n    </form>\r\n  </div>\r\n  <section class=\"search-dropdown search-item\" #seachResult>\r\n    <search-box (closeSearch)=\"closeSearch($event)\" [searchValue]=\"inputValue\" [resultStat]=\"resultStat\" [studentResult]=\"studentResult\"\r\n      (viewAll)=\"viewMoreRecods($event)\" (searchAgain)=\"searchAgain($event)\" (stuSelected)=\"selectedStudent($event)\" (enqSelected)=\"selectedEnquiry($event)\"\r\n      [enquiryResult]=\"enquiryResult\" (actionSelected)=\"actionSelected($event)\">\r\n    </search-box>\r\n  </section>\r\n</aside>\r\n\r\n<aside class=\"side-menu\" [hidden]=\"!sideBar\">\r\n  <!--  (click)=\"closeSubMenu()\" -->\r\n  <div class=\"side-menu-container\">\r\n    <div class=\"back-btn-container\">\r\n      <img src=\"./assets/images/sidebar/sideMenu/back.svg\" alt=\"\" (click)=\"closeMenu()\">\r\n    </div>\r\n    <div class=\"account-name-and-icon\">\r\n      <div class=\"profile-photo-container\">\r\n        <img src=\"./assets/images/sidebar/default-picture.png\" alt=\"profile photo\">\r\n      </div>\r\n      <div class=\"account-name-container\">\r\n        <span>{{instituteName}}</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"menu-container\">\r\n\r\n      <div class=\"menu-item\">\r\n        <div class=\"external-menu\" id=\"profile\">\r\n          <div class=\"external-menu-item\">\r\n            <span (click)=\"changePasswordClick()\">Change Password</span>\r\n          </div>\r\n          <div class=\"external-menu-item\">\r\n            <span (click)=\"logout()\">Logout</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"current-menu\" (click)=\"showSubMenu('profile')\" id=\"profile_current\">\r\n          <div class=\"menu-icon\">\r\n            <img src=\"./assets/images/sidebar/sideMenu/profile.svg\" alt=\"icon\" id=\"profile_icon\">\r\n          </div>\r\n          <div class=\"menu-name\">\r\n            <span>Profile</span>\r\n          </div>\r\n          <div class=\"side-menu-icon\">\r\n            <i class=\"fa fa-chevron-right\" style=\"font-family: FontAwesome;\" aria-hidden=\"true\"></i>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"menu-item\" *ngIf=\"isMainBranch == 'Y' && checkAdmin\">\r\n        <div class=\"external-menu\" id=\"branches\">\r\n          <div class=\"external-menu-item\" *ngFor=\"let data of branchesList\">\r\n            <span (click)=\"onSubBranchClick(data)\">{{data.institute_name}}</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"current-menu\" (click)=\"showSubMenu('branches')\" id=\"branches_current\">\r\n          <div class=\"menu-icon\">\r\n            <img src=\"./assets/images/sidebar/sideMenu/branches.svg\" alt=\"icon\" id=\"branches_icon\">\r\n          </div>\r\n          <div class=\"menu-name\">\r\n            <span>Branches</span>\r\n          </div>\r\n          <div class=\"side-menu-icon\">\r\n            <i class=\"fa fa-chevron-right\" style=\"font-family: FontAwesome;\" aria-hidden=\"true\"></i>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"menu-item\" *ngIf=\"(showMainBranchBackBtn)\">\r\n        <div class=\"current-menu\" (click)=\"showSubMenu('branches')\">\r\n          <div class=\"menu-icon\">\r\n            <img src=\"./assets/images/sidebar/sideMenu/branches.svg\" alt=\"icon\">\r\n          </div>\r\n          <div class=\"menu-name\">\r\n            <span (click)=\"loginToMainBranch()\">Back To Main Branch</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"menu-item\" #divMyAccountTag id=\"divMyAccountTag\">\r\n        <div class=\"current-menu\" (click)=\"routerLink('/view/account')\">\r\n          <div class=\"menu-icon\">\r\n            <img src=\"./assets/images/sidebar/sideMenu/account.svg\" alt=\"icon\">\r\n          </div>\r\n          <div class=\"menu-name\">\r\n            <span>My Account</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"menu-item\" #divManageUsers id=\"divManageUsers\">\r\n        <div class=\"current-menu\" (click)=\"routerLink('/view/manage')\">\r\n          <div class=\"menu-icon\">\r\n            <img src=\"./assets/images/sidebar/sideMenu/users.svg\" alt=\"icon\">\r\n          </div>\r\n          <div class=\"menu-name\">\r\n            <span>Manage Users</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"menu-item\" #divMasterTag id=\"divMasterTag\">\r\n        <div class=\"external-menu\" id=\"master\">\r\n          <div class=\"external-menu-item\" #divAcademicTag id=\"divAcademicTag\">\r\n            <span (click)=\"routerLink('/view/academic/list')\">Academic Year</span>\r\n          </div>\r\n          <div class=\"external-menu-item\" #divClassRoomTag id=\"divClassRoomTag\">\r\n            <span (click)=\"routerLink('/view/master/classroom')\">Class Room</span>\r\n          </div>\r\n          <div class=\"external-menu-item\">\r\n            <span (click)=\"routerLink('view/master/closingReason')\">Closing Reason</span>\r\n          </div>\r\n          <div class=\"external-menu-item\">\r\n            <span (click)=\"routerLink('/view/master/discount-reason')\">Discount Reason</span>\r\n          </div>\r\n          <div class=\"external-menu-item\" #divManageTag id=\"divManageTag\">\r\n            <span (click)=\"routerLink('/view/master/eventManagment')\">Event</span>\r\n          </div>\r\n          <div class=\"external-menu-item\" #divTeacherTag id=\"divTeacherTag\">\r\n            <span (click)=\"routerLink('/view/teacher')\">Faculty</span>\r\n          </div>\r\n          <div class=\"external-menu-item\" #divFeeTag id=\"divFeeTag\">\r\n            <span (click)=\"routerLink('/view/fee')\">Fee</span>\r\n          </div>\r\n          <div class=\"external-menu-item\" *ngIf=\"libraryRole\" #divLibraryTag id=\"divLibraryTag\">\r\n            <span (click)=\"routerLink('/view/library/master')\">Library</span>\r\n          </div>\r\n          <div class=\"external-menu-item\" #divGradesTag id=\"divGradesTag\">\r\n            <span (click)=\"routerLink('/view/master/manage-exam-grades')\">Manage exam grades</span>\r\n          </div>\r\n          <div class=\"external-menu-item\" #divProfileTag id=\"divProfileTag\">\r\n            <span (click)=\"viewTeacherProfile()\">Profile</span>\r\n          </div>\r\n          <div class=\"external-menu-item\" #divSlotTag id=\"divSlotTag\">\r\n            <span (click)=\"routerLink('/view/master/slot')\">Slot</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"current-menu\" (click)=\"showSubMenu('master')\" id=\"master_current\">\r\n          <div class=\"menu-icon\">\r\n            <img src=\"./assets/images/sidebar/sideMenu/master.svg\" alt=\"icon\" id=\"master_icon\">\r\n          </div>\r\n          <div class=\"menu-name\">\r\n            <span>Master</span>\r\n          </div>\r\n          <div class=\"side-menu-icon\">\r\n            <i class=\"fa fa-chevron-right\" style=\"font-family: FontAwesome;\" aria-hidden=\"true\"></i>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"menu-item\" #divSettingTag id=\"divSettingTag\">\r\n        <div class=\"external-menu\" id=\"settings\">\r\n          <div class=\"external-menu-item\" #divGeneralSettingTag id=\"divGeneralSettingTag\">\r\n            <span (click)=\"routerLink('/view/setting')\">General Settings</span>\r\n          </div>\r\n          <div class=\"external-menu-item\" #divManageFormTag id=\"divManageFormTag\">\r\n            <span (click)=\"routerLink('/view/formField/home')\">Manage Form Field</span>\r\n          </div>\r\n          <div class=\"external-menu-item\" #divAreaAndMap id=\"divAreaAndMap\">\r\n            <span (click)=\"routerLink('/view/master/areaCity')\">City Area Map</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"current-menu\" (click)=\"showSubMenu('settings')\" id=\"settings_current\">\r\n          <div class=\"menu-icon\">\r\n            <img src=\"./assets/images/sidebar/sideMenu/settings.svg\" alt=\"icon\" id=\"settings_icon\">\r\n          </div>\r\n          <div class=\"menu-name\">\r\n            <span>Settings</span>\r\n          </div>\r\n          <div class=\"side-menu-icon\">\r\n            <i class=\"fa fa-chevron-right\" style=\"font-family: FontAwesome;\" aria-hidden=\"true\"></i>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"menu-item\">\r\n        <div class=\"current-menu\" (click)=\"logout()\">\r\n          <div class=\"menu-icon\">\r\n            <img src=\"./assets/images/sidebar/sideMenu/logout.svg\" alt=\"icon\">\r\n          </div>\r\n          <div class=\"menu-name\">\r\n            <span>Logout</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n</aside>\r\n\r\n<aside class=\"blur-background\" *ngIf=\"sideBar || searchBar || helpMenu\" (click)=\"closeMenu()\">\r\n\r\n</aside>"

/***/ }),

/***/ "./src/app/components/core/core-sidednav/core-sidednav.component.scss":
/***/ (function(module, exports) {

module.exports = "\n@import url(\"https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800\");\n@import url(\"https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800\");\n/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/* Import Font CSS*/\n/* @font-face {\r\n    font-family: 'Open Sans';\r\n    font-style: normal;\r\n    font-weight: 700;\r\n    src: local('Open Sans Bold'), local('OpenSans-Bold'), url(https://themes.googleusercontent.com/static/fonts/opensans/v6/k3k702ZOKiLJc3WVjuplzHhCUOGz7vYGh680lGh-uXM.woff) format('woff');\r\n}\r\n\r\n@font-face {\r\n    font-family: 'Open Sans';\r\n    font-style: normal;\r\n    font-weight: 300;\r\n    src: local('Open Sans Light'), local('OpenSans-Light'), url(https://themes.googleusercontent.com/static/fonts/opensans/v6/DXI1ORHCpsQm3Vp6mXoaTXhCUOGz7vYGh680lGh-uXM.woff) format('woff');\r\n}\r\n\r\n@font-face {\r\n    font-family: 'Open Sans';\r\n    font-style: normal;\r\n    font-weight: 600;\r\n    src: local('Open Sans Semibold'), local('OpenSans-Semibold'), url(https://themes.googleusercontent.com/static/fonts/opensans/v6/MTP_ySUJH_bn48VBG8sNSnhCUOGz7vYGh680lGh-uXM.woff) format('woff');\r\n}\r\n\r\n@font-face {\r\n    font-family: 'Open Sans';\r\n    font-style: normal;\r\n    font-weight: 400;\r\n    src: local('Open Sans'), local('OpenSans'), url(https://themes.googleusercontent.com/static/fonts/opensans/v6/cJZKeOuBrn4kERxqtaUH3T8E0i7KZn-EPnyo3HZu7kw.woff) format('woff');\r\n} */\n/*/ import reset css*/\n* {\n  margin: 0;\n  padding: 0;\n  border: 0;\n  -webkit-font-smoothing: antialiased;\n  outline: none; }\nhtml,\nbody,\ndiv,\nspan,\napplet,\nobject,\niframe,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6,\np,\nblockquote,\npre,\na,\nabbr,\nacronym,\naddress,\nbig,\ncite,\ncode,\ndel,\ndfn,\nem,\nimg,\nins,\nkbd,\nq,\ns,\nsamp,\nsmall,\nstrike,\nstrong,\nsub,\nsup,\ntt,\nvar,\nb,\nu,\ni,\ncenter,\ndl,\ndt,\ndd,\nol,\nul,\nli,\nfieldset,\nform,\nlabel,\nlegend,\ntable,\ncaption,\ntbody,\ntfoot,\nthead,\ntr,\nth,\ntd,\narticle,\naside,\ncanvas,\ndetails,\nembed,\nfigure,\nfigcaption,\nfooter,\nheader,\nhgroup,\nmenu,\nnav,\noutput,\nruby,\nsection,\nsummary,\ntime,\nmark,\naudio,\nvideo {\n  border: 0;\n  font: inherit;\n  vertical-align: baseline;\n  margin: 0;\n  padding: 0; }\ninput,\nimg,\nselect,\ntextarea,\nbutton {\n  outline: none; }\nul,\nol {\n  list-style-type: none;\n  padding-left: 0;\n  margin-top: 0; }\nhtml {\n  -ms-text-size-adjust: 100%;\n  -webkit-text-size-adjust: 100%; }\nbody {\n  font-size: 14px;\n  line-height: 1.2;\n  letter-spacing: normal;\n  word-spacing: normal; }\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  font-weight: 400; }\ninput {\n  -webkit-appearance: none;\n  -moz-appearance: none;\n  appearance: none; }\nimg {\n  max-width: 100%;\n  height: auto; }\n/*/ import themes css*/\n/* import commom css*/\n/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/* Scrollbar thickness changed here for vertical display */\n::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);\n  background-color: #F5F5F5;\n  border-radius: 10px; }\n::-webkit-scrollbar {\n  width: 10px;\n  background-color: #F5F5F5; }\n::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0.44, #7a99d9), color-stop(0.72, #497dbd), color-stop(0.86, #1c3a94)); }\n.footer-section {\n  position: absolute;\n  bottom: 0;\n  z-index: 1000;\n  background: #fff;\n  width: 100%;\n  height: 24px; }\n.footer-section ul {\n    list-style: none; }\n.footer-section ul.footer-list li {\n      display: inline-block;\n      margin: 5px 20px 0; }\n.footer-section ul.footer-list li i {\n        font-family: FontAwesome; }\n.footer-section a {\n    color: #0084f6; }\n/* Track */\n.danger {\n  color: #ff0000 !important; }\n.btn.active, .btn:active {\n  background-image: none;\n  outline: 0;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n  border-radius: 4px; }\ninput[type=\"button\"], input[type=\"submit\"], input[type=\"reset\"], input[type=\"file\"]::-webkit-file-upload-button, button {\n  border-radius: 4px; }\n:host /deep/ .tooltip-arrow {\n  display: none; }\n::ng-deep .tooltip-arrow {\n  display: none; }\n:host /deep/ .tooltip-left {\n  top: 0 !important;\n  min-width: 300px; }\n::ng-deep .tooltip-left {\n  top: 0; }\n:host /deep/ .tooltip-right {\n  top: calc(10% - 2.5px);\n  left: calc(10% - 2.5px); }\n::ng-deep .tooltip-right {\n  top: calc(10% - 2.5px);\n  left: calc(10% - 2.5px); }\n:host /deep/ .tooltip-top {\n  top: calc(10% - 2.5px);\n  left: calc(10% - 2.5px); }\n::ng-deep .tooltip-top {\n  top: calc(10% - 2.5px);\n  left: calc(10% - 2.5px); }\n:host /deep/ .bs-datepicker .bs-datepicker-container {\n  padding: 10px; }\n.bs-calendar-container div:nth-child(1) {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex; }\n.bs-datepicker-head {\n  display: block !important; }\n:host /deep/ bs-days-calendar-view .bs-datepicker-head {\n  color: white;\n  border-top: 1px solid white;\n  border-left: 1px solid white;\n  border-right: 1px solid white;\n  min-width: 300px !important;\n  font-weight: 800; }\n:host /deep/ bs-days-calendar-view .bs-datepicker-body {\n  padding: 5px; }\n::ng-deep .bs-datepicker-container {\n  padding: 5px; }\n::ng-deep .bs-datepicker-head {\n  color: white;\n  border-top: 1px solid white;\n  border-left: 1px solid white;\n  border-right: 1px solid white;\n  min-width: 300px !important;\n  font-weight: 800; }\n::ng-deep .bs-datepicker-body {\n  padding: 0;\n  border: 1px solid rgba(119, 119, 119, 0.28); }\n::ng-deep .bs-datepicker-body table tbody tr td {\n  padding: 0;\n  border-top: 1px solid rgba(211, 212, 213, 0.5);\n  border-bottom: 1px solid rgba(211, 212, 213, 0.5); }\n:host /deep/ .bs-datepicker-body table tbody tr td {\n  padding: 0;\n  border-top: 1px solid rgba(211, 212, 213, 0.5);\n  border-bottom: 1px solid rgba(211, 212, 213, 0.5); }\n::ng-deep .bs-datepicker-body table thead tr th {\n  font-size: 14px;\n  color: black;\n  font-weight: 600;\n  text-align: center; }\n:host /deep/ .bs-datepicker-body table thead tr th {\n  font-size: 14px;\n  color: black;\n  font-weight: 600;\n  text-align: center; }\n.cursor-icon {\n  cursor: pointer; }\n.table-responsive {\n  max-width: 100%; }\n.table-responsive ::-webkit-scrollbar {\n    display: block; }\n.courses-list-table {\n  max-height: 400px;\n  overflow: auto;\n  padding: 10px;\n  margin-top: 10px;\n  -webkit-box-shadow: 0 2px 5px 0 rgba(38, 0, 0, 0.2);\n          box-shadow: 0 2px 5px 0 rgba(38, 0, 0, 0.2); }\n.courses-list-table ::-webkit-scrollbar {\n    display: block; }\ntextarea {\n  resize: none; }\n.filter-fields .field-wrapper.has-value .form-ctrl + label,\n.filter-fields .field-wrapper .form-ctrl:focus + label {\n  top: 0; }\n.time-picker .field-wrapper {\n  display: inline-block;\n  margin: 5px 10px 0 0; }\n.time-picker .field-wrapper .form-ctrl {\n    width: 70px;\n    z-index: 10; }\n.time-picker .field-wrapper label {\n    font-size: 12px;\n    z-index: 1; }\n.multiselect-wrapper {\n  padding: 5px;\n  border: 1px solid #deeaee;\n  position: absolute;\n  z-index: 100;\n  background: white;\n  min-width: 400px;\n  min-height: 50px;\n  top: 65px; }\n.multiselect-wrapper .multiselect-wrapper-inner {\n    padding: 10px; }\n.multiselect-wrapper .multiselect-wrapper-inner ul li {\n      height: 40px;\n      padding: 10px 0 0 5px; }\ninput[type=\"text\"][disabled] {\n  background: transparent !important; }\n.report-wrapper {\n  background: #efefef;\n  height: 110vh;\n  width: 100%;\n  padding: 5px; }\n.report-wrapper .report-header {\n    background: #fff;\n    padding: 5px; }\n.chipped {\n  color: white !important;\n  font-size: 14px;\n  background: #0084f6;\n  cursor: pointer;\n  border: 2px solid white;\n  border-radius: 32px;\n  display: inline-block;\n  margin: 0 !important;\n  font-weight: 400;\n  padding: .1rem .8rem;\n  outline: none;\n  text-align: center;\n  white-space: nowrap;\n  vertical-align: middle;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  overflow: hidden;\n  position: relative;\n  -webkit-transition: all 0.24s cubic-bezier(0.4, 0, 0.2, 1);\n  transition: all 0.24s cubic-bezier(0.4, 0, 0.2, 1);\n  will-change: padding; }\n.chipped i {\n    color: #99D154;\n    position: absolute;\n    top: 6px;\n    margin-left: 1rem;\n    font-size: 48px;\n    -webkit-transition: all 0.24s cubic-bezier(0.4, 0, 0.2, 1);\n    transition: all 0.24s cubic-bezier(0.4, 0, 0.2, 1);\n    opacity: 0;\n    -webkit-transform: translateX(1rem);\n            transform: translateX(1rem);\n    will-change: opacity, transform; }\n.chipped.small {\n    color: white !important;\n    font-size: 12px !important;\n    background: #0084f6;\n    cursor: pointer;\n    border: 2px solid white;\n    border-radius: 32px;\n    display: inline-block;\n    margin: 0 !important;\n    font-weight: 400;\n    padding: .2rem .5rem; }\n.chipped.intable {\n    color: rgba(30, 35, 40, 0.7) !important;\n    font-size: 12px !important;\n    background: transparent;\n    cursor: pointer;\n    border: 1px solid #64676b;\n    border-radius: 5px;\n    display: inline-block;\n    margin: 0 2px 0 0 !important;\n    font-weight: 400;\n    padding: .2rem; }\n.chipped.active {\n  background-color: #fff;\n  color: #333333;\n  padding-right: 4.5rem; }\n.chipped.active i {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n            transform: translateX(0); }\n/* ================================================================================================= */\n/* ================================================================================================= */\n/* ================================================================================================= */\n/* ================================================================================================= */\n/* ================================================================================================= */\n/* ================================================================================================= */\n.fbold {\n  font-weight: 700; }\n.sbold {\n  font-weight: 600; }\n.fnormal {\n  font-weight: 300; }\n.rupee {\n  font-family: 'WebRupee'; }\n.line-height {\n  line-height: 1.2; }\n.link,\na {\n  text-decoration: none;\n  color: #0084f6; }\n.link:hover,\n  a:hover {\n    text-decoration: none; }\n.small,\n.small *,\np {\n  font-size: 12px; }\n.xsmall,\n.xsmall * {\n  font-size: 10px;\n  line-height: 14px; }\nh1 {\n  font-size: 14px;\n  font-weight: 700;\n  line-height: 1.2; }\nh2 {\n  font-size: 14px;\n  font-weight: 600;\n  line-height: 1.2; }\nh3 {\n  font-size: 14px;\n  font-weight: 600;\n  line-height: 1.2; }\n.container {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0 auto; }\n.clearFix:after,\n.container:after {\n  content: \"\";\n  display: table;\n  clear: both; }\n.common-width {\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  vertical-align: top;\n  display: inline-block; }\n.pull-left {\n  float: left; }\n.pull-right {\n  float: right; }\n.mR10 {\n  margin-right: 10px; }\n.pos-rel {\n  position: relative; }\n.pos-abs {\n  position: absolute; }\n.hide {\n  display: none !important; }\n.show {\n  display: block !important; }\n.display-b {\n  display: block; }\n.display-ib {\n  display: inline-block; }\n.align-right {\n  text-align: right; }\n.align-left {\n  text-align: left; }\n.v-middle {\n  vertical-align: middle; }\n.radius-4 {\n  border-radius: 4px; }\n.overflowHidden {\n  overflow: hidden; }\n/*===============================call grid view css====================*/\n.container,\n.container-fluid {\n  margin-right: auto;\n  margin-left: auto;\n  padding-left: 15px;\n  padding-right: 15px; }\n@media (min-width: 768px) {\n  .container {\n    width: 750px; } }\n@media (min-width: 992px) {\n  .container {\n    width: 970px; } }\n@media (min-width: 1200px) {\n  .container {\n    width: 1170px; } }\n.row {\n  margin-left: -15px;\n  margin-right: -15px; }\n.c-lg-1,\n.c-lg-10,\n.c-lg-11,\n.c-lg-12,\n.c-lg-2,\n.c-lg-3,\n.c-lg-4,\n.c-lg-5,\n.c-lg-6,\n.c-lg-7,\n.c-lg-8,\n.c-lg-9,\n.c-md-1,\n.c-md-10,\n.c-md-11,\n.c-md-12,\n.c-md-2,\n.c-md-3,\n.c-md-4,\n.c-md-5,\n.c-md-6,\n.c-md-7,\n.c-md-8,\n.c-md-9,\n.c-sm-1,\n.c-sm-10,\n.c-sm-11,\n.c-sm-12,\n.c-sm-2,\n.c-sm-3,\n.c-sm-4,\n.c-sm-5,\n.c-sm-6,\n.c-sm-7,\n.c-sm-8,\n.c-sm-9,\n.c-xs-1,\n.c-xs-10,\n.c-xs-11,\n.c-xs-12,\n.c-xs-2,\n.c-xs-3,\n.c-xs-4,\n.c-xs-5,\n.c-xs-6,\n.c-xs-7,\n.c-xs-8,\n.c-xs-9 {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  position: relative;\n  min-height: 1px;\n  padding-left: 15px;\n  padding-right: 15px; }\n.c-xs-1,\n.c-xs-10,\n.c-xs-11,\n.c-xs-12,\n.c-xs-2,\n.c-xs-3,\n.c-xs-4,\n.c-xs-5,\n.c-xs-6,\n.c-xs-7,\n.c-xs-8,\n.c-xs-9 {\n  float: left; }\n.c-xs-12 {\n  width: 100%; }\n.c-xs-11 {\n  width: 91.66666667%; }\n.c-xs-10 {\n  width: 83.33333333%; }\n.c-xs-9 {\n  width: 75%; }\n.c-xs-8 {\n  width: 66.66666667%; }\n.c-xs-7 {\n  width: 58.33333333%; }\n.c-xs-6 {\n  width: 50%; }\n.c-xs-5 {\n  width: 41.66666667%; }\n.c-xs-4 {\n  width: 33.33333333%; }\n.c-xs-3 {\n  width: 25%; }\n.c-xs-2 {\n  width: 16.66666667%; }\n.c-xs-1 {\n  width: 8.33333333%; }\n.c-xs-pull-12 {\n  right: 100%; }\n.c-xs-pull-11 {\n  right: 91.66666667%; }\n.c-xs-pull-10 {\n  right: 83.33333333%; }\n.c-xs-pull-9 {\n  right: 75%; }\n.c-xs-pull-8 {\n  right: 66.66666667%; }\n.c-xs-pull-7 {\n  right: 58.33333333%; }\n.c-xs-pull-6 {\n  right: 50%; }\n.c-xs-pull-5 {\n  right: 41.66666667%; }\n.c-xs-pull-4 {\n  right: 33.33333333%; }\n.c-xs-pull-3 {\n  right: 25%; }\n.c-xs-pull-2 {\n  right: 16.66666667%; }\n.c-xs-pull-1 {\n  right: 8.33333333%; }\n.c-xs-pull-0 {\n  right: auto; }\n.c-xs-push-12 {\n  left: 100%; }\n.c-xs-push-11 {\n  left: 91.66666667%; }\n.c-xs-push-10 {\n  left: 83.33333333%; }\n.c-xs-push-9 {\n  left: 75%; }\n.c-xs-push-8 {\n  left: 66.66666667%; }\n.c-xs-push-7 {\n  left: 58.33333333%; }\n.c-xs-push-6 {\n  left: 50%; }\n.c-xs-push-5 {\n  left: 41.66666667%; }\n.c-xs-push-4 {\n  left: 33.33333333%; }\n.c-xs-push-3 {\n  left: 25%; }\n.c-xs-push-2 {\n  left: 16.66666667%; }\n.c-xs-push-1 {\n  left: 8.33333333%; }\n.c-xs-push-0 {\n  left: auto; }\n.c-xs-offset-12 {\n  margin-left: 100%; }\n.c-xs-offset-11 {\n  margin-left: 91.66666667%; }\n.c-xs-offset-10 {\n  margin-left: 83.33333333%; }\n.c-xs-offset-9 {\n  margin-left: 75%; }\n.c-xs-offset-8 {\n  margin-left: 66.66666667%; }\n.c-xs-offset-7 {\n  margin-left: 58.33333333%; }\n.c-xs-offset-6 {\n  margin-left: 50%; }\n.c-xs-offset-5 {\n  margin-left: 41.66666667%; }\n.c-xs-offset-4 {\n  margin-left: 33.33333333%; }\n.c-xs-offset-3 {\n  margin-left: 25%; }\n.c-xs-offset-2 {\n  margin-left: 16.66666667%; }\n.c-xs-offset-1 {\n  margin-left: 8.33333333%; }\n.c-xs-offset-0 {\n  margin-left: 0; }\n@media (min-width: 768px) {\n  .c-sm-1,\n  .c-sm-10,\n  .c-sm-11,\n  .c-sm-12,\n  .c-sm-2,\n  .c-sm-3,\n  .c-sm-4,\n  .c-sm-5,\n  .c-sm-6,\n  .c-sm-7,\n  .c-sm-8,\n  .c-sm-9 {\n    float: left; }\n  .c-sm-12 {\n    width: 100%; }\n  .c-sm-11 {\n    width: 91.66666667%; }\n  .c-sm-10 {\n    width: 83.33333333%; }\n  .c-sm-9 {\n    width: 75%; }\n  .c-sm-8 {\n    width: 66.66666667%; }\n  .c-sm-7 {\n    width: 58.33333333%; }\n  .c-sm-6 {\n    width: 50%; }\n  .c-sm-5 {\n    width: 41.66666667%; }\n  .c-sm-4 {\n    width: 33.33333333%; }\n  .c-sm-3 {\n    width: 25%; }\n  .c-sm-2 {\n    width: 16.66666667%; }\n  .c-sm-1 {\n    width: 8.33333333%; }\n  .c-sm-pull-12 {\n    right: 100%; }\n  .c-sm-pull-11 {\n    right: 91.66666667%; }\n  .c-sm-pull-10 {\n    right: 83.33333333%; }\n  .c-sm-pull-9 {\n    right: 75%; }\n  .c-sm-pull-8 {\n    right: 66.66666667%; }\n  .c-sm-pull-7 {\n    right: 58.33333333%; }\n  .c-sm-pull-6 {\n    right: 50%; }\n  .c-sm-pull-5 {\n    right: 41.66666667%; }\n  .c-sm-pull-4 {\n    right: 33.33333333%; }\n  .c-sm-pull-3 {\n    right: 25%; }\n  .c-sm-pull-2 {\n    right: 16.66666667%; }\n  .c-sm-pull-1 {\n    right: 8.33333333%; }\n  .c-sm-pull-0 {\n    right: auto; }\n  .c-sm-push-12 {\n    left: 100%; }\n  .c-sm-push-11 {\n    left: 91.66666667%; }\n  .c-sm-push-10 {\n    left: 83.33333333%; }\n  .c-sm-push-9 {\n    left: 75%; }\n  .c-sm-push-8 {\n    left: 66.66666667%; }\n  .c-sm-push-7 {\n    left: 58.33333333%; }\n  .c-sm-push-6 {\n    left: 50%; }\n  .c-sm-push-5 {\n    left: 41.66666667%; }\n  .c-sm-push-4 {\n    left: 33.33333333%; }\n  .c-sm-push-3 {\n    left: 25%; }\n  .c-sm-push-2 {\n    left: 16.66666667%; }\n  .c-sm-push-1 {\n    left: 8.33333333%; }\n  .c-sm-push-0 {\n    left: auto; }\n  .c-sm-offset-12 {\n    margin-left: 100%; }\n  .c-sm-offset-11 {\n    margin-left: 91.66666667%; }\n  .c-sm-offset-10 {\n    margin-left: 83.33333333%; }\n  .c-sm-offset-9 {\n    margin-left: 75%; }\n  .c-sm-offset-8 {\n    margin-left: 66.66666667%; }\n  .c-sm-offset-7 {\n    margin-left: 58.33333333%; }\n  .c-sm-offset-6 {\n    margin-left: 50%; }\n  .c-sm-offset-5 {\n    margin-left: 41.66666667%; }\n  .c-sm-offset-4 {\n    margin-left: 33.33333333%; }\n  .c-sm-offset-3 {\n    margin-left: 25%; }\n  .c-sm-offset-2 {\n    margin-left: 16.66666667%; }\n  .c-sm-offset-1 {\n    margin-left: 8.33333333%; }\n  .c-sm-offset-0 {\n    margin-left: 0; } }\n@media (min-width: 992px) {\n  .c-md-1,\n  .c-md-10,\n  .c-md-11,\n  .c-md-12,\n  .c-md-2,\n  .c-md-3,\n  .c-md-4,\n  .c-md-5,\n  .c-md-6,\n  .c-md-7,\n  .c-md-8,\n  .c-md-9 {\n    float: left; }\n  .c-md-12 {\n    width: 100%; }\n  .c-md-11 {\n    width: 91.66666667%; }\n  .c-md-10 {\n    width: 83.33333333%; }\n  .c-md-9 {\n    width: 75%; }\n  .c-md-8 {\n    width: 66.66666667%; }\n  .c-md-7 {\n    width: 58.33333333%; }\n  .c-md-6 {\n    width: 50%; }\n  .c-md-5 {\n    width: 41.66666667%; }\n  .c-md-4 {\n    width: 33.33333333%; }\n  .c-md-3 {\n    width: 25%; }\n  .c-md-2 {\n    width: 16.66666667%; }\n  .c-md-1 {\n    width: 8.33333333%; }\n  .c-md-pull-12 {\n    right: 100%; }\n  .c-md-pull-11 {\n    right: 91.66666667%; }\n  .c-md-pull-10 {\n    right: 83.33333333%; }\n  .c-md-pull-9 {\n    right: 75%; }\n  .c-md-pull-8 {\n    right: 66.66666667%; }\n  .c-md-pull-7 {\n    right: 58.33333333%; }\n  .c-md-pull-6 {\n    right: 50%; }\n  .c-md-pull-5 {\n    right: 41.66666667%; }\n  .c-md-pull-4 {\n    right: 33.33333333%; }\n  .c-md-pull-3 {\n    right: 25%; }\n  .c-md-pull-2 {\n    right: 16.66666667%; }\n  .c-md-pull-1 {\n    right: 8.33333333%; }\n  .c-md-pull-0 {\n    right: auto; }\n  .c-md-push-12 {\n    left: 100%; }\n  .c-md-push-11 {\n    left: 91.66666667%; }\n  .c-md-push-10 {\n    left: 83.33333333%; }\n  .c-md-push-9 {\n    left: 75%; }\n  .c-md-push-8 {\n    left: 66.66666667%; }\n  .c-md-push-7 {\n    left: 58.33333333%; }\n  .c-md-push-6 {\n    left: 50%; }\n  .c-md-push-5 {\n    left: 41.66666667%; }\n  .c-md-push-4 {\n    left: 33.33333333%; }\n  .c-md-push-3 {\n    left: 25%; }\n  .c-md-push-2 {\n    left: 16.66666667%; }\n  .c-md-push-1 {\n    left: 8.33333333%; }\n  .c-md-push-0 {\n    left: auto; }\n  .c-md-offset-12 {\n    margin-left: 100%; }\n  .c-md-offset-11 {\n    margin-left: 91.66666667%; }\n  .c-md-offset-10 {\n    margin-left: 83.33333333%; }\n  .c-md-offset-9 {\n    margin-left: 75%; }\n  .c-md-offset-8 {\n    margin-left: 66.66666667%; }\n  .c-md-offset-7 {\n    margin-left: 58.33333333%; }\n  .c-md-offset-6 {\n    margin-left: 50%; }\n  .c-md-offset-5 {\n    margin-left: 41.66666667%; }\n  .c-md-offset-4 {\n    margin-left: 33.33333333%; }\n  .c-md-offset-3 {\n    margin-left: 25%; }\n  .c-md-offset-2 {\n    margin-left: 16.66666667%; }\n  .c-md-offset-1 {\n    margin-left: 8.33333333%; }\n  .c-md-offset-0 {\n    margin-left: 0; } }\n@media (min-width: 1200px) {\n  .c-lg-1,\n  .c-lg-10,\n  .c-lg-11,\n  .c-lg-12,\n  .c-lg-2,\n  .c-lg-3,\n  .c-lg-4,\n  .c-lg-5,\n  .c-lg-6,\n  .c-lg-7,\n  .c-lg-8,\n  .c-lg-9 {\n    float: left; }\n  .c-lg-12 {\n    width: 100%; }\n  .c-lg-11 {\n    width: 91.66666667%; }\n  .c-lg-10 {\n    width: 83.33333333%; }\n  .c-lg-9 {\n    width: 75%; }\n  .c-lg-8 {\n    width: 66.66666667%; }\n  .c-lg-7 {\n    width: 58.33333333%; }\n  .c-lg-6 {\n    width: 50%; }\n  .c-lg-5 {\n    width: 41.66666667%; }\n  .c-lg-4 {\n    width: 33.33333333%; }\n  .c-lg-3 {\n    width: 25%; }\n  .c-lg-2 {\n    width: 16.66666667%; }\n  .c-lg-1 {\n    width: 8.33333333%; }\n  .c-lg-pull-12 {\n    right: 100%; }\n  .c-lg-pull-11 {\n    right: 91.66666667%; }\n  .c-lg-pull-10 {\n    right: 83.33333333%; }\n  .c-lg-pull-9 {\n    right: 75%; }\n  .c-lg-pull-8 {\n    right: 66.66666667%; }\n  .c-lg-pull-7 {\n    right: 58.33333333%; }\n  .c-lg-pull-6 {\n    right: 50%; }\n  .c-lg-pull-5 {\n    right: 41.66666667%; }\n  .c-lg-pull-4 {\n    right: 33.33333333%; }\n  .c-lg-pull-3 {\n    right: 25%; }\n  .c-lg-pull-2 {\n    right: 16.66666667%; }\n  .c-lg-pull-1 {\n    right: 8.33333333%; }\n  .c-lg-pull-0 {\n    right: auto; }\n  .c-lg-push-12 {\n    left: 100%; }\n  .c-lg-push-11 {\n    left: 91.66666667%; }\n  .c-lg-push-10 {\n    left: 83.33333333%; }\n  .c-lg-push-9 {\n    left: 75%; }\n  .c-lg-push-8 {\n    left: 66.66666667%; }\n  .c-lg-push-7 {\n    left: 58.33333333%; }\n  .c-lg-push-6 {\n    left: 50%; }\n  .c-lg-push-5 {\n    left: 41.66666667%; }\n  .c-lg-push-4 {\n    left: 33.33333333%; }\n  .c-lg-push-3 {\n    left: 25%; }\n  .c-lg-push-2 {\n    left: 16.66666667%; }\n  .c-lg-push-1 {\n    left: 8.33333333%; }\n  .c-lg-push-0 {\n    left: auto; }\n  .c-lg-offset-12 {\n    margin-left: 100%; }\n  .c-lg-offset-11 {\n    margin-left: 91.66666667%; }\n  .c-lg-offset-10 {\n    margin-left: 83.33333333%; }\n  .c-lg-offset-9 {\n    margin-left: 75%; }\n  .c-lg-offset-8 {\n    margin-left: 66.66666667%; }\n  .c-lg-offset-7 {\n    margin-left: 58.33333333%; }\n  .c-lg-offset-6 {\n    margin-left: 50%; }\n  .c-lg-offset-5 {\n    margin-left: 41.66666667%; }\n  .c-lg-offset-4 {\n    margin-left: 33.33333333%; }\n  .c-lg-offset-3 {\n    margin-left: 25%; }\n  .c-lg-offset-2 {\n    margin-left: 16.66666667%; }\n  .c-lg-offset-1 {\n    margin-left: 8.33333333%; }\n  .c-lg-offset-0 {\n    margin-left: 0; } }\n.clearfix:after,\n.clearfix:before,\n.container-fluid:after,\n.container-fluid:before,\n.container:after,\n.container:before,\n.row:after,\n.row:before {\n  content: \" \";\n  display: table; }\n.clearfix:after,\n.container-fluid:after,\n.container:after,\n.row:after {\n  clear: both; }\n/* ========================================== Common Fields CSS============================*/\n.table-responsive {\n  max-width: 100%; }\n.filter-fields .field-wrapper.has-value .form-ctrl + label,\n.filter-fields .field-wrapper .form-ctrl:focus + label {\n  top: 0; }\n/* For DatePicker */\n.field-wrapper {\n  position: relative;\n  padding-top: 10px; }\n.field-wrapper .form-ctrl {\n    z-index: 10; }\n.field-wrapper.datePickerBox .form-ctrl {\n    cursor: pointer;\n    position: relative;\n    z-index: 10;\n    background: transparent; }\n.field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"/./assets/images/calendar.svg\") no-repeat;\n    position: absolute;\n    right: 5px;\n    top: 28px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.field-wrapper .date-clear {\n    position: absolute;\n    right: -35px;\n    top: 35px;\n    cursor: pointer;\n    color: #0084f6; }\n.field-wrapper label {\n    font-size: 12px;\n    z-index: 1; }\n/* text field  */\n.field-wrapper .form-ctrl {\n  display: block;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 5px;\n  outline: none;\n  border: solid 1px #e2ebee;\n  background: #fff;\n  z-index: 10;\n  font: 400 12px 'Open sans',sans-serif;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n  border-radius: 0;\n  color: #000; }\n.field-wrapper .form-ctrl.form-ctrl-multiple {\n    height: 100px;\n    overflow-y: auto; }\n.field-wrapper .form-ctrl:focus {\n  border: solid 2px #0084f6;\n  -webkit-box-shadow: none;\n          box-shadow: none; }\n.field-wrapper .form-ctrl:focus + label,\n.field-wrapper.has-value .form-ctrl + label {\n  font-size: 12px;\n  top: 6px;\n  left: 0; }\n.field-wrapper .form-ctrl:focus + label,\n.field-wrapper.has-value .form-ctrl + label {\n  color: #0084f6;\n  font-size: 12px; }\n/*radio button  */\n.field-checkbox-wrapper,\n.field-radio-wrapper {\n  position: relative;\n  padding-left: 25px;\n  margin-bottom: 10px; }\n.field-radio-wrapper .form-radio {\n  opacity: 0;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px;\n  z-index: 1; }\n.field-radio-wrapper .form-radio + label {\n  vertical-align: middle;\n  -webkit-transition: all .1s;\n  transition: all .1s; }\n.field-radio-wrapper .form-radio + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 50%;\n  position: absolute;\n  left: 0;\n  top: 0;\n  -webkit-transition: all .1s;\n  transition: all .1s; }\n.field-radio-wrapper .form-radio:checked + label:after {\n  border: 2px solid #0084f6; }\n.field-radio-wrapper .form-radio + label:before {\n  -webkit-transition: all .1s;\n  transition: all .1s;\n  width: 1px;\n  height: 1px;\n  left: 9px;\n  top: 9px;\n  position: absolute;\n  content: ''; }\n.field-radio-wrapper .form-radio:checked + label:before {\n  content: '';\n  width: 10px;\n  height: 10px;\n  background: #0084f6;\n  border-radius: 50%;\n  left: 3px;\n  top: 3px; }\n.field-radio-wrapper .form-radio:checked + label {\n  color: #0084f6; }\n/*checkbox  */\n.field-checkbox-wrapper .form-checkbox {\n  opacity: 0;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px;\n  z-index: 1; }\n.field-checkbox-wrapper .form-checkbox + label {\n  vertical-align: middle;\n  font-size: 14px;\n  display: inline-block; }\n.field-checkbox-wrapper .form-checkbox + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 2px;\n  position: absolute;\n  left: 0;\n  top: 0; }\n.field-checkbox-wrapper .form-checkbox:checked + label:after {\n  border: 2px solid #0084f6; }\n.field-checkbox-wrapper .form-checkbox + label:before {\n  width: 1px;\n  height: 1px;\n  left: 8px;\n  top: 9px;\n  position: absolute;\n  content: '';\n  border-top: 0;\n  border-right: 0;\n  border-left: 2px solid transparent;\n  border-bottom: 2px solid transparent;\n  -webkit-transform: rotate(-45deg);\n          transform: rotate(-45deg); }\n.field-checkbox-wrapper .form-checkbox:checked + label:before {\n  border-left: 2px solid #0084f6;\n  border-bottom: 2px solid #0084f6;\n  width: 12px;\n  height: 5px;\n  left: 2px;\n  top: 5px; }\n.field-checkbox-wrapper .form-checkbox:checked + label {\n  color: #0084f6; }\n/*navigation   */\n.useFul li {\n  list-style-type: none; }\n.useFul nav {\n  margin-left: 200px; }\n/*===========================================common Table CSS===============================*/\n.mb0,\n.middle-top.mb0 {\n  margin-bottom: 0; }\n.align-center {\n  text-align: center; }\ntable {\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  border-collapse: collapse;\n  overflow-y: hidden; }\ntd,\nth {\n  font-size: 14px;\n  padding: 6px 2px;\n  vertical-align: middle; }\nth {\n  background: #fff;\n  font-size: 12px !important;\n  color: #000000;\n  font-weight: 600;\n  padding: 20px 10px;\n  border-top: 2px solid rgba(119, 119, 119, 0.11); }\nth label {\n    font-size: 14px !important;\n    color: #000000; }\nth a {\n    font-size: 14px !important;\n    color: #000000; }\nth:first-child {\n    border-top-left-radius: 5px; }\nth.No {\n    text-align: right; }\nth.Name {\n    text-align: left; }\nth.Contact {\n    text-align: right; }\nth.Date {\n    text-align: right; }\ntd {\n  border-bottom: 1px solid #fff; }\ntd.No {\n    text-align: right; }\ntd.Name {\n    text-align: left; }\ntd.Contact {\n    text-align: right; }\ntd.Date {\n    text-align: right; }\ntable tr {\n  -webkit-transition: all .1s;\n  transition: all .1s; }\ntable tr {\n  background: #ffffff;\n  border-left: 1px solid rgba(211, 212, 213, 0.5);\n  border-right: 1px solid rgba(211, 212, 213, 0.5);\n  cursor: pointer; }\ntable tr td {\n    border-top: 1px solid rgba(211, 212, 213, 0.5);\n    border-bottom: 2px solid rgba(211, 212, 213, 0.5);\n    padding: 5px 15px;\n    font-size: 14px; }\ntable tr:nth-child(even):hover {\n  background: #ececec; }\ntable tr:nth-child(odd):hover {\n  background: #eaeaea; }\ntable tr.selected {\n  background: #dceff7 !important;\n  -webkit-box-shadow: 0 11px 8px -10px #CCC, 0 -11px 13px -9px #CCC;\n          box-shadow: 0 11px 8px -10px #CCC, 0 -11px 13px -9px #CCC;\n  -webkit-transform: scale(1);\n          transform: scale(1); }\n.table-responsive tr td:first-child .field-checkbox-wrapper,\n.table-responsive tr th:first-child .field-checkbox-wrapper {\n  width: 20px;\n  overflow: hidden;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 20px;\n  padding-left: 20px;\n  margin-bottom: 0;\n  margin-left: 5px;\n  background: transparent;\n  border-radius: 2px; }\n.enquiry-status label {\n  display: block;\n  font-weight: 600; }\n.progress-status {\n  color: dodgerblue; }\n.inactive-status,\n.open-status {\n  color: #333; }\n.admitted-status {\n  color: green; }\n.btn {\n  padding: 6px 10px;\n  background: #fff;\n  border: 1px solid #ccc;\n  margin-left: 10px;\n  display: inline-block;\n  font-size: 14px;\n  font-weight: 600;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  /* height: 35px; */\n  cursor: pointer;\n  color: #0084f6;\n  border-radius: 4px; }\n.btn.fullBlue {\n  background: #0084f6;\n  border: 1px solid #0084f6;\n  color: #fff;\n  padding: 4px 10px;\n  border-radius: 4px; }\n.btn.cancle {\n  background: #fff;\n  border: 1px solid #ccc;\n  color: #0084f6;\n  font-size: 14px;\n  padding: 6px 10px;\n  border-radius: 4px; }\n.btn.redBtn {\n  background: #f44336;\n  border: 1px solid #f44336;\n  color: #fff;\n  font-size: 14px; }\n.btn.normal-btn {\n  margin: 0; }\n.middle-bottom .btn.redBtn {\n  margin-right: 0; }\n.customSelectWrapper select {\n  -webkit-appearance: none;\n  -moz-appearance: none;\n  -o-appearance: none;\n  -ms-appearance: none;\n  appearance: none;\n  position: relative;\n  z-index: 1;\n  background: transparent; }\n.customSelectWrapper:after {\n  display: inline-block;\n  font: normal normal normal 14px/1 FontAwesome;\n  font-size: inherit;\n  text-rendering: auto;\n  -webkit-font-smoothing: antialiased;\n  content: \"\\f107\";\n  font-size: 22px;\n  position: absolute;\n  right: 0;\n  top: 20px; }\n.box-shadow-lite .field-wrapper.customSelectWrapper:after {\n  right: 40px; }\n.field-wrapper.customSelectWrapper label {\n  top: 13px;\n  width: 100%;\n  height: 22px;\n  padding-top: 10px;\n  z-index: 2; }\n.field-wrapper.customSelectWrapper .form-ctrl:focus + label,\n.field-wrapper.customSelectWrapper.has-value label {\n  padding-top: 0;\n  height: 42px; }\n.customSelectWrapper .form-ctrl option {\n  opacity: 0;\n  visibility: hidden;\n  display: none; }\n.open-accor {\n  float: right;\n  width: 24px;\n  font-size: 24px;\n  height: 24px;\n  text-align: center;\n  border: none;\n  border-radius: 50%;\n  line-height: 24px;\n  margin-right: 4px;\n  margin-top: 3px;\n  cursor: pointer;\n  color: #0084f6;\n  cursor: pointer; }\n.hasError .form-ctrl,\n.hasError.form-ctrl {\n  color: red;\n  border-color: red !important; }\np.error-msg {\n  color: red; }\n.middle-bottom .questionInfo {\n  display: inline-block;\n  position: static;\n  margin-left: 10px;\n  vertical-align: middle; }\n.next {\n  position: relative;\n  padding-right: 12px;\n  font-size: 12px;\n  font-weight: 600; }\n.next:after {\n    display: inline-block;\n    font: normal normal normal 14px/1 FontAwesome;\n    font-size: inherit;\n    text-rendering: auto;\n    -webkit-font-smoothing: antialiased;\n    content: \"\\f105\";\n    font-size: 17px;\n    position: absolute;\n    right: 0;\n    top: 0; }\n.next:hover {\n    text-decoration: underline; }\n.prev {\n  position: relative;\n  padding-left: 12px;\n  font-size: 12px;\n  font-weight: 600;\n  margin-right: 30px; }\n.prev:after {\n    display: inline-block;\n    font: normal normal normal 14px/1 FontAwesome;\n    font-size: inherit;\n    text-rendering: auto;\n    -webkit-font-smoothing: antialiased;\n    content: \"\\f104\";\n    font-size: 17px;\n    position: absolute;\n    left: 0;\n    top: 0; }\n.prev:hover {\n    text-decoration: underline; }\n.form-type1 h2,\n.form-type2 h2 {\n  margin-top: 15px;\n  font-size: 15px; }\n.other-heading h2,\n.other-heading h4 {\n  font-size: 16px;\n  margin-bottom: 10px;\n  font-weight: 600; }\n.other-heading h2 a,\n  .other-heading h4 a {\n    display: inline-block;\n    margin-top: 3px;\n    font-size: 12px; }\n.other-heading h2 .close-btns,\n  .other-heading h4 .close-btns {\n    float: right;\n    cursor: pointer;\n    width: 20px;\n    text-align: center; }\n.other-heading h2 .close-btns svg,\n    .other-heading h4 .close-btns svg {\n      width: 13px;\n      stroke-width: 2px; }\n.other-heading h2 .close-btns svg .cls-1,\n      .other-heading h4 .close-btns svg .cls-1 {\n        stroke: #333; }\n.other-heading h2 .close-btns:hover svg .cls-1,\n    .other-heading h4 .close-btns:hover svg .cls-1 {\n      stroke: #0084f6; }\n.info-icon {\n  width: 17px;\n  height: 17px;\n  border-radius: 50%;\n  border: 1px solid #333;\n  display: inline-block;\n  vertical-align: middle;\n  font-size: 12px;\n  text-align: center;\n  font-weight: bold;\n  padding-top: 1px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  cursor: pointer;\n  position: relative;\n  margin: 0 5px; }\n.add-edit {\n  margin-top: 15px;\n  margin-bottom: 15px;\n  font-size: 12px;\n  font-weight: 600; }\n.add-edit a {\n    margin-right: 15px; }\n.form-new-field {\n  background: transparent;\n  width: 60px;\n  text-align: center;\n  border: 0;\n  border-bottom: 1px solid #ccc;\n  padding: 6px 0; }\nselect.form-new-field {\n  width: 110px; }\n.tooltip-box {\n  position: absolute;\n  width: 150px;\n  min-height: 30px;\n  background: #fff;\n  border: 1px solid #ccc;\n  left: -150px;\n  z-index: 1;\n  top: -8px;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all .1s linear .1s;\n  transition: all .1s linear .1s;\n  font-size: 11px;\n  border-radius: 4px;\n  padding: 3px 5px;\n  -webkit-box-shadow: 0 0 4px #ccc;\n          box-shadow: 0 0 4px #ccc; }\n.tooltip-box:after {\n    content: '';\n    width: 0;\n    height: 0;\n    border-left: 8px solid #fff;\n    border-top: 8px solid transparent;\n    border-bottom: 8px solid transparent;\n    position: absolute;\n    right: -8px;\n    top: 0;\n    bottom: 0;\n    margin: auto; }\n.tooltip-box-field {\n  position: absolute;\n  width: 130px;\n  min-height: 30px;\n  background: #e0e0e0;\n  border: 1px solid #ccc;\n  left: 16px;\n  z-index: 1;\n  top: -2px;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all .1s linear .1s;\n  transition: all .1s linear .1s;\n  font-size: 11px;\n  border-radius: 4px;\n  padding: 3px 5px;\n  -webkit-box-shadow: 0 0 4px #ccc;\n          box-shadow: 0 0 4px #ccc; }\n.tooltip-box-field:after {\n    content: '';\n    width: 0;\n    height: 0;\n    border-right: 8px solid #e0e0e0;\n    border-top: 8px solid transparent;\n    border-bottom: 8px solid transparent;\n    position: absolute;\n    left: -7px;\n    top: 4px;\n    bottom: 0;\n    /* margin: auto; */ }\n.middle-top .questionInfo {\n  position: relative; }\n.middle-top .questionInfo .tooltip-box-field {\n    left: auto;\n    right: 16px; }\n.middle-top .questionInfo .tooltip-box-field:after {\n      -webkit-transform: rotate(180deg);\n              transform: rotate(180deg);\n      right: -7px;\n      left: auto; }\n.middle-top .questionInfo:hover .tooltip-box-field {\n    left: auto;\n    right: 28px; }\n.middle-top .questionInfo:hover .tooltip-box-field:after {\n      -webkit-transform: rotate(180deg);\n              transform: rotate(180deg);\n      right: -7px;\n      left: auto; }\n.questionInfo.pos-rel {\n  position: relative; }\n.info-tool {\n  display: inline-block; }\n.info-tool .tooltip-box-field {\n    width: 100px;\n    left: 0; }\n.info-tool:hover .tooltip-box-field,\n.questionInfo:hover .tooltip-box-field {\n  visibility: visible;\n  opacity: 1;\n  left: 28px; }\n.questionInfo.inline-relative {\n  display: inline-block;\n  position: relative; }\n.tooltip-table:hover .tooltip-box {\n  visibility: visible;\n  opacity: 1;\n  left: -140px; }\n.nav-tab {\n  max-width: 700px;\n  margin: 10px auto;\n  font-size: 0; }\n.nav-tab li {\n    width: 15%;\n    display: inline-block;\n    vertical-align: top;\n    position: relative;\n    margin: 0 5%; }\n.nav-tab li div {\n      display: inline-block;\n      text-align: center;\n      position: relative;\n      cursor: pointer; }\n.nav-tab li div:after {\n        content: '';\n        position: absolute;\n        width: 166px;\n        height: 2px;\n        background: #ccc;\n        right: 50%;\n        top: -24px;\n        bottom: 0;\n        margin: auto; }\n.nav-tab li div span {\n        border: 1px solid #ccc;\n        width: 30px;\n        height: 30px;\n        border-radius: 50%;\n        background: #ddd;\n        display: inline-block;\n        text-align: center;\n        line-height: 30px;\n        position: relative;\n        z-index: 1;\n        font-weight: 600;\n        font-size: 14px; }\n.nav-tab li div p {\n        font-weight: 600;\n        color: #888;\n        margin-top: 10px; }\n.nav-tab li:first-child div:after {\n      display: none; }\n.nav-tab li.active div span, .nav-tab li.tab-completed div span {\n      border-color: #0084f6;\n      color: #fff;\n      background: #0084f6; }\n.nav-tab li.active div:after, .nav-tab li.tab-completed div:after {\n      background: #0084f6; }\n.nav-tab li.active div p, .nav-tab li.tab-completed div p {\n      color: #0084f6; }\n.student-table.table-responsive tr td:first-child .field-checkbox-wrapper,\n.student-table.table-responsive tr th:first-child .field-checkbox-wrapper {\n  display: inline-block; }\n@media only screen and (max-width: 767px) {\n  .nav-tab {\n    max-width: 300px; }\n  .nav-tab li div:after {\n    width: 73px;\n    bottom: auto;\n    margin: 0;\n    top: 15px; }\n  .tooltip-box-field {\n    right: 16px;\n    left: auto; }\n  .questionInfo:hover .tooltip-box-field {\n    right: 28px;\n    left: auto; }\n  .tooltip-box-field:after {\n    -webkit-transform: rotate(180deg);\n            transform: rotate(180deg);\n    right: -7px;\n    left: auto; }\n  .info-tool:hover .tooltip-box-field {\n    left: 28px;\n    right: auto; }\n    .info-tool:hover .tooltip-box-field:after {\n      -webkit-transform: rotate(0deg);\n              transform: rotate(0deg);\n      right: auto;\n      left: -7px; }\n  .export-print .export-icon,\n  .export-print .report-icon {\n    margin-left: 0 !important; }\n  .middle-top .questionInfo:hover .tooltip-box-field {\n    left: 28px;\n    right: auto; }\n    .middle-top .questionInfo:hover .tooltip-box-field:after {\n      -webkit-transform: rotate(0deg);\n              transform: rotate(0deg);\n      left: -7px;\n      right: auto; } }\n/*======================================common menu icon=====================*/\n.edit-icon {\n  background: url(\"/../assets/images/edit_details.svg\") no-repeat;\n  width: 19px;\n  height: 19px;\n  display: inline-block;\n  vertical-align: middle; }\ninput:-webkit-autofill {\n  -webkit-box-shadow: 0 0 0 1000px white inset !important; }\n.view-icon {\n  background: url(\"/./assets/images/view_details.svg\") no-repeat;\n  width: 13px;\n  height: 15px;\n  display: inline-block;\n  vertical-align: middle; }\n.alert-danger {\n  color: red !important;\n  background-color: transparent !important;\n  border: none !important; }\n.alert {\n  padding: 0 !important;\n  margin-bottom: 0 !important; }\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all .5s ease-in;\n  transition: all .5s ease-in; }\n.popupWrapper .popup {\n    max-width: 60%;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popupWrapper .popup.large {\n      max-width: 80%;\n      width: 100%;\n      height: auto;\n      left: 0;\n      right: 0;\n      top: 2%;\n      bottom: 0;\n      margin: auto; }\n.popupWrapper .popup.small {\n      max-width: 40%;\n      width: 100%;\n      height: auto;\n      left: 0;\n      right: 0;\n      top: 5%;\n      bottom: 0;\n      margin: auto; }\n.popupWrapper .popup ::-webkit-scrollbar {\n      display: block;\n      width: 7px;\n      height: 7px; }\n.popup-wrapper {\n  padding: 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 14px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.popup-content .row {\n    margin: 0; }\n.popup-content .content-wrapper {\n    margin: 5px;\n    max-height: 480px;\n    overflow: hidden; }\n.popup-content .content-wrapper .content-scroller {\n      max-height: 475px;\n      overflow-x: hidden;\n      overflow-y: scroll; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all .5s ease-in;\n  transition: all .5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all .5s ease-in;\n  transition: all .5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n.sdb {\n  cursor: pointer; }\n.sdb > li {\n    padding: 8px 0;\n    border-bottom: 2px solid rgba(211, 212, 213, 0.2);\n    margin-bottom: 16px;\n    cursor: pointer; }\n.sdb > li:last-child {\n      border-bottom: 0;\n      margin-bottom: 0; }\n.sdb > li h5 {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: justify;\n          -ms-flex-pack: justify;\n              justify-content: space-between;\n      color: #1e2328;\n      font-size: 14px;\n      cursor: pointer;\n      margin-bottom: 12px; }\n.sdb > li h5 span {\n        text-transform: uppercase;\n        opacity: .8;\n        margin-bottom: 4px;\n        font-weight: 600;\n        cursor: pointer; }\n.sdb > li h6 {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: justify;\n          -ms-flex-pack: justify;\n              justify-content: space-between;\n      color: #1e2328;\n      font-size: 12px;\n      cursor: pointer;\n      margin-bottom: 12px; }\n.sdb > li h6 span {\n        text-transform: uppercase;\n        opacity: .8;\n        margin-bottom: 4px;\n        font-weight: 600;\n        cursor: pointer; }\n.in-student-list > li {\n  margin-bottom: 0;\n  cursor: pointer; }\n.in-student-list > li a {\n    display: block;\n    margin: 0 -15px;\n    padding: 8px 15px;\n    cursor: pointer; }\n.in-student-list > li a:hover {\n      background: rgba(27, 96, 163, 0.0901961); }\n.in-student-list > li a img {\n      float: left;\n      width: 24px;\n      height: 24px;\n      border-radius: 50%;\n      margin-right: 12px;\n      cursor: pointer; }\n.in-student-list > li a .sdb-right {\n      display: block;\n      overflow: hidden;\n      color: rgba(30, 35, 40, 0.7);\n      cursor: pointer; }\n.in-student-list > li a .sdb-right label {\n        display: block;\n        margin-bottom: 6px;\n        cursor: pointer; }\n.in-student-list > li a .sdb-right label strong {\n          font-weight: 600; }\n.in-student-list > li a .sdb-right label.recent {\n          display: inline-block;\n          margin-bottom: 6px;\n          color: rgba(30, 35, 40, 0.7);\n          width: 85%; }\n.in-student-list > li a .sdb-right label.delete {\n          display: inline-block;\n          margin-bottom: 6px;\n          color: rgba(30, 35, 40, 0.7);\n          width: 10%; }\n.in-student-list > li a .sdb-right label.delete img {\n            float: left;\n            width: 14px;\n            height: 14px;\n            border-radius: 50%;\n            margin-right: 0;\n            cursor: pointer; }\n.in-student-list > li a .sdb-right span {\n        font-size: 12px;\n        cursor: pointer; }\n.in-student-list > li a.markers {\n      display: inline-block;\n      margin: 0;\n      padding: 8px 10px; }\n.in-student-list .holder li:last-child {\n  display: none; }\n.in-student-list .holder:hover li:last-child {\n  display: block; }\n.dropdown ul {\n  cursor: pointer; }\n/* import header css*/\n/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/*====================main section css===============*/\nmain {\n  padding-left: 150px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  position: relative; }\n.common-nav {\n  position: fixed;\n  left: 0;\n  top: 0;\n  height: 100%;\n  width: 70px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  z-index: 102; }\n/* @font-face {\r\n    font-family: 'Open Sans';\r\n    font-style: normal;\r\n    font-weight: 700;\r\n    src: local(\"Open Sans Bold\"), local(\"OpenSans-Bold\"), url(https://themes.googleusercontent.com/static/fonts/opensans/v6/k3k702ZOKiLJc3WVjuplzHhCUOGz7vYGh680lGh-uXM.woff) format(\"woff\");\r\n}\r\n\r\n@font-face {\r\n    font-family: 'Open Sans';\r\n    font-style: normal;\r\n    font-weight: 300;\r\n    src: local(\"Open Sans Light\"), local(\"OpenSans-Light\"), url(https://themes.googleusercontent.com/static/fonts/opensans/v6/DXI1ORHCpsQm3Vp6mXoaTXhCUOGz7vYGh680lGh-uXM.woff) format(\"woff\");\r\n}\r\n\r\n@font-face {\r\n    font-family: 'Open Sans';\r\n    font-style: normal;\r\n    font-weight: 600;\r\n    src: local(\"Open Sans Semibold\"), local(\"OpenSans-Semibold\"), url(https://themes.googleusercontent.com/static/fonts/opensans/v6/MTP_ySUJH_bn48VBG8sNSnhCUOGz7vYGh680lGh-uXM.woff) format(\"woff\");\r\n}\r\n\r\n@font-face {\r\n    font-family: 'Open Sans';\r\n    font-style: normal;\r\n    font-weight: 400;\r\n    src: local(\"Open Sans\"), local(\"OpenSans\"), url(https://themes.googleusercontent.com/static/fonts/opensans/v6/cJZKeOuBrn4kERxqtaUH3T8E0i7KZn-EPnyo3HZu7kw.woff) format(\"woff\");\r\n} */\nhtml, body {\n  font-family: 'Open Sans', sans-serif; }\ntable th,\ntable td {\n  text-align: center; }\ntable tbody .field-checkbox-wrapper {\n  background: transparent;\n  display: inline-block;\n  overflow: initial; }\n/*==========================================Responsive css==============================*/\n@media only screen and (min-width: 768px) and (max-width: 960px) {\n  .middle-section {\n    padding: 1%; }\n  .middle-left {\n    width: 65%; }\n  .middle-right {\n    width: 35%; }\n  .btn {\n    height: 29px;\n    padding: 7px 6px;\n    font-size: 12px; }\n  .normal-field {\n    height: 29px; }\n  .middle-top h1 {\n    margin-top: 5px;\n    font-size: 15px;\n    margin-bottom: 10px; }\n  .header-search .form-ctrl-head {\n    width: 200px; }\n  .header-search {\n    left: 20px;\n    top: 7px; }\n  .login-tube {\n    margin-right: 0; }\n  .btn.cancle,\n  .btn.redBtn {\n    font-size: 14px;\n    height: 35px; }\n  .popupWrapper .popup {\n    max-width: 77%; }\n  .common-right-section h4 {\n    font-size: 14px; }\n  .file-wrapper {\n    padding-left: 15px; }\n  .file-upload-box .select-file-upload ul li label {\n    font-size: 14px; }\n  .file-upload-box .select-file-upload ul li .choose-file input[type=\"text\"] {\n    height: 28px; }\n  .file-upload-box .file-uploaded {\n    margin: 10px 0 15px;\n    font-size: 14px; }\n  .progress-bar-wrapper {\n    width: 70%; }\n  .file-upload-box .drag-drop-box {\n    margin-top: 30px; }\n  .file-upload-box {\n    padding: 15px 00px;\n    max-width: none; }\n  .search-data td {\n    font-size: 12px; } }\n@media only screen and (min-width: 768px) {\n  .visible-xs {\n    display: none !important; } }\n@media only screen and (max-width: 767px) {\n  header {\n    padding: 5px 5px; }\n    header > div {\n      width: 100%; }\n    header .logo {\n      text-align: center;\n      margin: 0 auto;\n      width: 129px;\n      float: left;\n      margin-left: 5px; }\n    header #searchHeader {\n      display: none; }\n    header .login-nav > li .user-info {\n      margin-right: 15px;\n      width: auto; }\n    header .login-nav > li {\n      padding: 0 7px; }\n  #middleWrapper {\n    width: 100%; }\n  main {\n    padding-left: 0;\n    width: 100%; }\n  #loginTube {\n    width: 100%; }\n  .login-tube {\n    float: right; }\n  .middle-section {\n    padding: 1%;\n    width: 100%;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box; }\n  .middle-left {\n    width: 100%;\n    padding: 0; }\n  .middle-top h1 {\n    margin-top: 8px;\n    margin-bottom: 10px;\n    float: none; }\n  .middle-top aside {\n    float: left; }\n  .btn {\n    padding: 4px 7px;\n    font-size: 12px;\n    margin-left: 0;\n    margin-right: 10px;\n    margin-bottom: 10px;\n    border-radius: 4px; }\n  .accordian-section {\n    padding: 15px 0px 0; }\n  .accordian-section .accordian-content {\n    padding-left: 40px; }\n  .create-institution {\n    right: auto;\n    left: 0;\n    bottom: -15px; }\n  .middle-bottom aside {\n    float: left;\n    margin-top: 10px;\n    width: 100%; }\n  .btn.cancle {\n    font-size: 14px;\n    height: 35px; }\n  .btn.redBtn {\n    font-size: 14px;\n    height: 35px; }\n  .middle-right {\n    width: 100%;\n    margin-top: 30px;\n    padding: 0; }\n  .common-right-section {\n    margin-top: 20px; }\n  .normal-field {\n    height: 31px; }\n  .filter-right .btn {\n    margin-top: 10px; }\n  .closeFilter {\n    margin-top: 20px;\n    font-size: 12px; }\n  .middle-main.hasFilter:before {\n    top: 111px; }\n  .search-enquiry-type-filter {\n    margin-top: 10px; }\n    .search-enquiry-type-filter .filter-label {\n      margin-bottom: 10px; }\n  .type-filter li {\n    margin: 0 10px;\n    width: auto;\n    margin-top: 10px;\n    margin-left: 0; }\n  .filter-res label {\n    margin-bottom: 15px;\n    display: block; }\n  .login-tube {\n    margin-right: 0; }\n  .boxPadding15,\n  .middle-left,\n  .middle-right,\n  .middle-full {\n    padding: 0; }\n  .filter-fields .field-wrapper {\n    margin: 6px 0; }\n  .file-wrapper {\n    padding-left: 15px; }\n  .file-upload-box .select-file-upload ul li label {\n    font-size: 14px; }\n  .file-upload-box .select-file-upload ul li .choose-file input[type=\"text\"] {\n    height: 28px; }\n  .file-upload-box .file-uploaded {\n    margin: 10px 0 15px;\n    font-size: 14px; }\n  .progress-bar-wrapper {\n    width: 100%; }\n  .file-upload-box .drag-drop-box {\n    margin-top: 30px; }\n  .file-upload-box {\n    padding: 15px 00px;\n    max-width: none; }\n  .search-data td {\n    font-size: 12px; } }\n/*===================================theme change=====================*/\n.green-theme .btn.fullBlue {\n  background: green;\n  border-color: green;\n  color: #fff; }\n.green-theme a,\n.green-theme .btn {\n  color: green; }\n.green-theme .btn.redBtn {\n  color: #fff; }\n.green-theme header {\n  background: #035d03; }\n.green-theme .cls-1 {\n  stroke: green; }\n.green-theme .nav-list > li:hover,\n.green-theme .nav-list > li.active {\n  background: green;\n  -webkit-box-shadow: 0px 0px 0px 1px green;\n          box-shadow: 0px 0px 0px 1px green;\n  border-bottom: 1px solid green; }\n.green-theme .accordian-section .accordian-heading h4 .open-accor,\n.green-theme .accordian-section .accordian-heading h4 .close-accor,\n.green-theme .close-accor,\n.green-theme .open-accor {\n  color: green;\n  border-color: green; }\n.green-theme .export-print .print-icon:hover,\n.green-theme .export-print .export-icon:hover,\n.green-theme .print-output-section li:hover,\n.green-theme .field-wrapper.has-value .form-ctrl + label,\n.green-theme .field-wrapper .form-ctrl:focus + label,\n.green-theme .login-tube nav > ul > li .dropdown > ul li a:hover,\n.green-theme .field-checkbox-wrapper .form-checkbox:checked + label {\n  color: green; }\n.green-theme .upload-bar > div,\n.green-theme .accordian-section .accordian > li.active .circle-accor,\n.green-theme .accordian-section .accordian > li.data-filled .circle-accor,\n.green-theme .table-head-menu span {\n  background: green; }\n.green-theme .shadow-box {\n  background: rgba(0, 128, 0, 0.26); }\n.green-theme th {\n  background: #035d03; }\n.green-theme table tr.selected {\n  background: rgba(3, 93, 3, 0.2) !important; }\n.green-theme .enquiry-action .cls-1 {\n  stroke: transparent; }\n.green-theme .closeFilter svg .cls-1,\n.green-theme .action-menu-inner ul li:hover .cls-2,\n.green-theme .action-menu-inner ul li:hover .cls-3,\n.green-theme .print-output-section li:first-child:hover svg .cls-1,\n.green-theme .print-output-section li.svg-icon:hover .cls-2,\n.green-theme .closePopup:hover .cls-1,\n.green-theme .enquiry-action:hover .action-icon svg .cls-2 {\n  stroke: green; }\n.green-theme .action-menu-inner ul li:hover {\n  color: green; }\n.green-theme .action-menu-inner ul li:hover .cls-2 {\n    stroke: green; }\n.green-theme .accordian-section .accordian > li.active .circle-accor,\n.green-theme .accordian-section .accordian > li.data-filled .circle-accor,\n.green-theme .field-wrapper .form-ctrl:focus,\n.green-theme .field-checkbox-wrapper .form-checkbox:checked + label:after,\n.green-theme .field-checkbox-wrapper .form-checkbox:checked + label:before {\n  border-color: green;\n  width: 12px;\n  height: 5px;\n  left: 2px;\n  top: 5px; }\n.green-theme .accordian-section .accordian > li.data-filled .accordian-heading h4 {\n  background: rgba(3, 93, 3, 0.29); }\n.green-theme .field-wrapper.datePickerBox:after {\n  background-image: url(/../../../assets/images/calendargreen.svg); }\n/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/*====================main section css===============*/\nmain {\n  padding-left: 150px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  position: relative; }\n.common-nav {\n  position: fixed;\n  left: 0;\n  top: 0;\n  height: 100%;\n  width: 70px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  z-index: 102; }\n/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/* Scrollbar thickness changed here for vertical display */\n::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);\n  background-color: #F5F5F5;\n  border-radius: 10px; }\n::-webkit-scrollbar {\n  width: 10px;\n  background-color: #F5F5F5; }\n::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0.44, #7a99d9), color-stop(0.72, #497dbd), color-stop(0.86, #1c3a94)); }\n.footer-section {\n  position: absolute;\n  bottom: 0;\n  z-index: 1000;\n  background: #fff;\n  width: 100%;\n  height: 24px; }\n.footer-section ul {\n    list-style: none; }\n.footer-section ul.footer-list li {\n      display: inline-block;\n      margin: 5px 20px 0; }\n.footer-section ul.footer-list li i {\n        font-family: FontAwesome; }\n.footer-section a {\n    color: #0084f6; }\n/* Track */\n.danger {\n  color: #ff0000 !important; }\n.btn.active, .btn:active {\n  background-image: none;\n  outline: 0;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n  border-radius: 4px; }\ninput[type=\"button\"], input[type=\"submit\"], input[type=\"reset\"], input[type=\"file\"]::-webkit-file-upload-button, button {\n  border-radius: 4px; }\n:host /deep/ .tooltip-arrow {\n  display: none; }\n::ng-deep .tooltip-arrow {\n  display: none; }\n:host /deep/ .tooltip-left {\n  top: 0 !important;\n  min-width: 300px; }\n::ng-deep .tooltip-left {\n  top: 0; }\n:host /deep/ .tooltip-right {\n  top: calc(10% - 2.5px);\n  left: calc(10% - 2.5px); }\n::ng-deep .tooltip-right {\n  top: calc(10% - 2.5px);\n  left: calc(10% - 2.5px); }\n:host /deep/ .tooltip-top {\n  top: calc(10% - 2.5px);\n  left: calc(10% - 2.5px); }\n::ng-deep .tooltip-top {\n  top: calc(10% - 2.5px);\n  left: calc(10% - 2.5px); }\n:host /deep/ .bs-datepicker .bs-datepicker-container {\n  padding: 10px; }\n.bs-calendar-container div:nth-child(1) {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex; }\n.bs-datepicker-head {\n  display: block !important; }\n:host /deep/ bs-days-calendar-view .bs-datepicker-head {\n  color: white;\n  border-top: 1px solid white;\n  border-left: 1px solid white;\n  border-right: 1px solid white;\n  min-width: 300px !important;\n  font-weight: 800; }\n:host /deep/ bs-days-calendar-view .bs-datepicker-body {\n  padding: 5px; }\n::ng-deep .bs-datepicker-container {\n  padding: 5px; }\n::ng-deep .bs-datepicker-head {\n  color: white;\n  border-top: 1px solid white;\n  border-left: 1px solid white;\n  border-right: 1px solid white;\n  min-width: 300px !important;\n  font-weight: 800; }\n::ng-deep .bs-datepicker-body {\n  padding: 0;\n  border: 1px solid rgba(119, 119, 119, 0.28); }\n::ng-deep .bs-datepicker-body table tbody tr td {\n  padding: 0;\n  border-top: 1px solid rgba(211, 212, 213, 0.5);\n  border-bottom: 1px solid rgba(211, 212, 213, 0.5); }\n:host /deep/ .bs-datepicker-body table tbody tr td {\n  padding: 0;\n  border-top: 1px solid rgba(211, 212, 213, 0.5);\n  border-bottom: 1px solid rgba(211, 212, 213, 0.5); }\n::ng-deep .bs-datepicker-body table thead tr th {\n  font-size: 14px;\n  color: black;\n  font-weight: 600;\n  text-align: center; }\n:host /deep/ .bs-datepicker-body table thead tr th {\n  font-size: 14px;\n  color: black;\n  font-weight: 600;\n  text-align: center; }\n.cursor-icon {\n  cursor: pointer; }\n.table-responsive {\n  max-width: 100%; }\n.table-responsive ::-webkit-scrollbar {\n    display: block; }\n.courses-list-table {\n  max-height: 400px;\n  overflow: auto;\n  padding: 10px;\n  margin-top: 10px;\n  -webkit-box-shadow: 0 2px 5px 0 rgba(38, 0, 0, 0.2);\n          box-shadow: 0 2px 5px 0 rgba(38, 0, 0, 0.2); }\n.courses-list-table ::-webkit-scrollbar {\n    display: block; }\ntextarea {\n  resize: none; }\n.filter-fields .field-wrapper.has-value .form-ctrl + label,\n.filter-fields .field-wrapper .form-ctrl:focus + label {\n  top: 0; }\n.time-picker .field-wrapper {\n  display: inline-block;\n  margin: 5px 10px 0 0; }\n.time-picker .field-wrapper .form-ctrl {\n    width: 70px;\n    z-index: 10; }\n.time-picker .field-wrapper label {\n    font-size: 12px;\n    z-index: 1; }\n.multiselect-wrapper {\n  padding: 5px;\n  border: 1px solid #deeaee;\n  position: absolute;\n  z-index: 100;\n  background: white;\n  min-width: 400px;\n  min-height: 50px;\n  top: 65px; }\n.multiselect-wrapper .multiselect-wrapper-inner {\n    padding: 10px; }\n.multiselect-wrapper .multiselect-wrapper-inner ul li {\n      height: 40px;\n      padding: 10px 0 0 5px; }\ninput[type=\"text\"][disabled] {\n  background: transparent !important; }\n.report-wrapper {\n  background: #efefef;\n  height: 110vh;\n  width: 100%;\n  padding: 5px; }\n.report-wrapper .report-header {\n    background: #fff;\n    padding: 5px; }\n.chipped {\n  color: white !important;\n  font-size: 14px;\n  background: #0084f6;\n  cursor: pointer;\n  border: 2px solid white;\n  border-radius: 32px;\n  display: inline-block;\n  margin: 0 !important;\n  font-weight: 400;\n  padding: .1rem .8rem;\n  outline: none;\n  text-align: center;\n  white-space: nowrap;\n  vertical-align: middle;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  overflow: hidden;\n  position: relative;\n  -webkit-transition: all 0.24s cubic-bezier(0.4, 0, 0.2, 1);\n  transition: all 0.24s cubic-bezier(0.4, 0, 0.2, 1);\n  will-change: padding; }\n.chipped i {\n    color: #99D154;\n    position: absolute;\n    top: 6px;\n    margin-left: 1rem;\n    font-size: 48px;\n    -webkit-transition: all 0.24s cubic-bezier(0.4, 0, 0.2, 1);\n    transition: all 0.24s cubic-bezier(0.4, 0, 0.2, 1);\n    opacity: 0;\n    -webkit-transform: translateX(1rem);\n            transform: translateX(1rem);\n    will-change: opacity, transform; }\n.chipped.small {\n    color: white !important;\n    font-size: 12px !important;\n    background: #0084f6;\n    cursor: pointer;\n    border: 2px solid white;\n    border-radius: 32px;\n    display: inline-block;\n    margin: 0 !important;\n    font-weight: 400;\n    padding: .2rem .5rem; }\n.chipped.intable {\n    color: rgba(30, 35, 40, 0.7) !important;\n    font-size: 12px !important;\n    background: transparent;\n    cursor: pointer;\n    border: 1px solid #64676b;\n    border-radius: 5px;\n    display: inline-block;\n    margin: 0 2px 0 0 !important;\n    font-weight: 400;\n    padding: .2rem; }\n.chipped.active {\n  background-color: #fff;\n  color: #333333;\n  padding-right: 4.5rem; }\n.chipped.active i {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n            transform: translateX(0); }\n/* ================================================================================================= */\n/* ================================================================================================= */\n/* ================================================================================================= */\n/* ================================================================================================= */\n/* ================================================================================================= */\n/* ================================================================================================= */\n.fbold {\n  font-weight: 700; }\n.sbold {\n  font-weight: 600; }\n.fnormal {\n  font-weight: 300; }\n.rupee {\n  font-family: 'WebRupee'; }\n.line-height {\n  line-height: 1.2; }\n.link,\na {\n  text-decoration: none;\n  color: #0084f6; }\n.link:hover,\n  a:hover {\n    text-decoration: none; }\n.small,\n.small *,\np {\n  font-size: 12px; }\n.xsmall,\n.xsmall * {\n  font-size: 10px;\n  line-height: 14px; }\nh1 {\n  font-size: 14px;\n  font-weight: 700;\n  line-height: 1.2; }\nh2 {\n  font-size: 14px;\n  font-weight: 600;\n  line-height: 1.2; }\nh3 {\n  font-size: 14px;\n  font-weight: 600;\n  line-height: 1.2; }\n.container {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0 auto; }\n.clearFix:after,\n.container:after {\n  content: \"\";\n  display: table;\n  clear: both; }\n.common-width {\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  vertical-align: top;\n  display: inline-block; }\n.pull-left {\n  float: left; }\n.pull-right {\n  float: right; }\n.mR10 {\n  margin-right: 10px; }\n.pos-rel {\n  position: relative; }\n.pos-abs {\n  position: absolute; }\n.hide {\n  display: none !important; }\n.show {\n  display: block !important; }\n.display-b {\n  display: block; }\n.display-ib {\n  display: inline-block; }\n.align-right {\n  text-align: right; }\n.align-left {\n  text-align: left; }\n.v-middle {\n  vertical-align: middle; }\n.radius-4 {\n  border-radius: 4px; }\n.overflowHidden {\n  overflow: hidden; }\n/*===============================call grid view css====================*/\n.container,\n.container-fluid {\n  margin-right: auto;\n  margin-left: auto;\n  padding-left: 15px;\n  padding-right: 15px; }\n@media (min-width: 768px) {\n  .container {\n    width: 750px; } }\n@media (min-width: 992px) {\n  .container {\n    width: 970px; } }\n@media (min-width: 1200px) {\n  .container {\n    width: 1170px; } }\n.row {\n  margin-left: -15px;\n  margin-right: -15px; }\n.c-lg-1,\n.c-lg-10,\n.c-lg-11,\n.c-lg-12,\n.c-lg-2,\n.c-lg-3,\n.c-lg-4,\n.c-lg-5,\n.c-lg-6,\n.c-lg-7,\n.c-lg-8,\n.c-lg-9,\n.c-md-1,\n.c-md-10,\n.c-md-11,\n.c-md-12,\n.c-md-2,\n.c-md-3,\n.c-md-4,\n.c-md-5,\n.c-md-6,\n.c-md-7,\n.c-md-8,\n.c-md-9,\n.c-sm-1,\n.c-sm-10,\n.c-sm-11,\n.c-sm-12,\n.c-sm-2,\n.c-sm-3,\n.c-sm-4,\n.c-sm-5,\n.c-sm-6,\n.c-sm-7,\n.c-sm-8,\n.c-sm-9,\n.c-xs-1,\n.c-xs-10,\n.c-xs-11,\n.c-xs-12,\n.c-xs-2,\n.c-xs-3,\n.c-xs-4,\n.c-xs-5,\n.c-xs-6,\n.c-xs-7,\n.c-xs-8,\n.c-xs-9 {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  position: relative;\n  min-height: 1px;\n  padding-left: 15px;\n  padding-right: 15px; }\n.c-xs-1,\n.c-xs-10,\n.c-xs-11,\n.c-xs-12,\n.c-xs-2,\n.c-xs-3,\n.c-xs-4,\n.c-xs-5,\n.c-xs-6,\n.c-xs-7,\n.c-xs-8,\n.c-xs-9 {\n  float: left; }\n.c-xs-12 {\n  width: 100%; }\n.c-xs-11 {\n  width: 91.66666667%; }\n.c-xs-10 {\n  width: 83.33333333%; }\n.c-xs-9 {\n  width: 75%; }\n.c-xs-8 {\n  width: 66.66666667%; }\n.c-xs-7 {\n  width: 58.33333333%; }\n.c-xs-6 {\n  width: 50%; }\n.c-xs-5 {\n  width: 41.66666667%; }\n.c-xs-4 {\n  width: 33.33333333%; }\n.c-xs-3 {\n  width: 25%; }\n.c-xs-2 {\n  width: 16.66666667%; }\n.c-xs-1 {\n  width: 8.33333333%; }\n.c-xs-pull-12 {\n  right: 100%; }\n.c-xs-pull-11 {\n  right: 91.66666667%; }\n.c-xs-pull-10 {\n  right: 83.33333333%; }\n.c-xs-pull-9 {\n  right: 75%; }\n.c-xs-pull-8 {\n  right: 66.66666667%; }\n.c-xs-pull-7 {\n  right: 58.33333333%; }\n.c-xs-pull-6 {\n  right: 50%; }\n.c-xs-pull-5 {\n  right: 41.66666667%; }\n.c-xs-pull-4 {\n  right: 33.33333333%; }\n.c-xs-pull-3 {\n  right: 25%; }\n.c-xs-pull-2 {\n  right: 16.66666667%; }\n.c-xs-pull-1 {\n  right: 8.33333333%; }\n.c-xs-pull-0 {\n  right: auto; }\n.c-xs-push-12 {\n  left: 100%; }\n.c-xs-push-11 {\n  left: 91.66666667%; }\n.c-xs-push-10 {\n  left: 83.33333333%; }\n.c-xs-push-9 {\n  left: 75%; }\n.c-xs-push-8 {\n  left: 66.66666667%; }\n.c-xs-push-7 {\n  left: 58.33333333%; }\n.c-xs-push-6 {\n  left: 50%; }\n.c-xs-push-5 {\n  left: 41.66666667%; }\n.c-xs-push-4 {\n  left: 33.33333333%; }\n.c-xs-push-3 {\n  left: 25%; }\n.c-xs-push-2 {\n  left: 16.66666667%; }\n.c-xs-push-1 {\n  left: 8.33333333%; }\n.c-xs-push-0 {\n  left: auto; }\n.c-xs-offset-12 {\n  margin-left: 100%; }\n.c-xs-offset-11 {\n  margin-left: 91.66666667%; }\n.c-xs-offset-10 {\n  margin-left: 83.33333333%; }\n.c-xs-offset-9 {\n  margin-left: 75%; }\n.c-xs-offset-8 {\n  margin-left: 66.66666667%; }\n.c-xs-offset-7 {\n  margin-left: 58.33333333%; }\n.c-xs-offset-6 {\n  margin-left: 50%; }\n.c-xs-offset-5 {\n  margin-left: 41.66666667%; }\n.c-xs-offset-4 {\n  margin-left: 33.33333333%; }\n.c-xs-offset-3 {\n  margin-left: 25%; }\n.c-xs-offset-2 {\n  margin-left: 16.66666667%; }\n.c-xs-offset-1 {\n  margin-left: 8.33333333%; }\n.c-xs-offset-0 {\n  margin-left: 0; }\n@media (min-width: 768px) {\n  .c-sm-1,\n  .c-sm-10,\n  .c-sm-11,\n  .c-sm-12,\n  .c-sm-2,\n  .c-sm-3,\n  .c-sm-4,\n  .c-sm-5,\n  .c-sm-6,\n  .c-sm-7,\n  .c-sm-8,\n  .c-sm-9 {\n    float: left; }\n  .c-sm-12 {\n    width: 100%; }\n  .c-sm-11 {\n    width: 91.66666667%; }\n  .c-sm-10 {\n    width: 83.33333333%; }\n  .c-sm-9 {\n    width: 75%; }\n  .c-sm-8 {\n    width: 66.66666667%; }\n  .c-sm-7 {\n    width: 58.33333333%; }\n  .c-sm-6 {\n    width: 50%; }\n  .c-sm-5 {\n    width: 41.66666667%; }\n  .c-sm-4 {\n    width: 33.33333333%; }\n  .c-sm-3 {\n    width: 25%; }\n  .c-sm-2 {\n    width: 16.66666667%; }\n  .c-sm-1 {\n    width: 8.33333333%; }\n  .c-sm-pull-12 {\n    right: 100%; }\n  .c-sm-pull-11 {\n    right: 91.66666667%; }\n  .c-sm-pull-10 {\n    right: 83.33333333%; }\n  .c-sm-pull-9 {\n    right: 75%; }\n  .c-sm-pull-8 {\n    right: 66.66666667%; }\n  .c-sm-pull-7 {\n    right: 58.33333333%; }\n  .c-sm-pull-6 {\n    right: 50%; }\n  .c-sm-pull-5 {\n    right: 41.66666667%; }\n  .c-sm-pull-4 {\n    right: 33.33333333%; }\n  .c-sm-pull-3 {\n    right: 25%; }\n  .c-sm-pull-2 {\n    right: 16.66666667%; }\n  .c-sm-pull-1 {\n    right: 8.33333333%; }\n  .c-sm-pull-0 {\n    right: auto; }\n  .c-sm-push-12 {\n    left: 100%; }\n  .c-sm-push-11 {\n    left: 91.66666667%; }\n  .c-sm-push-10 {\n    left: 83.33333333%; }\n  .c-sm-push-9 {\n    left: 75%; }\n  .c-sm-push-8 {\n    left: 66.66666667%; }\n  .c-sm-push-7 {\n    left: 58.33333333%; }\n  .c-sm-push-6 {\n    left: 50%; }\n  .c-sm-push-5 {\n    left: 41.66666667%; }\n  .c-sm-push-4 {\n    left: 33.33333333%; }\n  .c-sm-push-3 {\n    left: 25%; }\n  .c-sm-push-2 {\n    left: 16.66666667%; }\n  .c-sm-push-1 {\n    left: 8.33333333%; }\n  .c-sm-push-0 {\n    left: auto; }\n  .c-sm-offset-12 {\n    margin-left: 100%; }\n  .c-sm-offset-11 {\n    margin-left: 91.66666667%; }\n  .c-sm-offset-10 {\n    margin-left: 83.33333333%; }\n  .c-sm-offset-9 {\n    margin-left: 75%; }\n  .c-sm-offset-8 {\n    margin-left: 66.66666667%; }\n  .c-sm-offset-7 {\n    margin-left: 58.33333333%; }\n  .c-sm-offset-6 {\n    margin-left: 50%; }\n  .c-sm-offset-5 {\n    margin-left: 41.66666667%; }\n  .c-sm-offset-4 {\n    margin-left: 33.33333333%; }\n  .c-sm-offset-3 {\n    margin-left: 25%; }\n  .c-sm-offset-2 {\n    margin-left: 16.66666667%; }\n  .c-sm-offset-1 {\n    margin-left: 8.33333333%; }\n  .c-sm-offset-0 {\n    margin-left: 0; } }\n@media (min-width: 992px) {\n  .c-md-1,\n  .c-md-10,\n  .c-md-11,\n  .c-md-12,\n  .c-md-2,\n  .c-md-3,\n  .c-md-4,\n  .c-md-5,\n  .c-md-6,\n  .c-md-7,\n  .c-md-8,\n  .c-md-9 {\n    float: left; }\n  .c-md-12 {\n    width: 100%; }\n  .c-md-11 {\n    width: 91.66666667%; }\n  .c-md-10 {\n    width: 83.33333333%; }\n  .c-md-9 {\n    width: 75%; }\n  .c-md-8 {\n    width: 66.66666667%; }\n  .c-md-7 {\n    width: 58.33333333%; }\n  .c-md-6 {\n    width: 50%; }\n  .c-md-5 {\n    width: 41.66666667%; }\n  .c-md-4 {\n    width: 33.33333333%; }\n  .c-md-3 {\n    width: 25%; }\n  .c-md-2 {\n    width: 16.66666667%; }\n  .c-md-1 {\n    width: 8.33333333%; }\n  .c-md-pull-12 {\n    right: 100%; }\n  .c-md-pull-11 {\n    right: 91.66666667%; }\n  .c-md-pull-10 {\n    right: 83.33333333%; }\n  .c-md-pull-9 {\n    right: 75%; }\n  .c-md-pull-8 {\n    right: 66.66666667%; }\n  .c-md-pull-7 {\n    right: 58.33333333%; }\n  .c-md-pull-6 {\n    right: 50%; }\n  .c-md-pull-5 {\n    right: 41.66666667%; }\n  .c-md-pull-4 {\n    right: 33.33333333%; }\n  .c-md-pull-3 {\n    right: 25%; }\n  .c-md-pull-2 {\n    right: 16.66666667%; }\n  .c-md-pull-1 {\n    right: 8.33333333%; }\n  .c-md-pull-0 {\n    right: auto; }\n  .c-md-push-12 {\n    left: 100%; }\n  .c-md-push-11 {\n    left: 91.66666667%; }\n  .c-md-push-10 {\n    left: 83.33333333%; }\n  .c-md-push-9 {\n    left: 75%; }\n  .c-md-push-8 {\n    left: 66.66666667%; }\n  .c-md-push-7 {\n    left: 58.33333333%; }\n  .c-md-push-6 {\n    left: 50%; }\n  .c-md-push-5 {\n    left: 41.66666667%; }\n  .c-md-push-4 {\n    left: 33.33333333%; }\n  .c-md-push-3 {\n    left: 25%; }\n  .c-md-push-2 {\n    left: 16.66666667%; }\n  .c-md-push-1 {\n    left: 8.33333333%; }\n  .c-md-push-0 {\n    left: auto; }\n  .c-md-offset-12 {\n    margin-left: 100%; }\n  .c-md-offset-11 {\n    margin-left: 91.66666667%; }\n  .c-md-offset-10 {\n    margin-left: 83.33333333%; }\n  .c-md-offset-9 {\n    margin-left: 75%; }\n  .c-md-offset-8 {\n    margin-left: 66.66666667%; }\n  .c-md-offset-7 {\n    margin-left: 58.33333333%; }\n  .c-md-offset-6 {\n    margin-left: 50%; }\n  .c-md-offset-5 {\n    margin-left: 41.66666667%; }\n  .c-md-offset-4 {\n    margin-left: 33.33333333%; }\n  .c-md-offset-3 {\n    margin-left: 25%; }\n  .c-md-offset-2 {\n    margin-left: 16.66666667%; }\n  .c-md-offset-1 {\n    margin-left: 8.33333333%; }\n  .c-md-offset-0 {\n    margin-left: 0; } }\n@media (min-width: 1200px) {\n  .c-lg-1,\n  .c-lg-10,\n  .c-lg-11,\n  .c-lg-12,\n  .c-lg-2,\n  .c-lg-3,\n  .c-lg-4,\n  .c-lg-5,\n  .c-lg-6,\n  .c-lg-7,\n  .c-lg-8,\n  .c-lg-9 {\n    float: left; }\n  .c-lg-12 {\n    width: 100%; }\n  .c-lg-11 {\n    width: 91.66666667%; }\n  .c-lg-10 {\n    width: 83.33333333%; }\n  .c-lg-9 {\n    width: 75%; }\n  .c-lg-8 {\n    width: 66.66666667%; }\n  .c-lg-7 {\n    width: 58.33333333%; }\n  .c-lg-6 {\n    width: 50%; }\n  .c-lg-5 {\n    width: 41.66666667%; }\n  .c-lg-4 {\n    width: 33.33333333%; }\n  .c-lg-3 {\n    width: 25%; }\n  .c-lg-2 {\n    width: 16.66666667%; }\n  .c-lg-1 {\n    width: 8.33333333%; }\n  .c-lg-pull-12 {\n    right: 100%; }\n  .c-lg-pull-11 {\n    right: 91.66666667%; }\n  .c-lg-pull-10 {\n    right: 83.33333333%; }\n  .c-lg-pull-9 {\n    right: 75%; }\n  .c-lg-pull-8 {\n    right: 66.66666667%; }\n  .c-lg-pull-7 {\n    right: 58.33333333%; }\n  .c-lg-pull-6 {\n    right: 50%; }\n  .c-lg-pull-5 {\n    right: 41.66666667%; }\n  .c-lg-pull-4 {\n    right: 33.33333333%; }\n  .c-lg-pull-3 {\n    right: 25%; }\n  .c-lg-pull-2 {\n    right: 16.66666667%; }\n  .c-lg-pull-1 {\n    right: 8.33333333%; }\n  .c-lg-pull-0 {\n    right: auto; }\n  .c-lg-push-12 {\n    left: 100%; }\n  .c-lg-push-11 {\n    left: 91.66666667%; }\n  .c-lg-push-10 {\n    left: 83.33333333%; }\n  .c-lg-push-9 {\n    left: 75%; }\n  .c-lg-push-8 {\n    left: 66.66666667%; }\n  .c-lg-push-7 {\n    left: 58.33333333%; }\n  .c-lg-push-6 {\n    left: 50%; }\n  .c-lg-push-5 {\n    left: 41.66666667%; }\n  .c-lg-push-4 {\n    left: 33.33333333%; }\n  .c-lg-push-3 {\n    left: 25%; }\n  .c-lg-push-2 {\n    left: 16.66666667%; }\n  .c-lg-push-1 {\n    left: 8.33333333%; }\n  .c-lg-push-0 {\n    left: auto; }\n  .c-lg-offset-12 {\n    margin-left: 100%; }\n  .c-lg-offset-11 {\n    margin-left: 91.66666667%; }\n  .c-lg-offset-10 {\n    margin-left: 83.33333333%; }\n  .c-lg-offset-9 {\n    margin-left: 75%; }\n  .c-lg-offset-8 {\n    margin-left: 66.66666667%; }\n  .c-lg-offset-7 {\n    margin-left: 58.33333333%; }\n  .c-lg-offset-6 {\n    margin-left: 50%; }\n  .c-lg-offset-5 {\n    margin-left: 41.66666667%; }\n  .c-lg-offset-4 {\n    margin-left: 33.33333333%; }\n  .c-lg-offset-3 {\n    margin-left: 25%; }\n  .c-lg-offset-2 {\n    margin-left: 16.66666667%; }\n  .c-lg-offset-1 {\n    margin-left: 8.33333333%; }\n  .c-lg-offset-0 {\n    margin-left: 0; } }\n.clearfix:after,\n.clearfix:before,\n.container-fluid:after,\n.container-fluid:before,\n.container:after,\n.container:before,\n.row:after,\n.row:before {\n  content: \" \";\n  display: table; }\n.clearfix:after,\n.container-fluid:after,\n.container:after,\n.row:after {\n  clear: both; }\n/* ========================================== Common Fields CSS============================*/\n.table-responsive {\n  max-width: 100%; }\n.filter-fields .field-wrapper.has-value .form-ctrl + label,\n.filter-fields .field-wrapper .form-ctrl:focus + label {\n  top: 0; }\n/* For DatePicker */\n.field-wrapper {\n  position: relative;\n  padding-top: 10px; }\n.field-wrapper .form-ctrl {\n    z-index: 10; }\n.field-wrapper.datePickerBox .form-ctrl {\n    cursor: pointer;\n    position: relative;\n    z-index: 10;\n    background: transparent; }\n.field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"/./assets/images/calendar.svg\") no-repeat;\n    position: absolute;\n    right: 5px;\n    top: 28px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.field-wrapper .date-clear {\n    position: absolute;\n    right: -35px;\n    top: 35px;\n    cursor: pointer;\n    color: #0084f6; }\n.field-wrapper label {\n    font-size: 12px;\n    z-index: 1; }\n/* text field  */\n.field-wrapper .form-ctrl {\n  display: block;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 5px;\n  outline: none;\n  border: solid 1px #e2ebee;\n  background: #fff;\n  z-index: 10;\n  font: 400 12px 'Open sans',sans-serif;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n  border-radius: 0;\n  color: #000; }\n.field-wrapper .form-ctrl.form-ctrl-multiple {\n    height: 100px;\n    overflow-y: auto; }\n.field-wrapper .form-ctrl:focus {\n  border: solid 2px #0084f6;\n  -webkit-box-shadow: none;\n          box-shadow: none; }\n.field-wrapper .form-ctrl:focus + label,\n.field-wrapper.has-value .form-ctrl + label {\n  font-size: 12px;\n  top: 6px;\n  left: 0; }\n.field-wrapper .form-ctrl:focus + label,\n.field-wrapper.has-value .form-ctrl + label {\n  color: #0084f6;\n  font-size: 12px; }\n/*radio button  */\n.field-checkbox-wrapper,\n.field-radio-wrapper {\n  position: relative;\n  padding-left: 25px;\n  margin-bottom: 10px; }\n.field-radio-wrapper .form-radio {\n  opacity: 0;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px;\n  z-index: 1; }\n.field-radio-wrapper .form-radio + label {\n  vertical-align: middle;\n  -webkit-transition: all .1s;\n  transition: all .1s; }\n.field-radio-wrapper .form-radio + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 50%;\n  position: absolute;\n  left: 0;\n  top: 0;\n  -webkit-transition: all .1s;\n  transition: all .1s; }\n.field-radio-wrapper .form-radio:checked + label:after {\n  border: 2px solid #0084f6; }\n.field-radio-wrapper .form-radio + label:before {\n  -webkit-transition: all .1s;\n  transition: all .1s;\n  width: 1px;\n  height: 1px;\n  left: 9px;\n  top: 9px;\n  position: absolute;\n  content: ''; }\n.field-radio-wrapper .form-radio:checked + label:before {\n  content: '';\n  width: 10px;\n  height: 10px;\n  background: #0084f6;\n  border-radius: 50%;\n  left: 3px;\n  top: 3px; }\n.field-radio-wrapper .form-radio:checked + label {\n  color: #0084f6; }\n/*checkbox  */\n.field-checkbox-wrapper .form-checkbox {\n  opacity: 0;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px;\n  z-index: 1; }\n.field-checkbox-wrapper .form-checkbox + label {\n  vertical-align: middle;\n  font-size: 14px;\n  display: inline-block; }\n.field-checkbox-wrapper .form-checkbox + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 2px;\n  position: absolute;\n  left: 0;\n  top: 0; }\n.field-checkbox-wrapper .form-checkbox:checked + label:after {\n  border: 2px solid #0084f6; }\n.field-checkbox-wrapper .form-checkbox + label:before {\n  width: 1px;\n  height: 1px;\n  left: 8px;\n  top: 9px;\n  position: absolute;\n  content: '';\n  border-top: 0;\n  border-right: 0;\n  border-left: 2px solid transparent;\n  border-bottom: 2px solid transparent;\n  -webkit-transform: rotate(-45deg);\n          transform: rotate(-45deg); }\n.field-checkbox-wrapper .form-checkbox:checked + label:before {\n  border-left: 2px solid #0084f6;\n  border-bottom: 2px solid #0084f6;\n  width: 12px;\n  height: 5px;\n  left: 2px;\n  top: 5px; }\n.field-checkbox-wrapper .form-checkbox:checked + label {\n  color: #0084f6; }\n/*navigation   */\n.useFul li {\n  list-style-type: none; }\n.useFul nav {\n  margin-left: 200px; }\n/*===========================================common Table CSS===============================*/\n.mb0,\n.middle-top.mb0 {\n  margin-bottom: 0; }\n.align-center {\n  text-align: center; }\ntable {\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  border-collapse: collapse;\n  overflow-y: hidden; }\ntd,\nth {\n  font-size: 14px;\n  padding: 6px 2px;\n  vertical-align: middle; }\nth {\n  background: #fff;\n  font-size: 12px !important;\n  color: #000000;\n  font-weight: 600;\n  padding: 20px 10px;\n  border-top: 2px solid rgba(119, 119, 119, 0.11); }\nth label {\n    font-size: 14px !important;\n    color: #000000; }\nth a {\n    font-size: 14px !important;\n    color: #000000; }\nth:first-child {\n    border-top-left-radius: 5px; }\nth.No {\n    text-align: right; }\nth.Name {\n    text-align: left; }\nth.Contact {\n    text-align: right; }\nth.Date {\n    text-align: right; }\ntd {\n  border-bottom: 1px solid #fff; }\ntd.No {\n    text-align: right; }\ntd.Name {\n    text-align: left; }\ntd.Contact {\n    text-align: right; }\ntd.Date {\n    text-align: right; }\ntable tr {\n  -webkit-transition: all .1s;\n  transition: all .1s; }\ntable tr {\n  background: #ffffff;\n  border-left: 1px solid rgba(211, 212, 213, 0.5);\n  border-right: 1px solid rgba(211, 212, 213, 0.5);\n  cursor: pointer; }\ntable tr td {\n    border-top: 1px solid rgba(211, 212, 213, 0.5);\n    border-bottom: 2px solid rgba(211, 212, 213, 0.5);\n    padding: 5px 15px;\n    font-size: 14px; }\ntable tr:nth-child(even):hover {\n  background: #ececec; }\ntable tr:nth-child(odd):hover {\n  background: #eaeaea; }\ntable tr.selected {\n  background: #dceff7 !important;\n  -webkit-box-shadow: 0 11px 8px -10px #CCC, 0 -11px 13px -9px #CCC;\n          box-shadow: 0 11px 8px -10px #CCC, 0 -11px 13px -9px #CCC;\n  -webkit-transform: scale(1);\n          transform: scale(1); }\n.table-responsive tr td:first-child .field-checkbox-wrapper,\n.table-responsive tr th:first-child .field-checkbox-wrapper {\n  width: 20px;\n  overflow: hidden;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 20px;\n  padding-left: 20px;\n  margin-bottom: 0;\n  margin-left: 5px;\n  background: transparent;\n  border-radius: 2px; }\n.enquiry-status label {\n  display: block;\n  font-weight: 600; }\n.progress-status {\n  color: dodgerblue; }\n.inactive-status,\n.open-status {\n  color: #333; }\n.admitted-status {\n  color: green; }\n.btn {\n  padding: 6px 10px;\n  background: #fff;\n  border: 1px solid #ccc;\n  margin-left: 10px;\n  display: inline-block;\n  font-size: 14px;\n  font-weight: 600;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  /* height: 35px; */\n  cursor: pointer;\n  color: #0084f6;\n  border-radius: 4px; }\n.btn.fullBlue {\n  background: #0084f6;\n  border: 1px solid #0084f6;\n  color: #fff;\n  padding: 4px 10px;\n  border-radius: 4px; }\n.btn.cancle {\n  background: #fff;\n  border: 1px solid #ccc;\n  color: #0084f6;\n  font-size: 14px;\n  padding: 6px 10px;\n  border-radius: 4px; }\n.btn.redBtn {\n  background: #f44336;\n  border: 1px solid #f44336;\n  color: #fff;\n  font-size: 14px; }\n.btn.normal-btn {\n  margin: 0; }\n.middle-bottom .btn.redBtn {\n  margin-right: 0; }\n.customSelectWrapper select {\n  -webkit-appearance: none;\n  -moz-appearance: none;\n  -o-appearance: none;\n  -ms-appearance: none;\n  appearance: none;\n  position: relative;\n  z-index: 1;\n  background: transparent; }\n.customSelectWrapper:after {\n  display: inline-block;\n  font: normal normal normal 14px/1 FontAwesome;\n  font-size: inherit;\n  text-rendering: auto;\n  -webkit-font-smoothing: antialiased;\n  content: \"\\f107\";\n  font-size: 22px;\n  position: absolute;\n  right: 0;\n  top: 20px; }\n.box-shadow-lite .field-wrapper.customSelectWrapper:after {\n  right: 40px; }\n.field-wrapper.customSelectWrapper label {\n  top: 13px;\n  width: 100%;\n  height: 22px;\n  padding-top: 10px;\n  z-index: 2; }\n.field-wrapper.customSelectWrapper .form-ctrl:focus + label,\n.field-wrapper.customSelectWrapper.has-value label {\n  padding-top: 0;\n  height: 42px; }\n.customSelectWrapper .form-ctrl option {\n  opacity: 0;\n  visibility: hidden;\n  display: none; }\n.open-accor {\n  float: right;\n  width: 24px;\n  font-size: 24px;\n  height: 24px;\n  text-align: center;\n  border: none;\n  border-radius: 50%;\n  line-height: 24px;\n  margin-right: 4px;\n  margin-top: 3px;\n  cursor: pointer;\n  color: #0084f6;\n  cursor: pointer; }\n.hasError .form-ctrl,\n.hasError.form-ctrl {\n  color: red;\n  border-color: red !important; }\np.error-msg {\n  color: red; }\n.middle-bottom .questionInfo {\n  display: inline-block;\n  position: static;\n  margin-left: 10px;\n  vertical-align: middle; }\n.next {\n  position: relative;\n  padding-right: 12px;\n  font-size: 12px;\n  font-weight: 600; }\n.next:after {\n    display: inline-block;\n    font: normal normal normal 14px/1 FontAwesome;\n    font-size: inherit;\n    text-rendering: auto;\n    -webkit-font-smoothing: antialiased;\n    content: \"\\f105\";\n    font-size: 17px;\n    position: absolute;\n    right: 0;\n    top: 0; }\n.next:hover {\n    text-decoration: underline; }\n.prev {\n  position: relative;\n  padding-left: 12px;\n  font-size: 12px;\n  font-weight: 600;\n  margin-right: 30px; }\n.prev:after {\n    display: inline-block;\n    font: normal normal normal 14px/1 FontAwesome;\n    font-size: inherit;\n    text-rendering: auto;\n    -webkit-font-smoothing: antialiased;\n    content: \"\\f104\";\n    font-size: 17px;\n    position: absolute;\n    left: 0;\n    top: 0; }\n.prev:hover {\n    text-decoration: underline; }\n.form-type1 h2,\n.form-type2 h2 {\n  margin-top: 15px;\n  font-size: 15px; }\n.other-heading h2,\n.other-heading h4 {\n  font-size: 16px;\n  margin-bottom: 10px;\n  font-weight: 600; }\n.other-heading h2 a,\n  .other-heading h4 a {\n    display: inline-block;\n    margin-top: 3px;\n    font-size: 12px; }\n.other-heading h2 .close-btns,\n  .other-heading h4 .close-btns {\n    float: right;\n    cursor: pointer;\n    width: 20px;\n    text-align: center; }\n.other-heading h2 .close-btns svg,\n    .other-heading h4 .close-btns svg {\n      width: 13px;\n      stroke-width: 2px; }\n.other-heading h2 .close-btns svg .cls-1,\n      .other-heading h4 .close-btns svg .cls-1 {\n        stroke: #333; }\n.other-heading h2 .close-btns:hover svg .cls-1,\n    .other-heading h4 .close-btns:hover svg .cls-1 {\n      stroke: #0084f6; }\n.info-icon {\n  width: 17px;\n  height: 17px;\n  border-radius: 50%;\n  border: 1px solid #333;\n  display: inline-block;\n  vertical-align: middle;\n  font-size: 12px;\n  text-align: center;\n  font-weight: bold;\n  padding-top: 1px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  cursor: pointer;\n  position: relative;\n  margin: 0 5px; }\n.add-edit {\n  margin-top: 15px;\n  margin-bottom: 15px;\n  font-size: 12px;\n  font-weight: 600; }\n.add-edit a {\n    margin-right: 15px; }\n.form-new-field {\n  background: transparent;\n  width: 60px;\n  text-align: center;\n  border: 0;\n  border-bottom: 1px solid #ccc;\n  padding: 6px 0; }\nselect.form-new-field {\n  width: 110px; }\n.tooltip-box {\n  position: absolute;\n  width: 150px;\n  min-height: 30px;\n  background: #fff;\n  border: 1px solid #ccc;\n  left: -150px;\n  z-index: 1;\n  top: -8px;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all .1s linear .1s;\n  transition: all .1s linear .1s;\n  font-size: 11px;\n  border-radius: 4px;\n  padding: 3px 5px;\n  -webkit-box-shadow: 0 0 4px #ccc;\n          box-shadow: 0 0 4px #ccc; }\n.tooltip-box:after {\n    content: '';\n    width: 0;\n    height: 0;\n    border-left: 8px solid #fff;\n    border-top: 8px solid transparent;\n    border-bottom: 8px solid transparent;\n    position: absolute;\n    right: -8px;\n    top: 0;\n    bottom: 0;\n    margin: auto; }\n.tooltip-box-field {\n  position: absolute;\n  width: 130px;\n  min-height: 30px;\n  background: #e0e0e0;\n  border: 1px solid #ccc;\n  left: 16px;\n  z-index: 1;\n  top: -2px;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all .1s linear .1s;\n  transition: all .1s linear .1s;\n  font-size: 11px;\n  border-radius: 4px;\n  padding: 3px 5px;\n  -webkit-box-shadow: 0 0 4px #ccc;\n          box-shadow: 0 0 4px #ccc; }\n.tooltip-box-field:after {\n    content: '';\n    width: 0;\n    height: 0;\n    border-right: 8px solid #e0e0e0;\n    border-top: 8px solid transparent;\n    border-bottom: 8px solid transparent;\n    position: absolute;\n    left: -7px;\n    top: 4px;\n    bottom: 0;\n    /* margin: auto; */ }\n.middle-top .questionInfo {\n  position: relative; }\n.middle-top .questionInfo .tooltip-box-field {\n    left: auto;\n    right: 16px; }\n.middle-top .questionInfo .tooltip-box-field:after {\n      -webkit-transform: rotate(180deg);\n              transform: rotate(180deg);\n      right: -7px;\n      left: auto; }\n.middle-top .questionInfo:hover .tooltip-box-field {\n    left: auto;\n    right: 28px; }\n.middle-top .questionInfo:hover .tooltip-box-field:after {\n      -webkit-transform: rotate(180deg);\n              transform: rotate(180deg);\n      right: -7px;\n      left: auto; }\n.questionInfo.pos-rel {\n  position: relative; }\n.info-tool {\n  display: inline-block; }\n.info-tool .tooltip-box-field {\n    width: 100px;\n    left: 0; }\n.info-tool:hover .tooltip-box-field,\n.questionInfo:hover .tooltip-box-field {\n  visibility: visible;\n  opacity: 1;\n  left: 28px; }\n.questionInfo.inline-relative {\n  display: inline-block;\n  position: relative; }\n.tooltip-table:hover .tooltip-box {\n  visibility: visible;\n  opacity: 1;\n  left: -140px; }\n.nav-tab {\n  max-width: 700px;\n  margin: 10px auto;\n  font-size: 0; }\n.nav-tab li {\n    width: 15%;\n    display: inline-block;\n    vertical-align: top;\n    position: relative;\n    margin: 0 5%; }\n.nav-tab li div {\n      display: inline-block;\n      text-align: center;\n      position: relative;\n      cursor: pointer; }\n.nav-tab li div:after {\n        content: '';\n        position: absolute;\n        width: 166px;\n        height: 2px;\n        background: #ccc;\n        right: 50%;\n        top: -24px;\n        bottom: 0;\n        margin: auto; }\n.nav-tab li div span {\n        border: 1px solid #ccc;\n        width: 30px;\n        height: 30px;\n        border-radius: 50%;\n        background: #ddd;\n        display: inline-block;\n        text-align: center;\n        line-height: 30px;\n        position: relative;\n        z-index: 1;\n        font-weight: 600;\n        font-size: 14px; }\n.nav-tab li div p {\n        font-weight: 600;\n        color: #888;\n        margin-top: 10px; }\n.nav-tab li:first-child div:after {\n      display: none; }\n.nav-tab li.active div span, .nav-tab li.tab-completed div span {\n      border-color: #0084f6;\n      color: #fff;\n      background: #0084f6; }\n.nav-tab li.active div:after, .nav-tab li.tab-completed div:after {\n      background: #0084f6; }\n.nav-tab li.active div p, .nav-tab li.tab-completed div p {\n      color: #0084f6; }\n.student-table.table-responsive tr td:first-child .field-checkbox-wrapper,\n.student-table.table-responsive tr th:first-child .field-checkbox-wrapper {\n  display: inline-block; }\n@media only screen and (max-width: 767px) {\n  .nav-tab {\n    max-width: 300px; }\n  .nav-tab li div:after {\n    width: 73px;\n    bottom: auto;\n    margin: 0;\n    top: 15px; }\n  .tooltip-box-field {\n    right: 16px;\n    left: auto; }\n  .questionInfo:hover .tooltip-box-field {\n    right: 28px;\n    left: auto; }\n  .tooltip-box-field:after {\n    -webkit-transform: rotate(180deg);\n            transform: rotate(180deg);\n    right: -7px;\n    left: auto; }\n  .info-tool:hover .tooltip-box-field {\n    left: 28px;\n    right: auto; }\n    .info-tool:hover .tooltip-box-field:after {\n      -webkit-transform: rotate(0deg);\n              transform: rotate(0deg);\n      right: auto;\n      left: -7px; }\n  .export-print .export-icon,\n  .export-print .report-icon {\n    margin-left: 0 !important; }\n  .middle-top .questionInfo:hover .tooltip-box-field {\n    left: 28px;\n    right: auto; }\n    .middle-top .questionInfo:hover .tooltip-box-field:after {\n      -webkit-transform: rotate(0deg);\n              transform: rotate(0deg);\n      left: -7px;\n      right: auto; } }\n/*======================================common menu icon=====================*/\n.edit-icon {\n  background: url(\"/../assets/images/edit_details.svg\") no-repeat;\n  width: 19px;\n  height: 19px;\n  display: inline-block;\n  vertical-align: middle; }\ninput:-webkit-autofill {\n  -webkit-box-shadow: 0 0 0 1000px white inset !important; }\n.view-icon {\n  background: url(\"/./assets/images/view_details.svg\") no-repeat;\n  width: 13px;\n  height: 15px;\n  display: inline-block;\n  vertical-align: middle; }\n.alert-danger {\n  color: red !important;\n  background-color: transparent !important;\n  border: none !important; }\n.alert {\n  padding: 0 !important;\n  margin-bottom: 0 !important; }\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all .5s ease-in;\n  transition: all .5s ease-in; }\n.popupWrapper .popup {\n    max-width: 60%;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popupWrapper .popup.large {\n      max-width: 80%;\n      width: 100%;\n      height: auto;\n      left: 0;\n      right: 0;\n      top: 2%;\n      bottom: 0;\n      margin: auto; }\n.popupWrapper .popup.small {\n      max-width: 40%;\n      width: 100%;\n      height: auto;\n      left: 0;\n      right: 0;\n      top: 5%;\n      bottom: 0;\n      margin: auto; }\n.popupWrapper .popup ::-webkit-scrollbar {\n      display: block;\n      width: 7px;\n      height: 7px; }\n.popup-wrapper {\n  padding: 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 14px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.popup-content .row {\n    margin: 0; }\n.popup-content .content-wrapper {\n    margin: 5px;\n    max-height: 480px;\n    overflow: hidden; }\n.popup-content .content-wrapper .content-scroller {\n      max-height: 475px;\n      overflow-x: hidden;\n      overflow-y: scroll; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all .5s ease-in;\n  transition: all .5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all .5s ease-in;\n  transition: all .5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n.sdb {\n  cursor: pointer; }\n.sdb > li {\n    padding: 8px 0;\n    border-bottom: 2px solid rgba(211, 212, 213, 0.2);\n    margin-bottom: 16px;\n    cursor: pointer; }\n.sdb > li:last-child {\n      border-bottom: 0;\n      margin-bottom: 0; }\n.sdb > li h5 {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: justify;\n          -ms-flex-pack: justify;\n              justify-content: space-between;\n      color: #1e2328;\n      font-size: 14px;\n      cursor: pointer;\n      margin-bottom: 12px; }\n.sdb > li h5 span {\n        text-transform: uppercase;\n        opacity: .8;\n        margin-bottom: 4px;\n        font-weight: 600;\n        cursor: pointer; }\n.sdb > li h6 {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: justify;\n          -ms-flex-pack: justify;\n              justify-content: space-between;\n      color: #1e2328;\n      font-size: 12px;\n      cursor: pointer;\n      margin-bottom: 12px; }\n.sdb > li h6 span {\n        text-transform: uppercase;\n        opacity: .8;\n        margin-bottom: 4px;\n        font-weight: 600;\n        cursor: pointer; }\n.in-student-list > li {\n  margin-bottom: 0;\n  cursor: pointer; }\n.in-student-list > li a {\n    display: block;\n    margin: 0 -15px;\n    padding: 8px 15px;\n    cursor: pointer; }\n.in-student-list > li a:hover {\n      background: rgba(27, 96, 163, 0.0901961); }\n.in-student-list > li a img {\n      float: left;\n      width: 24px;\n      height: 24px;\n      border-radius: 50%;\n      margin-right: 12px;\n      cursor: pointer; }\n.in-student-list > li a .sdb-right {\n      display: block;\n      overflow: hidden;\n      color: rgba(30, 35, 40, 0.7);\n      cursor: pointer; }\n.in-student-list > li a .sdb-right label {\n        display: block;\n        margin-bottom: 6px;\n        cursor: pointer; }\n.in-student-list > li a .sdb-right label strong {\n          font-weight: 600; }\n.in-student-list > li a .sdb-right label.recent {\n          display: inline-block;\n          margin-bottom: 6px;\n          color: rgba(30, 35, 40, 0.7);\n          width: 85%; }\n.in-student-list > li a .sdb-right label.delete {\n          display: inline-block;\n          margin-bottom: 6px;\n          color: rgba(30, 35, 40, 0.7);\n          width: 10%; }\n.in-student-list > li a .sdb-right label.delete img {\n            float: left;\n            width: 14px;\n            height: 14px;\n            border-radius: 50%;\n            margin-right: 0;\n            cursor: pointer; }\n.in-student-list > li a .sdb-right span {\n        font-size: 12px;\n        cursor: pointer; }\n.in-student-list > li a.markers {\n      display: inline-block;\n      margin: 0;\n      padding: 8px 10px; }\n.in-student-list .holder li:last-child {\n  display: none; }\n.in-student-list .holder:hover li:last-child {\n  display: block; }\n.dropdown ul {\n  cursor: pointer; }\n.container,\n.container-fluid {\n  margin-right: auto;\n  margin-left: auto;\n  padding-left: 15px;\n  padding-right: 15px; }\n@media (min-width: 768px) {\n  .container {\n    width: 750px; } }\n@media (min-width: 992px) {\n  .container {\n    width: 970px; } }\n@media (min-width: 1200px) {\n  .container {\n    width: 1170px; } }\n.row {\n  margin-left: -15px;\n  margin-right: -15px; }\n.c-lg-1,\n.c-lg-10,\n.c-lg-11,\n.c-lg-12,\n.c-lg-2,\n.c-lg-3,\n.c-lg-4,\n.c-lg-5,\n.c-lg-6,\n.c-lg-7,\n.c-lg-8,\n.c-lg-9,\n.c-md-1,\n.c-md-10,\n.c-md-11,\n.c-md-12,\n.c-md-2,\n.c-md-3,\n.c-md-4,\n.c-md-5,\n.c-md-6,\n.c-md-7,\n.c-md-8,\n.c-md-9,\n.c-sm-1,\n.c-sm-10,\n.c-sm-11,\n.c-sm-12,\n.c-sm-2,\n.c-sm-3,\n.c-sm-4,\n.c-sm-5,\n.c-sm-6,\n.c-sm-7,\n.c-sm-8,\n.c-sm-9,\n.c-xs-1,\n.c-xs-10,\n.c-xs-11,\n.c-xs-12,\n.c-xs-2,\n.c-xs-3,\n.c-xs-4,\n.c-xs-5,\n.c-xs-6,\n.c-xs-7,\n.c-xs-8,\n.c-xs-9 {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  position: relative;\n  min-height: 1px;\n  padding-left: 15px;\n  padding-right: 15px; }\n.c-xs-1,\n.c-xs-10,\n.c-xs-11,\n.c-xs-12,\n.c-xs-2,\n.c-xs-3,\n.c-xs-4,\n.c-xs-5,\n.c-xs-6,\n.c-xs-7,\n.c-xs-8,\n.c-xs-9 {\n  float: left; }\n.c-xs-12 {\n  width: 100%; }\n.c-xs-11 {\n  width: 91.66666667%; }\n.c-xs-10 {\n  width: 83.33333333%; }\n.c-xs-9 {\n  width: 75%; }\n.c-xs-8 {\n  width: 66.66666667%; }\n.c-xs-7 {\n  width: 58.33333333%; }\n.c-xs-6 {\n  width: 50%; }\n.c-xs-5 {\n  width: 41.66666667%; }\n.c-xs-4 {\n  width: 33.33333333%; }\n.c-xs-3 {\n  width: 25%; }\n.c-xs-2 {\n  width: 16.66666667%; }\n.c-xs-1 {\n  width: 8.33333333%; }\n.c-xs-pull-12 {\n  right: 100%; }\n.c-xs-pull-11 {\n  right: 91.66666667%; }\n.c-xs-pull-10 {\n  right: 83.33333333%; }\n.c-xs-pull-9 {\n  right: 75%; }\n.c-xs-pull-8 {\n  right: 66.66666667%; }\n.c-xs-pull-7 {\n  right: 58.33333333%; }\n.c-xs-pull-6 {\n  right: 50%; }\n.c-xs-pull-5 {\n  right: 41.66666667%; }\n.c-xs-pull-4 {\n  right: 33.33333333%; }\n.c-xs-pull-3 {\n  right: 25%; }\n.c-xs-pull-2 {\n  right: 16.66666667%; }\n.c-xs-pull-1 {\n  right: 8.33333333%; }\n.c-xs-pull-0 {\n  right: auto; }\n.c-xs-push-12 {\n  left: 100%; }\n.c-xs-push-11 {\n  left: 91.66666667%; }\n.c-xs-push-10 {\n  left: 83.33333333%; }\n.c-xs-push-9 {\n  left: 75%; }\n.c-xs-push-8 {\n  left: 66.66666667%; }\n.c-xs-push-7 {\n  left: 58.33333333%; }\n.c-xs-push-6 {\n  left: 50%; }\n.c-xs-push-5 {\n  left: 41.66666667%; }\n.c-xs-push-4 {\n  left: 33.33333333%; }\n.c-xs-push-3 {\n  left: 25%; }\n.c-xs-push-2 {\n  left: 16.66666667%; }\n.c-xs-push-1 {\n  left: 8.33333333%; }\n.c-xs-push-0 {\n  left: auto; }\n.c-xs-offset-12 {\n  margin-left: 100%; }\n.c-xs-offset-11 {\n  margin-left: 91.66666667%; }\n.c-xs-offset-10 {\n  margin-left: 83.33333333%; }\n.c-xs-offset-9 {\n  margin-left: 75%; }\n.c-xs-offset-8 {\n  margin-left: 66.66666667%; }\n.c-xs-offset-7 {\n  margin-left: 58.33333333%; }\n.c-xs-offset-6 {\n  margin-left: 50%; }\n.c-xs-offset-5 {\n  margin-left: 41.66666667%; }\n.c-xs-offset-4 {\n  margin-left: 33.33333333%; }\n.c-xs-offset-3 {\n  margin-left: 25%; }\n.c-xs-offset-2 {\n  margin-left: 16.66666667%; }\n.c-xs-offset-1 {\n  margin-left: 8.33333333%; }\n.c-xs-offset-0 {\n  margin-left: 0; }\n@media (min-width: 768px) {\n  .c-sm-1,\n  .c-sm-10,\n  .c-sm-11,\n  .c-sm-12,\n  .c-sm-2,\n  .c-sm-3,\n  .c-sm-4,\n  .c-sm-5,\n  .c-sm-6,\n  .c-sm-7,\n  .c-sm-8,\n  .c-sm-9 {\n    float: left; }\n  .c-sm-12 {\n    width: 100%; }\n  .c-sm-11 {\n    width: 91.66666667%; }\n  .c-sm-10 {\n    width: 83.33333333%; }\n  .c-sm-9 {\n    width: 75%; }\n  .c-sm-8 {\n    width: 66.66666667%; }\n  .c-sm-7 {\n    width: 58.33333333%; }\n  .c-sm-6 {\n    width: 50%; }\n  .c-sm-5 {\n    width: 41.66666667%; }\n  .c-sm-4 {\n    width: 33.33333333%; }\n  .c-sm-3 {\n    width: 25%; }\n  .c-sm-2 {\n    width: 16.66666667%; }\n  .c-sm-1 {\n    width: 8.33333333%; }\n  .c-sm-pull-12 {\n    right: 100%; }\n  .c-sm-pull-11 {\n    right: 91.66666667%; }\n  .c-sm-pull-10 {\n    right: 83.33333333%; }\n  .c-sm-pull-9 {\n    right: 75%; }\n  .c-sm-pull-8 {\n    right: 66.66666667%; }\n  .c-sm-pull-7 {\n    right: 58.33333333%; }\n  .c-sm-pull-6 {\n    right: 50%; }\n  .c-sm-pull-5 {\n    right: 41.66666667%; }\n  .c-sm-pull-4 {\n    right: 33.33333333%; }\n  .c-sm-pull-3 {\n    right: 25%; }\n  .c-sm-pull-2 {\n    right: 16.66666667%; }\n  .c-sm-pull-1 {\n    right: 8.33333333%; }\n  .c-sm-pull-0 {\n    right: auto; }\n  .c-sm-push-12 {\n    left: 100%; }\n  .c-sm-push-11 {\n    left: 91.66666667%; }\n  .c-sm-push-10 {\n    left: 83.33333333%; }\n  .c-sm-push-9 {\n    left: 75%; }\n  .c-sm-push-8 {\n    left: 66.66666667%; }\n  .c-sm-push-7 {\n    left: 58.33333333%; }\n  .c-sm-push-6 {\n    left: 50%; }\n  .c-sm-push-5 {\n    left: 41.66666667%; }\n  .c-sm-push-4 {\n    left: 33.33333333%; }\n  .c-sm-push-3 {\n    left: 25%; }\n  .c-sm-push-2 {\n    left: 16.66666667%; }\n  .c-sm-push-1 {\n    left: 8.33333333%; }\n  .c-sm-push-0 {\n    left: auto; }\n  .c-sm-offset-12 {\n    margin-left: 100%; }\n  .c-sm-offset-11 {\n    margin-left: 91.66666667%; }\n  .c-sm-offset-10 {\n    margin-left: 83.33333333%; }\n  .c-sm-offset-9 {\n    margin-left: 75%; }\n  .c-sm-offset-8 {\n    margin-left: 66.66666667%; }\n  .c-sm-offset-7 {\n    margin-left: 58.33333333%; }\n  .c-sm-offset-6 {\n    margin-left: 50%; }\n  .c-sm-offset-5 {\n    margin-left: 41.66666667%; }\n  .c-sm-offset-4 {\n    margin-left: 33.33333333%; }\n  .c-sm-offset-3 {\n    margin-left: 25%; }\n  .c-sm-offset-2 {\n    margin-left: 16.66666667%; }\n  .c-sm-offset-1 {\n    margin-left: 8.33333333%; }\n  .c-sm-offset-0 {\n    margin-left: 0; } }\n@media (min-width: 992px) {\n  .c-md-1,\n  .c-md-10,\n  .c-md-11,\n  .c-md-12,\n  .c-md-2,\n  .c-md-3,\n  .c-md-4,\n  .c-md-5,\n  .c-md-6,\n  .c-md-7,\n  .c-md-8,\n  .c-md-9 {\n    float: left; }\n  .c-md-12 {\n    width: 100%; }\n  .c-md-11 {\n    width: 91.66666667%; }\n  .c-md-10 {\n    width: 83.33333333%; }\n  .c-md-9 {\n    width: 75%; }\n  .c-md-8 {\n    width: 66.66666667%; }\n  .c-md-7 {\n    width: 58.33333333%; }\n  .c-md-6 {\n    width: 50%; }\n  .c-md-5 {\n    width: 41.66666667%; }\n  .c-md-4 {\n    width: 33.33333333%; }\n  .c-md-3 {\n    width: 25%; }\n  .c-md-2 {\n    width: 16.66666667%; }\n  .c-md-1 {\n    width: 8.33333333%; }\n  .c-md-pull-12 {\n    right: 100%; }\n  .c-md-pull-11 {\n    right: 91.66666667%; }\n  .c-md-pull-10 {\n    right: 83.33333333%; }\n  .c-md-pull-9 {\n    right: 75%; }\n  .c-md-pull-8 {\n    right: 66.66666667%; }\n  .c-md-pull-7 {\n    right: 58.33333333%; }\n  .c-md-pull-6 {\n    right: 50%; }\n  .c-md-pull-5 {\n    right: 41.66666667%; }\n  .c-md-pull-4 {\n    right: 33.33333333%; }\n  .c-md-pull-3 {\n    right: 25%; }\n  .c-md-pull-2 {\n    right: 16.66666667%; }\n  .c-md-pull-1 {\n    right: 8.33333333%; }\n  .c-md-pull-0 {\n    right: auto; }\n  .c-md-push-12 {\n    left: 100%; }\n  .c-md-push-11 {\n    left: 91.66666667%; }\n  .c-md-push-10 {\n    left: 83.33333333%; }\n  .c-md-push-9 {\n    left: 75%; }\n  .c-md-push-8 {\n    left: 66.66666667%; }\n  .c-md-push-7 {\n    left: 58.33333333%; }\n  .c-md-push-6 {\n    left: 50%; }\n  .c-md-push-5 {\n    left: 41.66666667%; }\n  .c-md-push-4 {\n    left: 33.33333333%; }\n  .c-md-push-3 {\n    left: 25%; }\n  .c-md-push-2 {\n    left: 16.66666667%; }\n  .c-md-push-1 {\n    left: 8.33333333%; }\n  .c-md-push-0 {\n    left: auto; }\n  .c-md-offset-12 {\n    margin-left: 100%; }\n  .c-md-offset-11 {\n    margin-left: 91.66666667%; }\n  .c-md-offset-10 {\n    margin-left: 83.33333333%; }\n  .c-md-offset-9 {\n    margin-left: 75%; }\n  .c-md-offset-8 {\n    margin-left: 66.66666667%; }\n  .c-md-offset-7 {\n    margin-left: 58.33333333%; }\n  .c-md-offset-6 {\n    margin-left: 50%; }\n  .c-md-offset-5 {\n    margin-left: 41.66666667%; }\n  .c-md-offset-4 {\n    margin-left: 33.33333333%; }\n  .c-md-offset-3 {\n    margin-left: 25%; }\n  .c-md-offset-2 {\n    margin-left: 16.66666667%; }\n  .c-md-offset-1 {\n    margin-left: 8.33333333%; }\n  .c-md-offset-0 {\n    margin-left: 0; } }\n@media (min-width: 1200px) {\n  .c-lg-1,\n  .c-lg-10,\n  .c-lg-11,\n  .c-lg-12,\n  .c-lg-2,\n  .c-lg-3,\n  .c-lg-4,\n  .c-lg-5,\n  .c-lg-6,\n  .c-lg-7,\n  .c-lg-8,\n  .c-lg-9 {\n    float: left; }\n  .c-lg-12 {\n    width: 100%; }\n  .c-lg-11 {\n    width: 91.66666667%; }\n  .c-lg-10 {\n    width: 83.33333333%; }\n  .c-lg-9 {\n    width: 75%; }\n  .c-lg-8 {\n    width: 66.66666667%; }\n  .c-lg-7 {\n    width: 58.33333333%; }\n  .c-lg-6 {\n    width: 50%; }\n  .c-lg-5 {\n    width: 41.66666667%; }\n  .c-lg-4 {\n    width: 33.33333333%; }\n  .c-lg-3 {\n    width: 25%; }\n  .c-lg-2 {\n    width: 16.66666667%; }\n  .c-lg-1 {\n    width: 8.33333333%; }\n  .c-lg-pull-12 {\n    right: 100%; }\n  .c-lg-pull-11 {\n    right: 91.66666667%; }\n  .c-lg-pull-10 {\n    right: 83.33333333%; }\n  .c-lg-pull-9 {\n    right: 75%; }\n  .c-lg-pull-8 {\n    right: 66.66666667%; }\n  .c-lg-pull-7 {\n    right: 58.33333333%; }\n  .c-lg-pull-6 {\n    right: 50%; }\n  .c-lg-pull-5 {\n    right: 41.66666667%; }\n  .c-lg-pull-4 {\n    right: 33.33333333%; }\n  .c-lg-pull-3 {\n    right: 25%; }\n  .c-lg-pull-2 {\n    right: 16.66666667%; }\n  .c-lg-pull-1 {\n    right: 8.33333333%; }\n  .c-lg-pull-0 {\n    right: auto; }\n  .c-lg-push-12 {\n    left: 100%; }\n  .c-lg-push-11 {\n    left: 91.66666667%; }\n  .c-lg-push-10 {\n    left: 83.33333333%; }\n  .c-lg-push-9 {\n    left: 75%; }\n  .c-lg-push-8 {\n    left: 66.66666667%; }\n  .c-lg-push-7 {\n    left: 58.33333333%; }\n  .c-lg-push-6 {\n    left: 50%; }\n  .c-lg-push-5 {\n    left: 41.66666667%; }\n  .c-lg-push-4 {\n    left: 33.33333333%; }\n  .c-lg-push-3 {\n    left: 25%; }\n  .c-lg-push-2 {\n    left: 16.66666667%; }\n  .c-lg-push-1 {\n    left: 8.33333333%; }\n  .c-lg-push-0 {\n    left: auto; }\n  .c-lg-offset-12 {\n    margin-left: 100%; }\n  .c-lg-offset-11 {\n    margin-left: 91.66666667%; }\n  .c-lg-offset-10 {\n    margin-left: 83.33333333%; }\n  .c-lg-offset-9 {\n    margin-left: 75%; }\n  .c-lg-offset-8 {\n    margin-left: 66.66666667%; }\n  .c-lg-offset-7 {\n    margin-left: 58.33333333%; }\n  .c-lg-offset-6 {\n    margin-left: 50%; }\n  .c-lg-offset-5 {\n    margin-left: 41.66666667%; }\n  .c-lg-offset-4 {\n    margin-left: 33.33333333%; }\n  .c-lg-offset-3 {\n    margin-left: 25%; }\n  .c-lg-offset-2 {\n    margin-left: 16.66666667%; }\n  .c-lg-offset-1 {\n    margin-left: 8.33333333%; }\n  .c-lg-offset-0 {\n    margin-left: 0; } }\n.clearfix:after,\n.clearfix:before,\n.container-fluid:after,\n.container-fluid:before,\n.container:after,\n.container:before,\n.row:after,\n.row:before {\n  content: \" \";\n  display: table; }\n.clearfix:after,\n.container-fluid:after,\n.container:after,\n.row:after {\n  clear: both; }\n/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.nav-list > li {\n  text-align: center;\n  padding-top: 6px;\n  padding-bottom: 6px;\n  border-bottom: 1px solid #eaeaeb;\n  -webkit-transition: all 0.2s linear;\n  transition: all 0.2s linear;\n  cursor: pointer; }\n.nav-list > li svg {\n    width: 29px; }\n.nav-list > li span {\n    display: block;\n    font-size: 10px; }\n.nav-list > li:hover, .nav-list > li.active {\n    background: #0084f6;\n    border-left: 1px solid #00ffee; }\n.nav-list > li:hover span, .nav-list > li.active span {\n      color: #fff; }\n.nav-list > li:hover .cls-1, .nav-list > li.active .cls-1 {\n      stroke: #fff; }\n.nav-list > li .icon img {\n    width: 30px; }\n.nav-list > li .icon rect {\n    stroke: none; }\n.header-search .cls-1,\n.header-search .cls-2,\n.header-search .cls-3 {\n  fill: none; }\n.header-search .cls-1,\n.header-search .cls-2 {\n  stroke: #0060a3;\n  stroke-width: 1.3px; }\n.header-search .cls-1 {\n  stroke-miterlimit: 10; }\n.common-nav {\n  background: #0747a6;\n  -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n          box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n  border-top-right-radius: 25px;\n  border-bottom-right-radius: 25px;\n  color: white;\n  width: 60px;\n  border-bottom: none; }\n.search_container {\n  border-bottom: 1px solid rgba(255, 255, 255, 0.2);\n  width: 60px;\n  height: 60px;\n  padding-top: 20px;\n  padding-left: 18px; }\n.search_container .search-icon {\n    cursor: pointer; }\n.search-bar-container {\n  position: fixed;\n  left: 70px;\n  z-index: 110;\n  width: 27%;\n  padding: 15px;\n  -webkit-animation-name: slideInLeft;\n  animation-name: slideInLeft;\n  -webkit-animation-duration: 0.5s;\n  animation-duration: 0.5s; }\n.search-bar-container .search-bar-input-container .search-input {\n    width: 100%;\n    border-radius: 25px;\n    padding: 10px;\n    font-size: 12px;\n    border: 1px solid #d2d2d2; }\n.search-dropdown {\n  opacity: 0;\n  visibility: hidden;\n  -webkit-transition: all 0.4s ease;\n  transition: all 0.4s ease;\n  -webkit-transform: translateY(10px);\n          transform: translateY(10px);\n  position: absolute;\n  background: #fff;\n  -webkit-box-shadow: 0px 1px 1px 1px rgba(0, 0, 0, 0.219608);\n          box-shadow: 0px 1px 1px 1px rgba(0, 0, 0, 0.219608);\n  border-radius: 4px;\n  padding: 8px 16px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  width: 110%;\n  margin-top: 10px; }\n.search-dropdown.searchView {\n    opacity: 1;\n    visibility: visible;\n    -webkit-transform: translateY(0);\n            transform: translateY(0); }\n.search-dropdown .sdb > li {\n    padding: 8px 0;\n    border-bottom: 2px solid rgba(211, 212, 213, 0.2);\n    margin-bottom: 16px; }\n.search-dropdown .sdb > li:last-child {\n      border-bottom: 0;\n      margin-bottom: 0; }\n.search-dropdown .sdb > li h5 {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: justify;\n          -ms-flex-pack: justify;\n              justify-content: space-between;\n      color: #1e2328;\n      font-size: 14px;\n      margin-bottom: 12px; }\n.search-dropdown .sdb > li h5 span {\n        text-transform: uppercase;\n        opacity: 0.8;\n        margin-bottom: 4px;\n        font-weight: 600; }\n.search-dropdown .in-student-list > li {\n    margin-bottom: 0px; }\n.search-dropdown .in-student-list > li a {\n      display: block;\n      margin: 0 -15px;\n      padding: 8px 15px; }\n.search-dropdown .in-student-list > li a:hover {\n        background: rgba(27, 96, 163, 0.0901961); }\n.search-dropdown .in-student-list > li a img {\n        float: left;\n        width: 24px;\n        height: 24px;\n        border-radius: 50%;\n        margin-right: 12px; }\n.search-dropdown .in-student-list > li a .sdb-right {\n        display: block;\n        overflow: hidden;\n        color: rgba(30, 35, 40, 0.7); }\n.search-dropdown .in-student-list > li a .sdb-right label {\n          display: block;\n          margin-bottom: 6px; }\n.search-dropdown .in-student-list > li a .sdb-right label strong {\n            font-weight: 600; }\n.search-dropdown .in-student-list > li a .sdb-right label.recent {\n            display: inline-block;\n            margin-bottom: 6px;\n            width: 60%; }\n.search-dropdown .in-student-list > li a .sdb-right label.delete {\n            display: inline-block;\n            margin-bottom: 6px;\n            font-family: FontAwesome;\n            color: rgba(30, 35, 40, 0.7);\n            width: 35%; }\n.search-dropdown .in-student-list > li a .sdb-right span {\n          font-size: 12px; }\n.searchbox:focus .search-dropdown {\n  opacity: 1;\n  visibility: visible;\n  -webkit-transform: translateY(0);\n          transform: translateY(0); }\n@media only screen and (max-width: 960px) and (min-width: 768px) {\n  .header-search {\n    position: relative;\n    left: 170px;\n    top: 7px; }\n    .header-search .form-ctrl-head.searchbox {\n      width: 122px;\n      -webkit-transition: 0.5s ease;\n      transition: 0.5s ease;\n      border-radius: 5px; }\n      .header-search .form-ctrl-head.searchbox.has-focus {\n        width: 244px; }\n    .header-search:hover .form-ctrl-head.searchbox {\n      width: 244px;\n      -webkit-transition: 0.5s;\n      transition: 0.5s;\n      border-radius: 5px; }\n  .header-search .form-ctrl-head.searchbox:focus .search-dropdown {\n    opacity: 1;\n    visibility: visible;\n    -webkit-transform: translateY(0);\n            transform: translateY(0); }\n  .search-dropdown {\n    width: 245px;\n    left: 171px;\n    margin-top: 10px; } }\n.nav-list > li {\n  text-align: center;\n  padding-top: 8px;\n  padding-bottom: 8px;\n  border-bottom: 0px;\n  -webkit-transition: all 0.6s linear;\n  transition: all 0.6s linear;\n  cursor: pointer; }\n.nav-list > li svg {\n  width: 29px; }\n.nav-list > li span {\n  display: block;\n  font-size: 10px; }\n.down-side-bar {\n  position: absolute;\n  bottom: 10px;\n  width: 60px;\n  text-align: center; }\n.down-side-bar ul li {\n    height: 40px; }\n.down-side-bar ul li svg {\n      cursor: pointer; }\n@media only screen and (max-width: 767px) {\n  .common-nav {\n    top: 0;\n    padding-top: 92px;\n    overflow: auto;\n    left: -100%;\n    -webkit-transition: all 0.5s linear 0.1s;\n    transition: all 0.5s linear 0.1s; }\n  .common-nav.show {\n    left: 0; }\n    .common-nav.show nav ul {\n      position: relative;\n      z-index: 11; }\n    .common-nav.show nav:after {\n      content: '';\n      background: rgba(0, 0, 0, 0.5);\n      position: fixed;\n      width: 100%;\n      height: 100%;\n      left: 0;\n      top: 0; }\n  .nav-list > li {\n    padding-top: 10px;\n    padding-bottom: 10px; }\n  .nav-list > li svg {\n    width: 35px; } }\n.help-menu-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  position: fixed;\n  left: 55px;\n  top: 60%;\n  background: white;\n  width: 250px;\n  border-radius: 4px;\n  z-index: 105;\n  -webkit-box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.35);\n          box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.35); }\n.help-menu-container .help-menu-item {\n    cursor: pointer;\n    font-size: 12px;\n    color: #585574;\n    width: 100%;\n    padding: 10px;\n    border-bottom: 1px solid rgba(10, 10, 10, 0.2);\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row; }\n.help-menu-container .help-menu-item .help-menu-icon-container {\n      width: 9%;\n      margin-right: 8px; }\n.help-menu-container .help-menu-item .help-menu-icon-container img {\n        width: 15px;\n        height: 15px; }\n.side-menu {\n  position: fixed;\n  left: 0;\n  top: 0;\n  height: 100%;\n  background: white;\n  z-index: 110;\n  width: 18%;\n  padding: 15px;\n  -webkit-animation-name: slideInLeft;\n          animation-name: slideInLeft;\n  -webkit-animation-duration: 0.5s;\n          animation-duration: 0.5s; }\n.side-menu .side-menu-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column; }\n.side-menu .side-menu-container .back-btn-container img {\n      cursor: pointer; }\n.side-menu .side-menu-container .account-name-and-icon {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 100%;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start;\n      margin-top: 10px; }\n.side-menu .side-menu-container .account-name-and-icon .profile-photo-container img {\n        width: 35px;\n        height: 35px;\n        border-radius: 4px; }\n.side-menu .side-menu-container .account-name-and-icon .account-name-container {\n        font-size: 14px;\n        font-weight: 600;\n        color: #585574;\n        margin-left: 10px;\n        font-size: 14px; }\n.side-menu .side-menu-container .menu-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      margin-top: 10px; }\n.side-menu .side-menu-container .menu-container .menu-item {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        position: relative; }\n.side-menu .side-menu-container .menu-container .menu-item .external-menu {\n          display: none;\n          position: absolute;\n          background: white;\n          width: 100%;\n          left: 105%;\n          padding: 10px;\n          border-radius: 4px;\n          -webkit-box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.35);\n                  box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.35);\n          z-index: 1; }\n.side-menu .side-menu-container .menu-container .menu-item .external-menu .external-menu-item {\n            width: 100%;\n            margin-bottom: 10px;\n            color: #585574;\n            font-size: 12px; }\n.side-menu .side-menu-container .menu-container .menu-item .external-menu .external-menu-item span {\n              cursor: pointer; }\n.side-menu .side-menu-container .menu-container .menu-item .external-menu .external-menu-item:last-child {\n            margin-bottom: 0px; }\n.side-menu .side-menu-container .menu-container .menu-item .external-menu .external-menu-item:hover {\n            color: #1283f4; }\n.side-menu .side-menu-container .menu-container .menu-item .current-menu {\n          padding: 5px 10px;\n          border: 1px solid #d2d2d2;\n          margin-bottom: 10px;\n          border-radius: 4px;\n          cursor: pointer;\n          width: 100%;\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: horizontal;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: row;\n                  flex-direction: row;\n          color: #585574; }\n.side-menu .side-menu-container .menu-container .menu-item .current-menu .menu-icon img {\n            height: 18px;\n            width: 18px; }\n.side-menu .side-menu-container .menu-container .menu-item .current-menu .menu-icon:hover {\n            fill: #1283f4; }\n.side-menu .side-menu-container .menu-container .menu-item .current-menu .menu-name {\n            font-weight: 600;\n            margin-left: 5px;\n            width: 85%;\n            font-size: 12px;\n            padding-top: 3px; }\n.side-menu .side-menu-container .menu-container .menu-item .current-menu .side-menu-icon .fa {\n            color: #707070;\n            font-size: 10px; }\n.side-menu .side-menu-container .menu-container .menu-item .active-current-menu {\n          color: #1283f4;\n          background: #f3f9ff;\n          border: 1px solid #d4eaff; }\n.blur-background {\n  background: rgba(10, 10, 10, 0.2);\n  position: fixed;\n  left: 0px;\n  top: 0px;\n  height: 100%;\n  z-index: 100;\n  width: 100%; }\n@-webkit-keyframes slideInLeft {\n  from {\n    -webkit-transform: translate3d(-100%, 0, 0);\n    transform: translate3d(-100%, 0, 0);\n    visibility: visible; }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n    transform: translate3d(0, 0, 0); } }\n@keyframes slideInLeft {\n  from {\n    -webkit-transform: translate3d(-100%, 0, 0);\n    transform: translate3d(-100%, 0, 0);\n    visibility: visible; }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n    transform: translate3d(0, 0, 0); } }\n"

/***/ }),

/***/ "./src/app/components/core/core-sidednav/core-sidednav.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CoreSidednavComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__ = __webpack_require__("./src/app/services/login-services/login.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_rxjs_add_operator_map__ = __webpack_require__("./node_modules/rxjs/_esm5/add/operator/map.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_rxjs_Rx__ = __webpack_require__("./node_modules/rxjs/_esm5/Rx.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_fetchprefilldata_service__ = __webpack_require__("./src/app/services/fetchprefilldata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_multiBranchdata_service__ = __webpack_require__("./src/app/services/multiBranchdata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var CoreSidednavComponent = /** @class */ (function () {
    function CoreSidednavComponent(login, auth, log, router, fetchService, multiBranchService, commonService) {
        this.login = login;
        this.auth = auth;
        this.log = log;
        this.router = router;
        this.fetchService = fetchService;
        this.multiBranchService = multiBranchService;
        this.commonService = commonService;
        this.logs = '';
        this.isLangInstitute = false;
        this.permissionData = [];
        this.userType = '';
        this.sideBar = false;
        this.searchBar = false;
        this.helpMenu = false;
        // From Header
        this.isProfessional = false;
        this.menuToggler = false;
        // hasEnquiry: boolean = true;
        // hasStudent: boolean = true;
        // hasClass: boolean = true;
        this.enquiryResult = [];
        this.studentResult = [];
        this.manageExamGrades = "";
        this.globalSearchForm = {
            name: '',
            phone: '',
            instituteId: sessionStorage.getItem('institute_id'),
            start_index: '0',
            batch_size: '6'
        };
        this.resultStat = 1;
        this.teacherId = 0;
        this.branchesList = [];
        this.mainBranchId = "";
        this.isMainBranch = "N";
        this.showMainBranchBackBtn = false;
        this.checkAdmin = "";
        this.libraryRole = false;
        this.searchViewMore = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.enquiryUpdateAction = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.hideSearchPopup = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.changePassword = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
    }
    CoreSidednavComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.log.currentUserType.subscribe(function (e) {
            if (e == '' || e == null || e == undefined) {
            }
            else {
                _this.userType = e;
            }
        });
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.settings = sessionStorage.getItem('is_exam_grad_feature');
        this.instituteName = sessionStorage.getItem('institute_name');
        this.userName = sessionStorage.getItem('name');
        this.instituteId = sessionStorage.getItem('institute_id');
        var permissionArray = sessionStorage.getItem('permissions');
        var username = sessionStorage.getItem('username');
        if (((username == "admin" && this.instituteId == 100127) ||
            (username == "admin" && this.instituteId == 100952) ||
            (username == "admin" && this.instituteId == 101077)) ||
            (permissionArray && permissionArray.indexOf('721') != -1)) {
            this.libraryRole = true;
        }
        this.log.currentPermissions.subscribe(function (e) {
            if (e == '' || e == null || e == undefined) {
            }
            else {
                _this.permissionData = JSON.parse(e);
            }
        });
        this.log.currentUsername.subscribe(function (res) {
            _this.createCustomSidenav();
        });
        this.checkUserHadAccess();
        this.form.valueChanges
            .debounceTime(1000)
            .distinctUntilChanged()
            .subscribe(function (data) {
            _this.userInput = data.userInput;
            _this.enquiryResult = [];
            _this.studentResult = [];
            _this.filterGlobal(data.userInput);
        });
        this.checkInstituteType();
        this.checkManinBranch();
    };
    // USER permission
    CoreSidednavComponent.prototype.checkUserHadAccess = function () {
        this.divProfileTag.nativeElement.style.display = 'none';
        var permissionArray = sessionStorage.getItem('permissions');
        if (permissionArray == null || permissionArray == "") {
            if (sessionStorage.getItem('userType') == '0') {
                this.showAllFields();
            }
            else if (sessionStorage.getItem('userType') == '3') {
                this.hideAllFields();
                this.teacherId = JSON.parse(sessionStorage.getItem('institute_info')).teacherId;
                // this.divProfileTag.nativeElement.style.display = '';
                this.setNativeElementValue(['divProfileTag'], '');
                // this.divAdminTag.nativeElement.style.display = 'none';
                // this.divAcademicTag.nativeElement.style.display = 'none';
                this.setNativeElementValue(['divAcademicTag'], 'none');
            }
        }
        else {
            if (permissionArray != undefined) {
                this.hideAllFields();
                if (permissionArray.indexOf('503') != -1) {
                    // this.divMasterTag.nativeElement.style.display = '';
                    // this.divTeacherTag.nativeElement.style.display = '';
                    this.setNativeElementValue(['divMasterTag', 'divTeacherTag'], '');
                }
                if (permissionArray.indexOf('506') != -1) {
                    // this.divMasterTag.nativeElement.style.display = '';
                    // this.divFeeTag.nativeElement.style.display = '';
                    this.setNativeElementValue(['divMasterTag', 'divFeeTag'], '');
                }
                if (permissionArray.indexOf('507') != -1 && this.isProfessional) {
                    // this.divMasterTag.nativeElement.style.display = '';
                    // this.divSlotTag.nativeElement.style.display = '';
                    this.setNativeElementValue(['divMasterTag', 'divSlotTag'], '');
                }
                if (permissionArray.indexOf('509') != -1) {
                    // this.divMasterTag.nativeElement.style.display = '';
                    // this.divAcademicTag.nativeElement.style.display = '';
                    this.setNativeElementValue(['divMasterTag', 'divAcademicTag'], '');
                }
                if (permissionArray.indexOf('602') != -1) {
                    // this.divSettingTag.nativeElement.style.display = '';
                    // this.divMyAccountTag.nativeElement.style.display = '';
                    this.setNativeElementValue(['divSettingTag', 'divMyAccountTag'], '');
                }
                if (permissionArray.indexOf('603') != -1) {
                    // this.divSettingTag.nativeElement.style.display = '';
                    // this.divGeneralSettingTag.nativeElement.style.display = '';
                    this.setNativeElementValue(['divSettingTag', 'divGeneralSettingTag'], '');
                }
                if (permissionArray.indexOf('115') != -1) {
                    // this.divManageFormTag.nativeElement.style.display = '';
                    // this.divAreaAndMap.nativeElement.style.display = '';
                    this.setNativeElementValue(['divAreaAndMap'], '');
                }
                if (permissionArray.indexOf('601') != -1) {
                    // this.divManageUsers.nativeElement.style.display = '';
                    this.setNativeElementValue(['divManageUsers'], '');
                }
                if (permissionArray.indexOf('508') != -1) {
                    this.setNativeElementValue(['divClassRoomTag'], '');
                    // this.divClassRoomTag.nativeElement.style.display = '';
                }
            }
        }
    };
    CoreSidednavComponent.prototype.showAllFields = function () {
        var array = ['divMyAccountTag', 'divMasterTag', 'divTeacherTag', 'divFeeTag', 'divAcademicTag',
            'divSettingTag', 'divGeneralSettingTag', 'divManageFormTag', 'divManageUsers', 'divClassRoomTag'];
        this.setNativeElementValue(array, '');
        if (this.settings == '1') {
            this.divGradesTag.nativeElement.style.display = '';
        }
        else {
            this.divGradesTag.nativeElement.style.display = 'none';
        }
        if (this.isProfessional) {
            this.divSlotTag.nativeElement.style.display = '';
        }
        else if (!this.isProfessional) {
            this.divSlotTag.nativeElement.style.display = 'none';
        }
    };
    CoreSidednavComponent.prototype.hideAllFields = function () {
        var array = ['divMyAccountTag', 'divMasterTag', 'divTeacherTag', 'divFeeTag',
            'divSlotTag', 'divAcademicTag', 'divSettingTag', 'divGeneralSettingTag', 'divManageFormTag',
            'divAreaAndMap', 'divManageUsers', 'divGradesTag', 'divClassRoomTag', 'divManageTag'];
        this.setNativeElementValue(array, 'none');
    };
    CoreSidednavComponent.prototype.setNativeElementValue = function (tagArray, value) {
        for (var index in tagArray) {
            this[tagArray[index]].nativeElement.style.display = value;
        }
    };
    CoreSidednavComponent.prototype.checkManinBranch = function () {
        var _this = this;
        this.auth.isMainBranch.subscribe(function (value) {
            if (_this.isMainBranch != value) {
                _this.isMainBranch = value;
                if (_this.isMainBranch == "Y") {
                    _this.multiBranchInstituteFound();
                }
            }
        });
        this.checkToShowMultiBranch();
        this.multiBranchService.subBranchSelected.subscribe(function (res) {
            _this.showMainBranchBackBtn = res;
        });
    };
    // Multi Branch Case Handling
    CoreSidednavComponent.prototype.multiBranchInstituteFound = function () {
        var _this = this;
        this.mainBranchId = sessionStorage.getItem('institute_id');
        this.multiBranchService.getAllBranches().subscribe(function (res) {
            _this.branchesList = res;
        }, function (err) {
        });
    };
    CoreSidednavComponent.prototype.checkToShowMultiBranch = function () {
        var _this = this;
        this.log.currentUserType.subscribe(function (res) {
            if (res == '3') {
                _this.checkAdmin = false;
            }
            else {
                if (_this.commonService.checkUserIsAdmin()) {
                    _this.checkAdmin = true;
                }
                else {
                    _this.checkAdmin = false;
                }
            }
        });
    };
    CoreSidednavComponent.prototype.ngAfterViewInit = function () {
        this.setActiveClassOnSideNav();
    };
    CoreSidednavComponent.prototype.validateUsertypePermissionData = function () {
        var p = sessionStorage.getItem('permissions');
        var e = sessionStorage.getItem('userType');
        if (p == '' || p == null || p == undefined) {
            this.permissionData = [];
        }
        if (p != '' && p != null && p != undefined) {
            this.permissionData = JSON.parse(p);
            this.log.changePermissions(p);
        }
        if (e == '' || e == null || e == undefined) {
            this.userType = 0;
        }
        else if (e != '' && e != null && e != undefined) {
            this.userType = e;
            this.log.changeUserType(e);
        }
    };
    CoreSidednavComponent.prototype.createCustomSidenav = function () {
        var p = sessionStorage.getItem('permissions');
        var e = sessionStorage.getItem('userType');
        if (p == '' || p == null || p == undefined) {
            this.permissionData = [];
        }
        if (p != '' && p != null && p != undefined) {
            this.permissionData = JSON.parse(p);
            this.log.changePermissions(p);
        }
        if (e == '' || e == null || e == undefined) {
            this.userType = 0;
        }
        if (e != '' && e != null && e != undefined) {
            this.userType = e;
            this.log.changeUserType(e);
        }
        var userType = this.userType;
        var permission = this.permissionData;
        /* Admin or Custom login */
        if (userType == 0) {
            /* admin detected */
            if (permission == null || permission == undefined || permission == '') {
                var hideArray = ['lione', 'litwo', 'lithree', 'lifour', 'lifive', 'lisix', 'liseven', 'lieight', 'linine', 'lieleone'];
                hideArray.forEach(function (obj) {
                    if (document.getElementById(obj)) {
                        document.getElementById(obj).classList.remove('hide');
                    }
                });
                document.getElementById('lizero').classList.remove('active');
                if (this.isProfessional || sessionStorage.getItem('enable_eLearn_feature') == '0') {
                    document.getElementById('lieleone').classList.add('hide');
                }
            }
            else {
                /* array to store the user permissions, if the permission length is less than equal to one
                remove the first and last char and validate if its admin or not */
                this.hasEnquiry(this.permissionData);
                this.hasStudent(this.permissionData);
                this.hasCourse(this.permissionData);
                this.hasActivity(this.permissionData);
                this.hasEmployee(this.permissionData);
                this.hasReport(this.permissionData);
                this.hasInventory(this.permissionData);
                this.hasExpense(this.permissionData);
                this.hasCampaign(this.permissionData);
                this.hasProducts(this.permissionData);
            }
        }
        else if (userType == 3) {
            this.teacherLoginFound();
        }
        var username = sessionStorage.getItem('username');
        if ((username == "admin" && this.instituteId == 100127) || (username == "admin" && this.instituteId == 101077) || (permission && permission.indexOf('721') != -1)) {
            document.getElementById('liten').classList.remove('hide');
        }
    };
    /// loggedout user
    CoreSidednavComponent.prototype.loggedout = function () {
        var hideArray = ['lione', 'litwo', 'lithree', 'lifour', 'lifive', 'lisix', 'liseven', 'lieight', 'linine'];
        hideArray.forEach(function (object) {
            if (document.getElementById(object)) {
                document.getElementById(object).classList.add('hide');
            }
        });
        document.getElementById('lizero').classList.add('active');
    };
    CoreSidednavComponent.prototype.hasEnquiry = function (permissions) {
        if (permissions.includes('110') || permissions.includes('115')) {
            document.getElementById('lione').classList.remove('hide');
        }
        else {
            document.getElementById('lione').classList.add('hide');
        }
    };
    CoreSidednavComponent.prototype.hasStudent = function (permissions) {
        if (permissions.includes('301') ||
            permissions.includes('302') ||
            permissions.includes('303')) {
            document.getElementById('litwo').classList.remove('hide');
        }
        else {
            document.getElementById('litwo').classList.add('hide');
        }
    };
    CoreSidednavComponent.prototype.hasCourse = function (permissions) {
        if (permissions.includes('401') || permissions.includes('402')
            || permissions.includes('403') || permissions.includes('404') ||
            permissions.includes('405') || permissions.includes('406') ||
            permissions.includes('501') || permissions.includes('502') ||
            permissions.includes('505') || permissions.includes('701') ||
            permissions.includes('704') || permissions.includes('702')) {
            document.getElementById('lithree').classList.remove('hide');
        }
        else {
            document.getElementById('lithree').classList.add('hide');
        }
    };
    CoreSidednavComponent.prototype.hasActivity = function (permissions) {
        if (permissions.includes('102') || permissions.includes('114') || permissions.includes('113')) {
            document.getElementById('lifour').classList.remove('hide');
        }
        else {
            document.getElementById('lifour').classList.add('hide');
        }
    };
    CoreSidednavComponent.prototype.hasEmployee = function (permissions) {
        if (permissions.includes('118') || permissions.includes('119') || permissions.includes('120') || permissions.includes('121')) {
            document.getElementById('lifive').classList.remove('hide');
        }
        else {
            document.getElementById('lifive').classList.add('hide');
        }
    };
    CoreSidednavComponent.prototype.hasReport = function (permissions) {
        if (permissions.includes('201') || permissions.includes('202') ||
            permissions.includes('203') || permissions.includes('204') ||
            permissions.includes('205') || permissions.includes('206') ||
            permissions.includes('207') || permissions.includes('208') ||
            permissions.includes('722')) {
            document.getElementById('lisix').classList.remove('hide');
        }
        else {
            document.getElementById('lisix').classList.add('hide');
        }
    };
    CoreSidednavComponent.prototype.hasInventory = function (permissions) {
        if (permissions.includes('301')) {
            document.getElementById('liseven').classList.remove('hide');
        }
        else {
            document.getElementById('liseven').classList.add('hide');
        }
    };
    CoreSidednavComponent.prototype.hasExpense = function (permissions) {
        if (permissions.includes('108') || permissions.includes('109')) {
            document.getElementById('lieight').classList.remove('hide');
        }
        else {
            document.getElementById('lieight').classList.add('hide');
        }
    };
    CoreSidednavComponent.prototype.hasCampaign = function (permissions) {
        if (permissions.includes('115')) {
            document.getElementById('linine').classList.remove('hide');
        }
        else {
            document.getElementById('linine').classList.add('hide');
        }
    };
    CoreSidednavComponent.prototype.hasProducts = function (permissions) {
        if (this.isProfessional) {
            if (permissions.includes('401') || permissions.includes('402')
                || permissions.includes('403') || permissions.includes('404') ||
                permissions.includes('405') || permissions.includes('406') ||
                permissions.includes('501') || permissions.includes('502') ||
                permissions.includes('505') || permissions.includes('701') ||
                permissions.includes('704') || permissions.includes('702')) {
                document.getElementById('lieleone').classList.remove('hide');
            }
            else {
                document.getElementById('lieleone').classList.add('hide');
            }
        }
    };
    CoreSidednavComponent.prototype.hasExam = function (permissions) {
        if (permissions.includes('103') || permissions.includes('112') || permissions.includes('203') || permissions.includes('404')) {
            //document.getElementById('liten').classList.remove('hide');
        }
        else { }
    };
    /* Function to set the id for setActive function to act upon */
    CoreSidednavComponent.prototype.toggler = function (id) {
        this.RemoveActiveTabs();
        if (document.getElementById(id)) {
            document.getElementById(id).classList.add('active');
        }
    };
    CoreSidednavComponent.prototype.checkInstituteType = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isLangInstitute = true;
            }
            else {
                _this.isLangInstitute = false;
            }
        });
    };
    /// Teacher Role Found
    CoreSidednavComponent.prototype.teacherLoginFound = function () {
        var hideArray = ['lione', 'litwo', 'lifive', 'liseven', 'lieight', 'linine'];
        hideArray.forEach(function (object) {
            if (document.getElementById(object)) {
                document.getElementById(object).classList.add('hide');
            }
        });
        var removeArray = ['lithree', 'lifour', 'lisix'];
        removeArray.forEach(function (object) {
            if (document.getElementById(object)) {
                document.getElementById(object).classList.remove('hide');
            }
        });
    };
    CoreSidednavComponent.prototype.RemoveActiveTabs = function () {
        var removeArray = ['lizero', 'lione', 'litwo', 'lithree', 'lifour', 'lifive', 'lisix', 'liseven', 'lieight', 'linine', 'liten', 'lieleone'];
        removeArray.forEach(function (object) {
            if (document.getElementById(object)) {
                document.getElementById(object).classList.remove('active');
            }
        });
    };
    CoreSidednavComponent.prototype.setActiveClassOnSideNav = function () {
        this.RemoveActiveTabs();
        var url = window.location.href;
        var pathLastURL = url.substring(url.lastIndexOf("/") + 1, url.length);
        var routesData = {
            'admin': 'lizero',
            'enquiry': 'lione',
            'student': 'litwo',
            'course': 'lithree',
            'activity': 'lifour',
            'reports': 'lisix',
            'inventory': 'liseven',
            'campaign': 'linine',
            'library': 'liten',
            'products': 'lieleone'
        };
        if (document.getElementById(routesData[pathLastURL])) {
            document.getElementById(routesData[pathLastURL]).classList.add('active');
        }
        // if (url.includes('admin')) {
        //   document.getElementById('lizero').classList.add('active');
        // } else if (url.includes('enquiry')) {
        //   document.getElementById('lione').classList.add('active');
        // } else if (url.includes('student')) {
        //   document.getElementById('litwo').classList.add('active');
        // } else if (url.includes('course')) {
        //   document.getElementById('lithree').classList.add('active');
        // } else if (url.includes('activity')) {
        //   document.getElementById('lifour').classList.add('active');
        // } else if (url.includes('reports')) {
        //   document.getElementById('lisix').classList.add('active');
        // } else if (url.includes('inventory')) {
        //   document.getElementById('liseven').classList.add('active');
        // } else if (url.includes('campaign')) {
        //   document.getElementById('linine').classList.add('active');
        // } else if (url.includes('library')) {
        //   document.getElementById('liten').classList.add('active');
        //   } else if (url.includes('products')) {
        //     document.getElementById('lieleone').classList.add('active');
        // }
    };
    // From Headers section
    CoreSidednavComponent.prototype.showHelpMenu = function () {
        if (this.helpMenu) {
            this.helpMenu = false;
        }
        else {
            this.helpMenu = true;
        }
        this.sideBar = false;
        this.searchBar = false;
    };
    CoreSidednavComponent.prototype.showMenu = function () {
        this.sideBar = true;
        this.helpMenu = false;
        this.searchBar = false;
        var totalExternalClasses = document.getElementsByClassName("external-menu").length;
        var externalMenu = document.getElementsByClassName("external-menu");
        for (var i = 0; i < totalExternalClasses; i++) {
            externalMenu[i].style.display = "none";
        }
    };
    CoreSidednavComponent.prototype.closeMenu = function () {
        this.sideBar = false;
        this.searchBar = false;
        this.helpMenu = false;
    };
    CoreSidednavComponent.prototype.logout = function () {
        this.clearSearch();
        if (this.log.logoutUser()) {
            this.multiBranchService.subBranchSelected.next(false);
            this.router.navigateByUrl('/authPage');
        }
    };
    CoreSidednavComponent.prototype.clearSearch = function () {
        this.enquiryResult = [];
        this.studentResult = [];
    };
    CoreSidednavComponent.prototype.changePasswordClick = function () {
        this.changePassword.emit('true');
        this.searchBar = false;
        this.sideBar = false;
        var totalExternalClasses = document.getElementsByClassName("external-menu").length;
        var externalMenu = document.getElementsByClassName("external-menu");
        for (var i = 0; i < totalExternalClasses; i++) {
            externalMenu[i].style.display = "none";
        }
    };
    CoreSidednavComponent.prototype.onSubBranchClick = function (data) {
        var _this = this;
        this.multiBranchService.setSelectedBranchData(data);
        this.auth.changeInstituteId(data.institute_id);
        this.multiBranchService.getSubBranchLoginInfo(data.institute_id).subscribe(function (res) {
            _this.multiBranchService.subBranchSelected.next(true);
            _this.fillSessionStorageCommonFields(res);
            sessionStorage.setItem('mainBranchId', _this.mainBranchId);
            sessionStorage.setItem('permissions', '');
            _this.getCountryData(data.institute_id);
            _this.router.navigateByUrl('/authPage');
        }, function (err) {
        });
    };
    CoreSidednavComponent.prototype.getCountryData = function (institute_id) {
        this.login.getInstituteCountryDetails(institute_id).subscribe(function (res) {
            var country_info = JSON.stringify(res);
            sessionStorage.setItem('country_data', country_info);
        }, function (err) {
            console.log(err);
        });
    };
    CoreSidednavComponent.prototype.loginToMainBranch = function () {
        var _this = this;
        var mainBranchId = sessionStorage.getItem('mainBranchId');
        this.multiBranchService.loginToMainBranch(mainBranchId).subscribe(function (res) {
            _this.multiBranchService.subBranchSelected.next(false);
            _this.fillSessionStorageCommonFields(res);
            _this.mainBranchLogin(res);
            _this.getCountryData(mainBranchId);
        }, function (err) {
            console.log(err);
        });
    };
    CoreSidednavComponent.prototype.mainBranchLogin = function (res) {
        sessionStorage.setItem('religion_feature', res.religion_feature);
        sessionStorage.setItem('permissions', '');
        this.router.navigateByUrl('/authPage');
    };
    CoreSidednavComponent.prototype.changeIcon = function (id) {
        document.getElementById(id + "_icon").setAttribute('src', "./assets/images/sidebar/sideMenu/" + id + "_color.svg");
    };
    CoreSidednavComponent.prototype.showSubMenu = function (id) {
        if (document.getElementById(id) && document.getElementById(id).style.display == 'block') {
            document.getElementById(id).style.display = "none";
            // document.getElementById(id+"_current").classList.remove('active-current-menu');
            // document.getElementById(id+"_icon").setAttribute( 'src', "./assets/images/sidebar/sideMenu/"+id+".svg");
            // document.getElementById(id+"icon").src = "./assets/images/sidebar/sideMenu/"+id+".svg";
            return;
        }
        else {
            var totalExternalClasses = document.getElementsByClassName("external-menu").length;
            var externalMenu = document.getElementsByClassName("external-menu");
            for (var i = 0; i < totalExternalClasses; i++) {
                externalMenu[i].style.display = "none";
            }
            // let totalCurrentClasses = document.getElementsByClassName("current-menu").length;
            // let currentMenu = document.getElementsByClassName("current-menu") as HTMLCollectionOf<HTMLElement>;
            // for(let i = 0; i < totalCurrentClasses; i++){
            //   currentMenu[i].classList.remove('active-current-menu');
            // }
            // document.getElementById(id+"_icon").setAttribute( 'src', "./assets/images/sidebar/sideMenu/"+id+"_color.svg");
            // document.getElementById(id+"icon").src = "./assets/images/sidebar/sideMenu/"+id+"_color.svg";
            // document.getElementById(id+"_current").classList.add('active-current-menu')
            if (document.getElementById(id)) {
                document.getElementById(id).style.display = "block";
            }
        }
    };
    ;
    CoreSidednavComponent.prototype.routerLink = function (route) {
        this.sideBar = false;
        var totalCurrentClasses = document.getElementsByClassName("current-menu").length;
        var currentMenu = document.getElementsByClassName("current-menu");
        for (var i = 0; i < totalCurrentClasses; i++) {
            currentMenu[i].classList.remove('active-current-menu');
        }
        this.router.navigate([route]);
    };
    CoreSidednavComponent.prototype.viewTeacherProfile = function () {
        this.router.navigate(['/view/teacher/edit/', this.teacherId]);
    };
    CoreSidednavComponent.prototype.fillSessionStorageCommonFields = function (res) {
        sessionStorage.clear();
        var Authorization = btoa(res.userid + "|" + res.userType + ":" + res.password + ":" + res.institution_id);
        sessionStorage.setItem('Authorization', Authorization);
        this.auth.changeAuthenticationKey(Authorization);
        sessionStorage.setItem('institute_id', res.institution_id);
        this.auth.changeInstituteId(res.institution_id);
        sessionStorage.setItem('accountId', res.accountId);
        sessionStorage.setItem('alternate_email_id', res.alternate_email_id);
        sessionStorage.setItem('biometric_attendance_feature', res.biometric_attendance_feature);
        sessionStorage.setItem('courseType', res.courseType);
        sessionStorage.setItem('course_structure_flag', res.course_structure_flag);
        this.auth.course_flag.next(res.course_structure_flag);
        sessionStorage.setItem('enable_fee_payment_mandatory_student_creation', res.enable_fee_payment_mandatory_student_creation);
        sessionStorage.setItem('enable_fee_templates', res.enable_fee_templates);
        sessionStorage.setItem('enable_tax_applicable_fee_installments', res.enable_tax_applicable_fee_installments);
        sessionStorage.setItem('is_exam_grad_feature', res.is_exam_grad_feature);
        sessionStorage.setItem('inst_email', res.inst_email);
        sessionStorage.setItem('inst_phone', res.inst_phone);
        sessionStorage.setItem('institute_type', res.institute_type);
        this.auth.instituteType_name.next(res.institute_type);
        // this.auth.institute_type.next(res.institute_type);
        this.auth.makeInstituteType(res.institute_type, res.course_structure_flag);
        sessionStorage.setItem('institute_name', res.institute_name);
        sessionStorage.setItem('is_campaign_message_approve_feature', res.is_campaign_message_approve_feature);
        sessionStorage.setItem('is_main_branch', res.is_main_branch);
        this.auth.isMainBranch.next(res.is_main_branch);
        sessionStorage.setItem('is_student_bulk_upload_byClient', res.is_student_bulk_upload_byClient);
        sessionStorage.setItem('is_student_mgmt_flag', res.is_student_mgmt_flag);
        sessionStorage.setItem('login_teacher_id', res.login_teacher_id);
        sessionStorage.setItem('name', res.name);
        sessionStorage.setItem('password', res.password);
        sessionStorage.setItem('student_report_card_fee_module', res.student_report_card_fee_module);
        sessionStorage.setItem('studwise_fee_mod_with_amt', res.studwise_fee_mod_with_amt);
        sessionStorage.setItem('test_feature', res.test_feature);
        sessionStorage.setItem('testprepEnabled', res.testprepEnabled);
        sessionStorage.setItem('userType', res.userType);
        this.log.changeUserType(res.userType);
        sessionStorage.setItem('username', res.username);
        sessionStorage.setItem('userid', res.userid);
        sessionStorage.setItem('message', res.message);
        sessionStorage.setItem('about_us_text', res.about_us_text);
        sessionStorage.setItem('inst_announcement', res.inst_announcement);
        sessionStorage.setItem('logo_url', res.logo_url);
        sessionStorage.setItem('permitted_roles', JSON.stringify(res.featureDivMapping));
        sessionStorage.setItem('enable_routing', res.enable_routing);
        sessionStorage.setItem('enable_online_payment_feature', res.enable_online_payment_feature);
        sessionStorage.setItem('institute_setup_type', res.institute_setup_type);
        sessionStorage.setItem('allow_sms_approve_feature', res.allow_sms_approve_feature);
        sessionStorage.setItem('enable_eLearn_feature', res.enable_eLearn_feature); //
        sessionStorage.setItem('open_enq_Visibility_feature', res.open_enq_Visibility_feature);
    };
    // closeSubMenu(){
    //   let totalExternalClasses = document.getElementsByClassName("external-menu").length;
    //   for(let i = 0; i < totalExternalClasses; i++){
    //     document.getElementsByClassName("external-menu")[i].style.display = "none";
    //   }
    // }
    // FOR Search
    CoreSidednavComponent.prototype.showSearchBar = function () {
        this.searchBar = true;
        window.setTimeout(function () {
            document.getElementById("search_bar").focus();
        }, 550);
    };
    CoreSidednavComponent.prototype.closeSearchBar = function () {
        this.searchBar = false;
    };
    CoreSidednavComponent.prototype.triggerSearchBox = function ($event) {
        $event.preventDefault();
        this.isResultDisplayed = true;
        this.seachResult.nativeElement.classList.add('searchView');
        this.hideSearchPopup.emit(null);
    };
    CoreSidednavComponent.prototype.closeSearch = function (e) {
        this.isResultDisplayed = e;
        this.seachResult.nativeElement.classList.remove('searchView');
        //this.userInput = '';
        // if(e){
        //   this.searchBar = false;
        // }
        // else{
        //   this.searchBar = true;
        // }
        // this.searchBar = false;
    };
    CoreSidednavComponent.prototype.filterGlobal = function (value) {
        var _this = this;
        if (value != null && value != undefined) {
            if (value.trim() != '' && value.length >= 4) {
                var obj = this.getSearchObject(value);
                this.inputValue = value;
                this.searchViewMore.emit(null);
                /* Loading Shows */
                this.resultStat = 0;
                this.fetchService.globalSearch(obj).subscribe(function (res) {
                    _this.resultStat = 1;
                    if (res.length != 0) {
                        _this.enquiryResult = res.filter(function (e) { return e.source == "Enquiry"; });
                        _this.studentResult = res.filter(function (s) { return s.source == "Student"; });
                    }
                    else {
                        _this.commonService.showErrorMessage("info", "No Records Found", "Please try with a different keyword");
                    }
                }, function (err) {
                });
            }
            else {
            }
        }
    };
    CoreSidednavComponent.prototype.getSearchObject = function (e) {
        var obj = this.globalSearchForm;
        /* Name detected */
        if (isNaN(e)) {
            this.globalSearchForm.name = e;
            this.globalSearchForm.phone = '';
            return this.globalSearchForm;
        }
        else {
            this.globalSearchForm.phone = e;
            this.globalSearchForm.name = '';
            return this.globalSearchForm;
        }
    };
    CoreSidednavComponent.prototype.selectedStudent = function (s) {
        this.closeSearch(false);
        this.router.navigate(['/view/students'], { queryParams: { id: s.id } });
        this.searchBar = false;
    };
    CoreSidednavComponent.prototype.selectedEnquiry = function (e) {
        this.closeSearch(false);
        this.router.navigate(['/view/enquiry'], { queryParams: { id: e.id } });
        this.searchBar = false;
    };
    CoreSidednavComponent.prototype.searchAgain = function (e) {
        this.userInput = e;
    };
    CoreSidednavComponent.prototype.viewMoreRecods = function (e) {
        var obj = {
            source: e,
            input: this.userInput
        };
        this.closeSearch(false);
        this.searchViewMore.emit(obj);
        this.searchBar = false;
    };
    CoreSidednavComponent.prototype.actionSelected = function (d) {
        this.closeSearch(false);
        if (d.data.source == "Student") {
            this.router.navigate(['/view/students'], { queryParams: { id: d.data.id, action: d.action } });
            this.searchBar = false;
        }
        else if (d.data.source == "Enquiry") {
            if (d.action == "enquiryUpdate") {
                this.enquiryUpdateAction.emit(d);
                this.searchBar = false;
            }
            else {
                this.router.navigate(['/view/enquiry'], { queryParams: { id: d.data.id, action: d.action } });
                this.searchBar = false;
            }
        }
    };
    CoreSidednavComponent.prototype.openInNewTab = function (url) {
        window.open(url, "_blank");
        this.helpMenu = false;
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divAdminTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divAdminTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divMyAccountTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divMyAccountTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divMasterTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divMasterTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divProfileTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divProfileTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divTeacherTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divTeacherTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divFeeTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divFeeTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divSlotTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divSlotTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divClassRoomTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divClassRoomTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divManageTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divManageTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divAcademicTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divAcademicTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divGradesTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divGradesTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divManageUsers'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divManageUsers", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divSettingTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divSettingTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divGeneralSettingTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divGeneralSettingTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divManageFormTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divManageFormTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divAreaAndMap'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "divAreaAndMap", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('searchInput'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "searchInput", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('seachResult'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CoreSidednavComponent.prototype, "seachResult", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('form'),
        __metadata("design:type", Object)
    ], CoreSidednavComponent.prototype, "form", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], CoreSidednavComponent.prototype, "searchViewMore", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], CoreSidednavComponent.prototype, "enquiryUpdateAction", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], CoreSidednavComponent.prototype, "hideSearchPopup", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], CoreSidednavComponent.prototype, "changePassword", void 0);
    CoreSidednavComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'core-sidednav',
            template: __webpack_require__("./src/app/components/core/core-sidednav/core-sidednav.component.html"),
            styles: [__webpack_require__("./src/app/components/core/core-sidednav/core-sidednav.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__["a" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_7__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__["a" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_2__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_5__services_fetchprefilldata_service__["a" /* FetchprefilldataService */],
            __WEBPACK_IMPORTED_MODULE_6__services_multiBranchdata_service__["a" /* MultiBranchDataService */],
            __WEBPACK_IMPORTED_MODULE_8__services_common_service__["a" /* CommonServiceFactory */]])
    ], CoreSidednavComponent);
    return CoreSidednavComponent;
}());



/***/ }),

/***/ "./src/app/components/core/search-box/search-box.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper black-bg\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n  </loaders-css>\r\n\r\n<div class=\"search-dropdown-box search-item\">\r\n\r\n  <section *ngIf=\"resultStat == 0\">\r\n    <ul>\r\n      <li>\r\n        <h6>\r\n          <span>\r\n            <div class=\"skeleton\">\r\n            </div>\r\n          </span>\r\n        </h6>\r\n      </li>\r\n      <li>\r\n        <h6>\r\n          <span>\r\n            <div class=\"skeleton\">\r\n            </div>\r\n          </span>\r\n        </h6>\r\n      </li>\r\n    </ul>\r\n  </section>\r\n\r\n  <section *ngIf=\"resultStat == 1\">\r\n\r\n    <!-- No Result, No Recent Search -->\r\n    <ul class=\"sdb search-item\" *ngIf=\"searchResult.length == 0 && recentlySearched.size == 0\">\r\n      <li>\r\n        <h6>\r\n          <span>\r\n            No Recent Search\r\n          </span>\r\n        </h6>\r\n      </li>\r\n    </ul>\r\n\r\n    <!-- No Result, Few Recent Search -->\r\n    <ul class=\"sdb search-item\" *ngIf=\"searchResult.length == 0 && recentlySearched.size != 0\">\r\n      <li>\r\n        <h5>\r\n          <span>\r\n            Your Recent Searches\r\n          </span>\r\n          <!-- <a>View More</a> -->\r\n        </h5>\r\n        <ul class=\"in-student-list search-item\">\r\n          <li class=\"search-item\" *ngFor=\"let rs of recentlySearched\">\r\n            <a>\r\n              <span class=\"sdb-right search-item\">\r\n                <label class=\"recent search-item\" (click)=\"searchThisAgain(rs)\">\r\n                  <strong>{{rs}}</strong>\r\n                </label>\r\n                <label class=\"delete search-item\">\r\n                  <img class=\"search-item\" src=\"./assets/images/cross.png\" (click)=\"deleteRecent(rs)\" alt=\"delete\">\r\n                </label>\r\n              </span>\r\n            </a>\r\n          </li>\r\n        </ul>\r\n      </li>\r\n    </ul>\r\n\r\n    <!-- Result-->\r\n    <ul class=\"sdb search-item\" *ngIf=\"searchResult.length != 0\">\r\n      <li *ngIf=\"studentResult.length != 0\">\r\n        <h5>\r\n          <span>\r\n            In Students\r\n          </span>\r\n          <a *ngIf=\"hasStudent\" (click)=\"fullView('student')\">View More</a>\r\n        </h5>\r\n        <ul class=\"in-student-list\">\r\n          <li *ngFor=\"let student of studentResult\">\r\n            <ul class=\"holder\">\r\n              <li>\r\n                <!-- (click)=\"studentSelected(student)\" -->\r\n                <a>\r\n                  <!-- <img src=\"\" alt=\"\" /> -->\r\n                  <img [src]=\"student.thumbnail_url\" alt=\"profile\" class=\"profile_img\" title=\"{{student.name}}\">\r\n                  <span class=\"sdb-right\">\r\n                    <label>\r\n                      <strong>{{student.name}}</strong>\r\n                    </label>\r\n                    <span>\r\n                      +91 {{student.phone}} | Enrolment ID : {{student.displayId}}\r\n                    </span>\r\n                  </span>\r\n                </a>\r\n              </li>\r\n              <li>\r\n                <a *ngIf=\"hasStudent\" class=\"markers\" (click)=\"performAction('studentEdit', student)\">\r\n                  Edit Student\r\n                </a>\r\n                <a *ngIf=\"hasStudent\" class=\"markers\" (click)=\"performAction('studentFee', student)\">\r\n                  Manage Fee\r\n                </a>\r\n                <!-- <a *ngIf=\"hasStudent\" class=\"markers\" (click)=\"performAction('studentInventory', student)\">\r\n                  Manage Inventory\r\n                </a> -->\r\n                <a *ngIf=\"hasStudent\" class=\"markers\" (click)=\"performAction('studentReortCard', student)\">\r\n                    Download Report Card\r\n                  </a>\r\n                <a *ngIf=\"hasStudent\" class=\"markers hide\" (click)=\"performAction('studentLeave', student)\">\r\n                  Mark Leave\r\n                </a>\r\n                <a *ngIf=\"hasStudent\" class=\"markers hide\" (click)=\"performAction('studentDelete', student)\">\r\n                  Delete\r\n                </a>\r\n              </li>\r\n            </ul>\r\n          </li>\r\n        </ul>\r\n      </li>\r\n      <li *ngIf=\"enquiryResult.length != 0\">\r\n        <h5>\r\n          <span>\r\n            In Enquiry\r\n          </span>\r\n          <a *ngIf=\"hasEnquiry\" (click)=\"fullView('enquiry')\">View More</a>\r\n        </h5>\r\n        <ul class=\"in-student-list\">\r\n          <li *ngFor=\"let enquiry of enquiryResult\">\r\n            <ul class=\"holder\">\r\n              <li>\r\n                <!--  (click)=\"enquirySelected(enquiry)\" -->\r\n                <a>\r\n                  <img src=\"\" alt=\"\" />\r\n                  <span class=\"sdb-right\">\r\n                    <label>\r\n                      <strong>{{enquiry.name}}</strong>\r\n                    </label>\r\n                    <span>\r\n                      +91 {{enquiry.phone}} | Enrolment ID : {{enquiry.displayId}}\r\n                    </span>\r\n                  </span>\r\n                </a>\r\n              </li>\r\n              <li>\r\n                <a *ngIf=\"hasEnquiry\" class=\"markers\" (click)=\"performAction('enquiryEdit',enquiry)\">\r\n                  Edit Enquiry\r\n                </a>\r\n                <a *ngIf=\"hasEnquiry\" class=\"markers hide\" (click)=\"performAction('enquiryDelete')\">\r\n                  Delete Enquiry\r\n                </a>\r\n                <a *ngIf=\"hasEnquiry\" class=\"markers\" (click)=\"performAction('enquiryUpdate',enquiry)\">\r\n                  Update Enquiry\r\n                </a>\r\n              </li>\r\n            </ul>\r\n          </li>\r\n        </ul>\r\n      </li>\r\n    </ul>\r\n\r\n  </section>\r\n  <a id=\"downloadFileClick1\"></a>\r\n</div>"

/***/ }),

/***/ "./src/app/components/core/search-box/search-box.component.scss":
/***/ (function(module, exports) {

module.exports = ".skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 100%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n  .skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n  @-webkit-keyframes progress {\n  0% {\n    -webkit-transform: translate3d(-100%, 0, 0);\n            transform: translate3d(-100%, 0, 0); }\n  100% {\n    -webkit-transform: translate3d(100%, 0, 0);\n            transform: translate3d(100%, 0, 0); } }\n  @keyframes progress {\n  0% {\n    -webkit-transform: translate3d(-100%, 0, 0);\n            transform: translate3d(-100%, 0, 0); }\n  100% {\n    -webkit-transform: translate3d(100%, 0, 0);\n            transform: translate3d(100%, 0, 0); } }\n  .sdb {\n  cursor: pointer; }\n  .sdb > li {\n    padding: 8px 0;\n    border-bottom: 2px solid rgba(211, 212, 213, 0.2);\n    margin-bottom: 16px;\n    cursor: pointer; }\n  .sdb > li:last-child {\n      border-bottom: 0;\n      margin-bottom: 0; }\n  .sdb > li h5 {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: justify;\n          -ms-flex-pack: justify;\n              justify-content: space-between;\n      color: #1e2328;\n      font-size: 14px;\n      cursor: pointer;\n      margin-bottom: 12px; }\n  .sdb > li h5 span {\n        text-transform: uppercase;\n        opacity: 0.8;\n        margin-bottom: 4px;\n        font-weight: 600;\n        cursor: pointer; }\n  .sdb > li h6 {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: justify;\n          -ms-flex-pack: justify;\n              justify-content: space-between;\n      color: #1e2328;\n      font-size: 12px;\n      cursor: pointer;\n      margin-bottom: 12px; }\n  .sdb > li h6 span {\n        text-transform: uppercase;\n        opacity: 0.8;\n        margin-bottom: 4px;\n        font-weight: 600;\n        cursor: pointer; }\n  .in-student-list > li {\n  margin-bottom: 0px;\n  cursor: pointer; }\n  .in-student-list > li a {\n    display: block;\n    margin: 0 -15px;\n    padding: 8px 15px;\n    cursor: pointer; }\n  .in-student-list > li a:hover {\n      background: rgba(27, 96, 163, 0.0901961); }\n  .in-student-list > li a img {\n      float: left;\n      width: 30px;\n      height: 30px;\n      border-radius: 50%;\n      margin-right: 12px;\n      cursor: pointer; }\n  .in-student-list > li a .sdb-right {\n      display: block;\n      overflow: hidden;\n      color: rgba(30, 35, 40, 0.7);\n      cursor: pointer; }\n  .in-student-list > li a .sdb-right label {\n        display: block;\n        margin-bottom: 6px;\n        cursor: pointer; }\n  .in-student-list > li a .sdb-right label strong {\n          font-weight: 600; }\n  .in-student-list > li a .sdb-right label.recent {\n          display: inline-block;\n          margin-bottom: 6px;\n          color: rgba(30, 35, 40, 0.7);\n          width: 85%; }\n  .in-student-list > li a .sdb-right label.delete {\n          display: inline-block;\n          margin-bottom: 6px;\n          color: rgba(30, 35, 40, 0.7);\n          width: 10%; }\n  .in-student-list > li a .sdb-right label.delete img {\n            float: left;\n            width: 14px;\n            height: 14px;\n            border-radius: 50%;\n            margin-right: 0px;\n            cursor: pointer; }\n  .in-student-list > li a .sdb-right span {\n        font-size: 12px;\n        cursor: pointer; }\n  .in-student-list > li a.markers {\n      display: inline-block;\n      margin: 0px;\n      padding: 8px 10px; }\n  .profile_img {\n  border-radius: 25px;\n  height: 30px;\n  width: 30px;\n  max-width: 30px;\n  max-height: 30px; }\n"

/***/ }),

/***/ "./src/app/components/core/search-box/search-box.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SearchBoxComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__ = __webpack_require__("./src/app/services/login-services/login.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_http_service__ = __webpack_require__("./src/app/services/http.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var SearchBoxComponent = /** @class */ (function () {
    function SearchBoxComponent(router, cd, renderer, eRef, log, _http, commonService) {
        this.router = router;
        this.cd = cd;
        this.renderer = renderer;
        this.eRef = eRef;
        this.log = log;
        this._http = _http;
        this.commonService = commonService;
        this.studentResult = [];
        this.enquiryResult = [];
        this.resultStat = 1;
        this.closeSearch = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.searchAgain = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.enqSelected = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.stuSelected = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.actionSelected = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.closeMenu = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.viewAll = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.searchResult = [];
        this.recentlySearched = new Set;
        this.hasStudent = false;
        this.hasEnquiry = false;
        this.isRippleLoad = false;
        // this.auth.currentInstituteId.subscribe(id => {
        //     this.institute_id = id;
        //   });
    }
    SearchBoxComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (sessionStorage.getItem('recentSearch') != null && sessionStorage.getItem('recentSearch') != undefined && sessionStorage.getItem('recentSearch') != '' && this.recentlySearched.size == 0 && sessionStorage.getItem('recentSearch') != '{}') {
            this.recentlySearched = JSON.parse(sessionStorage.getItem('recentSearch'));
        }
        this.log.currentPermissions.subscribe(function (e) {
            if (e != '' && e != null && e != undefined && e != []) {
                var perm = JSON.parse(sessionStorage.getItem('permissions'));
                if (perm != '' && perm != null && perm != undefined && perm != []) {
                    var permissionArray = perm;
                    var id = '115';
                    var id2 = '110';
                    var id3 = '301';
                    var id4 = '303';
                    if (permissionArray.indexOf(id) != -1 || permissionArray.indexOf(id2) != -1) {
                        _this.hasEnquiry = true;
                        if (permissionArray.indexOf(id3) != -1) {
                            _this.hasStudent = true;
                        }
                    }
                    else if (permissionArray.indexOf(id3) != -1 || permissionArray.indexOf(id4) != -1) {
                        _this.hasStudent = true;
                    }
                }
            }
            else {
                _this.hasEnquiry = false;
                _this.hasStudent = false;
                var type = sessionStorage.getItem('userType');
                if (type == '0') {
                    _this.hasEnquiry = true;
                    _this.hasStudent = true;
                }
            }
        });
    };
    SearchBoxComponent.prototype.ngOnChanges = function () {
        this.studentResult;
        this.enquiryResult;
        this.searchValue;
        this.updateResult();
        this.studentResult.forEach(function (student) {
            student.thumbnail_url = student.thumbnail_url + '?' + Math.random().toFixed(2);
            ;
        });
    };
    SearchBoxComponent.prototype.onWindowClick = function (event) {
        if (this.eRef.nativeElement.contains(event.target)) {
        }
        else {
            if (!event.target.classList.contains('search-item')) {
                this.closeSearch.emit(false);
            }
        }
    };
    SearchBoxComponent.prototype.updateResult = function () {
        this.searchResult = this.studentResult.concat(this.enquiryResult);
        if (this.searchValue != null && this.searchValue != undefined) {
            if (this.recentlySearched.size <= 5) {
                this.recentlySearched.add(this.searchValue);
                sessionStorage.setItem('recentSearch', JSON.stringify(this.recentlySearched));
            }
            else {
                var value = this.recentlySearched.values();
                var del = value.next().value;
                this.recentlySearched.delete(del);
                this.recentlySearched.add(this.searchValue);
                sessionStorage.setItem('recentSearch', JSON.stringify(this.recentlySearched));
            }
        }
    };
    SearchBoxComponent.prototype.searchThisAgain = function (rs) {
        this.searchAgain.emit(rs);
    };
    SearchBoxComponent.prototype.studentSelected = function (s) {
        this.stuSelected.emit(s);
    };
    SearchBoxComponent.prototype.enquirySelected = function (e) {
        this.enqSelected.emit(e);
    };
    SearchBoxComponent.prototype.deleteRecent = function (rs) {
        this.recentlySearched.delete(rs);
    };
    SearchBoxComponent.prototype.fullView = function (id) {
        //console.log(id);
        this.viewAll.emit(id);
    };
    SearchBoxComponent.prototype.performAction = function (a, d) {
        sessionStorage.setItem('global_search_edit_student', 'true');
        switch (a) {
            case 'studentEdit': {
                var obj = {
                    action: a,
                    data: d
                };
                this.actionSelected.emit(obj);
                break;
            }
            case 'studentFee': {
                var obj = {
                    action: a,
                    data: d
                };
                this.actionSelected.emit(obj);
                break;
            }
            case 'studentInventory': {
                var obj = {
                    action: a,
                    data: d
                };
                this.actionSelected.emit(obj);
                break;
            }
            case 'studentLeave': {
                var obj = {
                    action: a,
                    data: d
                };
                this.actionSelected.emit(obj);
                break;
            }
            case 'studentDelete': {
                var obj = {
                    action: a,
                    data: d
                };
                this.actionSelected.emit(obj);
                break;
            }
            case 'studentReortCard': {
                // let obj = {
                //     action: a,
                //     data: d
                // }
                console.log(d.id);
                this.downloadStudentReportCard(d.id);
                break;
            }
            case 'enquiryEdit': {
                var obj = {
                    action: a,
                    data: d
                };
                this.actionSelected.emit(obj);
                break;
            }
            case 'enquiryUpdate': {
                var obj = {
                    action: a,
                    data: d
                };
                this.actionSelected.emit(obj);
                break;
            }
        }
    };
    SearchBoxComponent.prototype.downloadStudentReportCard = function (student_id) {
        var _this = this;
        this.isRippleLoad = true;
        var url = '/api/v1/reports/Student/downloadReportCard/' + sessionStorage.getItem('institute_id') + '/' + student_id;
        this._http.getData(url).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.closeSearch.emit(false);
            _this.closeMenu.emit(false);
            if (res.document != "") {
                var byteArr = _this.commonService.convertBase64ToArray(res.document);
                var fileName = res.docTitle;
                var file = new Blob([byteArr], { type: 'application/pdf;charset=utf-8;' });
                var url_1 = URL.createObjectURL(file);
                var dwldLink = document.getElementById('downloadFileClick1');
                dwldLink.setAttribute("href", url_1);
                dwldLink.setAttribute("download", fileName);
                document.body.appendChild(dwldLink);
                dwldLink.click();
            }
            else {
                _this.commonService.showErrorMessage('info', 'Info', "Document does not have any data.");
            }
        }, function (err) {
            _this.isRippleLoad = false;
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], SearchBoxComponent.prototype, "searchValue", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], SearchBoxComponent.prototype, "studentResult", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], SearchBoxComponent.prototype, "enquiryResult", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], SearchBoxComponent.prototype, "resultStat", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], SearchBoxComponent.prototype, "closeSearch", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], SearchBoxComponent.prototype, "searchAgain", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], SearchBoxComponent.prototype, "enqSelected", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], SearchBoxComponent.prototype, "stuSelected", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], SearchBoxComponent.prototype, "actionSelected", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], SearchBoxComponent.prototype, "closeMenu", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], SearchBoxComponent.prototype, "viewAll", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["HostListener"])("document:click", ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], SearchBoxComponent.prototype, "onWindowClick", null);
    SearchBoxComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'search-box',
            template: __webpack_require__("./src/app/components/core/search-box/search-box.component.html"),
            styles: [__webpack_require__("./src/app/components/core/search-box/search-box.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["Renderer2"],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"],
            __WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__["a" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_3__services_http_service__["a" /* HttpService */],
            __WEBPACK_IMPORTED_MODULE_4__services_common_service__["a" /* CommonServiceFactory */]])
    ], SearchBoxComponent);
    return SearchBoxComponent;
}());



/***/ }),

/***/ "./src/app/components/core/side-bar/side-bar.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"sideBar\">\r\n  <section class=\"institute-logo-name-container\">\r\n    <!-- <div class=\"institute-logo-container\">\r\n      <img src=\"\" alt=\"\">\r\n    </div> -->\r\n    <div class=\"institute-name-container\">\r\n      <span>{{instituteName}}</span>\r\n    </div>\r\n  </section>\r\n  <div class=\"nav\" (click)=\"closeMenu()\">\r\n    <div class=\"search-container\">\r\n      <form autocomplete=\"off\" #form=\"ngForm\">\r\n        <input type=\"text\" value=\"\" id=\"search_bar\" [(ngModel)]=\"userInput\" name=\"userInput\" #searchInput\r\n          [ngClass]=\"{'has-focus': isResultDisplayed}\" (focus)=\"triggerSearchBox($event)\" autocomplete=\"off\"\r\n          maxlength=\"20\" placeholder=\"Search here...\"\r\n          class=\"search-input searchbox form-ctrl-head search-item searchBox\">\r\n      </form>\r\n      <i class=\"fa fa-search search-icon\" aria-hidden=\"true\"></i>\r\n      <section class=\"search-dropdown search-item\" #seachResult>\r\n        <search-box (closeSearch)=\"closeSearch($event)\" [searchValue]=\"inputValue\" [resultStat]=\"resultStat\"\r\n          [studentResult]=\"studentResult\" (viewAll)=\"viewMoreRecods($event)\" (searchAgain)=\"searchAgain($event)\"\r\n          (stuSelected)=\"selectedStudent($event)\" (enqSelected)=\"selectedEnquiry($event)\"\r\n          [enquiryResult]=\"enquiryResult\" (actionSelected)=\"actionSelected($event)\" (closeMenu)=\"closeMenu()\">\r\n        </search-box>\r\n      </section>\r\n    </div>\r\n    <span [ngClass]=\"activeSession === 'lizero' ? 'active activeClass' : 'NavLink'\" routerLink=\"/view/home\" id=\"lizero\"\r\n      class=\"\" (click)=\"toggler('lizero')\">\r\n      <img src=\"./assets/images/sidebar/home.svg\" alt=\"\" class=\"sideBar_centerAlign\">\r\n      <span class=\"sideBar_centerAlign\" style=\"padding-left: 5px\">Home </span>\r\n    </span>\r\n    <span [ngClass]=\"activeSession === 'lione' ? 'active activeClass' : 'NavLink'\" routerLink=\"/view/leads\" id=\"lione\"\r\n       (click)=\"toggler('lione')\" *ngIf=\"jsonFlags.isShowLead\" >\r\n      <img src=\"./assets/images/sidebar/lead.svg\" alt=\"\" class=\"sideBar_centerAlign\">\r\n      <span class=\"sideBar_centerAlign\" style=\"padding-left: 5px\">Lead</span>\r\n    </span>\r\n    <span [ngClass]=\"activeSession === 'litwo' ? 'active activeClass' : 'NavLink'\" routerLink=\"/view/students\"\r\n      id=\"litwo\"  (click)=\"toggler('litwo')\" *ngIf=\"jsonFlags.isShowStudent\">\r\n      <img src=\"./assets/images/sidebar/student.svg\" alt=\"\" class=\"sideBar_centerAlign\">\r\n    <span class=\"sideBar_centerAlign\" style=\"padding-left: 5px\">Student</span>\r\n    </span>\r\n    <span [ngClass]=\"activeSession === 'lithree' ? 'active activeClass' : 'NavLink'\"\r\n      [routerLink]=\"isLangInstitute?'/view/batch': '/view/course'\"  id=\"lithree\" \r\n      (click)=\"toggler('lithree')\" *ngIf=\"jsonFlags.isShowModel\"> \r\n      <img src=\"./assets/images/sidebar/course.svg\" alt=\"\" class=\"sideBar_centerAlign\">\r\n      <span id=\"li3\" *ngIf=\"(!isLangInstitute)\" class=\"sideBar_centerAlign\" style=\"padding-left: 5px\">Course</span>\r\n      <span id=\"li3\" *ngIf=\"(isLangInstitute)\" class=\"sideBar_centerAlign\" style=\"padding-left: 5px\">Batch</span>\r\n    </span>\r\n    <span [ngClass]=\"activeSession === 'lifour' ? 'active activeClass' : 'NavLink'\" routerLink=\"/view/fee\"\r\n      id=\"lifour\" (click)=\"toggler('lifour')\"  *ngIf=\"jsonFlags.isShowFee\">\r\n      <img src=\"./assets/images/sidebar/fees.svg\" alt=\"\" class=\"sideBar_centerAlign\">\r\n    <span class=\"sideBar_centerAlign\" style=\"padding-left: 5px\">Fees</span>\r\n    </span>\r\n    <span [ngClass]=\"activeSession === 'lifive' ? 'active activeClass' : 'NavLink'\" routerLink=\"/view/live-classes\"\r\n      (click)=\"toggler('lifive')\"  id=\"lifive\" *ngIf=\"jsonFlags.isShowLiveclass\">\r\n      <img src=\"./assets/images/sidebar/live-class.svg\" alt=\"\" class=\"sideBar_centerAlign\">\r\n    <span class=\"sideBar_centerAlign\" style=\"padding-left: 5px\">Live Class</span>\r\n    </span>\r\n    <span [ngClass]=\"activeSession === 'lisix' ? 'active activeClass' : 'NavLink'\" routerLink=\"/view/communicate\"\r\n      (click)=\"toggler('lisix')\"  id=\"lisix\" *ngIf=\"jsonFlags.isShowCommunicate\">\r\n      <img src=\"./assets/images/sidebar/communicate.svg\" alt=\"\" class=\"sideBar_centerAlign\">\r\n    <span class=\"sideBar_centerAlign\" style=\"padding-left: 5px\">Communicate</span>\r\n    </span>\r\n    <span  routerLink=\"/view/library/issue\" [ngClass]=\"activeSession === 'liseven' ? 'active activeClass' : 'NavLink'\"   \r\n    *ngIf=\"jsonFlags.isShowLibrabry\"   (click)=\"toggler('liseven')\">\r\n      <img src=\"./assets/images/sidebar/library.svg\" alt=\"\" class=\"sideBar_centerAlign\">\r\n    <span class=\"sideBar_centerAlign\" style=\"padding-left: 5px\">Library</span>\r\n    </span>\r\n    <span [ngClass]=\"activeSession === 'lieight' ? 'active activeClass' : 'NavLink'\" routerLink=\"/view/e-store/home\"\r\n      id=\"lieight\"  (click)=\"toggler('lieight')\" *ngIf=\"jsonFlags.isShoweStore\">\r\n      <img src=\"./assets/images/sidebar/eStore.svg\" alt=\"\" class=\"sideBar_centerAlign\">\r\n    <span class=\"sideBar_centerAlign\" style=\"padding-left: 5px\">eStore</span>\r\n    </span>\r\n    <span [ngClass]=\"activeSession === 'linine' ? 'active activeClass' : 'NavLink'\" routerLink=\"/view/online-exam\"\r\n      id=\"linine\"  (click)=\"toggler('linine')\" *ngIf=\"jsonFlags.isShoweOnlineExam\">\r\n      <img src=\"./assets/images/sidebar/online_exam.svg\" alt=\"\" class=\"sideBar_centerAlign\">\r\n    <span class=\"sideBar_centerAlign\" style=\"padding-left: 5px\">Online Exam</span>\r\n    </span>\r\n    <!-- <span class=\"NavLink\" href=\"#/app/dashboard\">\r\n      <img src=\"./assets/images/sidebar/employee.svg\" alt=\"\">\r\n      Empolyee\r\n    </span>\r\n    <span class=\"NavLink\" href=\"#/app/dashboard\">\r\n      <img src=\"./assets/images/sidebar/expenses.svg\" alt=\"\">\r\n      Expense\r\n    </span>\r\n    <span class=\"NavLink\" href=\"#/app/dashboard\">\r\n      <img src=\"./assets/images/sidebar/task.svg\" alt=\"\">\r\n      Task\r\n    </span>\r\n    <span class=\"NavLink\" routerLink=\"/view/students\">\r\n      <i class=\"fa fa-money\" aria-hidden=\"true\"></i>\r\n      Dashboard\r\n    </span> -->\r\n  </div>\r\n  <div style=\"bottom: 16%;position: absolute;margin-left: 50%;\">\r\n    <span class=\"badge\" (click)=\"showVideo('https://www.youtube.com/embed/kkA-D0i3HeQ')\" title=\"View demo video\">v3.0</span>\r\n  </div>\r\n  <div class=\"videoplayer\" *ngIf=\"videoplayer\">\r\n      <iframe width=\"650\" height=\"400\"\r\n        [src]=\"currentProjectUrl\"\r\n        frameborder=\"0\" style=\"border-radius: 10px;\"\r\n        allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen>\r\n      </iframe>\r\n    </div>\r\n  <div class=\"setting\" [ngStyle]=\"{'bottom':jsonFlags.isShowPowerBy?'20px':'0px'}\" >\r\n    <div class=\"setting-item\">\r\n      <img src=\"./assets/images/sidebar/help.svg\" title=\"Help\" alt=\"\" (click)=\"showSubSection('help')\">\r\n      <div class=\"side-section\" id=\"help\">\r\n        <div class=\"side-section-item\">\r\n          <span (click)=\"openInNewTab('https://procturhelp.freshdesk.com/support/home')\" ><img src=\"./assets/images/sidebar/sideMenu/proctur.svg\" alt=\"faqs\" class=\"helpSection\">FAQs</span>\r\n        </div>\r\n        <div class=\"side-section-item\">\r\n          <span (click)=\"openInNewTab('https://procturhelp.freshdesk.com/support/tickets/new')\"><img src=\"./assets/images/sidebar/sideMenu/support.svg\" alt=\"ticket\" class=\"helpSection\">Create Support\r\n            Ticket</span>\r\n        </div>\r\n        <div class=\"side-section-item\">\r\n          <span (click)=\"openInNewTab('https://anydesk.com/en/downloads/')\"><img src=\"./assets/images/sidebar/sideMenu/download.svg\" alt=\"download\" class=\"helpSection\">Download Anydesk</span>\r\n        </div>\r\n        <div class=\"side-section-item\">\r\n          <span><img src=\"./assets/images/sidebar/sideMenu/call.svg\" alt=\"phone\" class=\"helpSection\">+91 9971839153</span>\r\n        </div>\r\n        <div class=\"side-section-item\" (click)=\"routerLink('/view/training-video' ,'help')\">       \r\n            <span>Training Videos</span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"setting-item\" #divSettingTag id=\"divSettingTag\">\r\n      <img src=\"./assets/images/sidebar/settings.svg\" title=\"Settings\" alt=\"\" \r\n      (click)=\"routerLink('/view/setting','generalSetting');activeSession=null\">\r\n      <div class=\"side-section\" id=\"generalSetting\">\r\n        </div>\r\n    </div>\r\n    <div class=\"setting-item\" #divMasterTag id=\"divMasterTag\">\r\n      <img src=\"./assets/images/sidebar/setup.svg\" title=\"Setup\" alt=\"\" (click)=\"showSubSection('setup')\">\r\n      <div class=\"side-section\" id=\"setup\">\r\n          <div class=\"side-section-item\" *ngIf=\"hasInventoryAccess()\">\r\n              <span (click)=\"routerLink('/view/inventory','setup')\"><img src=\"./assets/images/sidebar/inventory.svg\" alt=\"phone\" class=\"helpSection\">Manage Inventory</span>\r\n            </div>\r\n            <div class=\"side-section-item\">\r\n              <span (click)=\"routerLink('/view/formField/home','setup')\"><img src=\"./assets/images/sidebar/custom_form_field.svg\" alt=\"phone\" class=\"helpSection\">Custom Form Field</span>\r\n            </div>\r\n            <div class=\"side-section-item\">\r\n              <span (click)=\"routerLink('/view/master/areaCity','setup')\"><img src=\"./assets/images/sidebar/city_area_map.svg\" alt=\"phone\" class=\"helpSection\">City Area Map</span>\r\n            </div>\r\n            <div class=\"side-section-item\" *ngIf=\"jsonFlags.isShowLibrabry\">\r\n                <span (click)=\"routerLink('/view/library/master','setup')\"><img src=\"./assets/images/sidebar/master_data.svg\" alt=\"phone\" class=\"helpSection\">Library</span>\r\n              </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"setting-item\" (click)=\"showSubSection('branches')\" *ngIf=\"isMainBranch == 'Y' && checkAdmin\">\r\n      <img src=\"./assets/images/sidebar/branches.svg\" title=\"Branches\" alt=\"\">\r\n      <div class=\"side-section\" id=\"branches\">\r\n        <div class=\"side-section-item\" *ngFor=\"let data of branchesList\">\r\n          <span (click)=\"onSubBranchClick(data)\">{{data.institute_name}}</span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"setting-item\" (click)=\"showSubMenu('branches')\" *ngIf=\"(showMainBranchBackBtn)\">\r\n      <img src=\"./assets/images/sidebar/branches.svg\" title=\"Back To Main Branch\" alt=\"\" (click)=\"loginToMainBranch()\">\r\n    </div>\r\n    <div class=\"setting-item\" #divManageUsers id=\"divManageUsers\">\r\n      <img src=\"./assets/images/sidebar/users.svg\" title=\"Manage Users\" alt=\"\"\r\n        (click)=\"routerLink('/view/manage','user');activeSession=null\">\r\n        <div class=\"side-section\" id=\"user\">\r\n          </div>\r\n    </div>\r\n    <div class=\"setting-item\"  #divMyAccountTag id=\"divMyAccountTag\">\r\n      <img src=\"./assets/images/sidebar/my-account.svg\" title=\"My Account\" alt=\"\" (click)=\"showSubSection('account')\">\r\n      <div class=\"side-section\" id=\"account\">\r\n        <div class=\"side-section-item\">\r\n          <span (click)=\"routerLink('/view/account','account')\"><img src=\"./assets/images/sidebar/sideMenu/account.svg\" alt=\"icon\" class=\"helpSection\">My Account</span>\r\n        </div>\r\n        <div class=\"side-section-item\">\r\n          <span (click)=\"changePasswordClick()\"><img src=\"./assets/images/sidebar/change_password.svg\" alt=\"phone\" class=\"helpSection\">Change Password</span>\r\n        </div>\r\n        <div class=\"side-section-item\">\r\n          <span (click)=\"logout()\"><img src=\"./assets/images/sidebar/sideMenu/logout.svg\" alt=\"icon\" class=\"helpSection\">Logout</span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"proctur-info\"  *ngIf=\"jsonFlags.isShowPowerBy\">\r\n    <a href=\"https://www.proctur.com/\" target=\"_blank\"> <span>Powered by Proctur</span> </a>\r\n  </div>\r\n\r\n</section>\r\n\r\n<aside class=\"blur-background\" id=\"blurBg\" *ngIf=\"sideBar  || searchBar || helpMenu || videoplayer\" (click)=\"closeMenu()\">\r\n</aside>"

/***/ }),

/***/ "./src/app/components/core/side-bar/side-bar.component.scss":
/***/ (function(module, exports) {

module.exports = ".sideBar {\n  position: fixed;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  background-color: #2e3345;\n  width: 150px;\n  z-index: 1111; }\n\n.institute-logo-name-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  width: 100%;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  padding: 5px 10px;\n  border-bottom: 1px solid #b4b6bd; }\n\n.institute-logo-name-container .institute-name-container {\n    width: 100%;\n    text-align: center;\n    color: #b4b6bd;\n    line-height: 20px;\n    font-size: 14px;\n    font-weight: 600; }\n\n.item {\n  border-color: #528ff0;\n  color: #fff;\n  background-color: #252939; }\n\n.nav {\n  margin-bottom: 0;\n  padding-left: 0;\n  list-style: none;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column; }\n\n.search-container {\n  width: 80%;\n  margin: 10px 10%;\n  margin-bottom: 0px;\n  position: relative; }\n\n.search-container .searchBox {\n    border-radius: 4px;\n    border: 1px solid #b4b6bd;\n    width: 100%;\n    background-color: transparent;\n    color: #b4b6bd;\n    line-height: 30px;\n    padding: 0 10px;\n    font-size: 12px; }\n\n.search-container .search-icon {\n    position: absolute;\n    right: 5%;\n    color: #b4b6bd;\n    top: 17%;\n    background: #2e3345;\n    padding: 3px; }\n\n.nav .NavLink {\n  background-color: transparent;\n  border-left: 4px solid transparent;\n  color: #b4b6bd;\n  line-height: 36px;\n  padding: 0 12px;\n  width: 100%;\n  cursor: pointer; }\n\n.nav .NavLink .fa {\n    margin-right: 10px;\n    width: 16px;\n    text-align: center; }\n\n.sidebar .nav span.activation-status-link {\n  padding: 0;\n  line-height: inherit;\n  border: none; }\n\n.active {\n  border-color: #528ff0;\n  color: #fff;\n  background-color: #252939;\n  border-left: 4px solid #528ff0;\n  line-height: 36px;\n  padding: 0 12px;\n  width: 100%;\n  cursor: pointer; }\n\n.active .fa {\n    margin-right: 10px;\n    width: 16px;\n    text-align: center; }\n\n.active img {\n    max-height: 16px;\n    max-width: 16px;\n    height: 16px;\n    margin-top: 0px;\n    cursor: pointer; }\n\n.activeClass {\n  border-color: #528ff0;\n  color: #fff;\n  background-color: #252939;\n  border-left: 4px solid #528ff0;\n  line-height: 36px;\n  padding: 0 12px;\n  width: 100%;\n  cursor: pointer; }\n\n.activeClass .fa {\n    margin-right: 10px;\n    width: 16px;\n    text-align: center; }\n\n.activeClass img {\n    max-height: 16px;\n    max-width: 16px;\n    height: 16px;\n    margin-top: 0px;\n    cursor: pointer; }\n\n.nav .NavLink:hover {\n  border-color: #528ff0;\n  color: #fff;\n  background-color: #252939; }\n\n.NavLink img {\n  max-height: 16px;\n  max-width: 16px;\n  height: 16px;\n  margin-top: 0px;\n  cursor: pointer; }\n\n.setting {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  position: fixed;\n  bottom: 20px;\n  left: 0;\n  width: 150px; }\n\n.setting .setting-item {\n    width: 30%;\n    text-align: center;\n    margin-bottom: 10px;\n    position: relative; }\n\n.setting .setting-item img {\n      max-height: 20px;\n      max-width: 20px;\n      height: 20px;\n      cursor: pointer; }\n\n.setting .side-section {\n    display: none;\n    position: fixed;\n    left: 160px;\n    background: White;\n    color: #2e3345;\n    border-radius: 4px;\n    border-radius: 4px;\n    -webkit-box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.35);\n            box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.35);\n    z-index: 1;\n    bottom: 10%;\n    width: 200px; }\n\n.setting .side-section .side-section-item {\n      width: 100%;\n      color: #585574;\n      font-size: 12px;\n      border-bottom: 1px solid rgba(0, 0, 0, 0.35);\n      text-align: left;\n      padding: 10px; }\n\n.setting .side-section .side-section-item span {\n        cursor: pointer; }\n\n.setting .side-section .side-section-item .help-menu-icon-container {\n        width: 9%;\n        margin-right: 8px; }\n\n.setting .side-section .side-section-item .help-menu-icon-container img {\n          width: 15px;\n          height: 15px; }\n\n.setting .side-section .side-section-item:last-child {\n      border-bottom: none; }\n\n.setting .side-section .side-section-item:hover {\n      color: #1283f4; }\n\n.setting .active-current-menu {\n    display: block; }\n\n.setting .remove-current-menu {\n    display: none; }\n\n.search-dropdown {\n  opacity: 0;\n  visibility: hidden;\n  -webkit-transition: all 0.4s ease;\n  transition: all 0.4s ease;\n  -webkit-transform: translateY(10px);\n          transform: translateY(10px);\n  position: absolute;\n  background: #fff;\n  -webkit-box-shadow: 0px 1px 1px 1px rgba(0, 0, 0, 0.219608);\n          box-shadow: 0px 1px 1px 1px rgba(0, 0, 0, 0.219608);\n  border-radius: 4px;\n  padding: 8px 16px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  width: 50%;\n  position: fixed;\n  left: 160px;\n  top: 5%; }\n\n.searchView {\n  opacity: 1;\n  visibility: visible;\n  -webkit-transform: translateY(0);\n          transform: translateY(0); }\n\n.searchbox:focus .search-dropdown {\n  opacity: 1;\n  visibility: visible;\n  -webkit-transform: translateY(0);\n          transform: translateY(0); }\n\n@media only screen and (max-width: 960px) and (min-width: 768px) {\n  .search-dropdown {\n    width: 245px;\n    left: 171px;\n    margin-top: 10px; }\n  .searchbox {\n    width: 122px;\n    -webkit-transition: 0.5s ease;\n    transition: 0.5s ease;\n    border-radius: 5px; }\n    .searchbox.has-focus {\n      width: 244px; }\n  .searchbox:hover.searchbox {\n    width: 244px;\n    -webkit-transition: 0.5s;\n    transition: 0.5s;\n    border-radius: 5px; }\n  .searchbox:focus .search-dropdown {\n    opacity: 1;\n    visibility: visible;\n    -webkit-transform: translateY(0);\n            transform: translateY(0); } }\n\n.proctur-info {\n  text-align: center;\n  font-size: 12px;\n  color: #fff;\n  padding: 10px 0px;\n  position: fixed;\n  bottom: 0px;\n  left: 10px; }\n\n.blur-background {\n  background: rgba(10, 10, 10, 0.2);\n  position: fixed;\n  left: 0px;\n  top: 0px;\n  height: 100%;\n  z-index: 100;\n  width: 100%; }\n\n.normal-background {\n  background: none;\n  position: fixed;\n  left: 0px;\n  top: 0px;\n  height: 100%;\n  width: 100%; }\n\n.sideBar_centerAlign {\n  vertical-align: middle; }\n\n.helpSection {\n  height: 15px;\n  width: 15px;\n  margin-right: 8px;\n  vertical-align: middle; }\n\n@-webkit-keyframes slideInLeft {\n  from {\n    -webkit-transform: translate3d(-100%, 0, 0);\n    transform: translate3d(-100%, 0, 0);\n    visibility: visible; }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n    transform: translate3d(0, 0, 0); } }\n\n@keyframes slideInLeft {\n  from {\n    -webkit-transform: translate3d(-100%, 0, 0);\n    transform: translate3d(-100%, 0, 0);\n    visibility: visible; }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n    transform: translate3d(0, 0, 0); } }\n\n.badge {\n  display: inline-block;\n  min-width: 50px;\n  padding: 3px 7px;\n  font-size: 14px;\n  font-weight: bold;\n  color: #fff;\n  line-height: 1;\n  vertical-align: middle;\n  white-space: nowrap;\n  text-align: center;\n  background-color: #27c24c;\n  border-radius: 10px;\n  letter-spacing: 0.7px;\n  cursor: pointer; }\n\n.videoplayer {\n  position: fixed;\n  top: 15%;\n  left: 30%;\n  z-index: 10; }\n"

/***/ }),

/***/ "./src/app/components/core/side-bar/side-bar.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SideBarComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__ = __webpack_require__("./src/app/services/login-services/login.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_rxjs_add_operator_map__ = __webpack_require__("./node_modules/rxjs/_esm5/add/operator/map.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_rxjs_Rx__ = __webpack_require__("./node_modules/rxjs/_esm5/Rx.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_fetchprefilldata_service__ = __webpack_require__("./src/app/services/fetchprefilldata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_multiBranchdata_service__ = __webpack_require__("./src/app/services/multiBranchdata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__angular_platform_browser__ = __webpack_require__("./node_modules/@angular/platform-browser/esm5/platform-browser.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};










var SideBarComponent = /** @class */ (function () {
    function SideBarComponent(login, auth, log, router, fetchService, multiBranchService, commonService, cd, sanitizer) {
        this.login = login;
        this.auth = auth;
        this.log = log;
        this.router = router;
        this.fetchService = fetchService;
        this.multiBranchService = multiBranchService;
        this.commonService = commonService;
        this.cd = cd;
        this.sanitizer = sanitizer;
        this.searchViewMore = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.enquiryUpdateAction = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.hideSearchPopup = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.changePassword = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.permissionData = [];
        this.enquiryResult = [];
        this.studentResult = [];
        this.branchesList = [];
        this.userType = '';
        this.mainBranchId = "";
        this.isMainBranch = "N";
        this.checkAdmin = "";
        this.resultStat = 1;
        this.teacherId = 0;
        this.sideBar = false;
        this.searchBar = false;
        this.helpMenu = false;
        this.isLangInstitute = false;
        this.showMainBranchBackBtn = false;
        this.isProfessional = false;
        this.menuToggler = false;
        this.isResultDisplayed = false;
        this.manageExamGrades = "";
        this.videoplayer = false;
        this.globalSearchForm = {
            name: '',
            phone: '',
            instituteId: sessionStorage.getItem('institute_id'),
            start_index: '0',
            batch_size: '6'
        };
        this.jsonFlags = {
            isShowLead: false,
            isShowStudent: false,
            isShowModel: false,
            isShowFee: false,
            isShowLiveclass: false,
            isShowCommunicate: true,
            isShowLibrabry: false,
            isShoweStore: false,
            isShoweOnlineExam: false,
            isAdmin: false,
            isShowPowerBy: false
        };
    }
    SideBarComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.settings = sessionStorage.getItem('is_exam_grad_feature');
        this.instituteName = sessionStorage.getItem('institute_name');
        this.userName = sessionStorage.getItem('name');
        this.instituteId = sessionStorage.getItem('institute_id');
        this.log.currentUserType.subscribe(function (e) {
            if (e == '' || e == null || e == undefined) {
            }
            else {
                _this.userType = e;
            }
        });
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.log.currentPermissions.subscribe(function (e) {
            if (e == '' || e == null || e == undefined) {
            }
            else {
                _this.permissionData = JSON.parse(e);
            }
        });
        this.log.currentUsername.subscribe(function (res) {
            _this.createCustomSidenav();
        });
        this.form.valueChanges
            .debounceTime(1000)
            .distinctUntilChanged()
            .subscribe(function (data) {
            _this.userInput = data.userInput;
            _this.enquiryResult = [];
            _this.studentResult = [];
            _this.filterGlobal(data.userInput);
        });
        this.checkUserHadAccess();
        this.checkInstituteType();
        this.checkManinBranch();
        this.hidePowerBy();
    };
    SideBarComponent.prototype.ngAfterViewInit = function () {
        this.setActiveClassOnSideNav();
    };
    SideBarComponent.prototype.hidePowerBy = function () {
        var institute_id = this.globalSearchForm.instituteId;
        this.jsonFlags.isShowPowerBy = true;
        if (institute_id == '101132' ||
            institute_id == '101133' ||
            institute_id == '101134' ||
            institute_id == '101135' ||
            institute_id == '101149' ||
            institute_id == '101150' ||
            institute_id == '101140' ||
            institute_id == '101151') {
            this.jsonFlags.isShowPowerBy = false;
        }
    };
    // USER permission
    SideBarComponent.prototype.checkUserHadAccess = function () {
        // this.divProfileTag.nativeElement.style.display = 'none';
        var permissionArray = sessionStorage.getItem('permissions');
        var usertype = sessionStorage.getItem('userType');
        if (permissionArray == null || permissionArray == "") {
            if (usertype == '0') {
                this.jsonFlags.isAdmin = true;
                this.showAllFields(); // Swapnil
            }
            else if (usertype == '3') {
                this.jsonFlags.isAdmin = true;
                this.jsonFlags.isShowFee = false;
                this.hideAllFields(); // Swapnil
                this.teacherId = JSON.parse(sessionStorage.getItem('institute_info')).teacherId;
                this.setNativeElementValue(['divMyAccountTag'], '');
            }
        }
        else {
            if (permissionArray != undefined) {
                this.setNativeElementValue(['divMasterTag'], 'none');
                if (permissionArray.indexOf('503') != -1) {
                    // this.divMasterTag.nativeElement.style.display = '';
                    // this.divTeacherTag.nativeElement.style.display = '';
                    // this.setNativeElementValue(['divMasterTag', 'divTeacherTag'], '');      // Swapnil
                    this.setNativeElementValue(['divMasterTag'], ''); // Swapnil
                }
                if (permissionArray.indexOf('506') != -1) {
                    this.jsonFlags.isShowFee = true;
                    this.setNativeElementValue(['divMasterTag'], ''); // Swapnil
                }
                if (permissionArray.indexOf('507') != -1 && this.isProfessional) {
                    // this.divMasterTag.nativeElement.style.display = '';
                    // this.divSlotTag.nativeElement.style.display = '';
                    // this.setNativeElementValue(['divMasterTag', 'divSlotTag'], '');       // Swapnil
                    this.setNativeElementValue(['divMasterTag'], ''); // Swapnil
                }
                if (permissionArray.indexOf('509') != -1) {
                    // this.divMasterTag.nativeElement.style.display = '';
                    // this.divAcademicTag.nativeElement.style.display = '';
                    // this.setNativeElementValue(['divMasterTag', 'divAcademicTag'], '');      // Swapnil
                    this.setNativeElementValue(['divMasterTag'], ''); // Swapnil
                }
                if (permissionArray.indexOf('602') != -1) {
                    // this.divSettingTag.nativeElement.style.display = '';
                    // this.divMyAccountTag.nativeElement.style.display = '';
                    this.setNativeElementValue(['divSettingTag', 'divMyAccountTag'], ''); // Swapnil
                }
                if (permissionArray.indexOf('603') != -1) {
                    // this.divSettingTag.nativeElement.style.display = '';
                    // this.divGeneralSettingTag.nativeElement.style.display = '';
                    // this.setNativeElementValue(['divSettingTag', 'divGeneralSettingTag'], '');      // Swapnil
                    this.setNativeElementValue(['divSettingTag'], ''); // Swapnil
                }
                else {
                    this.setNativeElementValue(['divSettingTag'], 'none');
                }
                if (permissionArray.indexOf('115') != -1) {
                    // this.divManageFormTag.nativeElement.style.display = '';
                    // this.divAreaAndMap.nativeElement.style.display = '';
                    // this.setNativeElementValue(['divAreaAndMap'], '');       // Swapnil
                }
                if (permissionArray.indexOf('601') != -1) {
                    // this.divManageUsers.nativeElement.style.display = '';
                    this.setNativeElementValue(['divManageUsers'], ''); // Swapnil
                }
                else {
                    this.setNativeElementValue(['divManageUsers'], 'none');
                }
                if (permissionArray.indexOf('508') != -1) {
                    // this.setNativeElementValue(['divClassRoomTag'], '');          // Swapnil
                    // this.divClassRoomTag.nativeElement.style.display = '';
                }
            }
        }
    };
    SideBarComponent.prototype.setActiveClassOnSideNav = function () {
        // this.RemoveActiveTabs();
        var pathLastURL;
        var str = window.location.href;
        var res = str.substring(str.lastIndexOf("/view") + 6, str.length);
        pathLastURL = res;
        var get_module_name = res.substring(0, res.indexOf("/"));
        if (get_module_name != '') {
            pathLastURL = get_module_name;
        }
        console.log(pathLastURL);
        var routesData = {
            'home': 'lizero',
            'leads': 'lione',
            'students': 'litwo',
            'students/add': 'litwo',
            'course': 'lithree',
            'batch': 'lithree',
            'fee': 'lifour',
            'live-classes': 'lifive',
            'communicate': 'lisix',
            'library': 'liseven',
            'e-store': 'lieight',
            'online-exam': 'linine',
        };
        if (document.getElementById(routesData[pathLastURL])) {
            this.activeSession = routesData[pathLastURL];
        }
    };
    SideBarComponent.prototype.showAllFields = function () {
        // let array = ['divMyAccountTag', 'divMasterTag', 'divTeacherTag',  'divAcademicTag',
        //   'divSettingTag', 'divGeneralSettingTag', 'divManageFormTag', 'divManageUsers', 'divClassRoomTag'];
        var array = ['divMyAccountTag', 'divMasterTag', 'divSettingTag', 'divManag', 'divManageUsers'];
        this.setNativeElementValue(array, '');
        // if (this.settings == '1') {
        //   this.divGradesTag.nativeElement.style.display = '';
        // } else {
        //   this.divGradesTag.nativeElement.style.display = 'none';
        // }
        // if (this.isProfessional) {
        //   this.divSlotTag.nativeElement.style.display = '';
        // }
        // else if (!this.isProfessional) {
        //   this.divSlotTag.nativeElement.style.display = 'none';
        // }   // Swapnil
    };
    SideBarComponent.prototype.hideAllFields = function () {
        // let array = ['divMyAccountTag', 'divMasterTag', 'divTeacherTag', 
        //   'divSlotTag', 'divAcademicTag', 'divSettingTag', 'divGeneralSettingTag', 'divManageFormTag',
        //   'divAreaAndMap', 'divManageUsers', 'divGradesTag', 'divClassRoomTag', 'divManageTag'];
        var array = ['divMyAccountTag', 'divMasterTag', 'divSettingTag', 'divManageUsers'];
        this.setNativeElementValue(array, 'none');
    };
    SideBarComponent.prototype.setNativeElementValue = function (tagArray, value) {
        for (var index in tagArray) {
            if (this[tagArray[index]]) {
                this[tagArray[index]].nativeElement.style.display = value;
            }
        }
    };
    SideBarComponent.prototype.checkManinBranch = function () {
        var _this = this;
        this.auth.isMainBranch.subscribe(function (value) {
            if (_this.isMainBranch != value) {
                _this.isMainBranch = value;
                if (_this.isMainBranch == "Y") {
                    _this.multiBranchInstituteFound();
                }
            }
        });
        this.checkToShowMultiBranch();
        this.multiBranchService.subBranchSelected.subscribe(function (res) {
            _this.showMainBranchBackBtn = res;
        });
    };
    // Multi Branch Case Handling
    SideBarComponent.prototype.multiBranchInstituteFound = function () {
        var _this = this;
        this.mainBranchId = sessionStorage.getItem('institute_id');
        this.multiBranchService.getAllBranches().subscribe(function (res) {
            _this.branchesList = res;
        }, function (err) {
        });
    };
    SideBarComponent.prototype.checkToShowMultiBranch = function () {
        var _this = this;
        this.log.currentUserType.subscribe(function (res) {
            if (res == '3') {
                _this.checkAdmin = false;
            }
            else {
                if (_this.commonService.checkUserIsAdmin()) {
                    _this.checkAdmin = true;
                }
                else {
                    _this.checkAdmin = false;
                }
            }
        });
    };
    SideBarComponent.prototype.validateUsertypePermissionData = function () {
        var p = sessionStorage.getItem('permissions');
        var e = sessionStorage.getItem('userType');
        if (p == '' || p == null || p == undefined) {
            this.permissionData = [];
        }
        if (p != '' && p != null && p != undefined) {
            this.permissionData = JSON.parse(p);
            this.log.changePermissions(p);
        }
        if (e == '' || e == null || e == undefined) {
            this.userType = 0;
        }
        else if (e != '' && e != null && e != undefined) {
            this.userType = e;
            this.log.changeUserType(e);
        }
    };
    //changes by laxmi
    SideBarComponent.prototype.createCustomSidenav = function () {
        var _this = this;
        var p = sessionStorage.getItem('permissions');
        var e = sessionStorage.getItem('userType');
        this.checkDefaultData(p, e);
        var userType = this.userType;
        var permission = this.permissionData;
        var type = Number(sessionStorage.getItem('institute_setup_type'));
        this.isLibraryFeatureAllow(permission); // check librabry feature
        /* Admin or Custom login */
        if (userType == 0) {
            /* admin detected */
            if (permission == null || permission == undefined || permission == '') {
                this.jsonFlags.isAdmin = true;
                var flagsArray = Object.keys(this.jsonFlags);
                flagsArray.forEach(function (object) {
                    _this.jsonFlags[object] = true;
                });
            }
            else {
                /* custom user detected */
                /* array to store the user permissions, if the permission length is less than equal to one
                remove the first and last char and validate if its admin or not */
                this.hasLead(this.permissionData);
                this.hasStudent(this.permissionData);
                this.hasCourse(this.permissionData);
                this.hasProducts(this.permissionData);
            }
            // check these new feature is enable for institute or not
            this.isElearnAllow();
            this.isLibraryFeatureAllow(permission);
        }
        else if (userType == 3) {
            /* Teacher login detected */
            this.jsonFlags.isAdmin = false;
            this.teacherLoginFound();
        }
        // please dont chnage this  code from here 
        this.isOnlineExamAllow(type); // check online test is enable or not 
        this.isLiveClassesAllow(type);
    };
    // check only default values 
    SideBarComponent.prototype.checkDefaultData = function (p, e) {
        if (p == '' || p == null || p == undefined) {
            this.permissionData = [];
        }
        if (p != '' && p != null && p != undefined) {
            this.permissionData = JSON.parse(p);
            this.log.changePermissions(p);
        }
        if (e == '' || e == null || e == undefined) {
            this.userType = 0;
        }
        if (e != '' && e != null && e != undefined) {
            this.userType = e;
            this.log.changeUserType(e);
        }
    };
    SideBarComponent.prototype.isLibraryFeatureAllow = function (permission) {
        this.jsonFlags.isShowLibrabry = false;
        var username = sessionStorage.getItem('username');
        if ((username == "admin" && this.instituteId == 100127) ||
            (username == "admin" && this.instituteId == 101077) ||
            (username == "admin" && this.instituteId == 101223) ||
            (username == "admin" && this.instituteId == 100058) ||
            (username == "admin" && this.instituteId == 100952) ||
            (permission && permission.indexOf('721') != -1)) {
            this.jsonFlags.isShowLibrabry = true;
        }
    };
    SideBarComponent.prototype.isLiveClassesAllow = function (type) {
        this.jsonFlags.isShowLiveclass = false;
        // if user is not admin
        this.jsonFlags.isShowLiveclass = this.checkInstSetupType(type, 256);
    };
    SideBarComponent.prototype.isElearnAllow = function () {
        // this senction is used for enable elearn feature
        if (this.isProfessional || sessionStorage.getItem('enable_eLearn_feature') == '0') {
            this.jsonFlags.isShoweStore = false;
        }
        if (sessionStorage.getItem('enable_elearn_course_mapping_feature') == '1') {
            this.jsonFlags.isShoweStore = true;
        }
    };
    SideBarComponent.prototype.isOnlineExamAllow = function (type) {
        if (this.jsonFlags.isAdmin) {
            this.jsonFlags.isShoweOnlineExam = this.checkInstSetupType(type, 4);
        }
    };
    SideBarComponent.prototype.checkInstSetupType = function (value, role) {
        if (value != 0) {
            var start = 2;
            var count = 1;
            while (start != value) {
                count++;
                start = start + 2;
            }
            var arr = [0, 0, 0, 0, 0, 0, 0, 0];
            var s = count.toString(2);
            var k = 0;
            for (var i = s.length - 1; i >= 0; i--) {
                arr[k] = parseInt(s.charAt(i));
                k++;
            }
            switch (role) {
                case 2:
                    if (arr[0] == 1)
                        return true;
                    break;
                case 4:
                    if (arr[1] == 1)
                        return true;
                    break;
                case 8:
                    if (arr[2] == 1)
                        return true;
                    break;
                case 16:
                    if (arr[3] == 1)
                        return true;
                    break;
                case 32:
                    if (arr[4] == 1)
                        return true;
                    break;
                case 64:
                    if (arr[5] == 1)
                        return true;
                    break;
                case 128:
                    if (arr[6] == 1)
                        return true;
                    break;
                case 256:
                    if (arr[7] == 1)
                        return true;
                    break;
                default: return false;
            }
            return false;
        }
        else {
            return false;
        }
    };
    /// loggedout user
    SideBarComponent.prototype.loggedout = function () {
        var _this = this;
        var flagsArray = Object.keys(this.jsonFlags);
        flagsArray.forEach(function (object) {
            _this.jsonFlags[object] = false;
        });
        document.getElementById('lizero').classList.add('active');
    };
    SideBarComponent.prototype.hasLead = function (permissions) {
        this.jsonFlags.isShowLead = false;
        if (permissions.includes('110') || permissions.includes('115') || permissions.includes('722')) {
            this.jsonFlags.isShowLead = true;
        }
    };
    SideBarComponent.prototype.hasStudent = function (permissions) {
        this.jsonFlags.isShowStudent = false;
        if (permissions.includes('301') ||
            permissions.includes('302') ||
            permissions.includes('303')) {
            this.jsonFlags.isShowStudent = true;
        }
    };
    SideBarComponent.prototype.hasCourse = function (permissions) {
        this.jsonFlags.isShowModel = false;
        if (permissions.includes('401') || permissions.includes('402')
            || permissions.includes('403') || permissions.includes('404') ||
            permissions.includes('405') || permissions.includes('406') ||
            permissions.includes('501') || permissions.includes('502') ||
            permissions.includes('505') || permissions.includes('701') ||
            permissions.includes('704') || permissions.includes('702')) {
            this.jsonFlags.isShowModel = true;
        }
    };
    SideBarComponent.prototype.hasProducts = function (permissions) {
        this.jsonFlags.isShoweStore = false;
        if (this.isProfessional) {
            if (permissions.includes('401') || permissions.includes('402')
                || permissions.includes('403') || permissions.includes('404') ||
                permissions.includes('405') || permissions.includes('406') ||
                permissions.includes('501') || permissions.includes('502') ||
                permissions.includes('505') || permissions.includes('701') ||
                permissions.includes('704') || permissions.includes('702')) {
                this.jsonFlags.isShoweStore = true;
            }
        }
    };
    SideBarComponent.prototype.hasExam = function (permissions) {
        if (permissions.includes('103') || permissions.includes('112') || permissions.includes('203') || permissions.includes('404')) {
            //document.getElementById('liten').classList.remove('hide');
        }
        else { }
    };
    SideBarComponent.prototype.ngAfterViewChecked = function () {
        this.cd.detectChanges();
    };
    /* Function to set the id for setActive function to act upon */
    SideBarComponent.prototype.toggler = function (id) {
        this.activeSession = id;
    };
    SideBarComponent.prototype.checkInstituteType = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isLangInstitute = true;
            }
            else {
                _this.isLangInstitute = false;
            }
        });
    };
    /// Teacher Role Found
    SideBarComponent.prototype.teacherLoginFound = function () {
        this.jsonFlags.isShowLead = false;
        this.jsonFlags.isShowStudent = false;
        this.jsonFlags.isShowModel = true;
    };
    // RemoveActiveTabs() {
    //   let removeArray = ['lizero', 'lione', 'litwo', 'lithree', 'lifour', 'lifive', 'lisix', 'linine'];
    //   removeArray.forEach(object => {
    //     if (document.getElementById(object)) {
    //       document.getElementById(object).classList.remove('active');
    //     }
    //   });
    // }
    SideBarComponent.prototype.showSubSection = function (id) {
        for (var i = 0; i < 6; i++) {
            if (document.getElementsByClassName("side-section")[i]) {
                document.getElementsByClassName("side-section") && document.getElementsByClassName("side-section")[i].classList.remove('active-current-menu');
                document.getElementsByClassName("side-section")[i].classList.remove('active-current-menu');
            }
        }
        if (document.getElementById(id)) {
            document.getElementById(id).className = ' side-section';
            // document.getElementById(id).className = ' active-current-menu';
            document.getElementById(id).classList.add('active-current-menu');
        }
        this.helpMenu = true;
        if (document.getElementById('blurBg')) {
            document.getElementById('blurBg').className = 'blur-background';
        }
    };
    // From Headers section
    SideBarComponent.prototype.showHelpMenu = function () {
        this.helpMenu = (!this.helpMenu);
        this.sideBar = false;
        this.searchBar = false;
    };
    SideBarComponent.prototype.showMenu = function () {
        this.sideBar = true;
        this.helpMenu = false;
        this.searchBar = false;
        var totalExternalClasses = document.getElementsByClassName("external-menu").length;
        var externalMenu = document.getElementsByClassName("external-menu");
        for (var i = 0; i < totalExternalClasses; i++) {
            externalMenu[i].style.display = "none";
        }
    };
    SideBarComponent.prototype.closeMenu = function () {
        this.sideBar = false;
        this.searchBar = false;
        this.helpMenu = false;
        this.videoplayer = false;
        if (document.getElementById('blurBg')) {
            document.getElementById('blurBg').className = 'normal-background';
        }
        for (var i = 0; i < 6; i++) {
            if (document.getElementsByClassName("side-section")[i]) {
                document.getElementsByClassName("side-section")[i].classList.remove('active-current-menu');
                document.getElementsByClassName("side-section")[i].className = ' side-section';
            }
        }
    };
    SideBarComponent.prototype.logout = function () {
        this.clearSearch();
        if (this.log.logoutUser()) {
            this.multiBranchService.subBranchSelected.next(false);
            this.router.navigateByUrl('/authPage');
        }
    };
    SideBarComponent.prototype.clearSearch = function () {
        this.enquiryResult = [];
        this.studentResult = [];
    };
    SideBarComponent.prototype.changePasswordClick = function () {
        this.changePassword.emit('true');
        this.searchBar = false;
        this.sideBar = false;
        var totalExternalClasses = document.getElementsByClassName("external-menu").length;
        var externalMenu = document.getElementsByClassName("external-menu");
        for (var i = 0; i < totalExternalClasses; i++) {
            externalMenu[i].style.display = "none";
        }
        document.getElementById('account').className = ' side-section';
        document.getElementById('blurBg').className = ' normal-background';
    };
    SideBarComponent.prototype.onSubBranchClick = function (data) {
        var _this = this;
        this.multiBranchService.setSelectedBranchData(data);
        this.auth.changeInstituteId(data.institute_id);
        this.multiBranchService.getSubBranchLoginInfo(data.institute_id).subscribe(function (res) {
            _this.multiBranchService.subBranchSelected.next(true);
            _this.fillSessionStorageCommonFields(res);
            sessionStorage.setItem('mainBranchId', _this.mainBranchId);
            sessionStorage.setItem('permissions', '');
            _this.getCountryData(data.institute_id);
            _this.router.navigateByUrl('/authPage');
        }, function (err) {
        });
    };
    SideBarComponent.prototype.getCountryData = function (institute_id) {
        this.login.getInstituteCountryDetails(institute_id).subscribe(function (res) {
            var country_info = JSON.stringify(res);
            sessionStorage.setItem('country_data', country_info);
        }, function (err) {
            console.log(err);
        });
    };
    SideBarComponent.prototype.loginToMainBranch = function () {
        var _this = this;
        var mainBranchId = sessionStorage.getItem('mainBranchId');
        this.multiBranchService.loginToMainBranch(mainBranchId).subscribe(function (res) {
            _this.multiBranchService.subBranchSelected.next(false);
            _this.fillSessionStorageCommonFields(res);
            _this.mainBranchLogin(res);
            _this.getCountryData(mainBranchId);
        }, function (err) {
            console.log(err);
        });
    };
    SideBarComponent.prototype.mainBranchLogin = function (res) {
        sessionStorage.setItem('religion_feature', res.religion_feature);
        sessionStorage.setItem('permissions', '');
        this.router.navigateByUrl('/authPage');
    };
    SideBarComponent.prototype.changeIcon = function (id) {
        document.getElementById(id + "_icon").setAttribute('src', "./assets/images/sidebar/sideMenu/" + id + "_color.svg");
    };
    SideBarComponent.prototype.showSubMenu = function (id) {
        if (document.getElementById(id) && document.getElementById(id).style.display == 'block') {
            document.getElementById(id).style.display = "none";
            // document.getElementById(id+"_current").classList.remove('active-current-menu');
            // document.getElementById(id+"_icon").setAttribute( 'src', "./assets/images/sidebar/sideMenu/"+id+".svg");
            // document.getElementById(id+"icon").src = "./assets/images/sidebar/sideMenu/"+id+".svg";
            return;
        }
        else {
            var totalExternalClasses = document.getElementsByClassName("external-menu").length;
            var externalMenu = document.getElementsByClassName("external-menu");
            for (var i = 0; i < totalExternalClasses; i++) {
                externalMenu[i].style.display = "none";
            }
            // let totalCurrentClasses = document.getElementsByClassName("current-menu").length;
            // let currentMenu = document.getElementsByClassName("current-menu") as HTMLCollectionOf<HTMLElement>;
            // for(let i = 0; i < totalCurrentClasses; i++){
            //   currentMenu[i].classList.remove('active-current-menu');
            // }
            // document.getElementById(id+"_icon").setAttribute( 'src', "./assets/images/sidebar/sideMenu/"+id+"_color.svg");
            // document.getElementById(id+"icon").src = "./assets/images/sidebar/sideMenu/"+id+"_color.svg";
            // document.getElementById(id+"_current").classList.add('active-current-menu')
            if (document.getElementById(id)) {
                document.getElementById(id).style.display = "block";
            }
        }
    };
    ;
    SideBarComponent.prototype.hasInventoryAccess = function () {
        if (sessionStorage.getItem('permissions') == '' && sessionStorage.getItem('userType') != '3') {
            return true;
        }
        else if ((sessionStorage.getItem('permissions')).includes('301')) {
            if (sessionStorage.getItem('userType') != '3') {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return false;
        }
    };
    SideBarComponent.prototype.routerLink = function (route, id) {
        for (var i = 0; i < 6; i++) {
            if (document.getElementsByClassName("side-section")[i]) {
                document.getElementsByClassName("side-section")[i].classList.remove('active-current-menu');
            }
        }
        this.sideBar = false;
        var totalCurrentClasses = document.getElementsByClassName("current-menu").length;
        var currentMenu = document.getElementsByClassName("current-menu");
        for (var i = 0; i < totalCurrentClasses; i++) {
            currentMenu[i] && currentMenu[i].classList.remove('active-current-menu');
        }
        if (document.getElementById(id)) {
            document.getElementById(id).className += ' remove-current-menu';
        }
        if (document.getElementById('blurBg')) {
            document.getElementById('blurBg').className = 'normal-background';
        }
        this.activeSession = null;
        this.router.navigate([route]);
    };
    SideBarComponent.prototype.viewTeacherProfile = function () {
        this.router.navigate(['/view/teacher/edit/', this.teacherId]);
    };
    SideBarComponent.prototype.fillSessionStorageCommonFields = function (res) {
        sessionStorage.clear();
        var Authorization = btoa(res.userid + "|" + res.userType + ":" + res.password + ":" + res.institution_id);
        sessionStorage.setItem('Authorization', Authorization);
        this.auth.changeAuthenticationKey(Authorization);
        sessionStorage.setItem('institute_id', res.institution_id);
        this.auth.changeInstituteId(res.institution_id);
        sessionStorage.setItem('accountId', res.accountId);
        sessionStorage.setItem('alternate_email_id', res.alternate_email_id);
        sessionStorage.setItem('biometric_attendance_feature', res.biometric_attendance_feature);
        sessionStorage.setItem('courseType', res.courseType);
        sessionStorage.setItem('course_structure_flag', res.course_structure_flag);
        this.auth.course_flag.next(res.course_structure_flag);
        sessionStorage.setItem('enable_fee_payment_mandatory_student_creation', res.enable_fee_payment_mandatory_student_creation);
        sessionStorage.setItem('enable_fee_templates', res.enable_fee_templates);
        sessionStorage.setItem('enable_tax_applicable_fee_installments', res.enable_tax_applicable_fee_installments);
        sessionStorage.setItem('is_exam_grad_feature', res.is_exam_grad_feature);
        sessionStorage.setItem('inst_email', res.inst_email);
        sessionStorage.setItem('inst_phone', res.inst_phone);
        sessionStorage.setItem('institute_type', res.institute_type);
        this.auth.instituteType_name.next(res.institute_type);
        // this.auth.institute_type.next(res.institute_type);
        this.auth.makeInstituteType(res.institute_type, res.course_structure_flag);
        sessionStorage.setItem('institute_name', res.institute_name);
        sessionStorage.setItem('is_campaign_message_approve_feature', res.is_campaign_message_approve_feature);
        sessionStorage.setItem('is_main_branch', res.is_main_branch);
        this.auth.isMainBranch.next(res.is_main_branch);
        sessionStorage.setItem('is_student_bulk_upload_byClient', res.is_student_bulk_upload_byClient);
        sessionStorage.setItem('is_student_mgmt_flag', res.is_student_mgmt_flag);
        sessionStorage.setItem('login_teacher_id', res.login_teacher_id);
        sessionStorage.setItem('name', res.name);
        sessionStorage.setItem('password', res.password);
        sessionStorage.setItem('student_report_card_fee_module', res.student_report_card_fee_module);
        sessionStorage.setItem('studwise_fee_mod_with_amt', res.studwise_fee_mod_with_amt);
        sessionStorage.setItem('test_feature', res.test_feature);
        sessionStorage.setItem('testprepEnabled', res.testprepEnabled);
        sessionStorage.setItem('userType', res.userType);
        this.log.changeUserType(res.userType);
        sessionStorage.setItem('username', res.username);
        sessionStorage.setItem('userid', res.userid);
        sessionStorage.setItem('message', res.message);
        sessionStorage.setItem('about_us_text', res.about_us_text);
        sessionStorage.setItem('inst_announcement', res.inst_announcement);
        sessionStorage.setItem('logo_url', res.logo_url);
        sessionStorage.setItem('permitted_roles', JSON.stringify(res.featureDivMapping));
        sessionStorage.setItem('enable_routing', res.enable_routing);
        sessionStorage.setItem('enable_online_payment_feature', res.enable_online_payment_feature);
        sessionStorage.setItem('institute_setup_type', res.institute_setup_type);
        sessionStorage.setItem('allow_sms_approve_feature', res.allow_sms_approve_feature);
        sessionStorage.setItem('enable_eLearn_feature', res.enable_eLearn_feature); //
        sessionStorage.setItem('open_enq_Visibility_feature', res.open_enq_Visibility_feature);
    };
    // closeSubMenu(){
    //   let totalExternalClasses = document.getElementsByClassName("external-menu").length;
    //   for(let i = 0; i < totalExternalClasses; i++){
    //     document.getElementsByClassName("external-menu")[i].style.display = "none";
    //   }
    // }
    // FOR Search
    SideBarComponent.prototype.showSearchBar = function () {
        this.searchBar = true;
        window.setTimeout(function () {
            document.getElementById("search_bar").focus();
        }, 550);
    };
    SideBarComponent.prototype.closeSearchBar = function () {
        this.searchBar = false;
    };
    SideBarComponent.prototype.triggerSearchBox = function ($event) {
        this.showSearchBar();
        $event.preventDefault();
        this.isResultDisplayed = true;
        this.seachResult.nativeElement.classList.add('searchView');
        this.hideSearchPopup.emit(null);
    };
    SideBarComponent.prototype.closeSearch = function (e) {
        this.isResultDisplayed = e;
        this.seachResult.nativeElement.classList.remove('searchView');
        //this.userInput = '';
        // if(e){
        //   this.searchBar = false;
        // }
        // else{
        //   this.searchBar = true;
        // }
        // this.searchBar = false;
    };
    SideBarComponent.prototype.filterGlobal = function (value) {
        var _this = this;
        if (value != null && value != undefined) {
            if (value.trim() != '' && value.length >= 4) {
                var obj = this.getSearchObject(value);
                this.inputValue = value;
                this.searchViewMore.emit(null);
                /* Loading Shows */
                this.resultStat = 0;
                this.fetchService.globalSearch(obj).subscribe(function (res) {
                    _this.resultStat = 1;
                    if (res.length != 0) {
                        _this.enquiryResult = res.filter(function (e) { return e.source == "Enquiry"; });
                        _this.studentResult = res.filter(function (s) { return s.source == "Student"; });
                    }
                    else {
                        _this.commonService.showErrorMessage("info", "No Records Found", "Please try with a different keyword");
                    }
                }, function (err) {
                });
            }
            else {
            }
        }
    };
    SideBarComponent.prototype.getSearchObject = function (e) {
        var obj = this.globalSearchForm;
        /* Name detected */
        if (isNaN(e)) {
            this.globalSearchForm.name = e;
            this.globalSearchForm.phone = '';
            return this.globalSearchForm;
        }
        else {
            this.globalSearchForm.phone = e;
            this.globalSearchForm.name = '';
            return this.globalSearchForm;
        }
    };
    SideBarComponent.prototype.selectedStudent = function (s) {
        this.closeSearch(false);
        this.router.navigate(['/view/students'], { queryParams: { id: s.id } });
        this.searchBar = false;
    };
    SideBarComponent.prototype.selectedEnquiry = function (e) {
        this.closeSearch(false);
        this.router.navigate(['/view/leads'], { queryParams: { id: e.id } });
        this.searchBar = false;
    };
    SideBarComponent.prototype.searchAgain = function (e) {
        this.userInput = e;
    };
    SideBarComponent.prototype.viewMoreRecods = function (e) {
        var obj = {
            source: e,
            input: this.userInput
        };
        this.closeSearch(false);
        this.searchViewMore.emit(obj);
        this.searchBar = false;
    };
    SideBarComponent.prototype.actionSelected = function (d) {
        this.closeSearch(false);
        if (d.data.source == "Student") {
            this.router.navigate(['/view/students'], { queryParams: { id: d.data.id, action: d.action } });
            this.searchBar = false;
        }
        else if (d.data.source == "Enquiry") {
            if (d.action == "enquiryUpdate") {
                this.enquiryUpdateAction.emit(d);
                this.searchBar = false;
            }
            else
                this.router.navigate(['/view/leads/enquiry/edit/' + d.data.id]);
            {
                // this.router.navigate(['/view/leads'], { queryParams: { id: d.data.id, action: d.action } });
                this.searchBar = false;
            }
        }
    };
    SideBarComponent.prototype.openInNewTab = function (url) {
        window.open(url, "_blank");
        this.closeMenu();
        this.helpMenu = false;
    };
    SideBarComponent.prototype.showVideo = function (url) {
        this.videoplayer = true;
        this.currentProjectUrl = this.sanitizer.bypassSecurityTrustResourceUrl(url);
        // this.currentProjectUrl = url;
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divAdminTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divAdminTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divMyAccountTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divMyAccountTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divMasterTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divMasterTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divProfileTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divProfileTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divTeacherTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divTeacherTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divSlotTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divSlotTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divClassRoomTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divClassRoomTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divManageTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divManageTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divAcademicTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divAcademicTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divGradesTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divGradesTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divManageUsers'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divManageUsers", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divSettingTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divSettingTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divGeneralSettingTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divGeneralSettingTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divManageFormTag'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divManageFormTag", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('divAreaAndMap'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "divAreaAndMap", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('searchInput'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "searchInput", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('seachResult'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], SideBarComponent.prototype, "seachResult", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('form'),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "form", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "searchViewMore", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "enquiryUpdateAction", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "hideSearchPopup", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], SideBarComponent.prototype, "changePassword", void 0);
    SideBarComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-side-bar',
            template: __webpack_require__("./src/app/components/core/side-bar/side-bar.component.html"),
            styles: [__webpack_require__("./src/app/components/core/side-bar/side-bar.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__["a" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_7__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__["a" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_2__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_5__services_fetchprefilldata_service__["a" /* FetchprefilldataService */],
            __WEBPACK_IMPORTED_MODULE_6__services_multiBranchdata_service__["a" /* MultiBranchDataService */],
            __WEBPACK_IMPORTED_MODULE_8__services_common_service__["a" /* CommonServiceFactory */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"],
            __WEBPACK_IMPORTED_MODULE_9__angular_platform_browser__["DomSanitizer"]])
    ], SideBarComponent);
    return SideBarComponent;
}());



/***/ }),

/***/ "./src/app/components/global-search-popup/global-search-popup.component.html":
/***/ (function(module, exports) {

module.exports = "<proctur-popup [sizeWidth]=\"'medium'\">\r\n\r\n  <span class=\"closePopup pos-abs fbold show\" (click)=\"closeSearchArea()\" close-button>\r\n    <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n      <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" style=\"fill: currentColor\"></path>\r\n    </svg>\r\n  </span>\r\n\r\n  <h2 popup-header>Found {{searchResult.length}} Records</h2>\r\n\r\n  <div class=\"hideHorizontalScroll\" popup-content>\r\n\r\n    <section class=\"\">\r\n      <section>\r\n        <!-- Result-->\r\n        <ul class=\"sdb search-item\" *ngIf=\"searchResult.length != 0\">\r\n          <li *ngIf=\"studentResult.length != 0\">\r\n            <h5>\r\n              <span>\r\n                In Students\r\n              </span>\r\n            </h5>\r\n            <ul class=\"in-student-list\">\r\n              <li *ngFor=\"let student of studentResult\">\r\n                <ul class=\"holder\">\r\n                  <li>\r\n                    <a (click)=\"studentSelected(student)\">\r\n                      <img src=\"\" alt=\"\" />\r\n                      <span class=\"sdb-right\">\r\n                        <label>\r\n                          <strong>{{student.name}}</strong>\r\n                        </label>\r\n                        <span>\r\n                          +91 {{student.phone}} | Enrolment ID : {{student.displayId}}\r\n                        </span>\r\n                      </span>\r\n                    </a>\r\n                  </li>\r\n                  <li>\r\n                    <a *ngIf=\"hasStudent\" class=\"markers\" (click)=\"performAction('studentEdit', student)\">\r\n                      Edit Student\r\n                    </a>\r\n                    <a *ngIf=\"hasStudent\" class=\"markers\" (click)=\"performAction('studentFee', student)\">\r\n                      Manage Fee\r\n                    </a>\r\n                    <a *ngIf=\"hasStudent\" class=\"markers\" (click)=\"performAction('studentInventory', student)\">\r\n                      Manage Inventory\r\n                    </a>\r\n                    <a *ngIf=\"hasStudent\" class=\"markers hide\" (click)=\"performAction('studentLeave', student)\">\r\n                      Mark Leave\r\n                    </a>\r\n                    <a *ngIf=\"hasStudent\" class=\"markers hide\" (click)=\"performAction('studentDelete', student)\">\r\n                      Delete\r\n                    </a>\r\n                  </li>\r\n                </ul>\r\n              </li>\r\n            </ul>\r\n          </li>\r\n          <li *ngIf=\"enquiryResult.length != 0\">\r\n            <h5>\r\n              <span>\r\n                In Enquiry\r\n              </span>\r\n            </h5>\r\n            <ul class=\"in-student-list\">\r\n              <li *ngFor=\"let enquiry of enquiryResult\">\r\n                <ul class=\"holder\">\r\n                  <li>\r\n                    <a (click)=\"enquirySelected(enquiry)\">\r\n                      <img src=\"\" alt=\"\" />\r\n                      <span class=\"sdb-right\">\r\n                        <label>\r\n                          <strong>{{enquiry.name}}</strong>\r\n                        </label>\r\n                        <span>\r\n                          +91 {{enquiry.phone}} | Enrolment ID : {{enquiry.displayId}}\r\n                        </span>\r\n                      </span>\r\n                    </a>\r\n                  </li>\r\n                  <li>\r\n                    <a *ngIf=\"hasEnquiry\" class=\"markers\" (click)=\"performAction('enquiryEdit',enquiry)\">\r\n                      Edit Enquiry\r\n                    </a>\r\n                    <a *ngIf=\"hasEnquiry\" class=\"markers hide\" (click)=\"performAction('enquiryDelete')\">\r\n                      Delete Enquiry\r\n                    </a>\r\n                    <a *ngIf=\"hasEnquiry\" class=\"markers\" (click)=\"performAction('enquiryUpdate',enquiry)\">\r\n                      Update Enquiry\r\n                    </a>\r\n                  </li>\r\n                </ul>\r\n              </li>\r\n            </ul>\r\n          </li>\r\n        </ul>\r\n\r\n      </section>\r\n    </section>\r\n\r\n  </div>\r\n\r\n</proctur-popup>\r\n"

/***/ }),

/***/ "./src/app/components/global-search-popup/global-search-popup.component.scss":
/***/ (function(module, exports) {

module.exports = ".hideHorizontalScroll {\n  overflow-x: hidden;\n  overflow-y: auto; }\n"

/***/ }),

/***/ "./src/app/components/global-search-popup/global-search-popup.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return GlobalSearchPopupComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_fetchprefilldata_service__ = __webpack_require__("./src/app/services/fetchprefilldata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var GlobalSearchPopupComponent = /** @class */ (function () {
    function GlobalSearchPopupComponent(appC, fetchService, router, commonService) {
        this.appC = appC;
        this.fetchService = fetchService;
        this.router = router;
        this.commonService = commonService;
        this.globalSearchForm = {
            name: '',
            phone: '',
            instituteId: sessionStorage.getItem('institute_id'),
            start_index: '-1', batch_size: '-1'
        };
        this.searchResult = [];
        this.enquiryResult = [];
        this.studentResult = [];
        this.hasEnquiry = false;
        this.hasStudent = false;
        this.eventData = "";
        this.closeViewMorePopUp = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"](null);
        this.enquiryUpdateAction = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"](null);
        this.checkAccessControl();
    }
    GlobalSearchPopupComponent.prototype.ngOnInit = function () {
    };
    GlobalSearchPopupComponent.prototype.checkAccessControl = function () {
        if (this.commonService.checkUserHadPermission('115') || this.commonService.checkUserHadPermission('110')) {
            this.hasEnquiry = true;
        }
        if (this.commonService.checkUserHadPermission('301') || this.commonService.checkUserHadPermission('303')) {
            this.hasStudent = true;
        }
    };
    GlobalSearchPopupComponent.prototype.ngOnChanges = function () {
        this.eventData;
        if (this.eventData != null && this.eventData != "") {
            this.fetchGlobalSearchDetails(this.eventData.input);
        }
    };
    GlobalSearchPopupComponent.prototype.fetchGlobalSearchDetails = function (value) {
        var _this = this;
        if (value != null && value != undefined) {
            if (value.trim() != '' && value.length >= 4) {
                var obj = this.getSearchObject(value);
                /* Loading Shows */
                this.fetchService.globalSearch(obj).subscribe(function (res) {
                    if (res.length != 0) {
                        _this.searchResult = res;
                        _this.enquiryResult = res.filter(function (e) { return e.source == "Enquiry"; });
                        _this.studentResult = res.filter(function (s) { return s.source == "Student"; });
                    }
                    else {
                        _this.messageNotifier("info", "No Records Found", "Please try with a different keyword");
                    }
                }, function (err) {
                    _this.messageNotifier('error', '', err.error.message);
                });
            }
            else {
            }
        }
    };
    GlobalSearchPopupComponent.prototype.studentSelected = function (s) {
        this.closeSearchArea();
        this.router.navigate(['/view/students'], { queryParams: { id: s.id } });
    };
    GlobalSearchPopupComponent.prototype.performAction = function (a, data) {
        var d = data.id;
        switch (a) {
            case 'studentEdit': {
                this.closeSearchArea();
                this.router.navigate(['/view/students'], { queryParams: { id: d, action: a } });
                break;
            }
            case 'studentFee': {
                this.closeSearchArea();
                this.router.navigate(['/view/students'], { queryParams: { id: d, action: a } });
                break;
            }
            case 'studentInventory': {
                this.closeSearchArea();
                this.router.navigate(['/view/students'], { queryParams: { id: d, action: a } });
                break;
            }
            case 'studentLeave': {
                this.closeSearchArea();
                this.router.navigate(['/view/students'], { queryParams: { id: d, action: a } });
                break;
            }
            case 'studentDelete': {
                this.closeSearchArea();
                this.router.navigate(['/view/students'], { queryParams: { id: d, action: a } });
                break;
            }
            case 'enquiryEdit': {
                this.closeSearchArea();
                // this.router.navigate(['/view/leads/enquiry/edit'], { queryParams: { id: d, action: a } });
                this.router.navigate(['/view/leads/enquiry/edit/' + d]);
                break;
            }
            case 'enquiryUpdate': {
                this.closeSearchArea();
                var obj = {
                    action: a,
                    data: data
                };
                this.enquiryUpdateAction.emit(obj);
                break;
            }
        }
    };
    GlobalSearchPopupComponent.prototype.enquirySelected = function (e) {
        this.closeSearchArea();
        this.router.navigate(['/view/leads/enquiry/edit/' + e.id]);
        // this.router.navigate(['/view/enquiry'], { queryParams: { id: e.id } });
    };
    GlobalSearchPopupComponent.prototype.closeSearchArea = function () {
        this.closeViewMorePopUp.emit(true);
    };
    GlobalSearchPopupComponent.prototype.getSearchObject = function (e) {
        var obj = this.globalSearchForm;
        /* Name detected */
        if (isNaN(e)) {
            this.globalSearchForm.name = e;
            this.globalSearchForm.phone = '';
            return this.globalSearchForm;
        }
        else {
            this.globalSearchForm.phone = e;
            this.globalSearchForm.name = '';
            return this.globalSearchForm;
        }
    };
    GlobalSearchPopupComponent.prototype.messageNotifier = function (type, title, message) {
        var obj = {
            type: type,
            title: title,
            body: message
        };
        this.appC.popToast(obj);
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], GlobalSearchPopupComponent.prototype, "eventData", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], GlobalSearchPopupComponent.prototype, "closeViewMorePopUp", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], GlobalSearchPopupComponent.prototype, "enquiryUpdateAction", void 0);
    GlobalSearchPopupComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-global-search-popup',
            template: __webpack_require__("./src/app/components/global-search-popup/global-search-popup.component.html"),
            styles: [__webpack_require__("./src/app/components/global-search-popup/global-search-popup.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_2__services_fetchprefilldata_service__["a" /* FetchprefilldataService */],
            __WEBPACK_IMPORTED_MODULE_3__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_4__services_common_service__["a" /* CommonServiceFactory */]])
    ], GlobalSearchPopupComponent);
    return GlobalSearchPopupComponent;
}());



/***/ }),

/***/ "./src/app/components/overlay-menu/overlay-menu.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"middle-section clearFix\" id=\"enquiryList\">\r\n  <div id=\"myNav\" class=\"overlay visible-xs\" (click)=\"screenClicked()\">\r\n    <!-- Overlay content -->\r\n    <div class=\"overlay-content\">\r\n      <a #liEnquiry routerLink=\"/view/enquiry\">Enquiry</a>\r\n      <a #liStudent routerLink=\"/view/students\">Student</a>\r\n      <a #liCourse routerLink=\"/view/course\">Courses</a>\r\n      <a #liActivity routerLink=\"/view/live-classes\">Activity</a>\r\n      <a #liEmployee routerLink=\"/view/employee\">Employee</a>\r\n      <a #liReports routerLink=\"/view/reports\">Reports</a>\r\n      <a #liInventory routerLink=\"/view/inventory\">Inventory</a>\r\n      <a #liCampaign routerLink=\"/view/campaign\">Campaign</a>\r\n      <a #liHelp routerLink=\"/view/help\">Help Center</a>\r\n      <a class=\"hide\" #liExpense routerLink=\"expense\">Expense</a>\r\n      <a class=\"hide\" #liExams routerLink=\"exams\">Online Exam</a>\r\n    </div>\r\n\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./src/app/components/overlay-menu/overlay-menu.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.overlay {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: 100%;\n  height: 100%;\n  z-index: 100;\n  background-color: black;\n  /* Black fallback color */\n  background-color: rgba(0, 0, 0, 0.9);\n  /* Black w/opacity */\n  overflow-x: hidden;\n  /* Disable horizontal scroll */\n  -webkit-transition: 0.5s;\n  transition: 0.5s;\n  /* 0.5 second transition effect to slide in or slide down the overlay (height or width, depending on reveal) */ }\n/* Position the content inside the overlay */\n.overlay-content {\n  position: absolute;\n  padding-top: 61px;\n  width: 100%;\n  /* 100% width */\n  text-align: center;\n  /* Centered text/links */\n  margin-top: 30px;\n  /* 30px top margin to avoid conflict with the close button on smaller screens */ }\n/* The navigation links inside the overlay */\n.overlay a {\n  padding: 1% 0% 1% 40%;\n  text-decoration: none;\n  font-size: 25px;\n  color: #818181;\n  display: block;\n  -webkit-transition: 0.3s;\n  transition: 0.3s;\n  text-align: left;\n  font-weight: bolder; }\n/* When you mouse over the navigation links, change their color */\n.overlay a:hover, .overlay a:focus {\n  color: #f1f1f1; }\n/* Position the close button (top right corner) */\n.overlay .closebtn {\n  position: absolute;\n  top: 20px;\n  right: 45px;\n  font-size: 60px; }\n/* When the height of the screen is less than 450 pixels, change the font-size of the links and position the close button again, so they don't overlap */\n@media screen and (max-height: 450px) {\n  .overlay a {\n    font-size: 20px; }\n  .overlay .closebtn {\n    font-size: 40px;\n    top: 15px;\n    right: 35px; } }\n"

/***/ }),

/***/ "./src/app/components/overlay-menu/overlay-menu.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return OverlayMenuComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__ = __webpack_require__("./src/app/services/login-services/login.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var OverlayMenuComponent = /** @class */ (function () {
    function OverlayMenuComponent(log) {
        this.log = log;
        this.userType = 0;
    }
    OverlayMenuComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.log.currentUserType.subscribe(function (e) {
            if (e == '' || e == null || e == undefined) {
            }
            else {
                _this.userType = e;
            }
        });
        this.checkUserAccess();
    };
    OverlayMenuComponent.prototype.screenClicked = function () {
        this.log.changeMenuStatus(false);
        document.getElementById('menu-close').classList.add('hide');
        document.getElementById('menu-open').classList.remove('hide');
    };
    OverlayMenuComponent.prototype.checkUserAccess = function () {
        if (this.userType == 0) {
            var permission = sessionStorage.getItem('permissions');
            if (permission == "" || permission == null) {
                this.showAllFields();
            }
            else {
                this.hasEnquiry(permission);
                this.hasStudent(permission);
                this.hasCourse(permission);
                this.hasActivity(permission);
                this.hasEmployee(permission);
                this.hasInventory(permission);
                this.hasReport(permission);
                this.hasCampaign(permission);
            }
        }
        else if (this.userType == 3) {
            this.teacherLoginFound();
        }
    };
    OverlayMenuComponent.prototype.hasEnquiry = function (permissions) {
        if (permissions.includes('110') || permissions.includes('115')) {
            this.liEnquiry.nativeElement.classList.remove('hide');
        }
        else {
            this.liEnquiry.nativeElement.classList.add('hide');
        }
    };
    OverlayMenuComponent.prototype.hasStudent = function (permissions) {
        if (permissions.includes('301') || permissions.includes('302') || permissions.includes('303')) {
            this.liStudent.nativeElement.classList.remove('hide');
        }
        else {
            this.liStudent.nativeElement.classList.add('hide');
        }
    };
    OverlayMenuComponent.prototype.hasCourse = function (permissions) {
        if (permissions.includes('401') || permissions.includes('402') || permissions.includes('403') || permissions.includes('404') || permissions.includes('405') || permissions.includes('406') || permissions.includes('501') || permissions.includes('502') || permissions.includes('505') || permissions.includes('701') || permissions.includes('704') || permissions.includes('702') || permissions.includes('404')) {
            this.liCourse.nativeElement.classList.remove('hide');
        }
        else {
            this.liCourse.nativeElement.classList.add('hide');
        }
    };
    OverlayMenuComponent.prototype.hasActivity = function (permissions) {
        if (permissions.includes('102') || permissions.includes('114') || permissions.includes('113')) {
            this.liActivity.nativeElement.classList.remove('hide');
        }
        else {
            this.liActivity.nativeElement.classList.add('hide');
        }
    };
    OverlayMenuComponent.prototype.hasEmployee = function (permissions) {
        if (permissions.includes('118') || permissions.includes('119') || permissions.includes('120') || permissions.includes('121')) {
            this.liEmployee.nativeElement.classList.remove('hide');
        }
        else {
            this.liEmployee.nativeElement.classList.add('hide');
        }
    };
    OverlayMenuComponent.prototype.hasReport = function (permissions) {
        if (permissions.includes('201') || permissions.includes('202') || permissions.includes('203') || permissions.includes('204') || permissions.includes('205') || permissions.includes('206') || permissions.includes('207') || permissions.includes('208')) {
            this.liReports.nativeElement.classList.remove('hide');
        }
        else {
            this.liReports.nativeElement.classList.add('hide');
        }
    };
    OverlayMenuComponent.prototype.hasInventory = function (permissions) {
        if (permissions.includes('301')) {
            this.liInventory.nativeElement.classList.remove('hide');
        }
        else {
            this.liInventory.nativeElement.classList.add('hide');
        }
    };
    OverlayMenuComponent.prototype.hasExpense = function (permissions) {
        if (permissions.includes('108') || permissions.includes('109')) {
            this.liExpense.nativeElement.classList.remove('hide');
        }
        else {
            this.liExpense.nativeElement.classList.add('hide');
        }
    };
    OverlayMenuComponent.prototype.hasCampaign = function (permissions) {
        if (permissions.includes('115')) {
            this.liCampaign.nativeElement.classList.remove('hide');
        }
        else {
            this.liCampaign.nativeElement.classList.add('hide');
        }
    };
    OverlayMenuComponent.prototype.hasExam = function (permissions) {
        if (permissions.includes('103') || permissions.includes('112') || permissions.includes('203') || permissions.includes('404')) {
            //document.getElementById('liten').classList.remove('hide');
        }
        else { }
    };
    OverlayMenuComponent.prototype.showAllFields = function () {
        this.liEnquiry.nativeElement.classList.remove('hide');
        this.liStudent.nativeElement.classList.remove('hide');
        this.liCourse.nativeElement.classList.remove('hide');
        this.liActivity.nativeElement.classList.remove('hide');
        this.liEmployee.nativeElement.classList.remove('hide');
        this.liReports.nativeElement.classList.remove('hide');
        this.liInventory.nativeElement.classList.remove('hide');
        this.liExpense.nativeElement.classList.remove('hide');
        this.liCampaign.nativeElement.classList.remove('hide');
        this.liExams.nativeElement.classList.remove('hide');
        this.liHelp.nativeElement.classList.remove('hide');
    };
    OverlayMenuComponent.prototype.hideAllFields = function () {
        this.liEnquiry.nativeElement.classList.add('hide');
        this.liStudent.nativeElement.classList.add('hide');
        this.liCourse.nativeElement.classList.add('hide');
        this.liActivity.nativeElement.classList.add('hide');
        this.liEmployee.nativeElement.classList.add('hide');
        this.liReports.nativeElement.classList.add('hide');
        this.liInventory.nativeElement.classList.add('hide');
        this.liExpense.nativeElement.classList.add('hide');
        this.liCampaign.nativeElement.classList.add('hide');
        this.liExams.nativeElement.classList.add('hide');
        this.liHelp.nativeElement.classList.add('hide');
    };
    OverlayMenuComponent.prototype.teacherLoginFound = function () {
        this.hideAllFields();
        this.liCourse.nativeElement.classList.remove('hide');
        this.liActivity.nativeElement.classList.remove('hide');
        this.liReports.nativeElement.classList.remove('hide');
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('liEnquiry'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], OverlayMenuComponent.prototype, "liEnquiry", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('liStudent'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], OverlayMenuComponent.prototype, "liStudent", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('liCourse'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], OverlayMenuComponent.prototype, "liCourse", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('liActivity'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], OverlayMenuComponent.prototype, "liActivity", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('liEmployee'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], OverlayMenuComponent.prototype, "liEmployee", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('liReports'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], OverlayMenuComponent.prototype, "liReports", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('liInventory'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], OverlayMenuComponent.prototype, "liInventory", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('liExpense'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], OverlayMenuComponent.prototype, "liExpense", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('liCampaign'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], OverlayMenuComponent.prototype, "liCampaign", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('liExams'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], OverlayMenuComponent.prototype, "liExams", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('liHelp'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], OverlayMenuComponent.prototype, "liHelp", void 0);
    OverlayMenuComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'overlay-menu',
            template: __webpack_require__("./src/app/components/overlay-menu/overlay-menu.component.html"),
            styles: [__webpack_require__("./src/app/components/overlay-menu/overlay-menu.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__["a" /* LoginService */]])
    ], OverlayMenuComponent);
    return OverlayMenuComponent;
}());



/***/ }),

/***/ "./src/app/components/training-video/training-video.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"middle-section clearFix\">\r\n  <div class=\"act-top clearfix\">\r\n    <h1 class=\"pull-left\">Training Videos</h1>\r\n  </div>\r\n\r\n  <div class=\"videos-outer-container\">\r\n    <div class=\"section-title-container\">\r\n      <span>Section 1</span>\r\n    </div>\r\n    <div class=\"videos-container\">\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/1.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/A9tBKQKoOkQ')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Overview and login</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>Overview of Proctur ERP and How to login using your credentials</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(0)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/2.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/FxG285gux2Q')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Account Type - Batch Model</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>Setup your user account in Proctur's batch model</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(1)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/3.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/q5z2ZA7hsjE')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Account Type - Course Model</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>Setup your user account in Proctur's course module</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(2)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"section-title-container\">\r\n      <span>Section 2</span>\r\n    </div>\r\n    <div class=\"videos-container\">\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/4.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/NzqeXfSZCLs')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>System Settings</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>Settings of various activities on the portal</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(3)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/5.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/2GgFqBeiZiU')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Student Data Add / Upload</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to upload enquiries in bulk</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(4)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/6.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/WhOj8G0Ha88')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Users & Access Management</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to assign differerent role to users</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(5)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/7.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/faIJ3ipNuLM')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Course Planning & Scheduling</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to plan and manage and schedule classes/exams</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(6)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"section-title-container\">\r\n      <span>Section 3</span>\r\n    </div>\r\n    <div class=\"videos-container\">\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/8.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/8zpXs3HZ-zI')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>SMS / Email Notifications</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to send notifications to Students of different courses/batches</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(7)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/9.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/PmqbVgVN148')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Managing Enquiries</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to easily manage your enquiries on proctur</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(8)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/10.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/nNvumeMwNRc')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Enquiry to Admission Process</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to convert an enquiry directly to into an admission</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(9)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/11.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/oGgxyy0Cp-4')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Student Admissions</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to add student details in the Proctur Account</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(10)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/12.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/79ur6e7GMfM')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Manage Student Fee - #1</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to update fees of a student</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(11)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/13.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/tZsrqM8Ru_w')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Manage Student Fee - #2</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to reconfigure fees i.e make changes in installments/fees of Students</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(12)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/14.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/dRS0YaVE9p0')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Manage Student Fee - #3 (Cheque Management)</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to get the details of the fees paid by cheques</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(13)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/15.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/5ckzLCC_s10')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Inventory Management</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to manage inventory like bags,study material,stationary etc.</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(14)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/16.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/CAIyjXWNaDM')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Sharing Notes / Assignments with Students</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to share files with students</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(15)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/17.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/EpBXelRBePg')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Parents Teacher Meeting (PTM)</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to create,organise and manage Parent teacher meetings</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(16)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/18.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/VYfV3Br5heY')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Timetable Generation</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to view and download a time table</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(17)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"section-title-container\">\r\n      <span>Section 4</span>\r\n    </div>\r\n    <div class=\"videos-container\">\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/19.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/U3WYFG0ZgHI')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Reports</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to view and use different reports provided for fees,sms,attendance,biometric attendance,exams,enquiries and others</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(18)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"section-title-container\">\r\n      <span>Section 5</span>\r\n    </div>\r\n    <div class=\"videos-container\">\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/20.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/L0lI_UeCEZA')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Promotional Activities (SMS)</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to send promotional sms campaign</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(19)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"video-item\">\r\n        <div class=\"thumbnail-container\">\r\n          <img src=\"./assets/images/training_video/21.jpg\" alt=\"\" (click)=\"showVideo('https://www.youtube.com/embed/UfEbiFazDeU')\">\r\n        </div>\r\n        <div class=\"video-info-container\">\r\n          <div class=\"video-title-container\">\r\n            <span>Data Archiving - Clearing old data</span>\r\n          </div>\r\n          <div class=\"video-description-container\">\r\n            <span>How to archive courses and student data</span>\r\n          </div>\r\n          <div class=\"view-more\">\r\n            <span data-toggle=\"modal\" data-target=\"#exampleModal\" (click)=\"viewMore(20)\">View more</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n\r\n  <div class=\"modal fade\" id=\"exampleModal\" role=\"dialog\">\r\n    <div class=\"modal-dialog\" role=\"document\">\r\n      <div class=\"modal-content\">\r\n        <div class=\"modal-header\">\r\n          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\r\n        </div>\r\n        <div class=\"modal-body\">\r\n          <span>{{viewMoreText}}</span>\r\n        </div>\r\n        <div class=\"modal-footer\">\r\n          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"videoplayer\" *ngIf=\"videoplayer\">\r\n    <iframe width=\"650\" height=\"400\"\r\n      [src]=\"currentProjectUrl\"\r\n      frameborder=\"0\" style=\"border-radius: 10px;\"\r\n      allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen>\r\n    </iframe>\r\n  </div>\r\n\r\n</section>\r\n\r\n<div class=\"black-bg\" id=\"black-bg\" *ngIf=\"videoplayer\" (click)=\"closePlayer()\">\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/components/training-video/training-video.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  padding: 1%; }\n\n.videos-outer-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%;\n  margin: 10px 0px; }\n\n.videos-outer-container .section-title-container {\n    padding: 10px;\n    background: #0747a6;\n    color: white;\n    text-align: center;\n    font-size: 14px;\n    font-weight: 600;\n    width: 130px;\n    border-radius: 10px; }\n\n.videos-outer-container .videos-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    -ms-flex-wrap: wrap;\n        flex-wrap: wrap;\n    -webkit-box-pack: start;\n        -ms-flex-pack: start;\n            justify-content: flex-start;\n    width: 100%;\n    padding: 10px; }\n\n.videos-outer-container .videos-container .video-item {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 46%;\n      margin: 0px 2%;\n      margin-bottom: 30px;\n      border-radius: 6px;\n      -webkit-box-shadow: 0px 3px 15px rgba(0, 0, 0, 0.15);\n              box-shadow: 0px 3px 15px rgba(0, 0, 0, 0.15); }\n\n.videos-outer-container .videos-container .video-item .thumbnail-container {\n        width: 30%;\n        cursor: pointer; }\n\n.videos-outer-container .videos-container .video-item .thumbnail-container img {\n          max-width: 100%;\n          height: 120px;\n          /* border-radius: 4px; */\n          border-top-left-radius: 6px;\n          border-bottom-left-radius: 6px; }\n\n.videos-outer-container .videos-container .video-item .video-info-container {\n        width: 68%;\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        text-align: left;\n        padding: 10px; }\n\n.videos-outer-container .videos-container .video-item .video-info-container .video-title-container {\n          font-weight: 600;\n          font-size: 12px;\n          margin-bottom: 10px; }\n\n.videos-outer-container .videos-container .video-item .video-info-container .video-description-container {\n          font-size: 12px;\n          margin-bottom: 10px; }\n\n.videos-outer-container .videos-container .video-item .video-info-container .view-more {\n          font-size: 12px;\n          color: #0747a6;\n          font-weight: 600;\n          text-align: right; }\n\n.videos-outer-container .videos-container .video-item .video-info-container .view-more span {\n            cursor: pointer; }\n\n.videoplayer {\n  position: fixed;\n  top: 15%;\n  left: 30%;\n  z-index: 10; }\n\n.black-bg {\n  background: rgba(10, 10, 10, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 1;\n  width: 100%; }\n"

/***/ }),

/***/ "./src/app/components/training-video/training-video.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TrainingVideoComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_platform_browser__ = __webpack_require__("./node_modules/@angular/platform-browser/esm5/platform-browser.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var TrainingVideoComponent = /** @class */ (function () {
    function TrainingVideoComponent(sanitizer) {
        this.sanitizer = sanitizer;
        this.viewMoreText = "";
        this.viewMoreList = [
            "This Video will help you to how to login using credentials and understand about overall features of Proctur ERP",
            "Based on the institute type you can set up your proctur account",
            "Based on the institute type you can set up your proctur account",
            "This Video will help you to set custom conditions on activities/cases like SMS,Exam report,Fee,Report,Miscellaneous ",
            "Understand How to upload bulk enquiries with Single Click and also how to view the status of the upload done",
            "Understand How to create custom type of users and assign roles to them",
            "",
            "This video will help you to send custom messages to active students/faculties/alumni/inactive students",
            "",
            "This Video will help you understand how to handle enquiries and how to follow up with them",
            "",
            "",
            "This Video will guide you to understand how to update fee payment in proctur",
            "This Video will guide you to understand how to change fee payment details in proctur",
            "With this video understand how to collect fee payment via cheque/post dated cheque",
            "",
            "",
            "",
            "",
            "",
            "",
            "This video will guide you to how to convert active Students to alumni and how to delete courses"
        ];
        this.videoplayer = false;
    }
    TrainingVideoComponent.prototype.ngOnInit = function () {
    };
    TrainingVideoComponent.prototype.showVideo = function (url) {
        this.videoplayer = true;
        this.currentProjectUrl = this.sanitizer.bypassSecurityTrustResourceUrl(url);
    };
    TrainingVideoComponent.prototype.viewMore = function (id) {
        this.viewMoreText = this.viewMoreList[id];
    };
    TrainingVideoComponent.prototype.closePlayer = function () {
        this.videoplayer = false;
    };
    TrainingVideoComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-training-video',
            template: __webpack_require__("./src/app/components/training-video/training-video.component.html"),
            styles: [__webpack_require__("./src/app/components/training-video/training-video.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_platform_browser__["DomSanitizer"]])
    ], TrainingVideoComponent);
    return TrainingVideoComponent;
}());



/***/ })

});
//# sourceMappingURL=component.module.chunk.js.map