webpackJsonp(["course-list.module"],{

/***/ "./src/app/components/course-module/create-course/course-course-list/course-add/course-add.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"middle-section clearFix courseAdd\" style=\"height:auto;\">\r\n\r\n  <section class=\"middle-top mb0 clearFix\" style=\"margin: 10px 0px;\">\r\n    <h1 class=\"pull-left\">\r\n      Add Course\r\n    </h1>\r\n  </section>\r\n\r\n  <section class=\"middle-main clearFix\">\r\n    <div class=\"clearFix add-edit\">\r\n      <a (click)=\"toggleCreateNewSlot()\">\r\n        <i id=\"showAddBtn\" class=\"addBtnClass\">+</i>\r\n        <i id=\"showCloseBtn\" style=\"display:none\" class=\"closeBtnClass\">-</i>\r\n        <span>Create Master Course</span>\r\n      </a>\r\n    </div>\r\n    <div *ngIf=\"divCreateNewCourse\" class=\"create-standard-form wrapperForm\">\r\n      <div class=\"row\">\r\n        <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"idMasterCourse\">Master Course\r\n             <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <input type=\"text\" id=\"idMasterCourse\" #masterCourseInput name=\"masterCourse\" [(ngModel)]=\"newCourseAdd.master_course_name\"\r\n              class=\"form-ctrl\" placeholder=\"Enter Master Course Name\"/>\r\n          </div>\r\n        </div>\r\n        <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"idStandardName\">Standard Name\r\n             <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <select id=\"idStandardName\" #standardNameDDn class=\"form-ctrl\" [(ngModel)]=\"newCourseAdd.standard_id\">\r\n              <option value=\"-1\">Select Standard</option>\r\n              <option *ngFor=\"let opt of standardNameList\" [value]=\"opt.standard_id\">\r\n                {{opt.standard_name}}\r\n              </option>\r\n            </select>\r\n\r\n          </div>\r\n        </div>\r\n        <div class=\"c-lg-3 c-md-3 c-sm-3\" style=\"margin-top: 25px\">\r\n          <input type=\"button\" value=\"Go\" class=\"btn fullBlue\" (click)=\"btnGoClickCreateCourse()\">\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n\r\n  <section class=\"add-section-wrapper\" *ngIf=\"(subjectList.length > 0)\">\r\n    <div class=\"row name-section\">\r\n      <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n        <div class=\"field-wrapper\">\r\n          <label for=\"masterCourse\">Course Name\r\n           <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <input type=\"text\" name=\"masterCourse\" id=\"masterCourse\" [(ngModel)]=\"courseDetails.course_name\" class=\"form-ctrl\" />\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n        <div class=\"field-wrapper datePickerBox\">\r\n          <label for=\"startDate\">Start Date\r\n           <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <input type=\"text\" value=\"\" readonly=\"true\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"courseDetails.start_Date\" name=\"startDate\"\r\n            id=\"startDate\" bsDatepicker>\r\n          <!-- <span class=\"date-clear\" name=\"followupdate\" (click)=\"clearAddEnquiryDate('startDatePicker')\">clear</span> -->\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n        <div class=\"field-wrapper datePickerBox\">\r\n          <label for=\"endDate\">End Date\r\n           <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <input type=\"text\" value=\"\" readonly=\"true\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"courseDetails.end_Date\" name=\"endDate\"\r\n            bsDatepicker id=\"endDate\">\r\n          <!-- <span class=\"date-clear\" name=\"followupdate\" (click)=\"clearAddEnquiryDate('endDatePicker')\">clear</span> -->\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n        <div class=\"field-wrapper\">\r\n          <label for=\"endDate\">Academic Year </label>\r\n          <select class=\"form-ctrl\" [(ngModel)]=\"courseDetails.academic_year_id\" style=\"background: transparent\">\r\n            <option value=\"-1\">Select</option>\r\n            <option *ngFor=\"let opt of academicList\" [value]=\"opt.inst_acad_year_id\">\r\n              {{opt.inst_acad_year}}\r\n            </option>\r\n          </select>\r\n        </div>\r\n      </div>\r\n      <div class=\"c-sm-3 c-md-3 c-lg-3\" style=\"padding-top: 20px\">\r\n        <div [ngClass]=\"{'hideVisibility' : examGradeFeature == 0}\" class=\"field-checkbox-wrapper\" style=\"margin-top: 10px;\">\r\n          <input type=\"checkbox\" id=\"allow\" value=\"\" [(ngModel)]=\"courseDetails.allow_exam_grades\" name=\"allow\" class=\"form-checkbox\">\r\n          <label for=\"allow\">Allow Exam Grades</label>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"table-section\">\r\n      <table class=\"\">\r\n        <thead>\r\n          <tr>\r\n            <th>\r\n              Allocate Subject\r\n            </th>\r\n            <th>\r\n              Subject Name\r\n            </th>\r\n            <th>\r\n              Allocate Faculty\r\n            </th>\r\n          </tr>\r\n        </thead>\r\n        <tbody>\r\n          <tr *ngFor=\"let row of subjectList ; let i= index; trackBy: index\">\r\n            <td>\r\n              <div class=\"field-checkbox-wrapper\">\r\n                <input id=\"{{row.subject_id}}\" [(ngModel)]=\"row.uiSelected\" type=\"checkbox\" value=\"\" class=\"form-checkbox\">\r\n                <label for=\"{{row.subject_id}}\"></label>\r\n              </div>\r\n            </td>\r\n            <td>\r\n              {{row.subject_name}}\r\n            </td>\r\n            <td>\r\n              <div class=\"field-wrapper\">\r\n                <select class=\"form-ctrl\" [(ngModel)]=\"row.selected_teacher\">\r\n                  <option value=\"-1\"></option>\r\n                  <option *ngFor=\"let opt of activeTeachers\" [value]=\"opt.teacher_id\">\r\n                    {{opt.teacher_name}}\r\n                  </option>\r\n                </select>\r\n              </div>\r\n            </td>\r\n          </tr>\r\n        </tbody>\r\n      </table>\r\n    </div>\r\n    <div class=\"btn-section row\">\r\n      <button class=\"btn fullBlue pull-right\" (click)=\"addDataToTable()\">Add</button>\r\n    </div>\r\n  </section>\r\n\r\n\r\n  <section *ngIf=\"mainArrayForTable.length > 0\" class=\"add-section-wrapper\">\r\n    <table>\r\n      <thead>\r\n        <tr>\r\n          <th style=\"width:20%\">\r\n            Course Name\r\n          </th>\r\n          <th style=\"width:10%\">\r\n            Start Date\r\n          </th>\r\n          <th style=\"width:10%\">\r\n            End Date\r\n          </th>\r\n          <th style=\"width:20%\">\r\n            Academic Year\r\n          </th>\r\n          <th *ngIf=\"examGradeFeature == '1'\" style=\"width:20%\">\r\n            Grade\r\n          </th>\r\n          <th style=\"width:20%\">\r\n            Action\r\n          </th>\r\n        </tr>\r\n      </thead>\r\n      <tbody>\r\n        <tr id=\"row{{i}}\" *ngFor=\"let row of mainArrayForTable; let i= index ; trackBy:index\">\r\n          <td colspan=\"6\">\r\n            <div>\r\n              <table>\r\n                <tbody>\r\n                  <tr style=\"text-align: right\">\r\n                    <td style=\"width:20%\">\r\n                      <span>\r\n                        {{row.course_name}}\r\n                      </span>\r\n                    </td>\r\n                    <td style=\"width:10%\">\r\n                      <span>\r\n                        {{row.start_Date | datePipe}}\r\n                      </span>\r\n                    </td>\r\n                    <td style=\"width:10%\">\r\n                      <span>\r\n                        {{row.end_Date | datePipe}}\r\n                      </span>\r\n                    </td>\r\n                    <td style=\"width:20%\">\r\n                      <select class=\"form-ctrl\" [(ngModel)]=\"row.academic_year_id\">\r\n                        <option value=\"-1\">Select</option>\r\n                        <option *ngFor=\"let opt of academicList\" [value]=\"opt.inst_acad_year_id\">\r\n                          {{opt.inst_acad_year}}\r\n                        </option>\r\n                      </select>\r\n                    </td>\r\n                    <td *ngIf=\"examGradeFeature == '1'\" style=\"width:20%\">\r\n                      <span *ngIf='(row.allow_exam_grades == true)'>Yes</span>\r\n                      <span *ngIf='(row.allow_exam_grades != true)'>No</span>\r\n                    </td>\r\n                    <td>\r\n                      <!-- {{row.subjectListArray.subject_name}} -->\r\n                    </td>\r\n                    <td id=\"viewComp{{i}}\" class=\"viewComp\" style=\"width:20%\">\r\n                      <a style=\"cursor:pointer\" (click)=\"editRowFromTable(row , i)\">Edit</a>\r\n                      <a style=\"cursor:pointer\" (click)=\"removeRowFromTable(row , i)\">&nbsp;Delete</a>\r\n                    </td>\r\n                    <td id=\"editComp{{i}}\" class=\"editComp\" style=\"display:none ; width:20%\">\r\n                      <a style=\"cursor:pointer\" (click)=\"updateDataOfNestedTable(row, i)\"> &nbsp;Update</a>\r\n                    </td>\r\n                  </tr>\r\n                </tbody>\r\n              </table>\r\n            </div>\r\n\r\n            <div id=\"show{{i}}\" class=\"nestedTable nestedTableHide\">\r\n              <div class=\"row name-section\">\r\n                <div class=\"field-wrapper c-sm-3 c-md-3 c-lg-3\">\r\n                  <label for=\"masterCourse\">Course Name\r\n                   <span class=\"text-danger\">*</span>\r\n                  </label>\r\n                  <input type=\"text\" style=\"background: transparent\" name=\"masterCourse\" [(ngModel)]=\"row.course_name\" id=\"masterCourse\" class=\"form-ctrl\"\r\n                  />\r\n                </div>\r\n\r\n                <div class=\"field-wrapper c-sm-2 c-md-2 c-lg-2\">\r\n                  <label for=\"startDate\">Start Date\r\n                   <span class=\"text-danger\">*</span>\r\n                  </label>\r\n                  <input type=\"text\" value=\"\" style=\"background: transparent\" readonly=\"true\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"row.start_Date\"\r\n                    name=\"startDate\" bsDatepicker id=\"startDate\">\r\n                </div>\r\n\r\n                <div class=\"field-wrapper c-sm-2 c-md-2 c-lg-2\">\r\n                  <label for=\"endDate\">End Date\r\n                   <span class=\"text-danger\">*</span>\r\n                  </label>\r\n                  <input type=\"text\" value=\"\" style=\"background: transparent\" readonly=\"true\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"row.end_Date\"\r\n                    name=\"endDate\" bsDatepicker id=\"endDate\">\r\n                </div>\r\n                <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"endDate\">Academic Year </label>\r\n                      <select class=\"form-ctrl\" [(ngModel)]=\"row.academic_year_id\" >\r\n                        <option value=\"-1\">Select</option>\r\n                        <option *ngFor=\"let opt of academicList\" [value]=\"opt.inst_acad_year_id\">\r\n                          {{opt.inst_acad_year}}\r\n                        </option>\r\n                      </select>\r\n                    </div>\r\n                  </div>\r\n\r\n                <div *ngIf=\"examGradeFeature == 0\" class=\"field-checkbox-wrapper c-sm-3 c-md-3 c-lg-3\">\r\n                  <input type=\"checkbox\" value=\"\" [(ngModel)]=\"row.allow_exam_grades\" name=\"allow\" class=\"form-checkbox\" id=\"allow\">\r\n                  <label for=\"allow\">Allow Exam Grades</label>\r\n                </div>\r\n\r\n              </div>\r\n\r\n              <div class=\"table-section\">\r\n                <table>\r\n                  <thead>\r\n                    <tr>\r\n                      <th>\r\n                        Allocate Subject\r\n                      </th>\r\n                      <th>\r\n                        Subject Name\r\n                      </th>\r\n                      <th>\r\n                        Allocate Faculty\r\n                      </th>\r\n                    </tr>\r\n                  </thead>\r\n                  <tbody class=\"subjectListTableTbody\">\r\n                    <tr *ngFor=\"let data of row.subjectListArray ; let i= index; trackBy: index\">\r\n                      <td>\r\n                        <div class=\"field-checkbox-wrapper\">\r\n                          <input id=\"{{data.subject_id}}\" [(ngModel)]=\"data.uiSelected\" type=\"checkbox\" value=\"\" class=\"form-checkbox\">\r\n                          <label for=\"{{data.subject_id}}\"></label>\r\n                        </div>\r\n                      </td>\r\n                      <td>\r\n                        {{data.subject_name}}\r\n                      </td>\r\n                      <td>\r\n                        <div class=\"field-wrapper\">\r\n                          <select class=\"form-ctrl\" [(ngModel)]=\"data.selected_teacher\">\r\n                            <option value=\"-1\"></option>\r\n                            <option *ngFor=\"let opt of activeTeachers\" [value]=\"opt.teacher_id\">\r\n                              {{opt.teacher_name}}\r\n                            </option>\r\n                          </select>\r\n                        </div>\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                </table>\r\n              </div>\r\n\r\n            </div>\r\n\r\n          </td>\r\n        </tr>\r\n      </tbody>\r\n    </table>\r\n  </section>\r\n\r\n  <div class=\"pull-right\" style=\"margin-top: 10px;\">\r\n    <button class=\"btn\" routerLink=\"/view/course/create/courselist\">Back</button>\r\n    <button id=\"btnSave\" *ngIf=\"(mainArrayForTable.length>0)\" class=\"btn fullBlue\" [disabled]=\"isRippleLoad\" (click)=\"submitCourseDetails()\">Save</button>\r\n  </div>\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-course-list/course-add/course-add.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.courseAdd table tr {\n  background: white; }\n.courseAdd table tr th {\n    text-align: left;\n    padding: 10px 10px;\n    font-size: 12px;\n    font-weight: 500; }\n.courseAdd table tr td {\n    text-align: left;\n    padding: 5px 10px; }\n.courseAdd table.adderTable tr td .field-wrapper {\n  padding-top: 0px; }\n.courseAdd table.adderTable tr td .field-wrapper .form-ctrl {\n    padding: 5px 0 0px;\n    height: 30px; }\n.asideWrapperNested table tr {\n  background: white; }\n.asideWrapperNested table tr th {\n    text-align: left;\n    padding: 10px 10px;\n    font-size: 12px;\n    font-weight: 500; }\n.asideWrapperNested table tr td {\n    text-align: left;\n    padding: 0px 10px; }\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.marginTopTwenty {\n  margin-top: 20px; }\n.marginBottomTen {\n  margin-bottom: 10px; }\n.tableWrapper {\n  max-width: 75%;\n  margin-top: 20px;\n  margin-left: 70px; }\n.create-standard-form {\n  margin: 10px 0;\n  border-top: 1px solid #d8d8d8; }\n.create-standard-form .form-ctrl {\n    background: white; }\n.closeBtnClass {\n  line-height: 11px !important; }\n.add-edit {\n  margin-bottom: 15px;\n  margin-top: 15px; }\n.add-edit i {\n    display: inline-block;\n    width: 17px;\n    height: 17px;\n    border-radius: 50%;\n    line-height: 16px;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle;\n    margin-right: 4px; }\n.add-edit span {\n    display: inline-block; }\n.add-edit .expend-box i {\n    line-height: 12px;\n    font-size: 22px; }\n.add-edit a {\n    cursor: pointer; }\n.asideWrapper {\n  background: #efefef;\n  max-height: 220px;\n  overflow: hidden; }\n.asideWrapper ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n.asideTableWrapper {\n  border-bottom: 1px solid #d8d8d8;\n  max-height: 155px;\n  overflow-x: hidden;\n  overflow-y: scroll;\n  margin-top: 20px; }\n.asideTableWrapper ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n.leftform .row {\n  margin: 0;\n  padding: 15px; }\n.leftform .row .field-wrapper {\n    width: 80%; }\n.nestedTable {\n  max-height: 220px;\n  overflow: scroll; }\n.nestedTableHide {\n  display: none; }\n.nestedTableShow {\n  display: ''; }\n.asideWrapperNested {\n  max-height: 180px;\n  overflow-x: hidden; }\n.asideWrapperNested ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n.asideMainWrapper ::-webkit-scrollbar {\n  display: block;\n  width: 7px;\n  height: 7px; }\n.nestedTableAsideWrapper {\n  border-bottom: 1px solid #d8d8d8;\n  margin-top: 10px; }\n.hideVisibility {\n  visibility: hidden; }\n.editCourseWrapper {\n  max-height: 500px;\n  overflow: hidden; }\n.editCourseWrapper .middle-main {\n    max-height: 400px;\n    overflow-x: hidden;\n    overflow-y: auto; }\n.editCourseWrapper ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n.add-section-wrapper {\n  border: 1px solid #ccc;\n  padding: 5px 10px; }\n.add-section-wrapper .name-section {\n    margin-bottom: 5px; }\n.add-section-wrapper .table-section {\n    margin-top: 5px;\n    max-height: 200px;\n    overflow-x: hidden;\n    overflow-y: scroll; }\n.add-section-wrapper .table-section ::-webkit-scrollbar {\n      display: block;\n      width: 7px;\n      height: 7px; }\n.add-section-wrapper .table-section table {\n      max-height: 190px;\n      overflow-x: hidden;\n      overflow-y: scroll; }\n.add-section-wrapper .table-section table tr td {\n        padding: 0px 0px !important; }\n.add-section-wrapper .table-section table tr td .field-wrapper {\n          width: 200px;\n          padding: 5px 0px !important; }\n.add-section-wrapper .table-section table tr td .field-wrapper .form-ctrl {\n            height: 25px !important;\n            padding: 0px 0px !important; }\n.add-section-wrapper .table-section table tr td .field-checkbox-wrapper {\n          margin-left: 20px !important;\n          margin-bottom: 0px !important; }\n.add-section-wrapper .btn-section {\n    margin-top: 5px; }\n.add-section-wrapper .btn-section .btn.fullBlue {\n      margin-right: 25px; }\n.main-Table-Wrapper {\n  margin-top: 10px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-course-list/course-add/course-add.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CourseAddComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return DateMonthFormatter; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_course_services_course_list_service__ = __webpack_require__("./src/app/services/course-services/course-list.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var CourseAddComponent = /** @class */ (function () {
    function CourseAddComponent(apiService, toastCtrl, route) {
        this.apiService = apiService;
        this.toastCtrl = toastCtrl;
        this.route = route;
        this.newCourseAdd = {
            master_course_name: '',
            standard_id: '-1',
        };
        this.courseDetails = {
            course_name: '',
            start_Date: '',
            end_Date: '',
            academic_year_id: '-1',
            allow_exam_grades: ''
        };
        this.tableRowData = {
            checkBox_value: '',
            selected_teacher: '',
        };
        this.nestedTableForm = {
            course_name: '',
            start_Date: '',
            end_Date: '',
            allow_exam_grades: ''
        };
        this.academicList = [];
        this.subjectList = [];
        this.dummyArrayOfSubjectList = [];
        this.mainArrayForTable = new Array;
        this.isRippleLoad = false;
        this.divCreateNewCourse = false;
    }
    CourseAddComponent.prototype.ngOnInit = function () {
        this.examGradeFeature = sessionStorage.getItem('is_exam_grad_feature');
        this.getAllStandardNameList();
        this.toggleCreateNewSlot();
        this.getAcademicYearDetails();
    };
    CourseAddComponent.prototype.btnGoClickCreateCourse = function () {
        var _this = this;
        if (this.newCourseAdd.master_course_name != "" && this.newCourseAdd.standard_id != "" && this.newCourseAdd.standard_id != -1) {
            this.apiService.getSubjectListOfStandard(this.newCourseAdd.standard_id).subscribe(function (data) {
                //console.log(data);
                if (data.length == 0) {
                    var msg = {
                        type: "error",
                        title: "",
                        body: 'No Subjects configured for selected standard'
                    };
                    _this.toastCtrl.popToast(msg);
                }
                else {
                    _this.subjectListDataSource = data;
                    var rawData = _this.addKeyInData(data);
                    _this.MasterCourseDDn.nativeElement.setAttribute('readonly', true);
                    _this.StandardName.nativeElement.disabled = true;
                    _this.subjectList = rawData;
                    _this.getActiveTeacherList();
                }
            }, function (error) {
                //console.log(error);
                var data = {
                    type: "error",
                    title: "",
                    body: error.error.message
                };
                _this.toastCtrl.popToast(data);
            });
        }
        else {
            var data = {
                type: "error",
                title: "",
                body: "Please Fill Mandatory Fields"
            };
            this.toastCtrl.popToast(data);
        }
    };
    CourseAddComponent.prototype.getAcademicYearDetails = function () {
        var _this = this;
        this.academicList = [];
        this.apiService.getAcadYear().subscribe(function (res) {
            _this.academicList = res;
        }, function (err) {
        });
    };
    CourseAddComponent.prototype.getAllStandardNameList = function () {
        var _this = this;
        this.apiService.getStandardListFromServer().subscribe(function (data) {
            _this.standardNameList = data;
        }, function (error) {
            //console.log(error);
        });
    };
    CourseAddComponent.prototype.getActiveTeacherList = function () {
        var _this = this;
        this.apiService.getTeacherListFromServer().subscribe(function (data) {
            _this.activeTeachers = data;
            _this.activeTeachers.sort(function (a, b) {
                var textA = a.teacher_name.toUpperCase();
                var textB = b.teacher_name.toUpperCase();
                return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
            });
        }, function (error) {
            //console.log(error);
            var data = {
                type: "error",
                title: "",
                body: "Please refresh the page."
            };
            _this.toastCtrl.popToast(data);
        });
    };
    CourseAddComponent.prototype.addDataToTable = function () {
        if (this.courseDetails.course_name != "" && this.courseDetails.start_Date != ""
            && this.courseDetails.start_Date != null && this.courseDetails.end_Date != ''
            && this.courseDetails.end_Date != null) {
            if (this.courseDetails.start_Date > this.courseDetails.end_Date) {
                var err = {
                    type: "error",
                    title: "Date Selection",
                    body: "Please enter valid dates."
                };
                this.toastCtrl.popToast(err);
                return;
            }
            else {
                var validateData = this.validateAllFields(this.subjectList);
                if (validateData == false) {
                    return;
                }
                var obj = {};
                obj.course_name = this.courseDetails.course_name;
                obj.start_Date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.courseDetails.start_Date).format("YYYY-MM-DD");
                obj.end_Date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.courseDetails.end_Date).format("YYYY-MM-DD");
                obj.academic_year_id = this.courseDetails.academic_year_id;
                obj.allow_exam_grades = this.courseDetails.allow_exam_grades;
                obj.subjectListArray = this.keepCloning(this.subjectList);
                this.mainArrayForTable.push(obj);
                this.clearAllFormsData();
                this.toggleCreateNewSlot();
            }
        }
        else {
            var warning = {
                type: "error",
                title: "Mandatory Fields",
                body: "You haven't filled mandatory details."
            };
            this.toastCtrl.popToast(warning);
        }
    };
    CourseAddComponent.prototype.validateAllFields = function (data) {
        var selected = 0;
        for (var i = 0; i < data.length; i++) {
            if (data[i].uiSelected == true) {
                selected = +1;
                if (data[i].selected_teacher == "" || data[i].selected_teacher == '-1') {
                    var err = {
                        type: "error",
                        title: "Teacher not selected",
                        body: "Please specify teacher of subject."
                    };
                    this.toastCtrl.popToast(err);
                    return false;
                }
            }
        }
        if (selected == 0) {
            var err = {
                type: "error",
                title: '',
                body: "You have not selected any subject."
            };
            this.toastCtrl.popToast(err);
            return false;
        }
    };
    CourseAddComponent.prototype.clearAllFormsData = function () {
        this.courseDetails = {
            course_name: '',
            start_Date: '',
            end_Date: '',
            academic_year_id: '-1',
            allow_exam_grades: ''
        };
        var bindData = this.addKeyInData(this.subjectListDataSource);
        this.subjectList = bindData;
    };
    CourseAddComponent.prototype.addKeyInData = function (data) {
        data.forEach(function (element) {
            element.uiSelected = '';
            element.selected_teacher = '';
        });
        return data;
    };
    CourseAddComponent.prototype.submitCourseDetails = function () {
        var _this = this;
        var dataToSend = this.constructJsonToSend();
        if (dataToSend == false) {
            return;
        }
        ;
        if (!this.isRippleLoad) {
            this.isRippleLoad = true;
            this.apiService.saveCourseDetails(dataToSend).subscribe(function (res) {
                _this.isRippleLoad = false;
                var msg = {
                    type: "success",
                    title: "Course Creation",
                    body: "Course Creation Successfull."
                };
                _this.toastCtrl.popToast(msg);
                _this.route.navigateByUrl('/view/course/create/courselist');
            }, function (error) {
                _this.isRippleLoad = false;
                var warning = {
                    type: "error",
                    title: '',
                    body: error.error.message
                };
                _this.toastCtrl.popToast(warning);
            });
        }
    };
    CourseAddComponent.prototype.constructJsonToSend = function () {
        var obj = {};
        obj.master_course = this.newCourseAdd.master_course_name;
        obj.standard_id = this.newCourseAdd.standard_id;
        obj.coursesList = [];
        for (var i = 0; i < this.mainArrayForTable.length; i++) {
            var test = {};
            test.academic_year_id = this.mainArrayForTable[i].academic_year_id;
            test.course_name = this.mainArrayForTable[i].course_name;
            if (this.mainArrayForTable[i].start_Date != "" && this.mainArrayForTable[i].start_Date != null && this.mainArrayForTable[i].start_Date != "Invalid date") {
                test.start_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.mainArrayForTable[i].start_Date).format('YYYY-MM-DD');
            }
            else {
                this.toastCtrl.popToast({ type: "error", title: "Date Error", body: "Please enter start date" });
                return false;
            }
            if (this.mainArrayForTable[i].end_Date != "" && this.mainArrayForTable[i].end_Date != null && this.mainArrayForTable[i].end_Date != "Invalid date") {
                test.end_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.mainArrayForTable[i].end_Date).format('YYYY-MM-DD');
            }
            else {
                this.toastCtrl.popToast({ type: "error", title: "Date Error", body: "Please enter end date" });
                return false;
            }
            if (this.mainArrayForTable[i].allow_exam_grades == true) {
                test.is_exam_grad_feature = 1;
            }
            else {
                test.is_exam_grad_feature = 0;
            }
            test.batchesList = [];
            var selectedSubjectRow = this.checkIfAnySubjectSelected(this.mainArrayForTable[i].subjectListArray);
            if (selectedSubjectRow.length == 0) {
                var err = {
                    type: "error",
                    title: '',
                    body: "You have not selected any subject"
                };
                this.toastCtrl.popToast(err);
                return false;
            }
            for (var y = 0; y < selectedSubjectRow.length; y++) {
                var trp = {};
                trp.batch_name = this.newCourseAdd.master_course_name + '-' + this.mainArrayForTable[i].course_name + '-' + selectedSubjectRow[y].subject_name;
                trp.subject_id = selectedSubjectRow[y].subject_id.toString();
                if (selectedSubjectRow[y].selected_teacher == "" || selectedSubjectRow[y].selected_teacher == null || selectedSubjectRow[y].selected_teacher == "-1") {
                    var err = {
                        type: "error",
                        title: '',
                        body: "Please enter teacher for the subject."
                    };
                    this.toastCtrl.popToast(err);
                    return false;
                }
                else {
                    trp.teacher_id = selectedSubjectRow[y].selected_teacher.toString();
                }
                test.batchesList.push(trp);
            }
            obj.coursesList.push(test);
        }
        return obj;
    };
    CourseAddComponent.prototype.clearAddEnquiryDate = function (str) {
        if (str == "startDatePicker") {
            this.courseDetails.start_Date = "";
        }
        else {
            this.courseDetails.end_Date = "";
        }
    };
    CourseAddComponent.prototype.keepCloning = function (objectpassed) {
        if (objectpassed === null || typeof objectpassed !== 'object') {
            return objectpassed;
        }
        var temporaryStorage = objectpassed.constructor();
        for (var key in objectpassed) {
            temporaryStorage[key] = this.keepCloning(objectpassed[key]);
        }
        return temporaryStorage;
    };
    CourseAddComponent.prototype.toggleCreateNewSlot = function () {
        if (this.divCreateNewCourse == false) {
            this.divCreateNewCourse = true;
            document.getElementById('showCloseBtn').style.display = '';
            document.getElementById('showAddBtn').style.display = 'none';
        }
        else {
            this.divCreateNewCourse = false;
            document.getElementById('showCloseBtn').style.display = 'none';
            document.getElementById('showAddBtn').style.display = '';
        }
    };
    CourseAddComponent.prototype.removeRowFromTable = function (row, i) {
        this.mainArrayForTable.splice(i, 1);
    };
    CourseAddComponent.prototype.editRowFromTable = function (row, index) {
        document.getElementById(("show" + index).toString()).classList.add('nestedTableShow');
        document.getElementById(("show" + index).toString()).classList.remove('nestedTableHide');
        document.getElementById(("viewComp" + index).toString()).style.display = 'none';
        document.getElementById(("editComp" + index).toString()).style.display = '';
    };
    CourseAddComponent.prototype.updateDataOfNestedTable = function (row, index) {
        if (row.course_name != "" && row.start_Date != "" && row.end_Date != '') {
            if (row.start_Date > row.end_Date) {
                var err = {
                    type: "error",
                    title: "Date Selection",
                    body: "Please enter valid dates."
                };
                this.toastCtrl.popToast(err);
                return;
            }
            else {
                var validateData = this.validateAllFields(row.subjectListArray);
                if (validateData == false) {
                    var err = {
                        type: "error",
                        title: "Allocation Error",
                        body: "Please specify atleast one subject for the course."
                    };
                    this.toastCtrl.popToast(err);
                    return;
                }
                var obj = {};
                obj.course_name = row.course_name;
                obj.start_Date = __WEBPACK_IMPORTED_MODULE_3_moment__(row.start_Date).format("YYYY-MM-DD");
                obj.end_Date = __WEBPACK_IMPORTED_MODULE_3_moment__(row.end_Date).format("YYYY-MM-DD");
                obj.allow_exam_grades = row.allow_exam_grades;
                obj.subjectListArray = row.subjectListArray;
                this.mainArrayForTable[index] = obj;
                document.getElementById("show" + index).style.display = 'none';
                document.getElementById(("viewComp" + index).toString()).style.display = '';
                document.getElementById(("editComp" + index).toString()).style.display = 'none';
            }
        }
        else {
            var warning = {
                type: "error",
                title: "Mandatory Fields",
                body: "You haven't filled mandatory details."
            };
            this.toastCtrl.popToast(warning);
        }
    };
    CourseAddComponent.prototype.checkIfAnySubjectSelected = function (data) {
        var arr = [];
        for (var i = 0; i < data.length; i++) {
            if (data[i].uiSelected == true) {
                arr.push(data[i]);
            }
        }
        return arr;
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('standardNameDDn'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CourseAddComponent.prototype, "StandardName", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('masterCourseInput'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CourseAddComponent.prototype, "MasterCourseDDn", void 0);
    CourseAddComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-course-add',
            template: __webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-add/course-add.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-add/course-add.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_course_services_course_list_service__["a" /* CourseListService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_4__angular_router__["Router"]])
    ], CourseAddComponent);
    return CourseAddComponent;
}());

var DateMonthFormatter = /** @class */ (function () {
    function DateMonthFormatter() {
    }
    DateMonthFormatter.prototype.transform = function (value) {
        if (value != "" && value != null && value != undefined) {
            return __WEBPACK_IMPORTED_MODULE_3_moment__(value).format('DD-MMM-YYYY');
        }
        else {
            return value;
        }
    };
    DateMonthFormatter = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Pipe"])({
            name: 'datePipe'
        })
    ], DateMonthFormatter);
    return DateMonthFormatter;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/course-course-list/course-course-list.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<section class=\"middle-section clearFix\">\r\n  <section class=\"course-second course\">\r\n    <div class=\"boxPadding15\">\r\n\r\n      <!-- Expanding Table -->\r\n      <section class=\"middle-top mb0 clearFix section-header\">\r\n        <h1 class=\"pull-left\" style=\"padding-top:15px;\">\r\n          Course List\r\n        </h1>\r\n        <aside class=\"headEnq pull-right\">\r\n          <div style=\"display: inline-flex;\r\n          position: absolute;\r\n          top: -12px;\">\r\n            <!-- <p-splitButton label=\"{{selectedRowCount}} Enquiry Selected\" [model]=\"bulkAddItems\" *ngIf=\"selectedRowCount != 0\"></p-splitButton> -->\r\n          </div>\r\n          <ul style=\"display: inline-flex;\">\r\n            <li class=\"headerBtn\" routerLink='add' *ngIf=\"jsonFlags.isShowAddCourse\">\r\n              <i class=\"fa fa-plus\" aria-hidden=\"true\"></i>\r\n                &nbsp;\r\n                Add Course\r\n            </li>\r\n          </ul>\r\n        </aside>\r\n      </section>\r\n\r\n      <section class=\"clearFix tableCourseExp calender-view1\">\r\n        <div class=\"tableCourseInn table-responsive \">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th style=\"width:25%; text-align: left\">\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('master_course')\">Master Course Name</label>\r\n                </th>\r\n                <th style=\"width:20%\">\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('coursee_names')\">Course(s)</label>\r\n                </th>\r\n                <th style=\"width:20%\">\r\n                  <label style=\"cursor:pointer;\" >Academic Year </label>\r\n                </th>\r\n                <th style=\"width:20%\">\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('standard_name')\">Standard</label>\r\n                </th>\r\n                <th style=\"width:15%\">Action</th>\r\n\r\n              </tr>\r\n            </thead>\r\n            <tbody id=\"tbodyItem{{i}}\" class=\"table-accor-head\" *ngFor=\"let row of courseList; let i=index;\">\r\n              <tr>\r\n                <td colspan=\"5\">\r\n                  <div class=\"accordian-heading\">\r\n                    <h4 class=\"clearFix \">\r\n                      <span class=\"close-accor\" (click)=\"toggleTbodyClass(i)\">-</span>\r\n                      <span class=\"open-accor\" (click)=\"toggleTbodyClass(i)\">+</span>\r\n                      <span class=\"date-c\" (click)=\"toggleTbodyClass(i)\">{{row.master_course}}</span>\r\n                      <span class=\"pull-right\" *ngIf=\"jsonFlags.isShowAddStudent\" routerLink=\"{{row.master_course}}\" style=\"cursor: pointer;padding-right: 9% !important;text-align: left;\">\r\n                        <i class=\"edit-icon\" aria-hidden=\"true\" style=\"margin-right: 5px;\" title=\"Edit\"></i>Edit\r\n                      </span>\r\n                    </h4>\r\n                  </div>\r\n                </td>\r\n              </tr>\r\n              <tr id=\"tbodyView{{i}}\" class=\"hide\">\r\n                <td colspan=\"5\">\r\n                  <table>\r\n                    <tbody class=\"table-accor-view accorInnerTable\">\r\n                      <tr *ngFor=\"let sc of row.coursesList; let y= index;\">\r\n                        <td style=\"width:25%\"></td>\r\n                        <td style=\"width:20%\">{{sc.course_name}}</td>\r\n                        <td style=\"width:20%\">\r\n                          <select class=\"form-ctrl\" [disabled]=\"true\" [ngStyle]=\"{'background':sc.academic_year_id? 'lightgrey':'','cursor':sc.academic_year_id ? 'not-allowed':''}\" [(ngModel)]=\"sc.academic_year_id\" >\r\n                            <option value=\"-1\">Select</option>\r\n                            <option *ngFor=\"let opt of academicList\" [value]=\"opt.inst_acad_year_id\">\r\n                              {{opt.inst_acad_year}}\r\n                            </option>\r\n                          </select>\r\n                        </td>\r\n                        <td style=\"width:20%\">{{row.standard_name}}</td>\r\n                        <td style=\"width:15%\">\r\n                          <div class=\"action-box \">\r\n                            <a style=\"cursor:pointer\"  *ngIf=\"jsonFlags.isShowAddStudent\" (click)=\"addStudentToBatch(sc)\">Add Student\r\n                              <!-- <i class=\"far fa fa-plus-square\" style=\"font-size: 25px\" alt=\"Add Student\" title=\"Add Student\"></i> -->\r\n                            </a>\r\n                          </div>\r\n                        </td>\r\n                      </tr>\r\n                    </tbody>\r\n                  </table>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n            <tbody *ngIf=\"courseList.length == 0 && dataStatus === 1\">\r\n              <tr *ngFor=\"let dummy of dummyArr\">\r\n                <td *ngFor=\"let c of columnMaps\">\r\n                  <div class=\"skeleton\">\r\n                  </div>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n            <tbody *ngIf=\"(courseList.length ==0 && dataStatus === 2)\">\r\n              <tr>\r\n                <td colspan=\"6\" style=\"text-align:center\">\r\n                  No Course Found\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </section>\r\n\r\n      <!-- Pagination -->\r\n\r\n      <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n        <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n          <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\"\r\n            [pagesToShow]=\"10\" [page]=\"PageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRow\">\r\n          </pagination>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </section>\r\n</section>\r\n\r\n\r\n\r\n<!-- =============================================================================== -->\r\n<!-- =============================================================================== -->\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"addStudentPopUp\">\r\n  <div class=\"popup pos-abs popup-body-container\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closeStudentPopup()\">\r\n        <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n          <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" style=\"fill: currentColor\"></path>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content student-assign-popup\">\r\n        <div class=\"row popup-title\">\r\n          <h2>Course Name :\r\n            <span>{{courseDetails.course_name}}</span>\r\n          </h2>\r\n        </div>\r\n\r\n        <div class=\"row filter-section\">\r\n          <div class=\"c-sm-4 c-md-4 c-lg-4 radio-button\">\r\n            <div class=\"field-radio-wrapper\">\r\n              <input type=\"radio\" name=\"bothRadio\" id=\"bothRadio\" class=\"form-radio\" value=\"0\" [(ngModel)]=\"searchFilter.unassignFlag\"\r\n                (ngModelChange)=\"onRadioButtonChange()\">\r\n              <label for=\"bothRadio\">Both</label>\r\n            </div>\r\n            <div class=\"field-radio-wrapper\">\r\n              <input type=\"radio\" name=\"assignRadio\" id=\"assignRadio\" value=\"1\" class=\"form-radio\" [(ngModel)]=\"searchFilter.unassignFlag\"\r\n                (ngModelChange)=\"onRadioButtonChange()\">\r\n              <label for=\"assignRadio\">Assigned</label>\r\n            </div>\r\n            <div class=\"field-radio-wrapper\">\r\n              <input type=\"radio\" name=\"unassignStudent\" id=\"unassignStudent\" value=\"2\" class=\"form-radio\" [(ngModel)]=\"searchFilter.unassignFlag\"\r\n                (ngModelChange)=\"onRadioButtonChange()\">\r\n              <label for=\"unassignStudent\">UnAssigned</label>\r\n            </div>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n\r\n            <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n              <div class=\"field-wrapper\">\r\n                <select class=\"form-ctrl\" [(ngModel)]=\"searchFilter.standard_id\" name=\"standard\" id=\"standard\">\r\n                  <option value=\"-1\">Select Standard</option>\r\n                  <option *ngFor=\"let opt of standardList\" [value]=\"opt.standard_id\">\r\n                    {{opt.standard_name}}\r\n                  </option>\r\n                </select>\r\n\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n              <button class=\"btn\" (click)=\"getAllStudentList()\">Go</button>\r\n            </div>\r\n\r\n            <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n              <div class=\"search-filter-wrapper\">\r\n                <input #searchVal type=\"text\" class=\"normal-field\" placeholder=\"Search\" id=\"searchStudent\" name=\"searchData\"\r\n                  [(ngModel)]=\"searchData\">\r\n              </div>\r\n            </div>\r\n\r\n          </div>\r\n        </div>\r\n\r\n        <div *ngIf=\"showTable\">\r\n          <div class=\"table-wrapper\">\r\n            <table>\r\n              <thead>\r\n                <th>\r\n                  <div class=\"field-checkbox-wrapper\">\r\n                    <input #idSelectAll type=\"checkbox\" class=\"form-checkbox\" [(ngModel)]=\"allChecked\" (click)=\"selectAllCheckBox(idSelectAll)\">  <!-- [attr.disabled] = \"searchFilter.unassignFlag == 1 ? 'disabled' : null\" -->\r\n                    <label></label>\r\n                  </div>\r\n                </th>\r\n                <th>\r\n                  ID\r\n                </th>\r\n                <th>\r\n                  Country\r\n                </th>\r\n                <th>\r\n                  Name\r\n                </th>\r\n                <th>\r\n                  Contact No.\r\n                </th>\r\n                <th>\r\n                  Standard Class\r\n                </th>\r\n                <th>\r\n                  Academic Year\r\n                </th>\r\n                <th>\r\n                  Fee Template\r\n                </th>\r\n              </thead>\r\n              <tbody>\r\n                <tr id=\"row{{i}}\" *ngFor=\"let row of (studentList | searchPipe:searchData); let i = index; trackBy: i;\">\r\n                  <td>\r\n                    <div class=\"field-checkbox-wrapper\">\r\n                      <input type=\"checkbox\" id=\"studentcheck{{row.student_id}}\" class=\"form-checkbox\" [(ngModel)]=\"row.assigned\">  <!-- [disabled]=\"row.immutableKey\" -->\r\n                      <label></label>\r\n                    </div>\r\n                  </td>\r\n                  <td>\r\n                    {{row.student_disp_id}}\r\n                  </td>\r\n                  <td [title]=\"row.country_name\">\r\n                   {{row.country_code}}\r\n                    </td>\r\n                  <td>\r\n              {{row.student_name}}\r\n                  </td>\r\n                  <td>\r\n                    {{row.student_phone}}\r\n                  </td>\r\n                  <td>\r\n                    {{row.student_class}}\r\n                  </td>\r\n                  <td>\r\n                    <div class=\"field-wrapper\">\r\n                      <select class=\"form-ctrl\" [disabled]=\"true\" [ngStyle]=\"{'background':courseDetails.academic_year_id? 'lightgrey':'','cursor':courseDetails.academic_year_id ? 'not-allowed':''}\" [(ngModel)]=\"courseDetails.academic_year_id\" style=\"background: transparent\">\r\n                        <option value=\"-1\">Select</option>\r\n                        <option *ngFor=\"let opt of academicList\" [value]=\"opt.inst_acad_year_id\">\r\n                          {{opt.inst_acad_year}}\r\n                        </option>\r\n                      </select>\r\n                    </div>\r\n                  </td>\r\n                  <td>\r\n                    <div class=\"field-wrapper\">\r\n                      <select class=\"form-ctrl\" [disabled]=\"row.immutableKey\" [(ngModel)]=\"row.assigned_fee_template_id\"\r\n                        style=\"background: transparent\">\r\n                        <option value=\"-1\">Select</option>\r\n                        <option *ngFor=\"let opt of setDefaultTemplate(row.country_id,feeTemplateDataSource,row)\" [value]=\"opt.template_id\">\r\n                          {{opt.template_name}}\r\n                        </option>\r\n                      </select>\r\n                    </div>\r\n                  </td>\r\n                </tr>\r\n                <tr *ngIf=\"(studentList.length == 0)\">\r\n                  <td colspan=\"9\">\r\n                    No Student Details Found\r\n                  </td>\r\n                </tr>\r\n              </tbody>\r\n            </table>\r\n          </div>\r\n          <div class=\"row btn-section\" style=\"margin: 10px 10px 0 0;\">\r\n            <button class=\"btn fullBlue pull-right\" (click)=\"saveChanges()\">Save</button>\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n<section [hidden]=\"alertBox\">\r\n  <div class=\"confirmation_popup\">\r\n    <div class=\"confirm_title\">\r\n      <i class=\"fa fa-exclamation-triangle\" aria-hidden=\"true\" style=\"color: rgba(255,0,0,0.7);\"></i> &nbsp;\r\n      <span>Alert</span>\r\n    </div>\r\n    <div class=\"confirmation_msg_box\">\r\n      <span id=\"confirm_msg\">Do you wish to unassign student from the course?</span>\r\n    </div>\r\n    <br>\r\n    <div class=\"field-checkbox-wrapper\">\r\n      <input type=\"checkbox\" id=\"delete_unpaid_fee\" name=\"batch\" [(ngModel)]=\"delete_unpaid_fee\"\r\n          class=\"form-checkbox\">\r\n      <label> Delete unpaid fees installments</label>\r\n    </div>\r\n    <div class=\"confirmation_button_container\">\r\n      <input type=\"button\" value=\"Yes\" class=\"btn\" (click)=\"unassign_course()\">\r\n      <input type=\"button\" value=\"No\" class=\"btn\" (click)=\"closeAlert()\">\r\n      <!-- <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closeAlert()\"> -->\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n<div class=\"black-bg\" id=\"black-bg\" [hidden]=\"alertBox\" (click)=\"closeAlert()\">\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-course-list/course-course-list.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.boxPadding15 {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 0 15px; }\n.headEnq .headerBtn {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  border: 1px solid #0084f6;\n  padding: 4px 10px;\n  cursor: pointer;\n  color: #0084f6;\n  text-align: center;\n  border-radius: 4px; }\n.headEnq .headerBtn i {\n    display: inline-block;\n    cursor: pointer;\n    color: #0084f6; }\n.section-header {\n  border-bottom: 1px solid #d3d4d5;\n  padding-bottom: 10px; }\n.optMenu .enq-dropdown-content {\n  position: absolute;\n  background: white;\n  z-index: 10;\n  right: 2%;\n  width: 150px;\n  padding: 0px 5px;\n  height: 80px;\n  -webkit-box-shadow: 0px 0px 2px 0px #313030;\n          box-shadow: 0px 0px 2px 0px #313030; }\n.optMenu .enq-dropdown-content ul {\n    list-style: none; }\n.optMenu .enq-dropdown-content ul .export-icon {\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%229268 266 26 22%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %23999%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1223%22 data-name%3D%22Group 1223%22 transform%3D%22translate(8100 -6)%22%3E%0D    %3Cg id%3D%22Group_1211%22 data-name%3D%22Group 1211%22 transform%3D%22translate(0 -1)%22%3E%0D      %3Cpath id%3D%22Path_178%22 data-name%3D%22Path 178%22 class%3D%22cls-1%22 d%3D%22M11.588%2C3H3.353A2.36%2C2.36%2C0%2C0%2C0%2C1%2C5.353V19.47a2.36%2C2.36%2C0%2C0%2C0%2C2.353%2C2.353H17.47a2.36%2C2.36%2C0%2C0%2C0%2C2.353-2.353V11.235%22 transform%3D%22translate(1170 272.176)%22%2F%3E%0D      %3Cline id%3D%22Line_140%22 data-name%3D%22Line 140%22 class%3D%22cls-1%22 y1%3D%2210%22 x2%3D%2210%22 transform%3D%22translate(1180.412 274.588)%22%2F%3E%0D      %3Cpath id%3D%22Path_179%22 data-name%3D%22Path 179%22 class%3D%22cls-1%22 d%3D%22M30.059%2C8.059V1.588A.556.556%2C0%2C0%2C0%2C29.47%2C1H23%22 transform%3D%22translate(1160.941 273)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Crect id%3D%22Rectangle_691%22 data-name%3D%22Rectangle 691%22 class%3D%22cls-2%22 width%3D%2226%22 height%3D%2222%22 transform%3D%22translate(1168 272)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      margin: 10px 0px 0px 2px;\n      background-size: 20px auto;\n      padding: 0px 0px 0px 25px;\n      cursor: pointer;\n      font-size: 14px;\n      color: #888; }\n.optMenu .enq-dropdown-content ul .export-icon:hover {\n        color: #0084f6; }\n.optMenu .enq-dropdown-content ul .upload-icon {\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%2214362 435 26 22%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %238b8b8b%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1230%22 data-name%3D%22Group 1230%22 transform%3D%22translate(13654 -6)%22%3E%0D    %3Crect id%3D%22Rectangle_695%22 data-name%3D%22Rectangle 695%22 class%3D%22cls-1%22 width%3D%2226%22 height%3D%2222%22 transform%3D%22translate(708 441)%22%2F%3E%0D    %3Cg id%3D%22Symbol_12_5%22 data-name%3D%22Symbol 12 %E2%80%93 5%22 transform%3D%22translate(53 -16)%22%3E%0D      %3Cpath id%3D%22Path_161%22 data-name%3D%22Path 161%22 class%3D%22cls-2%22 d%3D%22M21%2C32v3.158H1V32%22 transform%3D%22translate(657 442.842)%22%2F%3E%0D      %3Cpath id%3D%22Path_162%22 data-name%3D%22Path 162%22 class%3D%22cls-2%22 d%3D%22M8%2C19l6.316%2C6.316L20.632%2C19%22 transform%3D%22translate(653.684 449)%22%2F%3E%0D      %3Cline id%3D%22Line_124%22 data-name%3D%22Line 124%22 class%3D%22cls-2%22 y1%3D%2216.316%22 transform%3D%22translate(668 458)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      margin: 10px 0px 0px 2px;\n      background-size: 20px auto;\n      padding: 0px 0px 0px 25px;\n      cursor: pointer;\n      font-size: 14px;\n      color: #888; }\n.optMenu .enq-dropdown-content ul .upload-icon:hover {\n        color: #0084f6; }\n.optMenu .enq-dropdown-content ul li {\n      height: 25px;\n      padding: 7px;\n      border-bottom: 1px solid rgba(119, 119, 119, 0.705); }\n.course-second .filter-for-courses {\n  margin-top: 0; }\n.course-second .filter-search {\n  margin-bottom: 0; }\n.course-second .filter-for-courses label {\n  margin-top: 10px; }\n.add-edit {\n  margin-bottom: 0;\n  margin-top: 20px; }\n.add-edit i {\n    border: 1px solid #0084f6;\n    display: inline-block;\n    width: 17px;\n    height: 17px;\n    border-radius: 50%;\n    line-height: 12px;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle;\n    margin-right: 4px; }\n.add-edit span {\n    display: inline-block; }\n.add-edit .expend-box i {\n    line-height: 12px;\n    font-size: 22px; }\n.create-standard-form {\n  margin: 10px 0;\n  padding: 10px 20px 20px;\n  background: #efefef;\n  border-top: 1px solid #d8d8d8; }\n.create-standard-form .form-ctrl {\n    background: transparent;\n    border-bottom: solid 1px #cccccc; }\n.create-standard-form p {\n    margin-top: 5px;\n    font-size: 10px;\n    color: #979797; }\n.create-standard-field {\n  margin-bottom: 10px; }\n.create-cancel-small {\n  margin-top: 10px; }\n.create-cancel-small .btn {\n    font-size: 14px;\n    font-weight: normal;\n    height: 36px; }\n.CourseListtableWrapper ::-webkit-scrollbar {\n  display: block;\n  width: 7px;\n  height: 7px; }\n.CourseListtableWrapper .popUpTableDiv {\n  max-height: 550px;\n  overflow-x: hidden;\n  overflow-y: scroll; }\n.btnWrapper .btn {\n  padding: 8px 0px 0px 0px;\n  border: none;\n  height: 35px;\n  width: 35px;\n  border-radius: 50%; }\n.btnWrapper .btn .tooltip {\n    position: relative;\n    top: -30px;\n    right: -30px;\n    min-width: 100px;\n    font-size: 12px;\n    padding: 6px;\n    height: 35px;\n    border-radius: 5px;\n    background: rgba(0, 0, 0, 0.541);\n    color: white;\n    visibility: hidden;\n    opacity: 0; }\n.btnWrapper .btn:hover {\n    background: #d8d6d6; }\n.btnWrapper .btn:hover .tooltip {\n      position: relative;\n      top: -26px;\n      right: 90px;\n      min-width: 83px;\n      padding: 6px;\n      border-radius: 5px;\n      font-size: 12px;\n      height: 30px;\n      background: rgba(0, 0, 0, 0.541);\n      color: white;\n      visibility: visible;\n      opacity: 1;\n      -webkit-transition: all 0.2s;\n      transition: all 0.2s; }\n.btnWrapper .btn:focus {\n    outline: none; }\n.btnWrapper .btn:active {\n    -webkit-box-shadow: none;\n            box-shadow: none; }\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 850px;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper span {\n    font-weight: 300;\n    display: inline-block; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n.popup-content ::-webkit-scrollbar {\n  display: block;\n  width: 7px;\n  height: 7px; }\n.content-wrapper {\n  max-height: 500px;\n  overflow-x: hidden;\n  overflow-y: scroll; }\ntable thead tr th {\n  padding-top: 10px;\n  padding-bottom: 10px;\n  font-size: 12px;\n  font-weight: 500; }\ntable tbody tr td {\n  padding-bottom: 5px;\n  padding-top: 5px; }\n.skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 50%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n.skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n@-webkit-keyframes progress {\n  0% {\n    -webkit-transform: translate3d(-100%, 0, 0);\n            transform: translate3d(-100%, 0, 0); }\n  100% {\n    -webkit-transform: translate3d(100%, 0, 0);\n            transform: translate3d(100%, 0, 0); } }\n@keyframes progress {\n  0% {\n    -webkit-transform: translate3d(-100%, 0, 0);\n            transform: translate3d(-100%, 0, 0); }\n  100% {\n    -webkit-transform: translate3d(100%, 0, 0);\n            transform: translate3d(100%, 0, 0); } }\n.tableCourseExp {\n  overflow: hidden;\n  overflow-y: auto; }\n.tableCourseExp ::-webkit-scrollbar {\n    display: block; }\n.tableCourseExp .tableCourseInn {\n    max-height: 68vh;\n    overflow-x: hidden;\n    overflow-y: auto; }\n.accorInnerTable tr {\n  line-height: 25px; }\n.accorInnerTable tr td {\n    font-size: 14px;\n    font-weight: 500; }\n.calender-view1 th {\n  padding: 10px;\n  font-size: 13px;\n  text-align: center; }\n.calender-view1 .table-responsive {\n  margin-top: 10px; }\n.calender-view1 .table-accor-head .open-accor {\n  display: block;\n  padding: -5px 2px 2px 2px;\n  margin-bottom: 2px;\n  border: none;\n  margin-top: -5px; }\n.calender-view1 .table-accor-head .close-accor {\n  border: none;\n  display: none; }\n.calender-view1 .table-accor-head.active .accordian-heading .open-accor {\n  display: none; }\n.calender-view1 .table-accor-head.active .accordian-heading .close-accor {\n  display: block; }\n.calender-view1 .table-accor-head td {\n  padding: 0;\n  background: #fff; }\n.calender-view1 .accordian-heading h4 {\n  padding: 3px !important;\n  color: #444;\n  border: 1px solid #eaecee;\n  border-radius: 20px;\n  margin: 4px 0 2px;\n  background: #e6f2fe;\n  text-align: left; }\n.calender-view1 .accordian-heading h4 .open-accor,\n  .calender-view1 .accordian-heading h4 .close-accor {\n    float: left; }\n.calender-view1 .accordian-heading h4 .close-accor {\n    width: 18px;\n    height: 18px;\n    line-height: 11px;\n    margin-top: 0; }\n.calender-view1 .accordian-heading h4 .open-accor {\n    width: 18px;\n    height: 18px;\n    line-height: 16px;\n    margin-top: 0; }\n.calender-view1 .accordian-heading h4 .date-c {\n    font-size: 13px;\n    line-height: 20px;\n    margin-left: 10px;\n    font-weight: 600; }\n.calender-view1 .accordian-heading h4 .delete-icon {\n    font-size: 18px;\n    color: #f44336;\n    margin-left: 10px;\n    margin-right: 9px;\n    cursor: pointer; }\n.calender-view1 .accordian-heading h4 .delete-icon svg {\n      width: 15px;\n      vertical-align: top;\n      display: inline-block;\n      margin-top: 3px; }\n.calender-view1 .accordian-heading h4 .delete-icon svg line {\n        stroke-width: 2; }\n.close-accor {\n  float: right;\n  width: 24px;\n  font-size: 31px;\n  height: 24px;\n  text-align: center;\n  border: 1px solid #0084f6;\n  border-radius: 50%;\n  line-height: 16px;\n  margin-right: 4px;\n  margin-top: 3px;\n  cursor: pointer;\n  color: #0084f6;\n  font-weight: 400; }\n.search-filter-wrapper .normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  height: 35px;\n  font-size: 14px; }\n.student-assign-popup .popup-title {\n  margin-left: 0px; }\n.student-assign-popup .filter-section {\n  padding: 10px 0px;\n  margin: 5px 0;\n  background: #efefef; }\n.student-assign-popup .filter-section .radio-button {\n    margin-top: 10px;\n    display: -webkit-inline-box;\n    display: -ms-inline-flexbox;\n    display: inline-flex; }\n.student-assign-popup .filter-section .radio-button .field-radio-wrapper {\n      margin-right: 5px; }\n.student-assign-popup .filter-section .field-wrapper {\n    padding-top: 0; }\n.student-assign-popup .filter-section .btn {\n    margin-left: 0; }\n.student-assign-popup .table-wrapper {\n  margin-top: 15px;\n  max-height: 280px;\n  overflow-x: hidden;\n  overflow-y: scroll; }\n.student-assign-popup .table-wrapper th {\n    text-align: left; }\n.student-assign-popup .table-wrapper td {\n    text-align: left;\n    padding: 5px; }\n.student-assign-popup .table-wrapper td .field-wrapper .form-ctrl {\n      padding: 5px;\n      width: 90px; }\n.black-bg {\n  background: rgba(10, 10, 10, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 1;\n  width: 100%; }\n.confirmation_popup {\n  position: fixed;\n  top: 35%;\n  left: 40%;\n  width: 300px;\n  background: white;\n  height: auto;\n  padding: 20px;\n  z-index: 100;\n  border-radius: 6px;\n  border-top: 4px solid rgba(255, 0, 0, 0.7);\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c; }\n.confirm_title {\n  font-size: 20px; }\n.confirmation_msg_box {\n  margin-top: 15px; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox {\n  opacity: 0;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px;\n  z-index: 1;\n  border: 2px solid #0084f6; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox + label {\n  vertical-align: middle;\n  font-size: 14px;\n  display: inline-block; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 2px;\n  position: absolute;\n  left: 0;\n  top: 0; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox:checked + label:after {\n  border: 2px solid #0084f6; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox + label:before {\n  width: 1px;\n  height: 1px;\n  left: 8px;\n  top: 9px;\n  position: absolute;\n  content: '';\n  border-top: 0;\n  border-right: 0;\n  border-left: 2px solid transparent;\n  border-bottom: 2px solid transparent;\n  -webkit-transform: rotate(-45deg);\n          transform: rotate(-45deg); }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox:checked + label:before {\n  border-left: 2px solid #0084f6;\n  border-bottom: 2px solid #0084f6;\n  width: 12px;\n  height: 5px;\n  left: 2px;\n  top: 5px; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox:checked + label {\n  color: #0084f6; }\n.confirmation_button_container {\n  margin-top: 20px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center; }\n.confirmation_button_container input {\n    width: 80px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-course-list/course-course-list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CourseCourseListComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_course_services_course_list_service__ = __webpack_require__("./src/app/services/course-services/course-list.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var CourseCourseListComponent = /** @class */ (function () {
    function CourseCourseListComponent(apiService, toastCtrl) {
        this.apiService = apiService;
        this.toastCtrl = toastCtrl;
        this.dummyArr = [0, 1, 2, 3, 4, 0, 1, 2, 3, 4];
        this.columnMaps = [0, 1, 2, 3, 4, 5];
        this.courseListDataSource = [];
        this.studentListDataSource = [];
        this.feeTemplateDataSource = [];
        this.studentList = [];
        this.academicList = [];
        this.standardList = [];
        this.courseList = [];
        this.isRippleLoad = false;
        this.addStudentPopUp = false;
        this.allChecked = false;
        this.showTable = false;
        this.alertBox = true;
        this.delete_unpaid_fee = false;
        this.searchData = "";
        this.PageIndex = 1;
        this.displayBatchSize = 10;
        this.dataStatus = 1;
        this.searchFilter = {
            unassignFlag: '0',
            standard_id: -1,
        };
        this.jsonFlags = {
            isShowAddStudent: false,
            isShowAddCourse: false
        };
    }
    CourseCourseListComponent.prototype.ngOnInit = function () {
        this.checkTabSelection();
        this.getCourseListForTable();
        this.getStandardList();
        this.getAcademicYearDetails();
        this.checkUserHadAccess();
    };
    // USER permission
    CourseCourseListComponent.prototype.checkUserHadAccess = function () {
        var permissionArray = sessionStorage.getItem('permissions');
        var usertype = sessionStorage.getItem('userType');
        if (permissionArray == null || permissionArray == "") {
            if (usertype == '0') {
                this.jsonFlags.isShowAddCourse = true;
                this.jsonFlags.isShowAddStudent = true;
            }
            else if (usertype == '3') {
                this.jsonFlags.isShowAddCourse = false;
                this.jsonFlags.isShowAddStudent = false;
            }
        }
        else {
            if (permissionArray != undefined) {
                if (permissionArray.indexOf('505') != -1) {
                    // MASTER-Course - 505 has all access
                    this.jsonFlags.isShowAddCourse = true;
                    this.jsonFlags.isShowAddStudent = true;
                }
            }
        }
    };
    CourseCourseListComponent.prototype.getCourseListForTable = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getCourseListFromServer().subscribe(function (data) {
            _this.dataStatus = 2;
            _this.courseListDataSource = data;
            _this.totalRow = data.length;
            _this.fetchTableDataByPage(_this.PageIndex);
            _this.isRippleLoad = false;
            if (data.length > 0) {
                setTimeout(function () {
                    _this.toggleTbodyClass(0);
                }, 300);
            }
        }, function (error) {
            _this.dataStatus = 2;
            _this.isRippleLoad = false;
            _this.messageToast('error', '', error.error.message);
        });
    };
    CourseCourseListComponent.prototype.getStandardList = function () {
        var _this = this;
        this.apiService.getStandardListFromServer().subscribe(function (res) {
            _this.standardList = res;
        }, function (err) {
        });
    };
    // pagination functions
    CourseCourseListComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.courseList = this.getDataFromDataSource(startindex);
    };
    CourseCourseListComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    CourseCourseListComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    CourseCourseListComponent.prototype.getDataFromDataSource = function (startindex) {
        var t = this.courseListDataSource.slice(startindex, startindex + this.displayBatchSize);
        return t;
    };
    CourseCourseListComponent.prototype.sortTable = function (str) {
        if (str == "master_course" || str == "standard_name" || str == "coursee_names") {
            this.courseList.sort(function (a, b) {
                var nameA = a[str].toUpperCase(); // ignore upper and lowercase
                var nameB = b[str].toUpperCase(); // ignore upper and lowercase
                if (nameA < nameB) {
                    return -1;
                }
                if (nameA > nameB) {
                    return 1;
                }
                // names must be equal
                return 0;
            });
        }
    };
    CourseCourseListComponent.prototype.rowSelectEvent = function (i) {
        this.selectedRow = i;
    };
    CourseCourseListComponent.prototype.addStudentToBatch = function (rowDetails) {
        this.addStudentPopUp = true;
        this.courseDetails = rowDetails;
        console.log("courseDetails", rowDetails);
        // this.getAllStudentList();
        this.getAllFeeTemplate();
    };
    // set default template and set 
    CourseCourseListComponent.prototype.setDefaultTemplate = function (country_id, templates, data) {
        templates[country_id] && templates[country_id].forEach(function (object) {
            if (object.is_default == 'Y' && data.assigned_fee_template_id == -1) {
                data.assigned_fee_template_id = object.template_id;
            }
        });
        return templates[country_id];
    };
    CourseCourseListComponent.prototype.getAcademicYearDetails = function () {
        var _this = this;
        this.academicList = [];
        this.apiService.getAcadYear().subscribe(function (res) {
            _this.academicList = res;
        }, function (err) {
        });
    };
    CourseCourseListComponent.prototype.getAllStudentList = function () {
        var _this = this;
        this.searchData = "";
        var unassign = "";
        if (this.searchFilter.unassignFlag == '2') {
            unassign = "Y";
        }
        else {
            unassign = "N";
        }
        var data = {
            course_id: this.courseDetails.course_id,
            standard_id: Number(this.searchFilter.standard_id),
            isUnassignedStudent: unassign
        };
        this.isRippleLoad = true;
        this.showTable = true;
        this.apiService.getStudentList(data).subscribe(function (res) {
            var clone = [];
            for (var i = 0; i < res.length; i++) {
                res[i]['immutableKey'] = res[i].assigned;
                clone.push(res[i]);
            }
            var data = _this.makeTableJson(clone);
            _this.studentListDataSource = _this.keepCloning(data);
            _this.studentList = data;
            _this.getHeaderCheckBoxValue();
            _this.isRippleLoad = false;
        }, function (error) {
            _this.isRippleLoad = false;
        });
    };
    CourseCourseListComponent.prototype.makeTableJson = function (res) {
        if (this.searchFilter.unassignFlag == '0') {
            return res;
        }
        else if (this.searchFilter.unassignFlag == '1') {
            var data_1 = [];
            res.forEach(function (element) {
                if (element.assigned) {
                    data_1.push(element);
                }
            });
            return data_1;
        }
        else {
            return res;
        }
    };
    CourseCourseListComponent.prototype.getAllFeeTemplate = function () {
        var _this = this;
        this.apiService.getFeeTemplate(this.courseDetails.course_id).subscribe(function (res) {
            _this.feeTemplateDataSource = res;
        }, function (err) {
            //console.log(err);
        });
    };
    CourseCourseListComponent.prototype.saveChanges = function () {
        var checkAssignedCourseList = this.checkAssignedCourse();
        if (checkAssignedCourseList.length > 0) {
            var checkFlag = true;
            for (var i = 0; i < checkAssignedCourseList.length; i++) {
                if (checkAssignedCourseList[i] == 'false') {
                    checkFlag = false;
                    break;
                }
            }
            if (!checkFlag) {
                this.alertBox = false;
                // if (confirm('If you unassign a course from student then corresponding unpaid fee instalments will be deleted. Do you wish to continue?')) {
                //   this.apiToAllocateAndDeallocate();
                // }
                // else{
                //   let data = this.getCheckedRows();
                //   for (let i = 0; i < Object.keys(data).length; i++) {
                //     (document.getElementById("studentcheck"+Object.keys(data)[i]) as HTMLInputElement).checked = true;
                //   }
                // }
            }
            else {
                this.addStudentPopUp = false;
                this.apiToAllocateAndDeallocate();
            }
        }
        else {
            this.addStudentPopUp = false;
            this.showTable = false;
        }
    };
    CourseCourseListComponent.prototype.unassign_course = function () {
        this.alertBox = true;
        this.apiToAllocateAndDeallocate();
    };
    CourseCourseListComponent.prototype.closeAlert = function () {
        this.alertBox = true;
        this.delete_unpaid_fee = false;
        var data = this.getCheckedRows();
        for (var i = 0; i < Object.keys(data).length; i++) {
            document.getElementById("studentcheck" + Object.keys(data)[i]).checked = true;
        }
    };
    CourseCourseListComponent.prototype.getUISelectedRows = function (data) {
        var tempdata = [];
        data.forEach(function (element) {
            if (element.assigned) {
                tempdata.push(element);
            }
        });
        return tempdata;
    };
    CourseCourseListComponent.prototype.apiToAllocateAndDeallocate = function () {
        var _this = this;
        this.isRippleLoad = true;
        var data = this.getCheckedRows();
        var dataToSend = {
            studentAssignedUnassigned_and_AcademicYearMapping: data,
            deleteCourse_SubjectUnPaidFeeSchedules: this.delete_unpaid_fee
        };
        // console.log(dataToSend)
        this.apiService.saveUpdatedList(dataToSend, this.courseDetails.course_id).subscribe(function (res) {
            _this.messageToast('success', '', 'Student\'(s) added successfully');
            _this.studentList = [];
            _this.addStudentPopUp = false;
            _this.isRippleLoad = false;
            _this.showTable = false;
        }, function (err) {
            _this.isRippleLoad = false;
            _this.messageToast('error', '', err.error.message);
        });
    };
    CourseCourseListComponent.prototype.getCheckedRows = function () {
        var test = {};
        for (var i = 0; i < this.studentListDataSource.length; i++) {
            for (var t = 0; t < this.studentList.length; t++) {
                if (this.studentList[t].student_id == this.studentListDataSource[i].student_id) {
                    if (this.studentList[t].assigned != this.studentListDataSource[i].assigned) {
                        test[this.studentList[t].student_id] = [this.studentList[t].assigned.toString(), this.studentList[t].academic_year.toString(), this.studentList[i].assigned_fee_template_id.toString()];
                        break;
                    }
                }
            }
        }
        return test;
    };
    CourseCourseListComponent.prototype.checkAssignedCourse = function () {
        var test = [];
        for (var i = 0; i < this.studentListDataSource.length; i++) {
            for (var t = 0; t < this.studentList.length; t++) {
                if (this.studentList[t].student_id == this.studentListDataSource[i].student_id) {
                    if (this.studentList[t].assigned != this.studentListDataSource[i].assigned) {
                        test = [this.studentList[t].assigned.toString()];
                        break;
                    }
                }
            }
        }
        return test;
    };
    CourseCourseListComponent.prototype.onRadioButtonChange = function () {
        this.searchData = "";
        this.studentList = [];
        this.studentListDataSource = [];
        this.getAllStudentList();
    };
    CourseCourseListComponent.prototype.searchStudent = function (element) {
        if (element.value != '' && element.value != null) {
            var searchData = this.studentListDataSource.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(element.value.toLowerCase()); });
            });
            this.studentList = searchData;
            this.PageIndex = 1;
        }
        else {
            this.studentList = this.studentListDataSource;
        }
    };
    CourseCourseListComponent.prototype.closeStudentPopup = function () {
        this.addStudentPopUp = false;
        this.alertBox = true;
        this.searchFilter = {
            unassignFlag: '0',
            standard_id: -1,
        };
        this.studentList = [];
        this.showTable = false;
        this.searchData = "";
    };
    CourseCourseListComponent.prototype.selectAllCheckBox = function (element) {
        var val = element.checked;
        for (var i = 0; i < this.studentList.length; i++) {
            this.studentList[i].assigned = val;
        }
    };
    CourseCourseListComponent.prototype.getHeaderCheckBoxValue = function () {
        for (var i = 0; i < this.studentList.length; i++) {
            if (this.studentList[i].assigned == false) {
                this.allChecked = false;
                break;
            }
            else {
                this.allChecked = true;
            }
        }
    };
    CourseCourseListComponent.prototype.keepCloning = function (objectpassed) {
        if (objectpassed === null || typeof objectpassed !== 'object') {
            return objectpassed;
        }
        var temporaryStorage = objectpassed.constructor();
        for (var key in objectpassed) {
            temporaryStorage[key] = this.keepCloning(objectpassed[key]);
        }
        return temporaryStorage;
    };
    CourseCourseListComponent.prototype.toggleTbodyClass = function (i) {
        document.getElementById('tbodyItem' + i) ? document.getElementById('tbodyItem' + i).classList.toggle("active") : '';
        document.getElementById('tbodyView' + i) ? document.getElementById('tbodyView' + i).classList.toggle("hide") : '';
    };
    CourseCourseListComponent.prototype.messageToast = function (Errortype, Errortitle, message) {
        var msg = {
            type: Errortype,
            title: Errortitle,
            body: message
        };
        this.toastCtrl.popToast(msg);
    };
    CourseCourseListComponent.prototype.checkTabSelection = function () {
        var _this = this;
        setTimeout(function () {
            _this.hideAllTabs();
            document.getElementById('liManageBatch').classList.add('active');
        }, 200);
    };
    CourseCourseListComponent.prototype.hideAllTabs = function () {
        document.getElementById('liStandard').classList.remove('active');
        document.getElementById('liSubject').classList.remove('active');
        document.getElementById('liManageBatch').classList.remove('active');
        // document.getElementById('liExam').classList.add('hide');
        document.getElementById('liClass').classList.remove('active');
    };
    CourseCourseListComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-course-course-list',
            template: __webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-course-list.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-course-list.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_course_services_course_list_service__["a" /* CourseListService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */]])
    ], CourseCourseListComponent);
    return CourseCourseListComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/course-course-list/course-edit/course-edit.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"middle-section clearFix head editCourseWrapper\">\r\n  <section class=\"middle-top mb0 clearFix\">\r\n    <h1 class=\"pull-left\">\r\n      <a routerLink=\"/view/course/create/courselist\">Course</a> / Edit\r\n      <u> {{selectedCourseDetails.master_course}}</u>\r\n    </h1>\r\n  </section>\r\n\r\n  <section class=\"middle-main clearFix\">\r\n\r\n    <div class=\"search-wrapper row\">\r\n      <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n        <div class=\"field-wrapper has-value\">\r\n          <label for=\"idMasterCourse\">Master Course\r\n           <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <input type=\"text\" id=\"idMasterCourse\" [(ngModel)]=\"selectedCourseDetails.master_course\r\n          \" name=\"masterCourse\" class=\"form-ctrl\" style=\"background: white\" />\r\n\r\n        </div>\r\n      </div>\r\n      <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n        <div class=\"field-wrapper has-value\">\r\n          <label for=\"idStanadardName\">Standard Name\r\n          </label>\r\n          <select id=\"idStanadardName\" class=\"form-ctrl\" disabled=\"true\" [(ngModel)]=\"selectedCourseDetails.standard_id\" style=\"background: white\">\r\n            <option *ngFor=\"let opt of standardNameList\" [value]=\"opt.standard_id\">\r\n              {{opt.standard_name}}\r\n            </option>\r\n          </select>\r\n\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"tableSection class-table-wrapper\">\r\n      <div>\r\n        <table class=\"table-courseEdit\">\r\n          <thead>\r\n              <tr>\r\n                  <th>\r\n                  </th>\r\n                  <th>\r\n                    Course Name\r\n                  </th>\r\n                  <th>\r\n                    Start Date\r\n                  </th>\r\n                  <th>\r\n                    End Date\r\n                  </th>\r\n                  <th >\r\n                      Academic Year\r\n                    </th>\r\n                  <th *ngIf=\"examGradeFeature == 1\">\r\n                    Allow Exam Grades\r\n                  </th>\r\n                  <th>\r\n\r\n                  </th>\r\n                </tr>\r\n          </thead>\r\n          <tbody>\r\n            <tr id=\"row{{i}}\" *ngFor=\"let row of mainTableDataSource; let i= index ;\">\r\n              <td class=\"noborder\" style=\"padding: 0px;\" colspan=\"7\">\r\n                <div id=\"show{{i}}\" class=\"nestedTable nested-Table-Show-Wrapper\">\r\n                  <div class=\"\">\r\n                    <table>\r\n                      <tbody>\r\n                        <tr class=\"editable-wrapper\">\r\n                          <td (click)=\"openSubjectTable(i)\">\r\n                            <h4 class=\"clearFix\">\r\n                              <!-- <span class=\"close-accor\">-</span> -->\r\n                              <span id=\"spani{{i}}\" style=\"color:blue; font-size: 20px;\">+</span>\r\n                            </h4>\r\n                          </td>\r\n                          <td>\r\n                            <div class=\"field-wrapper has-value\">\r\n                              <input type=\"text\" name=\"masterCourse\" style=\"background: transparent\" [(ngModel)]=\"mainTableDataSource[i].course_name\" class=\"form-ctrl\"\r\n                              />\r\n                              <!-- <label for=\"masterCourse\">Course Name\r\n                               <span class=\"text-danger\">*</span>\r\n                                [ngClass]=\"{disableDatePicker : mainTableDataSource[i].course_id == '0' }\"\r\n                              </label> -->\r\n                            </div>\r\n                          </td>\r\n                          <td>\r\n                            <div class=\"field-wrapper datePickerBox\">\r\n                              <input type=\"text\" value=\"\" readonly=\"true\" style=\"background: transparent\" [disabled]=\"mainTableDataSource[i].course_id != '0'\"\r\n                                [(ngModel)]=\"mainTableDataSource[i].start_date\" class=\"form-ctrl bsDatepicker\" name=\"startDate\"\r\n                                bsDatepicker>\r\n                            </div>\r\n                          </td>\r\n                          <td>\r\n                            <div class=\"field-wrapper has-value datePickerBox\">\r\n                              <input type=\"text\" value=\"\" readonly=\"true\" style=\"background: transparent\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"mainTableDataSource[i].end_date\"\r\n                                name=\"endDate\" bsDatepicker>\r\n                            </div>\r\n                          </td>\r\n                          <td  style=\"width: 12%;\">\r\n                              <select class=\"form-ctrl\" [(ngModel)]=\"mainTableDataSource[i].academic_year_id\">\r\n                                <option value=\"-1\">Select</option>\r\n                                <option *ngFor=\"let opt of academicList\" [value]=\"opt.inst_acad_year_id\">\r\n                                  {{opt.inst_acad_year}}\r\n                                </option>\r\n                              </select>\r\n                            </td>\r\n                          <td *ngIf=\"examGradeFeature == 1\">\r\n                            <div class=\"field-checkbox-wrapper\" style=\"margin-top: 25px;\">\r\n                              <input type=\"checkbox\" value=\"\" style=\"background: transparent\" [(ngModel)]=\"mainTableDataSource[i].is_exam_grad_feature\"\r\n                                (change)=\"openPopup($event.target.checked,mainTableDataSource[i])\" name=\"allow\" class=\"form-checkbox\" id=\"allow\">\r\n                              <label for=\"allow\">Allow Exam Grades</label>\r\n                            </div>\r\n                          </td>\r\n                          <td>\r\n                            <a *ngIf=\"row.course_id == '0'\" style=\"cursor:pointer\" (click)=\"removeRowFromTable(row , i)\">Delete</a>\r\n                          </td>\r\n                        </tr>\r\n                      </tbody>\r\n                    </table>\r\n                  </div>\r\n                  <div id=\"sub{{i}}\" class=\"tableWrapper hide subjectList-table-wrapper\">\r\n                    <table>\r\n                      <thead>\r\n                        <tr class=\"teacher-list\">\r\n                          <th>\r\n                            Allocate Subject\r\n                          </th>\r\n                          <th>\r\n                            Subject Name\r\n                          </th>\r\n                          <th>\r\n                            Allocate Faculty\r\n                          </th>\r\n                          <th>\r\n                          </th>\r\n                        </tr>\r\n                      </thead>\r\n                      <tbody class=\"subjectListTableTbody\">\r\n                        <tr class=\"teacher-list\" *ngFor=\"let row of mainTableDataSource[i].batchesList ; let y= index; trackBy: index\">\r\n                          <td>\r\n                            <div class=\"field-checkbox-wrapper\">\r\n\r\n                              <input id=\"{{row.subject_id}}\" [disabled]=\"row.uiSelected == true && row.isAssigned == 'N'\" [(ngModel)]=\"row.uiSelected\"\r\n                                type=\"checkbox\" value=\"\" class=\"form-checkbox\">\r\n                              <label for=\"{{row.subject_id}}\"></label>\r\n                            </div>\r\n                          </td>\r\n                          <td>\r\n                            {{row.subject_name}}\r\n                          </td>\r\n                          <td>\r\n                            <div class=\"field-wrapper\">\r\n                              <select class=\"form-ctrl\" [(ngModel)]=\"row.selected_teacher\">\r\n                                <option value=\"-1\"></option>\r\n                                <option *ngFor=\"let opt of activeTeachers\" [value]=\"opt.teacher_id\">\r\n                                  {{opt.teacher_name}}\r\n                                </option>\r\n                              </select>\r\n                            </div>\r\n                          </td>\r\n                          <td>\r\n                            <a *ngIf=\"(row.isAssigned == 'N')\" (click)=\"deleteSubjectRow(row, i , y)\">Delete</a>\r\n                          </td>\r\n                        </tr>\r\n                      </tbody>\r\n                    </table>\r\n                  </div>\r\n                </div>\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n        </table>\r\n      </div>\r\n    </div>\r\n\r\n  </section>\r\n\r\n  <div>\r\n    <div class=\"pull-left btn-group\">\r\n      <button class=\"btn fullBlue\" (click)=\"addRowToMainTable()\">Add Course</button>\r\n    </div>\r\n\r\n    <div class=\"row pull-right btn-group\">\r\n      <button class=\"btn\" routerLink='/view/course/create/courselist'>Cancel</button>\r\n      <button class=\"btn fullBlue\" *ngIf=\"mainTableDataSource.length >0\" [disabled]=\"!jsonVar.callApi\" (click)=\"updateEditedDetails()\">Update</button>\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\"  *ngIf=\"jsonVar.isallowGrading\">\r\n  <div class=\"popup pos-abs popup-body-container\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"jsonVar.isallowGrading=false\">\r\n        <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n          <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" style=\"fill: currentColor\"></path>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content\">\r\n        <div class=\"\">\r\n            <h2>Alert </h2>\r\n        </div>\r\n\r\n        <div class=\"row\">\r\n          {{jsonVar.message}}\r\n        </div>\r\n        <br><br>\r\n        <div class=\"row\" popup-footer>\r\n          <aside class=\"pull-right popup-btn\" style=\"margin: 10px 20px 0px 0px;\">\r\n            <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closePopup()\">\r\n            <input type=\"button\" value=\"Yes\" class=\"fullBlue btn\" (click)=\"allowMarksORGrades()\">\r\n          </aside>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-course-list/course-edit/course-edit.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.search-wrapper .field-wrapper {\n  margin-bottom: 5px; }\n.search-wrapper .field-wrapper .form-ctrl {\n    border-bottom: solid 1px #0084f6;\n    background: transparent; }\n.open-accor {\n  float: left;\n  width: 24px;\n  font-size: 24px;\n  height: 24px;\n  text-align: center;\n  border: none;\n  border-radius: 50%;\n  line-height: 22px;\n  margin-left: 20px;\n  margin-top: 3px;\n  cursor: pointer;\n  color: #0084f6; }\n.close-accor {\n  line-height: 17px; }\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.nestedTableHide {\n  display: none; }\n.nestedTableShow {\n  display: ''; }\n.disableDatePicker {\n  pointer-events: none; }\n.nested-Table-Show-Wrapper .field-wrapper {\n  background: transparent; }\n.nested-Table-Show-Wrapper .field-wrapper .form-ctrl {\n    background: transparent; }\n.nested-Table-Show-Wrapper ::-webkit-scrollbar {\n  display: block;\n  width: 7px;\n  height: 7px; }\n.btn-group {\n  margin-top: 15px !important;\n  margin-left: 0px !important;\n  margin-right: 0px !important; }\n.btn-group .btn {\n    margin: 0px 0px 0px 5px !important;\n    border-radius: 5px !important; }\n.tableSection .table-courseEdit tr th {\n  background: #f7f7f7;\n  font-size: 14px !important;\n  color: #000000;\n  font-weight: normal;\n  height: 20px;\n  padding: 10px 0px;\n  border-top: 2px solid rgba(119, 119, 119, 0.11);\n  text-align: left;\n  width: 20%;\n  font-weight: 600; }\n.tableSection .table-courseEdit tr th:first-child {\n    width: 4%; }\n.tableSection .table-courseEdit tr td.noborder {\n  border-top: none;\n  border-bottom: none; }\n.tableSection .table-courseEdit tr.editable-wrapper {\n  line-height: 5px; }\n.tableSection .table-courseEdit tr.editable-wrapper td {\n    padding: 0px 12px;\n    width: 22%;\n    border-bottom: 1px solid #efefef;\n    text-align: left; }\n.tableSection .table-courseEdit tr.editable-wrapper td:first-child {\n      width: 4%; }\n.tableSection .table-courseEdit tr.editable-wrapper .field-wrapper {\n    max-width: 85%;\n    padding-top: 0px;\n    margin-top: 0px; }\n.tableSection .table-courseEdit tr.editable-wrapper .field-wrapper .form-ctrl {\n      border-bottom: 1px solid #0084f6; }\n.tableSection .table-courseEdit tr.editable-wrapper .field-wrapper .form-ctrl.disableDatePicker {\n        border-bottom: none; }\n.tableSection .table-courseEdit tr.teacher-list th {\n  background: #e0eaec;\n  font-size: 14px !important;\n  color: #000000;\n  font-weight: normal;\n  height: 20px;\n  padding-top: 13px;\n  padding-bottom: 15px;\n  border-top: 2px solid rgba(119, 119, 119, 0.11);\n  text-align: center;\n  width: 22%; }\n.tableSection .table-courseEdit tr.teacher-list th:first-child {\n    width: 22%; }\n.tableSection .table-courseEdit tr.teacher-list td {\n  padding: 2px 5px; }\n.tableSection .table-courseEdit tr.teacher-list td .field-wrapper {\n    padding-top: 0px;\n    border-bottom: solid 1px #0084f6; }\n.nestedTable.nested-Table-Show-Wrapper .row table {\n  padding-top: 12px !important;\n  padding-bottom: 14px !important;\n  border-top: 2px solid rgba(119, 119, 119, 0.11);\n  text-align: center;\n  position: relative; }\n.middle-main .row .field-wrapper .has-value .form-ctrl {\n  margin-top: 2px;\n  color: #0084f6;\n  font-size: 12px; }\n.middle-section .middle-top h1 {\n  margin-top: 10px; }\n.field-wrapper.datePickerBox:after {\n  top: 2px; }\n.editCourseWrapper {\n  max-height: 90vh;\n  overflow: hidden;\n  min-height: 90vh; }\n.editCourseWrapper .middle-main {\n    max-height: 75vh;\n    min-height: 75vh;\n    overflow-x: hidden;\n    overflow-y: auto; }\n.editCourseWrapper ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-course-list/course-edit/course-edit.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CourseEditComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_course_services_course_list_service__ = __webpack_require__("./src/app/services/course-services/course-list.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var CourseEditComponent = /** @class */ (function () {
    function CourseEditComponent(apiService, toastCtrl, route, router) {
        var _this = this;
        this.apiService = apiService;
        this.toastCtrl = toastCtrl;
        this.route = route;
        this.router = router;
        this.selectedCourseDetails = [];
        this.mainTableDataSource = [];
        this.academicList = [];
        this.dummyArray = [];
        this.jsonVar = {
            callApi: true,
            isallowGrading: false,
            message: '',
            tempObject: {}
        };
        this.route.params.subscribe(function (params) {
            if (params.course_name != undefined && params.course_name != "" && params.course_name != null) {
                _this.courseName = params.course_name;
            }
            else {
                _this.router.navigateByUrl('/view/course/create/courselist');
            }
        });
    }
    CourseEditComponent.prototype.ngOnInit = function () {
        this.examGradeFeature = sessionStorage.getItem('is_exam_grad_feature');
        this.getSelectedCourse(this.courseName);
        this.getAllStandardNameList();
        this.getActiveTeacherList();
        this.getAcademicYearDetails();
    };
    CourseEditComponent.prototype.getAcademicYearDetails = function () {
        var _this = this;
        this.academicList = [];
        this.apiService.getAcadYear().subscribe(function (res) {
            _this.academicList = res;
        }, function (err) {
        });
    };
    CourseEditComponent.prototype.openSubjectTable = function (i) {
        var t = document.getElementById('spani' + i).innerHTML;
        if (t == '+') {
            document.getElementById('spani' + i).innerHTML = '-';
            document.getElementById('spani' + i).classList.add('close-accor');
            document.getElementById('sub' + i).classList.toggle('hide');
        }
        else {
            document.getElementById('spani' + i).innerHTML = '+';
            document.getElementById('spani' + i).classList.remove('close-accor');
            document.getElementById('sub' + i).classList.toggle('hide');
        }
    };
    CourseEditComponent.prototype.getSelectedCourse = function (data) {
        var _this = this;
        this.apiService.getSeletedMasterCourseEdit(data).subscribe(function (res) {
            _this.selectedCourseDetails = res;
            _this.getSubjectList(res.standard_id);
            _this.getMetaDataForTable(_this.selectedCourseDetails);
            _this.dummyArray.push("Selected Course");
            _this.makeMainTableDataSource();
        }, function (error) {
            //console.log(error);
            _this.messageToast('error', '', error.error.message);
        });
    };
    CourseEditComponent.prototype.getAllStandardNameList = function () {
        var _this = this;
        this.apiService.getStandardListFromServer().subscribe(function (data) {
            _this.standardNameList = data;
        }, function (error) {
            //console.log(error);
            _this.messageToast('error', '', 'Please refresh the page.');
        });
    };
    CourseEditComponent.prototype.getActiveTeacherList = function () {
        var _this = this;
        this.apiService.getTeacherListFromServer().subscribe(function (data) {
            _this.activeTeachers = data;
            _this.activeTeachers.sort(function (a, b) {
                var textA = a.teacher_name.toUpperCase();
                var textB = b.teacher_name.toUpperCase();
                return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
            });
        }, function (error) {
            //console.log(error);
            _this.messageToast('error', '', 'Please refresh the page.');
        });
    };
    CourseEditComponent.prototype.getSubjectList = function (standardID) {
        var _this = this;
        this.apiService.getSubjectListOfStandard(standardID).subscribe(function (res) {
            _this.dummyArray.push("Subject List");
            _this.subjectList = _this.addKeyInData(res);
            _this.nestedTableDataSource = _this.addKeyInData(res);
            _this.makeMainTableDataSource();
        }, function (err) {
            //console.log(err);
            _this.messageToast('error', '', 'Please refresh the page.');
        });
    };
    CourseEditComponent.prototype.openPopup = function (flag, data) {
        // object.course_id
        data.is_exam_grad_feature = (!flag);
        this.jsonVar.tempObject = data;
        this.jsonVar.isallowGrading = true;
        this.jsonVar.message = '';
        if (flag) {
            this.jsonVar.message = 'If exam grades are allowed, previous data of exam marks will be corrupted. Do you wish to proceed?';
        }
        else {
            this.jsonVar.message = "If exam marks are allowed, previous data of exam grades will be corrupted. Do you wish to proceed?";
        }
    };
    CourseEditComponent.prototype.allowMarksORGrades = function () {
        this.jsonVar.tempObject.is_exam_grad_feature = (!this.jsonVar.tempObject.is_exam_grad_feature);
        this.closePopup();
    };
    CourseEditComponent.prototype.closePopup = function () {
        this.jsonVar.isallowGrading = false;
        this.jsonVar.message = '';
    };
    CourseEditComponent.prototype.updateEditedDetails = function () {
        var _this = this;
        var dataToSend = this.constructJsonToSend();
        if (dataToSend == false) {
            return;
        }
        if (this.jsonVar.callApi) {
            this.jsonVar.callApi = false;
            this.apiService.updateDetailsInEdit(dataToSend).subscribe(function (res) {
                _this.jsonVar.callApi = true;
                _this.router.navigateByUrl('/view/course/create/courselist');
                _this.messageToast('success', '', 'Course updated successfully.');
            }, function (err) {
                _this.jsonVar.callApi = true;
                //console.log(err);
                _this.messageToast('error', '', err.error.message);
            });
        }
    };
    CourseEditComponent.prototype.removeRowFromTable = function (row, i) {
        this.mainTableDataSource.splice(i, 1);
    };
    CourseEditComponent.prototype.deleteSubjectRow = function (row, mainTableIndex, nestedTableIndex) {
        var _this = this;
        if (confirm("Are you sure you want to delete?")) {
            if (row.hasOwnProperty('otherDetails')) {
                this.apiService.deleteSubjectFromServer(row.otherDetails.batch_id).subscribe(function (data) {
                    _this.mainTableDataSource[mainTableIndex].batchesList[nestedTableIndex].uiSelected = false;
                    _this.mainTableDataSource[mainTableIndex].batchesList[nestedTableIndex].selected_teacher = '-1';
                    _this.checkIfAnySelectedRowExist(_this.mainTableDataSource[mainTableIndex], mainTableIndex);
                    _this.messageToast('success', 'Deleted', 'Sucessfully deleted from the list.');
                }, function (error) {
                    _this.messageToast('error', '', error.error.message);
                });
            }
        }
    };
    CourseEditComponent.prototype.checkIfAnySelectedRowExist = function (data, mainTableIndex) {
        var uiSelctedData = false;
        for (var i = 0; i < data.batchesList.length; i++) {
            if (data.batchesList[i].uiSelected == "Y" || data.batchesList[i].uiSelected == true) {
                uiSelctedData = true;
            }
        }
        if (uiSelctedData == false) {
            this.mainTableDataSource.splice(mainTableIndex, 1);
        }
    };
    CourseEditComponent.prototype.addRowToMainTable = function () {
        var obj = {};
        obj.start_date = '';
        obj.end_date = '';
        obj.course_name = '';
        obj.is_exam_grad_feature = 0;
        obj.course_id = "0";
        obj.academic_year_id = '-1';
        obj.batchesList = this.keepCloning(this.subjectList);
        this.mainTableDataSource.push(obj);
    };
    CourseEditComponent.prototype.constructJsonToSend = function () {
        var obj = {};
        obj.master_course = this.selectedCourseDetails.master_course;
        obj.standard_id = this.selectedCourseDetails.standard_id;
        obj.coursesList = [];
        for (var i = 0; i < this.mainTableDataSource.length; i++) {
            var test = {};
            if (this.mainTableDataSource[i].course_name == "" || this.mainTableDataSource[i].course_name == null) {
                this.messageToast('error', '', "Please Fill Mandatory Details");
                return false;
            }
            test.course_name = this.mainTableDataSource[i].course_name;
            test.academic_year_id = this.mainTableDataSource[i].academic_year_id;
            if (this.mainTableDataSource[i].start_date != "" && this.mainTableDataSource[i].start_date != null && this.mainTableDataSource[i].start_date != "Invalid date") {
                test.start_date = __WEBPACK_IMPORTED_MODULE_4_moment__(this.mainTableDataSource[i].start_date).format("YYYY-MM-DD");
            }
            else {
                this.messageToast('error', '', 'Please Provide start date');
                return false;
            }
            if (this.mainTableDataSource[i].end_date != "" && this.mainTableDataSource[i].end_date != null && this.mainTableDataSource[i].end_date != "Invalid date") {
                test.end_date = __WEBPACK_IMPORTED_MODULE_4_moment__(this.mainTableDataSource[i].end_date).format("YYYY-MM-DD");
            }
            else {
                this.messageToast('error', '', 'Please Provide end date');
                return false;
            }
            test.course_id = this.mainTableDataSource[i].course_id.toString();
            if (this.mainTableDataSource[i].is_exam_grad_feature == true) {
                test.is_exam_grad_feature = 1;
            }
            else {
                test.is_exam_grad_feature = 0;
            }
            test.batchesList = [];
            var selectedSubjectRow = this.checkIfAnySubjectSelected(this.mainTableDataSource[i].batchesList);
            if (selectedSubjectRow.length == 0) {
                this.messageToast('error', '', "You haven't selected any Subject");
                return false;
            }
            for (var y = 0; y < selectedSubjectRow.length; y++) {
                var trp = {};
                if (selectedSubjectRow[y].hasOwnProperty('otherDetails')) {
                    trp.batch_id = selectedSubjectRow[y].otherDetails.batch_id.toString();
                }
                else {
                    trp.batch_id = '0';
                }
                trp.batch_name = this.selectedCourseDetails.master_course + '-' + this.mainTableDataSource[i].course_name + '-' + selectedSubjectRow[y].subject_name;
                trp.subject_id = selectedSubjectRow[y].subject_id.toString();
                if (selectedSubjectRow[y].selected_teacher == "" || selectedSubjectRow[y].selected_teacher == '-1') {
                    this.messageToast('error', '', 'Please enter teacher');
                    return false;
                }
                trp.teacher_id = selectedSubjectRow[y].selected_teacher.toString();
                test.batchesList.push(trp);
            }
            obj.coursesList.push(test);
        }
        return obj;
    };
    CourseEditComponent.prototype.checkIfAnySubjectSelected = function (data) {
        var arr = [];
        for (var i = 0; i < data.length; i++) {
            if (data[i].uiSelected == true) {
                arr.push(data[i]);
            }
        }
        return arr;
    };
    CourseEditComponent.prototype.addKeyInData = function (data) {
        data.forEach(function (element) {
            element.uiSelected = '';
            element.selected_teacher = '';
            element.isAssigned = 'Y';
        });
        return data;
    };
    CourseEditComponent.prototype.getMetaDataForTable = function (data) {
        for (var i = 0; i < data.coursesList.length; i++) {
            this.mainTableDataSource.push(data.coursesList[i]);
        }
    };
    CourseEditComponent.prototype.makeMainTableDataSource = function () {
        if (this.dummyArray.length == 2) {
            for (var t = 0; t < this.mainTableDataSource.length; t++) {
                this.manipulateNestedTableDataSource(t);
            }
        }
        else {
            return;
        }
    };
    CourseEditComponent.prototype.manipulateNestedTableDataSource = function (index) {
        var test = this.mainTableDataSource[index].batchesList;
        this.nestedTableDataSource = this.keepCloning(this.subjectList);
        for (var i = 0; i < test.length; i++) {
            for (var y = 0; y < this.nestedTableDataSource.length; y++) {
                if (test[i].subject_id == this.nestedTableDataSource[y].subject_id) {
                    this.nestedTableDataSource[y].uiSelected = true;
                    this.nestedTableDataSource[y].selected_teacher = test[i].teacher_id;
                    this.nestedTableDataSource[y].isAssigned = test[i].isAssigned;
                    this.nestedTableDataSource[y].otherDetails = test[i];
                }
            }
        }
        this.mainTableDataSource[index].batchesList = this.nestedTableDataSource;
    };
    CourseEditComponent.prototype.keepCloning = function (objectpassed) {
        if (objectpassed === null || typeof objectpassed !== 'object') {
            return objectpassed;
        }
        var temporaryStorage = objectpassed.constructor();
        for (var key in objectpassed) {
            temporaryStorage[key] = this.keepCloning(objectpassed[key]);
        }
        return temporaryStorage;
    };
    CourseEditComponent.prototype.messageToast = function (errorType, errorTitle, errorMeassage) {
        var data = {
            type: errorType,
            title: errorTitle,
            body: errorMeassage
        };
        this.toastCtrl.popToast(data);
    };
    CourseEditComponent.prototype.parseDateFormat = function (date) {
        return __WEBPACK_IMPORTED_MODULE_4_moment__(date).format("YYYY-MM-DD");
    };
    CourseEditComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-course-edit',
            template: __webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-edit/course-edit.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-edit/course-edit.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_course_services_course_list_service__["a" /* CourseListService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_3__angular_router__["ActivatedRoute"],
            __WEBPACK_IMPORTED_MODULE_3__angular_router__["Router"]])
    ], CourseEditComponent);
    return CourseEditComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/course-course-list/course-list.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseListModule", function() { return CourseListModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap_custome_datepicker_bs_datepicker_module__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/bs-datepicker.module.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_course_services_course_list_service__ = __webpack_require__("./src/app/services/course-services/course-list.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__course_course_list_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-course-list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__course_list_routing_module__ = __webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-list.routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__course_edit_course_edit_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-edit/course-edit.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__course_add_course_add_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-add/course-add.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var CourseListModule = /** @class */ (function () {
    function CourseListModule() {
    }
    CourseListModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_3__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_3__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_4__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap_custome_datepicker_bs_datepicker_module__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_1__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_7__course_list_routing_module__["a" /* CourseListRouting */]
            ],
            exports: [],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_6__course_course_list_component__["a" /* CourseCourseListComponent */],
                __WEBPACK_IMPORTED_MODULE_8__course_edit_course_edit_component__["a" /* CourseEditComponent */],
                __WEBPACK_IMPORTED_MODULE_9__course_add_course_add_component__["a" /* CourseAddComponent */],
                __WEBPACK_IMPORTED_MODULE_9__course_add_course_add_component__["b" /* DateMonthFormatter */],
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_5__services_course_services_course_list_service__["a" /* CourseListService */],
            ]
        })
    ], CourseListModule);
    return CourseListModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/course-course-list/course-list.routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CourseListRouting; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__course_course_list_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-course-list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__course_edit_course_edit_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-edit/course-edit.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__course_add_course_add_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-course-list/course-add/course-add.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var CourseListRouting = /** @class */ (function () {
    function CourseListRouting() {
    }
    CourseListRouting = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__course_course_list_component__["a" /* CourseCourseListComponent */],
                        pathMatch: 'prefix',
                    },
                    {
                        path: 'add',
                        component: __WEBPACK_IMPORTED_MODULE_4__course_add_course_add_component__["a" /* CourseAddComponent */],
                        pathMatch: 'prefix'
                    },
                    {
                        path: ':course_name',
                        component: __WEBPACK_IMPORTED_MODULE_3__course_edit_course_edit_component__["a" /* CourseEditComponent */],
                        pathMatch: 'prefix'
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], CourseListRouting);
    return CourseListRouting;
}());



/***/ })

});
//# sourceMappingURL=course-list.module.chunk.js.map