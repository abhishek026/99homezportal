webpackJsonp(["custom-common.module"],{

/***/ "./src/app/components/custom-common/check-box-converter.pipe.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CheckBoxConverterPipe; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

/* Used to cconvert the input type id to text for user view purpose */
var CheckBoxConverterPipe = /** @class */ (function () {
    function CheckBoxConverterPipe() {
    }
    CheckBoxConverterPipe.prototype.transform = function (value, exponent) {
        if (value == 1) {
            return 'textbox';
        }
        else if (value == 2) {
            return "checkbox";
        }
        else if (value == 3) {
            return "dropdown";
        }
        else if (value == 4) {
            return "multiselect";
        }
    };
    CheckBoxConverterPipe = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Pipe"])({ name: 'checkBoxConverter' })
    ], CheckBoxConverterPipe);
    return CheckBoxConverterPipe;
}());



/***/ }),

/***/ "./src/app/components/custom-common/create-custom-comp/create-custom-comp.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"middle-section clearFix\" id=\"enquiryList\">\r\n  <section class=\"middle-top clearFix custom-comp-header\">\r\n    <div class=\"row\">\r\n      <h1 class=\"pull-left\" style=\"font-size: 14px;padding-top:10px \">\r\n        Manage Form Field (On Both)\r\n      </h1>\r\n    </div>\r\n  </section>\r\n\r\n  <section class=\"middle-main clearFix\">\r\n    <div class=\"row\">\r\n      <div class=\"clearFix add-edit\">\r\n        <a  (click)=\"toggleNewComponentVisisbility('Add')\">\r\n          <i id=\"addComponent-icon\" style=\"border:none;\">+</i>\r\n          <span class=\"txt_font\">Add New Form Field</span>\r\n        </a>\r\n      </div>\r\n    </div>\r\n    <div class=\"row\" style=\"margin-top:12px\">\r\n      <div class=\"c-lg-4\">\r\n        <h4> <span class=\"txt_font\" style=\"font-weight: 600\">Total Count</span> &nbsp;:&nbsp;{{userCreatedComponent.length}}</h4>\r\n      </div>\r\n      <div class=\"c-lg-4\"></div>\r\n      <div class=\"c-lg-4\" class=\"txt_font\">\r\n        <button class=\"btn pull-right\" style=\"font-size: 12px\" [routerLink]=\"['../customizedOnly']\">Student Form Fields</button>\r\n      </div>\r\n    </div>\r\n\r\n\r\n    <!-- Custom Component Table Here -->\r\n    <div class=\"custom-comp-tablewrapper\">\r\n      <div class=\"table-responsive\">\r\n        <table>\r\n          <thead>\r\n            <tr>\r\n              <th>Label</th>\r\n              <th>Type</th>\r\n              <th>Show On Student</th>\r\n              <th>Is Required</th>\r\n              <th>Is Searchable</th>\r\n              <th>Sequence</th>\r\n              <th>Max Length</th>\r\n              <th>Default Value</th>\r\n              <th>Is External</th>\r\n              <th></th>\r\n            </tr>\r\n          </thead>\r\n\r\n          <tbody>\r\n\r\n            <tr *ngFor=\"let comp of userCreatedComponent\">\r\n\r\n              <td>{{comp.label}}</td>\r\n\r\n              <td>{{comp.type|checkBoxConverter}}</td>\r\n\r\n              <td>{{comp.on_both}}</td>\r\n\r\n              <td>{{comp.is_required}}</td>\r\n\r\n              <td>{{comp.is_searchable}}</td>\r\n\r\n              <td>{{comp.sequence_number}}</td>\r\n\r\n              <td>{{comp.comp_length}}</td>\r\n\r\n              <td>{{comp.defaultValue}}</td>\r\n\r\n              <td>{{comp.is_external}}</td>\r\n\r\n              <td class=\"custom-table-action\">\r\n                <ul>\r\n                  <li>\r\n                    <i class=\"fa fa-pencil\" style=\"color:#1283f4;\" aria-hidden=\"true\" (click)=\"editRow(comp)\"></i>\r\n                  </li>\r\n                  <li>\r\n                    <i class=\"fa fa-trash\" style=\"color:#fa3145;\" aria-hidden=\"true\" (click)=\"deleteRow(comp)\"></i>\r\n                  </li>\r\n                </ul>\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n        </table>\r\n      </div>\r\n    </div>\r\n\r\n  </section>\r\n\r\n  <proctur-popup [sizeWidth]=\"'large'\" *ngIf=\"isEdit=='Add'||isEdit=='Edit'\">\r\n\r\n    <span class=\"closePopup pos-abs fbold show\" (click)=\"cancelRow()\" close-button>\r\n      <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n        <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" style=\"fill: currentColor\"></path>\r\n      </svg>\r\n    </span>\r\n\r\n    <h2 popup-header>{{isEdit}} Field</h2>\r\n\r\n    <div class=\"row updatecomponent-wrapper\" popup-content>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.label != ''}\">\r\n          <label for=\"label\">Label\r\n            <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"editCustomComponentForm.label\" name=\"label\">\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.type != '' }\">\r\n          <label for=\"opt.data_value\">Type\r\n            <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <select id=\"opt.data_value\" class=\"form-ctrl\" (ngModelChange)=\"checkValuetype($event)\" [(ngModel)]=\"editCustomComponentForm.type\" name=\"opt.data_value\">\r\n            <option value=\"\"></option>\r\n            <option *ngFor=\"let opt of componentShell\" [value]=\"opt.data_key\">\r\n              {{opt.data_value}}\r\n            </option>\r\n          </select>\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.prefilled_data != ''}\">\r\n          <label for=\"prefilledData\">Prefilled Data (Non-Empty And Separated By ,)</label>\r\n          <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"editCustomComponentForm.prefilled_data\" id=\"prefilledData\" name=\"prefilledData\">\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.description != ''}\">\r\n          <label for=\"description\">Description</label>\r\n          <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"editCustomComponentForm.description\" name=\"description\" id=\"description\">\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.on_both != ''}\">\r\n          <label for=\"onboth\">Show On Student</label>\r\n          <select id=\"onboth\" class=\"form-ctrl\" name=\"onboth\" [(ngModel)]=\"editCustomComponentForm.on_both\">\r\n            <option value=\"Y\">Yes</option>\r\n            <option value=\"N\">No</option>\r\n          </select>\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.is_required != ''}\">\r\n          <label for=\"isrequired\">Is Required</label>\r\n          <select id=\"isrequired\" class=\"form-ctrl\" name=\"isrequired\" [(ngModel)]=\"editCustomComponentForm.is_required\">\r\n            <option value=\"Y\">Yes</option>\r\n            <option value=\"N\" selected>No</option>\r\n          </select>\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.is_searchable != ''}\">\r\n          <label for=\"issearchable\">Is Searchable</label>\r\n          <select id=\"issearchable\" class=\"form-ctrl\" name=\"issearchable\" [(ngModel)]=\"editCustomComponentForm.is_searchable\">\r\n            <option value=\"Y\">Yes</option>\r\n            <option value=\"N\" selected>No</option>\r\n          </select>\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.sequence_number != ''}\">\r\n          <label for=\"sequencenumber\">Sequence (Numerals Only)</label>\r\n          <input type=\"text\" class=\"form-ctrl\" onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" maxlength=\"3\" [(ngModel)]=\"editCustomComponentForm.sequence_number\"\r\n            name=\"sequencenumber\" id=\"sequencenumber\">\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.comp_length != null}\">\r\n          <label for=\"complength\">Max- Length (Numerals Only)</label>\r\n          <input type=\"text\" class=\"form-ctrl\" onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" [(ngModel)]=\"editCustomComponentForm.comp_length\"\r\n            name=\"complength\" id=\"complength\">\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.defaultValue != ''}\">\r\n          <label for=\"defVal\">Default Value</label>\r\n          <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"editCustomComponentForm.defaultValue\" name=\"defVal\" id=\"defVal\">\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.is_external != ''}\">\r\n          <label for=\"isexternal\">Is External</label>\r\n          <select id=\"isexternal\" class=\"form-ctrl\" name=\"isexternal\" [(ngModel)]=\"editCustomComponentForm.is_external\">\r\n            <option value=\"Y\">Yes</option>\r\n            <option value=\"N\" selected>No</option>\r\n          </select>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"\" popup-footer>\r\n      <div class=\"clearfix\">\r\n        <aside class=\"pull-right popup-btn\">\r\n          <input type=\"button\" value=\"Cancel\" class=\"btn txt_font\" (click)=\"cancelRow()\">\r\n          <input type=\"button\" value=\"Update \" *ngIf=\"isEdit=='Edit'\" class=\"fullBlue btn txt_font\" (click)=\"updateRow()\">\r\n          <input type=\"button\" value=\"Add \" *ngIf=\"isEdit=='Add'\" class=\"fullBlue btn txt_font\" (click)=\"addNewCustomComponent()\">\r\n        </aside>\r\n      </div>\r\n    </div>\r\n\r\n  </proctur-popup>\r\n\r\n  <proctur-popup [sizeWidth]=\"'small'\" *ngIf=\"isDelete\">\r\n\r\n    <span class=\"closePopup pos-abs fbold show\" (click)=\"cancelRow()\" close-button>\r\n      <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n        <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n          <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n            <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n            <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n          </g>\r\n          <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n          />\r\n        </g>\r\n      </svg>\r\n    </span>\r\n\r\n    <h2 popup-header>Delete Field</h2>\r\n\r\n    <div class=\"row delete-wrapper\" popup-content>\r\n      <h5>You are about to delete {{editCustomComponentForm.label}}, kindy confirm your action.</h5>\r\n    </div>\r\n\r\n    <div class=\"\" popup-footer>\r\n      <div class=\"clearfix\">\r\n        <aside class=\"pull-right popup-btn\">\r\n          <input type=\"button\" value=\"Cancel\" class=\"btn txt_font\" (click)=\"cancelRow()\">\r\n          <input type=\"button\" value=\"Confirm\" class=\"fullBlue btn txt_font\" (click)=\"DeleteRowConfirmed()\">\r\n        </aside>\r\n      </div>\r\n    </div>\r\n\r\n  </proctur-popup>\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/custom-common/create-custom-comp/create-custom-comp.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.middle-section ::-webkit-scrollbar {\n  display: block;\n  width: 7px;\n  height: 7px; }\n.row {\n  margin: 0 15px; }\n.row.extraMargin {\n  margin: 10px 0 25px; }\n.custom-comp-header .row {\n  margin: 0 15px; }\n.txt_font {\n  font-size: 12px; }\n.add-edit a {\n  cursor: pointer; }\n.add-edit i {\n  border: 1px solid #0084f6;\n  display: inline-block;\n  width: 17px;\n  height: 17px;\n  border-radius: 50%;\n  line-height: 12px;\n  text-align: center;\n  font-size: 22px;\n  vertical-align: middle;\n  margin-right: 4px; }\n.createcomponent-wrapper {\n  padding: 10px 5px;\n  background: #efefef;\n  border: 1px solid #d8d8d8;\n  height: 100%;\n  width: 100%; }\n.createcomponent-wrapper .form-ctrl {\n    background: transparent;\n    border-bottom: solid 1px #cccccc !important; }\n.createcomponent-wrapper .field-wrapper .form-ctrl {\n    display: block;\n    width: 100%;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 10px 0 5px;\n    outline: none;\n    border: 0;\n    height: 36px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 24px; }\n.custom-comp-tablewrapper {\n  margin: 15px;\n  max-height: 70vh;\n  overflow: auto; }\n.custom-comp-tablewrapper ::-webkit-scrollbar {\n    display: block; }\n.custom-comp-tablewrapper table tr {\n    /*checkbox  */ }\n.custom-comp-tablewrapper table tr th {\n      padding: 10px; }\n.custom-comp-tablewrapper table tr td {\n      padding: 5px 10px !important;\n      font-size: 12px; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper {\n      margin-bottom: 0 !important;\n      background: transparent; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox {\n      opacity: 0;\n      position: absolute;\n      left: 0;\n      top: 0;\n      width: 20px;\n      height: 20px;\n      z-index: 1; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox + label {\n      vertical-align: middle;\n      -webkit-transition: all 0s;\n      transition: all 0s;\n      font-size: 10px;\n      display: inline-block; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox + label:after {\n      content: '';\n      width: 16px;\n      height: 16px;\n      border: 2px solid #ccc;\n      border-radius: 2px;\n      position: absolute;\n      left: 0;\n      top: 6px;\n      -webkit-transition: all 0s;\n      transition: all 0s; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox:checked + label:after {\n      border: 2px solid #0084f6; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox + label:before {\n      -webkit-transition: all 0s;\n      transition: all 0s;\n      width: 1px;\n      height: 1px;\n      left: 8px;\n      top: 12px;\n      position: absolute;\n      content: '';\n      border-top: 0;\n      border-right: 0;\n      border-left: 2px solid transparent;\n      border-bottom: 2px solid transparent;\n      -webkit-transform: rotate(-45deg);\n              transform: rotate(-45deg); }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox:checked + label:before {\n      border-left: 2px solid #0084f6;\n      border-bottom: 2px solid #0084f6;\n      width: 10px;\n      height: 4px;\n      left: 4px;\n      top: 12px; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox:checked + label {\n      color: #0084f6; }\n.custom-comp-tablewrapper table tr .field-wrapper {\n      padding: 0 !important; }\n.custom-comp-tablewrapper table tr .field-wrapper .form-ctrl {\n        display: block;\n        -webkit-box-sizing: border-box;\n                box-sizing: border-box;\n        padding: 0 0 0 5px;\n        outline: none;\n        border: 0;\n        height: 26px;\n        -webkit-box-shadow: none;\n                box-shadow: none;\n        border-radius: 0;\n        line-height: 25px;\n        background: transparent;\n        width: 80px;\n        text-align: center;\n        border-bottom: 1px solid #ccc; }\n.custom-comp-tablewrapper table .displayComp .edit-comp {\n    display: none; }\n.custom-comp-tablewrapper table .editComp .view-comp {\n    display: none; }\n.custom-table-action ul li {\n  display: inline-block;\n  margin: 0 5px; }\n.custom-table-action ul li a {\n    cursor: pointer; }\n.updatecomponent-wrapper {\n  padding: 10px 5px;\n  margin: 20px 0;\n  background: #efefef;\n  border-radius: 5px;\n  border: 1px solid #d8d8d8;\n  height: 100%;\n  width: 100%;\n  max-height: 400px;\n  overflow-x: hidden;\n  overflow-y: auto; }\n.updatecomponent-wrapper ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n.updatecomponent-wrapper .form-ctrl {\n    background: transparent;\n    border-bottom: solid 1px #cccccc !important; }\n.updatecomponent-wrapper .field-wrapper .form-ctrl {\n    display: block;\n    width: 100%;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 10px 0 5px;\n    outline: none;\n    border: 0;\n    height: 36px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 24px; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.delete-wrapper {\n  padding: 20px 15px;\n  margin: 10px 0;\n  background: #efefef; }\n.middle-main clearFix .middle {\n  font-size: 30px;\n  margin-left: 25px;\n  margin-top: 10px;\n  font-weight: 600px !important; }\n"

/***/ }),

/***/ "./src/app/components/custom-common/create-custom-comp/create-custom-comp.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CreateCustomCompComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_fetchprefilldata_service__ = __webpack_require__("./src/app/services/fetchprefilldata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_enquiry_services_post_enquiry_data_service__ = __webpack_require__("./src/app/services/enquiry-services/post-enquiry-data.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




/**  custome fields changes
 * updated by laxmi wapte
 */
var CreateCustomCompComponent = /** @class */ (function () {
    function CreateCustomCompComponent(prefill, postdata, msgService) {
        this.prefill = prefill;
        this.postdata = postdata;
        this.msgService = msgService;
        this.componentShell = [];
        this.userCreatedComponent = [];
        this.isRippleLoad = false;
        this.isDelete = false;
        this.isEdit = '';
        this.editCustomComponentForm = {
            comp_length: "",
            description: "",
            institution_id: sessionStorage.getItem('institute_id'),
            is_required: "N",
            is_searchable: "N",
            label: "",
            page: 1,
            prefilled_data: "",
            sequence_number: "",
            type: "",
            on_both: "Y",
            defaultValue: "",
            is_external: "N"
        };
    }
    CreateCustomCompComponent.prototype.ngOnInit = function () {
        this.fetchPrefillData();
    };
    /* fetches list of user created component and the default type */
    CreateCustomCompComponent.prototype.fetchPrefillData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.prefill.fetchComponentGenerator().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.componentShell = res;
        }, function (err) {
            _this.isRippleLoad = false;
        });
        this.isRippleLoad = true;
        return this.prefill.fetchUserCreatedComponent().subscribe(function (res) {
            _this.isRippleLoad = false;
            if (res != null && res.length > 0) {
                _this.userCreatedComponent = res;
            }
        }, function (err) {
            _this.isRippleLoad = false;
        });
    };
    /* toggle the visibility of the the new component created */
    CreateCustomCompComponent.prototype.toggleNewComponentVisisbility = function (type) {
        this.isEdit = type;
        this.emptyObject();
    };
    CreateCustomCompComponent.prototype.addNewCustomComponent = function () {
        var _this = this;
        //Case 1 Label/Type is not empty and MaxLength and Sequence
        if (this.editCustomComponentForm.label.trim() != "") {
            if (this.editCustomComponentForm.type != "") {
                //Case 2 if its a select or multiselect dropdown list cannot be empty or duplicate
                if (this.editCustomComponentForm.type == "3" ||
                    this.editCustomComponentForm.type == "4") {
                    /* Validate Prefilled Data */
                    if (this.validateDropDown(this.editCustomComponentForm.prefilled_data)) {
                        if (this.validateDropdownDefvalue(this.editCustomComponentForm.prefilled_data, this.editCustomComponentForm.defaultValue)) {
                            this.isRippleLoad = true;
                            this.postdata.addNewCustomComponent(this.editCustomComponentForm).subscribe(function (res) {
                                _this.isRippleLoad = false;
                                _this.msgService.showErrorMessage('success', '', 'Form-Field added successfully');
                                _this.cancelEditRow();
                            }, function (err) {
                                _this.isRippleLoad = false;
                                _this.msgService.showErrorMessage('error', '', 'Label name is already created with the same name');
                            });
                        }
                        else {
                            this.msgService.showErrorMessage('error', '', 'dropdown default value should be present in prefilled data');
                        }
                    }
                    else {
                        this.msgService.showErrorMessage('error', '', 'Prefill data has to be unique and non-empty');
                    }
                }
                else if (this.editCustomComponentForm.type == "5") {
                    /* Date cannot be searchable and does not a default value */
                    if (this.editCustomComponentForm.is_searchable == "N" && this.editCustomComponentForm.defaultValue.trim() == "") {
                        this.isRippleLoad = true;
                        this.postdata.addNewCustomComponent(this.editCustomComponentForm).subscribe(function (res) {
                            _this.isRippleLoad = false;
                            _this.msgService.showErrorMessage('success', '', 'Form-Field added successfully');
                            _this.cancelEditRow();
                        }, function (err) {
                            _this.isRippleLoad = false;
                            _this.msgService.showErrorMessage('error', '', 'There was an error processing your request' + err.error.message);
                        });
                    }
                    else {
                        this.msgService.showErrorMessage('error', '', 'Date Field Cannot Be Searchable Or have any default value');
                    }
                }
                else if (this.editCustomComponentForm.type != "3" && this.editCustomComponentForm.type != "4" && this.editCustomComponentForm.type != "5") {
                    this.isRippleLoad = true;
                    this.postdata.addNewCustomComponent(this.editCustomComponentForm).subscribe(function (res) {
                        _this.isRippleLoad = false;
                        _this.msgService.showErrorMessage('success', '', 'Form-Field added successfully');
                        _this.cancelEditRow();
                    }, function (err) {
                        _this.isRippleLoad = false;
                        _this.msgService.showErrorMessage('error', '', 'Label name already exists');
                    });
                }
            }
            else {
                this.msgService.showErrorMessage('error', '', 'Please mention a type');
            }
        }
        else {
            this.msgService.showErrorMessage('error', '', 'Please mention a Label');
        }
    };
    CreateCustomCompComponent.prototype.isDefaultEmpty = function (obj) {
        if (obj.defaultValue) {
            return true;
        }
    };
    CreateCustomCompComponent.prototype.validateDropDown = function (data) {
        var arr = data.split(',');
        /* boolean for non empty value */
        var test1 = arr.every(function checkNonEmpty(el) {
            return (el != "" && el != " ");
        });
        /* convert array to set unique value */
        this.editCustomComponentForm.prefilled_data = Array.from(new Set(arr)).join(',');
        return test1;
    };
    CreateCustomCompComponent.prototype.validateDropdownDefvalue = function (tocheck, tomatch) {
        var arr = tocheck.split(',');
        for (var i = 0; i < arr.length; i++) {
            if (tomatch === arr[i].trim()) {
                return true;
            }
        }
        return false;
    };
    CreateCustomCompComponent.prototype.validateDropDownUpdate = function (data) {
        var arr = data.split(',');
        /* boolean for non empty value */
        var test1 = arr.every(function checkNonEmpty(el) {
            return (el != "" && el != " ");
        });
        /* convert array to set unique value */
        return test1;
    };
    //edit manage field and set editable object
    CreateCustomCompComponent.prototype.editRow = function (data) {
        this.editCustomComponentForm = Object.assign({}, data);
        this.checkValuetype(this.editCustomComponentForm.type);
        this.isEdit = 'Edit';
    };
    CreateCustomCompComponent.prototype.emptyObject = function () {
        this.editCustomComponentForm = {
            comp_length: "",
            description: "",
            institution_id: sessionStorage.getItem('institute_id'),
            is_required: "N",
            is_searchable: "N",
            label: "",
            page: 1,
            prefilled_data: "",
            sequence_number: "",
            type: "",
            on_both: "Y",
            defaultValue: "",
            is_external: "N"
        };
    };
    CreateCustomCompComponent.prototype.cancelEditRow = function () {
        this.emptyObject();
        this.fetchPrefillData();
        this.isEdit = '';
    };
    CreateCustomCompComponent.prototype.updateRow = function () {
        var _this = this;
        var data = this.editCustomComponentForm;
        //Case 1 Label/Type is not empty and MaxLength and Sequence
        if (data.label.trim() != "" && data.type != "") {
            //Case 2 if its a select or multiselect dropdown list cannot be empty or duplicate
            if (data.type == "3" || data.type == "4") {
                /* Validate Prefilled Data */
                if (this.validateDropDown(data.prefilled_data)) {
                    if (this.validateDropdownDefvalue(data.prefilled_data, data.defaultValue)) {
                        this.isRippleLoad = true;
                        this.postdata.updateCustomComponent(data).subscribe(function (res) {
                            _this.isRippleLoad = false;
                            _this.cancelEditRow();
                            _this.msgService.showErrorMessage('success', '', 'Form-Field  Updated Successfully');
                        }, function (err) {
                            _this.isRippleLoad = false;
                            _this.msgService.showErrorMessage('error', '', err.error.message);
                        });
                    }
                    else {
                        this.msgService.showErrorMessage('error', 'dropdown default value should be present in prefilled data', '');
                    }
                }
                else {
                    this.msgService.showErrorMessage('error', 'Prefill data has to be unique and non-empty', '');
                }
            }
            else if (data.type == "5") {
                /* Date cannot be searchable and does not a default value */
                if (data.is_searchable == "N" && data.defaultValue.trim() == "") {
                    this.isRippleLoad = true;
                    this.postdata.updateCustomComponent(data).subscribe(function (res) {
                        _this.isRippleLoad = false;
                        _this.cancelEditRow();
                        _this.msgService.showErrorMessage('success', '', 'Form-Field updated successfully');
                    }, function (err) {
                        _this.isRippleLoad = false;
                        _this.msgService.showErrorMessage('error', '', err.error.message);
                    });
                }
                else {
                    this.msgService.showErrorMessage('error', 'Date field cannot be searchable Or have any default value', '');
                }
            }
            else if (data.type != "3" && data.type != "4" && data.type != "5") {
                this.isRippleLoad = true;
                this.postdata.updateCustomComponent(data).subscribe(function (res) {
                    _this.isRippleLoad = false;
                    _this.cancelEditRow();
                    _this.msgService.showErrorMessage('success', '', 'Form-Field updated successfully');
                }, function (err) {
                    _this.isRippleLoad = false;
                    _this.msgService.showErrorMessage('error', '', err.error.message);
                });
            }
        }
        else {
            this.msgService.showErrorMessage('error', '', 'Please mention a label/type');
        }
    };
    CreateCustomCompComponent.prototype.deleteRow = function (data) {
        this.editCustomComponentForm = data;
        this.isDelete = true;
    };
    CreateCustomCompComponent.prototype.cancelRow = function () {
        this.isDelete = false;
        this.isEdit = '';
        this.emptyObject();
    };
    //this function set default max length  50 when type is textbox
    CreateCustomCompComponent.prototype.checkValuetype = function (value) {
        this.editCustomComponentForm.comp_length = value == 1 ? 50 : 0;
    };
    //delete manage filed
    CreateCustomCompComponent.prototype.DeleteRowConfirmed = function () {
        var _this = this;
        var data = this.editCustomComponentForm;
        this.isRippleLoad = true;
        this.postdata.deleteCustomComponent(data.component_id).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage('success', 'Form-field Deleted ', 'requested form-field deleted Successfully');
            _this.cancelEditRow();
            _this.cancelRow();
        }, function (err) {
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage('error', '', err.error.message);
            _this.cancelRow();
        });
    };
    CreateCustomCompComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-create-custom-comp',
            template: __webpack_require__("./src/app/components/custom-common/create-custom-comp/create-custom-comp.component.html"),
            styles: [__webpack_require__("./src/app/components/custom-common/create-custom-comp/create-custom-comp.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_fetchprefilldata_service__["a" /* FetchprefilldataService */],
            __WEBPACK_IMPORTED_MODULE_2__services_enquiry_services_post_enquiry_data_service__["a" /* PostEnquiryDataService */],
            __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__["a" /* MessageShowService */]])
    ], CreateCustomCompComponent);
    return CreateCustomCompComponent;
}());

// /* Converts Boolean into Y or N depending on condition for user preview */
// @Pipe({ name: 'booleanConverter' })
// export class BooleanConverter implements PipeTransform {
//   transform(value: any, exponent: any): any {
//     if (value === 'Y' || value) {
//       return "Y";
//     }
//     else if (value === 'N' || value) {
//       return "N";
//     }
//   }
// }


/***/ }),

/***/ "./src/app/components/custom-common/custom-common-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomCommonRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__student_custom_comp_student_custom_comp_component__ = __webpack_require__("./src/app/components/custom-common/student-custom-comp/student-custom-comp.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__custom_common_component__ = __webpack_require__("./src/app/components/custom-common/custom-common.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__create_custom_comp_create_custom_comp_component__ = __webpack_require__("./src/app/components/custom-common/create-custom-comp/create-custom-comp.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var CustomCommonRoutingModule = /** @class */ (function () {
    function CustomCommonRoutingModule() {
    }
    CustomCommonRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_3__custom_common_component__["a" /* CustomCommonComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                component: __WEBPACK_IMPORTED_MODULE_4__create_custom_comp_create_custom_comp_component__["a" /* CreateCustomCompComponent */]
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_4__create_custom_comp_create_custom_comp_component__["a" /* CreateCustomCompComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'customizedOnly',
                                component: __WEBPACK_IMPORTED_MODULE_2__student_custom_comp_student_custom_comp_component__["a" /* StudentCustomComponent */],
                                pathMatch: 'prefix'
                            }
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], CustomCommonRoutingModule);
    return CustomCommonRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/custom-common/custom-common.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/components/custom-common/custom-common.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/custom-common/custom-common.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomCommonComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var CustomCommonComponent = /** @class */ (function () {
    function CustomCommonComponent() {
    }
    CustomCommonComponent.prototype.ngOnInit = function () { };
    CustomCommonComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-custom-common',
            template: __webpack_require__("./src/app/components/custom-common/custom-common.component.html"),
            styles: [__webpack_require__("./src/app/components/custom-common/custom-common.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], CustomCommonComponent);
    return CustomCommonComponent;
}());



/***/ }),

/***/ "./src/app/components/custom-common/custom-common.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomCommonModule", function() { return CustomCommonModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__custom_common_component__ = __webpack_require__("./src/app/components/custom-common/custom-common.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__student_custom_comp_student_custom_comp_component__ = __webpack_require__("./src/app/components/custom-common/student-custom-comp/student-custom-comp.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__custom_common_routing_module__ = __webpack_require__("./src/app/components/custom-common/custom-common-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__create_custom_comp_create_custom_comp_component__ = __webpack_require__("./src/app/components/custom-common/create-custom-comp/create-custom-comp.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__check_box_converter_pipe__ = __webpack_require__("./src/app/components/custom-common/check-box-converter.pipe.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






/* Modules */




var CustomCommonModule = /** @class */ (function () {
    function CustomCommonModule() {
    }
    CustomCommonModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_6__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_6__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_4__custom_common_routing_module__["a" /* CustomCommonRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_7_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_8__shared_shared_module__["a" /* SharedModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_2__custom_common_component__["a" /* CustomCommonComponent */],
                __WEBPACK_IMPORTED_MODULE_5__create_custom_comp_create_custom_comp_component__["a" /* CreateCustomCompComponent */],
                __WEBPACK_IMPORTED_MODULE_3__student_custom_comp_student_custom_comp_component__["a" /* StudentCustomComponent */],
                __WEBPACK_IMPORTED_MODULE_9__check_box_converter_pipe__["a" /* CheckBoxConverterPipe */]
            ],
            entryComponents: [],
            providers: []
        })
    ], CustomCommonModule);
    return CustomCommonModule;
}());



/***/ }),

/***/ "./src/app/components/custom-common/student-custom-comp/student-custom-comp.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"middle-section clearFix\" id=\"enquiryList\">\r\n  <section class=\"middle-top clearFix custom-comp-header\">\r\n\r\n    <div class=\"row\">\r\n      <h1 class=\"pull-left\" style=\"font-size: 14px;padding-top:10px \">\r\n        <a [routerLink]=\"['../home']\">\r\n          <i style=\"font-family: 'FontAwesome'; font-size: 20px;cursor: pointer;\" class=\"fas fa-home\"></i>\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i> Manage Student Form Field\r\n      </h1>\r\n    </div>\r\n\r\n  </section>\r\n\r\n  <section class=\"middle-main clearFix\">\r\n\r\n    <div class=\"row\">\r\n      <div class=\"clearFix add-edit\">\r\n        <a (click)=\"toggleNewComponentVisisbility('Add')\">\r\n          <i id=\"addComponent-icon\" style=\"border:none;\">+</i>\r\n          <span class=\"txt_font\">Add New Form Field</span>\r\n        </a>\r\n      </div>\r\n    </div>\r\n    <div class=\"row\" style=\"margin-top:12px\">\r\n      <div class=\"c-lg-4\">\r\n        <h4>\r\n          <span class=\"txt_font\" style=\"font-weight: 600\">Total Count</span> &nbsp;:&nbsp;{{userCreatedComponent.length}}</h4>\r\n      </div>\r\n      <div class=\"c-lg-8\"></div>\r\n    </div>\r\n\r\n    <!-- Custom Component Table Here -->\r\n    <div class=\"custom-comp-tablewrapper\">\r\n      <div class=\"table-responsive\">\r\n        <table>\r\n          <thead>\r\n            <tr>\r\n              <th>Label</th>\r\n              <th>Type</th>\r\n              <th>Is Required</th>\r\n              <th>Is Searchable</th>\r\n              <th>Sequence</th>\r\n              <th>Max Length</th>\r\n              <th>Default Value</th>\r\n              <th></th>\r\n            </tr>\r\n          </thead>\r\n\r\n          <tbody>\r\n\r\n            <tr *ngFor=\"let comp of userCreatedComponent\">\r\n\r\n              <td>{{comp.label}}</td>\r\n\r\n              <td>{{comp.type|checkBoxConverter}}</td>\r\n\r\n              <td>{{comp.is_required}}</td>\r\n\r\n              <td>{{comp.is_searchable}}</td>\r\n\r\n              <td>{{comp.sequence_number}}</td>\r\n\r\n              <td>{{comp.comp_length}}</td>\r\n\r\n              <td>{{comp.defaultValue}}</td>\r\n\r\n              <td class=\"custom-table-action\">\r\n                <ul>\r\n                  <li>\r\n                    <i class=\"fa fa-pencil\" style=\"color:#1283f4;\" aria-hidden=\"true\" (click)=\"editRow(comp)\"></i>\r\n                  </li>\r\n                  <li>\r\n                    <i class=\"fa fa-trash\" style=\"color:#fa3145;\" aria-hidden=\"true\" (click)=\"deleteRow(comp)\"></i>\r\n                  </li>\r\n                </ul>\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n        </table>\r\n      </div>\r\n    </div>\r\n\r\n  </section>\r\n\r\n  <proctur-popup [sizeWidth]=\"'large'\" *ngIf=\"isEdit=='Add'||isEdit=='Edit'\">\r\n\r\n    <span class=\"closePopup pos-abs fbold show\" (click)=\"cancelRow()\" close-button>\r\n      <svg class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\"\r\n        x=\"0\" y=\"0\">\r\n        <path class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\"\r\n          style=\"fill: currentColor\"></path>\r\n      </svg>\r\n    </span>\r\n\r\n    <h2 popup-header>{{isEdit}} Field</h2>\r\n\r\n    <div class=\"row updatecomponent-wrapper\" popup-content>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.label != ''}\">\r\n          <label for=\"label\">Label\r\n            <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"editCustomComponentForm.label\" name=\"label\">\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.type != '' }\">\r\n          <label for=\"opt.data_value\">Type\r\n            <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <select id=\"opt.data_value\" class=\"form-ctrl\" [(ngModel)]=\"editCustomComponentForm.type\" name=\"opt.data_value\">\r\n            <option value=\"\"></option>\r\n            <option *ngFor=\"let opt of componentShell\" [value]=\"opt.data_key\">\r\n              {{opt.data_value}}\r\n            </option>\r\n          </select>\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.prefilled_data != ''}\">\r\n          <label for=\"prefilledData\">Prefilled Data (Non-Empty And Separated By ,)</label>\r\n          <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"editCustomComponentForm.prefilled_data\" id=\"prefilledData\" name=\"prefilledData\">\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.description != ''}\">\r\n          <label for=\"description\">Description</label>\r\n          <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"editCustomComponentForm.description\" name=\"description\" id=\"description\">\r\n\r\n        </div>\r\n      </div>\r\n\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.is_required != ''}\">\r\n          <label for=\"isrequired\">Is Required</label>\r\n          <select id=\"isrequired\" class=\"form-ctrl\" name=\"isrequired\" [(ngModel)]=\"editCustomComponentForm.is_required\">\r\n            <option value=\"Y\">Yes</option>\r\n            <option value=\"N\" selected>No</option>\r\n          </select>\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.is_searchable != ''}\">\r\n          <label for=\"issearchable\">Is Searchable</label>\r\n          <select id=\"issearchable\" class=\"form-ctrl\" name=\"issearchable\" [(ngModel)]=\"editCustomComponentForm.is_searchable\">\r\n            <option value=\"Y\">Yes</option>\r\n            <option value=\"N\" selected>No</option>\r\n          </select>\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.sequence_number != ''}\">\r\n          <label for=\"sequencenumber\">Sequence (Numerals Only)</label>\r\n          <input type=\"text\" class=\"form-ctrl\" onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" maxlength=\"3\" [(ngModel)]=\"editCustomComponentForm.sequence_number\"\r\n            name=\"sequencenumber\" id=\"sequencenumber\">\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.comp_length != null}\">\r\n          <label for=\"complength\">Max- Length (Numerals Only)</label>\r\n          <input type=\"text\" class=\"form-ctrl\" onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" (ngModelChange)=\"checkValuetype($event)\"\r\n            [(ngModel)]=\"editCustomComponentForm.comp_length\" name=\"complength\" id=\"complength\">\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-4\">\r\n        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editCustomComponentForm.defaultValue != ''}\">\r\n          <label for=\"defVal\">Default Value</label>\r\n          <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"editCustomComponentForm.defaultValue\" name=\"defVal\" id=\"defVal\">\r\n\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n\r\n    <div class=\"\" popup-footer>\r\n      <div class=\"clearfix\">\r\n        <aside class=\"pull-right popup-btn\">\r\n          <input type=\"button\" value=\"Cancel\" class=\"btn txt_font\" (click)=\"cancelRow()\">\r\n          <input type=\"button\" value=\"Update \" *ngIf=\"isEdit=='Edit'\" class=\"fullBlue btn txt_font\" (click)=\"updateRow()\">\r\n          <input type=\"button\" value=\"Add \" *ngIf=\"isEdit=='Add'\" class=\"fullBlue btn txt_font\" (click)=\"addNewCustomComponent()\">\r\n\r\n        </aside>\r\n      </div>\r\n    </div>\r\n\r\n  </proctur-popup>\r\n\r\n  <proctur-popup [sizeWidth]=\"'small'\" *ngIf=\"isDelete\">\r\n\r\n    <span class=\"closePopup pos-abs fbold show\" (click)=\"cancelRow()\" close-button>\r\n      <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n        <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n          <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n            <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n            <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n          </g>\r\n          <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n          />\r\n        </g>\r\n      </svg>\r\n    </span>\r\n\r\n    <h2 popup-header>Delete Field</h2>\r\n\r\n    <div class=\"row delete-wrapper\" popup-content>\r\n      <h5>You are about to delete {{editCustomComponentForm.label}}, kindy confirm your action.</h5>\r\n    </div>\r\n\r\n    <div class=\"\" popup-footer>\r\n      <div class=\"clearfix\">\r\n        <aside class=\"pull-right popup-btn\">\r\n          <input type=\"button\" value=\"Cancel\" class=\"btn txt_font\" (click)=\"cancelRow()\">\r\n          <input type=\"button\" value=\"Confirm\" class=\"fullBlue btn txt_font\" (click)=\"DeleteRowConfirmed()\">\r\n\r\n        </aside>\r\n      </div>\r\n    </div>\r\n  </proctur-popup>\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/components/custom-common/student-custom-comp/student-custom-comp.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.middle-section ::-webkit-scrollbar {\n  display: block;\n  width: 7px;\n  height: 7px; }\n.row {\n  margin: 0 15px; }\n.row.extraMargin {\n  margin: 10px 0 25px; }\n.custom-comp-header .row {\n  margin: 0 15px; }\n.txt_font {\n  font-size: 12px; }\n.add-edit a {\n  cursor: pointer; }\n.add-edit i {\n  border: 1px solid #0084f6;\n  display: inline-block;\n  width: 17px;\n  height: 17px;\n  border-radius: 50%;\n  line-height: 12px;\n  text-align: center;\n  font-size: 22px;\n  vertical-align: middle;\n  margin-right: 4px; }\n.createcomponent-wrapper {\n  padding: 10px 5px;\n  background: #efefef;\n  border: 1px solid #d8d8d8;\n  height: 100%;\n  width: 100%; }\n.createcomponent-wrapper .form-ctrl {\n    background: transparent;\n    border-bottom: solid 1px #cccccc !important; }\n.createcomponent-wrapper .field-wrapper .form-ctrl {\n    display: block;\n    width: 100%;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 10px 0 5px;\n    outline: none;\n    border: 0;\n    height: 36px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 24px; }\n.custom-comp-tablewrapper {\n  margin: 15px;\n  max-height: 70vh;\n  overflow: auto; }\n.custom-comp-tablewrapper ::-webkit-scrollbar {\n    display: block; }\n.custom-comp-tablewrapper table tr {\n    /*checkbox  */ }\n.custom-comp-tablewrapper table tr th {\n      padding: 10px; }\n.custom-comp-tablewrapper table tr td {\n      padding: 5px 10px !important;\n      font-size: 12px; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper {\n      margin-bottom: 0 !important;\n      background: transparent; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox {\n      opacity: 0;\n      position: absolute;\n      left: 0;\n      top: 0;\n      width: 20px;\n      height: 20px;\n      z-index: 1; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox + label {\n      vertical-align: middle;\n      -webkit-transition: all 0s;\n      transition: all 0s;\n      font-size: 10px;\n      display: inline-block; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox + label:after {\n      content: '';\n      width: 16px;\n      height: 16px;\n      border: 2px solid #ccc;\n      border-radius: 2px;\n      position: absolute;\n      left: 0;\n      top: 6px;\n      -webkit-transition: all 0s;\n      transition: all 0s; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox:checked + label:after {\n      border: 2px solid #0084f6; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox + label:before {\n      -webkit-transition: all 0s;\n      transition: all 0s;\n      width: 1px;\n      height: 1px;\n      left: 8px;\n      top: 12px;\n      position: absolute;\n      content: '';\n      border-top: 0;\n      border-right: 0;\n      border-left: 2px solid transparent;\n      border-bottom: 2px solid transparent;\n      -webkit-transform: rotate(-45deg);\n              transform: rotate(-45deg); }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox:checked + label:before {\n      border-left: 2px solid #0084f6;\n      border-bottom: 2px solid #0084f6;\n      width: 10px;\n      height: 4px;\n      left: 4px;\n      top: 12px; }\n.custom-comp-tablewrapper table tr .field-checkbox-wrapper .form-checkbox:checked + label {\n      color: #0084f6; }\n.custom-comp-tablewrapper table tr .field-wrapper {\n      padding: 0 !important; }\n.custom-comp-tablewrapper table tr .field-wrapper .form-ctrl {\n        display: block;\n        -webkit-box-sizing: border-box;\n                box-sizing: border-box;\n        padding: 0 0 0 5px;\n        outline: none;\n        border: 0;\n        height: 26px;\n        -webkit-box-shadow: none;\n                box-shadow: none;\n        border-radius: 0;\n        line-height: 25px;\n        background: transparent;\n        width: 80px;\n        text-align: center;\n        border-bottom: 1px solid #ccc; }\n.custom-comp-tablewrapper table .displayComp .edit-comp {\n    display: none; }\n.custom-comp-tablewrapper table .editComp .view-comp {\n    display: none; }\n.custom-table-action ul li {\n  display: inline-block;\n  margin: 0 5px; }\n.custom-table-action ul li a {\n    cursor: pointer; }\n.updatecomponent-wrapper {\n  padding: 10px 5px;\n  margin: 20px 0;\n  background: #efefef;\n  border-radius: 5px;\n  border: 1px solid #d8d8d8;\n  height: 100%;\n  width: 100%;\n  max-height: 400px;\n  overflow-x: hidden;\n  overflow-y: auto; }\n.updatecomponent-wrapper ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n.updatecomponent-wrapper .form-ctrl {\n    background: transparent;\n    border-bottom: solid 1px #cccccc !important; }\n.updatecomponent-wrapper .field-wrapper .form-ctrl {\n    display: block;\n    width: 100%;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 10px 0 5px;\n    outline: none;\n    border: 0;\n    height: 36px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 24px; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.delete-wrapper {\n  padding: 20px 15px;\n  margin: 10px 0;\n  background: #efefef; }\n.middle-main clearFix .middle {\n  font-size: 30px;\n  margin-left: 25px;\n  margin-top: 10px;\n  font-weight: 600px !important; }\n"

/***/ }),

/***/ "./src/app/components/custom-common/student-custom-comp/student-custom-comp.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return StudentCustomComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_fetchprefilldata_service__ = __webpack_require__("./src/app/services/fetchprefilldata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_enquiry_services_post_enquiry_data_service__ = __webpack_require__("./src/app/services/enquiry-services/post-enquiry-data.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




/**  custome fields changes
 * updated by laxmi wapte
 */
var StudentCustomComponent = /** @class */ (function () {
    function StudentCustomComponent(prefill, postdata, msgService) {
        this.prefill = prefill;
        this.postdata = postdata;
        this.msgService = msgService;
        this.componentShell = [];
        this.userCreatedComponent = [];
        this.isDelete = false;
        this.isRippleLoad = false;
        this.isEdit = '';
        this.editCustomComponentForm = {
            comp_length: "",
            description: "",
            institution_id: sessionStorage.getItem('institute_id'),
            is_required: "N",
            is_searchable: "N",
            label: "",
            page: 2,
            prefilled_data: "",
            sequence_number: "",
            type: "",
            defaultValue: ""
        };
    }
    StudentCustomComponent.prototype.ngOnInit = function () {
        this.fetchPrefillData();
    };
    /* fetches list of user created component and the default type */
    StudentCustomComponent.prototype.fetchPrefillData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.prefill.fetchComponentGenerator().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.componentShell = res;
        }, function (err) {
            _this.isRippleLoad = false;
        });
        this.isRippleLoad = true;
        return this.prefill.fetchUserCreatedComponentStudent().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.userCreatedComponent = res;
        }, function (err) {
            _this.isRippleLoad = false;
        });
    };
    /* toggle the visibility of the the new component created */
    StudentCustomComponent.prototype.toggleNewComponentVisisbility = function (type) {
        this.isEdit = type;
        this.emptyObject();
    };
    StudentCustomComponent.prototype.addNewCustomComponent = function () {
        var _this = this;
        //Case 1 Label/Type is not empty and MaxLength and Sequence
        if (this.editCustomComponentForm.label != "" && this.editCustomComponentForm.label != " "
            && this.editCustomComponentForm.type != "") {
            //Case 2 if its a select or multiselect dropdown list cannot be empty or duplicate
            if (this.editCustomComponentForm.type == "3" || this.editCustomComponentForm.type == "4") {
                /* Validate Prefilled Data */
                if (this.validateDropDown(this.editCustomComponentForm.prefilled_data)) {
                    if (this.validateDropdownDefvalue(this.editCustomComponentForm.prefilled_data, this.editCustomComponentForm.defaultValue)) {
                        this.isRippleLoad = true;
                        this.postdata.addNewCustomComponent(this.editCustomComponentForm).subscribe(function (res) {
                            _this.isRippleLoad = false;
                            _this.msgService.showErrorMessage('success', '', 'Form-Field  Updated Successfully');
                            _this.cancelEditRow();
                        }, function (err) {
                            _this.isRippleLoad = false;
                            _this.msgService.showErrorMessage('error', '', 'Label name is already created with the same name');
                        });
                    }
                    else {
                        this.msgService.showErrorMessage('error', '', 'dropdown default value should be present in prefilled data');
                    }
                }
                else {
                    this.msgService.showErrorMessage('error', '', 'Prefill data has to be unique and non-empty');
                }
            }
            else if (this.editCustomComponentForm.type == "5") {
                /* Date cannot be searchable and does not a default value */
                if (this.editCustomComponentForm.is_searchable == "N" && this.editCustomComponentForm.defaultValue.trim() == "") {
                    this.isRippleLoad = true;
                    this.postdata.addNewCustomComponent(this.editCustomComponentForm).subscribe(function (res) {
                        _this.isRippleLoad = false;
                        _this.msgService.showErrorMessage('success', '', 'Form-Field Updated Successfully');
                        _this.fetchPrefillData();
                    }, function (err) {
                        _this.isRippleLoad = false;
                        _this.msgService.showErrorMessage('error', '', 'There was an error processing your request' + err.error.message);
                    });
                }
                else {
                    this.msgService.showErrorMessage('error', 'Date Field Cannot Be Searchable Or have any default value', '');
                }
            }
            else if (this.editCustomComponentForm.type != "3" && this.editCustomComponentForm.type != "4" && this.editCustomComponentForm.type != "5") {
                this.isRippleLoad = true;
                this.postdata.addNewCustomComponent(this.editCustomComponentForm).subscribe(function (res) {
                    _this.isRippleLoad = false;
                    _this.msgService.showErrorMessage('success', 'Form-Field Updated Successfully', '');
                    _this.cancelEditRow();
                }, function (err) {
                    _this.isRippleLoad = false;
                    _this.msgService.showErrorMessage('error', '', 'Label name is already created with the same name');
                });
            }
        }
        else {
            this.msgService.showErrorMessage('error', '', 'Please mention a Label/Type');
        }
    };
    StudentCustomComponent.prototype.isDefaultEmpty = function (obj) {
        if (obj.defaultValue) {
            return true;
        }
    };
    StudentCustomComponent.prototype.validateDropDown = function (data) {
        var arr = data.split(',');
        /* boolean for non empty value */
        var test1 = arr.every(function checkNonEmpty(el) {
            return (el != "" && el != " ");
        });
        /* convert array to set unique value */
        this.editCustomComponentForm.prefilled_data = Array.from(new Set(arr)).join(',');
        return test1;
    };
    StudentCustomComponent.prototype.validateDropdownDefvalue = function (tocheck, tomatch) {
        var arr = tocheck.split(',');
        for (var i = 0; i < arr.length; i++) {
            if (tomatch === arr[i].trim()) {
                return true;
            }
        }
        return false;
    };
    StudentCustomComponent.prototype.validateDropDownUpdate = function (data) {
        var arr = data.split(',');
        /* boolean for non empty value */
        var test1 = arr.every(function checkNonEmpty(el) {
            return (el != "" && el != " ");
        });
        /* convert array to set unique value */
        return test1;
    };
    StudentCustomComponent.prototype.editRow = function (data) {
        this.editCustomComponentForm = data;
        this.isEdit = 'Edit';
    };
    StudentCustomComponent.prototype.cancelEditRow = function () {
        this.emptyObject();
        this.fetchPrefillData();
        this.isEdit = '';
    };
    StudentCustomComponent.prototype.updateRow = function () {
        var _this = this;
        var data = this.editCustomComponentForm;
        //Case 1 Label/Type is not empty and MaxLength and Sequence
        if (data.label.trim() != "" && data.type != "") {
            //Case 2 if its a select or multiselect dropdown list cannot be empty or duplicate
            if (data.type == "3" || data.type == "4") {
                /* Validate Prefilled Data */
                if (this.validateDropDown(data.prefilled_data)) {
                    if (this.validateDropdownDefvalue(data.prefilled_data, data.defaultValue)) {
                        this.postdata.updateCustomComponent(data).subscribe(function (res) {
                            _this.msgService.showErrorMessage('success', 'Form-Field Updated', '');
                            _this.cancelEditRow();
                        }, function (err) {
                            _this.msgService.showErrorMessage('error', '', err.error.message);
                        });
                    }
                    else {
                        this.msgService.showErrorMessage('error', 'dropdown default value should be present in prefilled data', '');
                    }
                }
                else {
                    this.msgService.showErrorMessage('error', 'Prefill data has to be unique and non-empty', '');
                }
            }
            else if (data.type == "5") {
                /* Date cannot be searchable and does not a default value */
                if (data.is_searchable == "N" && data.defaultValue.trim() == "") {
                    this.postdata.updateCustomComponent(data).subscribe(function (res) {
                        _this.msgService.showErrorMessage('success', 'Form-Field Updated Successfully', '');
                        _this.cancelEditRow();
                    }, function (err) {
                        _this.msgService.showErrorMessage('error', '', err.error.message);
                    });
                }
                else {
                    this.msgService.showErrorMessage('error', 'Date Field Cannot Be Searchable Or have any default value', '');
                }
            }
            else if (data.type != "3" && data.type != "4" && data.type != "5") {
                this.isRippleLoad = true;
                this.postdata.updateCustomComponent(data).subscribe(function (res) {
                    _this.isRippleLoad = false;
                    _this.msgService.showErrorMessage('success', 'Form-Field Updated', '');
                    _this.cancelEditRow();
                }, function (err) {
                    _this.isRippleLoad = false;
                    _this.msgService.showErrorMessage('error', '', err.error.message);
                });
            }
        }
        else {
            this.msgService.showErrorMessage('error', '', 'Please mention a Label/Type');
        }
    };
    StudentCustomComponent.prototype.emptyObject = function () {
        this.editCustomComponentForm = {
            comp_length: "",
            description: "",
            institution_id: sessionStorage.getItem('institute_id'),
            is_required: "N",
            is_searchable: "N",
            label: "",
            page: 2,
            prefilled_data: "",
            sequence_number: "",
            type: "",
            defaultValue: ""
        };
    };
    //this function set default max length  50 when type is textbox
    StudentCustomComponent.prototype.checkValuetype = function (value) {
        this.editCustomComponentForm.comp_length = value == 1 ? 50 : 0;
    };
    StudentCustomComponent.prototype.deleteRow = function (data) {
        this.editCustomComponentForm = data;
        this.isDelete = true;
    };
    StudentCustomComponent.prototype.cancelRow = function () {
        this.isDelete = false;
        this.isEdit = '';
        this.emptyObject();
    };
    StudentCustomComponent.prototype.DeleteRowConfirmed = function () {
        var _this = this;
        var data = this.editCustomComponentForm;
        this.isRippleLoad = true;
        this.postdata.deleteCustomComponent(data.component_id).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.isDelete = false;
            _this.msgService.showErrorMessage('success', 'Form-field Deleted', 'requested form-field deleted successfully');
            _this.cancelEditRow();
        }, function (err) {
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage('error', '', err.error.message);
            _this.cancelRow();
        });
    };
    StudentCustomComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'student-custom-comp',
            template: __webpack_require__("./src/app/components/custom-common/student-custom-comp/student-custom-comp.component.html"),
            styles: [__webpack_require__("./src/app/components/custom-common/student-custom-comp/student-custom-comp.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_fetchprefilldata_service__["a" /* FetchprefilldataService */],
            __WEBPACK_IMPORTED_MODULE_2__services_enquiry_services_post_enquiry_data_service__["a" /* PostEnquiryDataService */],
            __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__["a" /* MessageShowService */]])
    ], StudentCustomComponent);
    return StudentCustomComponent;
}());



/***/ })

});
//# sourceMappingURL=custom-common.module.chunk.js.map