webpackJsonp(["enquiry.module"],{

/***/ "./src/app/components/leads/enquiry/enquiry-bulkadd/enquiry-bulkadd.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"middle-section clearFix\" id=\"enquiryList\">\r\n\r\n  <section class=\"middle-top clearFix bulk-header\">\r\n\r\n    <div class=\"row\">\r\n      <h1 class=\"pull-left\">\r\n        <a routerLink=\"/view/leads\" style=\"padding:0px; \">\r\n          Lead\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n        <a routerLink=\"/view/leads/enquiry\" style=\"padding:0px; \">\r\n          Enquiry\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n        Upload Enquiry\r\n      </h1>\r\n      <aside class=\"pull-right\">\r\n        <input type=\"button\" value=\"Upload Status Report\" (click)=\"bulkStatusReporter()\" class=\"btn\" />\r\n        <a id=\"template_link\">\r\n          <input type=\"button\" value=\"Download Template\" class=\"btn\" (click)=\"downloadTemplate()\" id=\"btnDownloadTemplate\" />\r\n        </a>\r\n        <input type=\"button\" value=\"Add Enquiry\" routerLink='/view/leads/enquiry/add' class=\"btn\" id=\"btnAddEnquiry\" />\r\n      </aside>\r\n    </div>\r\n\r\n  </section>\r\n\r\n\r\n\r\n  <!--====================================middle <Main> section==========================-->\r\n  <section class=\"middle-main clearFix\" id=\"bulkEnquiryMain\">\r\n    <div class=\"file-upload-box\">\r\n      <div class=\"select-file-upload\">\r\n        <h5>Select a file to upload</h5>\r\n        <div class=\"file-wrapper\">\r\n          <ul>\r\n            <li>\r\n              <!-- accept=\"application/vnd.ms-excel\" -->\r\n              <p-fileUpload\r\n                customUpload=\"true\" (uploadHandler)=\"uploadHandler($event)\" [showCancelButton]=\"false\">\r\n              </p-fileUpload>\r\n\r\n              <div class=\"uploadProcessAndFileName clearfix\" *ngIf=\"isUploadingXls\">\r\n                <div class=\"file-uploaded\">\r\n                  {{fileLoading}}\r\n                </div>\r\n                <div class=\"progress-bar-wrapper\">\r\n                  <div class=\"upload-bar\">\r\n                    <div id=\"progress-width\"></div>\r\n                  </div>\r\n                  <span>{{progress}} %</span>\r\n                </div>\r\n              </div>\r\n            </li>\r\n          </ul>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </section>\r\n\r\n\r\n\r\n\r\n\r\n  <!-- ================================================================================= -->\r\n  <!-- ========================= Bulk Update Status =================================== -->\r\n  <enquiry-pop-up [hidden]=\"!isBulkUploadStatus\">\r\n\r\n    <span class=\"closePopup pos-abs fbold \" id=\"popupCloseBtn\" (click)=\"closeBulkStatus()\" close-button>\r\n      <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n        <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" style=\"fill: currentColor\"></path>\r\n      </svg>\r\n    </span>\r\n\r\n    <h2 id=\"bulk-head\" popup-header>Upload Enquiry Status</h2>\r\n\r\n    <div class=\"bulk-enquiry-form\" popup-content>\r\n\r\n      <div class=\"row\">\r\n        <div class=\"table-responsive bulk-update-report\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>File Name</th>\r\n                <th>Upload Date</th>\r\n                <th>Total Count</th>\r\n                <th>Success Count</th>\r\n                <th>Failure Count</th>\r\n                <th *ngIf=\"downloadEnquiryReportAccess\">Action</th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr *ngFor = \"let record of bulkUploadRecords\">\r\n                <td>{{record.list_name}}</td>\r\n                <td>{{record.created_date}}</td>\r\n                <td>{{record.total_count}}</td>\r\n                <td>{{record.success_count}}</td>\r\n                <td>{{record.failure_count}}</td>\r\n                <td *ngIf=\"downloadEnquiryReportAccess\">\r\n                  <a *ngIf=\"record.failure_count != 0\" [id]=\"record.list_id\" class=\"download-icon\" (click)=\"downloadBulkStatusReport(record)\" id=\"generateAnch5\">\r\n                    Generate Report\r\n                  </a>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n\r\n  </enquiry-pop-up>\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-bulkadd/enquiry-bulkadd.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.bulk-update-report {\n  max-height: 400px !important;\n  overflow-y: scroll !important;\n  overflow-x: hidden !important;\n  max-width: 98% !important; }\n#bulk-head {\n  padding-top: 20px; }\n.bulk-enquiry-form {\n  padding-top: 30px; }\n.bulk-enquiry-form table thead tr {\n    line-height: 25px; }\n.bulk-enquiry-form table tbody tr {\n    line-height: 20px; }\n.bulk-enquiry-form table tbody tr td {\n      text-overflow: ellipsis; }\n.bulk-enquiry-form table tbody tr td .download-icon {\n        cursor: pointer; }\n.bulk-enquiry-form table tbody tr td .download-icon::after {\n          content: \"\\f0ed\";\n          font-family: FontAwesome; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: block; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.bulk-header .row {\n  margin: 0px 15px; }\n.file-upload-box {\n  padding: 35px 20px;\n  max-width: 70%; }\n.file-upload-box h5 {\n    font-weight: 600;\n    margin-bottom: 30px;\n    font-size: 15px; }\n.file-upload-box .select-file-upload ul li label {\n    display: block;\n    font-size: 15px;\n    margin-bottom: 10px; }\n.file-upload-box .select-file-upload ul li .choose-file {\n    position: relative;\n    margin-bottom: 15px; }\n.file-upload-box .select-file-upload ul li .choose-file input[type=\"file\"] {\n      opacity: 0;\n      z-index: 1;\n      position: absolute;\n      width: 100%;\n      height: 100%;\n      left: 0;\n      top: 0;\n      cursor: pointer; }\n.file-upload-box .select-file-upload ul li .choose-file input[type=\"text\"] {\n      height: 34px;\n      border: 1px solid #ccc;\n      width: 77%;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      padding: 5px 10px;\n      font-size: 14px; }\n.file-upload-box .select-file-upload ul li .choose-file .btn {\n      width: 21%;\n      float: right;\n      margin: 0; }\n.file-upload-box .drag-drop-box {\n    margin-top: 50px; }\n.file-upload-box .drag-drop-box .dropable-area {\n      width: 100%;\n      border: 1px solid #ccc;\n      height: 150px;\n      cursor: pointer;\n      text-align: center;\n      line-height: 150px;\n      font-size: 16px;\n      margin-bottom: 10px; }\n.file-upload-box .file-uploaded {\n    margin: 25px 0 30px;\n    font-weight: 600;\n    font-size: 16px; }\n.file-upload-box .file-uploaded span {\n      display: inline-block;\n      vertical-align: middle;\n      cursor: pointer; }\n.file-upload-box .file-uploaded span svg {\n        margin-right: 10px;\n        width: 15px; }\n.file-upload-box .file-uploaded span svg .cls-1 {\n          stroke: #888;\n          stroke-width: 2; }\n.file-upload-box .file-uploaded span svg:hover .cls-1 {\n          stroke: #0084f6; }\n.progress-bar-wrapper {\n  float: left;\n  width: 80%; }\n.upload-bar {\n  position: relative;\n  height: 8px;\n  width: 100%;\n  background: #ccc;\n  border-radius: 0;\n  overflow: hidden;\n  margin: 10px 0 5px; }\n.upload-bar > div {\n    position: absolute;\n    height: 100%;\n    width: 0%;\n    left: 0;\n    background: blue;\n    top: 0;\n    border-radius: 0;\n    -webkit-transition: all 0.5s ease;\n    transition: all 0.5s ease; }\n.cancel-upload {\n  float: right;\n  cursor: pointer;\n  margin: 4px 0 0 0px; }\n.upload-another {\n  margin: 15px 0px; }\n.file-wrapper {\n  padding-left: 35px; }\n::ng-deep .ui-fileupload {\n  width: 100%;\n  cursor: pointer; }\n::ng-deep .ui-fileupload-buttonbar {\n  background: #0060A3;\n  width: 70vw; }\n::ng-deep .ui-fileupload-content {\n  min-height: 200px;\n  width: 70vw;\n  padding: 5px;\n  border-top: none;\n  border-right: 3px dashed #eaeaeb;\n  border-bottom: 3px dashed #eaeaeb;\n  border-left: 3px dashed #eaeaeb;\n  cursor: pointer; }\n::ng-deep .ui-fileupload-content::after {\n    content: \"Drag & Drop Files Here\";\n    color: rgba(0, 0, 0, 0.09);\n    position: absolute;\n    top: 35%;\n    left: 25%;\n    font-size: 36px; }\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-bulkadd/enquiry-bulkadd.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EnquiryBulkaddComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_enquiry_services_fetchenquiry_service__ = __webpack_require__("./src/app/services/enquiry-services/fetchenquiry.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_enquiry_services_post_enquiry_data_service__ = __webpack_require__("./src/app/services/enquiry-services/post-enquiry-data.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_login_services_login_service__ = __webpack_require__("./src/app/services/login-services/login.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_fetchprefilldata_service__ = __webpack_require__("./src/app/services/fetchprefilldata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var EnquiryBulkaddComponent = /** @class */ (function () {
    function EnquiryBulkaddComponent(fetchData, postData, appC, router, prefill, login, auth, _commService) {
        this.fetchData = fetchData;
        this.postData = postData;
        this.appC = appC;
        this.router = router;
        this.prefill = prefill;
        this.login = login;
        this.auth = auth;
        this._commService = _commService;
        this.isCancelUpload = false;
        this.isUploadingXls = false;
        this.progress = 0;
        this.fileLoading = "";
        this.isBulkUploadStatus = false;
        this.downloadEnquiryReportAccess = false;
        if (sessionStorage.getItem('userid') == null) {
            this.router.navigate(['/authPage']);
        }
    }
    EnquiryBulkaddComponent.prototype.ngOnInit = function () {
        this.fetchBulkUploadStatusData();
        this.checkRoleAccess();
    };
    EnquiryBulkaddComponent.prototype.checkRoleAccess = function () {
        if (sessionStorage.getItem('downloadEnquiryReportAccess') == 'true') {
            this.downloadEnquiryReportAccess = true;
        }
    };
    /* base64 data to be converted to xls file */
    EnquiryBulkaddComponent.prototype.downloadTemplate = function () {
        var _this = this;
        this.fetchData.fetchDownloadTemplate().subscribe(function (res) {
            var byteArr = _this._commService.convertBase64ToArray(res.document);
            var format = res.format;
            var fileName = res.docTitle;
            var file = new Blob([byteArr], { type: 'text/csv;charset=utf-8;' });
            var url = URL.createObjectURL(file);
            var dwldLink = document.getElementById('template_link');
            dwldLink.setAttribute("href", url);
            dwldLink.setAttribute("download", fileName);
            dwldLink.click();
        }, function (err) {
        });
    };
    /* update xhr header for uploading formdata */
    EnquiryBulkaddComponent.prototype.updateXlsHeaders = function (ev) {
        ev.xhr.setRequestHeader("processData", "false");
        ev.xhr.setRequestHeader("contentType", "false");
        ev.xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
        ev.xhr.setRequestHeader("enctype", "multipart/form-data");
        ev.xhr.setRequestHeader("Authorization", sessionStorage.getItem("Authorization"));
    };
    /* function to upload the xls file as formdata */
    EnquiryBulkaddComponent.prototype.uploadHandler = function (event) {
        var _this = this;
        var _loop_1 = function (file) {
            var formdata = new FormData();
            formdata.append("file", file);
            var base = this_1.auth.getBaseUrl();
            var urlPostXlsDocument = base + "/api/v2/enquiry_manager/bulkUploadEnquiries";
            var xhr = new XMLHttpRequest();
            xhr.open("POST", urlPostXlsDocument, true);
            xhr.setRequestHeader("processData", "false");
            xhr.setRequestHeader("contentType", "false");
            xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
            xhr.setRequestHeader("enctype", "multipart/form-data");
            var auths = {
                userid: sessionStorage.getItem('userid'),
                userType: sessionStorage.getItem('userType'),
                password: sessionStorage.getItem('password'),
                institution_id: sessionStorage.getItem('institute_id'),
            };
            var Authorization = btoa(auths.userid + "|" + auths.userType + ":" + auths.password + ":" + auths.institution_id);
            xhr.setRequestHeader("Authorization", Authorization);
            this_1.isUploadingXls = true;
            xhr.upload.addEventListener('progress', function (e) {
                if (e.lengthComputable) {
                    _this.progress = Math.round((e.loaded * 100) / e.total);
                    document.getElementById('progress-width').style.width = _this.progress + '%';
                    _this.fileLoading = file.name;
                }
            }, false);
            //Call function when onload.
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4) {
                    _this.progress = 0;
                    if (xhr.status >= 200 && xhr.status < 300) {
                        _this.isUploadingXls = false;
                        var data = {
                            type: 'success',
                            title: "",
                            body: xhr.response.fileName
                        };
                        _this.appC.popToast(data);
                        _this.fetchBulkUploadStatusData();
                    }
                    else {
                        _this.isUploadingXls = false;
                        var data = {
                            type: 'error',
                            title: "File couldn\'t be uploaded",
                            body: xhr.response.fileName
                        };
                        _this.appC.popToast(data);
                    }
                }
            };
            xhr.send(formdata);
        };
        var this_1 = this;
        for (var _i = 0, _a = event.files; _i < _a.length; _i++) {
            var file = _a[_i];
            _loop_1(file);
        }
        event.files = [];
    };
    /* fetch the status of the data updated to server */
    EnquiryBulkaddComponent.prototype.fetchBulkUploadStatusData = function () {
        var _this = this;
        return this.prefill.fetchBulkUpdateStatusReport().subscribe(function (res) {
            _this.bulkUploadRecords = res;
        });
    };
    /* toggle visibility of tabular displayy of bulk data upload */
    EnquiryBulkaddComponent.prototype.bulkStatusReporter = function () {
        this.fetchBulkUploadStatusData();
        this.isBulkUploadStatus = true;
    };
    /* toggle visibility of tabular displayy of bulk data upload */
    EnquiryBulkaddComponent.prototype.closeBulkStatus = function () {
        this.isBulkUploadStatus = false;
    };
    /* download the xls status report for a particular file uploaded */
    EnquiryBulkaddComponent.prototype.downloadBulkStatusReport = function (el) {
        var _this = this;
        var fileId = el.list_id.toString();
        var dwldLink = document.getElementById(fileId);
        this.fetchData.fetchBulkReport(el.list_id).subscribe(function (res) {
            var byteArr = _this._commService.convertBase64ToArray(res.document);
            var format = res.format;
            var fileName = res.docTitle;
            var file = new Blob([byteArr], { type: 'text/csv;charset=utf-8;' });
            var url = URL.createObjectURL(file);
            if (dwldLink.getAttribute('href') == "" || dwldLink.getAttribute('href') == null) {
                dwldLink.setAttribute("href", url);
                dwldLink.setAttribute("download", fileName);
                dwldLink.click();
            }
        }, function (err) {
            var obj = {
                type: "error",
                title: "error downloading file",
                body: ""
            };
            _this.appC.popToast(obj);
        });
    };
    EnquiryBulkaddComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-enquiry-bulkadd',
            template: __webpack_require__("./src/app/components/leads/enquiry/enquiry-bulkadd/enquiry-bulkadd.component.html"),
            styles: [__webpack_require__("./src/app/components/leads/enquiry/enquiry-bulkadd/enquiry-bulkadd.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_3__services_enquiry_services_fetchenquiry_service__["a" /* FetchenquiryService */],
            __WEBPACK_IMPORTED_MODULE_4__services_enquiry_services_post_enquiry_data_service__["a" /* PostEnquiryDataService */],
            __WEBPACK_IMPORTED_MODULE_1__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_2__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_6__services_fetchprefilldata_service__["a" /* FetchprefilldataService */],
            __WEBPACK_IMPORTED_MODULE_5__services_login_services_login_service__["a" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_7__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_8__services_common_service__["a" /* CommonServiceFactory */]])
    ], EnquiryBulkaddComponent);
    return EnquiryBulkaddComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-edit/enquiry-edit.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\"\r\n  *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<section class=\"homewrap middle-section clearFix\">\r\n  <form  class=\"scroll-content\" #myForm=\"ngForm\">\r\n    <!-- Left Side Form -->\r\n    <aside class=\"pull-left middle-left \" id=\"addNewEnquiry\">\r\n      <!-- Header -->\r\n      <section class=\"middle-top clearFix\">\r\n        <div class=\"row\">\r\n          <h1 class=\"pull-left\">\r\n            Edit Enquiry\r\n          </h1>\r\n          <aside class=\"pull-right\">\r\n\r\n          </aside>\r\n        </div>\r\n      </section>\r\n\r\n      <!-- Accordian Menu Element -->\r\n      <section class=\"middle-main clearFix\" id=\"middleMain\">\r\n        <div class=\"add-new-enquiry-form accordian-section\">\r\n          <ul class=\"accordian\">\r\n            <!-- Basic Form -->\r\n            <li class=\"active data-filled\" id=\"basicDetails\">\r\n              <!-- Accordian Toggler -->\r\n              <div class=\"accordian-heading\">\r\n                <h4>\r\n                  <span class=\"circle-accor\">1</span> Basic Details\r\n                  <span class=\"open-accor\" id=\"openBasic\" (click)=\"toggleForm($event)\">+</span>\r\n                  <span class=\"close-accor\" id=\"closeBasic\" (click)=\"toggleForm($event)\">-</span>\r\n                </h4>\r\n              </div>\r\n              <! -- Accordian Form 1 -->\r\n                <div class=\"accordian-content\">\r\n                  <div class=\"form-type1\">\r\n\r\n                    <!-- Name -->\r\n                    <div class=\"field-wrapper \" [ngClass]=\"{'has-value': editEnqData.name != ''}\">\r\n                      <label for=\"name\">Name\r\n                        <span class=\"text-danger\">*</span>\r\n                      </label>\r\n                      <input type=\"text\" value=\"\" id=\"name\" #name=\"ngModel\" class=\"form-ctrl\"\r\n                        [(ngModel)]=\"editEnqData.name\" name=\"name\" maxlength=\"50\" required />\r\n\r\n                      <div *ngIf=\"name.invalid && (name.dirty || name.touched)\" class=\"alert invalid-alert\">\r\n                        <div *ngIf=\"name.errors.required\">\r\n                          name is required.\r\n                        </div>\r\n                        <!-- <div *ngIf=\"name.errors.pattern\">\r\n                        Only Alphabets . - Allowed.    pattern=\"^([a-zA-Z .-]){1,30}$\"\r\n                      </div> -->\r\n                      </div>\r\n                    </div>\r\n\r\n                    <!-- Phone -->\r\n                    <div class=\"field-wrapper \" [ngClass]=\"{'has-value': editEnqData.phone != ''}\">\r\n                      <label for=\"phone\">Phone No</label><br>\r\n                      <span class=\"countryCallingCode\"style=\"width: 22%\">\r\n                        <select id=\"country_id\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.country_id\" name=\"country_id\"\r\n                          [disabled]=\"countryDetails.length<=1\" (change)=\"onChangeObj($event.target.value)\"\r\n                          style=\"height: 29px;padding: 0\">\r\n                          <option value=\"\"></option>\r\n                          <option [value]=\"data.id\" selected *ngFor='let data of countryDetails'>\r\n                            {{data.country_code}} +{{data.country_calling_code}}\r\n                          </option>\r\n                        </select>\r\n                      </span>\r\n                      <input type=\"text\" value=\"\" id=\"phone\" #phone=\"ngModel\" class=\"form-ctrl\"\r\n                        [(ngModel)]=\"editEnqData.phone\" name=\"phone\"\r\n                        onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\"\r\n                        style=\"width: 78%\" />\r\n                    </div>\r\n\r\n                    <!-- Email -->\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"email\">Email ID</label>\r\n                      <input type=\"text\" value=\"\" id=\"email\" #email=\"ngModel\" class=\"form-ctrl\"\r\n                        [(ngModel)]=\"editEnqData.email\" name=\"email\"\r\n                        pattern=\"[a-zA-Z0-9._%+-]+@[a-zA-Z]+\\.[a-zA-Z.]{2,5}$\" />\r\n                      <div *ngIf=\"email.invalid && (email.dirty || email.touched)\" class=\"alert invalid-alert\">\r\n                        <div *ngIf=\"email.errors.pattern\">\r\n                          Enter email in format eg. someone@xyz.com\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n\r\n                    <!-- Gender -->\r\n                    <div class=\"field-wrapper \" [ngClass]=\"{'has-value': editEnqData.gender != ''}\">\r\n                      <label for=\"gender\">Gender</label>\r\n                      <select class=\"form-ctrl\" [(ngModel)]=\"editEnqData.gender\" name=\"gender\" id=\"gender\">\r\n                        <option value=\"\"></option>\r\n                        <option value=\"M\">Male</option>\r\n                        <option value=\"F\">Female</option>\r\n                        <option value=\"NA\">NA</option>\r\n                      </select>\r\n                    </div>\r\n\r\n                    <!-- Date of Birth -->\r\n                    <div class=\"field-wrapper datePickerBox\" [ngClass]=\"{'has-value': editEnqData.dob != ''}\">\r\n                      <label for=\"dob\">Date of Birth</label>\r\n                      <input type=\"text\" value=\"\" id=\"dob\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"editEnqData.dob\"\r\n                        name=\"dob\" readonly='true' bsDatepicker>\r\n                      <span class=\"date-clear\" name=\"dob\" (click)=\"editEnqData.dob = ''\">clear</span>\r\n                    </div>\r\n\r\n                    <!-- city -->\r\n                    <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editEnqData.city != ''}\">\r\n                      <label for=\"cityDdn\">City\r\n                        <span class=\"text-danger\" *ngIf=\"isCityMandatory == 1\">*</span>\r\n                      </label>\r\n                      <select id=\"cityDdn\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.city\"\r\n                        (ngModelChange)=\"onCitySelctionChanges($event)\" name=\"city\">\r\n                        <option value=\"-1\"></option>\r\n                        <option *ngFor=\"let city of cityListDataSource\" [value]=\"city.city\">{{city.city}}</option>\r\n                      </select>\r\n                    </div>\r\n\r\n                    <!-- area -->\r\n                    <div class=\"field-wrapper\" [ngClass]=\"{'has-value': editEnqData.area != ''}\">\r\n                      <label for=\"areaDdn\">Area\r\n                      </label>\r\n                      <select id=\"areaDdn\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.area\" name=\"area\">\r\n                        <option value=\"-1\"></option>\r\n                        <option *ngFor=\"let area of areaListDataSource\" [value]=\"area.area\">{{area.area}}</option>\r\n                      </select>\r\n\r\n                    </div>\r\n\r\n                    <!-- Source -->\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"source\">Source<span class=\"text-danger\">*</span></label>\r\n                      <select id=\"source\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.source_id\" name=\"source\">\r\n                        <option value=\"-1\"></option>\r\n                        <option *ngFor=\"let source of sourceLead\" [value]=\"source.id\">{{source.name}}</option>\r\n                      </select>\r\n\r\n                    </div>\r\n\r\n                    <!-- Additonal details -->\r\n                    <div class=\"more-detail\">\r\n                      <b>\r\n                        <a *ngIf=\"!additionDetails\" (click)=\"showAdditionDetails()\"\r\n                          style=\"font-size: 14px;font-weight: 600;cursor:pointer\" id=\"additionAnch2\">+ &nbsp; Add\r\n                          Additional Details</a>\r\n                        <a *ngIf=\"additionDetails\" (click)=\"showAdditionDetails()\"\r\n                          style=\"font-size: 14px;font-weight: 600;cursor:pointer\" id=\"additionAnch3\">- &nbsp; Add\r\n                          Additional Details</a>\r\n                      </b>\r\n                    </div>\r\n\r\n                  </div>\r\n\r\n                  <div class=\"form-type1\" *ngIf=\"additionDetails\">\r\n                    <br>\r\n\r\n                    <!-- Address -->\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"userAddress\">Address</label>\r\n                      <input type=\"text\" value=\"\" id=\"userAddress\" class=\"form-ctrl\"\r\n                        [(ngModel)]=\"editEnqData.curr_address\" name=\"address\" />\r\n                    </div>\r\n\r\n                    <!-- Phone -->\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"phone2\">Alternate Contact</label><br>\r\n                      <span class=\"countryCallingCode\"style=\"width: 22%\">\r\n                         <select id=\"country_id\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.country_id\" name=\"country_id\"\r\n                          [disabled]=\"countryDetails.length<=1\" (change)=\"onChangeObj($event.target.value)\"\r\n                          style=\"height: 29px;padding: 0\">\r\n                          <option value=\"\"></option>\r\n                          <option [value]=\"data.id\" selected *ngFor='let data of countryDetails'>\r\n                            {{data.country_code}} +{{data.country_calling_code}}\r\n                          </option>\r\n                        </select>\r\n                      </span>\r\n                      <input type=\"text\" value=\"\" id=\"phone2\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.phone2\"\r\n                        name=\"phone2\" \r\n                        style=\"width: 78%\"\r\n                        onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" />\r\n                    </div>\r\n\r\n                    <!-- Email -->\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"email2\">Alternate Email ID</label>\r\n                      <input type=\"text\" value=\"\" id=\"email2\" #email2=\"ngModel\" class=\"form-ctrl\"\r\n                        [(ngModel)]=\"editEnqData.email2\" name=\"email2\"\r\n                        pattern=\"[a-zA-Z0-9._%+-]+@[a-zA-Z]+\\.[a-zA-Z.]{2,5}$\" />\r\n\r\n                      <div *ngIf=\"email2.invalid && (email2.dirty || email2.touched)\" class=\"alert invalid-alert\">\r\n                        <div *ngIf=\"email2.errors.pattern\">\r\n                          Enter email in format eg. someone@xyz.com\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n\r\n                    <!-- Name -->\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"guardianName\">Parent Name</label>\r\n                      <input type=\"text\" value=\"\" id=\"guardianName\" class=\"form-ctrl\"\r\n                        [(ngModel)]=\"editEnqData.parent_name\" name=\"guardianName\" maxlength=\"50\"\r\n                        #guardianName=\"ngModel\" />\r\n\r\n                      <div *ngIf=\"guardianName.invalid && (guardianName.dirty || guardianName.touched)\"\r\n                        class=\"alert invalid-alert\">\r\n                        <!-- <div *ngIf=\"guardianName.errors.pattern\">\r\n                        Only Alphabets . - Allowed. pattern=\"^([a-zA-Z .-]){1,30}$\"\r\n                      </div> -->\r\n                      </div>\r\n                    </div>\r\n\r\n                    <!-- Phone -->\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"guardianContact\"style=\"width: 22%\">Parent Contact</label><br>\r\n                      <span class=\"countryCallingCode\">\r\n                          <select id=\"country_id\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.country_id\" name=\"country_id\"\r\n                          [disabled]=\"countryDetails.length<=1\" (change)=\"onChangeObj($event.target.value)\"\r\n                          style=\"height: 29px;padding: 0\">\r\n                          <option value=\"\"></option>\r\n                          <option [value]=\"data.id\" selected *ngFor='let data of countryDetails'>\r\n                            {{data.country_code}} +{{data.country_calling_code}}\r\n                          </option>\r\n                        </select>\r\n                      </span>\r\n                      <input type=\"text\" value=\"\" id=\"guardianContact\" class=\"form-ctrl\"\r\n                        [(ngModel)]=\"editEnqData.parent_phone\" name=\"guardianContact\"\r\n                        style=\"width: 78%\"\r\n                        onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" />\r\n                    </div>\r\n\r\n                    <!-- Email -->\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"guardianEmail\">Parent Email ID</label>\r\n                      <input type=\"text\" value=\"\" id=\"guardianEmail\" class=\"form-ctrl\"\r\n                        [(ngModel)]=\"editEnqData.parent_email\" name=\"guardianEmail\"\r\n                        pattern=\"[a-zA-Z0-9._%+-]+@[a-zA-Z]+\\.[a-zA-Z.]{2,5}$\" #guardianEmail=\"ngModel\" />\r\n\r\n                      <div *ngIf=\"guardianEmail.invalid && (guardianEmail.dirty || guardianEmail.touched)\"\r\n                        class=\"alert invalid-alert\">\r\n                        <div *ngIf=\"guardianEmail.errors.pattern\">\r\n                          Enter email in format eg. someone@xyz.com\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n\r\n                    <!-- Link -->\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"enquirerLink\">Link Details</label>\r\n                      <input type=\"text\" value=\"\" id=\"enquirerLink\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.link\"\r\n                        name=\"enquirerLink\" />\r\n\r\n                    </div>\r\n\r\n                    <!-- Fee Commited -->\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"feeCommitted\">Fees Committed Details</label>\r\n                      <input type=\"text\" value=\"\" id=\"feeCommitted\" class=\"form-ctrl\"\r\n                        [(ngModel)]=\"editEnqData.fee_committed\" name=\"feeCommitted\" #feeCommitted=\"ngModel\"\r\n                        onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" />\r\n\r\n                    </div>\r\n\r\n                    <!-- Discount -->\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"discount\">Discount Offered Details</label>\r\n                      <input type=\"text\" value=\"\" id=\"discount\" class=\"form-ctrl\"\r\n                        [(ngModel)]=\"editEnqData.discount_offered\" name=\"discount\" pattern=\"[0-9]+\"\r\n                        onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" #discount=\"ngModel\" />\r\n\r\n                    </div>\r\n\r\n                  </div>\r\n                </div>\r\n            </li>\r\n            <!-- Academic Form 2-->\r\n            <li class=\"data-filled\" id=\"academicDetails\" style=\"padding-bottom: 60px;\">\r\n              <div class=\"accordian-heading\">\r\n                <h4>\r\n                  <span class=\"circle-accor\">2</span> Academics Details\r\n                  <span class=\"close-accor\" id=\"closeAcademic\" (click)=\"toggleForm($event)\">-</span>\r\n                  <span class=\"open-accor\" id=\"openAcademic\" (click)=\"toggleForm($event)\">+</span>\r\n                </h4>\r\n              </div>\r\n              <div class=\"accordian-content\">\r\n                <div class=\"form-type2\">\r\n\r\n                  <div class=\"field-wrapper\">\r\n                    <label for=\"institutionName\">Institution Name</label>\r\n                    <select id=\"institutionName\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.school_id\"\r\n                      name=\"institutename\">\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let institute of school\" [value]=\"institute.school_id\">\r\n                        {{institute.school_name}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n\r\n                  <!-- standard Course-->\r\n                  <div *ngIf=\"!isProfessional\" class=\"field-wrapper\">\r\n                    <label for=\"editStandard\">Standard</label>\r\n                    <select id=\"editStandard\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.standard_id\"\r\n                      (ngModelChange)=\"fetchSubject($event)\" name=\"editStandard\">\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let std of enqStd\" [value]=\"std.standard_id\">{{std.standard_name}}</option>\r\n                    </select>\r\n                    <div class=\"questionInfo\">\r\n                      <span class=\"qInfoIcon\" style=\"margin-top:-12px;\">?</span>\r\n                      <div class=\"tooltip-box-field tooltip-size\">\r\n                        Enquirer select a standard to fetch related subject\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n\r\n                  <!-- subject Course -->\r\n                  <div *ngIf=\"!isProfessional\" class=\"field-wrapper\">\r\n                    <label for=\"forSubject\">Subject</label>\r\n                    <select multiple id=\"forSubject\" class=\"form-ctrl form-ctrl-multiple\"\r\n                      [(ngModel)]=\"editEnqData.subjectIdArray\" name=\"subject\">\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let subject of enqSub\" [value]=\"subject.subject_id\">{{subject.subject_name}}\r\n                      </option>\r\n                    </select>\r\n                    <div class=\"questionInfo\">\r\n                      <span class=\"qInfoIcon\" style=\"margin-top:-12px;\">?</span>\r\n                      <div class=\"tooltip-box-field\">\r\n                        Subject with relation to the standard opted\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n\r\n                  <!-- masterCourse course -->\r\n                  <div *ngIf=\"!isProfessional\" class=\"field-wrapper\">\r\n                    <label for=\"editMc\">Master Course</label>\r\n                    <select id=\"editMc\" class=\"form-ctrl\" name=\"editMc\" [(ngModel)]=\"editEnqData.master_course_name\"\r\n                      (ngModelChange)=\"courseMasterChange($event)\">\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let master of masterCourseData\" [value]=\"master.master_course\">\r\n                        {{master.master_course}}</option>\r\n                    </select>\r\n                  </div>\r\n\r\n                  <!-- course course-->\r\n                  <div *ngIf=\"!isProfessional\" class=\"field-wrapper\">\r\n                    <label for=\"editCC\">Course</label>\r\n                    <select id=\"editCC\" class=\"form-ctrl form-ctrl-multiple\" [(ngModel)]=\"editEnqData.courseIdArray\"\r\n                      name=\"editCC\" multiple>\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let cc of course_course\" [value]=\"cc.course_id\">{{cc.course_name}}</option>\r\n                    </select>\r\n                  </div>\r\n\r\n                  <!-- master Professional -->\r\n                  <div *ngIf=\"isProfessional\" class=\"field-wrapper\">\r\n                    <label for=\"editStandard\">Master Course</label>\r\n                    <select id=\"editStandard\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.standard_id\"\r\n                      (ngModelChange)=\"fetchSubject($event)\" name=\"editStandard\">\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let std of enqStd\" [value]=\"std.standard_id\">{{std.standard_name}}</option>\r\n                    </select>\r\n                    <div class=\"questionInfo\">\r\n                      <span class=\"qInfoIcon\" style=\"margin-top:-12px;\">?</span>\r\n                      <div class=\"tooltip-box-field tooltip-size\">\r\n                        Enquirer select a standard to fetch related subject\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n\r\n                  <!-- course Professional -->\r\n                  <div *ngIf=\"isProfessional\" class=\"field-wrapper\">\r\n                    <label for=\"forSubject\">Course</label>\r\n                    <select id=\"forSubject\" class=\"form-ctrl form-ctrl-multiple\"\r\n                      [(ngModel)]=\"editEnqData.subjectIdArray\" name=\"subject\" multiple>\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let subject of enqSub\" [value]=\"subject.subject_id\">{{subject.subject_name}}\r\n                      </option>\r\n                    </select>\r\n                    <div class=\"questionInfo\">\r\n                      <span class=\"qInfoIcon\" style=\"margin-top:-12px;\">?</span>\r\n                      <div class=\"tooltip-box-field\">\r\n                        Subject with relation to the standard opted\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n\r\n\r\n                  <custom-enquiry *ngFor=\"let component of customComponents\">\r\n                    <div class=\"\" *ngIf=\"component.type == 1\" input-def>\r\n                      <div class=\"field-wrapper\" [class.has-value]=\"component.value != ''\">\r\n                        <label *ngIf=\"component.is_required == 'Y'\" for=\"{{component.id}}\">{{component.label}}<span\r\n                            class=\"text-danger\">*</span></label>\r\n                        <label *ngIf=\"component.is_required == 'N'\" for=\"{{component.id}}\">{{component.label}} </label>\r\n                        <input type=\"text\" value=\"\" id=\"{{component.id}}\" [(ngModel)]=\"component.value\"\r\n                          class=\"form-ctrl\" name=\"a{{component.label}}\" [maxlength]=\"component.comp_length\" />\r\n                      </div>\r\n                    </div>\r\n\r\n                    <div class=\"\" *ngIf=\"component.type == 2\" input-def>\r\n                      <br>\r\n                      <div class=\"field-checkbox-wrapper\" [class.has-value]=\"component.value != ''\">\r\n\r\n                        <input class=\"form-checkbox\" id=\"{{component.id}}\" type=\"checkbox\" [(ngModel)]=\"component.value\"\r\n                          (ngModelChange)=\"fillCustomComponent($event, component)\" name=\"a{{component.label}}\" value=\"\">\r\n                        <label *ngIf=\"component.is_required == 'Y'\" for=\"{{component.id}}\">{{component.label}}<span\r\n                            class=\"text-danger\">*</span></label>\r\n                        <label *ngIf=\"component.is_required == 'N'\" for=\"{{component.id}}\">{{component.label}} </label>\r\n\r\n                      </div>\r\n                    </div>\r\n\r\n                    <div class=\"\" *ngIf=\"component.type == 3\" input-def>\r\n                      <div class=\"field-wrapper\" [class.has-value]=\"component.value != ''\">\r\n                        <label *ngIf=\"component.is_required == 'Y'\" for=\"{{component.id}}\">{{component.label}}<span\r\n                            class=\"text-danger\">*</span></label>\r\n                        <label *ngIf=\"component.is_required == 'N'\" for=\"{{component.id}}\">{{component.label}} </label>\r\n                        <select id=\"{{component.id}}\" class=\"form-ctrl\" [(ngModel)]=\"component.value\"\r\n                          name=\"a{{component.label}}\">\r\n                          <option value=\"\"></option>\r\n                          <option *ngFor=\"let opt of component.prefilled_data\" value=\"{{opt.data}}\">{{opt.displayName}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n\r\n                    <div class=\"\" *ngIf=\"component.type == 4\" input-def>\r\n                      <div id=\"{{component.id}}wrapper\" class=\"field-wrapper\" [class.has-value]=\"component.value != ''\"\r\n                        (click)=\"multiselectVisible($event.target.id)\">\r\n                        <label *ngIf=\"component.is_required == 'Y'\" for=\"component.id\">{{component.label}}*</label>\r\n                        <label *ngIf=\"component.is_required == 'N'\" for=\"component.id\">{{component.label}} </label>\r\n                        <input id=\"{{component.id}}\" type=\"text\" [ngModel]=\"component.selectedString\" autocomplete=\"off\"\r\n                          name=\"a{{component.label}}\" readonly=\"true\" class=\"form-ctrl\" />\r\n                      </div>\r\n                      <div id=\"{{component.id}}multi\" class=\"hide multiselect-wrapper\"\r\n                        (mouseleave)=\"multiselectVisible(component.id)\">\r\n                        <div class=\"multiselect-wrapper-inner\">\r\n                          <ul class=\"\">\r\n                            <li *ngFor=\"let opt of component.prefilled_data\">\r\n                              <div class=\"field-checkbox-wrapper\">\r\n\r\n                                <input type=\"checkbox\" value=\"\" name=\"{{opt.data}}\" [(ngModel)]=\"opt.checked\"\r\n                                  (ngModelChange)=\"updateMultiSelect(opt, component.id)\" class=\"form-checkbox\"\r\n                                  id=\"{{opt.data}}\">\r\n                                <label for=\"opt.data\">{{opt.data}}</label>\r\n                              </div>\r\n                            </li>\r\n                          </ul>\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n\r\n                    <div class=\"newDate\" *ngIf=\"component.type == 5\" input-def>\r\n                      <div class=\"field-wrapper datePickerBox\">\r\n                        <label for=\"component.id\">{{component.label}} </label>\r\n                        <input type=\"text\" value=\"\" readonly=\"true\" id=\"{{component.id}}\" [(ngModel)]=\"component.value\"\r\n                          class=\"form-ctrl bsDatepicker\" name=\"{{component.label}}\" bsDatepicker />\r\n                      </div>\r\n                    </div>\r\n                  </custom-enquiry>\r\n\r\n                </div>\r\n              </div>\r\n            </li>\r\n          </ul>\r\n        </div>\r\n      </section>\r\n\r\n      <!-- Footer for Accordian Menu -->\r\n      <section class=\"middle-bottom clearFix\">\r\n        <div class=\"pull-left\">\r\n        </div>\r\n        <aside class=\"pull-right\">\r\n          <input type=\"button\" value=\"Cancel\" class=\"btn cancle\" (click)=\"clearLocalAndRoute()\" id=\"btnClearLocal\">\r\n          <input style=\"display: inline-block;\" type=\"button\" value=\"Update & Admit Enquiry\"\r\n            class=\"btn fullBlue\" (click)=\"submitRegisterForm()\" id=\"btnUpdateAndAdmit\">\r\n          <input type=\"button\" value=\"Save Enquiry\" [disabled]=\"isEnquirySubmit\"\r\n            class=\"btn fullBlue\" (click)=\"submitForm()\" id=\"btnSaveEnquiry\">\r\n        </aside>\r\n      </section>\r\n    </aside>\r\n    <!-- Right side form for Office purrpose only -->\r\n    <aside class=\"pull-right middle-right\" id=\"rightSideBar\">\r\n\r\n      <!-- Enquiry Details official use-->\r\n      <section class=\"enquiry-detail common-right-section\">\r\n        <h4>\r\n          <strong>Enquiry Details</strong> (Official Use)</h4>\r\n        <div class=\"box-shadow-lite AdFilter\">\r\n          <div class=\"field-wrapper datePickerBox\">\r\n            <label for=\"enquiryDate\">Enquiry Date</label>\r\n            <input type=\"text\" value=\"\" id=\"enquiryDate\" class=\"form-ctrl bsDatepicker\"\r\n              [(ngModel)]=\"editEnqData.enquiry_date\" name=\"enquiryDate\" readonly=\"true\" bsDatepicker>\r\n            <!-- <span class=\"date-clear\" name=\"followupdate\" (click)=\"editEnqData.enquiry_date = ''\">clear</span> -->\r\n          </div>\r\n\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"eStatus\">Enquiry Status</label>\r\n            <select id=\"eStatus\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.status\" name=\"status\"\r\n              [disabled]=\"enquiryStatus ==1 || enquiryStatus == 12\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let status of enqstatus\" [value]=\"status.data_key\"\r\n                [hidden]=\"status.data_key == 12 ? true : false\">{{status.data_value}}</option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper\" *ngIf=\"editEnqData.status == '1'\">\r\n            <label for=\"closingReason\">Closing Reason<span class=\"text-danger\">*</span></label>\r\n            <select id=\"closingReason\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.closing_reason_id\"\r\n              name=\"closingReason\">\r\n              <option value=\"0\"></option>\r\n              <option *ngFor=\"let status of closingReasonDataSource\" [value]=\"status.closing_reason_id\">\r\n                {{status.closing_desc}}</option>\r\n            </select>\r\n            <span style=\"right: 5px;\" class=\"sourceI iconPlus\" (click)=\"closingReason()\">+</span>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"priority\">Enquiry Priority</label>\r\n            <select id=\"priority\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.priority\" name=\"priority\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let priority of enqPriority\" [value]=\"priority.data_key\">\r\n                {{priority.data_value}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"followUpType\">Follow Up Type</label>\r\n            <select id=\"followUpType\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.follow_type\" name=\"followtype\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let followUp of enqFollowType\" [value]=\"followUp.data_key\">\r\n                {{followUp.data_value}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper datePickerBox\">\r\n            <label for=\"followUpDate\">Follow Up Date</label>\r\n            <input type=\"text\" value=\"\" id=\"followUpDate\" class=\"form-ctrl bsDatepicker\"\r\n              [(ngModel)]=\"editEnqData.followUpDate\" name=\"followUpDate\" readonly='true'\r\n              (ngModelChange)=\"notifyMeCheckBoxChangesDetect()\" bsDatepicker>\r\n            <span class=\"date-clear\" name=\"followupdate\" (click)=\"editEnqData.followUpDate = ''\">clear</span>\r\n          </div>\r\n\r\n\r\n          <div class=\"time-picker\">\r\n\r\n            <div class=\"field-wrapper\" id=\"hourpar\" style=\"padding-right: 10px;\">\r\n              <label for=\"hour\">Hour</label>\r\n              <select id=\"hour\" class=\"form-ctrl ng-valid ng-touched ng-dirty\" [(ngModel)]=\"followUpTime\" name=\"hour\"\r\n                style=\"width: 75px;\" (ngModelChange)=\"timeChanges($event)\">\r\n                <option *ngFor=\"let time of times\" [value]=\"time\">\r\n                  {{time}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n\r\n            <div class=\"field-wrapper\" id=\"minutepar\" style=\"padding-right: 10px;\">\r\n              <label for=\"minute\">Minute</label>\r\n              <select id=\"minute\" class=\"form-ctrl ng-valid ng-touched ng-dirty\" [(ngModel)]=\"minute\" name=\"minute\"\r\n                style=\"width: 70px;\" (ngModelChange)=\"notifyMeCheckBoxChangesDetect()\">\r\n                <option *ngFor=\"let minute of minuteArr\" [value]=\"minute\">\r\n                  {{minute}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n\r\n          </div>\r\n\r\n          <div\r\n            *ngIf=\"followUpTime!='' && minute!='' && editEnqData.followUpDate != '' && editEnqData.followUpDate != null\"\r\n            style=\"padding-top: 20px;\">\r\n            <div class=\"field-checkbox-wrapper\">\r\n              <input type=\"checkbox\" class=\"form-checkbox\" [(ngModel)]=\"editEnqData.is_follow_up_time_notification\"\r\n                name=\"checked\">\r\n              <label>Notify Me</label>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper datePickerBox\" *ngIf=\"editEnqData.follow_type == 'Walkin'\">\r\n            <label for=\"walkinDate\">Walkin Date<span class=\"text-danger\">*</span></label>\r\n            <input type=\"text\" value=\"\" id=\"walkinDate\" class=\"form-ctrl bsDatepicker\"\r\n              [(ngModel)]=\"editEnqData.walkin_followUpDate\" name=\"walkinDate\" readonly='true' bsDatepicker>\r\n            <span class=\"date-clear\" name=\"walkin_followUpDate\"\r\n              (click)=\"editEnqData.walkin_followUpDate = ''\">clear</span>\r\n          </div>\r\n\r\n          <div class=\"time-picker\" *ngIf=\"editEnqData.follow_type == 'Walkin'\">\r\n\r\n            <div class=\"field-wrapper\" style=\"padding-right: 10px;\">\r\n              <label for=\"walkinHour\">Hour<span class=\"text-danger\">*</span></label>\r\n              <select id=\"walkinHour\" class=\"form-ctrl\" [(ngModel)]=\"walkintime.hour\" name=\"walkinHour\"\r\n                style=\"width: 75px;\">\r\n                <option *ngFor=\"let time of times\" [value]=\"time\">\r\n                  {{time}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n\r\n            <div class=\"field-wrapper\" style=\"padding-right: 10px;\">\r\n              <label for=\"walkinMin\">Minute<span class=\"text-danger\">*</span></label>\r\n              <select id=\"walkinMin\" class=\"form-ctrl\" [(ngModel)]=\"walkintime.minute\" name=\"walkinMin\"\r\n                style=\"width: 70px;\">\r\n                <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                  {{minute}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n\r\n          </div>\r\n\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"refferedBy\">Referred By</label>\r\n            <select id=\"refferedBy\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.referred_by\" name=\"reffered\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let refer of refferedBy\" [value]=\"refer.id\">{{refer.name}}</option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper\" *ngIf=\"isMainBranch == 'Y' || subBranchSelected == true\">\r\n            <label for=\"selectBranch\">Branch</label>\r\n            <select id=\"selectBranch\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.source_instituteId\" name=\"selectBranch\"\r\n              (ngModelChange)=\"branchUpdated($event)\">\r\n              <option *ngFor=\"let data of branchesList\" [value]=\"data.institute_id\">{{data.institute_name}}</option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper \" [ngClass]=\"{'has-value': editEnqData.assigned_to != '-1'}\" *ngIf=\"isEnquiryAdmin\">\r\n            <label for=\"assignedTo\">Assigned To</label>\r\n            <select id=\"assignedTo\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.assigned_to\" name=\"assigned_to\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let assign of enqAssignTo\" [value]=\"assign.userid\">{{assign.name}}</option>\r\n            </select>\r\n\r\n          </div>\r\n          <div class=\"field-wrapper \" [ngClass]=\"{'has-value': editEnqData.enquiry != ''}\">\r\n            <label for=\"Remarks\">Comment</label>\r\n            <input type=\"text\" value=\"\" id=\"Remarks\" class=\"form-ctrl\" [(ngModel)]=\"editEnqData.enquiry\" name=\"remarks\">\r\n\r\n          </div>\r\n          <label style=\"margin-top: 5px;\" (click)=\"commentHandlerOpen()\">\r\n            <a style=\"font-weight: 600;\" class=\"cursor-icon\" id=\"cursorIconAnch1\">View Previous Comment</a>\r\n          </label>\r\n        </div>\r\n      </section>\r\n    </aside>\r\n  </form>\r\n  <!-- Update PopUp -->\r\n  <section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"isUpdateComment\">\r\n    <div class=\"popup pos-abs\" style=\"max-width: 80%;\">\r\n      <div class=\"popup-wrapper pos-rel\">\r\n        <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"commentHandlerClose()\">\r\n          <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\"\r\n            preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n            <path _ngcontent-c11=\"\" class=\"large-icon\"\r\n              d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\"\r\n              style=\"fill: currentColor\"></path>\r\n          </svg>\r\n        </span>\r\n        <div class=\"popup-content\" style=\"min-height: 400px; max-height: 500px; padding: 15px 15px 20px 15px;\">\r\n          <h2>Update Enquiry# {{editEnqData.enquiry_no}} | {{editEnqData.name}}</h2>\r\n          <div class=\"update-enquiry-form overflowHidden\">\r\n\r\n            <aside class=\"pull-right form-wrapper\">\r\n              <div class=\"row\" style=\"background: #d1d1d1;\">\r\n                <div class=\"c-lg-12 c-md-12 c-sm-12\">\r\n                  <div class=\"field-wrapper\" style=\"background: transparent;\">\r\n                    <textarea placeholder=\"Update Comment Here (max 1000 characters)\" rows=\"2\" cols=\"10\"\r\n                      style=\"height: 200px;background: transparent;\" id=\"addcommentEdit\" class=\"form-ctrl\"\r\n                      [(ngModel)]=\"updateFormData.comment\">\r\n                    </textarea>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"pull-right submitter\">\r\n                <div class=\"clearfix\">\r\n                  <aside class=\"pull-right popup-btn\">\r\n                    <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"commentHandlerClose()\"\r\n                      id=\"btnCommentHandler\">\r\n                    <input type=\"button\" value=\"Update\" class=\"fullBlue btn\" (click)=\"pushUpdatedEnquiry()\"\r\n                      id=\"btnUpdateEnquiry\">\r\n                  </aside>\r\n                </div>\r\n              </div>\r\n            </aside>\r\n\r\n\r\n            <aside class=\"pull-left table-wrapper\">\r\n              <h4>Comment History</h4>\r\n              <div class=\"enquiry-update-history table-responsive\">\r\n                <table>\r\n\r\n                  <thead>\r\n                    <tr>\r\n                      <th>Comment</th>\r\n                      <th>Commented On</th>\r\n                      <th>Commented By</th>\r\n                    </tr>\r\n                  </thead>\r\n\r\n                  <tbody *ngIf=\"updateFormComments.length != 0\">\r\n                    <tr *ngFor=\"let item of updateFormComments; let i=index;\">\r\n                      <td>{{updateFormComments[i]}}</td>\r\n                      <td>{{updateFormCommentsOn[i]| date:'dd-MM-yyyy hh:mm a'}}</td>\r\n                      <td>{{updateFormCommentsBy[i]}}</td>\r\n                    </tr>\r\n                  </tbody>\r\n                  <tbody *ngIf=\"updateFormComments.length == 0\">\r\n                    <tr>\r\n                      <td colspan=\"3\">\r\n                        No Comments Found\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                </table>\r\n              </div>\r\n            </aside>\r\n\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n</section>\r\n\r\n<proctur-popup [sizeWidth]=\"'medium'\" *ngIf=\"closingReasonOpen\">\r\n\r\n  <span class=\"closePopup pos-abs fbold show\" (click)=\"closeClosingReason()\" close-button>\r\n    <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n      <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n        <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n          <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\"\r\n            transform=\"translate(992.81 305.77) rotate(45)\" />\r\n          <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\"\r\n            transform=\"translate(978.81 305.77) rotate(45)\" />\r\n        </g>\r\n        <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\"\r\n          transform=\"translate(1012 297)\" />\r\n      </g>\r\n    </svg>\r\n  </span>\r\n\r\n  <div popup-header class=\"popup-header-content\">\r\n    <h2>Closing Reasons</h2>\r\n  </div>\r\n\r\n  <div class=\"popup-content\" popup-content>\r\n\r\n    <div class=\"row clearFix add-edit\">\r\n      <a class=\"expend-box\" (click)=\"toggleReferAdd()\" id=\"toggleAnch\">\r\n        <i id=\"add-refer-icon\">+</i>\r\n        <span style=\"font-size: 12px;\">Add New Reason</span>\r\n      </a>\r\n    </div>\r\n\r\n    <div class=\"row class-edit\" *ngIf=\"isNewRefer\">\r\n      <div class=\"c-lg-4 field-wrapper\">\r\n        <label>Closing Reason Description<span class=\"text-danger\">*</span></label>\r\n        <textarea class=\"form-ctrl\" style=\"height: 69px;\" maxlength=\"50\"\r\n          [(ngModel)]=\"createNewReasonObj.closing_desc\"></textarea>\r\n      </div>\r\n      <div class=\"c-lg-2\" style=\"margin-top: 3%;\">\r\n        <button class=\"btn fullBlue\" (click)=\"createNewReason()\">Add</button>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"table table-responsive scroll-up\">\r\n      <div class=\"scroll-down\">\r\n        <table>\r\n          <thead>\r\n            <tr>\r\n              <th>\r\n                Id\r\n              </th>\r\n              <th>\r\n                Closing Reason\r\n              </th>\r\n              <th>\r\n\r\n              </th>\r\n            </tr>\r\n          </thead>\r\n          <tbody *ngIf=\"closingReasonDataSource.length!=0\">\r\n            <tr *ngFor=\"let reason of closingReasonDataSource ; let i=index;\" class=\"displayComp\" id=\"reason{{i}}\">\r\n              <td class=\"view-comp\">\r\n                {{reason.closing_reason_id}}\r\n              </td>\r\n\r\n              <td class=\"edit-comp\">\r\n                {{reason.closing_reason_id}}\r\n              </td>\r\n\r\n              <td class=\"view-comp\">\r\n                {{reason.closing_desc}}\r\n              </td>\r\n\r\n              <td class=\"edit-comp\">\r\n                <div class=\"field-wrapper\">\r\n                  <input type=\"text\" class=\"form-ctrl editCellInput\" name=\"label\" [(ngModel)]=\"reason.closing_desc\"\r\n                    [value]=\"reason.closing_desc\" style=\"text-align: center;\">\r\n                </div>\r\n              </td>\r\n\r\n              <td class=\"view-comp\">\r\n                <a (click)=\"editRowTable(reason, i)\">\r\n                  <i class=\"edit-icon cursor-icon\" aria-hidden=\"true\" id=\"editIcon5\"></i>Edit\r\n                </a>\r\n              </td>\r\n\r\n              <td class=\"edit-comp\">\r\n                <a class=\"anchorTagCursor\" (click)=\"saveInformation(reason , i)\"> Save </a>\r\n                <a class=\"anchorTagCursor anchorTag\" (click)=\"cancelEditRow(i)\"> Cancel </a>\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n\r\n          <tbody *ngIf=\"closingReasonDataSource.length==0\">\r\n            <tr>\r\n              <td colspan=\"3\">\r\n                No Closing Reason found\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n        </table>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n\r\n</proctur-popup>"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-edit/enquiry-edit.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/* ============================================================================================================= */\n.homewrap {\n  overflow-x: hidden;\n  overflow-y: auto; }\n.homewrap ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n.homewrap .scroll-content {\n    overflow-x: hidden;\n    overflow-y: auto;\n    padding-bottom: 15px; }\n/* ============================================================================================================= */\n.discount-wrapper .field-checkbox-wrapper,\n.discount-wrapper .field-radio-wrapper {\n  position: relative;\n  padding-left: 25px;\n  margin-bottom: 10px; }\n.discount-wrapper .field-radio-wrapper .form-radio {\n  opacity: 0;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px;\n  z-index: 1; }\n.discount-wrapper .field-radio-wrapper .form-radio + label {\n  vertical-align: middle;\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s; }\n.discount-wrapper .field-radio-wrapper .form-radio + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 50%;\n  position: absolute;\n  left: 0;\n  top: 0;\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s; }\n.discount-wrapper .field-radio-wrapper .form-radio:checked + label:after {\n  border: 2px solid #0084f6; }\n.discount-wrapper .field-radio-wrapper .form-radio + label:before {\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s;\n  width: 1px;\n  height: 1px;\n  left: 9px;\n  top: 9px;\n  position: absolute;\n  content: ''; }\n.discount-wrapper .field-radio-wrapper .form-radio:checked + label:before {\n  content: '';\n  width: 8px;\n  height: 8px;\n  background: #0084f6;\n  border-radius: 50%;\n  left: 4px;\n  top: 4px; }\n.discount-wrapper .field-radio-wrapper .form-radio:checked + label {\n  color: #0084f6; }\n.fee-definations {\n  width: 100%;\n  max-height: 400px;\n  overflow: hidden;\n  border-top: 2px solid rgba(119, 119, 119, 0.12); }\n.fee-definations ::-webkit-scrollbar {\n    display: block; }\n.fee-definations .fee-container {\n    padding-top: 10px;\n    max-height: 400px;\n    overflow-x: hidden;\n    overflow-y: auto; }\n.fee-definations .fee-container ul li a {\n      cursor: pointer; }\n.fee-definations .fee-container .installment-container {\n      -webkit-box-shadow: 0px 1px 3px 0px rgba(38, 0, 0, 0.2);\n              box-shadow: 0px 1px 3px 0px rgba(38, 0, 0, 0.2); }\n.fee-definations .fee-container .installment-container .installment-header {\n        background: #efefef;\n        padding: 10px;\n        font-size: 18px;\n        font-weight: 700;\n        border-top-left-radius: 5px;\n        border-top-right-radius: 5px; }\n.fee-definations .fee-container .installment-container .installment-adder {\n        background: #efefef;\n        padding: 20px 5px 10px 5px; }\n.fee-definations .fee-container .installment-container .installment-adder ul li {\n          display: -webkit-inline-box;\n          display: -ms-inline-flexbox;\n          display: inline-flex;\n          width: 20%;\n          margin: 0px 10px; }\n.fee-definations .fee-container .installment-container .installment-adder ul li .form-wrapper {\n            position: relative;\n            background: transparent;\n            margin: 0px;\n            border: none;\n            padding: 0; }\n.fee-definations .fee-container .installment-container .installment-adder ul li .form-wrapper .date-clear {\n              position: absolute;\n              right: 60%;\n              top: 50px;\n              cursor: pointer;\n              color: #0084f6; }\n.fee-definations .fee-container .installment-container .installment-adder ul li .form-wrapper .form-ctrl {\n              background: transparent; }\n.fee-definations .fee-container .installment-container .installment-adder ul li .form-wrapper.datepicker span {\n              position: absolute;\n              top: 30px;\n              right: 20px;\n              font-weight: 300;\n              color: red;\n              cursor: pointer; }\n.fee-definations .fee-container .installment-container .installment-adder ul li .form-wrapper label {\n              font-size: 12px;\n              font-weight: 400;\n              width: 100%;\n              display: block;\n              color: black;\n              text-decoration: none;\n              text-shadow: none;\n              -webkit-font-smoothing: antialiased; }\n.fee-definations .fee-container .installment-container .installment-adder ul li .form-wrapper .form-ctrl {\n              background: transparent;\n              border: 1px solid rgba(119, 119, 119, 0.419608);\n              border-radius: 5px;\n              width: 100%;\n              display: block;\n              padding: 0px 5px;\n              font-weight: 600;\n              font-size: 12px;\n              color: black;\n              height: 25px; }\n.fee-definations .fee-container .installment-container .installment-adder ul li .form-wrapper .form-ctrl.bsDatepicker {\n                padding: 0px 5px; }\n.fee-definations .fee-container .installment-container .installment-adder ul li .form-wrapper.timepick .form-ctrl {\n              background: transparent;\n              border: 1px solid rgba(119, 119, 119, 0.419608);\n              width: 100%;\n              padding: 8px 5px;\n              font-weight: 600;\n              font-size: 14px;\n              color: black; }\n.fee-definations .fee-container .installment-container .installment-adder ul li .datePickerBox .bsDatepicker {\n            cursor: pointer;\n            position: relative;\n            z-index: 1;\n            background: transparent;\n            width: 95%; }\n.fee-definations .fee-container .installment-container .installment-adder ul li .datePickerBox:after {\n            content: '';\n            background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n            position: absolute;\n            right: 13px;\n            top: 15px;\n            width: 21px;\n            height: 21px;\n            z-index: 0; }\n.fee-definations .fee-container .installment-container .installment-table ul li {\n        display: -webkit-inline-box;\n        display: -ms-inline-flexbox;\n        display: inline-flex; }\n.fee-definations .fee-container .installment-container .installment-table ul li:first-child {\n          width: 5% !important; }\n.fee-definations .fee-container .installment-container .installment-table ul li.date {\n          width: 20% !important; }\n.fee-definations .fee-container .installment-container .installment-table ul .form-wrapper {\n        position: relative;\n        background: transparent;\n        margin: 0px;\n        border: none;\n        padding: 0;\n        width: 100%; }\n.fee-definations .fee-container .installment-container .installment-table ul .form-wrapper.datePickerBox .bsDatepicker {\n          cursor: pointer;\n          position: relative;\n          z-index: 1;\n          background: transparent;\n          width: 95%; }\n.fee-definations .fee-container .installment-container .installment-table ul .form-wrapper.datePickerBox:after {\n          content: '';\n          background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n          position: absolute;\n          right: 9px;\n          top: 1px;\n          width: 21px;\n          height: 21px;\n          z-index: 0; }\n.fee-definations .fee-container .installment-container .installment-table ul .form-wrapper .date-clear {\n          position: absolute;\n          right: 60%;\n          top: 50px;\n          cursor: pointer;\n          color: #0084f6; }\n.fee-definations .fee-container .installment-container .installment-table ul .form-wrapper .form-ctrl {\n          background: transparent; }\n.fee-definations .fee-container .installment-container .installment-table ul .form-wrapper.datepicker span {\n          position: absolute;\n          top: 30px;\n          right: 20px;\n          font-weight: 300;\n          color: red;\n          cursor: pointer; }\n.fee-definations .fee-container .installment-container .installment-table ul .form-wrapper label {\n          font-size: 12px;\n          font-weight: 400;\n          width: 100%;\n          display: block;\n          color: black;\n          text-decoration: none;\n          text-shadow: none;\n          -webkit-font-smoothing: antialiased; }\n.fee-definations .fee-container .installment-container .installment-table ul .form-wrapper .form-ctrl {\n          background: transparent;\n          border: 1px solid rgba(119, 119, 119, 0.419608);\n          border-radius: 5px;\n          width: 100%;\n          display: block;\n          padding: 0px 5px;\n          font-weight: 600;\n          font-size: 12px;\n          color: black;\n          height: 25px; }\n.fee-definations .fee-container .installment-container .installment-table ul .form-wrapper .form-ctrl.bsDatepicker {\n            padding: 0px 5px; }\n.fee-definations .fee-container .installment-container .installment-table ul .form-wrapper.timepick .form-ctrl {\n          background: transparent;\n          border: 1px solid rgba(119, 119, 119, 0.419608);\n          width: 100%;\n          padding: 8px 5px;\n          font-weight: 600;\n          font-size: 14px;\n          color: black; }\n.fee-definations .fee-container .installment-container .installment-table ul.table-header {\n        border: 1px solid rgba(119, 119, 119, 0.24);\n        font-size: 14px;\n        font-weight: 600; }\n.fee-definations .fee-container .installment-container .installment-table ul.table-header li {\n          width: 14%;\n          padding: 10px;\n          margin-left: 12px;\n          text-transform: uppercase;\n          color: #777; }\n.fee-definations .fee-container .installment-container .installment-table ul.table-header li.bigger {\n            width: 20%; }\n.fee-definations .fee-container .installment-container .installment-table .table-data ul {\n        border: 1px solid #efefef; }\n.fee-definations .fee-container .installment-container .installment-table .table-data ul li {\n          display: -webkit-inline-box;\n          display: -ms-inline-flexbox;\n          display: inline-flex;\n          width: 14%;\n          padding: 2px 12px;\n          margin-left: 10px;\n          text-align: center; }\n.fee-definations .fee-container .installment-container .installment-table .table-data ul li.bigger {\n            width: 20%; }\n.fee-definations .fee-container .installment-container .installment-table .table-data ul li.bigger a {\n              margin-left: 40px; }\n.fee-definations .fee-container .additional-container {\n      -webkit-box-shadow: 0px 1px 3px 0px rgba(38, 0, 0, 0.2);\n              box-shadow: 0px 1px 3px 0px rgba(38, 0, 0, 0.2);\n      margin-top: 20px; }\n.fee-definations .fee-container .additional-container .additional-header {\n        background: #efefef;\n        padding: 10px;\n        font-size: 18px;\n        font-weight: 700;\n        border-top-left-radius: 5px;\n        border-top-right-radius: 5px; }\n.fee-definations .fee-container .additional-container .additional-adder {\n        background: #efefef;\n        padding: 20px 5px 10px 5px; }\n.fee-definations .fee-container .additional-container .additional-adder ul li {\n          display: -webkit-inline-box;\n          display: -ms-inline-flexbox;\n          display: inline-flex;\n          width: 15%;\n          margin: 0px 5px; }\n.fee-definations .fee-container .additional-container .additional-adder ul li .form-wrapper {\n            position: relative;\n            background: transparent;\n            margin: 0px;\n            border: none;\n            padding: 0; }\n.fee-definations .fee-container .additional-container .additional-adder ul li .form-wrapper.datePickerBox .bsDatepicker {\n              cursor: pointer;\n              position: relative;\n              z-index: 1;\n              background: transparent;\n              width: 95%; }\n.fee-definations .fee-container .additional-container .additional-adder ul li .form-wrapper.datePickerBox:after {\n              content: '';\n              background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n              position: absolute;\n              right: 13px;\n              top: 15px;\n              width: 21px;\n              height: 21px;\n              z-index: 0; }\n.fee-definations .fee-container .additional-container .additional-adder ul li .form-wrapper .date-clear {\n              position: absolute;\n              right: 60%;\n              top: 50px;\n              cursor: pointer;\n              color: #0084f6; }\n.fee-definations .fee-container .additional-container .additional-adder ul li .form-wrapper .form-ctrl {\n              background: transparent; }\n.fee-definations .fee-container .additional-container .additional-adder ul li .form-wrapper.datepicker span {\n              position: absolute;\n              top: 30px;\n              right: 20px;\n              font-weight: 300;\n              color: red;\n              cursor: pointer; }\n.fee-definations .fee-container .additional-container .additional-adder ul li .form-wrapper label {\n              font-size: 12px;\n              font-weight: 400;\n              width: 100%;\n              display: block;\n              color: black;\n              text-decoration: none;\n              text-shadow: none;\n              -webkit-font-smoothing: antialiased; }\n.fee-definations .fee-container .additional-container .additional-adder ul li .form-wrapper .form-ctrl {\n              background: transparent;\n              border: 1px solid rgba(119, 119, 119, 0.419608);\n              border-radius: 5px;\n              width: 100%;\n              display: block;\n              padding: 0px 5px;\n              font-weight: 600;\n              font-size: 12px;\n              color: black;\n              height: 25px; }\n.fee-definations .fee-container .additional-container .additional-adder ul li .form-wrapper .form-ctrl.bsDatepicker {\n                padding: 0px 5px; }\n.fee-definations .fee-container .additional-container .additional-adder ul li .form-wrapper.timepick .form-ctrl {\n              background: transparent;\n              border: 1px solid rgba(119, 119, 119, 0.419608);\n              width: 100%;\n              padding: 8px 5px;\n              font-weight: 600;\n              font-size: 14px;\n              color: black; }\n.fee-definations .fee-container .additional-container .additional-table ul li {\n        display: -webkit-inline-box;\n        display: -ms-inline-flexbox;\n        display: inline-flex; }\n.fee-definations .fee-container .additional-container .additional-table ul.table-header {\n        border: 1px solid rgba(119, 119, 119, 0.24);\n        font-size: 14px;\n        font-weight: 600; }\n.fee-definations .fee-container .additional-container .additional-table ul.table-header li {\n          width: 15%;\n          padding: 10px;\n          margin-left: 10px;\n          text-transform: uppercase;\n          color: #777; }\n.fee-definations .fee-container .additional-container .additional-table ul.table-header li.bigger {\n            width: 20%; }\n.fee-definations .fee-container .additional-container .additional-table ul.table-header li.tax {\n            width: 10% !important; }\n.fee-definations .fee-container .additional-container .additional-table ul.table-header li.date {\n            width: 20% !important; }\n.fee-definations .fee-container .additional-container .additional-table ul .form-wrapper {\n        position: relative;\n        background: transparent;\n        margin: 0px;\n        border: none;\n        padding: 0;\n        width: 75%; }\n.fee-definations .fee-container .additional-container .additional-table ul .form-wrapper.datePickerBox .bsDatepicker {\n          cursor: pointer;\n          position: relative;\n          z-index: 1;\n          background: transparent;\n          width: 95%; }\n.fee-definations .fee-container .additional-container .additional-table ul .form-wrapper.datePickerBox:after {\n          content: '';\n          background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n          position: absolute;\n          right: 9px;\n          top: 1px;\n          width: 21px;\n          height: 21px;\n          z-index: 0; }\n.fee-definations .fee-container .additional-container .additional-table ul .form-wrapper .date-clear {\n          position: absolute;\n          right: 60%;\n          top: 50px;\n          cursor: pointer;\n          color: #0084f6; }\n.fee-definations .fee-container .additional-container .additional-table ul .form-wrapper .form-ctrl {\n          background: transparent; }\n.fee-definations .fee-container .additional-container .additional-table ul .form-wrapper.datepicker span {\n          position: absolute;\n          top: 30px;\n          right: 20px;\n          font-weight: 300;\n          color: red;\n          cursor: pointer; }\n.fee-definations .fee-container .additional-container .additional-table ul .form-wrapper label {\n          font-size: 12px;\n          font-weight: 400;\n          width: 100%;\n          display: block;\n          color: black;\n          text-decoration: none;\n          text-shadow: none;\n          -webkit-font-smoothing: antialiased; }\n.fee-definations .fee-container .additional-container .additional-table ul .form-wrapper .form-ctrl {\n          background: transparent;\n          border: 1px solid rgba(119, 119, 119, 0.419608);\n          border-radius: 5px;\n          width: 100%;\n          display: block;\n          padding: 0px 5px;\n          font-weight: 600;\n          font-size: 12px;\n          color: black;\n          height: 25px; }\n.fee-definations .fee-container .additional-container .additional-table ul .form-wrapper .form-ctrl.bsDatepicker {\n            padding: 0px 5px; }\n.fee-definations .fee-container .additional-container .additional-table ul .form-wrapper.timepick .form-ctrl {\n          background: transparent;\n          border: 1px solid rgba(119, 119, 119, 0.419608);\n          width: 100%;\n          padding: 8px 5px;\n          font-weight: 600;\n          font-size: 14px;\n          color: black; }\n.fee-definations .fee-container .additional-container .additional-table .table-data ul {\n        border: 1px solid #efefef; }\n.fee-definations .fee-container .additional-container .additional-table .table-data ul li {\n          display: -webkit-inline-box;\n          display: -ms-inline-flexbox;\n          display: inline-flex;\n          width: 15%;\n          padding: 2px 12px;\n          margin-left: 10px;\n          text-align: center; }\n.fee-definations .fee-container .additional-container .additional-table .table-data ul li.bigger {\n            width: 20%; }\n.fee-definations .fee-container .additional-container .additional-table .table-data ul li.bigger a {\n              margin-left: 40px; }\n.fee-definations .fee-container .additional-container .additional-table .table-data ul li.tax {\n            width: 10% !important; }\n.fee-definations .fee-container .additional-container .additional-table .table-data ul li.date {\n            width: 20% !important; }\n.table-row {\n  padding: 3px 5px; }\n.bigger {\n  width: 20%; }\n.fee-adder {\n  background: #0084f6 !important;\n  color: white !important;\n  position: relative;\n  top: 21px !important;\n  height: 30px !important;\n  padding: 3px 12px 7px 12px !important; }\n.fee-adder i {\n    display: -webkit-inline-box;\n    display: -ms-inline-flexbox;\n    display: inline-flex; }\n.fee-adder i::before {\n      font-family: FontAwesome;\n      content: \"\\f09d\";\n      font-size: 12px; }\n.form-wrapper {\n  padding: 8px 5px;\n  border-radius: 5px;\n  width: 100%;\n  position: relative;\n  border: 1px solid rgba(119, 119, 119, 0.34); }\n.form-wrapper .form-ctrl {\n    width: inherit;\n    background: transparent; }\n.form-wrapper.disable {\n    background: #dddddd !important; }\n.datePickerBox .bsDatepicker {\n  cursor: pointer;\n  position: relative;\n  z-index: 1;\n  background: transparent;\n  width: 95%; }\n.datePickerBox:after {\n  content: '';\n  background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n  position: absolute;\n  right: 20px;\n  width: 21px;\n  height: 21px;\n  z-index: 0; }\n.paid-fee {\n  border-radius: 10px;\n  padding: 5px;\n  width: 50px;\n  background: #6ad66a;\n  color: white; }\n/* ============================================================================================================= */\n/* ============================================================================================================= */\n.pdcChequePayment {\n  margin: 15px 0px !important; }\n.batch-wrapper {\n  max-height: 350px;\n  overflow: hidden; }\n.batch-wrapper ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n.batch-wrapper .table-responsive {\n    max-width: 100%;\n    max-height: 340px;\n    overflow-x: hidden;\n    overflow-y: scroll; }\n.batch-wrapper .table-responsive tr td .field-checkbox-wrapper {\n      background: transparent; }\n.batch-wrapper .table-responsive tr td .field-checkbox-wrapper .checkbox {\n        padding-left: 0px; }\n.batch-wrapper th {\n    text-align: left;\n    padding: 15px; }\n.batch-wrapper td {\n    padding: 10px 5px;\n    text-align: left; }\n.batch-wrapper td .field-wrapper {\n      position: relative;\n      padding-top: 0px; }\n.batch-wrapper td .field-wrapper.datePickerBox .bsDatepicker {\n        cursor: pointer;\n        position: relative;\n        z-index: 1;\n        background: transparent;\n        width: 120px; }\n.batch-wrapper td .field-wrapper.datePickerBox:after {\n        content: '';\n        background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n        position: absolute;\n        left: 97px;\n        top: 10px;\n        width: 21px;\n        height: 21px;\n        z-index: 0; }\n.batch-wrapper td .field-wrapper .date-clear {\n        position: absolute;\n        right: 60%;\n        top: 50px;\n        cursor: pointer;\n        color: #0084f6; }\n.batch-wrapper td .field-wrapper .form-ctrl {\n        background: transparent;\n        border-bottom: 1px solid #0084f6; }\n.batch-wrapper td .field-checkbox-wrapper .form-checkbox {\n      opacity: 0;\n      position: absolute;\n      left: 0;\n      top: 0;\n      width: 20px;\n      height: 20px;\n      z-index: 1; }\n.batch-wrapper td .field-checkbox-wrapper .form-checkbox + label {\n      vertical-align: middle;\n      font-size: 14px;\n      display: inline-block; }\n.batch-wrapper td .field-checkbox-wrapper .form-checkbox + label:after {\n      content: '';\n      width: 16px;\n      height: 16px;\n      border: 2px solid #ccc;\n      border-radius: 2px;\n      position: absolute;\n      left: 0;\n      top: 0; }\n.batch-wrapper td .field-checkbox-wrapper .form-checkbox:checked + label:after {\n      border: 2px solid #0084f6; }\n.batch-wrapper td .field-checkbox-wrapper .form-checkbox + label:before {\n      width: 1px;\n      height: 1px;\n      left: 8px;\n      top: 9px;\n      position: absolute;\n      content: '';\n      border-top: 0;\n      border-right: 0;\n      border-left: 2px solid transparent;\n      border-bottom: 2px solid transparent;\n      -webkit-transform: rotate(-45deg);\n              transform: rotate(-45deg); }\n.batch-wrapper td .field-checkbox-wrapper .form-checkbox:checked + label:before {\n      border-left: 2px solid #0084f6;\n      border-bottom: 2px solid #0084f6;\n      width: 12px;\n      height: 5px;\n      left: 2px;\n      top: 5px; }\n.batch-wrapper td .field-checkbox-wrapper .form-checkbox:checked + label {\n      color: #0084f6; }\n.PDCMain {\n  max-height: 480px;\n  overflow: hidden;\n  border-top: 1px solid rgba(119, 119, 119, 0.49);\n  border-bottom: 1px solid rgba(119, 119, 119, 0.49); }\n.PDCMain ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n.pdc-container {\n  width: 100%;\n  max-height: 400px;\n  overflow: hidden;\n  border-top: 2px solid rgba(119, 119, 119, 0.12); }\n.pdc-container ::-webkit-scrollbar {\n    display: block; }\n.pdc-container .pdc-wrapper {\n    padding-top: 10px;\n    max-height: 400px;\n    overflow-x: hidden;\n    overflow-y: auto; }\n.pdc-container .pdc-wrapper ::-webkit-scrollbar {\n      display: block;\n      width: 7px;\n      height: 7px; }\n.pdc-container .pdc-wrapper .row {\n      margin: 0px; }\n.pdc-container .pdc-wrapper .pdc-shell {\n      -webkit-box-shadow: 0px 1px 3px 0px rgba(38, 0, 0, 0.2);\n              box-shadow: 0px 1px 3px 0px rgba(38, 0, 0, 0.2); }\n.pdc-container .pdc-wrapper .pdc-shell .pdc-header {\n        padding: 10px;\n        font-size: 14px;\n        font-weight: 600;\n        border-top-left-radius: 5px;\n        border-top-right-radius: 5px; }\n.pdc-container .pdc-wrapper .pdc-shell .pdc-adder {\n        padding: 20px 5px 10px 5px; }\n.pdc-container .pdc-wrapper .pdc-shell .pdc-adder ul li {\n          display: -webkit-inline-box;\n          display: -ms-inline-flexbox;\n          display: inline-flex;\n          width: 15%;\n          margin: 0px 5px; }\n.pdc-container .pdc-wrapper .pdc-shell .pdc-table ul li {\n        display: -webkit-inline-box;\n        display: -ms-inline-flexbox;\n        display: inline-flex; }\n.pdc-container .pdc-wrapper .pdc-shell .pdc-table ul.table-header {\n        border: 1px solid rgba(119, 119, 119, 0.24);\n        font-size: 14px;\n        font-weight: 600; }\n.pdc-container .pdc-wrapper .pdc-shell .pdc-table ul.table-header li {\n          width: 15%;\n          padding: 10px;\n          margin-left: 10px;\n          text-transform: uppercase;\n          color: #777; }\n.pdc-container .pdc-wrapper .pdc-shell .pdc-table ul.table-header li.bigger {\n            width: 20%; }\n.pdc-container .pdc-wrapper .pdc-shell .pdc-table .table-data ul {\n        border: 1px solid #efefef; }\n.pdc-container .pdc-wrapper .pdc-shell .pdc-table .table-data ul li {\n          display: -webkit-inline-box;\n          display: -ms-inline-flexbox;\n          display: inline-flex;\n          width: 15%;\n          padding: 2px 12px;\n          margin-left: 10px;\n          text-align: center; }\n.pdc-container .pdc-wrapper .pdc-shell .pdc-table .table-data ul li.bigger {\n            width: 20%; }\n.pdc-container .pdc-wrapper .pdc-shell .pdc-table .table-data ul li.bigger a {\n              margin-left: 40px; }\n.pdc-container .pdc-wrapper .pdc-data-shell {\n      margin-top: 20px;\n      -webkit-box-shadow: 0px 1px 3px 0px rgba(38, 0, 0, 0.2);\n              box-shadow: 0px 1px 3px 0px rgba(38, 0, 0, 0.2); }\n.pdc-container .pdc-wrapper .pdc-data-shell .field-checkbox-wrapper,\n      .pdc-container .pdc-wrapper .pdc-data-shell .field-radio-wrapper {\n        position: relative;\n        padding-left: 25px;\n        margin-bottom: 10px; }\n.pdc-container .pdc-wrapper .pdc-data-shell .field-radio-wrapper .form-radio {\n        opacity: 0;\n        position: absolute;\n        left: 0;\n        top: 0;\n        width: 20px;\n        height: 20px;\n        z-index: 1; }\n.pdc-container .pdc-wrapper .pdc-data-shell .field-radio-wrapper .form-radio + label {\n        vertical-align: middle;\n        -webkit-transition: all 0.1s;\n        transition: all 0.1s; }\n.pdc-container .pdc-wrapper .pdc-data-shell .field-radio-wrapper .form-radio + label:after {\n        content: '';\n        width: 16px;\n        height: 16px;\n        border: 2px solid #ccc;\n        border-radius: 50%;\n        position: absolute;\n        left: 0;\n        top: 0;\n        -webkit-transition: all 0.1s;\n        transition: all 0.1s; }\n.pdc-container .pdc-wrapper .pdc-data-shell .field-radio-wrapper .form-radio:checked + label:after {\n        border: 2px solid #0084f6; }\n.pdc-container .pdc-wrapper .pdc-data-shell .field-radio-wrapper .form-radio + label:before {\n        -webkit-transition: all 0.1s;\n        transition: all 0.1s;\n        width: 1px;\n        height: 1px;\n        left: 9px;\n        top: 9px;\n        position: absolute;\n        content: ''; }\n.pdc-container .pdc-wrapper .pdc-data-shell .field-radio-wrapper .form-radio:checked + label:before {\n        content: '';\n        width: 10px;\n        height: 10px;\n        background: #0084f6;\n        border-radius: 50%;\n        left: 3px;\n        top: 3px; }\n.pdc-container .pdc-wrapper .pdc-data-shell .field-radio-wrapper .form-radio:checked + label {\n        color: #0084f6; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-header {\n        background: #efefef;\n        padding: 10px;\n        font-size: 14px;\n        font-weight: 600;\n        border-top-left-radius: 5px;\n        border-top-right-radius: 5px; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-search {\n        background: #efefef;\n        padding: 20px 5px 10px 5px; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-search ul li {\n          display: -webkit-inline-box;\n          display: -ms-inline-flexbox;\n          display: inline-flex;\n          width: 20%;\n          margin: 0px 5px; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-search ul li .form-wrapper {\n            background: transparent;\n            border: none;\n            width: 100%;\n            margin: 0px; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-search ul li .form-wrapper.datepicker span {\n              position: absolute;\n              top: 30px;\n              right: 20px;\n              font-weight: 300;\n              color: red;\n              cursor: pointer; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-search ul li .form-wrapper label {\n              font-size: 12px;\n              font-weight: 400;\n              color: black;\n              text-decoration: none;\n              text-shadow: none;\n              -webkit-font-smoothing: antialiased; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-search ul li .form-wrapper .form-ctrl {\n              background: transparent;\n              border: 1px solid rgba(119, 119, 119, 0.419608);\n              width: 100%;\n              padding: 8px 5px;\n              font-weight: 600;\n              font-size: 14px;\n              color: black; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-search ul li .form-wrapper .form-ctrl.bsDatepicker {\n                padding: 10px 5px; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-search ul li .form-wrapper.timepick .side-form-ctrl {\n              background: transparent;\n              border: 1px solid rgba(119, 119, 119, 0.419608);\n              width: 100%;\n              padding: 8px 5px;\n              font-weight: 600;\n              font-size: 14px;\n              color: black; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table ul li {\n        display: -webkit-inline-box;\n        display: -ms-inline-flexbox;\n        display: inline-flex; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table ul.table-header {\n        border: 1px solid rgba(119, 119, 119, 0.24);\n        font-size: 14px;\n        font-weight: 600; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table ul.table-header li {\n          width: 12%;\n          padding: 10px;\n          margin-left: 10px;\n          text-transform: uppercase;\n          color: #777; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table ul.table-header li:first-child {\n            width: 5%; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table ul.table-header li.bigger {\n            width: 20%; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table ul.table-header li.bigger a {\n              margin-left: 40px; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table .table-data ul {\n        border: 1px solid #efefef; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table .table-data ul li {\n          display: -webkit-inline-box;\n          display: -ms-inline-flexbox;\n          display: inline-flex;\n          width: 12%;\n          padding: 2px 12px;\n          margin-left: 10px;\n          text-align: center; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table .table-data ul li:first-child {\n            width: 5%; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table .table-data ul li.bigger {\n            width: 20%; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table .table-data ul li.bigger a {\n              margin-left: 40px; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table .table-data ul.displayComp .edit-comp {\n          display: none; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table .table-data ul.editComp .view-comp {\n          display: none; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table .table-data ul.editComp .edit-comp .field-wrapper {\n          position: relative;\n          /* padding-top: 20px; */ }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table .table-data ul.editComp .edit-comp .field-wrapper.datePickerBox .bsDatepicker {\n            cursor: pointer;\n            position: relative;\n            z-index: 1;\n            background: transparent; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table .table-data ul.editComp .edit-comp .field-wrapper.datePickerBox:after {\n            content: '';\n            background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n            position: absolute;\n            right: 0px;\n            top: 18px;\n            width: 21px;\n            height: 21px;\n            z-index: 0; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table .table-data ul.editComp .edit-comp .field-wrapper .date-clear {\n            position: absolute;\n            right: 60%;\n            top: 50px;\n            cursor: pointer;\n            color: #0084f6; }\n.pdc-container .pdc-wrapper .pdc-data-shell .pdc-table .table-data ul.actions a {\n          margin-right: 15px;\n          display: -webkit-inline-box;\n          display: -ms-inline-flexbox;\n          display: inline-flex;\n          text-decoration: none; }\n.save-pdf {\n  margin: 0px;\n  padding: 0px 20px;\n  background: #efefef; }\n.field-view {\n  margin-top: 10px;\n  border: none;\n  height: 30px; }\n.field-view a {\n    font-size: 13px;\n    margin-left: -4px; }\n/* ============================================================================================================= */\n.allocation-table {\n  width: 100%;\n  padding: 10px; }\n.allocation-table .table-responsive {\n    overflow: auto;\n    overflow-y: auto;\n    overflow-x: hidden; }\n.allocation-table table thead tr {\n    line-height: 30px; }\n.allocation-table table thead tr th {\n      font-weight: 600;\n      padding: 5px; }\n.allocation-table table tbody tr {\n    line-height: 20px; }\n.allocation-table table tbody tr .field-wrapper {\n      max-width: 100px;\n      left: 30%; }\n.allocation-table table tbody tr .field-wrapper .form-ctrl {\n        background: transparent;\n        text-align: center;\n        border-bottom: solid 1px #0084f6; }\n.allocation-table .table-footer {\n    width: 100%;\n    min-height: 40px;\n    padding: 5px 0px;\n    margin: 10px 0px; }\n.allocation-table .table-footer #allocateInv {\n      width: 100%; }\n/* ============================================================================================================= */\n/* ============================================================================================================= */\n.feeManager {\n  min-height: 400px;\n  max-height: 400px;\n  overflow-x: hidden;\n  overflow-y: auto; }\n.feeManager ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n.feeManager .fee-content {\n    max-height: 440px;\n    overflow-x: hidden;\n    overflow-y: auto; }\n.feeManager .row {\n    margin: 0px; }\n.feeManager .header {\n    border-bottom: 1px solid rgba(119, 119, 119, 0.733);\n    margin: 5px 0px; }\n.feeManager table .field-wrapper {\n    background: transparent;\n    width: 100%; }\n.feeManager table .field-wrapper .form-ctrl {\n      background: transparent;\n      border-bottom: solid 1px #0084f6;\n      text-align: center;\n      width: 150px; }\n.feeManager table .field-wrapper {\n    position: relative;\n    /* padding-top: 20px; */ }\n.feeManager table .field-wrapper.datePickerBox .bsDatepicker {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent; }\n.feeManager table .field-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 30px;\n      /* top: 0px; */\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n.feeManager table .field-wrapper .date-clear {\n      position: absolute;\n      right: 60%;\n      top: 50px;\n      cursor: pointer;\n      color: #0084f6; }\n.feeManager table tr {\n    line-height: 20px; }\n.feeManager table tr i {\n      font-size: 18px;\n      cursor: pointer; }\n.feeManager table tr td {\n      padding: 3px 20px; }\n.feeManager .installment {\n    border: 1px solid #777;\n    padding: 5px; }\n.feeManager .installment legend {\n      padding: 0.2em 0.5em;\n      border: 1px solid #0084f6;\n      color: #ffffff;\n      font-size: 14px;\n      font-weight: 600;\n      text-align: left;\n      width: 200px;\n      background: #0084f6; }\n.feeManager .installment .data-adder {\n      margin: 0px 0px 5px 0px; }\n.feeManager .installment .data-adder .outer .inner {\n        width: 30%;\n        display: -webkit-inline-box;\n        display: -ms-inline-flexbox;\n        display: inline-flex; }\n.feeManager .installment .data-adder .outer .inner .btn {\n          padding: 2px 0px 0px 7px;\n          border: none;\n          height: 35px;\n          width: 35px;\n          border-radius: 50%; }\n.feeManager .installment .data-adder .outer .inner .btn .tooltip {\n            position: relative;\n            top: -30px;\n            right: 50px;\n            min-width: 100px;\n            font-size: 12px;\n            padding: 6px;\n            height: 35px;\n            border-radius: 5px;\n            background: rgba(0, 0, 0, 0.774);\n            color: white;\n            visibility: hidden;\n            opacity: 0; }\n.feeManager .installment .data-adder .outer .inner .btn:hover {\n            background: #d8d6d6; }\n.feeManager .installment .data-adder .outer .inner .btn:hover .tooltip {\n              position: relative;\n              top: -65px;\n              right: 100px;\n              min-width: 160px;\n              padding: 6px;\n              border-radius: 5px;\n              font-size: 12px;\n              height: 35px;\n              background: rgba(0, 0, 0, 0.541);\n              color: white;\n              visibility: visible;\n              opacity: 1;\n              -webkit-transition: all 0.2s;\n              transition: all 0.2s; }\n.feeManager .installment .data-adder .outer .inner .btn:focus {\n            outline: none; }\n.feeManager .installment .data-adder .outer .inner .btn:active {\n            -webkit-box-shadow: none;\n                    box-shadow: none; }\n.feeManager .additional {\n    margin-top: 40px;\n    border: 1px solid #777;\n    padding: 5px; }\n.feeManager .additional legend {\n      padding: 0.2em 0.5em;\n      border: 1px solid #0084f6;\n      color: #ffffff;\n      font-size: 14px;\n      font-weight: 600;\n      text-align: left;\n      width: 200px;\n      background: #0084f6; }\n.feeManager .additional .data-adder {\n      margin: 0px 0px 5px 0px; }\n.feeManager .additional .data-adder .outer .inner {\n        width: 30%;\n        display: -webkit-inline-box;\n        display: -ms-inline-flexbox;\n        display: inline-flex; }\n.feeManager .additional .data-adder .outer .inner .btn {\n          padding: 2px 0px 0px 7px;\n          border: none;\n          height: 35px;\n          width: 35px;\n          border-radius: 50%; }\n.feeManager .additional .data-adder .outer .inner .btn .tooltip {\n            position: relative;\n            top: -30px;\n            right: 50px;\n            min-width: 100px;\n            font-size: 12px;\n            padding: 6px;\n            height: 35px;\n            border-radius: 5px;\n            background: rgba(0, 0, 0, 0.774);\n            color: white;\n            visibility: hidden;\n            opacity: 0; }\n.feeManager .additional .data-adder .outer .inner .btn:hover {\n            background: #d8d6d6; }\n.feeManager .additional .data-adder .outer .inner .btn:hover .tooltip {\n              position: relative;\n              top: -65px;\n              right: 100px;\n              min-width: 160px;\n              padding: 6px;\n              border-radius: 5px;\n              font-size: 12px;\n              height: 35px;\n              background: rgba(0, 0, 0, 0.541);\n              color: white;\n              visibility: visible;\n              opacity: 1;\n              -webkit-transition: all 0.2s;\n              transition: all 0.2s; }\n.feeManager .additional .data-adder .outer .inner .btn:focus {\n            outline: none; }\n.feeManager .additional .data-adder .outer .inner .btn:active {\n            -webkit-box-shadow: none;\n                    box-shadow: none; }\n.feeManager .additional .data-adder .outer .innermost {\n        display: -webkit-inline-box;\n        display: -ms-inline-flexbox;\n        display: inline-flex; }\n.feeManager .additional .data-adder .outer .innermost .field-wrapper {\n          width: 200px; }\n.feeManager .additional .data-adder .outer .innermost .btn {\n          padding: 2px 0px 0px 7px;\n          border: none;\n          height: 35px;\n          width: 35px;\n          border-radius: 50%; }\n.feeManager .additional .data-adder .outer .innermost .btn .tooltip {\n            position: relative;\n            top: -30px;\n            right: 50px;\n            min-width: 100px;\n            font-size: 12px;\n            padding: 6px;\n            height: 35px;\n            border-radius: 5px;\n            background: rgba(0, 0, 0, 0.774);\n            color: white;\n            visibility: hidden;\n            opacity: 0; }\n.feeManager .additional .data-adder .outer .innermost .btn:hover {\n            background: #d8d6d6; }\n.feeManager .additional .data-adder .outer .innermost .btn:hover .tooltip {\n              position: relative;\n              top: -65px;\n              right: 100px;\n              min-width: 160px;\n              padding: 6px;\n              border-radius: 5px;\n              font-size: 12px;\n              height: 35px;\n              background: rgba(0, 0, 0, 0.541);\n              color: white;\n              visibility: visible;\n              opacity: 1;\n              -webkit-transition: all 0.2s;\n              transition: all 0.2s; }\n.feeManager .additional .data-adder .outer .innermost .btn:focus {\n            outline: none; }\n.feeManager .additional .data-adder .outer .innermost .btn:active {\n            -webkit-box-shadow: none;\n                    box-shadow: none; }\ninput[type='number'] {\n  -moz-appearance: textfield; }\n/* Webkit browsers like Safari and Chrome */\ninput[type=number]::-webkit-inner-spin-button,\ninput[type=number]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0; }\n.bigPop .popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 00px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.bigPop .popupWrapper .popup {\n    max-width: 80%;\n    width: 80%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.enquiry-detail .field-wrapper {\n  position: relative;\n  padding-top: 10px; }\n.enquiry-detail .field-wrapper.datePickerBox .form-ctrl {\n    cursor: pointer;\n    position: relative;\n    z-index: 1;\n    background: transparent; }\n.enquiry-detail .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    right: 58px;\n    top: 30px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.enquiry-detail .field-wrapper .date-clear {\n    position: absolute;\n    right: 5px;\n    top: 25px;\n    cursor: pointer;\n    color: #0084f6; }\n.enquiry-detail .field-checkbox-wrapper {\n  margin: 20px 0px; }\n.fee-install-table {\n  max-height: 350px;\n  overflow: hidden; }\n.fee-install-table ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n.fee-install-table .table-responsive {\n    max-width: 100%;\n    max-height: 340px;\n    overflow-x: hidden;\n    overflow-y: scroll; }\n.fee-install-table th {\n    text-align: left; }\n.fee-install-table td {\n    padding: 10px 5px;\n    text-align: left; }\n.fee-install-table td .field-wrapper {\n      position: relative;\n      padding-top: 20px; }\n.fee-install-table td .field-wrapper.datePickerBox .bsDatepicker {\n        cursor: pointer;\n        position: relative;\n        z-index: 1;\n        background: transparent;\n        width: 120px; }\n.fee-install-table td .field-wrapper.datePickerBox:after {\n        content: '';\n        background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n        position: absolute;\n        left: 110px;\n        top: 2px;\n        width: 21px;\n        height: 21px;\n        z-index: 0; }\n.fee-install-table td .field-wrapper .date-clear {\n        position: absolute;\n        right: 60%;\n        top: 50px;\n        cursor: pointer;\n        color: #0084f6; }\n.student-flow-wrapper {\n  height: 82vh;\n  padding: 1%; }\n.toggle {\n  cursor: pointer;\n  display: inline-block; }\n.toggle-switch {\n  display: inline-block;\n  background: #0084f6;\n  border-radius: 16px;\n  width: 46px;\n  height: 16px;\n  position: relative;\n  vertical-align: middle;\n  -webkit-transition: background 0.25s;\n  transition: background 0.25s; }\n.toggle-switch:before, .toggle-switch:after {\n    content: \"\"; }\n.toggle-switch:before {\n    display: block;\n    background: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#eee));\n    background: linear-gradient(to bottom, #fff 0%, #eee 100%);\n    border-radius: 50%;\n    -webkit-box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.25);\n            box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.25);\n    width: 16px;\n    height: 16px;\n    position: absolute;\n    -webkit-transition: left 0.25s;\n    transition: left 0.25s; }\n.toggle:hover .toggle-switch:before {\n    background: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#fff));\n    background: linear-gradient(to bottom, #fff 0%, #fff 100%);\n    -webkit-box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.5);\n            box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.5); }\n.toggle-checkbox:checked + .toggle-switch {\n    background: #0084f6; }\n.toggle-checkbox:checked + .toggle-switch:before {\n      left: 30px; }\n.toggle-checkbox {\n  position: absolute;\n  visibility: hidden; }\n.toggle-label {\n  margin-left: 5px;\n  margin-right: 5px;\n  position: relative;\n  top: 2px;\n  font-weight: 600; }\n.active_toggle_button {\n  color: #00a2ff; }\n.inactive_toggle_button {\n  color: lightgray; }\n.map-courses {\n  margin: 15px 0 10px;\n  font-size: 13px; }\n.map-courses strong {\n    font-weight: 600; }\n.multiselect-wrapper {\n  padding: 5px;\n  border: 1px solid #deeaee;\n  position: relative;\n  z-index: 100;\n  background: white;\n  min-width: 300px;\n  min-height: 50px;\n  top: -26px; }\n.multiselect-wrapper .multiselect-wrapper-inner {\n    padding: 10px; }\n.multiselect-wrapper .multiselect-wrapper-inner ul li {\n      height: 40px;\n      padding: 10px 0px 0px 5px; }\n.other-detail-wrapper .row {\n  margin: 0px 15px; }\n.duplicate-contact-form .row {\n  margin: 15px; }\n.common-right-section:first-child {\n  margin-top: 15px; }\n.need-help {\n  padding-top: 8px; }\n.need-help .questionInfo {\n    margin-right: 2px;\n    height: 20px;\n    width: 20px;\n    display: inline-block;\n    vertical-align: middle; }\n.need-help .questionInfo .qInfoIcon {\n      color: #0084f6;\n      border-color: #0084f6;\n      width: 20px;\n      height: 20px;\n      border: 1px solid #ccc;\n      border-radius: 50%;\n      display: block;\n      text-align: center;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      line-height: 20px;\n      font-weight: 600;\n      font-size: 12px;\n      cursor: pointer;\n      -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n              box-shadow: 0px 0px 1px 0px #ccc inset;\n      color: #888;\n      -webkit-transition: all 0.2s linear;\n      transition: all 0.2s linear; }\n.need-help a {\n    font-size: 13px;\n    font-weight: 600; }\n.feeold-detail .btn {\n  margin-left: 0;\n  min-width: 150px;\n  margin-top: 20px;\n  margin-bottom: 10px; }\n.feeold-box {\n  min-height: 300px;\n  position: relative;\n  margin-bottom: 10px; }\n.apply-tax {\n  margin-top: 20px; }\n.installment-detail {\n  padding: 15px 0 0; }\n.feeold-install-table .table-responsive table th,\n.feeold-install-table .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.feeold-install-table .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.feeold-install-table .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.feeold-install-table .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.feeold-install-table .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.feeold-install-table .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .feeold-install-table .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.feeold-install-table .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.feeold-install-table .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.manage-additional-deal {\n  margin-bottom: 20px; }\n.feeold-detail-right .box-shadow-lite {\n  padding: 10px; }\n.feeold-detail-total-calc > div {\n  padding: 15px 0;\n  border-bottom: 1px solid #deeaee; }\n.feeold-detail-total-calc > div.total-feeold {\n    border-top: 1px solid #deeaee;\n    border-bottom: 0; }\n.feeold-detail-total-calc > div.total-feeold span {\n      font-size: 14px;\n      font-weight: bold; }\n.feeold-detail-total-calc > div.amount-paid {\n    padding: 10px;\n    background: #ebfdeb;\n    border: 1px solid #b8d0b8;\n    margin-bottom: 15px; }\n.feeold-detail-total-calc > div.amount-due {\n    padding: 10px;\n    background: #fdd9e0;\n    border: 1px solid #e1b0b9;\n    margin-bottom: 5px; }\n.feeold-detail-total-calc .fdtc-label {\n  font-size: 13px; }\n.feeold-detail-total-calc .fdtc-value {\n  font-size: 13px;\n  font-weight: 600;\n  text-align: right; }\n.feeold-detail-total-calc .fdtc-value a {\n    font-weight: 400;\n    font-size: 12px;\n    display: block;\n    color: inherit;\n    margin-top: 3px; }\n.radio-options {\n  text-align: center;\n  margin-top: 40px; }\n.radio-options > div {\n    display: inline-block;\n    margin-right: 10px;\n    margin-bottom: 15px; }\n.student-table {\n  overflow: inherit; }\n.student-table .fa-sticky-note-o {\n    font-size: 18px;\n    color: #333; }\n.allocation .form-type1 p {\n  margin-top: 4px; }\n.done-section {\n  padding: 20px 0;\n  border-bottom: 4px solid #ffd800;\n  min-height: 200px;\n  position: relative; }\n.done-section p {\n    font-size: 14px;\n    font-weight: 600;\n    max-width: 80%; }\n.done-section .close-btns {\n    position: absolute;\n    right: 10px;\n    top: 15px;\n    width: 20px;\n    height: 20px;\n    padding: 2px;\n    cursor: pointer;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box; }\n.done-section .btn {\n    position: absolute;\n    right: 0;\n    bottom: 20px;\n    width: 150px; }\n.middle-section {\n  padding: 0; }\n.boxPadding15, .middle-left, .middle-right, .middle-full {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 0 15px; }\n.middle-left {\n  width: 70%;\n  padding-bottom: 50px; }\n.middle-right {\n  width: 30%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 0 15px;\n  padding-bottom: 50px; }\n.form-type2 .questionInfo {\n  position: absolute;\n  right: 0px;\n  bottom: 5px;\n  z-index: 2; }\n.form-type2 .field-wrapper {\n  position: relative;\n  padding-top: 10px; }\n.form-type2 .field-wrapper.datePickerBox .form-ctrl {\n    cursor: pointer;\n    position: relative;\n    z-index: 1;\n    background: transparent; }\n.form-type2 .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    right: 40px;\n    top: 35px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n/*=====================================middle top section css===================*/\n.downloadbtn {\n  position: absolute;\n  right: 17px;\n  border-radius: 6px; }\n.middle-top {\n  padding-bottom: 10px;\n  margin: 10px; }\n.middle-top h1 {\n    margin-top: 8px; }\n.btn {\n  padding: 4px 10px;\n  background: #fff;\n  border: 1px solid #ccc;\n  margin-left: 10px;\n  display: inline-block;\n  font-size: 14px;\n  font-weight: 600;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 30px;\n  cursor: pointer;\n  color: #0084f6; }\n.btn.fullBlue {\n  background: #0084f6;\n  border: 1px solid #0084f6;\n  color: #fff; }\n.btn.cancle {\n  background: #fff;\n  border: 1px solid #ccc;\n  color: #0084f6;\n  font-size: 14px;\n  height: 35px; }\n.btn.redBtn {\n  background: #f44336;\n  border: 1px solid #f44336;\n  color: #fff;\n  font-size: 16px;\n  height: 40px; }\n/*==================================middle bottom css=========================*/\n.middle-bottom {\n  padding-top: 15px;\n  border-top: 1px solid #ccc;\n  margin-top: 15px; }\n.middle-bottom .field-checkbox-wrapper {\n    margin-top: 3px; }\n.middle-bottom .btn {\n    margin-left: 0;\n    margin-right: 10px; }\n.feeold-install-table {\n  margin: 10px 0px 0px 0px; }\n.feeold-install-table .table-responsive {\n    max-height: 400px; }\n.feeold-install-table .table-responsive table th,\n    .feeold-install-table .table-responsive table td {\n      text-align: center;\n      padding: 10px 5px; }\n.feeold-install-table .table-responsive table th {\n      text-transform: capitalize;\n      font-size: 14px; }\n.feeold-install-table .table-responsive table tbody tr td .field-checkbox-wrapper {\n      display: inline-block;\n      overflow: initial;\n      margin-left: 0;\n      width: auto;\n      position: relative;\n      background: transparent; }\n.feeold-install-table .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n        z-index: 2; }\n.feeold-install-table .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n        font-size: 16px;\n        margin-left: 7px;\n        font-weight: 600;\n        vertical-align: middle; }\n.feeold-install-table .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .feeold-install-table .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n          z-index: 1; }\n.feeold-install-table .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n        content: '';\n        width: 16px;\n        height: 16px;\n        background: #fff;\n        left: 0;\n        top: 0;\n        position: absolute; }\n.feeold-install-table .table-responsive table tbody tr td .fa-trash-o {\n      color: #f44336;\n      font-size: 20px; }\n/* import accordian css*/\n/*==========================Middle Enquiry CSS=================================*/\n.cls-1,\n.cls-2 {\n  fill: none; }\n.cls-1 {\n  stroke: #0084f6;\n  stroke-miterlimit: 10; }\n/* ======================= Right Side bar CSS =================================== */\n.shadow-box {\n  -webkit-box-shadow: 0px 2px 2px #7d7d7d;\n          box-shadow: 0px 2px 2px #7d7d7d;\n  padding: 7px;\n  border-radius: 2px;\n  background: #eff7ff; }\n.last-added-info {\n  font-size: 12px; }\n.last-added-info ul li {\n    line-height: normal;\n    padding: 2px 0;\n    display: inline-block;\n    width: 100%;\n    vertical-align: top; }\n.last-added-info strong {\n    font-weight: 600;\n    color: #28384a; }\n.last-added-info .view-details {\n    float: right;\n    font-size: 11px; }\n.last-added-info .view-details a:hover {\n      text-decoration: underline; }\n.last-added-info .enquiry-time {\n    float: right;\n    font-size: 10px;\n    color: #28384a;\n    margin-top: 4px; }\n/*=======================Right bottom lite shadow box======================*/\n.box-shadow-lite {\n  -webkit-box-shadow: 0px 1px 2px 0px #ccc;\n          box-shadow: 0px 1px 2px 0px #ccc;\n  padding: 10px 0 10px 10px;\n  border-top: 1px solid #e8e8e8; }\n.box-shadow-lite .field-wrapper {\n    padding-right: 40px; }\n.box-shadow-lite .field-wrapper .open-accor {\n      width: 17px;\n      font-size: 17px;\n      height: 17px;\n      line-height: 18px;\n      position: absolute;\n      right: 4px;\n      top: 19px;\n      z-index: 2; }\n.box-shadow-lite .field-wrapper:first-child {\n      margin-top: -10px; }\n.common-right-section {\n  margin-top: 30px; }\n.common-right-section h4 {\n    margin-bottom: 7px;\n    color: #28383A;\n    font-size: 16px; }\n.common-right-section h4 strong {\n      font-weight: 600; }\n.common-right-section .clear-detail {\n    margin-top: 10px;\n    font-size: 12px;\n    margin-bottom: 10px; }\n.follow-up-date-icon {\n  position: absolute;\n  position: absolute;\n  right: 7px;\n  top: 20px;\n  cursor: pointer; }\n.follow-up-date-icon img {\n    width: 21px; }\n.unstyled-calendar::-webkit-inner-spin-button,\n.unstyled-calendar::-webkit-calendar-picker-indicator {\n  -webkit-appearance: none; }\n/* ======================== Responsive Data ================================== */\n@media only screen and (max-width: 767px) {\n  .feeold-detail.row,\n  .installment-detail,\n  .student-flow-wrapper .middle-full.row,\n  .helpDetail.row,\n  .student-flow.row {\n    margin: 0; }\n  .student-flow-wrapper {\n    padding: 0; }\n  .allocation.row {\n    margin: 0; } }\n@media only screen and (max-width: 1100px) {\n  .student-table {\n    overflow: auto; }\n    .student-table .table-heading-menu {\n      display: none; } }\n.btn-diff .btn-header {\n  margin-right: 5px;\n  font-size: 14px;\n  font-weight: bold;\n  font-style: normal;\n  font-stretch: normal;\n  line-height: 1.36;\n  letter-spacing: normal;\n  text-align: center;\n  color: #00a2ff;\n  background: transparent; }\n.btn-diff .btn-header img {\n    display: inline-block;\n    vertical-align: middle; }\n.fee-summary {\n  margin-top: 5px; }\n.fee-summary ul {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between; }\n.fee-summary ul li {\n      width: auto; }\n.fee-summary ul li label {\n        font-size: 14px;\n        color: #666666;\n        display: block;\n        margin-bottom: 5px;\n        text-transform: uppercase; }\n.fee-summary ul li > div {\n        border-radius: 4px;\n        height: 64px;\n        width: 175px;\n        -ms-flex-wrap: nowrap;\n            flex-wrap: nowrap;\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-pack: justify;\n            -ms-flex-pack: justify;\n                justify-content: space-between;\n        -webkit-box-align: center;\n            -ms-flex-align: center;\n                align-items: center;\n        padding: 0 15px; }\n.fee-summary ul li > div span {\n          font-size: 14px;\n          font-weight: 600; }\n.fee-summary ul li > div span.feename {\n            font-size: 14px;\n            font-weight: 600;\n            max-width: 100px;\n            height: 50px;\n            overflow: auto;\n            text-overflow: ellipsis; }\n.fee-summary ul li > div a {\n          text-decoration: underline;\n          cursor: pointer; }\n.fee-summary ul li > div * {\n          color: #fff; }\n.fee-summary ul li > div.blue {\n          background: #24c4d0;\n          -webkit-box-shadow: 0 2px 2px rgba(83, 196, 208, 0.55);\n                  box-shadow: 0 2px 2px rgba(83, 196, 208, 0.55); }\n.fee-summary ul li > div.purple {\n          background: #b159f2;\n          -webkit-box-shadow: 0 2px 4px 0px rgba(177, 89, 242, 0.55);\n                  box-shadow: 0 2px 4px 0px rgba(177, 89, 242, 0.55); }\n.fee-summary ul li > div.yellow {\n          background: #fcc03d;\n          -webkit-box-shadow: 0 2px 4px 0px rgba(252, 192, 61, 0.58);\n                  box-shadow: 0 2px 4px 0px rgba(252, 192, 61, 0.58); }\n.fee-summary ul li > div.green {\n          background: #78dd95;\n          -webkit-box-shadow: 0 2px 4px 0px rgba(120, 221, 149, 0.55);\n                  box-shadow: 0 2px 4px 0px rgba(120, 221, 149, 0.55); }\n.fee-summary ul li > div.red {\n          background: #f44167;\n          -webkit-box-shadow: 0 2px 4px 0px rgba(244, 65, 103, 0.55);\n                  box-shadow: 0 2px 4px 0px rgba(244, 65, 103, 0.55); }\n.fee-summary ul li > div.gray {\n          background: #abaaaa;\n          -webkit-box-shadow: 0 2px 4px 0px rgba(171, 170, 170, 0.55);\n                  box-shadow: 0 2px 4px 0px rgba(171, 170, 170, 0.55); }\n.fd-heading {\n  padding-bottom: 10px; }\n.fee-detail-summary {\n  padding-top: 10px; }\n.fee-inst-list > ul > li {\n  border: 1px solid #ccc;\n  padding: 5px;\n  border-top: 0; }\n.fee-inst-list > ul > li.active, .fee-inst-list > ul > li:hover {\n    -webkit-box-shadow: inset 0 0px 4px 2px rgba(0, 0, 0, 0.08);\n            box-shadow: inset 0 0px 4px 2px rgba(0, 0, 0, 0.08); }\n.fee-inst-list > ul > li:first-child {\n    border-top: 1px solid #ccc; }\n.fee-inst-list > ul > li .inst-detail {\n    overflow: hidden;\n    padding-left: 12px; }\n.fee-inst-list .add-edit {\n  padding-left: 37px;\n  font-size: 14px;\n  margin-bottom: 5px;\n  margin-top: 5px; }\n.instl-info > ul > li {\n  display: inline-block;\n  margin-right: 70px;\n  margin-bottom: 10px; }\n.instl-info > ul > li label {\n    font-size: 10px;\n    color: rgba(0, 0, 0, 0.3);\n    display: block; }\n.instl-info > ul > li span {\n    font-size: 14px;\n    display: block;\n    color: #000;\n    margin-top: 6px; }\n.instl-info > ul > li:first-child span {\n    font-size: 18px;\n    color: rgba(0, 0, 0, 0.7);\n    font-weight: 600; }\n.inst-detail .inst-label {\n  font-size: 14px;\n  color: #000;\n  padding-bottom: 12px; }\n.fee-status {\n  display: inline-block;\n  border-radius: 4px;\n  padding: 4px 8px;\n  color: #fff;\n  font-size: 11px;\n  margin-left: 10px;\n  vertical-align: middle;\n  text-transform: uppercase; }\n.fee-status.paid {\n    background: #78dd95; }\n.fee-status.due {\n    background: #f44167; }\n.fee-status.upcoming {\n    background: #fcc03d; }\n.fee-status.partial {\n    background: #24c4d0; }\n.fd-btm {\n  margin-top: 20px; }\n.fd-btm .btn {\n    width: 172px;\n    border-radius: 3px; }\n.fd-btm .fd-btm-label {\n    font-size: 14px;\n    color: rgba(0, 0, 0, 0.8);\n    margin: 5px 0 15px; }\n.btn-diff .btn {\n  -webkit-transition: all 0.3s ease-in-out;\n  transition: all 0.3s ease-in-out; }\n.btn-diff .btn:hover {\n    background: #0084f6;\n    border: 1px solid #0084f6;\n    color: #fff;\n    color: #fff; }\n.btn-diff .btn:hover path {\n      fill: #fff; }\n@media only screen and (max-width: 1200px) {\n  .fee-summary ul {\n    display: block; }\n    .fee-summary ul li {\n      display: inline-block;\n      margin-right: 15px;\n      margin-bottom: 10px; } }\n@media only screen and (max-width: 767px) {\n  .fee-section-page {\n    padding: 10px 0; }\n  .instl-info > ul > li {\n    margin-top: 10px;\n    margin-bottom: 10px;\n    margin-right: 0;\n    float: left;\n    width: 50%;\n    min-height: 50px; }\n  .fee-summary ul li > div {\n    padding: 0 10px;\n    height: 58px;\n    width: 134px; }\n    .fee-summary ul li > div span {\n      font-size: 18px; } }\n.configureFee {\n  border-top: 1px solid rgba(97, 96, 96, 0.478431); }\n.configureFee ::-webkit-scrollbar {\n    display: block; }\n.configureFee .row {\n    margin: 0px 5px; }\n.configureFee .row .field-wrapper {\n      width: 40%; }\n.paymentWrapper {\n  border-top: 1px solid rgba(97, 96, 96, 0.478431); }\n.paymentWrapper ::-webkit-scrollbar {\n    display: block; }\n.paymentWrapper .paymentForm ::-webkit-scrollbar {\n    display: block; }\n.paymentWrapper .paymentForm .datePickerBox .bsDatepicker {\n    cursor: pointer;\n    position: relative;\n    z-index: 1;\n    background: transparent;\n    width: 95%; }\n.paymentWrapper .paymentForm .datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    right: 20px;\n    top: 30px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.paymentWrapper .row {\n    margin: 0px 10px; }\n.paymentWrapper .row .field-wrapper {\n      width: 250px; }\n.paymentWrapper .questionInfo {\n    position: relative;\n    left: 45%;\n    top: -17px;\n    height: 20px;\n    width: 20px;\n    z-index: 2; }\n#paydayClear {\n  color: red;\n  left: 105% !important;\n  top: 40px !important;\n  font-size: 14px; }\n.export-print {\n  margin-bottom: 10px; }\n.export-print .print-icon {\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%229177 266 26 22%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %23999%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1224%22 data-name%3D%22Group 1224%22 transform%3D%22translate(8100 -6)%22%3E%0D    %3Cg id%3D%22Group_1222%22 data-name%3D%22Group 1222%22%3E%0D      %3Cg id%3D%22Group_1212%22 data-name%3D%22Group 1212%22%3E%0D        %3Cpath id%3D%22Path_163%22 data-name%3D%22Path 163%22 class%3D%22cls-1%22 d%3D%22M37%2C22.478h4.174a1.047%2C1.047%2C0%2C0%2C0%2C1.043-1.043V12.043A1.047%2C1.047%2C0%2C0%2C0%2C41.174%2C11H39.087%22 transform%3D%22translate(1059.782 267.47)%22%2F%3E%0D        %3Cpath id%3D%22Path_164%22 data-name%3D%22Path 164%22 class%3D%22cls-1%22 d%3D%22M4.13%2C11H2.043A1.047%2C1.047%2C0%2C0%2C0%2C1%2C12.043v9.391a1.047%2C1.047%2C0%2C0%2C0%2C1.043%2C1.043H6.217%22 transform%3D%22translate(1077 267.47)%22%2F%3E%0D        %3Crect id%3D%22Rectangle_269%22 data-name%3D%22Rectangle 269%22 class%3D%22cls-1%22 width%3D%2213.565%22 height%3D%2210.435%22 transform%3D%22translate(1083.217 273)%22%2F%3E%0D        %3Crect id%3D%22Rectangle_270%22 data-name%3D%22Rectangle 270%22 class%3D%22cls-1%22 width%3D%2213.565%22 height%3D%225.217%22 transform%3D%22translate(1083.217 287.77)%22%2F%3E%0D        %3Cline id%3D%22Line_125%22 data-name%3D%22Line 125%22 class%3D%22cls-1%22 x2%3D%2219.826%22 transform%3D%22translate(1080.087 283.94)%22%2F%3E%0D        %3Cline id%3D%22Line_126%22 data-name%3D%22Line 126%22 class%3D%22cls-1%22 y2%3D%221.094%22 transform%3D%22translate(1080.609 286.128)%22%2F%3E%0D        %3Cline id%3D%22Line_127%22 data-name%3D%22Line 127%22 class%3D%22cls-1%22 y1%3D%226.564%22 transform%3D%22translate(1081.13 275.735)%22%2F%3E%0D        %3Cline id%3D%22Line_128%22 data-name%3D%22Line 128%22 class%3D%22cls-1%22 y1%3D%226.564%22 transform%3D%22translate(1098.87 275.735)%22%2F%3E%0D      %3C%2Fg%3E%0D      %3Crect id%3D%22Rectangle_690%22 data-name%3D%22Rectangle 690%22 class%3D%22cls-2%22 width%3D%2226%22 height%3D%2222%22 transform%3D%22translate(1077 272)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    color: #888; }\n.export-print .export-icon {\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%229268 266 26 22%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %23999%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1223%22 data-name%3D%22Group 1223%22 transform%3D%22translate(8100 -6)%22%3E%0D    %3Cg id%3D%22Group_1211%22 data-name%3D%22Group 1211%22 transform%3D%22translate(0 -1)%22%3E%0D      %3Cpath id%3D%22Path_178%22 data-name%3D%22Path 178%22 class%3D%22cls-1%22 d%3D%22M11.588%2C3H3.353A2.36%2C2.36%2C0%2C0%2C0%2C1%2C5.353V19.47a2.36%2C2.36%2C0%2C0%2C0%2C2.353%2C2.353H17.47a2.36%2C2.36%2C0%2C0%2C0%2C2.353-2.353V11.235%22 transform%3D%22translate(1170 272.176)%22%2F%3E%0D      %3Cline id%3D%22Line_140%22 data-name%3D%22Line 140%22 class%3D%22cls-1%22 y1%3D%2210%22 x2%3D%2210%22 transform%3D%22translate(1180.412 274.588)%22%2F%3E%0D      %3Cpath id%3D%22Path_179%22 data-name%3D%22Path 179%22 class%3D%22cls-1%22 d%3D%22M30.059%2C8.059V1.588A.556.556%2C0%2C0%2C0%2C29.47%2C1H23%22 transform%3D%22translate(1160.941 273)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Crect id%3D%22Rectangle_691%22 data-name%3D%22Rectangle 691%22 class%3D%22cls-2%22 width%3D%2226%22 height%3D%2222%22 transform%3D%22translate(1168 272)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    margin-left: 25px; }\n.export-print .print-icon,\n  .export-print .export-icon {\n    background-size: 20px auto;\n    padding: 0px 0px 0px 22px;\n    cursor: pointer;\n    font-size: 14px;\n    color: #888; }\n.export-print .print-icon:hover,\n    .export-print .export-icon:hover {\n      color: #0084f6; }\n/* @media print {\r\n    body, html * {\r\n      visibility: hidden;\r\n    }\r\n    #printView * {\r\n      visibility: visible;\r\n    }\r\n    #printView {\r\n      position: absolute;\r\n      left: 0;\r\n      top: 0;\r\n    }\r\n  } */\n.invertory-add {\n  margin-bottom: 10px;\n  padding: 10px; }\n.invertory-add .field-wrapper {\n    padding-top: 0; }\n.invertory-add .btn-section {\n    padding-top: 17px; }\n.table-section {\n  cursor: default;\n  font-size: 0.9em; }\n.table-section .table-rows {\n    display: inline-block;\n    width: 100%; }\n.table-section .table-rows .checkbox-div {\n      width: 30%;\n      display: inline-block; }\n.table-section .table-rows .checkbox-div label {\n        font-size: 14px;\n        font-weight: bold;\n        font-style: normal;\n        font-stretch: normal;\n        letter-spacing: normal;\n        text-align: left; }\n.table-section .table-rows .column-name {\n      width: 69%;\n      display: inline-block; }\n.table-section .table-rows .column-name div {\n        display: inline-block;\n        margin: 0 1em;\n        width: 10%; }\n.table-section .table-rows .column-name div.fee-amount {\n          width: 15% !important; }\n.table-section .table-rows .column-name div.status-amount {\n          width: 14% !important; }\n.table-section .table-rows .column-name div.amount {\n          text-align: right; }\n.table-section .installment-row:nth-child(odd) {\n    background: white; }\n.table-section .installment-row:nth-child(even) {\n    background: #ebebeb; }\n.table-section .field-checkbox-wrapper {\n    margin-bottom: 0;\n    display: inline-block; }\n.table-section .field-checkbox-wrapper label {\n      font-size: 14px;\n      font-weight: bold;\n      line-height: 1.36;\n      text-align: left;\n      color: #000000; }\n.table-section .course-installment {\n    padding: 20px 5px; }\n.inner-table {\n  width: 100%;\n  display: inline-block;\n  padding: 0 5px; }\n.inner-table .checkbox {\n    width: 15%;\n    display: inline-block; }\n.inner-table .checkbox label {\n      padding-left: 0px; }\n.inner-table .column-map {\n    width: 84%;\n    display: inline-block; }\n.inner-table .column-map div {\n      width: 10%;\n      display: inline-block; }\n.inner-table .column-map div.amount, .inner-table .column-map div.Tax, .inner-table .column-map div.discount, .inner-table .column-map div.balance {\n        text-align: right; }\n.inner-table .column-map div .balance {\n        margin-right: 5px; }\n.inner-table .column-map div span {\n        cursor: default; }\n.inner-table .column-map.paymentMode {\n      width: 16%; }\n.title-section {\n  background-color: #c8dbef !important;\n  padding: 10px 5px; }\n.title-section span {\n    font-size: 14px;\n    font-weight: bold;\n    line-height: 1.36;\n    text-align: left;\n    color: #000000;\n    cursor: default; }\n.status-amount span {\n  display: inline-block;\n  border-radius: 4px;\n  padding: 4px 8px;\n  color: #fff;\n  font-size: 11px;\n  vertical-align: middle;\n  text-transform: uppercase; }\n.status-amount span.paid {\n    background: #78dd95; }\n.status-amount span.due {\n    background: #f44167; }\n.status-amount span.upcoming {\n    background: #fcc03d; }\n.status-amount span.partial {\n    background: #24c4d0; }\n.academicYearFilter {\n  margin-left: 5px;\n  padding: 5px;\n  border: 1px solid lightgray;\n  margin-bottom: 5px; }\n.dd-list-container {\n  position: absolute;\n  border: 1px solid rgba(119, 119, 119, 0.29);\n  right: 15px;\n  z-index: 100;\n  top: 115px;\n  width: 200px;\n  height: auto;\n  background: white;\n  -webkit-box-shadow: 0px 0px 2px 0px rgba(0, 0, 0, 0.611765);\n          box-shadow: 0px 0px 2px 0px rgba(0, 0, 0, 0.611765); }\n.actions-menu {\n  list-style-type: none;\n  padding-left: 0;\n  margin-top: 0;\n  padding: 5px; }\n.actions-menu .action-item {\n    padding: 3px;\n    background: white;\n    display: -webkit-box !important;\n    display: -ms-flexbox !important;\n    display: flex !important;\n    margin: 0 !important;\n    cursor: pointer; }\n.actions-menu .action-item span {\n      padding: 5px 10px;\n      font-size: 12px;\n      font-weight: 600; }\n.actions-menu .action-item img {\n      max-width: 100%;\n      height: auto;\n      margin-right: 8px; }\n.actions-menu .action-item:hover {\n      background: #eff1f5; }\n.visibilityHidden {\n  visibility: hidden; }\n.card-layout {\n  margin-bottom: 10px; }\n.card-layout.oldDiscount div {\n    width: 13% !important; }\n.card-layout div {\n    width: 13% !important;\n    display: inline-block;\n    padding: 10px;\n    border-radius: 4px;\n    margin-right: 5px; }\n.card-layout div span {\n      text-align: left;\n      font-size: 11px;\n      font-weight: bold;\n      font-style: normal;\n      font-stretch: normal;\n      line-height: 1.36;\n      letter-spacing: normal;\n      text-align: left;\n      color: #ffffff;\n      cursor: default; }\n.card-layout div span.label {\n        padding: 0; }\n.card-layout div span.amount-Value {\n        font-size: 14px; }\n.card-layout .actual-Amount {\n    background: #ff8f36; }\n.card-layout .total-Amount {\n    background: #67e845; }\n.card-layout .tax-Amount {\n    background: #fcc03d; }\n.card-layout .discount-Amount {\n    background: #b159f2; }\n.card-layout .additional-Amount {\n    background: #59b4f2; }\n.card-layout .amount-Paid {\n    background: #78dd95; }\n.card-layout .amount-Due {\n    background: #f44167; }\n.actionDiv {\n  vertical-align: middle;\n  width: 5% !important; }\n.actionDiv .spanTitle:hover .dropdown-data {\n    display: block !important;\n    background: #efefef;\n    width: -webkit-max-content;\n    width: -moz-max-content;\n    width: max-content;\n    padding: 5px;\n    z-index: 99999;\n    opacity: 3;\n    -webkit-box-shadow: 0px 5px 6px 0px #dedede;\n            box-shadow: 0px 5px 6px 0px #dedede;\n    float: right;\n    border: 1pt solid #ddd;\n    position: relative;\n    margin-right: 2em; }\n.actionDiv .spanTitle:hover .dropdown-data li {\n      margin: 5px 0; }\n.actionDiv .spanTitle:hover .dropdown-data li a {\n        padding: 5px;\n        cursor: pointer; }\n.actionDiv svg {\n    -webkit-transform: rotate(90deg);\n            transform: rotate(90deg); }\n.actionDiv .dropdown-data {\n    display: none !important; }\n.tooltipDiv:hover .tooltip-content {\n  padding: 6px;\n  width: 200px;\n  background: white;\n  color: black;\n  -webkit-box-shadow: 0 0 3px inset;\n  box-shadow: 0 0 3px #784646;\n  margin-top: -30px;\n  margin-left: 30px;\n  position: absolute;\n  display: block;\n  border-radius: 0.2em;\n  cursor: default; }\n.tooltip-content {\n  display: none; }\n.iconStyling {\n  font-size: 1.3em;\n  text-align: center;\n  font-weight: 200;\n  padding: 0em 0.5em;\n  color: #797979;\n  vertical-align: top; }\n.elipsisText {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  width: 65%;\n  display: inline-block;\n  white-space: nowrap; }\n.popup-btn .btn {\n  font-size: 14px;\n  height: 30px;\n  padding: 4px 10px; }\n.middle-bottom {\n  position: absolute;\n  bottom: 0px;\n  width: 94%;\n  left: 5%;\n  background: white;\n  padding: 10px;\n  border-top: 1px solid rgba(10, 10, 10, 0.3);\n  /* margin-top: 10px; */ }\n.countryCallingCode {\n  float: left; }\nhomewrap {\n  max-height: 100vh;\n  overflow-x: auto;\n  overflow-y: scroll; }\nhomewrap ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\nhomewrap .scroll-content {\n    overflow-x: hidden;\n    padding-bottom: 15px; }\n.multiselect-wrapper {\n  padding: 5px;\n  border: 1px solid #deeaee;\n  position: relative;\n  z-index: 100;\n  background: white;\n  min-width: 400px;\n  min-height: 50px;\n  top: 0px; }\n.multiselect-wrapper .multiselect-wrapper-inner {\n    padding: 10px; }\n.multiselect-wrapper .multiselect-wrapper-inner ul li {\n      height: 40px;\n      padding: 10px 0px 0px 5px; }\n.institute-table table tr th {\n  text-align: left;\n  padding: 5px 20px;\n  font-size: 14px; }\n.institute-table table tr td {\n  text-align: left; }\n.institute-table table tr td:first-child {\n    padding-left: 20px !important; }\n.institute-table table tr td.edit-view-btn div {\n    display: inline-block; }\n.institute-table table tr td .field-wrapper {\n    background: transparent; }\n.institute-table table tr td .field-wrapper .invalid-alert {\n      color: red;\n      background: rgba(255, 255, 255, 0); }\n.institute-table table tr td .field-wrapper .form-ctrl {\n    display: block;\n    width: 100%;\n    background: transparent;\n    font: 400 12px 'Open sans',sans-serif;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 0px 0px 0px 6px;\n    outline: none;\n    border: 0;\n    border-bottom: solid 1px #0084f6;\n    height: 36px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 24px; }\n.institute-table table tr td .field-wrapper label {\n    position: absolute;\n    top: 22px;\n    font-size: 14px;\n    left: 0px;\n    -webkit-transition: all 0.2s ease-in-out;\n    transition: all 0.2s ease-in-out;\n    color: #777; }\n.institute-table table tr td .field-wrapper .form-ctrl:focus {\n    padding: 12px 0 6px;\n    border-bottom: solid 2px #0084f6;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    line-height: 26px; }\n.institute-table table tr td .field-wrapper.has-value .form-ctrl + label,\n  .institute-table table tr td .field-wrapper .form-ctrl:focus + label {\n    font: 400 12px 'Open sans',sans-serif;\n    top: 6px;\n    left: 0px; }\n.institute-table table tr td .field-wrapper.has-value .form-ctrl + label,\n  .institute-table table tr td .field-wrapper .form-ctrl:focus + label {\n    color: #0084f6;\n    font: 400 12px 'Open sans',sans-serif; }\n.institute-table table tr td:first-child {\n    padding-left: 50px; }\n.add-edit {\n  margin-bottom: 0;\n  margin-top: 10px; }\n.add-edit i {\n    display: inline-block;\n    width: 20px;\n    height: 20px;\n    border-radius: 50%;\n    line-height: 1rem;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle; }\n.add-edit span {\n    display: inline-block; }\n.add-edit .expend-box i {\n    line-height: 16px;\n    font-size: 16px; }\n.add-edit a {\n    cursor: pointer; }\n.sourceI {\n  cursor: pointer;\n  line-height: 20px;\n  position: absolute;\n  right: -35px;\n  bottom: 5px; }\n.iconPlus {\n  float: right;\n  width: 24px;\n  font-size: 24px;\n  height: 24px;\n  text-align: center;\n  border-radius: 50%;\n  line-height: 22px;\n  margin-right: 4px;\n  margin-top: 3px;\n  cursor: pointer;\n  color: #0084f6;\n  cursor: pointer; }\n.iconPlus:hover {\n    background: #0084f6;\n    color: white; }\n.enquiry-detail .field-wrapper {\n  position: relative;\n  padding-top: 10px; }\n.enquiry-detail .field-wrapper.datePickerBox .form-ctrl {\n    cursor: pointer;\n    position: relative;\n    z-index: 1;\n    background: transparent; }\n.enquiry-detail .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    right: 5px;\n    top: 28px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.enquiry-detail .field-wrapper .date-clear {\n    position: absolute;\n    right: 5px;\n    top: 28px;\n    cursor: pointer;\n    color: #0084f6; }\n.enquiry-detail .field-wrapper {\n  position: relative;\n  padding-top: 10px; }\n.enquiry-detail .field-wrapper.datePickerBox .form-ctrl {\n    cursor: pointer;\n    position: relative;\n    z-index: 1;\n    background: transparent; }\n.enquiry-detail .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    right: 50px;\n    top: 35px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.middle-section {\n  padding: 15px; }\n.boxPadding15, .middle-left, .middle-right, .middle-full {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 0 15px; }\n.middle-left {\n  width: 70%; }\n.middle-right {\n  width: 30%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 0 15px; }\n.accordian-section {\n  padding: 15px 10px 0; }\n.accordian-section .accordian-heading h4 {\n    font-size: 14px;\n    font-weight: 600;\n    color: #ddd; }\n.accordian-section .accordian-heading h4 .open-accor {\n      display: none;\n      float: right;\n      width: 24px;\n      font-size: 24px;\n      height: 24px;\n      text-align: center;\n      border: none;\n      border-radius: 50%;\n      line-height: 24px;\n      margin-right: 4px;\n      margin-top: 3px;\n      cursor: pointer;\n      color: #0084f6; }\n.accordian-section .accordian-heading h4 .close-accor {\n      float: right;\n      width: 24px;\n      font-size: 31px;\n      height: 24px;\n      text-align: center;\n      border: none;\n      border-radius: 50%;\n      line-height: 16px;\n      margin-right: 4px;\n      margin-top: 5px;\n      cursor: pointer;\n      color: #0084f6;\n      font-weight: 400; }\n.accordian-section .accordian-content {\n    padding-left: 50px; }\n.accordian-section .accordian > li {\n    position: relative;\n    padding-bottom: 25px; }\n.accordian-section .accordian > li:before {\n      content: '';\n      width: 1px;\n      height: 90.5%;\n      position: absolute;\n      background: #cccccc;\n      z-index: 0;\n      left: 15px;\n      top: 34px;\n      display: block; }\n.accordian-section .accordian > li:last-child:before {\n      display: none; }\n.accordian-section .accordian > li.active .circle-accor, .accordian-section .accordian > li.data-filled .circle-accor {\n      background: #0084f6;\n      color: #fff;\n      border-color: #0084f6; }\n.accordian-section .accordian > li.active .accordian-heading h4, .accordian-section .accordian > li.data-filled .accordian-heading h4 {\n      color: #333; }\n.accordian-section .accordian > li.data-filled .accordian-content {\n      display: none; }\n.accordian-section .accordian > li.data-filled .accordian-heading h4 {\n      color: #444;\n      border: 1px solid #eaecee;\n      padding: 1px;\n      border-radius: 20px;\n      background: #e6f2fe; }\n.accordian-section .accordian > li.data-filled .accordian-heading h4 .open-accor {\n        display: block; }\n.accordian-section .accordian > li.data-filled .accordian-heading h4 .close-accor {\n        display: none; }\n.accordian-section .accordian > li.data-filled.active .accordian-content {\n      display: block; }\n.accordian-section .accordian > li.data-filled.active .accordian-heading h4 .open-accor {\n      display: none; }\n.accordian-section .accordian > li.data-filled.active .accordian-heading h4 .close-accor {\n      display: block; }\n.more-detail {\n  margin-top: 10px;\n  font-size: 12px; }\n.circle-accor {\n  display: inline-block;\n  width: 32px;\n  border-radius: 50%;\n  text-align: center;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding-top: 4px;\n  font-size: 14px;\n  background: #f0f0f0;\n  height: 32px;\n  border: 1px solid #bbb;\n  margin-right: 5px;\n  color: #ceced1;\n  padding: 0;\n  line-height: 30px; }\n.form-type2,\n.form-type1 {\n  max-width: 360px; }\n.form-type2 .field-wrapper .invalid-alert,\n  .form-type1 .field-wrapper .invalid-alert {\n    color: red;\n    background: rgba(255, 255, 255, 0); }\n.paddingR30 {\n  padding-right: 30px; }\n.form-type2 .field-wrapper {\n  padding-right: 35px; }\n.form-type2 .customSelectWrapper:after {\n  right: 35px; }\n.newDate .field-wrapper {\n  margin: 15px 0; }\n.newDate .field-wrapper .date-clear {\n    position: absolute;\n    right: 5px;\n    top: 28px;\n    cursor: pointer;\n    color: #0084f6; }\n.newDate .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    left: 82% !important;\n    top: 32px !important;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.AdFilter-field .field-wrapper {\n  margin: 15px 0; }\n.AdFilter-field .field-wrapper .date-clear {\n    position: absolute;\n    right: -35px;\n    top: 35px;\n    cursor: pointer;\n    color: #0084f6; }\n.AdFilter-field .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    left: 92% !important;\n    top: 29px !important;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.questionInfo {\n  position: relative;\n  left: 100%;\n  top: -17px;\n  height: 20px;\n  width: 20px;\n  z-index: 2; }\n.questionInfo .tooltip-box-field {\n    color: black;\n    min-height: 22px;\n    width: 179px; }\n.questionInfo .qInfoIcon {\n    margin-left: 5px;\n    width: 20px;\n    height: 20px;\n    border: 1px solid #ccc;\n    border-radius: 50%;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    line-height: 20px;\n    font-weight: 600;\n    font-size: 12px;\n    cursor: pointer;\n    -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n            box-shadow: 0px 0px 1px 0px #ccc inset;\n    color: #888;\n    -webkit-transition: all 0.2s linear;\n    transition: all 0.2s linear; }\n.questionInfo .qInfoIcon:hover {\n      border-color: #0060A3;\n      -webkit-box-shadow: 0px 0px 1px 0px #0060A3 inset;\n              box-shadow: 0px 0px 1px 0px #0060A3 inset; }\n.create-institution {\n  position: absolute;\n  right: 15px;\n  bottom: 4px;\n  font-size: 25px; }\n.shadow-box {\n  -webkit-box-shadow: 0px 2px 2px #7d7d7d;\n          box-shadow: 0px 2px 2px #7d7d7d;\n  padding: 7px;\n  border-radius: 2px;\n  background: #eff7ff; }\n.last-added-info {\n  font-size: 12px; }\n.last-added-info ul li {\n    line-height: normal;\n    padding: 2px 0;\n    display: inline-block;\n    width: 100%;\n    vertical-align: top; }\n.last-added-info strong {\n    font-weight: 600;\n    color: #28384a; }\n.last-added-info .view-details {\n    float: right;\n    font-size: 11px; }\n.last-added-info .view-details a:hover {\n      text-decoration: underline; }\n.last-added-info .enquiry-time {\n    float: right;\n    font-size: 10px;\n    color: #28384a;\n    margin-top: 4px; }\n/*=======================Right bottom lite shadow box======================*/\n.box-shadow-lite {\n  -webkit-box-shadow: 0px 1px 2px 0px #ccc;\n          box-shadow: 0px 1px 2px 0px #ccc;\n  padding: 10px 0 10px 10px;\n  border-top: 1px solid #e8e8e8; }\n.box-shadow-lite .field-wrapper {\n    padding-right: 40px; }\n.box-shadow-lite .field-wrapper .open-accor {\n      width: 17px;\n      font-size: 17px;\n      height: 17px;\n      line-height: 18px;\n      position: absolute;\n      right: 4px;\n      top: 19px;\n      z-index: 2; }\n.box-shadow-lite .field-wrapper:first-child {\n      margin-top: -10px; }\n.common-right-section {\n  margin-top: 30px; }\n.common-right-section h4 {\n    margin-bottom: 7px;\n    color: #28383A;\n    font-size: 16px; }\n.common-right-section h4 strong {\n      font-weight: 600; }\n.common-right-section .clear-detail {\n    margin-top: 10px;\n    font-size: 12px;\n    margin-bottom: 10px; }\n.follow-up-date-icon {\n  position: absolute;\n  position: absolute;\n  right: 7px;\n  top: 20px;\n  cursor: pointer; }\n.follow-up-date-icon img {\n    width: 21px; }\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.1s ease-in;\n  transition: all 0.1s ease-in; }\n.popupWrapper .popup {\n    max-width: 850px;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.1s ease-in;\n  transition: all 0.1s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.1s ease-in;\n  transition: all 0.1s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n/*=========================================registration popup form css==================*/\n.registration-fee-form {\n  overflow: hidden; }\n.print-output-section {\n  margin: 35px 0 25px;\n  border-top: 1px solid #deeaee;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  border-bottom: 1px solid #deeaee;\n  text-align: center;\n  font-size: 0; }\n.print-output-section li {\n    display: inline-block;\n    padding: 0 15px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    width: 25%;\n    border-right: 1px solid #deeaee;\n    font-size: 15px;\n    cursor: pointer;\n    color: #929292; }\n.print-output-section li:last-child {\n      border-right: 0; }\n.print-output-section li:hover {\n      color: #0084f6; }\n.print-output-section li svg {\n      width: 30px;\n      display: inline-block;\n      vertical-align: middle;\n      margin-right: 8px; }\n.print-output-section li svg .cls-1 {\n        stroke: none;\n        stroke: #929292; }\n.print-output-section li.svg-icon .cls-1 {\n      stroke: none; }\n.print-output-section li.svg-icon .cls-2 {\n      stroke: #929292; }\n.print-output-section li.svg-icon:hover .cls-2 {\n      stroke: #0084f6; }\n.print-output-section li:first-child:hover svg .cls-1 {\n      stroke: #0084f6; }\n/*=======================================confirmation =========================*/\n.confirmation-popup-content {\n  line-height: normal; }\n.confirmation-popup-content > div {\n    margin-bottom: 10px; }\n.confirmation-popup-content > div:first-child {\n      margin-bottom: 20px; }\n.confirmation-popup-content > div a,\n    .confirmation-popup-content > div p {\n      font-size: 16px;\n      line-height: 22px; }\n.confirmation-popup-content > div a {\n      font-weight: 600; }\n.confirmation-popup-content > div a:hover {\n      text-decoration: underline; }\n.confirmation-popup-content strong {\n    font-weight: 600; }\n.confirmation-popup-content .add-form-btns a {\n    margin-left: 20px;\n    font-size: 14px; }\n.popup-btn {\n  margin-top: 20px; }\n.popup-btn .btn {\n    font-size: 16px;\n    height: 40px;\n    /* color: #333; */ }\n.popup-btn .btn.redBtn {\n      color: #fff;\n      min-width: 160px; }\n.update-enquiry-form table th {\n  text-align: left;\n  padding: 10px;\n  font-size: 14px; }\n.update-enquiry-form table td {\n  text-align: left;\n  padding: 10px;\n  font-size: 14px; }\n.enquiry-update-history {\n  max-height: 110px;\n  overflow: auto; }\n.update-enquiry-form .row {\n  margin: 10px -15px 20px; }\n.confirmation-popup-content:after {\n  content: '';\n  height: 8px;\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  width: 100%;\n  background: #8bc34a; }\n.institute-editor {\n  overflow-x: hidden; }\n.institute-editor .row {\n    margin: 0 0 5px 0; }\n.institute-editor .input-section {\n    background: #efefef;\n    padding: 10px; }\n.institute-editor .input-section .field-wrapper {\n      padding-top: 0; }\n.institute-editor .input-section .field-wrapper .form-ctrl {\n        background: white; }\n.institute-editor .input-section .btn-grp {\n      padding-top: 16px; }\n.institute-editor .cursor-icon {\n    cursor: pointer; }\n.row.extraMargin {\n  margin: 10px -15px 20px; }\n@media only screen and (max-width: 767px) {\n  .middle-left {\n    width: 100%; }\n  .middle-right {\n    width: 100%;\n    padding: 0; }\n  .accordian-section {\n    padding: 15px 0px 0; }\n  .accordian-section .accordian-content {\n    padding-left: 40px; } }\n.middle-bottom {\n  position: absolute;\n  bottom: 0px;\n  width: 88%;\n  left: 11%;\n  background: white;\n  padding: 10px;\n  border-top: 1px solid rgba(10, 10, 10, 0.3);\n  z-index: 100;\n  /* margin-top: 10px; */ }\n.countryCallingCode {\n  float: left; }\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-edit/enquiry-edit.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EnquiryEditComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_rxjs_Rx__ = __webpack_require__("./node_modules/rxjs/_esm5/Rx.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_fetchprefilldata_service__ = __webpack_require__("./src/app/services/fetchprefilldata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_login_services_login_service__ = __webpack_require__("./src/app/services/login-services/login.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_enquiry_services_post_enquiry_data_service__ = __webpack_require__("./src/app/services/enquiry-services/post-enquiry-data.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_enquiry_services_popup_handler_service__ = __webpack_require__("./src/app/services/enquiry-services/popup-handler.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__services_multiBranchdata_service__ = __webpack_require__("./src/app/services/multiBranchdata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__services_closing_reason_service__ = __webpack_require__("./src/app/components/leads/services/closing-reason.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};












var EnquiryEditComponent = /** @class */ (function () {
    /* Return to login if Auth fails else return to enqiury list if no row selected found, else store the rowdata to local variable */
    function EnquiryEditComponent(prefill, router, pops, poster, login, route, auth, multiBranchService, service, commonServiceFactory) {
        var _this = this;
        this.prefill = prefill;
        this.router = router;
        this.pops = pops;
        this.poster = poster;
        this.login = login;
        this.route = route;
        this.auth = auth;
        this.multiBranchService = multiBranchService;
        this.service = service;
        this.commonServiceFactory = commonServiceFactory;
        this.isConvertToStudent = false;
        /* Variable Declarations */
        this.enqstatus = [];
        this.enqPriority = [];
        this.enqFollowType = [];
        this.enqAssignTo = [];
        this.enqStd = [];
        this.enqSub = [];
        this.enqScholarship = [];
        this.enqSub2 = [];
        this.school = [];
        this.sourceLead = [];
        this.refferedBy = [];
        this.occupation = [];
        this.lastDetail = [];
        this.confimationPop = false;
        this.updatePop = false;
        this.isProfessional = false;
        this.institute_enquiry_id = '';
        this.editEnqData = {
            name: "",
            country_id: "",
            phone: "",
            email: "",
            dob: '',
            gender: "",
            phone2: "",
            email2: "",
            curr_address: "",
            parent_name: "",
            parent_phone: "",
            parent_email: "",
            master_course_name: "",
            city: -1,
            area: -1,
            occupation_id: "-1",
            school_id: "-1",
            qualification: "",
            grade: "",
            enquiry_date: __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD'),
            standard_id: "-1",
            subject_id: "-1",
            subjectIdArray: null,
            referred_by: "-1",
            source_id: "-1",
            fee_committed: "",
            discount_offered: "",
            priority: "",
            enquiry: "",
            follow_type: "",
            followUpDate: "",
            religion: null,
            link: "",
            slot_id: null,
            closedReason: "",
            demo_by_id: "",
            status: "",
            assigned_to: "-1",
            followUpTime: "",
            lead_id: -1,
            enqCustomLi: [],
            source_instituteId: -1,
            walkin_followUpDate: '',
            walkin_followUpTime: '',
            courseIdArray: null,
            closing_reason_id: '-1',
            is_follow_up_time_notification: false
        };
        this.isUpdateComment = false;
        this.additionDetails = false;
        this.institute_id = "100123";
        this.todayDate = Date.now();
        this.isSourcePop = false;
        this.isInstitutePop = false;
        this.isRefferPop = false;
        this.componentPrefill = [];
        this.componentListObject = {};
        this.componentRenderer = [];
        this.isCustomComponentValid = true;
        this.isFormValid = false;
        this.submitError = false;
        this.addNextCheck = false;
        this.isEnquiryAdmin = false;
        this.updateFormComments = [];
        this.updateFormCommentsBy = [];
        this.updateFormCommentsOn = [];
        this.commentUpdater = [];
        this.customComponents = [];
        /* Model for Enquiry Update Popup Form */
        this.updateFormData = {
            comment: "",
            status: "",
            statusValue: "",
            institution_id: sessionStorage.getItem('institute_id'),
            isEnquiryUpdate: "Y",
            closedReason: null,
            slot_id: null,
            priority: "",
            follow_type: "",
            followUpDate: "",
            commentDate: __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD'),
            followUpTime: "",
            isEnquiryV2Update: "N",
            isRegisterFeeUpdate: "N",
            amount: null,
            paymentMode: null,
            paymentDate: null,
            reference: null,
        };
        this.hourArr = ['', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];
        this.minArr = ['', '00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55'];
        this.meridianArr = ['', "AM", "PM"];
        this.hour = '';
        this.minute = '';
        this.meridian = '';
        this.times = ['', '1 AM', '2 AM', '3 AM', '4 AM', '5 AM', '6 AM', '7 AM', '8 AM', '9 AM', '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM', '4 PM', '5 PM', '6 PM', '7 PM', '8 PM', '9 PM', '10 PM', '11 PM', '12 AM'];
        this.followUpTime = "";
        this.cityListDataSource = [];
        this.areaListDataSource = [];
        this.isMainBranch = "N";
        this.branchesList = [];
        this.subBranchSelected = false;
        this.course_standard_id = '-1';
        this.course_subject = [];
        this.course_mastercourse_id = '-1';
        this.course_course = [];
        this.masterCourseData = [];
        this.isEnquirySubmit = false;
        this.closingReasonDataSource = [];
        this.closingReasonOpen = false;
        this.isRippleLoad = false;
        this.instituteCountryDetObj = {};
        this.createNewReasonObj = {
            closing_desc: "",
            institution_id: this.service.institute_id
        };
        this.enquiryStatus = '0';
        this.walkintime = {
            hour: '',
            minute: ''
        };
        this.minuteArr = ['', '00', '15', '30', '45'];
        this.countryDetails = [];
        this.maxlength = 10;
        this.country_id = null;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        if (sessionStorage.getItem('userid') == null) {
            this.showErrorMessage('error', 'User not logged-in', "Please login to continue");
            this.router.navigateByUrl('/login');
        }
        else {
            this.institute_enquiry_id = this.route.snapshot.paramMap.get('id');
            this.fetchCommentData(this.route.snapshot.paramMap.get('id'));
        }
    }
    /* OnInit Initialized */
    EnquiryEditComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.isCityMandatory = sessionStorage.getItem('enable_routing');
        this.isEnquiryAdministrator();
        this.FetchEnquiryPrefilledData();
        this.updateEnquiryData();
        // Multi Branch Check
        this.auth.isMainBranch.subscribe(function (value) {
            _this.isMainBranch = value;
            if (_this.isMainBranch == "Y") {
                _this.editEnqData.source_instituteId = sessionStorage.getItem('institute_id');
                _this.multiBranchInstituteFound(_this.editEnqData.source_instituteId);
            }
        });
        this.multiBranchService.subBranchSelected.subscribe(function (res) {
            _this.subBranchSelected = res;
            if (_this.subBranchSelected) {
                _this.editEnqData.source_instituteId = sessionStorage.getItem('institute_id');
                var mainBranchID = sessionStorage.getItem('mainBranchId');
                if (mainBranchID != null) {
                    _this.multiBranchInstituteFound(mainBranchID);
                }
            }
        });
        console.log(this.editEnqData);
        this.fetchDataForCountryDetails();
        this.checklengthOfCountry();
    };
    EnquiryEditComponent.prototype.fetchDataForCountryDetails = function () {
        var encryptedData = sessionStorage.getItem('country_data');
        var data = JSON.parse(encryptedData);
        if (data.length > 0) {
            this.countryDetails = data;
            this.maxlength = this.countryDetails[0].country_phone_number_length;
            this.country_id = this.countryDetails[0].id;
            console.log(this.countryDetails);
        }
    };
    EnquiryEditComponent.prototype.checklengthOfCountry = function () {
        var _this = this;
        if (this.countryDetails.length <= 1) {
            this.countryDetails.forEach(function (element) {
                _this.instituteCountryDetObj = element;
            });
            this.editEnqData.country_id = this.instituteCountryDetObj.country_id;
            return true;
        }
        else {
            return false;
        }
    };
    EnquiryEditComponent.prototype.onChangeObj = function (event) {
        var _this = this;
        console.log(event);
        this.countryDetails.forEach(function (element) {
            if (element.id == event) {
                _this.instituteCountryDetObj = element;
                _this.maxlength = _this.instituteCountryDetObj.country_phone_number_length;
                _this.country_id = element.id;
            }
        });
    };
    EnquiryEditComponent.prototype.timeChanges = function (ev) {
        //
        if (ev.split(' ')[0] != '') {
            this.hour = ev.split(' ')[0];
            this.meridian = ev.split(' ')[1];
            //console.log(this.hour + "" +this.meridian)
        }
        else {
            this.hour = '';
            this.meridian = '';
        }
        this.notifyMeCheckBoxChangesDetect();
    };
    /* set the enquiry feilds for Form */
    EnquiryEditComponent.prototype.updateEnquiryData = function () {
        var _this = this;
        this.institute_enquiry_id = this.route.snapshot.paramMap.get('id');
        this.fetchCommentData(this.route.snapshot.paramMap.get('id'));
        var id = this.institute_enquiry_id;
        this.prefill.fetchEnquiryByInstituteID(id).subscribe(function (data) {
            _this.editEnqData = data;
            console.log(data);
            // this.editEnqData.country_id = this.instituteCountryDetObj.country_id;
            _this.countryDetails.forEach(function (element) {
                if (element.id == _this.editEnqData.country_id) {
                    _this.instituteCountryDetObj = element;
                    _this.maxlength = _this.instituteCountryDetObj.country_phone_number_length;
                    _this.country_id = element.id;
                }
            });
            _this.enquiryStatus = data.status;
            if (_this.editEnqData.courseIdArray != null && _this.editEnqData.courseIdArray.length) {
                _this.editEnqData.courseIdArray = _this.editEnqData.courseIdArray.map(function (el) { return parseInt(el); });
            }
            if (_this.editEnqData.subjectIdArray != null && _this.editEnqData.subjectIdArray.length) {
                _this.editEnqData.subjectIdArray = _this.editEnqData.subjectIdArray.map(function (el) { return parseInt(el); });
            }
            _this.actualAssignee = data.assigned_to;
            _this.editEnqData.dob = _this.editEnqData.dob == null ? null : _this.editEnqData.dob;
            if (data.followUpTime != '' && data.followUpTime != null && data.followUpTime != " :") {
                var followUpDateTime = __WEBPACK_IMPORTED_MODULE_3_moment__(data.followUpDate).format('YYYY-MM-DD') + " " + data.followUpTime;
                _this.hour = __WEBPACK_IMPORTED_MODULE_3_moment__(followUpDateTime).format('h');
                _this.followUpTime = __WEBPACK_IMPORTED_MODULE_3_moment__(followUpDateTime).format('h') + " " + __WEBPACK_IMPORTED_MODULE_3_moment__(followUpDateTime).format('a').toString().toUpperCase();
                _this.minute = __WEBPACK_IMPORTED_MODULE_3_moment__(followUpDateTime).format('mm');
                _this.meridian = __WEBPACK_IMPORTED_MODULE_3_moment__(followUpDateTime).format('a').toString().toUpperCase();
            }
            if (data.walkin_followUpDate != "" && data.walkin_followUpDate != "Invalid date" && data.walkin_followUpDate != null) {
                _this.editEnqData.walkin_followUpDate = data.walkin_followUpDate;
            }
            if (data.walkin_followUpTime != "" && data.walkin_followUpTime != null && data.walkin_followUpTime != ": ") {
                _this.walkintime = _this.breakTimeInToHrAndMin(data.walkin_followUpTime);
            }
            _this.updateCustomComponent(id);
            _this.fetchSubject(_this.editEnqData.standard_id);
            if (!_this.isProfessional) {
                _this.prefill.getMasterCourseData().subscribe(function (res) {
                    _this.masterCourseData = res;
                    if (_this.editEnqData.courseIdArray != null && _this.editEnqData.courseIdArray.length) {
                        _this.editEnqData.courseIdArray = _this.editEnqData.courseIdArray.map(function (el) { return parseInt(el); });
                    }
                    _this.courseMasterChange(_this.editEnqData.master_course_name);
                });
            }
            else if (_this.isProfessional) {
            }
            if (data.city != "" && data.city != null) {
                _this.onCitySelctionChanges(data.city);
            }
            if (_this.isMainBranch == 'Y' || _this.subBranchSelected == true) {
                _this.editEnqData.source_instituteId = sessionStorage.getItem('institute_id');
            }
        });
    };
    /* ============================================================================================================================ */
    /* ============================================================================================================================ */
    EnquiryEditComponent.prototype.fetchMasterCourseDetails = function () {
        var _this = this;
        this.prefill.getMasterCourseData().subscribe(function (res) {
            _this.masterCourseData = res;
        });
    };
    /* ============================================================================================================================ */
    /* ============================================================================================================================ */
    EnquiryEditComponent.prototype.getCustomComponents = function () {
        var tempArr = [];
        this.customComponents.forEach(function (e) {
            if (e.type == 5) {
                if (e.hasOwnProperty('value')) {
                    var dd = __WEBPACK_IMPORTED_MODULE_3_moment__(e.value).format("YYYY-MM-DD");
                    if (dd != '' && dd != "Invalid date" && dd != null) {
                        var obj = {};
                        obj.component_id = e.id;
                        obj.enq_custom_id = e.data.enq_custom_id;
                        obj.enq_custom_value = __WEBPACK_IMPORTED_MODULE_3_moment__(e.value).format("YYYY-MM-DD");
                        obj.comp_length = e.comp_length;
                        tempArr.push(obj);
                    }
                }
            }
            else {
                if (e.hasOwnProperty('value')) {
                    if (typeof e.value == 'string') {
                        if (e.value.trim() != '') {
                            var obj = {};
                            obj.component_id = e.id;
                            obj.enq_custom_id = e.data.enq_custom_id;
                            obj.enq_custom_value = e.value;
                            obj.comp_length = e.comp_length;
                            tempArr.push(obj);
                        }
                    }
                    else if (typeof e.value == 'boolean') {
                        if (e.value) {
                            var obj = {};
                            obj.component_id = e.id;
                            obj.enq_custom_id = e.data.enq_custom_id;
                            obj.enq_custom_value = "Y";
                            obj.comp_length = e.comp_length;
                            tempArr.push(obj);
                        }
                        else {
                            var obj = {};
                            obj.component_id = e.id;
                            obj.enq_custom_id = e.data.enq_custom_id;
                            obj.enq_custom_value = "N";
                            obj.comp_length = e.comp_length;
                            tempArr.push(obj);
                        }
                    }
                }
            }
        });
        return tempArr;
    };
    EnquiryEditComponent.prototype.fillCustomComponent = function (v, comp) {
        if (v) {
            this.customComponents.forEach(function (e) {
                if (e.id === comp.id) {
                    e.value = v;
                }
            });
        }
        else {
            this.customComponents.forEach(function (e) {
                if (e.id === comp.id) {
                    e.value = v;
                }
            });
        }
    };
    /* Function for Toggling Form Visibility */
    EnquiryEditComponent.prototype.toggleForm = function (event) {
        var eleid = event.srcElement.id;
        //console.log(eleid);
        if (eleid == "openBasic") {
            var academic = document.getElementById('academicDetails').classList;
            academic.remove('active');
            var basic = document.getElementById('basicDetails').classList;
            basic.add('active');
        }
        else if (eleid == "closeBasic") {
            var basic = document.getElementById('basicDetails').classList;
            basic.remove('active');
            var academic = document.getElementById('academicDetails').classList;
            academic.add('active');
        }
        else if (eleid == "openAcademic") {
            var basic = document.getElementById('basicDetails').classList;
            //console.log(basic);
            basic.remove('active');
            var academic = document.getElementById('academicDetails').classList;
            //console.log(academic);
            academic.add('active');
        }
        else if (eleid == "closeAcademic") {
            var academic = document.getElementById('academicDetails').classList;
            academic.remove('active');
            var basic = document.getElementById('basicDetails').classList;
            basic.add('active');
        }
    };
    /* Function to fetch prefill data for form creation */
    EnquiryEditComponent.prototype.FetchEnquiryPrefilledData = function () {
        var _this = this;
        this.prefill.getEnqStatus().subscribe(function (data) { _this.enqstatus = data; }, function (err) {
            //  console.log(err);
        });
        this.prefill.getEnqPriority().subscribe(function (data) { _this.enqPriority = data; }, function (err) {
            //  console.log(err);
        });
        this.prefill.getFollowupType().subscribe(function (data) { _this.enqFollowType = data; }, function (err) {
            //  console.log(err);
        });
        this.prefill.getAssignTo().subscribe(function (data) { _this.enqAssignTo = data; }, function (err) {
            // console.log(err);
        });
        this.prefill.getEnqStardards().subscribe(function (data) { _this.enqStd = data; }, function (err) {
            //  console.log(err);
        });
        this.prefill.getSchoolDetails().subscribe(function (data) { _this.school = data; }, function (err) {
            //  console.log(err);
        });
        this.prefill.getLeadSource().subscribe(function (data) { _this.sourceLead = data; }, function (err) {
            //  console.log(err);
        });
        this.prefill.getLeadReffered().subscribe(function (data) { _this.refferedBy = data; }, function (err) {
            //  console.log(err);
        });
        this.prefill.getOccupation().subscribe(function (data) { _this.occupation = data; }, function (err) {
            //  console.log(err);
        });
        this.prefill.fetchLastDetail().subscribe(function (data) {
            _this.lastDetail = data;
            var createTime = new Date(data.enquiry_creation_datetime);
            _this.lastUpdated = __WEBPACK_IMPORTED_MODULE_3_moment__(createTime).fromNow();
        }, function (err) {
            // console.log(err);
        });
        this.prefill.getCityList().subscribe(function (data) {
            _this.cityListDataSource = data;
        }, function (err) {
            //console.log(err);
        });
        this.getClosingReasons();
    };
    EnquiryEditComponent.prototype.updateCustomComponent = function (id) {
        var _this = this;
        this.prefill.fetchCustomComponentById(id)
            .subscribe(function (data) {
            _this.customComponents = [];
            if (data != null) {
                data.forEach(function (el) {
                    var max_length = el.comp_length == 0 ? 100 : el.comp_length;
                    var obj = {
                        data: el,
                        id: el.component_id,
                        is_required: el.is_required,
                        is_searchable: el.is_searchable,
                        label: el.label,
                        prefilled_data: _this.createPrefilledData(el.prefilled_data.split(',')),
                        selected: [],
                        selectedString: '',
                        type: el.type,
                        value: el.enq_custom_value,
                        comp_length: max_length
                    };
                    if (el.type == 4) {
                        obj = {
                            data: el,
                            id: el.component_id,
                            is_required: el.is_required,
                            is_searchable: el.is_searchable,
                            label: el.label,
                            prefilled_data: _this.createPrefilledDataType4(el.prefilled_data.split(','), el.enq_custom_value.split(','), el.defaultValue.split(',')),
                            selected: (el.enq_custom_value.trim().split(',').length == 1 && el.enq_custom_value.trim().split(',')[0] == "") ? _this.getDefaultArr(el.defaultValue) : el.enq_custom_value.split(','),
                            selectedString: (el.enq_custom_value.trim().split(',').length == 1 && el.enq_custom_value.trim().split(',')[0] == "") ? el.defaultValue : el.enq_custom_value,
                            type: el.type,
                            value: (el.enq_custom_value.trim().split(',').length == 1 && el.enq_custom_value.trim().split(',')[0] == "") ? el.defaultValue : el.enq_custom_value,
                            comp_length: max_length
                        };
                    }
                    if (el.type == 3) {
                        obj = {
                            data: el,
                            id: el.component_id,
                            is_required: el.is_required,
                            is_searchable: el.is_searchable,
                            label: el.label,
                            prefilled_data: _this.createPrefilledData(el.prefilled_data.split(',')),
                            selected: [],
                            selectedString: "",
                            type: el.type,
                            value: (el.enq_custom_value.trim().split(',').length == 1 && el.enq_custom_value.trim().split(',')[0] == "") ? el.defaultValue : el.enq_custom_value,
                            comp_length: max_length
                        };
                    }
                    if (el.type == 2) {
                        obj = {
                            data: el,
                            id: el.component_id,
                            is_required: el.is_required,
                            is_searchable: el.is_searchable,
                            label: el.label,
                            prefilled_data: _this.createPrefilledData(el.prefilled_data.split(',')),
                            selected: [],
                            selectedString: '',
                            type: el.type,
                            value: el.enq_custom_value == "Y" ? true : false,
                            comp_length: max_length
                        };
                    }
                    else if (el.type != 2 && el.type != 4 && el.type != 3) {
                        obj = {
                            data: el,
                            id: el.component_id,
                            is_required: el.is_required,
                            is_searchable: el.is_searchable,
                            label: el.label,
                            prefilled_data: _this.createPrefilledData(el.prefilled_data.split(',')),
                            selected: [],
                            selectedString: '',
                            type: el.type,
                            value: el.enq_custom_value,
                            comp_length: max_length
                        };
                    }
                    _this.customComponents.push(obj);
                });
            }
            _this.emptyCustomComponent = _this.componentListObject;
        }, function (err) {
        });
    };
    /* ============================================================================================================================ */
    /* ============================================================================================================================ */
    EnquiryEditComponent.prototype.getDefaultArr = function (d) {
        var a = [];
        a.push(d);
        return a;
    };
    /* ============================================================================================================================ */
    /* ============================================================================================================================ */
    EnquiryEditComponent.prototype.createPrefilledDataType4 = function (dataArr, selected, def) {
        var customPrefilled = [];
        if (selected.length != 0 && selected[0] != "") {
            dataArr.forEach(function (el) {
                var obj = {
                    data: el,
                    checked: selected.includes(el)
                };
                customPrefilled.push(obj);
            });
        }
        else {
            dataArr.forEach(function (el) {
                var obj = {
                    data: el,
                    checked: def.indexOf(el) != -1
                };
                customPrefilled.push(obj);
            });
        }
        return customPrefilled;
    };
    /* ============================================================================================================================ */
    /* ============================================================================================================================ */
    /* Custom Compoenent array creater */
    EnquiryEditComponent.prototype.createPrefilledData = function (dataArr) {
        var customPrefilled = [];
        dataArr.forEach(function (el) {
            var obj = {
                displayName: el.toLowerCase(),
                data: el,
                checked: false
            };
            customPrefilled.push(obj);
        });
        return customPrefilled;
    };
    /* if custom component is of type multielect then toggle the visibility of the dropdowm */
    EnquiryEditComponent.prototype.multiselectVisible = function (elid) {
        var targetid = elid + "multi";
        if (elid != null && elid != '') {
            if (document.getElementById(targetid).classList.contains('hide')) {
                document.getElementById(targetid).classList.remove('hide');
            }
            else {
                document.getElementById(targetid).classList.add('hide');
            }
        }
    };
    /* if custom component is of type multielect then update the selected or unselected data*/
    EnquiryEditComponent.prototype.updateMultiSelect = function (data, id) {
        this.customComponents.forEach(function (el) {
            if (el.id == id) {
                var x_1 = [];
                var y = el.prefilled_data;
                y.forEach(function (e) {
                    if (e.checked) {
                        x_1.push(e.data);
                    }
                });
                el.selected = x_1;
                el.selectedString = el.selected.join(',');
                el.value = el.selectedString;
            }
        });
    };
    /* Function to Toggle visibility of additional details div */
    EnquiryEditComponent.prototype.showAdditionDetails = function () {
        this.additionDetails = !this.additionDetails;
    };
    /* Function to fetch subject when user selects a standard from dropdown */
    EnquiryEditComponent.prototype.fetchSubject = function (value) {
        var _this = this;
        if (value != null && value != '' && value != '-1') {
            this.enqSub = [];
            this.editEnqData.standard_id = value;
            this.prefill.getEnqSubjects(this.editEnqData.standard_id).subscribe(function (data) {
                _this.enqSub = data;
            });
        }
        else {
            this.editEnqData.subject_id = '-1';
            this.editEnqData.subjectIdArray = [];
            this.enqSub = [];
        }
    };
    EnquiryEditComponent.prototype.validateAreaAndCityFields = function () {
        if (this.isCityMandatory == 1) {
            if (this.editEnqData.city == '-1') {
                this.showErrorMessage('error', 'City Is Mandatory', 'Please enter city details');
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return true;
        }
    };
    EnquiryEditComponent.prototype.submitRegisterForm = function () {
        this.isConvertToStudent = true;
        this.editEnqData.follow_type = "Walkin";
        this.editEnqData.walkin_followUpDate = __WEBPACK_IMPORTED_MODULE_3_moment__(new Date()).format('YYYY-MM-DD');
        this.editEnqData.walkin_followUpTime = this.getFollowupTime();
        this.submitForm();
    };
    /* Function to submit validated form data */
    EnquiryEditComponent.prototype.submitForm = function () {
        var _this = this;
        this.isEnquirySubmit = true;
        //Validates if the custom component required fields are selected or not
        var customComponentValidator = this.validateCustomComponent();
        /* Validate the predefine required fields of the form */
        this.isFormValid = this.ValidateFormDataBeforeSubmit();
        // Validate If Area And City Settings is enable
        var validate = this.validateAreaAndCityFields();
        if (validate == false) {
            return;
        }
        // Validate if closing reason is given for closed enquiry
        if (this.editEnqData.status == '1') {
            if (this.editEnqData.closing_reason_id == "0" || this.editEnqData.closing_reason_id == '-1') {
                this.showErrorMessage('error', '', 'Please enter closing reason of enquiry.');
                return;
            }
        }
        /* Upload Data if the formData is valid */
        if (this.isFormValid && customComponentValidator) {
            if (this.validateTime()) {
                var id = this.institute_enquiry_id;
                if (this.hour != '') {
                    this.editEnqData.followUpTime = this.hour + ":" + this.minute + " " + this.meridian;
                }
                this.editEnqData.enqCustomLi = this.getCustomComponents();
                this.editEnqData.dob = this.fetchDate(this.editEnqData.dob);
                this.editEnqData.enquiry_date = this.fetchDate(this.editEnqData.enquiry_date);
                this.editEnqData.followUpDate = this.fetchDate(this.editEnqData.followUpDate);
                if (this.editEnqData.courseIdArray == '-1') {
                    this.editEnqData.courseIdArray = null;
                }
                if (this.editEnqData.subjectIdArray == '-1') {
                    this.editEnqData.courseIdArray = null;
                }
                if (this.editEnqData.standard_id == '-1') {
                    this.editEnqData.standard_id = null;
                }
                /* isMainBranch,subBranchSelected */
                if (this.isMainBranch == "N" && this.subBranchSelected == false) {
                    this.editEnqData.source_instituteId = '-1';
                }
                else if (this.isMainBranch == "Y" && this.subBranchSelected == false) {
                    this.editEnqData.source_instituteId = this.editEnqData.source_instituteId;
                }
                if (this.isConvertToStudent == false) {
                    if (this.editEnqData.walkin_followUpDate == "" || this.editEnqData.walkin_followUpDate == "Invalid date") {
                        this.editEnqData.walkin_followUpDate = "";
                    }
                    else {
                        this.editEnqData.walkin_followUpDate = __WEBPACK_IMPORTED_MODULE_3_moment__(this.editEnqData.walkin_followUpDate).format('YYYY-MM-DD');
                    }
                    if (this.walkintime.hour == "" || this.walkintime.minute == "") {
                        this.editEnqData.walkin_followUpTime = "";
                    }
                    else {
                        if (this.walkintime.hour != "") {
                            var time = this.walkintime.hour.split(' ');
                            this.editEnqData.walkin_followUpTime = time[0] + ':' + this.walkintime.minute + " " + time[1];
                        }
                    }
                }
                if (this.editEnqData.follow_type == "Walkin") {
                    if (this.editEnqData.walkin_followUpDate == "") {
                        this.showErrorMessage('error', '', 'Please enter walkin date for follow up type walkin');
                        return;
                    }
                    if (this.editEnqData.walkin_followUpTime == "") {
                        this.showErrorMessage('error', '', 'Please enter walkin time for follow up type walkin');
                        return;
                    }
                }
                this.enquiryStatus = this.editEnqData.status;
                if (this.editEnqData.is_follow_up_time_notification == true) {
                    this.editEnqData.is_follow_up_time_notification = 1;
                }
                else {
                    this.editEnqData.is_follow_up_time_notification = 0;
                }
                this.poster.editFormUpdater(id, this.editEnqData).subscribe(function (data) {
                    _this.isEnquirySubmit = false;
                    if (data.statusCode == 200) {
                        _this.showErrorMessage('success', "", 'Enquiry updated successfully');
                        if (_this.isConvertToStudent) {
                            var obj = {
                                name: _this.editEnqData.name,
                                phone: _this.editEnqData.phone,
                                email: _this.editEnqData.email,
                                gender: _this.editEnqData.gender,
                                dob: _this.fetchDate(_this.editEnqData.dob),
                                parent_email: _this.editEnqData.parent_email,
                                parent_name: _this.editEnqData.parent_name,
                                parent_phone: _this.editEnqData.parent_phone,
                                enquiry_id: _this.institute_enquiry_id,
                                institute_enquiry_id: _this.institute_enquiry_id,
                                school_id: _this.editEnqData.school_id,
                                country_id: _this.editEnqData.country_id
                            };
                            if (!_this.isProfessional) {
                                obj.standard_id = _this.editEnqData.standard_id;
                            }
                            else {
                                obj.standard_id = _this.editEnqData.master_course_name;
                            }
                            sessionStorage.setItem('studentPrefill', JSON.stringify(obj));
                            _this.router.navigate(['/view/students/add']);
                        }
                        else {
                            _this.clearLocalAndRoute();
                        }
                    }
                    else if (data.statusCode != 200) {
                        _this.showErrorMessage('error', '', data.message);
                    }
                }, function (err) {
                    _this.isEnquirySubmit = false;
                    _this.showErrorMessage('error', "Error updating Enquiry", err.error.message);
                });
            }
            else {
                this.showErrorMessage('error', '', 'Please select a valid time for follow up');
            }
        }
        else {
            this.isEnquirySubmit = false;
        }
    };
    EnquiryEditComponent.prototype.getFollowupTime = function () {
        var hour = parseInt(__WEBPACK_IMPORTED_MODULE_3_moment__(new Date()).format('hh'));
        var min = __WEBPACK_IMPORTED_MODULE_3_moment__(new Date()).format('mm');
        var mer = __WEBPACK_IMPORTED_MODULE_3_moment__(new Date()).format('A');
        if (parseInt(min) % 5 != 0) {
            min = Math.ceil(parseInt(min) / 5) * 5;
            if (min >= 60) {
                min = '00';
                if (hour == 12) {
                    hour = '1';
                    if (mer == 'AM') {
                        mer = 'PM';
                    }
                    else {
                        mer = 'AM';
                    }
                }
                else {
                    hour += 1;
                    var formattedNumber = (hour).slice(-2);
                    hour = formattedNumber.toString();
                }
            }
        }
        return (hour + ":" + min + " " + mer);
    };
    EnquiryEditComponent.prototype.fetchDate = function (e) {
        if (e == null || e == '' || e == "Invalid date") {
            return '';
        }
        else {
            return __WEBPACK_IMPORTED_MODULE_3_moment__(e).format('YYYY-MM-DD');
        }
    };
    EnquiryEditComponent.prototype.validateTime = function () {
        /* some time selected by user or nothing*/
        if ((this.hour != '' && this.minute != '' && this.meridian != '') || (this.hour == '' && this.minute == '' && this.meridian == '')) {
            if (this.hour == "Invalid date") {
                this.hour = '';
            }
            if (this.minute == "Invalid date") {
                this.minute = '';
            }
            if (this.meridian == "INVALID DATE") {
                this.meridian = '';
            }
            return true;
        }
        else {
            return false;
        }
    };
    EnquiryEditComponent.prototype.validateCustomComponent = function () {
        var temp = true;
        this.customComponents.forEach(function (el) {
            //console.log(el);
            if (el.is_required == 'Y' && el.value == '') {
                if (temp) {
                    temp = false;
                }
            }
        });
        if (!temp) {
            this.showErrorMessage('error', 'Please add required field(s) in academics details section', '');
        }
        return temp;
    };
    /* Validate the Entire FormData Once Before Uploading= */
    EnquiryEditComponent.prototype.ValidateFormDataBeforeSubmit = function () {
        var phoneFlag = this.commonServiceFactory.phonenumberCheck(this.editEnqData.phone, this.maxlength, this.country_id);
        // if (this.commonServiceFactory.valueCheck(this.editEnqData.name.trim())) {
        //   return this.showErrorMessage('error', 'Enquirer Please enter name', '');
        // }
        // else
        if (phoneFlag == false || phoneFlag == 'noNumber') {
            if (phoneFlag == 'noNumber') {
                return this.showErrorMessage('error', 'Please enter valid contact no.', '');
            }
            else {
                var msg = 'Enter '.concat(this.maxlength).concat(' Digit Contact Number');
                return this.showErrorMessage('error', msg, '');
            }
        }
        else if (this.commonServiceFactory.checkValueType(this.editEnqData.enquiry_date)) {
            return this.showErrorMessage('error', 'Please select enquiry date ', '');
        }
        else if (this.commonServiceFactory.sourceValueCheck(this.editEnqData.source_id)) {
            return this.showErrorMessage('error', 'Please select enquiry source', '');
        }
        else if (this.editEnqData.parent_phone != "" || this.editEnqData.parent_phone != null) {
            var parentPhoneCheck = this.commonServiceFactory.phonenumberCheck(this.editEnqData.parent_phone, this.maxlength, this.country_id);
            if (parentPhoneCheck == false) {
                var msg = 'Enter '.concat(this.maxlength).concat(' Digit Contact Number');
                return this.showErrorMessage('error', msg, '');
            }
            else {
                return true;
            }
        }
        else if (this.editEnqData.phone2 != "" || this.editEnqData.phone2 != null) {
            var alternatePhoneCheck = this.commonServiceFactory.phonenumberCheck(this.editEnqData.phone2, this.maxlength, this.country_id);
            if (alternatePhoneCheck == false || phoneFlag == 'noNumber') {
                if (alternatePhoneCheck == 'noNumber') {
                    return this.showErrorMessage('error', 'Please enter valid contact no.', '');
                }
                else {
                    var msg = 'Enter '.concat(this.maxlength).concat(' Digit Contact Number');
                    return this.showErrorMessage('error', msg, '');
                }
            }
            else {
                return true;
            }
        }
        else {
            if (this.validateEnquiryDate()) {
                return true;
            }
            else {
                return this.showErrorMessage('error', '', 'Cannot set future enquiry date');
            }
        }
    };
    EnquiryEditComponent.prototype.showErrorMessage = function (objType, massage, body) {
        this.commonServiceFactory.showErrorMessage(objType, massage, body);
        return false;
    };
    EnquiryEditComponent.prototype.validateEnquiryDate = function () {
        var a = __WEBPACK_IMPORTED_MODULE_3_moment__();
        var b = __WEBPACK_IMPORTED_MODULE_3_moment__(this.editEnqData.enquiry_date);
        var d = a.diff(b);
        if (d < 0) {
            return false;
        }
        else {
            return true;
        }
    };
    /* Function to store the data of Custom Component in to Base64 encoded array string */
    EnquiryEditComponent.prototype.customComponentUpdated = function (val, data) {
        this.componentListObject[data.component_id].enq_custom_value = val;
    };
    /* Function to clear the form data */
    EnquiryEditComponent.prototype.clearFormData = function () {
        this.editEnqData = {
            name: "",
            phone: "",
            email: "",
            gender: "",
            phone2: "",
            email2: "",
            curr_address: "",
            parent_name: "",
            parent_phone: "",
            parent_email: "",
            city: -1,
            area: -1,
            occupation_id: "-1",
            school_id: "-1",
            master_course_name: "",
            qualification: "",
            grade: "",
            enquiry_date: __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD'),
            dob: '',
            standard_id: "-1",
            subject_id: "-1",
            subjectIdArray: [],
            referred_by: "-1",
            source_id: "-1",
            fee_committed: "",
            discount_offered: "",
            priority: "",
            enquiry: "",
            follow_type: "",
            followUpDate: "",
            religion: null,
            link: "",
            slot_id: null,
            closedReason: "",
            demo_by_id: "",
            status: "",
            assigned_to: "-1",
            followUpTime: "",
            lead_id: -1,
            enqCustomLi: [],
            walkin_followUpDate: '',
            walkin_followUpTime: '',
            closing_reason_id: '-1'
        };
        this.course_standard_id = '-1';
        this.course_mastercourse_id = '-1';
        this.hour = '';
        this.minute = '';
        this.meridian = '';
        this.customComponents.forEach(function (el) {
            el.value = '';
        });
        this.walkintime = {
            hour: '',
            minute: ''
        };
    };
    EnquiryEditComponent.prototype.clearLocalAndRoute = function () {
        this.clearFormData();
        sessionStorage.removeItem('institute_enquiry_id');
        this.router.navigateByUrl('/view/leads/enquiry');
    };
    EnquiryEditComponent.prototype.commentHandlerOpen = function () {
        this.isUpdateComment = true;
    };
    EnquiryEditComponent.prototype.commentHandlerClose = function () {
        this.isUpdateComment = false;
        this.updateFormData = {
            comment: "",
            status: "",
            statusValue: "",
            institution_id: sessionStorage.getItem('institute_id'),
            isEnquiryUpdate: "Y",
            closedReason: null,
            slot_id: null,
            priority: "",
            follow_type: "",
            followUpDate: "",
            commentDate: __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD'),
            followUpTime: "",
            isEnquiryV2Update: "N",
            isRegisterFeeUpdate: "N",
            amount: null,
            paymentMode: null,
            paymentDate: null,
            reference: null,
        };
    };
    EnquiryEditComponent.prototype.fetchCommentData = function (id) {
        var _this = this;
        this.prefill.fetchCommentsForEnquiry(id).subscribe(function (res) {
            _this.updateFormData.priority = res.priority;
            _this.updateFormData.follow_type = res.follow_type;
            _this.updateFormData.statusValue = res.statusValue;
            _this.updateFormData.status = res.status;
            _this.updateFormData.followUpDate = res.followUpDate;
            _this.updateFormData.commentDate = __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD');
            if (res.comments != null) {
                _this.updateFormComments = res.comments;
            }
            _this.updateFormCommentsOn = res.commentedOn;
            _this.updateFormCommentsBy = res.commentedBy;
        });
    };
    EnquiryEditComponent.prototype.notifyMeCheckBoxChangesDetect = function () {
        if (this.editEnqData.followUpDate != "" && this.editEnqData.followUpDate != null) {
            if (this.hour != "" && this.meridian != "" && this.minute != "") {
                // Do nothing
            }
            else {
                this.editEnqData.is_follow_up_time_notification = false;
            }
        }
        else {
            this.editEnqData.is_follow_up_time_notification = false;
        }
    };
    EnquiryEditComponent.prototype.pushUpdatedEnquiry = function () {
        var _this = this;
        var id = this.institute_enquiry_id;
        this.updateFormData.comment = this.updateFormData.comment;
        this.poster.updateEnquiryForm(id, this.updateFormData)
            .subscribe(function (res) {
            _this.showErrorMessage('success', 'Enquiry Updated', 'Your enquiry has been successfully submitted');
            _this.fetchCommentData(_this.route.snapshot.paramMap.get('id'));
            _this.commentHandlerClose();
        }, function (err) {
            _this.showErrorMessage('error', 'Failed To Update Enquiry', err.error.message);
        });
    };
    EnquiryEditComponent.prototype.isEnquiryAdministrator = function () {
        if (sessionStorage.getItem('permissions') == null || sessionStorage.getItem('permissions') == undefined
            || sessionStorage.getItem('permissions') == '' || sessionStorage.getItem('username') == 'admin') {
            this.isEnquiryAdmin = true;
        }
        else {
            var permissions = [];
            permissions = JSON.parse(sessionStorage.getItem('permissions'));
            /* User has permission to view all enquiries */
            if (permissions.includes('115')) {
                this.isEnquiryAdmin = true;
            }
            else {
                this.isEnquiryAdmin = false;
            }
        }
    };
    EnquiryEditComponent.prototype.clearEditEnquiryDate = function () {
        this.editEnqData.enquiry_date = "";
    };
    EnquiryEditComponent.prototype.clearEditFollowUpDate = function () {
        this.editEnqData.followUpDate = "";
        this.hour = '';
        this.minute = '';
        this.meridian = '';
    };
    EnquiryEditComponent.prototype.onCitySelctionChanges = function (event) {
        var _this = this;
        this.areaListDataSource = [];
        if (event != -1 && event != "" && event != null) {
            var obj = {
                city: event
            };
            this.prefill.getAreaList(obj).subscribe(function (res) {
                _this.areaListDataSource = res;
            }, function (err) {
                //console.log(err);
            });
        }
    };
    EnquiryEditComponent.prototype.multiBranchInstituteFound = function (id) {
        var _this = this;
        this.prefill.getAllSubBranches(id).subscribe(function (res) {
            _this.branchesList = res;
        }, function (err) {
            console.log(err);
        });
    };
    EnquiryEditComponent.prototype.branchUpdated = function (e) {
        var _this = this;
        this.editEnqData.source_instituteId = e;
        var sessid = sessionStorage.getItem('institute_id');
        this.prefill.fetchAssignedToData(e).subscribe(function (res) {
            _this.enqAssignTo = res;
            if (sessid == e) {
                _this.editEnqData.assigned_to = _this.actualAssignee;
            }
            else {
                _this.editEnqData.assigned_to = "-1";
            }
        }, function (err) {
            console.log(err);
        });
    };
    /* ============================================================================================================================ */
    /* ============================================================================================================================ */
    EnquiryEditComponent.prototype.courseMasterChange = function (e) {
        var _this = this;
        if (e != '-1') {
            this.masterCourseData.map(function (el) {
                if (el.master_course == e) {
                    if (el.coursesList == null || el.coursesList.length == 0) {
                        _this.course_course = [];
                    }
                    else {
                        _this.course_course = el.coursesList;
                    }
                }
            });
        }
        else {
            this.course_course = [];
        }
    };
    /* ============================================================================================================================ */
    /* ============================================================================================================================ */
    // Closing Reason Pop Up Function
    EnquiryEditComponent.prototype.getClosingReasons = function () {
        var _this = this;
        this.prefill.getClosingReasons().subscribe(function (res) {
            _this.closingReasonDataSource = res;
        }, function (err) {
            console.log(err);
        });
    };
    EnquiryEditComponent.prototype.closingReason = function () {
        this.closingReasonOpen = true;
    };
    EnquiryEditComponent.prototype.closeClosingReason = function () {
        this.closingReasonOpen = false;
    };
    EnquiryEditComponent.prototype.toggleReferAdd = function () {
        var icon = document.getElementById('add-refer-icon').innerHTML;
        if (icon == '+') {
            this.isNewRefer = true;
            document.getElementById('add-refer-icon').innerHTML = '-';
        }
        else if (icon == '-') {
            this.isNewRefer = false;
            document.getElementById('add-refer-icon').innerHTML = '+';
        }
    };
    EnquiryEditComponent.prototype.createNewReason = function () {
        var _this = this;
        if (this.createNewReasonObj.closing_desc == "") {
            this.showErrorMessage('error', '', "Closing reason can't be empty");
        }
        else {
            this.service.createReason(this.createNewReasonObj).subscribe(function (data) {
                _this.showErrorMessage('success', '', 'Reason created successfully');
                _this.getClosingReasons();
                _this.isNewRefer = false;
                document.getElementById('add-refer-icon').innerHTML = '+';
                _this.createNewReasonObj.closing_desc = "";
            }, function (error) {
                _this.errorMessage(error);
            });
        }
    };
    EnquiryEditComponent.prototype.editRowTable = function (row, index) {
        document.getElementById(("reason" + index).toString()).classList.remove('displayComp');
        document.getElementById(("reason" + index).toString()).classList.add('editComp');
    };
    EnquiryEditComponent.prototype.saveInformation = function (row, index) {
        var _this = this;
        var obj = {
            closing_desc: row.closing_desc,
            institution_id: this.service.institute_id
        };
        if (row.closing_desc == "") {
            this.showErrorMessage('error', '', "Closing reason can't be empty");
        }
        else {
            this.service.updateClosingReason(obj, row.closing_reason_id).subscribe(function (data) {
                _this.showErrorMessage('success', '', "Reason updated successfully");
                _this.getClosingReasons();
            }, function (err) {
                _this.errorMessage(err);
            });
        }
    };
    EnquiryEditComponent.prototype.cancelEditRow = function (index) {
        document.getElementById(("reason" + index).toString()).classList.add('displayComp');
        document.getElementById(("reason" + index).toString()).classList.remove('editComp');
    };
    EnquiryEditComponent.prototype.breakTimeInToHrAndMin = function (time) {
        var obj = {
            hour: '',
            minute: ''
        };
        obj.hour = time.split(':')[0] + " " + time.split(':')[1].split(' ')[1];
        obj.minute = time.split(':')[1].split(' ')[0];
        return obj;
    };
    EnquiryEditComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-enquiry-edit',
            template: __webpack_require__("./src/app/components/leads/enquiry/enquiry-edit/enquiry-edit.component.html"),
            styles: [__webpack_require__("./src/app/components/leads/enquiry/enquiry-edit/enquiry-edit.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_4__services_fetchprefilldata_service__["a" /* FetchprefilldataService */],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_7__services_enquiry_services_popup_handler_service__["a" /* PopupHandlerService */],
            __WEBPACK_IMPORTED_MODULE_6__services_enquiry_services_post_enquiry_data_service__["a" /* PostEnquiryDataService */],
            __WEBPACK_IMPORTED_MODULE_5__services_login_services_login_service__["a" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["ActivatedRoute"],
            __WEBPACK_IMPORTED_MODULE_8__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_9__services_multiBranchdata_service__["a" /* MultiBranchDataService */],
            __WEBPACK_IMPORTED_MODULE_10__services_closing_reason_service__["a" /* ClosingReasonService */],
            __WEBPACK_IMPORTED_MODULE_11__services_common_service__["a" /* CommonServiceFactory */]])
    ], EnquiryEditComponent);
    return EnquiryEditComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-home/action-button.component.html":
/***/ (function(module, exports) {

module.exports = "<button aria-expanded=\"true\" class=\"dropdown-trigger\" (click)=\"openMenu()\" id=\"openMenu\">\r\n    <span class=\"svg-icon-wrap\">\r\n        <span class=\"visually-hidden\"></span>\r\n        <div aria-hidden=\"true\" type=\"ellipsis-horizontal-icon\">\r\n            <svg viewBox=\"0 0 24 24\" width=\"24px\" height=\"24px\" x=\"0\" y=\"0\" preserveAspectRatio=\"xMinYMin meet\" class=\"artdeco-icon\"\r\n                focusable=\"false\">\r\n                <path d=\"M2,10H6v4H2V10Zm8,4h4V10H10v4Zm8-4v4h4V10H18Z\" class=\"large-icon\" style=\"fill: currentColor\"></path>\r\n            </svg>\r\n        </div>\r\n    </span>\r\n</button>\r\n\r\n<div class=\"dd-list-container\" *ngIf=\"showMenu\">\r\n    <div class=\"dropdown-list\">\r\n        <div class=\"dd-list-inner\">\r\n            <ul class=\"actions-menu\">\r\n\r\n                <li class=\"action-item\" (click)=\"openPopup('update')\">\r\n                    <a class=\"enq-act enq-act--one\" id=\"imagesAnch1\">\r\n                        <img src=\"./assets/images/update_enquiry.svg\" height=\"10\" width=\"20\"> Update Enquiry\r\n                    </a>\r\n                </li>\r\n\r\n                <li class=\"action-item\" (click)=\"NavigateToEdit()\">\r\n                    <a class=\"enq-act enq-act--two\" id=\"imagesAnch2\">\r\n                        <img src=\"./assets/images/edit_details.svg\" height=\"10\" width=\"20\">Edit Enquiry\r\n                    </a>\r\n                </li>\r\n                <li class=\"action-item\" *ngIf=\"rowData.status == 0 || rowData.status == 3 && hasDeleteAccess\" (click)=\"openPopup('delete')\">\r\n                    <a class=\"enq-act enq-act--three\" id=\"imagesAnch3\">\r\n                        <img src=\"./assets/images/delete_entry.svg\" height=\"10\" width=\"20\">Delete Enquiry\r\n                    </a>\r\n                </li>\r\n\r\n                <li class=\"action-item\" *ngIf=\"rowData.status !=12 && hasStudentAccess\" (click)=\"openPopup('convert')\">\r\n                    <a class=\"enq-act enq-act--four\" id=\"imagesAnch4\">\r\n                        <img src=\"./assets/images/convert_student.svg\" height=\"10\" width=\"20\">Convert to Admission\r\n                    </a>\r\n                </li>\r\n\r\n                <li class=\"action-item\" *ngIf=\"isProfessional && (rowData.status == 12|| rowData.status ==11)\" (click)=\"openPopup('payment')\">\r\n                    <a class=\"enq-act enq-act--five\" id=\"imagesAnch5\">\r\n                        <img src=\"./assets/images/reciept_preview.svg\" height=\"10\" width=\"20\">Registration Fees\r\n                    </a>\r\n                </li>\r\n\r\n                <li class=\"action-item\" (click)=\"openPopup('sms')\">\r\n                    <a class=\"enq-act enq-act--six\" id=\"imagesAnch6\">\r\n                        <img src=\"./assets/images/send_email.svg\" height=\"10\" width=\"20\">Send SMS\r\n                    </a>\r\n                </li>\r\n\r\n            </ul>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-home/action-button.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.dropdown-trigger {\n  background: white;\n  position: absolute;\n  right: 60px;\n  margin-top: 5px;\n  z-index: 100; }\n.svg-icon-wrap {\n  display: inline-block; }\n.visually-hidden {\n  display: block;\n  border: 0;\n  clip: rect(0 0 0 0);\n  height: 1px;\n  margin: -1px;\n  overflow: hidden;\n  padding: 0;\n  position: absolute;\n  white-space: nowrap;\n  width: 1px; }\n.dd-list-container {\n  position: absolute;\n  top: 40px;\n  border: 1px solid rgba(119, 119, 119, 0.29);\n  right: 50px;\n  z-index: 100;\n  width: 100%;\n  max-width: 250px;\n  height: auto;\n  background: white;\n  -webkit-box-shadow: 0px 0px 2px 0px rgba(0, 0, 0, 0.611765);\n          box-shadow: 0px 0px 2px 0px rgba(0, 0, 0, 0.611765); }\n.actions-menu {\n  list-style-type: none;\n  padding-left: 0;\n  margin-top: 0;\n  padding: 5px; }\n.actions-menu .action-item {\n    padding: 10px;\n    background: white;\n    cursor: pointer; }\n.actions-menu .action-item img {\n      max-width: 100%;\n      height: auto;\n      margin-right: 8px; }\n.actions-menu .action-item:hover {\n      background: #eff1f5; }\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-home/action-button.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ActionButtonComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_enquiry_services_popup_handler_service__ = __webpack_require__("./src/app/services/enquiry-services/popup-handler.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ActionButtonComponent = /** @class */ (function () {
    function ActionButtonComponent(pops, router, cd, renderer, eRef, auth) {
        this.pops = pops;
        this.router = router;
        this.cd = cd;
        this.renderer = renderer;
        this.eRef = eRef;
        this.auth = auth;
        /* Variable for displayng the popUp */
        this.showMenu = false;
        this.isProfessional = false;
        this.hasStudentAccess = false;
        /* message to describe which popup to be opened  */
        this.message = "";
        this.eventSelected = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.hasDeleteAccess = false;
    }
    /* OnInit function to listen the changes in message value from service */
    ActionButtonComponent.prototype.ngOnInit = function () { };
    ActionButtonComponent.prototype.ngOnChanges = function () {
        var _this = this;
        this.rowData;
        this.professionalStatus();
        this.pops.currentMessage.subscribe(function (message) { return _this.message = message; });
        this.pops.currentActionValue.subscribe(function (data) { return _this.isActionDisabled = data; });
        var permissions = [];
        this.setRoleAccess();
        this.cd.markForCheck();
    };
    /* open action menu on click */
    ActionButtonComponent.prototype.openMenu = function () {
        this.showMenu = !this.showMenu;
    };
    /* close action menu on events  */
    ActionButtonComponent.prototype.closeMenu = function () {
        this.showMenu = false;
    };
    /* function to determine which pop up has to be opened on parent component */
    ActionButtonComponent.prototype.openPopup = function (eventData) {
        this.pops.changeMessage(eventData);
    };
    /* if user select edit navigate him to edit page directly from here */
    ActionButtonComponent.prototype.NavigateToEdit = function () {
        this.router.navigate(['/view/leads/enquiry/edit/' + this.rowData.institute_enquiry_id]);
    };
    ActionButtonComponent.prototype.professionalStatus = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
    };
    ActionButtonComponent.prototype.setRoleAccess = function () {
        if (sessionStorage.getItem('permissions') == null || sessionStorage.getItem('permissions') == undefined
            || sessionStorage.getItem('permissions') == '' || sessionStorage.getItem('username') == 'admin') {
            this.hasStudentAccess = true;
            this.hasDeleteAccess = true;
        }
        else {
            var permissions = [];
            permissions = JSON.parse(sessionStorage.getItem('permissions'));
            if (permissions.includes('301')) {
                this.hasStudentAccess = true;
                this.hasDeleteAccess = false;
            }
            else if (permissions.includes('115')) {
                this.hasStudentAccess = false;
                // this.hasDeleteAccess = true;
            }
            else {
                this.hasStudentAccess = false;
                this.hasDeleteAccess = false;
            }
        }
    };
    ActionButtonComponent.prototype.onWindowClick = function (event) {
        if (this.eRef.nativeElement.contains(event.target)) {
        }
        else {
            this.showMenu = false;
        }
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], ActionButtonComponent.prototype, "rowData", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], ActionButtonComponent.prototype, "eventSelected", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["HostListener"])("document:click", ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], ActionButtonComponent.prototype, "onWindowClick", null);
    ActionButtonComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'enquiry-actions',
            template: __webpack_require__("./src/app/components/leads/enquiry/enquiry-home/action-button.component.html"),
            styles: [__webpack_require__("./src/app/components/leads/enquiry/enquiry-home/action-button.component.scss")],
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_enquiry_services_popup_handler_service__["a" /* PopupHandlerService */],
            __WEBPACK_IMPORTED_MODULE_2__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["Renderer2"],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], ActionButtonComponent);
    return ActionButtonComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-home/comment-tooltip.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CommentTooltipComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var CommentTooltipComponent = /** @class */ (function () {
    function CommentTooltipComponent(cd) {
        this.cd = cd;
        this.updateFormComments = [];
        this.updateFormCommentsBy = [];
        this.updateFormCommentsOn = [];
    }
    /* OnInit function to listen the changes in message value from service */
    CommentTooltipComponent.prototype.ngOnInit = function () {
        this.updateFormComments = this.rowData.comments;
        this.updateFormCommentsOn = this.rowData.commentedOn;
        this.updateFormCommentsBy = this.rowData.commentedBy;
        this.cd.markForCheck();
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], CommentTooltipComponent.prototype, "rowData", void 0);
    CommentTooltipComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'comment-tooltip',
            template: 
            /* HTML content for the rendered component with CSS style as well */
            "\n  <style>\n\n    .comment-tooltip-wrapper{\n        width: 100%;\n        margin: 5px 0px 20px 0px;\n    }\n\n    .comment-tooltip-wrapper .row{\n        margin: 5px;\n    }\n\n    hr.style-seven {\n        overflow: visible; /* For IE */\n        height: 10px;\n        border-style: solid;\n        border-color: rgba(0, 0, 0, 0.3);\n        border-width: 0px 0 0 0;\n        border-radius: 5px;\n    }\n    hr.style-seven:before { /* Not really supposed to work, but does */\n        display: block;\n        content: \"\";\n        height: 10px;\n        margin-top: 0px;\n        border-style: solid;\n        border-color: rgba(0, 0, 0, 0.3);\n        border-width: 0 0 1px 0;\n        border-radius: 5px;\n    }\n\n    .comment-header{\n        margin: 5px !important;\n    }\n\n    .comment-header .comment-by{ \n        font-size: 13px;\n        font-weight: 700;\n        text-decoration: underline;\n        text-transform: capitalize;\n        color: rgba(0, 0, 0, 0.6705882352941176);\n    }\n\n    .comment-header .comment-date{\n        font-size: 11px;\n        font-weight: 600;\n        color: rgba(0, 0, 0, 0.68);\n    }\n\n    .comment-data{\n        font-size: 13px;\n        margin: 5px 5px 5px 5px;\n        text-align: left;\n        padding-bottom: 1px;\n    }\n\n  </style>\n  \n  <div class=\"comment-tooltip-wrapper\" *ngFor=\"let item of updateFormComments; let i=index;\">\n        \n        <div class=\"row comment-header\">\n              <aside class=\"pull-left comment-by\">\n                  {{updateFormCommentsBy[i]}}\n              </aside>\n              <aside class=\"pull-right comment-date\">\n                  {{updateFormCommentsOn[i]| date:'dd-MMM-yyyy hh:mm a'}}\n              </aside>\n        </div>\n        <div class=\"row comment-data\">\n            {{updateFormComments[i]}}\n        </div>\n        <hr class=\"style-seven\">        \n    </div>\n  \n  ",
            changeDetection: __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectionStrategy"].OnPush
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"]])
    ], CommentTooltipComponent);
    return CommentTooltipComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-home/enquiry-home.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"flagJSON.isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"middle-section clearFix\" id=\"enquiryList\" #enquiryManager>\r\n  <!-- Main View -->\r\n  <aside class=\"middle-full\" #enqPage>\r\n    <!-- Navigation to other tabs -->\r\n    <section class=\"middle-top mb0 clearFix\">\r\n      <h1 class=\"pull-left\">\r\n        Enquiry List\r\n        <a class=\"hide\" id=\"enq_download\"></a>\r\n      </h1>\r\n\r\n      <aside class=\"headEnq pull-right\">\r\n\r\n        <div class=\"btn-container\">\r\n          <div class=\"btn-item\">\r\n            <p-splitButton label=\"{{varJson.selectedRowCount}} Enquiry Selected\" [model]=\"bulkAddItems\" *ngIf=\"varJson.selectedRowCount != 0\"></p-splitButton>\r\n          </div>\r\n          <div class=\"btn-item\">\r\n            <button type=\"button\" class=\"btn pull-right\" name=\"button\" routerLink='/view/leads/add'>\r\n              <i class=\"fa fa-plus\" aria-hidden=\"true\"></i>\r\n              &nbsp; Add Enquiry\r\n            </button>\r\n          </div>\r\n          <div class=\"btn-item\">\r\n            <button type=\"button\" class=\"btn pull-right\" name=\"button\" (click)=\"flagJSON.isEnquiryOptions = !flagJSON.isEnquiryOptions\">\r\n              More &nbsp;\r\n              <i class=\"fa fa-ellipsis-v\" aria-hidden=\"true\"></i>\r\n            </button>\r\n            <div class=\"more-info-container\" [ngClass]=\"{'visibiltyClass':(flagJSON.isEnquiryAdmin == false)}\" *ngIf=\"flagJSON.isEnquiryOptions\"\r\n              (mouseleave)=\"flagJSON.isEnquiryOptions = false\" #optMenu>\r\n              <div class=\"more-info-item\" (click)=\"downloadAllEnquiries()\" *ngIf=\"downloadEnquiryReportAccess\">\r\n                <i class=\"fa fa-file-excel-o\" aria-hidden=\"true\"></i>\r\n                &nbsp;\r\n                <span>Export</span>\r\n              </div>\r\n              <div class=\"more-info-item\" routerLink=\"upload\">\r\n                <i class=\"fa fa-upload\" aria-hidden=\"true\"></i>\r\n                &nbsp;\r\n                <span>Upload Enquiry</span>\r\n              </div>\r\n              <div *ngIf=\"varJson.showDownloadSummary && downloadEnquiryReportAccess\" class=\"more-info-item\" (click)=\"downloadSummaryReport()\" style=\"border-bottom: none;\">\r\n                <i class=\"fa fa-download\" aria-hidden=\"true\"></i>\r\n                &nbsp;\r\n                <span>Download Summary Report</span>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </aside>\r\n\r\n    </section>\r\n\r\n    <!-- Enquiry Page Start here -->\r\n    <section class=\"middle-main clearFix\" id=\"middleMainForEnquiryList\">\r\n      <!-- Search bar and Advance Filter -->\r\n      <section class=\"common-search-filter\" id=\"searchFilter\">\r\n        <div class=\"filter-search\">\r\n          <div class=\"filter-box clearFix\">\r\n            <!-- Search Bar -->\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6 pull-left\">\r\n              <div class=\"search-filter-wrapper\" id=\"adFilterExitVisible\">\r\n                <input #search type=\"text\" class=\"normal-field\" placeholder=\"Search Name/Contact/Enquiry No.\" style=\"font-size:12px; margin: 0px 5px 0px -5px;\"\r\n                  [(ngModel)]=\"varJson.searchBarData\" name=\"searchData\" (keyup.enter)=\"searchDatabase()\" id=\"searchBarData\">\r\n                <input type=\"button\" class=\"fullBlue btn\" value=\"Search\" (click)=\"searchDatabase()\" id=\"btnSearchData\" />\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Quick Filter -->\r\n            <div class=\"c-lg-3 c-md-3 c-sm-3 pull-left\">\r\n              <div id=\"qfilt\">\r\n                <quick-filter [inputList]=\"statFilter\" (selectedValue)=\"statusFilter($event)\" [modelName]=\"'enqList'\"></quick-filter>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Advance Filter Trigger -->\r\n            <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n              <span class=\"filter-right\" style=\"float: right;margin-right: 20px;margin-top: 10px;\">\r\n                <a href=\"javascript:void(0);\" id=\"adFilterOpen\" (click)=\"openAdFilter()\" class=\"openAdFilter\">Advance Filter\r\n                </a>\r\n                <a href=\"javascript:void(0);\" id=\"adFilterExit\" class=\"closeAdFilter hide\" (click)=\"closeAdFilter()\">\r\n                  <!-- <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"3712 291 16 16\">\r\n                      <g id=\"Group_1214\" data-name=\"Group 1214\" transform=\"translate(2700 -6)\">\r\n                          <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n                              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n                              <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n                          </g>\r\n                          <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\" />\r\n                      </g>\r\n                  </svg> -->\r\n                  <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" id=\"Capa_1\" x=\"0px\" y=\"0px\"\r\n                    viewBox=\"0 0 469.785 469.785\" style=\"enable-background:new 0 0 469.785 469.785;\" xml:space=\"preserve\">\r\n                    <g transform=\"matrix(1.25 0 0 -1.25 0 45)\">\r\n                      <g>\r\n                        <g>\r\n                          <path style=\"fill:#DD2E44;\" d=\"M228.294-151.753L367.489-12.558c11.116,11.105,11.116,29.116,0,40.22     c-11.105,11.116-29.104,11.116-40.22,0L188.073-111.533L48.866,27.663c-11.093,11.116-29.116,11.116-40.22,0     c-11.105-11.105-11.105-29.116,0-40.22l139.207-139.196L8.338-291.268c-11.116-11.116-11.116-29.116,0-40.22     c5.552-5.564,12.834-8.34,20.116-8.34c7.27,0,14.552,2.776,20.105,8.34l139.514,139.514l139.196-139.196     c5.564-5.552,12.834-8.34,20.116-8.34c7.27,0,14.552,2.788,20.105,8.34c11.116,11.105,11.116,29.104,0,40.22L228.294-151.753z\"\r\n                          />\r\n                        </g>\r\n                      </g>\r\n                    </g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g></g>\r\n                    <g>\r\n                    </g>\r\n                  </svg>\r\n                  Close Advance Filter\r\n                </a>\r\n              </span>\r\n              <section id=\"customizableTableSection\" class=\"login-tube\" style=\"position: absolute;right: 7px;\">\r\n                <nav style=\"margin-top: 10px;\">\r\n                  <ul class=\"login-nav\">\r\n                    <li class=\"pos-rel\">\r\n                      <i class=\"icons\">\r\n                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\">\r\n                          <path id=\"gearIcon\" d=\"M24 14.187v-4.374c-2.148-.766-2.726-.802-3.027-1.529-.303-.729.083-1.169 1.059-3.223l-3.093-3.093c-2.026.963-2.488 1.364-3.224 1.059-.727-.302-.768-.889-1.527-3.027h-4.375c-.764 2.144-.8 2.725-1.529 3.027-.752.313-1.203-.1-3.223-1.059l-3.093 3.093c.977 2.055 1.362 2.493 1.059 3.224-.302.727-.881.764-3.027 1.528v4.375c2.139.76 2.725.8 3.027 1.528.304.734-.081 1.167-1.059 3.223l3.093 3.093c1.999-.95 2.47-1.373 3.223-1.059.728.302.764.88 1.529 3.027h4.374c.758-2.131.799-2.723 1.537-3.031.745-.308 1.186.099 3.215 1.062l3.093-3.093c-.975-2.05-1.362-2.492-1.059-3.223.3-.726.88-.763 3.027-1.528zm-4.875.764c-.577 1.394-.068 2.458.488 3.578l-1.084 1.084c-1.093-.543-2.161-1.076-3.573-.49-1.396.581-1.79 1.693-2.188 2.877h-1.534c-.398-1.185-.791-2.297-2.183-2.875-1.419-.588-2.507-.045-3.579.488l-1.083-1.084c.557-1.118 1.066-2.18.487-3.58-.579-1.391-1.691-1.784-2.876-2.182v-1.533c1.185-.398 2.297-.791 2.875-2.184.578-1.394.068-2.459-.488-3.579l1.084-1.084c1.082.538 2.162 1.077 3.58.488 1.392-.577 1.785-1.69 2.183-2.875h1.534c.398 1.185.792 2.297 2.184 2.875 1.419.588 2.506.045 3.579-.488l1.084 1.084c-.556 1.121-1.065 2.187-.488 3.58.577 1.391 1.689 1.784 2.875 2.183v1.534c-1.188.398-2.302.791-2.877 2.183zm-7.125-5.951c1.654 0 3 1.346 3 3s-1.346 3-3 3-3-1.346-3-3 1.346-3 3-3zm0-2c-2.762 0-5 2.238-5 5s2.238 5 5 5 5-2.238 5-5-2.238-5-5-5z\"\r\n                            style=\"fill: #0084f6;\" />\r\n                        </svg>\r\n                      </i>\r\n                      <div class=\"dropdown\">\r\n                        <ul class=\"user-detail\">\r\n                          <li (click)=\"openPreferences()\" class=\"asHover\">\r\n                            <i class=\"fa fa-low-vision\" style=\"font-family: 'FontAwesome' ; display: inline-block;\"></i>\r\n                            <strong style=\"display: inline-block;\">Show/Hide Columns</strong>\r\n                          </li>\r\n                        </ul>\r\n                      </div>\r\n                    </li>\r\n                  </ul>\r\n                </nav>\r\n              </section>\r\n            </div>\r\n          </div>\r\n\r\n          <!-- Advance Filter Div Element -->\r\n          <div class=\"AdFilter-field hide\" id=\"advanced-filter-section\">\r\n            <!-- Status -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"enquiryStatus\">Enquiry Status</label>\r\n                <select id=\"enquiryStatus\" class=\"form-ctrl\" [(ngModel)]=\"advancedFilterForm.filtered_statuses\" name=\"status\">\r\n                  <option value=\"\"></option>\r\n                  <option *ngFor=\"let status of enqstatus\" [value]=\"status.data_key\">{{status.data_value}}</option>\r\n                </select>\r\n\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Campaigns -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper\" [ngClass]=\"{'has-value': advancedFilterForm.list_id != '-1' }\">\r\n                <label for=\"campaignList\">Campaigns</label>\r\n                <select id=\"campaignList\" class=\"form-ctrl\" [(ngModel)]=\"advancedFilterForm.list_id\" name=\"campaign\">\r\n                  <option value=\"-1\"></option>\r\n                  <option *ngFor=\"let campaign of campaignList\" [value]=\"campaign.list_id\">{{campaign.list_name}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Priority -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"enquiryPriority\">Enquiry Priority</label>\r\n                <select id=\"enquiryPriority\" class=\"form-ctrl\" [(ngModel)]=\"advancedFilterForm.priority\" name=\"priority\">\r\n                  <option></option>\r\n                  <option *ngFor=\"let priority of enqPriority\" [value]=\"priority.data_key\">\r\n                    {{priority.data_value}}\r\n                  </option>\r\n                </select>\r\n\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Followup Type -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"followupType\">Enquiry Follow up Type</label>\r\n                <select id=\"followupType\" class=\"form-ctrl\" [(ngModel)]=\"advancedFilterForm.follow_type\" name=\"followType\">\r\n                  <option></option>\r\n                  <option *ngFor=\"let follow of enqFollowType\" [value]=\"follow.data_key\">\r\n                    {{ follow.data_value }}\r\n                  </option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Slot -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\" *ngIf=\"flagJSON.isProfessional\">\r\n              <div id=\"slotwrapper\" class=\"field-wrapper\" (click)=\"multiselectVisible($event.target.id)\">\r\n                <label for=\"assignCourses\">Slots</label>\r\n                <input id=\"slot\" type=\"text\" [ngModel]=\"varJson.selectedSlotsString\" name=\"slots\" class=\"form-ctrl\" readonly=\"true\" />\r\n\r\n              </div>\r\n              <div id=\"slotmulti\" class=\"hide multiselect-wrapper\" (mouseleave)=\"multiselectVisible('slot')\">\r\n                <div class=\"multiselect-wrapper-inner\">\r\n                  <ul class=\"\">\r\n                    <li *ngFor=\"let slot of slots\">\r\n                      <div class=\"field-checkbox-wrapper\">\r\n\r\n                        <input type=\"checkbox\" value=\"\" name=\"slotLabel\" [(ngModel)]=\"slot.status\" (ngModelChange)=\"updateSlotSelected(slot)\" class=\"form-checkbox\"\r\n                          id=\"slotLabel\">\r\n                        <label for=\"slotLabel\">{{slot.label}}</label>\r\n                      </div>\r\n                    </li>\r\n                  </ul>\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Assigned -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\" *ngIf=\"flagJSON.isEnquiryAdmin\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"assignTo\">Assign To</label>\r\n                <select id=\"assignTo\" class=\"form-ctrl\" [(ngModel)]=\"advancedFilterForm.assigned_to\" name=\"assignTo\">\r\n                  <option></option>\r\n                  <option *ngFor=\"let assigned of enqAssignTo\" [value]=\"assigned.userid\">\r\n                    {{ assigned.name }}\r\n                  </option>\r\n                </select>\r\n\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Update Date -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4 hide\">\r\n              <div class=\"field-wrapper datePickerBox\">\r\n                <label for=\"updateDate\">Update Date</label>\r\n                <input type=\"text\" value=\"\" id=\"updateDate\" class=\"form-ctrl bsDatepicker dateFormat\" [(ngModel)]=\"advancedFilterForm.updateDate\"\r\n                  name=\"UD\" readonly=\"true\" bsDatepicker />\r\n\r\n                <span class=\"date-clear\" name=\"followupdate\" (click)=\"clearFilterType('updateDate')\">clear</span>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Update Date From -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper datePickerBox\">\r\n                <label for=\"enquiryDateTo\">Enquiry Changes From</label>\r\n                <input type=\"text\" value=\"\" id=\"enquiryDateTo\" class=\"form-ctrl bsDatepicker dateFormat\" [(ngModel)]=\"advancedFilterForm.updateDateFrom\"\r\n                  name=\"enquiryDateTo\" readonly=\"true\" bsDatepicker />\r\n\r\n                <span class=\"date-clear\" name=\"followupdate\" (click)=\"advancedFilterForm.updateDateFrom = ''\">clear</span>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Update Date To -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper datePickerBox\">\r\n                <label for=\"enquiryDateFrom\">Enquiry Changes To</label>\r\n                <input type=\"text\" value=\"\" id=\"enquiryDateFrom\" class=\"form-ctrl bsDatepicker dateFormat\" [(ngModel)]=\"advancedFilterForm.updateDateTo\"\r\n                  name=\"enquiryDateFrom\" readonly=\"true\" bsDatepicker />\r\n\r\n                <span class=\"date-clear\" name=\"followupdate\" (click)=\"advancedFilterForm.updateDateTo = ''\">clear</span>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Enquiry From Date -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper datePickerBox\">\r\n                <label for=\"enquiryFromDate\">Enquiry From Date</label>\r\n                <input type=\"text\" value=\"\" id=\"enquiryFromDate\" class=\"form-ctrl bsDatepicker dateFormat\" [(ngModel)]=\"advancedFilterForm.enquireDateFrom\"\r\n                  name=\"EFD\" bsDatepicker readonly=\"true\" />\r\n\r\n                <span class=\"date-clear\" name=\"followupdate\" (click)=\"clearFilterType('enquireDateFrom')\">clear</span>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Enquiry To Date -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper datePickerBox\">\r\n                <label for=\"enquiryToDate\">Enquiry To Date</label>\r\n                <input type=\"text\" value=\"\" id=\"enquiryToDate\" class=\"form-ctrl bsDatepicker dateFormat \" [(ngModel)]=\"advancedFilterForm.enquireDateTo\"\r\n                  name=\"ETD\" bsDatepicker readonly=\"true\" />\r\n\r\n                <span class=\"date-clear\" name=\"followupdate\" (click)=\"clearFilterType('enquireDateTo')\">clear</span>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Follow Up Date -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper datePickerBox\">\r\n                <label for=\"followDate\">Follow-Up Date</label>\r\n                <input type=\"text\" value=\"\" id=\"followDate\" class=\"form-ctrl bsDatepicker dateFormat\" [(ngModel)]=\"advancedFilterForm.followUpDate\"\r\n                  name=\"FD\" readonly=\"true\" bsDatepicker />\r\n\r\n                <span class=\"date-clear\" name=\"followupdate\" (click)=\"clearFilterType('followUpDate')\">clear</span>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Lead Sources  -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper\" [ngClass]=\"{'has-value': advancedFilterForm['id'] == '-1' }\">\r\n                <label for=\"sourceList\">Source</label>\r\n                <select id=\"sourceList\" class=\"form-ctrl\" [(ngModel)]=\"advancedFilterForm.source_id\" name=\"source\">\r\n                  <option value=\"-1\"></option>\r\n                  <option *ngFor=\"let source of sources\" [value]=\"source.id\">{{source.name}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Institute List  -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper\" [ngClass]=\"{'has-value': advancedFilterForm.school_id != '-1' }\">\r\n                <label for=\"schoolList\">Institute Name</label>\r\n                <select id=\"schoolList\" class=\"form-ctrl\" [(ngModel)]=\"advancedFilterForm.school_id\" name=\"school\">\r\n                  <option value=\"-1\"></option>\r\n                  <option *ngFor=\"let school of schools\" [value]=\"school.school_id\">{{school.school_name}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- City List  -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"cityList\">City</label>\r\n                <select id=\"cityList\" class=\"form-ctrl\" [(ngModel)]=\"advancedFilterForm.city\" name=\"cityList\" (ngModelChange)=\"onCitySelection($event)\">\r\n                  <option value=\"\"></option>\r\n                  <option *ngFor=\"let obj of cityList\" [value]=\"obj.city\">{{obj.city}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Area List  -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"areaList\">Area</label>\r\n                <select id=\"areaList\" class=\"form-ctrl\" [(ngModel)]=\"advancedFilterForm.area\" name=\"areaList\">\r\n                  <option value=\"\"></option>\r\n                  <option *ngFor=\"let obj of areaList\" [value]=\"obj.area\">{{obj.area}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- standard Course-->\r\n            <div *ngIf=\"!flagJSON.isProfessional\" class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"editStandard\">Standard</label>\r\n                <select id=\"editStandard\" class=\"form-ctrl\" [(ngModel)]=\"advancedFilterForm.standard_id\" (ngModelChange)=\"fetchEnquirySubject($event)\"\r\n                  name=\"editStandard\">\r\n                  <option value=\"-1\"></option>\r\n                  <option *ngFor=\"let std of enqStd\" [value]=\"std.standard_id\">{{std.standard_name}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <div *ngIf=\"!flagJSON.isProfessional\" class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <!-- subject Course -->\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"forSubject\">Subject</label>\r\n                <select multiple id=\"forSubject\" class=\"form-ctrl form-ctrl-multiple\" [(ngModel)]=\"advancedFilterForm.subjectIdArray\" name=\"subject\">\r\n                  <option *ngFor=\"let subject of enqSubject\" [value]=\"subject.subject_id\">{{subject.subject_name}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <div *ngIf=\"!flagJSON.isProfessional\" class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <!-- masterCourse course -->\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"editMc\">Master Course</label>\r\n                <select id=\"editMc\" class=\"form-ctrl\" name=\"editMc\" [(ngModel)]=\"advancedFilterForm.master_course_name\" (ngModelChange)=\"courseMasterChange($event)\">\r\n                  <option value=\"-1\"></option>\r\n                  <option *ngFor=\"let master of masterCourseData\" [value]=\"master.master_course\">{{master.master_course}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <div *ngIf=\"!flagJSON.isProfessional\" class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <!-- course course-->\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"editCC\">Course</label>\r\n                <select id=\"editCC\" class=\"form-ctrl form-ctrl-multiple\" [(ngModel)]=\"advancedFilterForm.courseIdArray\" name=\"editCC\" multiple>\r\n                  <option *ngFor=\"let cc of course_course\" [value]=\"cc.course_id\">{{cc.course_name}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <div *ngIf=\"flagJSON.isProfessional\" class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <!-- master Professional -->\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"editStandard\">Master Course</label>\r\n                <select id=\"editStandard\" class=\"form-ctrl\" [(ngModel)]=\"advancedFilterForm.standard_id\" (ngModelChange)=\"fetchEnquirySubject($event)\"\r\n                  name=\"editStandard\">\r\n                  <option value=\"-1\"></option>\r\n                  <option *ngFor=\"let std of enqStd\" [value]=\"std.standard_id\">{{std.standard_name}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <div *ngIf=\"flagJSON.isProfessional\" class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <!-- course Professional -->\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"forSubject\">Course</label>\r\n                <select id=\"forSubject\" class=\"form-ctrl form-ctrl-multiple\" [(ngModel)]=\"advancedFilterForm.subjectIdArray\" name=\"subject\"\r\n                  multiple>\r\n                  <option *ngFor=\"let subject of enqSubject\" [value]=\"subject.subject_id\">{{subject.subject_name}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Referred By -->\r\n            <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"ReferredBy\">Referred By</label>\r\n                <select id=\"ReferredBy\" class=\"form-ctrl\" [(ngModel)]=\"advancedFilterForm.referred_by\" name=\"referred_by\">\r\n                  <option value=\"-1\"></option>\r\n                  <option *ngFor=\"let source of referredByData\" [value]=\"source.id\">{{source.name}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <!-- Custom Component -->\r\n            <custom-enquiry *ngFor=\"let component of customComponents\">\r\n\r\n              <div class=\"c-lg-4 c-md-4 c-sm-4\" *ngIf=\"component.type == 1 && component.is_searchable == 'Y'\" input-def>\r\n                <div class=\"field-wrapper\" [ngClass]=\"{'has-value': component.value != ''}\">\r\n                  <label for=\"{{component.id}}\">{{component.label}} </label>\r\n                  <input type=\"text\" value=\"\" id=\"{{component.id}}\" [(ngModel)]=\"component.value\" class=\"form-ctrl\" name=\"{{component.label}}\"\r\n                  />\r\n\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-lg-4 c-md-4 c-sm-4\" *ngIf=\"component.type == 2 && component.is_searchable == 'Y'\" input-def>\r\n                <br>\r\n                <div class=\"field-checkbox-wrapper\">\r\n\r\n                  <input class=\"form-checkbox\" id=\"{{component.id}}\" type=\"checkbox\" [(ngModel)]=\"component.value\" name=\"{{component.label}}\"\r\n                    value=\"\">\r\n                  <label for=\"{{component.id}}\">{{component.label}} </label>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-lg-4 c-md-4 c-sm-4\" *ngIf=\"component.type == 3 && component.is_searchable == 'Y'\" input-def>\r\n                <div class=\"field-wrapper\" [ngClass]=\"{'has-value': component.value != ''}\">\r\n                  <label for=\"{{component.id}}\">{{component.label}} </label>\r\n                  <select id=\"{{component.id}}\" class=\"form-ctrl\" [(ngModel)]=\"component.value\" name=\"{{component.label}}\">\r\n                    <option value=\"\"></option>\r\n                    <option *ngFor=\"let opt of component.prefilled_data\" value=\"{{opt.data}}\">{{opt.displayName}}</option>\r\n                  </select>\r\n\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-lg-4 c-md-4 c-sm-4\" *ngIf=\"component.type == 4 && component.is_searchable == 'Y'\" input-def>\r\n                <div id=\"{{component.id}}wrapper\" class=\"field-wrapper\" (click)=\"multiselectVisible($event.target.id)\">\r\n                  <label for=\"{{component.id}}\">{{component.label}} </label>\r\n                  <input id=\"{{component.id}}\" type=\"text\" [ngModel]=\"component.selectedString\" name=\"{{component.label}}\" class=\"form-ctrl\"\r\n                    readonly=\"true\" />\r\n\r\n                </div>\r\n                <div id=\"{{component.id}}multi\" class=\"hide multiselect-wrapper\" (mouseleave)=\"multiselectVisible(component.id)\">\r\n                  <div class=\"multiselect-wrapper-inner\">\r\n                    <ul class=\"\">\r\n                      <li *ngFor=\"let opt of component.prefilled_data\">\r\n                        <div class=\"field-checkbox-wrapper\">\r\n\r\n                          <input type=\"checkbox\" value=\"\" name=\"{{opt.data}}\" [(ngModel)]=\"opt.checked\" (ngModelChange)=\"updateMultiSelect(opt, component.id)\"\r\n                            class=\"form-checkbox\" id=\"{{opt.data}}\">\r\n                          <label for=\"opt.data\">{{opt.data}}</label>\r\n                        </div>\r\n                      </li>\r\n                    </ul>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-lg-4 c-md-4 c-sm-4\" *ngIf=\"component.type == 5 && component.is_searchable == 'Y'\" input-def>\r\n                <div class=\"field-wrapper datePickerBox\" [ngClass]=\"{'has-value': component.value != 'Invalid date'}\">\r\n                  <label for=\"{{component.id}}\">{{component.label}} </label>\r\n                  <input type=\"text\" value=\"\" readonly=\"true\" id=\"{{component.id}}\" [(ngModel)]=\"component.value\" class=\"form-ctrl bsDatepicker\"\r\n                    name=\"{{component.label}}\" bsDatepicker />\r\n\r\n                </div>\r\n              </div>\r\n\r\n\r\n            </custom-enquiry>\r\n\r\n            <!-- Submitter -->\r\n            <div class=\"row\">\r\n              <div class=\"c-lg-12 c-md-12 c-sm-12\">\r\n                <div class=\"field-wrapper pull-left\">\r\n                  <input type=\"button\" class=\"btn filterSearchBtn\" value=\"Clear Filter\" (click)=\"clearFilterAdvanced()\" id=\"BtnClearAdvance\"\r\n                  />\r\n                </div>\r\n                <div class=\"field-wrapper pull-left\">\r\n                  <input type=\"button\" class=\"btn filterSearchBtn fullBlue\" value=\"Search Now\" (click)=\"filterAdvanced()\" id=\"BtnFilterAdvance\"\r\n                  />\r\n                </div>\r\n\r\n              </div>\r\n            </div>\r\n\r\n          </div>\r\n\r\n        </div>\r\n      </section>\r\n\r\n      <!-- Data Table and Pagination -->\r\n      <section class=\"search-data\">\r\n        <!-- Enquiry DataTable -->\r\n        <div class=\"\" id=\"table-main\" #tablemain>\r\n          <div class=\"table-scroll-wrapper\">\r\n            <div class=\"\">\r\n              <ng-robTable [records]=\"sourceEnquiry\" [reset]=\"flagJSON.isSideBar\" [defaultSort]=\"varJson.sortBy\" [tableName]=\"'enquiry'\"\r\n                [settings]=\"displayKeys\" (userRowSelect)=\"userRowSelect($event)\" (rowsSelected)=\"getRowCount($event)\" [dataStatus]=\"varJson.fetchingDataMessage\"\r\n                [key1]=\"'followUpDate'\" [primaryKey]=\"'institute_enquiry_id'\" (rowIdArr)=\"getSelectedEnquiries($event)\" (sortById)=\"sortTableById($event)\"\r\n                (sortDirection)=\"getDirection($event)\">\r\n              </ng-robTable>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <!-- Paginator Here -->\r\n        <div class=\"row filter-res pagination\" #pager id=\"pager\" style=\"width: 100%;\">\r\n          <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n            <pagination (goPage)=\"fectchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n              [page]=\"varJson.PageIndex\" [perPage]=\"varJson.displayBatchSize\" [sizeArr]=\"sizeArr\" (sizeChange)=\"updateTableBatchSize($event)\"\r\n              [count]=\"varJson.totalEnquiry\">\r\n            </pagination>\r\n          </div>\r\n\r\n        </div>\r\n      </section>\r\n    </section>\r\n\r\n  </aside>\r\n\r\n  <aside #mySidenav class=\"middle-full sidenav\" [ngClass]=\"{'hide': !flagJSON.isSideBar}\">\r\n    <div class=\"sidewrapper\">\r\n      <a href=\"javascript:void(0)\" title=\"close\" class=\"closebtn\" (click)=\"closeEnquiryFullDetails(); false; $event.stopPropagation()\"\r\n        id=\"closeAnch1\">\r\n        <svg viewBox=\"0 0 24 24\" width=\"24px\" height=\"24px\" x=\"0\" y=\"0\" preserveAspectRatio=\"xMinYMin meet\" class=\"artdeco-icon\"\r\n          focusable=\"false\">\r\n          <path d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" class=\"large-icon\"\r\n            style=\"fill: currentColor\"></path>\r\n        </svg>\r\n      </a>\r\n      <enquiry-sidebar *ngIf=\"flagJSON.isSideBar\" [enqAssignTo]=\"enqAssignTo\" [enquiryRow]=\"enquiryFullDetail\" [row]=\"selectedRow\"\r\n        [priorityArr]=\"enqPriority\" [sourceList]=\"sources\" [statusArr]=\"enqstatus\" [customComp]=\"customCompid\" [followupArr]=\"enqFollowType\"\r\n        (updateEnq)=\"virtualUpdateEnquiry($event)\" (cancelUpdate)=\"closeEnquiryFullDetails($event); false; $event.stopPropagation()\"\r\n        [mainBranchAdmin]=\"isMainBranch\" [subBranchAdmin]=\"flagJSON.subBranchSelected\" [branchesList]=\"branchesList\" (getUserList)=\"branchUpdated($event)\"\r\n        [masterCourseData]=\"masterCourseData\" [standardArr]=\"enqStd\" [subjectArr]=\"enqSubject\" (fullEnquiryDetails)=\"completeEnquiryDeatils($event)\"\r\n        [closingReasonDataSource]=\"closingReasonDataSource\">\r\n      </enquiry-sidebar>\r\n    </div>\r\n  </aside>\r\n\r\n  <!-- Enquiry update popup -->\r\n  <app-enquiry-update-popup *ngIf=\"varJson.message === 'update'\" [enqData]=\"varJson.enquiryInfo\" (closePopUp)=\"closeUpdatePop($event)\"></app-enquiry-update-popup>\r\n\r\n\r\n  <!-- Delete PopUp -->\r\n  <section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"varJson.message === 'delete'\">\r\n    <div class=\"popup pos-abs\">\r\n      <div class=\"popup-wrapper pos-rel\">\r\n        <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closePopup()\">\r\n          <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\"\r\n            width=\"24px\" x=\"0\" y=\"0\">\r\n            <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\"\r\n              style=\"fill: currentColor\"></path>\r\n          </svg>\r\n        </span>\r\n        <div class=\"popup-content\">\r\n          <h2>Delete Enquiry - Enquiry No: {{selectedRow.enquiry_no}}</h2>\r\n          <div class=\"update-enquiry-form overflowHidden\">\r\n            <div class=\"enquiry-update-history\">\r\n              <h4>Are you Sure you wish to delete this data, it cannot be recovered later.</h4>\r\n            </div>\r\n            <div class=\"\">\r\n              <div class=\"clearfix\">\r\n                <aside class=\"pull-right popup-btn\">\r\n                  <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closePopup()\" id=\"BtncancelClose\">\r\n                  <input type=\"button\" value=\"Delete\" class=\"fullBlue btn\" (click)=\"deleteEnquiry()\" id=\"BtndeleteClose\">\r\n                </aside>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <!-- Convert PopUp -->\r\n  <section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"varJson.message === 'convert'\">\r\n    <div class=\"popup pos-abs\">\r\n      <div class=\"popup-wrapper pos-rel\">\r\n        <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closePopup()\">\r\n          <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\"\r\n            width=\"24px\" x=\"0\" y=\"0\">\r\n            <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\"\r\n              style=\"fill: currentColor\"></path>\r\n          </svg>\r\n        </span>\r\n\r\n        <!-- If Not converted -->\r\n        <div class=\"popup-content\" *ngIf=\"!flagJSON.isConverted\">\r\n          <h2>Convert Enquiry - Enquiry No: {{selectedRow.enquiry_no}}</h2>\r\n          <div class=\"update-enquiry-form overflowHidden\">\r\n            <div class=\"enquiry-update-history\">\r\n              <h4> You will be converting {{selectedRow.name}} to student, this is irreversible </h4>\r\n            </div>\r\n            <div class=\"\">\r\n              <div class=\"clearfix\">\r\n                <aside class=\"pull-right popup-btn\">\r\n                  <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closePopup()\" id=\"btnClosePopup\">\r\n                  <input type=\"button\" value=\"Convert\" class=\"fullBlue btn\" (click)=\"convertRow(selectedRow.data)\" id=\"btnConvertRow\">\r\n                </aside>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <!-- If Enquiry Converted -->\r\n        <div class=\"popup-content\" *ngIf=\"flagJSON.isConverted\">\r\n          <h2>Convert Enquiry - Enquiry No: {{selectedRow.enquiry_no}}</h2>\r\n          <div class=\"update-enquiry-form overflowHidden\">\r\n            <div class=\"enquiry-update-history\">\r\n              <h4>It Seems that this enquiry has already been converted to student</h4>\r\n            </div>\r\n            <div class=\"\">\r\n              <div class=\"clearfix\">\r\n                <aside class=\"pull-right popup-btn\">\r\n                  <input type=\"button\" value=\"Ok\" class=\"btn\" (click)=\"closePopup()\" id=\"btnClosePopup2\">\r\n                  <!-- <input type=\"button\" value=\"Convert\" class=\"redBtn btn\" (click)=\"convertRow(selectedRow.data)\"> -->\r\n                </aside>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <!--Registration Payment PopUp -->\r\n  <section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"varJson.message === 'payment'\">\r\n    <div class=\"popup pos-abs\">\r\n      <div class=\"popup-wrapper pos-rel\">\r\n        <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closePopup()\">\r\n          <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n            <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n              <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n                <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n                <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n              </g>\r\n              <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n              />\r\n            </g>\r\n          </svg>\r\n        </span>\r\n        <div class=\"popup-content\">\r\n          <h2>Registration Fee</h2>\r\n          <div class=\"registration-fee-form overflowHidden\">\r\n            <div class=\"\">\r\n\r\n              <!-- student has invoice and registered with status 11 -->\r\n              <div class=\"enquiry-update-history\" *ngIf=\"flagJSON.hasReceipt\">\r\n                <h4>\r\n                  A payment towards the selected enquiry has been updated, you may download the receipt for your reference\r\n                </h4>\r\n              </div>\r\n\r\n              <!-- any one of above case has failed -->\r\n              <div class=\"payment-form\" *ngIf=\"!flagJSON.hasReceipt\">\r\n\r\n                <!-- status admitted or registered but no open, inprogress or closed  -->\r\n                <div class=\"\" *ngIf=\"flagJSON.isadmitted\">\r\n                  <div class=\"row extraMargin\">\r\n                    <div class=\"c-lg-6 c-md-6 c-sm-6\">\r\n                      <div class=\"field-wrapper has-value\">\r\n                        <label for=\"pDate\">Payment Date</label>\r\n                        <input type=\"text\" value=\"\" id=\"pDate\" class=\"form-ctrl bsDatepicker\" [ngModel]=\"registrationForm.paymentDate\" name=\"pDate\"\r\n                          bsDatepicker readonly=\"true\" />\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"c-lg-6 c-md-6 c-sm-6\">\r\n                      <div class=\"field-wrapper\">\r\n                        <label for=\"paymentMode\">Payment Mode</label>\r\n                        <select id=\"paymentMode\" class=\"form-ctrl\" [(ngModel)]=\"registrationForm.paymentMode\">\r\n                          <option></option>\r\n                          <option *ngFor=\"let payment of paymentMode\" [value]=\"payment\">\r\n                            {{payment}}\r\n                          </option>\r\n                        </select>\r\n\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n\r\n                  <div class=\"row extraMargin\">\r\n                    <div class=\"c-lg-6 c-md-6 c-sm-6\">\r\n                      <div class=\"field-wrapper\">\r\n                        <label for=\"remark\">Amount</label>\r\n                        <input type=\"text\" value=\"\" id=\"remark\" class=\"form-ctrl\" [(ngModel)]=\"registrationForm.amount\" name=\"remark\" />\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"c-lg-6 c-md-6 c-sm-6\">\r\n                      <div class=\"field-wrapper\">\r\n                        <label for=\"referenceNo\">Reference No.</label>\r\n                        <input type=\"text\" value=\"\" id=\"referenceNo\" class=\"form-ctrl\" [(ngModel)]=\"registrationForm.reference\" name=\"reference\"\r\n                        />\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n\r\n                <!-- status open, inprogress or converted but not closed-->\r\n                <h4 *ngIf=\"flagJSON.notClosednAdmitted\">\r\n                  The requested enquiry has not yet been converted to student, please select the convert to student option from menu.\r\n                </h4>\r\n\r\n                <!-- status closed-->\r\n                <h4 *ngIf=\"flagJSON.isClosed\">\r\n                  The Enquiry has been closed or converted as a student.\r\n                </h4>\r\n\r\n              </div>\r\n\r\n              <!-- Icon for DownLoad -->\r\n              <div class=\"row\" *ngIf=\"flagJSON.hasReceipt\">\r\n                <div class=\"c-lg-12 c-md-12 c-sm-12\">\r\n                  <ul class=\"print-output-section\">\r\n\r\n                    <!-- <li>\r\n                          <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9177 266 26 22\">\r\n                            <g id=\"Group_1224\" data-name=\"Group 1224\" transform=\"translate(8100 -6)\">\r\n                              <g id=\"Group_1222\" data-name=\"Group 1222\">\r\n                                <g id=\"Group_1212\" data-name=\"Group 1212\">\r\n                                  <path id=\"Path_163\" data-name=\"Path 163\" class=\"cls-1\" d=\"M37,22.478h4.174a1.047,1.047,0,0,0,1.043-1.043V12.043A1.047,1.047,0,0,0,41.174,11H39.087\"\r\n                                    transform=\"translate(1059.782 267.47)\" />\r\n                                  <path id=\"Path_164\" data-name=\"Path 164\" class=\"cls-1\" d=\"M4.13,11H2.043A1.047,1.047,0,0,0,1,12.043v9.391a1.047,1.047,0,0,0,1.043,1.043H6.217\"\r\n                                    transform=\"translate(1077 267.47)\" />\r\n                                  <rect id=\"Rectangle_269\" data-name=\"Rectangle 269\" class=\"cls-1\" width=\"13.565\" height=\"10.435\" transform=\"translate(1083.217 273)\"\r\n                                  />\r\n                                  <rect id=\"Rectangle_270\" data-name=\"Rectangle 270\" class=\"cls-1\" width=\"13.565\" height=\"5.217\" transform=\"translate(1083.217 287.77)\"\r\n                                  />\r\n                                  <line id=\"Line_125\" data-name=\"Line 125\" class=\"cls-1\" x2=\"19.826\" transform=\"translate(1080.087 283.94)\" />\r\n                                  <line id=\"Line_126\" data-name=\"Line 126\" class=\"cls-1\" y2=\"1.094\" transform=\"translate(1080.609 286.128)\" />\r\n                                  <line id=\"Line_127\" data-name=\"Line 127\" class=\"cls-1\" y1=\"6.564\" transform=\"translate(1081.13 275.735)\" />\r\n                                  <line id=\"Line_128\" data-name=\"Line 128\" class=\"cls-1\" y1=\"6.564\" transform=\"translate(1098.87 275.735)\" />\r\n                                </g>\r\n                                <rect id=\"Rectangle_690\" data-name=\"Rectangle 690\" class=\"cls-2\" width=\"26\" height=\"22\" transform=\"translate(1077 272)\" style=\"stroke:none\"\r\n                                />\r\n                              </g>\r\n                            </g>\r\n                          </svg>\r\n                          <span>Print Fee Receipt</span>\r\n                    </li> -->\r\n\r\n                    <li class=\"svg-icon\" (click)=\"downloadReceiptPdf()\">\r\n                      <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"14362 435 26 22\">\r\n                        <g id=\"Group_1230\" data-name=\"Group 1230\" transform=\"translate(13654 -6)\">\r\n                          <rect id=\"Rectangle_695\" data-name=\"Rectangle 695\" class=\"cls-1\" width=\"26\" height=\"22\" transform=\"translate(708 441)\" style=\"stroke:none\"\r\n                          />\r\n                          <g id=\"Symbol_12_5\" data-name=\"Symbol 12 – 5\" transform=\"translate(53 -16)\">\r\n                            <path id=\"Path_161\" data-name=\"Path 161\" class=\"cls-2\" d=\"M21,32v3.158H1V32\" transform=\"translate(657 442.842)\" />\r\n                            <path id=\"Path_162\" data-name=\"Path 162\" class=\"cls-2\" d=\"M8,19l6.316,6.316L20.632,19\" transform=\"translate(653.684 449)\"\r\n                            />\r\n                            <line id=\"Line_124\" data-name=\"Line 124\" class=\"cls-2\" y1=\"16.316\" transform=\"translate(668 458)\" />\r\n                          </g>\r\n                        </g>\r\n                      </svg>\r\n                      <a id=\"reg-pdf-link\"></a>\r\n                      <span>PDF Download</span>\r\n                    </li>\r\n\r\n                  </ul>\r\n                </div>\r\n              </div>\r\n\r\n              <!-- Footer 1-->\r\n              <div class=\"row\" *ngIf=\"!flagJSON.hasReceipt\">\r\n\r\n                <div class=\"c-lg-12 c-md-12 c-sm-12\" *ngIf=\"flagJSON.isadmitted\">\r\n                  <aside class=\"pull-right popup-btn\">\r\n                    <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closePopup()\" id=\"BtncancelPopup\">\r\n                    <input type=\"button\" value=\"Save\" class=\"btn fullBlue\" (click)=\"registerPayment()\" id=\"BtnregisterPayment\">\r\n                  </aside>\r\n                </div>\r\n\r\n                <div class=\"c-lg-12 c-md-12 c-sm-12\" *ngIf=\"flagJSON.notClosednAdmitted\">\r\n                  <aside class=\"pull-right popup-btn\">\r\n                    <input type=\"button\" value=\"Ok\" class=\"btn\" (click)=\"closePopup()\" id=\"btnclosePopup\">\r\n                  </aside>\r\n                </div>\r\n\r\n                <div class=\"c-lg-12 c-md-12 c-sm-12\" *ngIf=\"flagJSON.isClosed\">\r\n                  <aside class=\"pull-right popup-btn\">\r\n                    <input type=\"button\" value=\"Ok\" class=\"btn\" (click)=\"closePopup()\" id=\"btnOpenClose\">\r\n                  </aside>\r\n                </div>\r\n\r\n              </div>\r\n\r\n              <!-- Footer 2-->\r\n              <div class=\"row\" *ngIf=\"flagJSON.hasReceipt\">\r\n                <div class=\"c-lg-12 c-md-12 c-sm-12\">\r\n                  <aside class=\"pull-right popup-btn\">\r\n                    <input type=\"button\" value=\"Ok\" class=\"btn\" (click)=\"closePopup()\" id=\"btnOpenClosePopup\">\r\n                  </aside>\r\n                </div>\r\n              </div>\r\n\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <!-- Bulk Assign PopUp -->\r\n  <section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"flagJSON.isAssignEnquiry\">\r\n    <div class=\"popup pos-abs\">\r\n      <div class=\"popup-wrapper pos-rel\">\r\n        <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"bulkAssignEnquiriesClose()\">\r\n          <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n            <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n              <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n                <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n                <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n              </g>\r\n              <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n              />\r\n            </g>\r\n          </svg>\r\n        </span>\r\n        <div class=\"popup-content\">\r\n          <h2>Assign {{selectedRowGroup.length}} Enquiries </h2>\r\n          <div class=\"update-enquiry-form overflowHidden\">\r\n            <div class=\"enquiry-update-history\">\r\n              <div class=\"field-wrapper\" *ngIf=\"isMainBranch == 'Y' || flagJSON.subBranchSelected == true\">\r\n                <div class=\"row\">\r\n                  <div class=\"c-lg-6 c-md-6 c-sm-6\">\r\n                    <label for=\"brchList\">Branch</label>\r\n                    <select id=\"brchList\" class=\"form-ctrl\" name=\"brchList\" [(ngModel)]=\"assignMultipleForm.source_instituteId\" (ngModelChange)=\"branchUpdated(assignMultipleForm.source_instituteId)\">\r\n                      <option value=\"-1\"></option>\r\n                      <option *ngFor=\"let branch of branchesList\" [value]=\"branch.institute_id\">\r\n                        {{ branch.institute_name }}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                  <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n                    <label for=\"assignTo\">Assign To</label>\r\n                    <select id=\"assignTo\" class=\"form-ctrl\" [(ngModel)]=\"assignMultipleForm.assigned_to\" name=\"assignTo\">\r\n                      <option></option>\r\n                      <option *ngFor=\"let assigned of enqAssignTo\" [value]=\"assigned.userid\">\r\n                        {{ assigned.name }}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"field-wrapper\" style=\"max-width: 70%\" *ngIf=\"isMainBranch=='N'\">\r\n                <div class=\"row\">\r\n                  <label for=\"assignTo\">Assign To</label>\r\n                  <select id=\"assignTo\" class=\"form-ctrl\" [(ngModel)]=\"assignMultipleForm.assigned_to\" name=\"assignTo\">\r\n                    <option></option>\r\n                    <option *ngFor=\"let assigned of enqAssignTo\" [value]=\"assigned.userid\">\r\n                      {{ assigned.name }}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"\">\r\n              <div class=\"clearfix\">\r\n                <aside class=\"pull-right popup-btn\">\r\n                  <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"bulkAssignEnquiriesClose()\" id=\"btn4\">\r\n                  <input type=\"button\" value=\"Assign Enquiries\" class=\"fullBlue btn\" (click)=\"bulkAssignEnquiries()\" id=\"BtnassignEnquiries\">\r\n                </aside>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <!-- SMS PopUp Single-->\r\n  <section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"varJson.message === 'sms'\">\r\n    <!-- -->\r\n    <div class=\"popup pos-abs popup-body-container\">\r\n      <div class=\"popup-wrapper pos-rel\" style=\"height: 80%;\">\r\n\r\n        <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closePopup()\">\r\n          <svg class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\"\r\n            x=\"0\" y=\"0\">\r\n            <path class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\"\r\n              style=\"fill: currentColor\"></path>\r\n          </svg>\r\n        </span>\r\n\r\n        <div class=\"popup-content\">\r\n          <h2>Send SMS</h2>\r\n          <div class=\"sms-form sms-popup-content\">\r\n            <div class=\"sms-update\">\r\n              <aside class=\"pull-left sms-table\">\r\n                <div class=\"sms-top-section\">\r\n                  <!-- Create New SMS Toggler -->\r\n                  <div class=\"row\">\r\n                    <div class=\"c-lg-12\">\r\n                      <div class=\"clearFix add-edit\">\r\n                        <a class=\"expend-box\" (click)=\"addNewMessage()\">\r\n                          <i class=\"add-sms\" id=\"sms-toggler-icon\">+</i>\r\n                          <span>Create New Sms</span>\r\n                        </a>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n\r\n                  <!-- Message TextArea Here -->\r\n                  <div class=\"row\" *ngIf=\"flagJSON.isMessageAddOpen\">\r\n                    <section class=\"clearFix new-sms-form\">\r\n                      <div class=\"row\">\r\n                        <div class=\"c-lg-8 pull-left new-sms-wrapper\">\r\n                          <textarea cols=\"1\" rows=\"5\" class=\"new-sms-textarea\" autocomplete=\"off\" role=\"textbox\" aria-autocomplete=\"list\" placeholder=\"Enter your SMS here\"\r\n                            [(ngModel)]=\"newSmsString.data\" aria-haspopup=\"true\" value=\"\" id=\"listTxt\"></textarea>\r\n                          <p>Message characters : {{newSmsString.data.length}}</p>\r\n                        </div>\r\n\r\n                        <div class=\"c-lg-4 pull-right\">\r\n                          <aside class=\"pull-left create-cancel-small\">\r\n                            <input type=\"button\" value=\"Cancel\" class=\"btn cancle\" (click)=\"addNewMessage()\" id=\"Btncancel7\">\r\n                            <input type=\"button\" class=\"btn fullBlue\" value=\"Save SMS\" (click)=\"addNewSmsTemplate()\" id=\"BtnsaveSms\">\r\n                          </aside>\r\n                        </div>\r\n\r\n                      </div>\r\n                    </section>\r\n                  </div>\r\n\r\n                  <!-- Message Header -->\r\n                  <h3>Message List</h3>\r\n\r\n                  <!-- Length of SMS Total and SearchBar -->\r\n                  <div class=\"row sms-table-head\">\r\n                    <div class=\"c-lg-7 c-md-7 c-sm-7\" style=\"padding-top: 10px;\">\r\n                      <div id=\"approvedSms\" class=\"sms-tab active\" style=\"margin-left: 5px;\" (click)=\"switchSmsTab('approvedSms')\">\r\n                        <label style=\"cursor: pointer\">Approved</label>\r\n                      </div>\r\n                      <div id=\"openSms\" class=\"sms-tab\" (click)=\"switchSmsTab('openSms')\">\r\n                        <label style=\"cursor: pointer\">Open</label>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"c-lg-5 c-md-5 c-sm-5 align-right\">\r\n                      <!-- <div class=\"search-filter-wrapper\">\r\n                        <input type=\"text\" class=\"sms-search-field\" placeholder=\"Search SMS\" #smssearch [(ngModel)]=\"smsSearchData\" name=\"searchData\"\r\n                          (keyup.enter)=\"onSearch(smssearch.value)\">\r\n                      </div> -->\r\n                    </div>\r\n                  </div>\r\n\r\n                </div>\r\n                <!-- Table Here -->\r\n                <div class=\"sms-middle-section\">\r\n                  <div class=\"table table-responsive table-container table-data-overflow\">\r\n                    <table>\r\n                      <thead>\r\n                        <tr>\r\n                          <th>\r\n                            <label>\r\n                              <a class=\"cursor-icon\" id=\"cursorAnch1\">{{smsHeader.message.title}}</a>\r\n                            </label>\r\n                          </th>\r\n                          <th style=\"width: 18%;\">\r\n                            <label>\r\n                              <a class=\"cursor-icon\" id=\"cursorAnch2\">{{smsHeader.date.title}}</a>\r\n                            </label>\r\n                          </th>\r\n                          <th>\r\n                            <label>\r\n                              <a class=\"cursor-icon\" id=\"cursorAnch3\">{{smsHeader.action.title}}</a>\r\n                            </label>\r\n                          </th>\r\n                        </tr>\r\n                      </thead>\r\n                      <tbody *ngIf=\"flagJSON.isApprovedTab\">\r\n                        <tr *ngFor=\"let row of smsSourceApproved; let i = index;\" (click)=\"appSmsSelected(row, i)\">\r\n                          <td style=\"text-overflow: ellipsis\">\r\n                            {{row.message}}\r\n                          </td>\r\n                          <td style=\"width: 18%;\">\r\n                            {{row.date}}\r\n                          </td>\r\n                          <td>\r\n                            <enquiry-sms-action>\r\n                            </enquiry-sms-action>\r\n                          </td>\r\n                        </tr>\r\n                        <tr *ngIf=\"smsSourceApproved.length == 0\">\r\n                          <td colspan=\"3\">\r\n                            No Message List Found\r\n                          </td>\r\n                        </tr>\r\n                      </tbody>\r\n                      <tbody *ngIf=\"flagJSON.isAllSelected\">\r\n                        <tr *ngFor=\"let row of smsSourceOpen; let i = index;\" (click)=\"opSmsSelected(row, i)\">\r\n                          <td style=\"text-align: left; text-overflow: ellipsis\">\r\n                            {{row.message}}\r\n                          </td>\r\n                          <td style=\"width: 18%;\">\r\n                            {{row.date}}\r\n                          </td>\r\n                          <td>\r\n                            <enquiry-sms-action>\r\n                            </enquiry-sms-action>\r\n                          </td>\r\n                        </tr>\r\n                        <tr *ngIf=\"smsSourceOpen.length == 0\">\r\n                          <td colspan=\"3\">\r\n                            No Message List Found\r\n                          </td>\r\n                        </tr>\r\n                      </tbody>\r\n                    </table>\r\n                  </div>\r\n                </div>\r\n\r\n              </aside>\r\n\r\n\r\n              <aside class=\"pull-right sms-preview\">\r\n                <div class=\"sms-preview-header\">\r\n                  <div class=\"row\">\r\n                    <div class=\"c-lg-6 c-md-6 c-sm-6\">\r\n                      <h4>Enquiry No. {{smsSelectedRows.enquiry_no}} Selected</h4>\r\n                    </div>\r\n                    <div class=\"c-lg-6 c-md-6 c-sm-6\" style=\"padding:24px 0px;\">\r\n                      <a style=\"cursor:pointer;\" (click)=\"closePopup()\" id=\"cursorAnch5\">Change</a>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"row\">\r\n                    <div class=\"c-lg-12 c-md-12 c-sm-12\">\r\n                      Available SMS Quota: {{varJson.availableSMS}}\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"sms-preview-content\">\r\n                  <div class=\"field-sms-wrapper\">\r\n                    <textarea placeholder=\"Select SMS to preview or edit to update template\" rows=\"20\" cols=\"1\" autocomplete=\"off\" role=\"textbox\"\r\n                      aria-autocomplete=\"list\" aria-haspopup=\"true\" id=\"sms-content\" value=\"\" [(ngModel)]=\"selectedSMS.message\"\r\n                      [disabled]=\"!flagJSON.smsBtnToggle\"></textarea>\r\n                  </div>\r\n                </div>\r\n                <div class=\"sms-preview-footer\">\r\n                  <div class=\"\">\r\n                    <div class=\"clearfix\">\r\n                      <aside class=\"popup-btn\">\r\n                        <input type=\"button\" value=\"Cancel Edit\" class=\"btn\" *ngIf=\"flagJSON.smsBtnToggle\" (click)=\"cancelSmsEdit()\" id=\"BtncancelSmsEdit\">\r\n                        <input type=\"button\" value=\"Save Template\" class=\"fullBlue btn\" *ngIf=\"flagJSON.smsBtnToggle\" (click)=\"saveEditedSms()\" id=\"BtnsaveEditedSms\">\r\n                        <input type=\"button\" value=\"Cancel\" class=\"btn\" *ngIf=\"!flagJSON.smsBtnToggle\" (click)=\"closePopup()\" id=\"Btncancel8\">\r\n                        <input type=\"button\" value=\"Send SMS\" class=\"fullBlue btn\" *ngIf=\"!flagJSON.smsBtnToggle\" (click)=\"sendSmsTemplate()\" id=\"BtnsendSms5\">\r\n                      </aside>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </aside>\r\n\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n  </section>\r\n\r\n  <!-- SMS PopUp MultiRow Selected-->\r\n  <section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"flagJSON.isMultiSms\">\r\n    <!--  -->\r\n    <div class=\"popup pos-abs popup-body-container\">\r\n      <div class=\"popup-wrapper pos-rel\" style=\"height: 86%;\">\r\n\r\n        <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closeBulkSms()\">\r\n            <svg class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\"\r\n            x=\"0\" y=\"0\">\r\n            <path class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\"\r\n              style=\"fill: currentColor\"></path>\r\n          </svg>\r\n        </span>\r\n\r\n        <div class=\"popup-content\">\r\n          <h2>Send Notification </h2>\r\n          <div class=\"common-tab\">\r\n              <div class=\"row\">\r\n                <div class=\"menu_list c-lg-6 c-md-6 c-sm-6\" [ngClass]=\"{'active':flagJSON.notificationType=='SMS'?true:false}\" (click)=\"sendNotificationType('SMS')\">\r\n                  Send SMS\r\n                </div>\r\n                <div class=\"menu_list c-lg-6 c-md-6 c-sm-6\" [ngClass]=\"{'active':flagJSON.notificationType=='Email'?true:false}\" (click)=\"sendNotificationType('Email')\">\r\n                  Send Email\r\n                </div>\r\n                <div class=\"menu_list c-lg-6 c-md-6 c-sm-6\" [ngClass]=\"{'active':flagJSON.notificationType=='sendGrid'?true:false}\" (click)=\"showSendGridData('sendGrid')\" style=\"width: 25%;\"  *ngIf=\"isSendGridEnable\"> \r\n                    Send Email using SendGrid\r\n                  </div>\r\n              </div>\r\n          </div>\r\n          <div class=\"sms-form sms-popup-content\" *ngIf=\"flagJSON.notificationType=='Email'|| flagJSON.notificationType=='SMS'\">\r\n            <div class=\"sms-update\">\r\n\r\n              <aside class=\"pull-left sms-table\">\r\n                <div class=\"sms-top-section\">\r\n                  <!-- Create New SMS Toggler -->\r\n                  <div class=\"row\">\r\n                    <div class=\"c-lg-12\">\r\n                      <div class=\"clearFix add-edit\">\r\n                        <a class=\"expend-box\" (click)=\"addNewMessage()\">\r\n                          <i class=\"add-sms\" id=\"sms-toggler-icon\">+</i>\r\n                          <span>Create New Sms</span>\r\n                        </a>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n\r\n                  <!-- Message TextArea Here -->\r\n                  <div class=\"row\" *ngIf=\"flagJSON.isMessageAddOpen\">\r\n                    <section class=\"clearFix new-sms-form\">\r\n                      <div class=\"row\">\r\n                        <div class=\"c-lg-8 pull-left new-sms-wrapper\">\r\n                          <textarea cols=\"1\" rows=\"5\" class=\"new-sms-textarea\" autocomplete=\"off\" role=\"textbox\" aria-autocomplete=\"list\" placeholder=\"Enter your SMS here\"\r\n                            [(ngModel)]=\"newSmsString.data\" aria-haspopup=\"true\" value=\"\" id=\"listTxt\" (ngModelChange)=\"countNumberOfMessage()\"></textarea>\r\n                          <div style=\"width:100%; display:flex; justify-content:space-between;\">\r\n                            <span>Character Count : {{newSmsString.data.length}}</span>\r\n                            <span>Message Count :\r\n                              <span [ngClass]=\"{'red' : messageCount >= 2}\">{{messageCount}}</span>\r\n                            </span>\r\n                          </div>\r\n                        </div>\r\n\r\n                        <div class=\"c-lg-4 pull-right\" style=\"margin-top: 16px;\">\r\n                          <aside class=\"pull-left create-cancel-small\">\r\n                            <input type=\"button\" value=\"Cancel\" class=\"btn cancle\" (click)=\"addNewMessage()\" >\r\n                            <input type=\"button\" class=\"btn fullBlue\" value=\"Save SMS\" (click)=\"addNewSmsTemplate()\" >\r\n                          </aside>\r\n                        </div>\r\n\r\n                      </div>\r\n                    </section>\r\n                  </div>\r\n\r\n                  <!-- Message Header -->\r\n\r\n                  <h3>Message List</h3>\r\n\r\n\r\n                  <!-- Length of SMS Total and SearchBar -->\r\n                  <div class=\"row sms-table-head\">\r\n                    <div class=\"c-lg-7 c-md-7 c-sm-7\" style=\"padding-top: 10px;\">\r\n                      <div id=\"approvedSms\" class=\"sms-tab active\" style=\"margin-left: 5px;\" (click)=\"switchSmsTab('approvedSms')\">\r\n                        <label style=\"cursor: pointer\">Approved</label>\r\n                      </div>\r\n                      <div id=\"openSms\" class=\"sms-tab\" (click)=\"switchSmsTab('openSms')\">\r\n                        <label style=\"cursor: pointer\">Open</label>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"c-lg-5 c-md-5 c-sm-5 align-right\">\r\n                      <!-- <div class=\"search-filter-wrapper\">\r\n                            <input type=\"text\" class=\"sms-search-field\" placeholder=\"Search SMS\" #smssearch [(ngModel)]=\"smsSearchData\" name=\"searchData\"\r\n                              (keyup.enter)=\"onSearch(smssearch.value)\">\r\n                          </div> -->\r\n                    </div>\r\n                  </div>\r\n\r\n                </div>\r\n\r\n                <div class=\"sms-middle-section\">\r\n                  <div class=\"table table-responsive table-container table-data-overflow\">\r\n                    <table>\r\n                      <thead>\r\n                        <tr>\r\n                          <!-- <th></th> -->\r\n                          <th>\r\n                            <label>\r\n                              <a class=\"cursor-icon\" id=\"cursorAnch11\">{{smsHeader.message.title}}</a>\r\n                            </label>\r\n                          </th>\r\n                          <th style=\"width: 18%;\">\r\n                            <label>\r\n                              <a class=\"cursor-icon\" id=\"cursorAnch12\">{{smsHeader.date.title}}</a>\r\n                            </label>\r\n                          </th>\r\n                          <th>\r\n                            <label>\r\n                              <a class=\"cursor-icon\" id=\"cursorAnch13\">{{smsHeader.action.title}}</a>\r\n                            </label>\r\n                          </th>\r\n                        </tr>\r\n                      </thead>\r\n                      <tbody *ngIf=\"flagJSON.isApprovedTab\">\r\n                        <tr *ngFor=\"let row of smsSourceApproved; let i = index;\" (click)=\"appSmsSelected(row, i)\">\r\n                          <!-- <td>\r\n                            <div class=\"field-radio-wrapper\">\r\n                              <label for=\"appradiosms{{i}}\"></label>\r\n                              <input type=\"radio\" name=\"smsTable\" class=\"form-radio\" id=\"appradiosms{{i}}\">\r\n                            </div>\r\n                          </td> -->\r\n                          <td>\r\n                            {{row.message}}\r\n                          </td>\r\n                          <td style=\"width: 18%;\">\r\n                            {{row.date}}\r\n                          </td>\r\n                          <td>\r\n                            <enquiry-sms-action>\r\n                            </enquiry-sms-action>\r\n                          </td>\r\n                        </tr>\r\n                      </tbody>\r\n                      <tbody *ngIf=\"flagJSON.isAllSelected\">\r\n                        <tr *ngFor=\"let row of smsSourceOpen; let i = index;\" (click)=\"opSmsSelected(row, i)\">\r\n                          <!-- <td>\r\n                            <div class=\"field-radio-wrapper\">\r\n                              <label for=\"oppradiosms{{i}}\"></label>\r\n                              <input type=\"radio\" name=\"smsTable\" class=\"form-radio\" id=\"opradiosms{{i}}\">\r\n                            </div>\r\n                          </td> -->\r\n                          <td>\r\n                            {{row.message}}\r\n                          </td>\r\n                          <td style=\"width: 18%;\">\r\n                            {{row.date}}\r\n                          </td>\r\n                          <td class=\"sms-Action-td\" style=\"display:block\">\r\n                            <span class=\"change-status\" [ngClass]=\"{hideElement : (!showApproveButtons(row))}\" style=\"display: inline-block\">\r\n                              <i class=\"fas fa-check\" (click)=\"approveRejectSms(row , '1')\" style=\"font-family: FontAwesome;font-size: 25px;color: green;\"></i>\r\n                              <i class=\"fa fa-times\" (click)=\"approveRejectSms(row,'2')\" style=\"font-family: FontAwesome;font-size: 25px;margin-left: 5px;\"></i>\r\n                            </span>\r\n                            <enquiry-sms-action style=\"display: inline-block\"></enquiry-sms-action>\r\n                          </td>\r\n                        </tr>\r\n                      </tbody>\r\n                    </table>\r\n                  </div>\r\n                </div>\r\n\r\n              </aside>\r\n\r\n\r\n              <aside class=\"pull-right sms-preview\">\r\n                <div style=\"    margin-bottom: 5px;\">\r\n                  <div class=\"row\">\r\n                    <div class=\"c-lg-6 c-md-6 c-sm-6\">\r\n                      <h4>{{smsSelectedRowsLength}} Users Selected</h4>\r\n                    </div>\r\n                    <div class=\"c-lg-6 c-md-6 c-sm-6\" style=\"padding:24px 0px;\">\r\n                      <a style=\"cursor:pointer;\" (click)=\"closeBulkSms()\" id=\"closeBulkAnch4\">Change</a>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"row\">\r\n                    <div class=\"c-lg-12 c-md-12 c-sm-12\">\r\n                      Available SMS Quota: {{varJson.availableSMS}}\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"row\" style=\"padding: 10px 0px; \" *ngIf=\"flagJSON.notificationType=='Email'\">\r\n                      <div class=\"c-lg-12 c-md-12 c-sm-12\" style=\"padding-bottom: 5px\"><label>Subject <span class=\"danger\">*</span></label></div>\r\n                        <div class=\"c-lg-12 c-md-12 c-sm-12\">\r\n                            <input type=\"text\" placeholder=\"Email Subject\" [(ngModel)]=\"emailSubject\" \r\n                            name=\"searchEmailData\">\r\n                        </div>\r\n                      </div>\r\n                </div>\r\n                <div class=\"sms-preview-content\">\r\n                  <div class=\"field-sms-wrapper\">\r\n                    <textarea placeholder=\"Edit Message Here\" rows=\"20\" cols=\"1\" autocomplete=\"off\" role=\"textbox\" aria-autocomplete=\"list\" aria-haspopup=\"true\"\r\n                      id=\"sms-content\" value=\"\" [(ngModel)]=\"selectedSMS.message\" [disabled]=\"!flagJSON.smsBtnToggle\" (ngModelChange)=\"countNumberOfMessageForEdit()\"></textarea>\r\n                    <div style=\"width:100%; display:flex; justify-content:space-between;font-size:12px\">\r\n                      <span>Character Count : {{selectedSMS.message.length}}</span>\r\n                      <span>Message Count :\r\n                        <span [ngClass]=\"{'red' : messageCountForEdit >= 2}\">{{messageCountForEdit}}</span>\r\n                      </span>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"sms-preview-footer\">\r\n                  <div class=\"\">\r\n                    <div class=\"clearfix\">\r\n                      <aside class=\"popup-btn\">\r\n                        <input type=\"button\" value=\"Cancel\" class=\"btn\" *ngIf=\"flagJSON.smsBtnToggle\" (click)=\"cancelSmsEdit()\" id=\"BtncancelEditSms\">\r\n                        <input type=\"button\" value=\"Save\" class=\"fullBlue btn\" *ngIf=\"flagJSON.smsBtnToggle\" (click)=\"saveEditedSms()\" id=\"BtnsaveSmsEdited\">\r\n                        <input type=\"button\" value=\"Cancel\" class=\"btn\" *ngIf=\"!flagJSON.smsBtnToggle\" (click)=\"closeBulkSms()\" id=\"Btncancel0\">\r\n                        <input type=\"button\" value=\"Send SMS\" class=\"fullBlue btn\" *ngIf=\"(!flagJSON.smsBtnToggle)&&(flagJSON.notificationType=='SMS')\" (click)=\"sendSmsTemplate()\" id=\"btn0\">\r\n                        <input type=\"button\" value=\"Send Email\" class=\"btn fullBlue\"  *ngIf=\"(!flagJSON.smsBtnToggle)&&(flagJSON.notificationType=='Email')\"  (click)=\"addNewEmailTemplate()\">\r\n                      </aside>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </aside>\r\n\r\n            </div>\r\n          </div>\r\n\r\n          <div *ngIf=\"flagJSON.notificationType=='sendGrid'\">\r\n              <div class=\"sms-form sms-popup-content\">\r\n                  <div class=\"sms-update\">\r\n      \r\n                    <aside class=\"pull-left sms-grid-table\">\r\n                      <div class=\"sms-top-section\">\r\n                        <h3 style=\"margin-top: 15px;margin-bottom: 15px;\">Template List</h3>\r\n                      </div>\r\n      \r\n                      <div class=\"sms-middle-section\">\r\n                        <div class=\"table table-responsive table-container table-data-overflow\">\r\n                          <table>\r\n                              <tr>\r\n                                <th>\r\n\r\n                                </th>\r\n                                <th style=\"width: 30%;\">\r\n                                  <label>\r\n                                    <a class=\"cursor-icon\" id=\"cursorAnch11\">Template Name</a>\r\n                                  </label>\r\n                                </th>\r\n                                <th style=\"width: 30%;\">\r\n                                  <label>\r\n                                    <a class=\"cursor-icon\" id=\"cursorAnch12\">Version Name</a>\r\n                                  </label>\r\n                                </th>\r\n                                <th style=\"width: 25%;\">\r\n                                    <label>\r\n                                      <a class=\"cursor-icon\" id=\"cursorAnch12\">Updated Date</a>\r\n                                    </label>\r\n                                  </th>\r\n                                <th style=\"width: 15%;\">\r\n                                  <label>\r\n                                    <a class=\"cursor-icon\" id=\"cursorAnch13\">Preview</a>\r\n                                  </label>\r\n                                </th>\r\n                              </tr>\r\n                               <tr  id=\"row{{i}}\" *ngFor=\"let row of emailGridData; let i = index;\" (click)=\"opEmailGridSelected(row,i)\" [class.selected]=\"i == selectedTableRow\">\r\n                                 <td>\r\n                                    <!-- <div class=\"c-sm-1 c-md-1 c-lg-1\"> -->\r\n                                        <!-- <div class=\"field-radio-wrapper\"> -->\r\n                                          <input type=\"radio\" name=\"bothRadio\" [id]=\"'bothRadio-'+i\" class=\"form-radio\" [value]=\"i\" [(ngModel)]=\"selectedTableRow\">\r\n                                          <!-- <label [for]=\"'bothRadio-'+i\">{{smsDetails.total_sms}}</label> -->\r\n                                        <!-- </div> -->\r\n                                      <!-- </div> -->\r\n                                 </td>\r\n                                <td style=\"width: 30%;\">\r\n                                  <span title=\"{{row.template_name}}\">{{ (row.template_name.length > 20) ? (row.template_name | slice:0:20) + '...' : row.template_name }}</span>\r\n                                </td>\r\n                                <td style=\"width: 30%;\">\r\n                                  <span title=\"{{row.version_name}}\">{{ (row.version_name.length > 20) ? (row.version_name | slice:0:20) + '...' : row.version_name }}</span>\r\n                                </td>\r\n                                <td style=\"width: 25%;\">\r\n                                  <span title=\"{{row.template_updated_date}}\">{{row.template_updated_date}}</span>\r\n                                  </td>\r\n                                <td style=\"width: 15%;\" (click)=\"viewThumbnailUrl(row.template_subject_thumbnail_url)\">\r\n                                    <a class=\"cursor\">View</a>\r\n                                  </td>\r\n                              </tr>\r\n                              <tr *ngIf=\"emailGridData?.length==0\">\r\n                                <td colspan=\"5\" style=\"padding: 10px;text-align: center;font-weight: 600;\">\r\n                                  No Data Found\r\n                                </td>\r\n                              </tr>\r\n                          </table>\r\n                        </div>\r\n                      </div>\r\n                        \r\n                    </aside>\r\n      \r\n      \r\n                    <aside class=\"pull-right sms-grid-preview\">\r\n                      <div class=\"sms-preview-footer\" style=\"float: right;\">\r\n                        <div class=\"\">\r\n                          <div class=\"clearfix\">\r\n                            <aside class=\"popup-btn\">\r\n                              <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closeBulkSms()\" id=\"Btncancel0\">\r\n                              <input type=\"button\" value=\"Send\" class=\"fullBlue btn\" (click)=\"sendEmailGrid()\" id=\"btn0\">                              \r\n                            </aside>\r\n                          </div>\r\n                        </div>\r\n                      </div>\r\n                    </aside>\r\n      \r\n                  </div>\r\n                </div>\r\n                </div>\r\n\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n\r\n  </section>\r\n\r\n \r\n  <section class=\"absent_popup\" *ngIf=\"viewPopUp\">\r\n      <div class=\"absent_student\">\r\n        <div class=\"header\">\r\n          <span style=\"font-weight: 600; cursor: pointer;\" (click)=\"closeViewPopUp()\">X</span>\r\n        </div>\r\n        <div class=\"main_container\">\r\n          <div class=\"for_absent\">\r\n              <img [src]=\"EmailThumbnailUrl\" class=\"emailGridImg\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </section>\r\n    \r\n<div class=\"black-bg1\" id=\"black-bg1\" *ngIf=\"viewPopUp\" (click)=\"closeViewPopUp()\"></div>\r\n  <!-- Download Summary Report Options PopUp Single-->\r\n  <section id=\"\" class=\"popupWrapper fadeIn\" *ngIf=\"flagJSON.summaryOptions\">\r\n    <!-- -->\r\n\r\n    <div class=\"popup pos-abs popup-body-container\" style=\"max-width: 30%\">\r\n      <div class=\"popup-wrapper pos-rel\">\r\n\r\n        <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closePopup()\">\r\n          <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n            <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n              <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n                <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n                <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n              </g>\r\n              <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n              />\r\n            </g>\r\n          </svg>\r\n        </span>\r\n\r\n        <div class=\"popup-content\">\r\n          <h2>Download Summary Report</h2>\r\n          <div class=\"content-section\">\r\n            <div id=\"divDropDownSection\" *ngIf=\"!flagJSON.showDateRange\" class=\"row dropDownSection\">\r\n              <div class=\"c-sm-6 c-lg-6 c-lg-6\">\r\n                <div class=\"field-wrapper has-value\">\r\n                  <label for=\"priorityEdit\">Select Duration</label>\r\n                  <select id=\"month\" class=\"form-ctrl\" [(ngModel)]=\"varJson.downloadReportOption\" name=\"priority\">\r\n                    <option value=\"1\">Select Month</option>\r\n                    <option value=\"2\">This Month</option>\r\n                    <option value=\"3\">Previous Month</option>\r\n                    <option value=\"4\">Last Two Month</option>\r\n                  </select>\r\n                </div>\r\n              </div>\r\n              <div style=\"padding-top: 16px;\" class=\"c-sm-6 c-lg-6 c-lg-6\">\r\n                <button class=\"btn fullBlue\" (click)=\"downloadSummaryReportXl()\" style=\"margin-top: 10px\" id=\"btnDownloadSummary\">Download</button>\r\n              </div>\r\n            </div>\r\n            <div id=\"divRangeSelection\" *ngIf=\"flagJSON.showDateRange\" class=\"row select-dates\" style=\"margin:0 -15px\">\r\n              <div class=\"c-sm-4 c-lg-4 c-lg-4\">\r\n                <div class=\"field-wrapper datePickerBox\">\r\n                  <label for=\"fromDate\">From Date</label>\r\n                  <input type=\"text\" value=\"\" id=\"\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"varJson.summaryReport.from_date\" name=\"fromDate\"\r\n                    readonly=\"true\" bsDatepicker />\r\n\r\n                </div>\r\n              </div>\r\n              <div class=\"c-sm-4 c-lg-4 c-lg-4\">\r\n                <div class=\"field-wrapper datePickerBox\">\r\n                  <label for=\"toDate\">To Date</label>\r\n                  <input type=\"text\" value=\"\" id=\"\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"varJson.summaryReport.to_date\" name=\"toDate\"\r\n                    readonly=\"true\" bsDatepicker />\r\n\r\n                </div>\r\n              </div>\r\n              <div class=\"c-sm-4 c-lg-4 c-lg-4\" style=\"margin-top: 15px;\">\r\n                <button class=\"btn fullBlue\" (click)=\"downloadSummaryReportXlDateWise()\" style=\"margin-top: 10px; padding: 5px\" id=\"btnDownloadDatewise\">Download</button>\r\n              </div>\r\n            </div>\r\n            <a id=\"anchTagToggle\" class=\"pull-right\" (click)=\"toggleDateSection()\" style=\"cursor: pointer;margin-top: 10px;\">Download By Date Range</a>\r\n            <a id=\"downloadSummaryReport121\" class=\"hide\"></a>\r\n          </div>\r\n        </div>\r\n\r\n\r\n      </div>\r\n    </div>\r\n\r\n  </section>\r\n\r\n\r\n</div>\r\n\r\n<!-- Customizable Enquiry table -->\r\n<preference-popup [settings]=\"tableSetting\" [keys]=\"enquirySettings\" (closeButton)=\"closePreferncesPopup($event)\" *ngIf=\"flagJSON.showPreference\"></preference-popup>"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-home/enquiry-home.component.scss":
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/** these css for gear icon download options\r\n* created by laxmi\r\n*/\nsvg:hover #gearIcon {\n  fill: #0084f6; }\n.asHover:hover {\n  color: #0084f6 !important; }\n.download:hover {\n  cursor: pointer; }\n.made-in {\n  font-size: 17px;\n  font-weight: bold;\n  text-align: left; }\n.dropdown > ul {\n  background: #fff;\n  padding: 10px 20px;\n  border: 1px solid #eaeaeb;\n  border-top: 0;\n  margin-top: 3px;\n  -webkit-box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 6px 10px 0 rgba(0, 0, 0, 0.12);\n          box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 6px 10px 0 rgba(0, 0, 0, 0.12); }\n.dropdown > ul li {\n    color: #333; }\n.dropdown > ul li strong {\n      font-weight: 600;\n      display: block; }\n.dropdown > ul li a {\n      display: block;\n      color: #333; }\n.login-tube nav > ul > li {\n  display: inline-block;\n  position: relative; }\n.login-tube nav > ul > li > a {\n  color: #333;\n  text-decoration: none;\n  padding: 5px 10px;\n  display: block;\n  -webkit-transition: all .4s;\n  transition: all .4s; }\n.login-tube nav > ul > li > a:hover,\n.login-tube nav > ul > li:hover > a {\n  text-decoration: none;\n  background: #ccc; }\n.login-tube nav > ul > li .dropdown {\n  position: absolute;\n  visibility: hidden;\n  right: 0;\n  top: 100%;\n  min-width: 200px;\n  border-top: 0;\n  opacity: 0;\n  -webkit-transition: all 0.1s cubic-bezier(0.55, 0, 0.55, 0.2);\n  transition: all 0.1s cubic-bezier(0.55, 0, 0.55, 0.2);\n  -webkit-transition-duration: .25s;\n  transition-duration: .2s;\n  -webkit-transform: scale(0.5);\n          transform: scale(0.5); }\n.login-tube nav > ul > li .dropdown > ul li {\n    line-height: normal; }\n.login-tube nav > ul > li .dropdown > ul li a {\n      display: block;\n      margin: 5px 0; }\n.login-tube nav > ul > li .dropdown > ul li a:hover {\n        color: #0084f6; }\n.login-tube nav > ul > li .dropdown > ul ul {\n    padding-left: 15px;\n    padding-top: 10px; }\n.login-tube nav > ul > li .dropdown > ul ul ul {\n      padding-top: 0; }\n.login-tube nav > ul > li:hover .dropdown {\n  visibility: visible;\n  position: absolute;\n  opacity: 1;\n  right: 0;\n  top: 100%;\n  -webkit-transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);\n  transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);\n  -webkit-transition-duration: .5s;\n  transition-duration: .5s;\n  -webkit-transform: scale(1);\n          transform: scale(1); }\n.span-button {\n  border: 1px solid #0084f6;\n  padding: 4px 8px;\n  color: #0084f6;\n  font-size: .9em;\n  border-radius: 2px;\n  font-weight: 600;\n  cursor: pointer; }\n.span-button svg {\n    margin: -3px 0;\n    height: 14px; }\nlogin-nav > li {\n  display: inline-block;\n  padding: 0 7px;\n  cursor: pointer;\n  vertical-align: text-bottom; }\nlogin-nav > li .dropdown {\n    position: absolute;\n    right: 0;\n    top: 100%;\n    padding-top: 10px; }\nlogin-nav > li .icons {\n    width: 35px;\n    height: 35px;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    border-radius: 50%;\n    padding-top: 3px;\n    -webkit-transition: all 0.1s;\n    transition: all 0.1s;\n    border: 1px solid transparent; }\nlogin-nav > li .icons svg {\n      width: 25px;\n      color: #034979; }\nlogin-nav > li .icons svg .cls-1 {\n        stroke: #034979;\n        stroke-linejoin: unset;\n        border: none; }\nlogin-nav > li .user-info {\n    white-space: nowrap;\n    margin-right: 40px;\n    width: auto;\n    display: block;\n    position: relative; }\nlogin-nav > li .user-info > .icons {\n      display: inline-block;\n      vertical-align: middle; }\nlogin-nav > li .user-info > span {\n      vertical-align: middle;\n      display: inline-block; }\nlogin-nav > li .user-info:after {\n      display: inline-block;\n      font: normal normal normal 14px/1 FontAwesome;\n      font-size: inherit;\n      text-rendering: auto;\n      -webkit-font-smoothing: antialiased;\n      content: \"\\f107\";\n      font-size: 17px;\n      position: absolute;\n      right: -20px;\n      top: 10px; }\n/**\r\n  this css is for report section css for cards\r\n  added by laxmi\r\n*/\n.report-box {\n  width: 100%;\n  height: 100%;\n  padding: 10px; }\n.report-box ul.card-box li.card-row {\n    margin: 10px 0px; }\n.report-box ul.card {\n    padding: 15px 10px;\n    border: 1px solid #efefef;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 10px 0px;\n    -webkit-box-shadow: 0px 0px 2px 0px;\n            box-shadow: 0px 0px 2px 0px; }\n.report-box ul.card li {\n      padding: 5px; }\n.report-box ul.card li:first-child {\n        font-size: 14px;\n        font-weight: 600;\n        padding: 10px 5px; }\n.report-box ul.card li:nth-child(2n) {\n        font-size: 12px; }\n.disabled {\n  cursor: not-allowed;\n  background: lightgrey; }\n/* =================================================================================== */\n/* =================================================================================== */\n.headEnq .headerBtn {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  border: 1px solid #0084f6;\n  height: 35px;\n  padding: 8px 12px;\n  cursor: pointer;\n  color: #0084f6;\n  -webkit-box-shadow: 0 0 1px #0084f6;\n          box-shadow: 0 0 1px #0084f6;\n  text-align: center; }\n.headEnq .headerBtn i {\n    display: inline-block;\n    margin-right: 10px;\n    cursor: pointer; }\n.headEnq .headerBtn p {\n    display: inline-block;\n    font-size: 14px;\n    font-weight: 600;\n    text-transform: capitalize;\n    text-align: center;\n    cursor: pointer; }\n.headEnq .optMenu .enq-dropdown-content {\n  position: absolute;\n  background: white;\n  z-index: 10;\n  right: 2%;\n  width: 150px;\n  padding: 0 5px;\n  padding-bottom: 10px;\n  -webkit-box-shadow: 0 0 2px 0 #313030;\n          box-shadow: 0 0 2px 0 #313030; }\n.headEnq .optMenu .enq-dropdown-content ul {\n    list-style: none; }\n.headEnq .optMenu .enq-dropdown-content ul .excel-icon {\n      cursor: pointer;\n      height: auto; }\n.headEnq .optMenu .enq-dropdown-content ul .excel-icon .labelName {\n        cursor: pointer;\n        margin-left: 5px;\n        font-size: 15px;\n        color: #888; }\n.headEnq .optMenu .enq-dropdown-content ul .excel-icon .labelName:hover {\n          color: #0084f6; }\n.headEnq .optMenu .enq-dropdown-content ul .export-icon {\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%229268 266 26 22%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %23999%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1223%22 data-name%3D%22Group 1223%22 transform%3D%22translate(8100 -6)%22%3E%0D    %3Cg id%3D%22Group_1211%22 data-name%3D%22Group 1211%22 transform%3D%22translate(0 -1)%22%3E%0D      %3Cpath id%3D%22Path_178%22 data-name%3D%22Path 178%22 class%3D%22cls-1%22 d%3D%22M11.588%2C3H3.353A2.36%2C2.36%2C0%2C0%2C0%2C1%2C5.353V19.47a2.36%2C2.36%2C0%2C0%2C0%2C2.353%2C2.353H17.47a2.36%2C2.36%2C0%2C0%2C0%2C2.353-2.353V11.235%22 transform%3D%22translate(1170 272.176)%22%2F%3E%0D      %3Cline id%3D%22Line_140%22 data-name%3D%22Line 140%22 class%3D%22cls-1%22 y1%3D%2210%22 x2%3D%2210%22 transform%3D%22translate(1180.412 274.588)%22%2F%3E%0D      %3Cpath id%3D%22Path_179%22 data-name%3D%22Path 179%22 class%3D%22cls-1%22 d%3D%22M30.059%2C8.059V1.588A.556.556%2C0%2C0%2C0%2C29.47%2C1H23%22 transform%3D%22translate(1160.941 273)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Crect id%3D%22Rectangle_691%22 data-name%3D%22Rectangle 691%22 class%3D%22cls-2%22 width%3D%2226%22 height%3D%2222%22 transform%3D%22translate(1168 272)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      margin: 10px 0 0 2px;\n      background-size: 20px auto;\n      padding: 0 0 0 25px;\n      cursor: pointer;\n      font-size: 14px;\n      color: #888; }\n.headEnq .optMenu .enq-dropdown-content ul .export-icon:hover {\n        color: #0084f6; }\n.headEnq .optMenu .enq-dropdown-content ul .upload-icon {\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%220 0 512 512%22%3E%3Cpath d%3D%22M296 384h-80c-13.3 0-24-10.7-24-24V192h-87.7c-17.8 0-26.7-21.5-14.1-34.1L242.3 5.7c7.5-7.5 19.8-7.5 27.3 0l152.2 152.2c12.6 12.6 3.7 34.1-14.1 34.1H320v168c0 13.3-10.7 24-24 24zm216-8v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h136v8c0 30.9 25.1 56 56 56h80c30.9 0 56-25.1 56-56v-8h136c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z%22%2F%3E%3C%2Fsvg%3E\") no-repeat;\n      margin: 10px 0 0 2px;\n      background-size: 20px auto;\n      padding: 0 0 0 25px;\n      cursor: pointer;\n      font-size: 14px;\n      color: #888; }\n.headEnq .optMenu .enq-dropdown-content ul .upload-icon:hover {\n        color: #0084f6; }\n.headEnq .optMenu .enq-dropdown-content ul .download-icon {\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%220 0 512 512%22%3E%3Cpath d%3D%22M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z%22%2F%3E%3C%2Fsvg%3E\") no-repeat;\n      margin: 10px 0 0 2px;\n      background-size: 20px auto;\n      padding: 0 0 0 25px;\n      cursor: pointer;\n      font-size: 14px;\n      color: #888; }\n.headEnq .optMenu .enq-dropdown-content ul .download-icon:hover {\n        color: #0084f6; }\n.headEnq .optMenu .enq-dropdown-content ul li {\n      height: 25px;\n      padding: 7px;\n      border-bottom: 1px solid rgba(119, 119, 119, 0.705); }\n.headEnq .optMenu.shorted .enq-dropdown-content {\n  position: absolute;\n  background: white;\n  z-index: 10;\n  right: 29%;\n  width: 150px;\n  padding: 0 5px;\n  height: 120px;\n  -webkit-box-shadow: 0 0 2px 0 #313030;\n          box-shadow: 0 0 2px 0 #313030; }\n.headEnq .optMenu.shorted .enq-dropdown-content ul {\n    list-style: none; }\n.headEnq .optMenu.shorted .enq-dropdown-content ul .export-icon {\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%229268 266 26 22%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %23999%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1223%22 data-name%3D%22Group 1223%22 transform%3D%22translate(8100 -6)%22%3E%0D    %3Cg id%3D%22Group_1211%22 data-name%3D%22Group 1211%22 transform%3D%22translate(0 -1)%22%3E%0D      %3Cpath id%3D%22Path_178%22 data-name%3D%22Path 178%22 class%3D%22cls-1%22 d%3D%22M11.588%2C3H3.353A2.36%2C2.36%2C0%2C0%2C0%2C1%2C5.353V19.47a2.36%2C2.36%2C0%2C0%2C0%2C2.353%2C2.353H17.47a2.36%2C2.36%2C0%2C0%2C0%2C2.353-2.353V11.235%22 transform%3D%22translate(1170 272.176)%22%2F%3E%0D      %3Cline id%3D%22Line_140%22 data-name%3D%22Line 140%22 class%3D%22cls-1%22 y1%3D%2210%22 x2%3D%2210%22 transform%3D%22translate(1180.412 274.588)%22%2F%3E%0D      %3Cpath id%3D%22Path_179%22 data-name%3D%22Path 179%22 class%3D%22cls-1%22 d%3D%22M30.059%2C8.059V1.588A.556.556%2C0%2C0%2C0%2C29.47%2C1H23%22 transform%3D%22translate(1160.941 273)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Crect id%3D%22Rectangle_691%22 data-name%3D%22Rectangle 691%22 class%3D%22cls-2%22 width%3D%2226%22 height%3D%2222%22 transform%3D%22translate(1168 272)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      margin: 10px 0 0 2px;\n      background-size: 20px auto;\n      padding: 0 0 0 25px;\n      cursor: pointer;\n      font-size: 14px;\n      color: #888; }\n.headEnq .optMenu.shorted .enq-dropdown-content ul .export-icon:hover {\n        color: #0084f6; }\n.headEnq .optMenu.shorted .enq-dropdown-content ul .upload-icon {\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%220 0 512 512%22%3E%3Cpath d%3D%22M296 384h-80c-13.3 0-24-10.7-24-24V192h-87.7c-17.8 0-26.7-21.5-14.1-34.1L242.3 5.7c7.5-7.5 19.8-7.5 27.3 0l152.2 152.2c12.6 12.6 3.7 34.1-14.1 34.1H320v168c0 13.3-10.7 24-24 24zm216-8v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h136v8c0 30.9 25.1 56 56 56h80c30.9 0 56-25.1 56-56v-8h136c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z%22%2F%3E%3C%2Fsvg%3E\") no-repeat;\n      margin: 10px 0 0 2px;\n      background-size: 20px auto;\n      padding: 0 0 0 25px;\n      cursor: pointer;\n      font-size: 14px;\n      color: #888; }\n.headEnq .optMenu.shorted .enq-dropdown-content ul .upload-icon:hover {\n        color: #0084f6; }\n.headEnq .optMenu.shorted .enq-dropdown-content ul .download-icon {\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%220 0 512 512%22%3E%3Cpath d%3D%22M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z%22%2F%3E%3C%2Fsvg%3E\") no-repeat;\n      margin: 10px 0 0 2px;\n      background-size: 20px auto;\n      padding: 0 0 0 25px;\n      cursor: pointer;\n      font-size: 14px;\n      color: #888; }\n.headEnq .optMenu.shorted .enq-dropdown-content ul .download-icon:hover {\n        color: #0084f6; }\n.headEnq .optMenu.shorted .enq-dropdown-content ul li {\n      height: 25px;\n      padding: 7px;\n      border-bottom: 1px solid rgba(119, 119, 119, 0.705); }\n.btn-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row; }\n.btn-container .btn-item {\n    position: relative; }\n.btn-container .more-info-container {\n    z-index: 100;\n    background: white;\n    position: absolute;\n    top: 40px;\n    border-radius: 4px;\n    border: 1px solid #0084f6;\n    min-width: 195px;\n    width: 100%;\n    right: 0; }\n.btn-container .more-info-container .more-info-item {\n      cursor: pointer;\n      padding: 5px;\n      font-size: 12px;\n      font-weight: 600;\n      border-bottom: 1px solid #0084f6; }\n/* =================================================================================== */\n.tooltip-table:hover .tooltip-box-right {\n  visibility: visible;\n  opacity: 1;\n  left: 100px; }\n.tooltip-table .tooltip-box-right {\n  position: absolute;\n  min-width: 700px;\n  max-width: 750px;\n  min-height: 150px;\n  max-height: 200px;\n  background: #f5f5ed;\n  border: 1px solid #ccc;\n  left: 100px;\n  z-index: 1;\n  top: -65px;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all .1s linear .1s;\n  transition: all .1s linear .1s;\n  font-size: 11px;\n  border-radius: 4px;\n  padding: 10px;\n  -webkit-box-shadow: 0 0 10px #161515;\n          box-shadow: 0 0 10px #161515;\n  overflow-y: auto;\n  overflow-x: hidden; }\n/* =================================================================================== */\n#table-main {\n  margin-left: 0 !important;\n  margin-top: 0;\n  margin-right: 15px !important;\n  overflow: hidden;\n  width: 100%; }\n#table-main ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n@media screen and (max-width: 767px) {\n  .sidenav {\n    margin-top: 20px !important;\n    padding-top: 30px !important;\n    height: 700px !important; } }\n@media screen and (max-width: 995px), screen and (max-height: 768px) {\n  #table-main {\n    margin-left: 0 !important;\n    margin-top: 0;\n    margin-right: 15px !important;\n    /* max-height: 375px;\r\n        overflow: hidden; */\n    width: 100%; }\n    #table-main ::-webkit-scrollbar {\n      display: block;\n      width: 7px;\n      height: 7px; } }\n.table-scroll-wrapper {\n  /*     max-height: 400px;\r\n    overflow-y: auto;\r\n    overflow-x: auto;\r\n     ::-webkit-scrollbar {\r\n        display: block;\r\n        width: 7px;\r\n        height: 7px;\r\n    } */ }\n.table-scroll-wrapper .enquiry-table {\n    overflow-y: visible;\n    overflow-x: visible; }\n.table-scroll-wrapper .enquiry-table table .field-checkbox-wrapper {\n      width: 22px !important;\n      overflow: hidden;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      height: 22px !important;\n      padding-left: 25px !important;\n      margin-bottom: 0;\n      margin-left: 5px;\n      background: transparent;\n      border-radius: 2px; }\n.table-scroll-wrapper .enquiry-table table .field-checkbox-wrapper .form-checkbox {\n      opacity: 0;\n      position: absolute;\n      left: 0;\n      top: 0;\n      width: 22px;\n      height: 22px;\n      z-index: 1; }\n.table-scroll-wrapper .enquiry-table table .field-checkbox-wrapper .form-checkbox + label {\n      vertical-align: middle;\n      -webkit-transition: all 0s;\n      transition: all 0s;\n      font-size: 14px;\n      display: inline-block; }\n.table-scroll-wrapper .enquiry-table table .field-checkbox-wrapper .form-checkbox + label:after {\n      content: '';\n      width: 22px;\n      height: 22px;\n      border: 2px solid #ccc;\n      border-radius: 2px;\n      position: absolute;\n      left: 0;\n      top: 0;\n      -webkit-transition: all 0s;\n      transition: all 0s; }\n.table-scroll-wrapper .enquiry-table table .field-checkbox-wrapper .form-checkbox:checked + label:after {\n      border: 2px solid #0084f6; }\n.table-scroll-wrapper .enquiry-table table .field-checkbox-wrapper .form-checkbox + label:before {\n      -webkit-transition: all 0s;\n      transition: all 0s;\n      width: 1px;\n      height: 1px;\n      left: 8px;\n      top: 9px;\n      position: absolute;\n      content: '';\n      border-top: 0;\n      border-right: 0;\n      border-left: 2px solid transparent;\n      border-bottom: 2px solid transparent;\n      -webkit-transform: rotate(-45deg);\n              transform: rotate(-45deg); }\n.table-scroll-wrapper .enquiry-table table .field-checkbox-wrapper .form-checkbox:checked + label:before {\n      border-left: 2px solid #0084f6;\n      border-bottom: 2px solid #0084f6;\n      width: 12px;\n      height: 5px;\n      left: 2px;\n      top: 5px; }\n.table-scroll-wrapper .enquiry-table table .field-checkbox-wrapper .form-checkbox:checked + label {\n      color: #0084f6; }\n.table-scroll-wrapper .enquiry-table .empty-table-wrapper {\n      height: 100px;\n      width: 100%;\n      text-align: center; }\n/* =================================================================================== */\n/* =================================================================================== */\n/* =================================================================================== */\n.time-picker .field-wrapper {\n  display: inline-block;\n  margin: 5px 10px 0 0; }\n.time-picker .field-wrapper .form-ctrl {\n    width: 70px; }\n.field-wrapper .btn {\n  padding: 4px 10px;\n  height: 30px; }\n/* =================================================================================== */\n/* =================================================================================== */\n/* =================================================================================== */\n/* =================================================================================== */\n/* =================================================================================== */\n/* =================================================================================== */\n.search-filter-wrapper .normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  width: 65%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  font-size: 14px;\n  border-radius: 4px; }\n.search-filter-wrapper .normal-btn {\n  padding: 8px 10px;\n  width: 30%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  float: left;\n  cursor: pointer; }\n.search-filter-wrapper .field-wrapper {\n  position: relative;\n  padding-top: 0 !important;\n  width: 40%;\n  float: left !important; }\n.search-filter-wrapper .field-wrapper .form-ctrl {\n    font: 400 12px 'Open sans',sans-serif;\n    border-top: none !important;\n    border-right: none !important;\n    border-left: none !important; }\n.search-filter-wrapper .field-wrapper label {\n  position: absolute !important;\n  left: 10% !important;\n  top: 1% !important; }\n.search-filter-wrapper .field-wrapper label:after {\n    left: 85% !important;\n    top: 10px !important; }\n.search-filter-wrapper .field-wrapper {\n  position: relative;\n  padding-top: 1px; }\n.search-filter-wrapper .field-wrapper.datePickerBox .form-ctrl {\n    position: relative;\n    z-index: 1;\n    background: transparent;\n    padding: 7px 10px;\n    border: 1px solid #ccc;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    margin: 0;\n    float: left;\n    border-right: 0;\n    height: 35px;\n    font: 400 12px 'Open sans',sans-serif;\n    width: 85% !important; }\n.search-filter-wrapper .field-wrapper.datePickerBox label {\n    position: absolute !important;\n    left: 3% !important;\n    top: -25% !important; }\n.search-filter-wrapper .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    left: 75% !important;\n    top: 5px !important;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.search-filter-wrapper .field-wrapper .date-clear {\n    position: absolute;\n    right: 40px;\n    top: 36px;\n    cursor: pointer;\n    color: #0084f6;\n    z-index: 1; }\n.registration-table {\n  padding: 30px 0; }\n.registration-table table thead tr {\n    line-height: 25px; }\n.registration-table table tbody tr {\n    line-height: 20px; }\n.registration-table table tbody tr td {\n      text-overflow: ellipsis; }\n.registration-table table tbody tr td .download-icon {\n        cursor: pointer; }\n.registration-table table tbody tr td .download-icon::after {\n          content: \"\\f0ed\";\n          font-family: FontAwesome; }\n::ng-deep .ui-splitbutton {\n  position: relative;\n  display: inline-block;\n  zoom: 1;\n  background: #fff;\n  border: none;\n  font-size: 14px !important;\n  font-weight: 500;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 32px;\n  min-width: 205px;\n  cursor: pointer;\n  color: #0084f6;\n  padding: 0;\n  font-size: 14px; }\n::ng-deep .ui-splitbutton .ui-button {\n    background: #fff;\n    color: #0084f6 !important;\n    font-size: 14px;\n    height: 30px !important;\n    font-weight: 600;\n    border: 1px solid #eaeaeb !important;\n    -webkit-transition: background-color 0s !important;\n    transition: background-color 0s !important; }\n::ng-deep .ui-splitbutton .ui-button:hover {\n      color: white !important; }\n::ng-deep .ui-splitbutton .ui-button:active {\n      color: white !important; }\n::ng-deep .ui-splitbutton .ui-button:focus {\n      color: white !important; }\n::ng-deep .ui-splitbutton .ui-corner-left {\n    min-width: 175px; }\n::ng-deep .ui-splitbutton .ui-menu {\n    border: none;\n    color: #1b1d1f;\n    background: #f6f7f9 0 0 repeat-x;\n    background: none;\n    top: 35px !important;\n    left: 0 !important;\n    outline: none;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    font-size: 14px;\n    text-align: left; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list {\n      font-size: 14px; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem {\n        font-size: 14px;\n        width: 100%;\n        max-width: 200px;\n        clear: both;\n        margin: .125em 0;\n        padding: 10px;\n        color: #0084f6;\n        margin: 0 0 -1px;\n        border: none !important;\n        -webkit-box-shadow: none;\n                box-shadow: none;\n        background: white; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem:hover {\n          background: #0084f6 !important;\n          color: white !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem:hover a {\n            color: white !important;\n            font-size: 14px !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem:active {\n          background: #0084f6 !important;\n          color: white !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem:active a {\n            color: white !important;\n            font-size: 14px !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem:focus {\n          background: #0084f6 !important;\n          color: white !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem:focus a {\n            color: white !important;\n            font-size: 14px !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem .ui-menuitem-link {\n          padding: 0 !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem a {\n          color: #0084f6 !important;\n          font-size: 14px !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem a:hover {\n            background: #0084f6 !important; }\n.middle-main {\n  position: relative; }\n.middle-main.hasFilter:before {\n    opacity: 1;\n    visibility: visible; }\n.middle-main.hasFilter .filter-fields {\n    opacity: 1;\n    visibility: visible;\n    top: 100%; }\n.middle-main.hasFilter .closeFilter {\n    display: block; }\n.normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  width: 74%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  border-right: 0;\n  font-size: 14px; }\n.normal-btn {\n  padding: 8px 10px;\n  width: 25%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  float: left;\n  background: #9c9b9b;\n  color: #fff;\n  cursor: pointer; }\n.filter-box {\n  padding: 10px 0; }\n.filter-right .btn {\n  min-width: 100px; }\n.filter-search {\n  position: relative;\n  border-bottom: 1px solid #d3d4d5;\n  margin: 0 10px 10px; }\n.filter-fields {\n  padding: 0 15px 20px;\n  background: #fff;\n  border: 1px solid #ccc;\n  position: absolute;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  z-index: 1;\n  left: 0;\n  top: 70%;\n  -webkit-transition: all .3s;\n  transition: all .3s;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-box-shadow: 0 2px 1px #e2e0e0;\n          box-shadow: 0 2px 1px #e2e0e0; }\n.filter-fields .form-ctrl {\n  background: transparent;\n  font: 400 12px 'Open sans',sans-serif;\n  border-bottom: solid 1px #d2d2d2; }\n.filter-fields .btn {\n  margin: 0;\n  width: 100%;\n  margin-top: 20px;\n  padding: 10px 12px;\n  height: auto; }\n.common-nav {\n  display: none; }\n.middle-section {\n  padding: 1%;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.middle-left {\n  width: 100%;\n  padding: 0; }\n.middle-top h1 {\n  margin-top: 8px;\n  margin-bottom: 10px;\n  float: none; }\n.middle-top aside {\n  float: left; }\n/*=======================filter type==============*/\n.search-enquiry-type-filter {\n  margin: 35px 0 10px; }\n.filter-label {\n  font-weight: 600; }\n.filter-label label {\n  font-weight: 600; }\n.type-filter li {\n  display: inline-block;\n  margin: 0 10px; }\n.export-print li,\n.pagination li {\n  display: inline-block;\n  margin-left: 10px;\n  font-size: 12px; }\n.export-print {\n  margin-bottom: 10px; }\n.export-print .print-icon {\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%229177 266 26 22%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %23999%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1224%22 data-name%3D%22Group 1224%22 transform%3D%22translate(8100 -6)%22%3E%0D    %3Cg id%3D%22Group_1222%22 data-name%3D%22Group 1222%22%3E%0D      %3Cg id%3D%22Group_1212%22 data-name%3D%22Group 1212%22%3E%0D        %3Cpath id%3D%22Path_163%22 data-name%3D%22Path 163%22 class%3D%22cls-1%22 d%3D%22M37%2C22.478h4.174a1.047%2C1.047%2C0%2C0%2C0%2C1.043-1.043V12.043A1.047%2C1.047%2C0%2C0%2C0%2C41.174%2C11H39.087%22 transform%3D%22translate(1059.782 267.47)%22%2F%3E%0D        %3Cpath id%3D%22Path_164%22 data-name%3D%22Path 164%22 class%3D%22cls-1%22 d%3D%22M4.13%2C11H2.043A1.047%2C1.047%2C0%2C0%2C0%2C1%2C12.043v9.391a1.047%2C1.047%2C0%2C0%2C0%2C1.043%2C1.043H6.217%22 transform%3D%22translate(1077 267.47)%22%2F%3E%0D        %3Crect id%3D%22Rectangle_269%22 data-name%3D%22Rectangle 269%22 class%3D%22cls-1%22 width%3D%2213.565%22 height%3D%2210.435%22 transform%3D%22translate(1083.217 273)%22%2F%3E%0D        %3Crect id%3D%22Rectangle_270%22 data-name%3D%22Rectangle 270%22 class%3D%22cls-1%22 width%3D%2213.565%22 height%3D%225.217%22 transform%3D%22translate(1083.217 287.77)%22%2F%3E%0D        %3Cline id%3D%22Line_125%22 data-name%3D%22Line 125%22 class%3D%22cls-1%22 x2%3D%2219.826%22 transform%3D%22translate(1080.087 283.94)%22%2F%3E%0D        %3Cline id%3D%22Line_126%22 data-name%3D%22Line 126%22 class%3D%22cls-1%22 y2%3D%221.094%22 transform%3D%22translate(1080.609 286.128)%22%2F%3E%0D        %3Cline id%3D%22Line_127%22 data-name%3D%22Line 127%22 class%3D%22cls-1%22 y1%3D%226.564%22 transform%3D%22translate(1081.13 275.735)%22%2F%3E%0D        %3Cline id%3D%22Line_128%22 data-name%3D%22Line 128%22 class%3D%22cls-1%22 y1%3D%226.564%22 transform%3D%22translate(1098.87 275.735)%22%2F%3E%0D      %3C%2Fg%3E%0D      %3Crect id%3D%22Rectangle_690%22 data-name%3D%22Rectangle 690%22 class%3D%22cls-2%22 width%3D%2226%22 height%3D%2222%22 transform%3D%22translate(1077 272)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    color: #888; }\n.export-print .export-icon {\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%229268 266 26 22%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %23999%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1223%22 data-name%3D%22Group 1223%22 transform%3D%22translate(8100 -6)%22%3E%0D    %3Cg id%3D%22Group_1211%22 data-name%3D%22Group 1211%22 transform%3D%22translate(0 -1)%22%3E%0D      %3Cpath id%3D%22Path_178%22 data-name%3D%22Path 178%22 class%3D%22cls-1%22 d%3D%22M11.588%2C3H3.353A2.36%2C2.36%2C0%2C0%2C0%2C1%2C5.353V19.47a2.36%2C2.36%2C0%2C0%2C0%2C2.353%2C2.353H17.47a2.36%2C2.36%2C0%2C0%2C0%2C2.353-2.353V11.235%22 transform%3D%22translate(1170 272.176)%22%2F%3E%0D      %3Cline id%3D%22Line_140%22 data-name%3D%22Line 140%22 class%3D%22cls-1%22 y1%3D%2210%22 x2%3D%2210%22 transform%3D%22translate(1180.412 274.588)%22%2F%3E%0D      %3Cpath id%3D%22Path_179%22 data-name%3D%22Path 179%22 class%3D%22cls-1%22 d%3D%22M30.059%2C8.059V1.588A.556.556%2C0%2C0%2C0%2C29.47%2C1H23%22 transform%3D%22translate(1160.941 273)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Crect id%3D%22Rectangle_691%22 data-name%3D%22Rectangle 691%22 class%3D%22cls-2%22 width%3D%2226%22 height%3D%2222%22 transform%3D%22translate(1168 272)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    margin-left: 25px; }\n.export-print .export-icon,\n  .export-print .print-icon {\n    background-size: 20px auto;\n    padding: 0 0 0 22px;\n    cursor: pointer;\n    font-size: 14px;\n    color: #888; }\n.export-print .export-icon:hover,\n    .export-print .print-icon:hover {\n      color: #0084f6; }\n.filter-res label {\n  font-size: 14px;\n  font-weight: 600; }\n.pagination {\n  margin: 0; }\n.pagination .first:before {\n    content: \"« \";\n    font-size: 16px;\n    font-weight: 800; }\n.pagination .last:after {\n    content: \" »\";\n    font-size: 16px;\n    font-weight: 800; }\n.pagination .batch-size {\n    font-size: 16px;\n    font-weight: 800;\n    border-bottom: 1px solid black; }\n.pagination li {\n    border-right: 1px solid #ccc;\n    padding: 0 7px;\n    margin: 0;\n    line-height: 10px;\n    font-weight: 800;\n    cursor: pointer; }\n.pagination li a {\n      line-height: 10px;\n      font-size: 16px;\n      font-weight: 800;\n      border: none;\n      padding: 0 14px; }\n.pagination li:last-child {\n  border-right: 0;\n  padding-right: 0; }\n.AdFilter-field {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  z-index: 1;\n  -webkit-box-shadow: #e2e0e0 0 2px 1px;\n          box-shadow: #e2e0e0 0 2px 1px;\n  padding: 0 15px 20px;\n  background: white;\n  border-width: 1px;\n  border-style: solid;\n  border-color: #cccccc;\n  -o-border-image: initial;\n     border-image: initial;\n  position: absolute;\n  height: 78vh;\n  overflow-y: auto; }\n.AdFilter-field .field-wrapper .date-clear {\n    position: absolute;\n    right: 0;\n    top: 58px;\n    cursor: pointer;\n    color: #0084f6;\n    z-index: 1; }\n.AdFilter-field .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    left: 93% !important;\n    top: 28px !important;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.newDate .field-wrapper {\n  margin: 15px 0; }\n.newDate .field-wrapper .date-clear {\n    position: absolute;\n    right: 43px;\n    top: 63px;\n    cursor: pointer;\n    color: #0084f6; }\n.newDate .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    left: 84% !important;\n    top: 32px !important;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.openAdFilter {\n  margin-top: 8px;\n  font-size: 14px;\n  font-weight: 600;\n  color: #0084f6; }\n.closeAdFilter {\n  margin-top: 8px;\n  font-size: 14px;\n  font-weight: 600;\n  color: #f44336; }\n.closeAdFilter svg {\n    width: 15px;\n    height: 16px;\n    display: inline-block;\n    vertical-align: bottom;\n    margin-right: 4px; }\n.closeAdFilter svg .cls-1 {\n      stroke: #f44336;\n      stroke-miterlimit: 10;\n      stroke-width: 2; }\n.closeAdFilter svg .cls-2 {\n      stroke: none; }\n/*===========================================action tooltip of table===================*/\n.enquiry-action {\n  position: relative;\n  cursor: pointer; }\n.enquiry-action .cls-1,\n  .enquiry-action .cls-2 {\n    fill: none;\n    stroke: transparent; }\n.enquiry-action svg {\n    width: 18px; }\n.enquiry-action .cls-2 {\n    stroke: #7d7f80;\n    stroke-miterlimit: 10; }\n.enquiry-action:hover .action-icon svg .cls-2 {\n    stroke: #0084f6;\n    stroke-miterlimit: 10; }\n.action-menu {\n  position: absolute;\n  background: #fff;\n  width: 350px;\n  border-radius: 0;\n  border: 1px solid #ccc;\n  bottom: 10px;\n  -webkit-box-shadow: 0 2px 4px 1px #ccc;\n          box-shadow: 0 2px 4px 1px #ccc;\n  -webkit-transform: translateX(-50%);\n          transform: translateX(-50%);\n  left: 200px;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all .6s;\n  transition: all .6s; }\n.enquiry-action:hover .action-menu {\n  visibility: visible;\n  opacity: 1;\n  bottom: 8px; }\n.action-menu-inner ul {\n  font-size: 0;\n  position: relative;\n  padding: 5px; }\n.action-menu-inner ul:after {\n  content: '';\n  position: absolute;\n  right: 0;\n  left: 0;\n  bottom: -15px;\n  margin: auto;\n  border-top: 8px solid #fff;\n  border-bottom: 8px solid transparent;\n  border-right: 8px solid transparent;\n  border-left: 8px solid transparent;\n  width: 0;\n  height: 0; }\n.action-menu-inner ul li {\n  display: inline-block;\n  text-align: center;\n  vertical-align: top;\n  font-size: 12px;\n  padding: 0 8px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  cursor: pointer;\n  width: 18%; }\n.action-menu-inner ul li:last-child {\n    width: 28%; }\n.action-menu-inner ul li:last-child svg {\n      width: 33px; }\n.action-menu-inner ul li.edit-detail-icon svg * {\n    fill: none;\n    stroke: #8b8b8b; }\n.action-menu-inner ul li.edit-detail-icon svg .cls-1 {\n    stroke: none;\n    /* stroke: #8b8b8b; */ }\n.action-menu-inner ul li:hover {\n    color: #0084f6; }\n.action-menu-inner ul li:hover .cls-2,\n    .action-menu-inner ul li:hover .cls-3 {\n      fill: none;\n      stroke: #0084f6; }\n.action-menu-inner ul li span {\n  display: block;\n  font-size: 9px;\n  text-align: center;\n  line-height: 10px; }\n.action-menu-inner .close {\n  position: absolute;\n  right: 4px;\n  top: 2px; }\n.action-menu-inner i {\n  display: block;\n  height: 32px; }\n.enquiry-action li svg {\n  width: 28px; }\n/**===============================search data=========================*/\n.search-data {\n  margin: 0; }\n.search-data th {\n    padding: 10px 20px;\n    font-weight: 500; }\n.search-data td {\n    font-size: 14px;\n    line-height: normal;\n    padding: 6px 5px; }\n.search-data tr td:first-child,\n  .search-data tr th:first-child {\n    padding: 15px 2px; }\n.search-data tr td:first-child .field-checkbox-wrapper,\n    .search-data tr th:first-child .field-checkbox-wrapper {\n      background: transparent; }\n.search-data tr th:last-child {\n    padding: 0; }\n/*=====================================mobile head menu css===========================*/\nul.customDropdown {\n  position: absolute;\n  top: 20%;\n  width: 100%;\n  height: auto;\n  background: #fff;\n  left: 0;\n  z-index: 11;\n  -webkit-box-shadow: 0 1px 2px 1px #e2e2e2;\n          box-shadow: 0 1px 2px 1px #e2e2e2; }\nul.customDropdown li {\n  padding: 10px 15px;\n  border-bottom: 1px solid #f5f5f5;\n  -webkit-transition: all .5s;\n  transition: all .5s;\n  cursor: pointer; }\nul.customDropdown li:hover {\n    background: #f5f5f5; }\nul.customDropdown li:first-child {\n  border: 0;\n  padding: 0; }\nul.customDropdown li:last-child {\n  border-bottom: 0; }\nul.customDropdown {\n  -webkit-transition: all 0.3s cubic-bezier(0.55, 0, 0.55, 0.2);\n  transition: all 0.3s cubic-bezier(0.55, 0, 0.55, 0.2);\n  -webkit-transition-duration: .15s;\n  transition-duration: .15s;\n  -webkit-transition-delay: .1s;\n  transition-delay: .1s;\n  opacity: 0;\n  visibility: hidden; }\nul.customDropdown.visibleDropdown {\n  visibility: visible;\n  opacity: 1;\n  top: 20%; }\nul.customDropdown li:hover {\n  background: #f5f5f5; }\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all .5s ease-in;\n  transition: all .5s ease-in; }\n.popupWrapper .popup {\n    max-width: 850px;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff;\n  width: 100%; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all .5s ease-in;\n  transition: all .5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all .5s ease-in;\n  transition: all .5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n/*=========================================registration popup form css==================*/\n.registration-fee-form {\n  overflow: hidden; }\n.print-output-section {\n  margin: 35px 0 25px;\n  border-top: 1px solid #deeaee;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  border-bottom: 1px solid #deeaee;\n  text-align: center;\n  font-size: 0; }\n.print-output-section li {\n    display: inline-block;\n    padding: 0 15px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    width: 25%;\n    border-right: 1px solid #deeaee;\n    font-size: 15px;\n    cursor: pointer;\n    color: #929292; }\n.print-output-section li:last-child {\n      border-right: 0; }\n.print-output-section li:hover {\n      color: #0084f6; }\n.print-output-section li svg {\n      width: 30px;\n      display: inline-block;\n      vertical-align: middle;\n      margin-right: 8px; }\n.print-output-section li svg .cls-1 {\n        stroke: none;\n        stroke: #929292; }\n.print-output-section li.svg-icon .cls-1 {\n      stroke: none; }\n.print-output-section li.svg-icon .cls-2 {\n      stroke: #929292; }\n.print-output-section li.svg-icon:hover .cls-2 {\n      stroke: #0084f6; }\n.print-output-section li:first-child:hover svg .cls-1 {\n      stroke: #0084f6; }\n/*=======================================confirmation =========================*/\n.confirmation-popup-content {\n  line-height: normal; }\n.confirmation-popup-content > div {\n    margin-bottom: 10px; }\n.confirmation-popup-content > div:first-child {\n      margin-bottom: 20px; }\n.confirmation-popup-content > div a,\n    .confirmation-popup-content > div p {\n      font-size: 16px;\n      line-height: 22px; }\n.confirmation-popup-content > div a {\n      font-weight: 600; }\n.confirmation-popup-content > div a:hover {\n      text-decoration: underline; }\n.confirmation-popup-content strong {\n    font-weight: 600; }\n.confirmation-popup-content .add-form-btns a {\n    margin-left: 20px;\n    font-size: 14px; }\n.popup-btn {\n  margin-top: 20px; }\n.popup-btn .btn {\n    font-size: 14px;\n    height: 30px; }\n.popup-btn .btn.redBtn {\n      color: #fff;\n      min-width: 160px; }\n.update-enquiry-form {\n  max-height: 380px;\n  overflow: hidden; }\n.update-enquiry-form .date-clear {\n    position: absolute;\n    right: 10px;\n    top: 10px;\n    cursor: pointer; }\n.update-enquiry-form ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n.update-enquiry-form .right-aside-wrapper {\n    width: 38%;\n    max-height: 360px;\n    overflow-x: hidden;\n    overflow-y: scroll; }\n.update-enquiry-form .right-aside-wrapper ::-webkit-scrollbar {\n      display: block;\n      width: 7px;\n      height: 7px; }\n.update-enquiry-form .right-aside-wrapper .row {\n      margin: 10px 5px 20px; }\n.update-enquiry-form .right-aside-wrapper .form-wrapper .submitter {\n      position: absolute;\n      right: 41px;\n      bottom: 41px; }\n.update-enquiry-form .left-aside-wrapper {\n    width: 60%;\n    max-height: 360px;\n    overflow: auto; }\n.update-enquiry-form .left-aside-wrapper.table-wrapper h4 {\n      margin: 0 0 15px;\n      font-weight: 600; }\n.update-enquiry-form .left-aside-wrapper.table-wrapper .enquiry-update-history {\n      /* min-height: 370px;\r\n                    max-height: 400px;\r\n                    overflow-y: auto;\r\n                    overflow-x: hidden; */ }\n.update-enquiry-form .left-aside-wrapper.table-wrapper .enquiry-update-history ::-webkit-scrollbar {\n        display: block;\n        width: 7px;\n        height: 7px; }\n.update-enquiry-form .left-aside-wrapper.table-wrapper table th {\n      text-align: left;\n      padding: 10px;\n      font-size: 14px; }\n.update-enquiry-form .left-aside-wrapper.table-wrapper table td {\n      text-align: left;\n      padding: 10px;\n      font-size: 14px; }\n.confirmation-popup-content:after {\n  content: '';\n  height: 8px;\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  width: 100%;\n  background: #8bc34a; }\n.row.extraMargin {\n  margin: 10px -15px 20px; }\n.sms-form .row {\n  margin: 0 -15px; }\n.sms-table-head {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex; }\n.sms-table-head .sms-tab {\n    display: inline-block;\n    padding: 10px;\n    background: #ffffff;\n    cursor: pointer; }\n.sms-table-head .sms-tab label {\n      font-weight: 700;\n      color: #0084f6; }\n.sms-table-head .sms-tab.active {\n      background: #0084f6;\n      -webkit-box-shadow: 0 0 0 1px #0084f6;\n              box-shadow: 0 0 0 1px #0084f6;\n      border-bottom: 1px solid #0084f6;\n      color: #ffffff; }\n.sms-table-head .sms-tab.active label {\n        color: #ffffff; }\n.popup-body-container {\n  max-width: 85%;\n  top: 2% !important;\n  left: 5% !important; }\n.sms-popup-content {\n  max-height: 80% !important;\n  display: -webkit-box !important;\n  display: -ms-flexbox !important;\n  display: flex !important;\n  overflow: hidden !important; }\n.sms-middle-section {\n  padding: 5px; }\n.sms-middle-section .table-container {\n    max-width: 100%;\n    min-height: 200px;\n    overflow: auto;\n    max-height: 250px; }\n.sms-middle-section .table-container td,\n    .sms-middle-section .table-container th {\n      text-align: left;\n      padding: 5px; }\n.sms-update {\n  min-height: 100%;\n  width: 100%; }\n.sms-update .sms-table {\n    min-height: 300px;\n    max-height: 450px;\n    border-top: 1px solid #eaeaeb;\n    border-right: 1px solid #eaeaeb;\n    width: 70%;\n    padding-left: 2px;\n    overflow-y: hidden;\n    overflow-x: hidden; }\n.sms-update .sms-table .sms-search-field {\n      padding: 5px 10px;\n      border: 1px solid #eaeaeb;\n      width: 65%;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      margin: 0 5px 0 0;\n      float: left;\n      border-right: 0;\n      height: 35px;\n      font-size: 14px;\n      outline: none; }\n.sms-update .sms-table .field-checkbox-wrapper,\n    .sms-update .sms-table .field-radio-wrapper {\n      position: relative;\n      padding-left: 25px;\n      margin-bottom: 10px; }\n.sms-update .sms-table .field-radio-wrapper .form-radio {\n      opacity: 0;\n      position: absolute;\n      left: 0;\n      top: 0;\n      width: 20px;\n      height: 20px;\n      z-index: 1; }\n.sms-update .sms-table .field-radio-wrapper .form-radio + label {\n      vertical-align: middle;\n      -webkit-transition: all .1s;\n      transition: all .1s; }\n.sms-update .sms-table .field-radio-wrapper .form-radio + label:after {\n      content: '';\n      width: 16px;\n      height: 16px;\n      border: 2px solid #ccc;\n      border-radius: 50%;\n      position: absolute;\n      left: 0;\n      top: 0;\n      -webkit-transition: all .1s;\n      transition: all .1s; }\n.sms-update .sms-table .field-radio-wrapper .form-radio:checked + label:after {\n      border: 2px solid #0084f6; }\n.sms-update .sms-table .field-radio-wrapper .form-radio + label:before {\n      -webkit-transition: all .1s;\n      transition: all .1s;\n      width: 1px;\n      height: 1px;\n      left: 9px;\n      top: 9px;\n      position: absolute;\n      content: ''; }\n.sms-update .sms-table .field-radio-wrapper .form-radio:checked + label:before {\n      content: '';\n      width: 10px;\n      height: 10px;\n      background: #0084f6;\n      border-radius: 50%;\n      left: 3px !important;\n      top: 3px !important; }\n.sms-update .sms-table .field-radio-wrapper .form-radio:checked + label {\n      color: #0084f6; }\n.sms-update .sms-grid-table {\n    min-height: 300px;\n    max-height: 450px;\n    border-top: 1px solid #eaeaeb;\n    border-right: 1px solid #eaeaeb;\n    width: 100%;\n    padding-left: 2px;\n    overflow-y: hidden;\n    overflow-x: hidden; }\n.sms-update .sms-preview {\n    min-height: 450px;\n    border-top: 1px solid #eaeaeb;\n    width: 30%;\n    padding: 0 5px;\n    position: absolute;\n    right: 9px; }\n.sms-update .sms-preview .sms-preview-header {\n      margin-bottom: 25px; }\n.sms-update .sms-grid-preview {\n    min-height: 450px;\n    border-top: 1px solid #eaeaeb;\n    width: 100%;\n    padding: 0 5px;\n    right: 9px; }\n.sms-update .sms-grid-preview .sms-preview-header {\n      margin-bottom: 25px; }\n.field-sms-wrapper {\n  position: relative;\n  padding-top: 10px;\n  border: 1px solid #eaeaeb;\n  overflow: hidden; }\n.field-sms-wrapper textarea {\n    width: 100%;\n    max-height: 200px;\n    color: #555555;\n    -webkit-transition: background-color .2s ease 0s;\n    transition: background-color .2s ease 0s; }\n.field-sms-wrapper textarea::focus {\n      background: none repeat scroll 0 0 #FFFFFF;\n      outline-width: 0; }\n.new-sms-form {\n  padding: 0;\n  width: 100%; }\n.new-sms-form .row {\n    margin: 0; }\n.new-sms-form .new-sms-wrapper .new-sms-textarea {\n    width: 100%;\n    border: 1px solid #eaeaeb;\n    padding: 5px; }\n.new-sms-form .new-sms-wrapper .red {\n    color: red; }\n.new-sms-form .create-cancel-small .btn {\n    margin-left: 0;\n    padding: 0 5px; }\n.red {\n  color: red; }\n.add-edit {\n  cursor: pointer; }\n.add-edit .add-sms {\n    line-height: 8px;\n    padding: 4px 0 0;\n    font-size: 24px;\n    display: inline-block;\n    width: 20px;\n    height: 20px;\n    border-radius: 50%;\n    margin-right: 7px;\n    vertical-align: middle;\n    text-align: center; }\n/* ======================== DropDown Menu ================================= */\n/* Dropdown Button */\n.bulk-dropbtn {\n  padding: 0 0 3px;\n  background: #fff;\n  border: none;\n  margin-left: 10px;\n  display: inline-block;\n  font-size: 14px;\n  font-weight: 600;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 35px;\n  cursor: pointer; }\n/* The container <div> - needed to position the dropdown content */\n.bulk-dropdown {\n  position: relative;\n  display: inline-block;\n  /* Dropdown Content (Hidden by Default) */\n  /* Links inside the dropdown */\n  /* Change color of dropdown links on hover */ }\n.bulk-dropdown .bulk-dropbtn {\n    padding: 0 0 3px;\n    background: #fff;\n    border: none;\n    margin-left: 10px;\n    display: inline-block;\n    font-size: 14px;\n    font-weight: 600;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    height: 35px;\n    cursor: pointer; }\n.bulk-dropdown .bulk-dropbtn .caret {\n      margin-left: 5px;\n      display: inline-block;\n      width: 0;\n      height: 0;\n      vertical-align: middle;\n      border-top: 4px dashed;\n      border-right: 4px solid transparent;\n      border-left: 4px solid transparent;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      font-size: 14px;\n      font-weight: 400;\n      line-height: 1.42857143;\n      text-align: center;\n      white-space: nowrap;\n      cursor: pointer;\n      -webkit-user-select: none;\n         -moz-user-select: none;\n          -ms-user-select: none;\n              user-select: none;\n      font-family: inherit;\n      text-transform: none;\n      text-indent: 0;\n      text-shadow: none; }\n.bulk-dropdown .bulk-dropbtn-border {\n    padding: 7px 12px;\n    background: #fff;\n    border-bottom: 1px solid #ccc;\n    border-top: none;\n    border-right: none;\n    border-left: none;\n    margin-left: 10px;\n    display: inline-block;\n    font-size: 14px;\n    font-weight: 600;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    height: 35px;\n    cursor: pointer;\n    color: #0084f6; }\n.bulk-dropdown .bulk-dropbtn-border:active {\n      -webkit-box-shadow: none;\n              box-shadow: none; }\n.bulk-dropdown .bulk-dropbtn-border::focus {\n      outline: none; }\n.bulk-dropdown .bulk-dropdown-content {\n    display: block;\n    position: absolute;\n    background-color: #f9f9f9;\n    min-width: 70px;\n    left: 75%;\n    -webkit-box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);\n            box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);\n    z-index: 1;\n    text-align: left;\n    cursor: pointer; }\n.bulk-dropdown .bulk-dropdown-content a {\n    color: black;\n    padding: 12px 16px;\n    text-decoration: none;\n    display: block; }\n.bulk-dropdown .bulk-dropdown-content a:hover {\n    background-color: #f1f1f1; }\n.sidenav {\n  position: absolute;\n  position: absolute;\n  display: none;\n  width: 0;\n  -webkit-transition: 100ms ease-in-out;\n  transition: 100ms ease-in-out;\n  height: 90vh;\n  overflow: hidden;\n  right: 0;\n  top: 60px;\n  padding: 0;\n  bottom: 0;\n  z-index: 1;\n  z-index: 1;\n  right: 0;\n  background: white;\n  border-left: 1px solid rgba(211, 212, 213, 0.5);\n  -webkit-box-shadow: -3px 0 6px rgba(119, 119, 119, 0.26);\n          box-shadow: -3px 0 6px rgba(119, 119, 119, 0.26); }\n.sidenav ::-webkit-scrollbar {\n    display: none;\n    width: 7px;\n    height: 7px; }\n.sidenav .sidewrapper {\n    height: 90vh;\n    overflow-x: hidden;\n    overflow-y: auto; }\n.sidenav .sidewrapper ::-webkit-scrollbar {\n      display: none;\n      width: 7px;\n      height: 7px; }\n.sidenav .closebtn {\n  right: 20px;\n  left: 88%;\n  width: 30px;\n  text-align: right;\n  top: 15px;\n  font-size: 20px;\n  font-weight: 900;\n  position: absolute;\n  cursor: pointer;\n  z-index: 100;\n  margin-right: 0;\n  text-decoration: none;\n  font-size: 25px;\n  color: #808080;\n  display: block;\n  padding: 0; }\n.form-wrapper {\n  background: transparent;\n  margin: 5px 0; }\n.form-wrapper.datepicker span {\n    position: absolute;\n    top: 35px;\n    right: 20px;\n    font-weight: 600;\n    font-size: 16px;\n    color: red;\n    cursor: pointer;\n    width: 20px;\n    text-align: center;\n    /* &::before {\r\n                        content: '';\r\n                        background: url('/assets/images/calendar.svg') no-repeat;\r\n                        position: absolute;\r\n                        right: 25px;\r\n                        top: 0px;\r\n                        width: 21px;\r\n                        height: 21px;\r\n                        z-index: 0;\r\n                    } */ }\n.form-wrapper label {\n    font-size: 12px;\n    font-weight: 400;\n    color: rgba(0, 0, 0, 0.77);\n    padding-bottom: 2px;\n    text-decoration: none;\n    text-transform: uppercase;\n    -webkit-font-smoothing: antialiased; }\n.form-wrapper .side-form-ctrl {\n    background: white;\n    border: 1px solid rgba(119, 119, 119, 0.419608);\n    width: 100%;\n    padding: 8px 5px;\n    font-weight: 600;\n    font-size: 14px;\n    color: black; }\n.form-wrapper .side-form-ctrl.bsDatepicker {\n      padding: 5px;\n      width: 100%; }\n.form-wrapper.timepick {\n    width: 50%;\n    padding: 1px 15px; }\n.form-wrapper.timepick .tbox {\n      width: 100%; }\n.form-wrapper.timepick .tbox .times {\n        display: inline-block; }\n.form-wrapper.timepick .tbox .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        padding: 8px 5px;\n        font-weight: 600;\n        font-size: 14px;\n        color: black; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mins {\n          width: 80px; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mers {\n          width: 50px; }\n.form-wrapper {\n  background: transparent;\n  margin: 5px 0; }\n.form-wrapper.datepicker span {\n    position: absolute;\n    top: 35px;\n    right: 20px;\n    font-weight: 600;\n    font-size: 16px;\n    color: red;\n    cursor: pointer;\n    width: 20px;\n    text-align: center;\n    /* &::before {\r\n                            content: '';\r\n                            background: url('/assets/images/calendar.svg') no-repeat;\r\n                            position: absolute;\r\n                            right: 25px;\r\n                            top: 0px;\r\n                            width: 21px;\r\n                            height: 21px;\r\n                            z-index: 0;\r\n                        } */ }\n.form-wrapper label {\n    font-size: 12px;\n    font-weight: 400;\n    color: rgba(0, 0, 0, 0.77);\n    padding-bottom: 2px;\n    text-decoration: none;\n    text-transform: uppercase;\n    -webkit-font-smoothing: antialiased; }\n.form-wrapper .side-form-ctrl {\n    background: white;\n    border: 1px solid rgba(119, 119, 119, 0.419608);\n    width: 100%;\n    padding: 8px 5px;\n    font-weight: 600;\n    font-size: 14px;\n    color: black;\n    cursor: context-menu; }\n.form-wrapper .side-form-ctrl.bsDatepicker {\n      padding: 5px;\n      width: 100%; }\n.form-wrapper.timepick {\n    width: 50%;\n    padding: 1px 15px; }\n.form-wrapper.timepick .tbox {\n      width: 100%; }\n.form-wrapper.timepick .tbox .times {\n        display: inline-block; }\n.form-wrapper.timepick .tbox .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        padding: 8px 5px;\n        font-weight: 600;\n        font-size: 14px;\n        color: black; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mins {\n          width: 80px; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mers {\n          width: 50px; }\n#main {\n  -webkit-transition: margin-right .5s;\n  transition: margin-right .5s;\n  padding: 16px; }\n@media screen and (max-height: 450px) {\n  .sidenav {\n    padding-top: 15px; }\n  .sidenav a {\n    font-size: 18px; } }\n.skeleton:empty {\n  margin: 55px 0 0;\n  width: 100%;\n  height: 300px;\n  background-image: linear-gradient(90deg, rgba(255, 255, 255, 0) 10%, rgba(255, 255, 255, 0.5) 20%, rgba(255, 255, 255, 0.5) 50%, rgba(255, 255, 255, 0.5) 20%, rgba(255, 255, 255, 0) 80%), linear-gradient(lightgray 10px, transparent 0), linear-gradient(lightgray 10px, transparent 0), linear-gradient(lightgray 10px, transparent 0), linear-gradient(lightgray 10px, transparent 0), linear-gradient(lightgray 10px, transparent 0), linear-gradient(lightgray 10px, transparent 0);\n  background-repeat: repeat-y;\n  background-size: 350px 200px, 350px 200px, 350px 200px, 350px 200px, 350px 200px, 350px 200px, 150px 200px, 150px 200px;\n  background-position: 80px 0px, 80px 0px, 80px 0px, 80px 40px, 80px 80px, 80px 120px;\n  -webkit-animation: shine 1s infinite;\n  animation: shine 1s infinite; }\n@-webkit-keyframes shine {\n  to {\n    background-position: 0 0, 100% 0, 100px 0, 100px 40px, 100px 80px, 100px 120px; } }\n@keyframes shine {\n  to {\n    background-position: 0 0, 100% 0, 100px 0, 100px 40px, 100px 80px, 100px 120px; } }\n.visibiltyClass {\n  height: 70px !important; }\n.visibiltyClass .upload-icon {\n    visibility: hidden; }\n.sms-Action-td {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex; }\n.sms-Action-td .change-status {\n    margin: auto 5px auto auto; }\n.hideElement {\n  visibility: hidden;\n  opacity: 0; }\n.select-dates .field-wrapper.datePickerBox:after {\n  content: '';\n  background: url(\"/./assets/images/calendar.svg\") no-repeat;\n  position: absolute;\n  right: 2px;\n  top: 28px;\n  width: 21px;\n  height: 21px;\n  z-index: 20; }\n.login-tube nav > ul > li .dropdown {\n  min-width: 205px; }\n.black-bg {\n  background: rgba(10, 10, 10, 0.3);\n  position: fixed;\n  top: 0;\n  height: 100%;\n  left: 0;\n  z-index: 1;\n  width: 100%; }\n.common-tab {\n  width: 100%; }\n.common-tab .menu_list {\n    cursor: pointer;\n    color: #0084f6;\n    background: #fff;\n    border-color: #0084f6;\n    font-weight: normal;\n    padding: 10px 5px;\n    text-align: center;\n    width: 15%; }\n.common-tab .menu_list:hover {\n      background: #0084f6;\n      color: #fff; }\n.common-tab .menu_list.active {\n      background: #0084f6;\n      color: #ffffff; }\n.emailGridImgHeader {\n  border: none;\n  padding: 10px;\n  padding-right: 15px;\n  padding-bottom: 0; }\n.emailGridImg {\n  width: 80%;\n  height: 50%;\n  max-width: 80%;\n  max-height: 50%;\n  padding-bottom: 5px;\n  margin-left: 10%; }\ntable tr.selected {\n  background: #dceff7 !important;\n  -webkit-box-shadow: 0 11px 8px -10px #CCC, 0 -11px 13px -9px #CCC;\n          box-shadow: 0 11px 8px -10px #CCC, 0 -11px 13px -9px #CCC;\n  -webkit-transform: scale(1);\n          transform: scale(1); }\n.absent_popup {\n  position: fixed;\n  top: 2%;\n  left: 25%;\n  right: 25%;\n  width: 50%;\n  z-index: 550;\n  background: white;\n  -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n          box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n  border-radius: 6px; }\n.absent_popup .absent_student {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    text-align: right; }\n.absent_popup .absent_student .header {\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      padding: 10px;\n      -webkit-box-pack: right;\n          -ms-flex-pack: right;\n              justify-content: right; }\n.absent_popup .absent_student .header .close-btn {\n        color: #b1b1b1; }\n.absent_popup .absent_student .main_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column; }\n.absent_popup .absent_student .main_container .for_absent {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row; }\ninput[type=radio] {\n  -webkit-appearance: radio;\n     -moz-appearance: radio;\n          appearance: radio; }\n.black-bg1 {\n  background: rgba(10, 10, 10, 0.3);\n  position: fixed;\n  top: 0;\n  height: 100%;\n  left: 0;\n  z-index: 500;\n  width: 100%; }\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-home/enquiry-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EnquiryHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_enquiry_services_fetchenquiry_service__ = __webpack_require__("./src/app/services/enquiry-services/fetchenquiry.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_fetchprefilldata_service__ = __webpack_require__("./src/app/services/fetchprefilldata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_enquiry_services_post_enquiry_data_service__ = __webpack_require__("./src/app/services/enquiry-services/post-enquiry-data.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_enquiry_services_popup_handler_service__ = __webpack_require__("./src/app/services/enquiry-services/popup-handler.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_rxjs_Rx__ = __webpack_require__("./node_modules/rxjs/_esm5/Rx.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/utils/facade/browser.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__services_multiBranchdata_service__ = __webpack_require__("./src/app/services/multiBranchdata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__services_table_preference_table_preferences_service__ = __webpack_require__("./src/app/services/table-preference/table-preferences.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__services_http_service__ = __webpack_require__("./src/app/services/http.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







/* Third party imports */








var EnquiryHomeComponent = /** @class */ (function () {
    /*Declaration Fin*/
    function EnquiryHomeComponent(enquire, prefill, router, pops, postdata, cd, actRoute, auth, multiBranchService, _commService, messageService, _tablePreferencesService, httpService) {
        var _this = this;
        this.enquire = enquire;
        this.prefill = prefill;
        this.router = router;
        this.pops = pops;
        this.postdata = postdata;
        this.cd = cd;
        this.actRoute = actRoute;
        this.auth = auth;
        this.multiBranchService = multiBranchService;
        this._commService = _commService;
        this.messageService = messageService;
        this._tablePreferencesService = _tablePreferencesService;
        this.httpService = httpService;
        this.sourceEnquiry = [];
        this.smsSourceApproved = [];
        this.smsSourceOpen = [];
        this.checkedStatus = [];
        this.filtered = [];
        this.enqstatus = [];
        this.enqPriority = [];
        this.campaignList = [];
        this.enqFollowType = [];
        this.enqAssignTo = [];
        this.enqStd = [];
        this.enqSubject = [];
        this.sources = [];
        this.enqScholarship = [];
        this.paymentMode = [];
        this.schools = [];
        this.slots = [];
        this.customComponents = [];
        this.statusString = [];
        this.smsGroupSelected = [];
        this.selectedSlots = [];
        this.slotIdArr = [];
        this.branchesList = [];
        this.cityList = [];
        this.areaList = [];
        this.closingReasonDataSource = [];
        this.indexJSON = [];
        this.selectedRowGroup = [];
        this.componentPrefill = [];
        this.componentRenderer = [];
        this.customComponentResponse = [];
        this.course_subject = [];
        this.course_course = [];
        this.masterCourseData = [];
        this.referredByData = [];
        this.sizeArr = [25, 50, 100, 150, 200, 500];
        this.commentFormData = {};
        this.emailGridData = [];
        this.EmailThumbnailUrl = '';
        this.EmailGridSelectedObject = null;
        this.viewPopUp = false;
        this.isSendGridEnable = false;
        this.downloadEnquiryReportAccess = false;
        /* Variable to handle popups */
        this.varJson = {
            message: '',
            selectedSlotsString: '',
            sortBy: 'followUpDateTime',
            PageIndex: 1,
            totalEnquiry: 0,
            availableSMS: 0,
            smsDataLength: 0,
            selectedRowCount: 0,
            currentDirection: 'desc',
            insttitueId: '',
            fetchingDataMessage: 1,
            sendSmsFormData: { baseIds: [], messageArray: [] },
            searchBarData: null,
            searchBarDate: '',
            displayBatchSize: 100,
            downloadReportOption: 1,
            summaryReport: { from_date: "", to_date: "" },
            enquiryInfo: '',
            smsShowType: 'approvedSms',
            showDownloadSummary: false,
            isFilterApplied: false,
        };
        this.timeJson = { hour: '', minute: '', meridian: '' };
        this.isMainBranch = 'N';
        // smsSearchData: string = "";
        this.emailSubject = "";
        this.smsSelectedRowsLength = 0;
        this.flagJSON = {
            isEnquiryAdmin: false,
            isConverted: false,
            hasReceipt: false,
            isadmitted: false,
            notClosednAdmitted: false,
            isClosed: false,
            isAssignEnquiry: false,
            smsBtnToggle: false,
            isEnquiryOptions: false,
            isProfessional: false,
            isMessageAddOpen: false,
            isMultiSms: false,
            isAllSelected: false,
            isApprovedTab: true,
            isOpenTab: false,
            isSideBar: false,
            isConvertToStudent: false,
            isRippleLoad: false,
            subBranchSelected: false,
            summaryOptions: false,
            showDateRange: false,
            showPreference: false,
            notificationType: 'SMS'
        };
        this.newSmsString = { data: "", type: "", };
        this.messageCount = 0;
        this.messageCountForEdit = 0;
        this.selectedRow = {};
        this.componentListObject = {};
        /* Model For Registration, valid only for professional institute where status is registred else will thow an error with status code 400 */
        this.registrationForm = {
            institute_enquiry_id: "",
            amount: "",
            paymentDate: __WEBPACK_IMPORTED_MODULE_7_moment__().format('YYYY-MM-DD'),
            paymentMode: "",
            reference: "",
        };
        this.selectedOption = {
            email: { show: false, id: 'email' },
            Gender: { show: false, id: 'Gender' },
            standard: { show: false, id: 'standard' },
            subjects: { show: false, id: 'subjects' }
        };
        this.myOptions = [
            { id: 'email', name: 'Email' },
            { id: 'Gender', name: 'Gender' },
            { id: 'standard', name: 'Standard' },
            { id: 'subjects', name: 'Subject' }
        ];
        /* Model for Enquiry Update Popup Form */
        this.updateFormData = {
            comment: "",
            status: "",
            statusValue: "",
            institution_id: sessionStorage.getItem('institute_id'),
            isEnquiryUpdate: "Y",
            closedReason: null,
            slot_id: null, priority: "",
            follow_type: "",
            followUpDate: "",
            commentDate: __WEBPACK_IMPORTED_MODULE_7_moment__().format('YYYY-MM-DD'),
            followUpTime: "",
            followUpDateTime: '',
            isEnquiryV2Update: "N",
            isRegisterFeeUpdate: "N",
            amount: null,
            paymentMode: null,
            paymentDate: null,
            reference: null,
            walkin_followUpDate: '',
            walkin_followUpTime: { hour: '', minute: '' },
            is_follow_up_time_notification: 0,
            source_instituteId: '-1',
            closing_reason_id: '0'
        };
        this.selectedSMS = {
            message: "",
            message_id: "",
            sms_type: "",
            status: "",
            statusValue: "",
            date: "",
            feature_type: "",
            institute_name: "",
        };
        this.statFilter = [
            { value: 'All', prop: 'All', checked: false, disabled: false },
            { value: 'Pending Followup', prop: 'Pending', checked: true, disabled: false },
            { value: 'Open', prop: 'Open', checked: false, disabled: false },
            { value: 'In_Progress', prop: 'In_Progress', checked: false, disabled: false },
            { value: 'Registered', prop: 'Registered', checked: false, disabled: false },
            { value: 'Student_Admitted', prop: 'Student_Admitted', checked: false, disabled: false },
            { value: 'Inactive', prop: 'Inactive', checked: false, disabled: false },
            { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }
        ];
        /* Settings for SMS Table Display */
        this.smsHeader = {
            message: { title: 'Message', id: 'message', show: true },
            statusValue: { title: 'Status.', id: 'statusValue', show: false },
            date: { title: 'Date', id: 'date', show: true },
            action: { title: 'Action', id: 'action', show: true },
            status: { title: 'Status Key', id: 'status', show: false },
            feature_type: { title: 'Feature Type.', id: 'feature_type', show: false },
            message_id: { title: 'Message Id.', id: 'message_id', show: false },
            sms_type: { title: 'Sms Type.', id: 'sms_type', show: false },
        };
        /* Model for institute Data */
        this.instituteData = {
            name: "",
            phone: "",
            email: "",
            enquiry_no: "",
            priority: "",
            status: -1,
            filtered_statuses: "",
            follow_type: "",
            followUpDate: this.getDateFormated(null, 'YYYY-MM-DD'),
            enquiry_date: "",
            assigned_to: -1,
            standard_id: -1,
            subjectIdArray: null,
            master_course_name: '',
            courseIdArray: null,
            subject_id: -1,
            is_recent: "N",
            slot_id: -1,
            filtered_slots: "",
            isDashbord: "N",
            enquireDateFrom: "",
            enquireDateTo: "",
            updateDate: "",
            updateDateFrom: "",
            updateDateTo: "",
            start_index: 0,
            batch_size: this.varJson.displayBatchSize,
            closedReason: "",
            enqCustomLi: null,
            sorted_by: "",
            order_by: "",
            commentShow: 'false'
        };
        /* Form for advanced filter  */
        this.advancedFilterForm = {
            name: "",
            phone: "",
            email: "",
            enquiry_no: "",
            priority: "",
            status: -1,
            commentShow: 'false',
            filtered_statuses: "",
            follow_type: "",
            followUpDate: this.getDateFormated(null, 'YYYY-MM-DD'),
            enquiry_date: "",
            assigned_to: -1,
            standard_id: -1,
            subjectIdArray: null,
            master_course_name: '-1',
            courseIdArray: null,
            subject_id: -1,
            is_recent: "Y",
            slot_id: -1,
            filtered_slots: "",
            isDashbord: "N",
            enquireDateFrom: "",
            enquireDateTo: "",
            updateDate: "",
            updateDateFrom: "",
            updateDateTo: "",
            start_index: 0,
            batch_size: this.varJson.displayBatchSize,
            closedReason: "",
            enqCustomLi: null,
            source_id: "-1",
            school_id: "-1",
            list_id: "-1",
            city: '',
            area: '',
            referred_by: ''
        };
        this.enquirySettings = [
            { primaryKey: 'enquiry_no', header: 'Enquiry No', priority: 1, format: this.varJson.currentDirection },
            { primaryKey: 'name', header: 'Name', priority: 2 },
            { primaryKey: 'phone', header: 'Contact No', priority: 3 },
            { primaryKey: 'statusValue', header: 'Status', priority: 4 },
            { primaryKey: 'priority', header: 'Priority', priority: 5 },
            { primaryKey: 'source_name', header: 'Source', priority: 6 },
            { primaryKey: 'followUpDate', header: 'Follow up Date', format: this.varJson.currentDirection, priority: 7, },
            { primaryKey: 'updateDate', header: 'Last Updated', priority: 8 },
            { primaryKey: 'assigned_name', header: 'Asignee Name', priority: 9 },
            { primaryKey: 'follow_type', header: 'Follow Up Type', priority: 10 },
            { primaryKey: 'standard', header: 'Standard', priority: 11 },
            { primaryKey: 'referred_by_name', header: 'Referred By', priority: 12 },
            { primaryKey: 'noOfCoursesAssigned', header: 'No. of Courses Assigned', priority: 12 }
        ];
        this.assignMultipleForm = {
            enqLi: [],
            assigned_to: "",
            source_instituteId: ''
        };
        // Customizable Table VAriable
        this.displayKeys = [];
        this.tableSetting = {
            tableDetails: { title: 'Enquiry List', key: 'enquiry.home', showTitle: false },
            search: { title: 'Search', showSearch: false },
            keys: this.displayKeys,
            selectAll: { showSelectAll: true, option: 'single', title: 'Select Enquiry', checked: false, key: 'enquiry_no' },
            actionSetting: {},
            displayMessage: "Enter Detail to Search"
        };
        if (_commService.valueCheck(sessionStorage.getItem('userid'))) {
            this.router.navigate(['/authPage']);
        }
        this.actRoute.queryParams.subscribe(function (e) {
            if ((!_this._commService.valueCheck(e.id))) {
                if (_this._commService.valueCheck(e.action)) {
                    _this.router.navigate(['/view/enquiry/edit/' + e.id]);
                }
                else {
                    switch (e.action) {
                        case 'enquiryEdit': {
                            _this.router.navigate(['/view/enquiry/edit/' + e.id]);
                            break;
                        }
                        case 'enquiryUpdate': {
                            //console.log(e);
                            break;
                        }
                    }
                }
            }
        });
    }
    /* OnInit Function */
    EnquiryHomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.flagJSON.isProfessional = true;
            }
            else {
                _this.flagJSON.isProfessional = false;
            }
        });
        this.auth.currentInstituteId.subscribe(function (res) {
            _this.varJson.insttitueId = res;
        });
        if (this.flagJSON.isProfessional) {
            this.enquirySettings[10].header = "Master Course";
        }
        this.isEnquiryAdministrator();
        this.FetchEnquiryPrefilledData();
        //this.prefill.getLeadSource().subscribe( (data)=>{ console.log(data)})
        /* Fetch prefill data after table data load completes */
        /* Dropdown items for Bulk Actions */
        this.roleManagementForBulkAdd();
        /* Load paginated enquiry data from server */
        var params = sessionStorage.getItem('dashBoardParam');
        if (params != "" && params != null && params != undefined) {
            this.checkIfRoutedFromEnquiry();
            sessionStorage.setItem('dashBoardParam', '');
        }
        else {
            this.loadTableDatatoSource(this.instituteData);
        }
        this.cd.markForCheck();
        /* Fetch the status of message from  popup handler service */
        this.pops.currentMessage.subscribe(function (message) {
            _this.cd.markForCheck();
            if (_this.selectedRow.institute_enquiry_id != null && _this.selectedRow.institute_enquiry_id != undefined) {
                if (message == 'sms') {
                    _this.cd.markForCheck();
                    _this.smsServicesInvoked();
                    _this.varJson.message = message;
                    _this.cd.markForCheck();
                    _this.smsSelectedRows = _this.selectedRow;
                    _this.flagJSON.isApprovedTab = true;
                    _this.cd.markForCheck();
                }
                else if (message == 'update') {
                    _this.varJson.enquiryInfo = _this.selectedRow.institute_enquiry_id;
                    _this.varJson.message = message;
                }
                else {
                    _this.varJson.message = message;
                    _this.cd.markForCheck();
                }
            }
        });
        /* SMS message service handler to communicate between components */
        this.pops.currentSms.subscribe(function (res) {
            if (res == 'edit') {
                _this.cd.markForCheck();
                _this.editSms();
            }
        });
        sessionStorage.setItem('varJson.displayBatchSize', this.varJson.displayBatchSize.toString());
        this.checkMultiBranchStatus();
        // Customizable Table
        this.tableSetting.keys = this.enquirySettings;
        if (this._tablePreferencesService.getTablePreferences(this.tableSetting.tableDetails.key) != null) {
            this.displayKeys = this._tablePreferencesService.getTablePreferences(this.tableSetting.tableDetails.key);
            this.tableSetting.keys = this.displayKeys;
            if (this.displayKeys.length == 0) {
                this.setDefaultValues();
            }
        }
        else {
            this.setDefaultValues();
        }
        if (sessionStorage.getItem('permissions')) {
            var permissions = JSON.parse(sessionStorage.getItem('permissions'));
            if (permissions.includes('714')) {
                this.varJson.showDownloadSummary = false;
            }
            if (permissions.includes('712')) {
                this.varJson.showDownloadSummary = true;
            }
        }
        if (sessionStorage.getItem('permissions') == undefined ||
            sessionStorage.getItem('permissions') == ''
            || sessionStorage.getItem('username') == 'admin') {
            this.varJson.showDownloadSummary = true;
        }
        this.checkRoleAccess();
    };
    EnquiryHomeComponent.prototype.checkRoleAccess = function () {
        if (sessionStorage.getItem('downloadEnquiryReportAccess') == 'true') {
            this.downloadEnquiryReportAccess = true;
        }
    };
    EnquiryHomeComponent.prototype.timeChanges = function (ev) {
        var obj = {};
        var time = ev.split(' ');
        obj.hour = time[0];
        obj.meridian = time[1];
        return obj;
    };
    EnquiryHomeComponent.prototype.getDateFormated = function (value, format) {
        if (value) {
            return __WEBPACK_IMPORTED_MODULE_7_moment__(value).format(format);
        }
        return __WEBPACK_IMPORTED_MODULE_7_moment__().format(format);
    };
    EnquiryHomeComponent.prototype.isEnquiryAdministrator = function () {
        if (this._commService.checkUserIsAdmin()) {
            this.flagJSON.isEnquiryAdmin = true;
        }
        else {
            if (this._commService.checkUserHadPermission('115')) {
                this.flagJSON.isEnquiryAdmin = true;
            }
            else {
                this.flagJSON.isEnquiryAdmin = false;
            }
        }
    };
    /* Load Table data with respect to the institute data provided */
    EnquiryHomeComponent.prototype.loadTableDatatoSource = function (obj) {
        var _this = this;
        this.flagJSON.isRippleLoad = true;
        this.varJson.fetchingDataMessage = 1;
        this.flagJSON.isAllSelected = false;
        this.sourceEnquiry = [];
        this.closeEnquiryFullDetails();
        this.flagJSON.isSideBar = false;
        /* start index of object passed is zero then create pagination */
        if (obj.start_index == 0) {
            return this.enquire.getAllEnquiry(obj).subscribe(function (data) {
                if (data.length != 0) {
                    _this.varJson.totalEnquiry = data[0].totalcount;
                    _this.sourceEnquiry = data;
                    _this.cd.markForCheck();
                    return _this.sourceEnquiry;
                }
                else {
                    _this.varJson.fetchingDataMessage = 2;
                    _this.showErrorMessage('info', 'No Records Found', 'We did not find any enquiry for the specified query');
                    _this.varJson.totalEnquiry = data.length;
                    _this.cd.markForCheck();
                }
            }, function (err) {
                _this.flagJSON.isRippleLoad = false;
                _this.varJson.fetchingDataMessage = 2;
                _this.showErrorMessage(_this.messageService.toastTypes.error, 'Unable To Connect To Server', 'Please check your internet connection or contact proctur support if the issue persist');
                _this.varJson.totalEnquiry = 0;
                _this.cd.markForCheck();
            });
        }
        else {
            return this.enquire.getAllEnquiry(obj).subscribe(function (data) {
                _this.flagJSON.isRippleLoad = false;
                if (data.length != 0) {
                    _this.sourceEnquiry = data;
                    _this.cd.markForCheck();
                }
                else {
                    _this.varJson.fetchingDataMessage = 2;
                    _this.showErrorMessage('info', 'No Records Found', 'We did not find any enquiry for the specified query');
                    _this.varJson.totalEnquiry = 0;
                    _this.cd.markForCheck();
                }
            }, function (err) {
                _this.flagJSON.isRippleLoad = false;
                _this.varJson.varJson.fetchingDataMessage = 2;
                _this.showErrorMessage(_this.messageService.toastTypes.error, 'Unable To Connect To Server', 'Please check your internet connection or contact proctur support if the issue persist');
                _this.varJson.totalEnquiry = 0;
                _this.cd.markForCheck();
            });
        }
    };
    /* Function to fetch prefill data for advanced filter */
    EnquiryHomeComponent.prototype.FetchEnquiryPrefilledData = function () {
        var _this = this;
        /* Status */
        this.prefill.getEnqStatus().subscribe(function (data) { _this.enqstatus = data; });
        /* Campaigns */
        this.prefill.getCampaignsList().subscribe(function (data) { _this.campaignList = data; });
        /* Priority */
        var priority = this.prefill.getEnqPriority().subscribe(function (data) { _this.enqPriority = data; });
        /* FollowUp Type */
        this.prefill.getFollowupType().subscribe(function (data) { _this.enqFollowType = data; });
        /* Assign To */
        this.prefill.getAssignTo().subscribe(function (data) { _this.enqAssignTo = data; });
        /* Sources */
        this.prefill.getLeadSource().subscribe(function (data) { _this.sources = data; });
        /* Schools */
        this.prefill.getSchoolDetails().subscribe(function (data) { _this.schools = data; });
        /* Standard */
        this.prefill.getEnqStardards().subscribe(function (data) { _this.enqStd = data; });
        /* Slots */
        if (this.flagJSON.isProfessional) {
            this.prefill.getEnquirySlots().subscribe(function (res) { res.forEach(function (el) { var obj = { label: el.slot_name, value: el, status: false }; _this.slots.push(obj); }); });
        }
        /* Payment Modes */
        this.prefill.fetchPaymentModes().subscribe(function (data) { _this.paymentMode = data; });
        /* Custom Components */
        this.fetchCustomComponentData();
        /* Master Course / Standard */
        if (!this.flagJSON.isProfessional) {
            this.fetchMasterCourseDetails();
        }
        ;
        // City Area Fetch //
        this.prefill.getCityList().subscribe(function (res) { _this.cityList = res; });
        // Closing Reason //
        this.prefill.getClosingReasons().subscribe(function (res) { _this.closingReasonDataSource = res; });
        //  Referred By //
        this.fetchReferredByData();
    };
    EnquiryHomeComponent.prototype.fetchReferredByData = function () {
        var _this = this;
        var url = '/api/v1/enquiry_campaign/master/lead_referred_by/' + sessionStorage.getItem('institute_id') + '/all';
        this.httpService.getData(url).subscribe(function (res) {
            _this.referredByData = res;
        }, function (err) {
            console.log(err);
        });
    };
    EnquiryHomeComponent.prototype.fetchMasterCourseDetails = function () {
        var _this = this;
        this.prefill.getMasterCourseData().subscribe(function (res) { _this.masterCourseData = res; });
    };
    EnquiryHomeComponent.prototype.fetchCustomComponentData = function () {
        var _this = this;
        this.customComponents = [];
        this.prefill.fetchCustomComponentEmpty()
            .subscribe(function (data) {
            if (data != null) {
                data.forEach(function (el) {
                    /* General template for custom component */
                    var obj = {};
                    switch (el.type) {
                        case 2: {
                            obj = { data: el, id: el.component_id, is_required: el.is_required, is_searchable: el.is_searchable, label: el.label, prefilled_data: _this.createPrefilledData(el.prefilled_data.split(',')), selected: [], selectedString: '', type: el.type, value: el.enq_custom_value == "" ? false : true, };
                            break;
                        }
                        case 3: {
                            obj = { data: el, id: el.component_id, is_required: el.is_required, is_searchable: el.is_searchable, label: el.label, prefilled_data: _this.createPrefilledData(el.prefilled_data.split(',')), selected: [], selectedString: "", type: el.type, value: el.enq_custom_value };
                            break;
                        }
                        case 4: {
                            obj = { data: el, id: el.component_id, is_required: el.is_required, is_searchable: el.is_searchable, label: el.label, prefilled_data: _this.createPrefilledDataType4(el.prefilled_data.split(','), el.enq_custom_value.split(','), el.defaultValue.split(',')), selected: [], selectedString: '', type: el.type, value: el.enq_custom_value };
                            break;
                        }
                        default:
                            /* Type +> Input/Date */
                            // if (el.type != 2 && el.type != 4 && el.type != 3) {
                            obj = { data: el, id: el.component_id, is_required: el.is_required, is_searchable: el.is_searchable, label: el.label, prefilled_data: _this.createPrefilledData(el.prefilled_data.split(',')), selected: [], selectedString: '', type: el.type, value: el.enq_custom_value };
                    }
                    _this.customComponents.push(obj);
                });
            }
            _this.emptyCustomComponent = _this.componentListObject;
        });
    };
    EnquiryHomeComponent.prototype.createPrefilledDataType4 = function (dataArr, selected, def) {
        var customPrefilled = [];
        if (selected.length != 0 && (!this._commService.valueCheck(selected[0]))) {
            dataArr.forEach(function (el) { var obj = { data: el, checked: selected.includes(el) }; customPrefilled.push(obj); });
        }
        else {
            dataArr.forEach(function (el) { var obj = { data: el, checked: def.indexOf(el) != -1 }; customPrefilled.push(obj); });
        }
        return customPrefilled;
    };
    /* Custom Compoenent array creater */
    EnquiryHomeComponent.prototype.createPrefilledData = function (dataArr) {
        var customPrefilled = [];
        dataArr.forEach(function (el) {
            var obj = {
                displayName: el.toLowerCase(),
                data: el,
                checked: false
            };
            customPrefilled.push(obj);
        });
        return customPrefilled;
    };
    /* if custom component is of type multielect then toggle the visibility of the dropdowm */
    EnquiryHomeComponent.prototype.multiselectVisible = function (elid) {
        var targetid = elid + "multi";
        if (elid != null && elid != '') {
            if (__WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(targetid).classList.contains('hide')) {
                __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(targetid).classList.remove('hide');
            }
            else {
                __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(targetid).classList.add('hide');
            }
        }
    };
    /* if custom component is of type multielect then update the selected or unselected data*/
    EnquiryHomeComponent.prototype.updateMultiSelect = function (data, id) {
        this.customComponents.forEach(function (el) {
            if (el.id == id) {
                var x_1 = [];
                var y = el.prefilled_data;
                y.forEach(function (e) { if (e.checked) {
                    x_1.push(e.data);
                } });
                el.selected = x_1;
                el.selectedString = el.selected.join(',');
                el.value = el.selectedString;
            }
        });
    };
    /* Function to search data on smart table */
    EnquiryHomeComponent.prototype.searchDatabase = function () {
        this.clearFilterAdvanced();
        this.statusString = [];
        this.statFilter = [{ value: 'All', prop: 'All', checked: true, disabled: false }, { value: 'Pending Followup', prop: 'Pending', checked: false, disabled: false }, { value: 'Open', prop: 'Open', checked: false, disabled: false }, { value: 'In_Progress', prop: 'In_Progress', checked: false, disabled: false }, { value: 'Registered', prop: 'Registered', checked: false, disabled: false }, { value: 'Student_Admitted', prop: 'Student_Admitted', checked: false, disabled: false }, { value: 'Inactive', prop: 'Inactive', checked: false, disabled: false }, { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }];
        this.indexJSON = [];
        this.instituteData.filtered_statuses = this.statusString.join(',');
        this.varJson.PageIndex = 1;
        /* Searchbar empty */
        if (this._commService.valueCheck(this.varJson.searchBarData)) {
            this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
            this.loadTableDatatoSource(this.instituteData);
        }
        else if (!this._commService.valueCheck(this.varJson.searchBarData)) {
            if (isNaN(this.varJson.searchBarData)) {
                /* Valid string entered */
                if (this.validateString(this.varJson.searchBarData)) {
                    this.instituteData = { name: this.varJson.searchBarData, phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.loadTableDatatoSource(this.instituteData);
                }
                else {
                    this.showErrorMessage(this.messageService.toastTypes.info, '', 'Please enter a valid name or number');
                }
            }
            else {
                /* mobile number detected */
                if (this.validateNumber(this.varJson.searchBarData)) {
                    this.instituteData = { name: "", phone: this.varJson.searchBarData, email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.loadTableDatatoSource(this.instituteData);
                }
                else {
                    this.instituteData = { name: "", phone: "", email: "", enquiry_no: this.varJson.searchBarData, commentShow: 'false', priority: "", status: -1, follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.loadTableDatatoSource(this.instituteData);
                }
            }
        }
    };
    /* regex validation for name atleast one word required */
    EnquiryHomeComponent.prototype.validateString = function (data) {
        return /^[a-zA-Z ]{1,40}$/.test(data);
    };
    /* Custom validation suited only for indian mobile numbers*/
    EnquiryHomeComponent.prototype.validateNumber = function (data) {
        return /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[123456789]\d{9}$/.test(data);
        ;
    };
    /* Function to open advanced filter */
    EnquiryHomeComponent.prototype.openAdFilter = function () {
        //document.getElementById('middleMainForEnquiryList').classList.add('hasFilter')
        //console.log(this.advancedFilterForm);
        //document.getElementById('middleMainForEnquiryList').classList.add('hasFilter');
        this.closeEnquiryFullDetails();
        this.flagJSON.isSideBar = false;
        var classArray = ['adFilterOpen', 'adFilterExitVisible', 'qfilt', 'customizableTableSection'];
        this.addHideClass(classArray);
        var removeClassNames = ['adFilterExit', 'advanced-filter-section'];
        this.removeHideClass(removeClassNames);
    };
    EnquiryHomeComponent.prototype.addHideClass = function (classArray) {
        classArray.forEach(function (className) {
            __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(className).classList.add('hide');
        });
    };
    EnquiryHomeComponent.prototype.removeHideClass = function (removeClassNames) {
        removeClassNames.forEach(function (className) {
            __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(className).classList.remove('hide');
        });
    };
    /** set notification type */
    EnquiryHomeComponent.prototype.sendNotificationType = function (type) {
        this.flagJSON.notificationType = type;
    };
    EnquiryHomeComponent.prototype.showSendGridData = function (type) {
        var _this = this;
        this.flagJSON.notificationType = type;
        var url = "/api/v1/alerts/config/sendGrid/emailTemplate/" + sessionStorage.getItem('institute_id');
        this.flagJSON.isRippleLoad = true;
        this.emailGridData = [];
        this.httpService.getData(url).subscribe(function (res) {
            _this.flagJSON.isRippleLoad = false;
            _this.emailGridData = res.result;
            _this.cd.markForCheck();
        }, function (err) {
            _this.flagJSON.isRippleLoad = false;
            console.log(err);
        });
        this.emailGridData.forEach(function (element) {
            if (element.template_updated_date != null || element.template_updated_date != '') {
                element.template_updated_date = __WEBPACK_IMPORTED_MODULE_7_moment__(element.template_updated_date).format('DD-MMM-YYYY');
            }
        });
    };
    EnquiryHomeComponent.prototype.opEmailGridSelected = function (object, i) {
        this.selectedTableRow = i;
        this.EmailGridSelectedObject = object;
    };
    EnquiryHomeComponent.prototype.viewThumbnailUrl = function (url) {
        this.viewPopUp = true;
        this.EmailThumbnailUrl = url;
    };
    EnquiryHomeComponent.prototype.closeViewPopUp = function () {
        this.viewPopUp = false;
    };
    EnquiryHomeComponent.prototype.sendEmailGrid = function () {
        var _this = this;
        if (this.EmailGridSelectedObject != null || this.EmailGridSelectedObject != undefined) {
            var url = "/api/v1/enquiry_manager/sendEmail/" + sessionStorage.getItem('institute_id');
            var obj = {
                baseIds: this.selectedRowGroup,
                sendGridTemplateId: this.EmailGridSelectedObject.template_id
            };
            this.flagJSON.isRippleLoad = true;
            this.httpService.postData(url, obj).subscribe(function (res) {
                _this.flagJSON.isRippleLoad = false;
                _this.showErrorMessage(_this.messageService.toastTypes.success, '', res.message);
                _this.cd.markForCheck();
            }, function (err) {
                _this.flagJSON.isRippleLoad = false;
                console.log(err);
            });
        }
        else {
            this.showErrorMessage(this.messageService.toastTypes.error, '', 'Please select email template');
        }
        // this.httpService.postData(url,)
    };
    /* Function to close advanced filter */
    EnquiryHomeComponent.prototype.closeAdFilter = function () {
        var hideClassNames = ['adFilterExitVisible', 'qfilt', 'adFilterOpen', 'customizableTableSection'];
        this.removeHideClass(hideClassNames);
        var removeHideClassNames = ['advanced-filter-section', 'adFilterExit'];
        this.addHideClass(removeHideClassNames);
    };
    EnquiryHomeComponent.prototype.updateRegisterEnquiry = function () {
        this.flagJSON.isConvertToStudent = true;
        this.updateFormData.follow_type = "Walkin";
        this.updateFormData.walkin_followUpDate = this.getDateFormated(new Date(), 'YYYY-MM-DD');
        this.updateFormData.walkin_followUpTime = this.getFollowupTime();
        this.pushUpdatedEnquiry();
    };
    EnquiryHomeComponent.prototype.getFollowupTime = function () {
        var hour = parseInt(__WEBPACK_IMPORTED_MODULE_7_moment__(new Date()).format('hh'));
        var min = __WEBPACK_IMPORTED_MODULE_7_moment__(new Date()).format('mm');
        var mer = __WEBPACK_IMPORTED_MODULE_7_moment__(new Date()).format('A');
        if (parseInt(min) % 5 != 0) {
            min = Math.ceil(parseInt(min) / 5) * 5;
            if (min >= 60) {
                min = '00';
                if (hour == 12) {
                    hour = '1';
                    if (mer == 'AM') {
                        mer = 'PM';
                    }
                    else {
                        mer = 'AM';
                    }
                }
                else {
                    hour += 1;
                    var formattedNumber = ("0" + hour).slice(-2);
                    hour = formattedNumber.toString();
                }
            }
        }
        return (hour + ":" + min + " " + mer);
    };
    /* Push the updated enquiry to server */
    EnquiryHomeComponent.prototype.pushUpdatedEnquiry = function () {
        var _this = this;
        if (this.validateTime()) {
            if (this.updateFormData.followUpDate != "Invalid date") {
                this.flagJSON.isRippleLoad = true;
                this.updateFormData.comment = this.updateFormData.comment;
                this.updateFormData.follow_type = this.getFollowUpReverse(this.updateFormData.follow_type);
                this.updateFormData.priority = this.getPriorityReverse(this.updateFormData.priority);
                var followupdateTime = "";
                if (!this._commService.valueCheck(this.timeJson.hour)) {
                    var time = this.timeChanges(this.timeJson.hour);
                    var followUpTime = time.hour + ":" + this.timeJson.minute + " " + time.meridian;
                    followupdateTime = this.getDateFormated(this.updateFormData.followUpDate, 'DD-MMM-YY') + " " + followUpTime;
                    this.updateFormData.followUpTime = followUpTime;
                }
                followupdateTime = this.getDateFormated(this.updateFormData.followUpDate, 'DD-MMM-YY');
                if (this.flagJSON.isConvertToStudent === false) {
                    if (!this._commService.valueCheck(this.updateFormData.walkin_followUpTime.hour)) {
                        var time = this.timeChanges(this.updateFormData.walkin_followUpTime.hour);
                        var walkin_followUpTime = time.hour + ":" + this.updateFormData.walkin_followUpTime.minute + " " + time.meridian;
                        this.updateFormData.walkin_followUpTime = walkin_followUpTime;
                    }
                    else {
                        this.updateFormData.walkin_followUpTime = "";
                    }
                    if (this._commService.valueCheck(this.updateFormData.walkin_followUpDate)) {
                        var walkinfollowUpDate = this.getDateFormated(this.updateFormData.walkin_followUpDate, 'YYYY-MM-DD');
                        this.updateFormData.walkin_followUpDate = walkinfollowUpDate;
                    }
                    else {
                        this.updateFormData.walkin_followUpDate = "";
                    }
                }
                if (this.updateFormData.is_follow_up_time_notification) {
                    this.updateFormData.is_follow_up_time_notification = 1;
                }
                else if (!this.updateFormData.is_follow_up_time_notification) {
                    this.updateFormData.is_follow_up_time_notification = 0;
                }
                if (this.updateFormData.followUpDate != "Invalid date") {
                    this.updateFormData.followUpDate = this.getDateFormated(this.updateFormData.followUpDate, 'YYYY-MM-DD');
                    this.postdata.updateEnquiryForm(this.selectedRow.institute_enquiry_id, this.updateFormData).subscribe(function (res) {
                        _this.flagJSON.isRippleLoad = false;
                        _this.showErrorMessage(_this.messageService.toastTypes.success, _this.messageService.object.enquiryMessages.update, 'Your enquiry has been successfully submitted');
                        if (_this.flagJSON.isConvertToStudent) {
                            var obj = {
                                name: _this.selectedRow.name,
                                phone: _this.selectedRow.phone,
                                email: _this.selectedRow.email,
                                gender: _this.selectedRow.gender,
                                dob: _this.getDateFormated(_this.selectedRow.dob, "YYYY-MM-DD"),
                                parent_email: _this.selectedRow.parent_email,
                                parent_name: _this.selectedRow.parent_name,
                                parent_phone: _this.selectedRow.parent_phone,
                                enquiry_id: _this.selectedRow.institute_enquiry_id,
                                institute_enquiry_id: _this.selectedRow.institute_enquiry_id
                            };
                            sessionStorage.setItem('studentPrefill', JSON.stringify(obj));
                            _this.router.navigate(['/view/student/add']);
                        }
                        else {
                            _this.closePopup();
                            _this.loadTableDatatoSource(_this.instituteData);
                        }
                    }, function (err) {
                        _this.flagJSON.isRippleLoad = false;
                        _this.showErrorMessage(_this.messageService.toastTypes.error, _this.messageService.object.enquiryMessages.failUpdate, 'There was an error processing your request');
                    });
                }
                else {
                    this.flagJSON.isRippleLoad = false;
                    this.showErrorMessage(this.messageService.toastTypes.error, this.messageService.object.dateTimeMessages.invalideDateTime, 'Please select a valid date time for follow up');
                }
            }
            else {
                this.flagJSON.isRippleLoad = false;
                this.showErrorMessage(this.messageService.toastTypes.error, this.messageService.object.dateTimeMessages.invalideDateTime, 'Please select a valid date time for follow up');
            }
        }
        else {
            this.showErrorMessage(this.messageService.toastTypes.error, this.messageService.object.dateTimeMessages.invalideDateTime, "Please enter a valid date time");
        }
    };
    EnquiryHomeComponent.prototype.validateTime = function () {
        /* some time selected by user or nothing*/
        var check = false;
        if ((this.timeJson.hour != '' && this.timeJson.minute != '') || (this.timeJson.hour == '' && this.timeJson.minute == '')) {
            check = true;
        }
        else {
            return check;
        }
        if ((this.updateFormData.walkin_followUpTime.hour != "" && this.updateFormData.walkin_followUpTime.minute != "") || (this.updateFormData.walkin_followUpTime.hour == "" && this.updateFormData.walkin_followUpTime.minute == "")) {
            check = true;
        }
        else {
            check = false;
        }
        return check;
    };
    /* update the enquiry id for enquiry update pop up */
    EnquiryHomeComponent.prototype.updateStatusForEnquiryUpdate = function (val) {
        var _this = this;
        this.enqstatus.forEach(function (el) { if (el.data_value == val) {
            _this.updateFormData.status = el.data_key;
        } });
    };
    /* Delete Enquiry  */
    EnquiryHomeComponent.prototype.deleteEnquiry = function () {
        var _this = this;
        this.flagJSON.isRippleLoad = true;
        this.postdata.deleteEnquiryById(this.selectedRow.institute_enquiry_id).subscribe(function (res) {
            _this.flagJSON.isRippleLoad = false;
            _this.showErrorMessage('success', "Enquiry Deleted", "Your enquiry has been deleted");
            _this.closePopup();
            _this.cd.markForCheck();
            _this.loadTableDatatoSource(_this.instituteData);
        }, function (err) {
            _this.flagJSON.isRippleLoad = false;
            _this.showErrorMessage(_this.messageService.toastTypes.error, _this.messageService.object.enquiryMessages.failDelete, err.error.message);
            _this.closePopup();
            _this.loadTableDatatoSource(_this.instituteData);
        });
    };
    /* Make Registration Payment Data update */
    EnquiryHomeComponent.prototype.registerPayment = function () {
        var _this = this;
        this.flagJSON.isRippleLoad = true;
        this.registrationForm.institute_enquiry_id = this.selectedRow.institute_enquiry_id.toString();
        this.registrationForm.paymentDate = this.getDateFormated(this.registrationForm.paymentDate, 'YYYY-MM-DD');
        this.postdata.updateRegisterationPayment(this.registrationForm).subscribe(function (res) {
            _this.flagJSON.isRippleLoad = false;
            _this.showErrorMessage(_this.messageService.toastTypes.success, 'Registration Fee Updated', '');
            _this.cd.markForCheck();
            _this.selectedRow.invoice_no = res.otherDetails.invoice_no;
            _this.flagJSON.hasReceipt = true;
            _this.registrationForm = { institute_enquiry_id: "", amount: "", paymentDate: "", paymentMode: "", reference: "", };
            _this.cd.markForCheck();
        }, function (err) {
            _this.flagJSON.isRippleLoad = false;
            _this.showErrorMessage(_this.messageService.toastTypes.error, '', 'There was an error processing your request');
        });
    };
    /* Service to fetch sms records from server and update table*/
    EnquiryHomeComponent.prototype.smsServicesInvoked = function () {
        var _this = this;
        this.flagJSON.isRippleLoad = true;
        /* store the data from server and update table */
        this.cd.markForCheck();
        this.enquire.fetchAllSms().subscribe(function (data) {
            _this.flagJSON.isRippleLoad = false;
            _this.isSendGridEnable = data[0].is_sendGrid_enable;
            _this.cd.markForCheck();
            _this.smsSourceApproved = [];
            _this.smsSourceOpen = [];
            _this.varJson.smsDataLength = data.length;
            _this.varJson.availableSMS = data[0].institute_sms_quota_available;
            _this.cd.markForCheck();
            data.forEach(function (el) {
                if (el.status == 1) {
                    _this.cd.markForCheck();
                    _this.smsSourceApproved.push(el);
                }
                else {
                    _this.cd.markForCheck();
                    _this.smsSourceOpen.push(el);
                }
            });
            _this.switchSmsTab(_this.varJson.smsShowType);
        }, function (err) {
            _this.flagJSON.isRippleLoad = false;
            _this.showErrorMessage(_this.messageService.toastTypes.error, 'Error loading SMS', 'Please check your internet connection or refresh');
        });
    };
    EnquiryHomeComponent.prototype.switchSmsTab = function (id) {
        this.varJson.smsShowType = id;
        switch (id) {
            case 'approvedSms':
                {
                    this.flagJSON.isApprovedTab = true;
                    this.flagJSON.isOpenTab = false;
                    this.flagJSON.smsBtnToggle = false;
                    this.flagJSON.isAllSelected = false;
                    this.selectedSMS = { message: "", message_id: "", sms_type: "", status: "", statusValue: "", date: "", feature_type: "", institute_name: "", };
                    if (__WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(id).classList) {
                        if (!__WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(id).classList.contains('active')) {
                            __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(id).classList.add('active');
                            __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('openSms').classList.remove('active');
                        }
                    }
                }
                break;
            case 'openSms':
                {
                    this.flagJSON.isApprovedTab = false;
                    this.flagJSON.isOpenTab = true;
                    this.flagJSON.smsBtnToggle = false;
                    this.flagJSON.isAllSelected = true;
                    this.selectedSMS = { message: "", message_id: "", sms_type: "", status: "", statusValue: "", date: "", feature_type: "", institute_name: "", };
                    if (__WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(id).classList) {
                        if (!__WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(id).classList.contains('active')) {
                            __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById(id).classList.add('active');
                            __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('approvedSms').classList.remove('active');
                        }
                    }
                }
                break;
            default:
        }
    };
    EnquiryHomeComponent.prototype.hasUnicode = function (str) {
        for (var i = 0; i < str.length; i++) {
            if (str.charCodeAt(i) > 127)
                return true;
        }
        return false;
    };
    EnquiryHomeComponent.prototype.countNumberOfMessage = function () {
        var uniCodeFlag = this.hasUnicode(this.newSmsString.data);
        var charLimit = 160;
        if (uniCodeFlag) {
            charLimit = 70;
        }
        if (this.newSmsString.data.length == 0) {
            this.messageCount = 0;
        }
        else if (this.newSmsString.data.length > 0 && this.newSmsString.data.length <= charLimit) {
            this.messageCount = 1;
        }
        else {
            var count = Math.ceil(this.newSmsString.data.length / charLimit);
            console.log(count);
            this.messageCount = count;
        }
    };
    /* push new sms template to server and update the table */
    EnquiryHomeComponent.prototype.addNewSmsTemplate = function () {
        var _this = this;
        if (this.newSmsString.data.trim() == '') {
            this.showErrorMessage(this.messageService.toastTypes.error, '', 'Please enter a valid text message');
        }
        else {
            var sms = { feature_type: 2, message: this.newSmsString.data, sms_type: "Transactional" };
            this.flagJSON.isRippleLoad = true;
            this.postdata.addNewSmsTemplate(sms).subscribe(function (res) {
                _this.flagJSON.isRippleLoad = false;
                if (res.statusCode == 200) {
                    _this.showErrorMessage(_this.messageService.toastTypes.success, _this.messageService.object.SMSMessages.addNewSMS, '');
                    _this.cd.markForCheck();
                    _this.newSmsString.data = '';
                    _this.cd.markForCheck();
                    _this.enquire.fetchAllSms().subscribe(function (data) {
                        _this.cd.markForCheck();
                        _this.smsSourceApproved = [];
                        _this.smsSourceOpen = [];
                        _this.varJson.smsDataLength = data.length;
                        _this.varJson.availableSMS = data[0].institute_sms_quota_available;
                        _this.cd.markForCheck();
                        data.forEach(function (el) {
                            if (el.status == 1) {
                                _this.cd.markForCheck();
                                _this.smsSourceApproved.push(el);
                            }
                            else {
                                _this.cd.markForCheck();
                                _this.smsSourceOpen.push(el);
                            }
                        });
                    }, function (err) {
                        _this.showErrorMessage('error', '', err.error.message);
                    });
                    _this.cd.markForCheck();
                }
            }, function (err) {
                _this.flagJSON.isRippleLoad = false;
                _this.showErrorMessage('error', '', err.error.message);
            });
        }
    };
    /* push new sms template to server and update the table */
    EnquiryHomeComponent.prototype.addNewEmailTemplate = function () {
        var _this = this;
        if (this.selectedSMS.message.trim() == '') {
            this.showErrorMessage(this.messageService.toastTypes.error, '', 'Please enter a valid text message');
        }
        if (this.emailSubject.trim() == '') {
            this.showErrorMessage(this.messageService.toastTypes.error, '', 'Please enter the subject');
        }
        else {
            var messageId = [];
            messageId.push((this.selectedSMS.message_id).toString());
            var email = {
                "baseIds": this.selectedRowGroup,
                "messageArray": messageId,
                "subject": this.emailSubject
            };
            this.flagJSON.isRippleLoad = true;
            this.cd.markForCheck();
            this.postdata.addNewEmailTemplate(email).subscribe(function (res) {
                _this.flagJSON.isRippleLoad = false;
                _this.cd.markForCheck();
                if (res.statusCode == 200) {
                    _this.showErrorMessage(_this.messageService.toastTypes.success, res.message, '');
                    _this.cd.markForCheck();
                    _this.emailSubject = '';
                    _this.cd.markForCheck();
                    _this.enquire.fetchAllSms().subscribe(function (data) {
                        _this.cd.markForCheck();
                        _this.smsSourceApproved = [];
                        _this.smsSourceOpen = [];
                        _this.varJson.smsDataLength = data.length;
                        _this.varJson.availableSMS = data[0].institute_sms_quota_available;
                        _this.cd.markForCheck();
                        data.forEach(function (el) {
                            if (el.status == 1) {
                                _this.cd.markForCheck();
                                _this.smsSourceApproved.push(el);
                            }
                            else {
                                _this.cd.markForCheck();
                                _this.smsSourceOpen.push(el);
                            }
                        });
                    }, function (err) {
                        _this.showErrorMessage('error', 'Error', err.error.message);
                    });
                    _this.cd.markForCheck();
                }
            }, function (err) {
                _this.flagJSON.isRippleLoad = false;
                _this.cd.markForCheck();
                _this.showErrorMessage('error', 'Error', 'Notification sender id not approved. Please contact to support team.');
            });
        }
    };
    /* Stores data for row user has clicked of selected */
    EnquiryHomeComponent.prototype.appSmsSelected = function (row, id) {
        this.cd.markForCheck();
        this.selectedSMS = row;
        // document.getElementById('appradiosms' + id).click();
    };
    /* Stores data for row user has clicked of selected */
    EnquiryHomeComponent.prototype.opSmsSelected = function (row, id) {
        this.cd.markForCheck();
        this.selectedSMS = row;
        // document.getElementById('opradiosms' + id).click();
    };
    /* toggle visibility for add new sms DIV */
    EnquiryHomeComponent.prototype.addNewMessage = function () {
        var content = __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('sms-toggler-icon').innerHTML;
        if (content == "-") {
            __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('sms-toggler-icon').innerHTML = "+";
            this.newSmsString.data = "";
            this.flagJSON.isMessageAddOpen = false;
        }
        else if (content == "+") {
            __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('sms-toggler-icon').innerHTML = "-";
            this.flagJSON.isMessageAddOpen = true;
        }
    };
    /* SMS button visibility */
    EnquiryHomeComponent.prototype.editSms = function () {
        this.flagJSON.smsBtnToggle = true;
    };
    /* Sms edit mode cancel */
    EnquiryHomeComponent.prototype.cancelSmsEdit = function () {
        this.flagJSON.isApprovedTab = false;
        this.flagJSON.isOpenTab = false;
        this.flagJSON.smsBtnToggle = false;
        this.flagJSON.isAllSelected = false;
        this.flagJSON.smsBtnToggle = false;
        this.smsServicesInvoked();
    };
    EnquiryHomeComponent.prototype.countNumberOfMessageForEdit = function () {
        var uniCodeFlag = this.hasUnicode(this.selectedSMS.message);
        var charLimit = 160;
        if (uniCodeFlag) {
            charLimit = 70;
        }
        if (this.selectedSMS.message.length == 0) {
            this.messageCountForEdit = 0;
        }
        else if (this.selectedSMS.message.length > 0 && this.selectedSMS.message.length <= charLimit) {
            this.messageCountForEdit = 1;
        }
        else {
            var count = Math.ceil(this.selectedSMS.message.length / charLimit);
            console.log(count);
            this.messageCountForEdit = count;
        }
    };
    /* Update the sms template */
    EnquiryHomeComponent.prototype.saveEditedSms = function () {
        var _this = this;
        var data = { message: this.selectedSMS.message };
        this.flagJSON.isRippleLoad = true;
        this.postdata.saveEditedSms(this.selectedSMS.message_id, data).subscribe(function (res) {
            _this.flagJSON.isRippleLoad = false;
            //"SMS Template saved"
            _this.showErrorMessage(_this.messageService.toastTypes.success, _this.messageService.object.SMSMessages.saveSMS, 'Your sms has been sent for approval');
            _this.cancelSmsEdit();
        }, function (err) {
            _this.flagJSON.isRippleLoad = false;
            _this.showErrorMessage(_this.messageService.toastTypes.error, _this.messageService.object.SMSMessages.failSMS, 'Please check your internet connection or try again later');
        });
    };
    /* Approved SMS template send */
    EnquiryHomeComponent.prototype.sendSmsTemplate = function () {
        var _this = this;
        if (this.selectedSMS.message != null && this.selectedSMS.message != '') {
            /* Denied */
            switch (this.selectedSMS.statusValue) {
                case 'Open': {
                    this.showErrorMessage(this.messageService.toastTypes.warning, '', 'Your sms template is pending approval, kindly contact support');
                    this.cd.markForCheck();
                    break;
                }
                case 'Rejected': {
                    this.showErrorMessage(this.messageService.toastTypes.error, '', 'Your sms template has been rejected, kindly contact support');
                    this.cd.markForCheck();
                    break;
                }
                case 'Approved': {
                    /* Send Multi SMS */
                    if (this.flagJSON.isMultiSms) {
                        var messageId = [];
                        messageId.push((this.selectedSMS.message_id).toString());
                        this.varJson.sendSmsFormData.baseIds = this.selectedRowGroup;
                        this.varJson.sendSmsFormData.messageArray = messageId;
                        this.cd.markForCheck();
                        this.flagJSON.isRippleLoad = true;
                        this.postdata.sendSmsToEnquirer(this.varJson.sendSmsFormData).subscribe(function (res) {
                            _this.flagJSON.isRippleLoad = false;
                            _this.showErrorMessage(_this.messageService.toastTypes.success, '', "SMS send successfully");
                            _this.cd.markForCheck();
                        }, function (err) {
                            _this.flagJSON.isRippleLoad = false;
                            _this.showErrorMessage(_this.messageService.toastTypes.error, '', "SMS notification cannot be sent due to any of following reasons: SMS setting is not enabled for institute. SMS Quota is insufficient for institute. No Users(Contacts) found for notify");
                            _this.cd.markForCheck();
                        });
                    }
                    else {
                        var userId = [];
                        userId.push((this.selectedRow.institute_enquiry_id).toString());
                        var messageId = [];
                        messageId.push((this.selectedSMS.message_id).toString());
                        this.varJson.sendSmsFormData.baseIds = userId;
                        this.varJson.sendSmsFormData.messageArray = messageId;
                        this.postdata.sendSmsToEnquirer(this.varJson.sendSmsFormData).subscribe(function (res) {
                            _this.showErrorMessage(_this.messageService.toastTypes.success, '', "SMS send successfully");
                        }, function (err) {
                            _this.showErrorMessage(_this.messageService.toastTypes.error, '', "SMS notification cannot be sent due to any of following reasons: SMS setting is not enabled for institute. SMS Quota is insufficient for institute. No Users(Contacts) found for notify");
                        });
                    }
                    break;
                }
                default:
                    this.showErrorMessage(this.messageService.toastTypes.error, this.messageService.object.SMSMessages.blankSMS, 'Please select an approved SMS Template to be sent');
            }
        }
    };
    /* Trigger Bulk Send SMS PopUp */
    EnquiryHomeComponent.prototype.sendBulkSms = function () {
        if ((!this._commService.valueCheck(this.selectedRowGroup)) && (this.selectedRowGroup.length != 0)) {
            this.flagJSON.isMultiSms = true;
            this.smsServicesInvoked();
            this.smsSelectedRowsLength = this.selectedRowGroup.length;
            this.cd.markForCheck();
        }
        else {
            this.showErrorMessage(this.messageService.toastTypes.warning, this.messageService.object.enquiryMessages.sendBulkSMS, '');
        }
    };
    /* Close Bulk Enquiry Popup and clear the field records and state */
    EnquiryHomeComponent.prototype.closeBulkSms = function () {
        this.emailSubject = '';
        this.flagJSON.isMultiSms = false;
        this.flagJSON.isMessageAddOpen = false;
        this.flagJSON.smsBtnToggle = false;
        this.flagJSON.isAllSelected = false;
        this.selectedSMS = { message: "", message_id: "", sms_type: "", status: "", statusValue: "", date: "", feature_type: "", institute_name: "", };
        this.newSmsString.data = "";
        this.smsSelectedRows = null;
        this.varJson.sendSmsFormData = { baseIds: [], messageArray: [] };
        this.cd.markForCheck();
    };
    /* Peform Delete Operation if access is OK */
    EnquiryHomeComponent.prototype.bulkDeleteEnquiries = function () {
        var _this = this;
        this.cd.markForCheck();
        /* If Admin */
        if (sessionStorage.getItem('permissions') == null || sessionStorage.getItem('permissions') == '') {
            /* Multi rows selected */
            if (this.selectedRowGroup.length != 0) {
                if (confirm('You are about to delete multiple enquiries')) {
                    /* Check if user has selected any enquiry with status 11 or 12 */
                    if (this.validateDeletable()) {
                        var deleteString_1 = '';
                        this.selectedRowGroup.forEach(function (el) { deleteString_1 = deleteString_1 + ',' + el; });
                        var data = { enquiryIdList: deleteString_1.slice(1), institution_id: sessionStorage.getItem('institute_id') };
                        this.flagJSON.isRippleLoad = true;
                        this.postdata.deleteEnquiryBulk(data).subscribe(function (res) {
                            _this.flagJSON.isRippleLoad = false;
                            _this.showErrorMessage(_this.messageService.toastTypes.success, _this.messageService.object.enquiryMessages.delete, 'Your delete request has been processed');
                            _this.selectedRowGroup = [];
                            _this.statusFilter({ value: 'In_Progress', prop: 'In_Progress', checked: true, disabled: false });
                            _this.statusFilter({ value: 'Open', prop: 'Open', checked: true, disabled: false });
                        }, function (err) {
                            _this.flagJSON.isRippleLoad = false;
                            _this.showErrorMessage(_this.messageService.toastTypes.error, _this.messageService.object.enquiryMessages.failDelete, err.error.message);
                        });
                        this.flagJSON.isRippleLoad = false;
                    }
                    else {
                        this.showErrorMessage(this.messageService.toastTypes.error, this.messageService.object.enquiryMessages.unableDelete, 'Only open and InProgress enquiries can be deleted');
                    }
                }
            }
            else {
                this.showErrorMessage(this.messageService.toastTypes.warning, this.messageService.object.enquiryMessages.bulkAction, '');
            }
        }
        else {
            /* If User is Authorized to assign Enquiries */
            if (JSON.parse(sessionStorage.getItem('permissions')).includes('115')) {
                /* Multi rows selected */
                if (this.selectedRowGroup.length != 0) {
                    if (confirm('You are about to delete multiple enquiries')) {
                        if (this.validateDeletable()) {
                            var deleteString_2 = '';
                            this.selectedRowGroup.forEach(function (el) { deleteString_2 = deleteString_2 + ',' + el; });
                            var data = { enquiryIdList: deleteString_2.slice(1), institution_id: sessionStorage.getItem('institute_id') };
                            this.postdata.deleteEnquiryBulk(data).subscribe(function (res) {
                                _this.showErrorMessage(_this.messageService.toastTypes.success, _this.messageService.object.enquiryMessages.delete, 'Your delete request has been processed');
                                _this.selectedRowGroup = [];
                                _this.statusFilter({ value: 'All', prop: 'All', checked: true, disabled: false });
                            }, function (err) {
                                _this.showErrorMessage(_this.messageService.toastTypes.error, _this.messageService.object.enquiryMessages.failDelete, err.message);
                            });
                        }
                        else {
                            this.showErrorMessage(this.messageService.toastTypes.error, this.messageService.object.enquiryMessages.unableDelete, 'Only open and InProgress enquiries can be deleted');
                        }
                    }
                }
                else {
                    this.showErrorMessage(this.messageService.toastTypes.warning, this.messageService.object.enquiryMessages.selectToDelete, '');
                }
            }
            else {
                this.showErrorMessage(this.messageService.toastTypes.error, this.messageService.object.enquiryMessages.deleteEnquiry, '');
            }
        }
    };
    /* Check if enquiry is deletable  */
    EnquiryHomeComponent.prototype.validateDeletable = function () {
        var _this = this;
        var temp = [];
        this.selectedRowGroup.forEach(function (s) {
            _this.sourceEnquiry.forEach(function (el) {
                if (el.institute_enquiry_id == s) {
                    temp.push(el);
                }
            });
        });
        var passed = temp.every(isOpenEnquiry);
        function isOpenEnquiry(element, index, array) {
            return (element.status == 0 || element.status == 3);
        }
        return passed;
    };
    /* Bulk Assign popup open */
    EnquiryHomeComponent.prototype.bulkAssignEnquiriesOpen = function () {
        this.cd.markForCheck();
        /* If Admin */
        if (sessionStorage.getItem('permissions') == null || sessionStorage.getItem('permissions') == '') {
            /* Multi rows selected */
            if (this.selectedRowGroup.length != 0) {
                this.flagJSON.isAssignEnquiry = true;
            }
            else {
                this.showErrorMessage(this.messageService.toastTypes.warning, this.messageService.object.enquiryMessages.bulkAction, '');
            }
        }
        else {
            /* If User is Authorized to assign Enquiries */
            if (JSON.parse(sessionStorage.getItem('permissions')).includes('115')) {
                /* Multi rows selected */
                if (this.selectedRowGroup.length != 0) {
                    this.flagJSON.isAssignEnquiry = true;
                }
                else {
                    this.showErrorMessage(this.messageService.toastTypes.warning, this.messageService.object.enquiryMessages.bulkAction, '');
                }
            }
            else {
                this.showErrorMessage(this.messageService.toastTypes.error, this.messageService.object.enquiryMessages.adminEnquiry, '');
            }
        }
    };
    /* Bulk Assign popup close */
    EnquiryHomeComponent.prototype.bulkAssignEnquiriesClose = function () {
        this.flagJSON.isAssignEnquiry = false;
        this.assignMultipleForm = { enqLi: [], assigned_to: "", source_instituteId: '' };
        this.cd.markForCheck();
    };
    /* Bulk Assign popup operation */
    EnquiryHomeComponent.prototype.bulkAssignEnquiries = function () {
        var _this = this;
        this.cd.markForCheck();
        var assigneeArr = [];
        this.flagJSON.isRippleLoad = true;
        this.assignMultipleForm.enqLi = this.selectedRowGroup;
        this.postdata.setEnquiryAssignee(this.assignMultipleForm).subscribe(function (res) {
            _this.flagJSON.isRippleLoad = false;
            _this.showErrorMessage(_this.messageService.toastTypes.success, _this.messageService.object.enquiryMessages.assignEnquiry, '');
            _this.loadTableDatatoSource(_this.instituteData);
            _this.bulkAssignEnquiriesClose();
            _this.cd.markForCheck();
        }, function (err) {
            _this.flagJSON.isRippleLoad = false;
            _this.showErrorMessage(_this.messageService.toastTypes.error, _this.messageService.object.enquiryMessages.failEnquiry, '');
        });
    };
    /* Convert assignee Id to name */
    EnquiryHomeComponent.prototype.getAssigneeName = function (id) {
        var name = '';
        this.enqAssignTo.forEach(function (el) { if (el.userid == id) {
            name = el.name;
        } });
        return name;
    };
    /* Function to perform advanced filter and update table data */
    EnquiryHomeComponent.prototype.filterAdvanced = function () {
        var _this = this;
        this.varJson.isFilterApplied = true;
        this.varJson.fetchingDataMessage = 1;
        this.statusString = [];
        this.statFilter = [{ value: 'All', prop: 'All', checked: true, disabled: false }, { value: 'Pending Followup', prop: 'Pending', checked: false, disabled: false }, { value: 'Open', prop: 'Open', checked: false, disabled: false }, { value: 'In_Progress', prop: 'In_Progress', checked: false, disabled: false }, { value: 'Registered', prop: 'Registered', checked: false, disabled: false }, { value: 'Student_Admitted', prop: 'Student_Admitted', checked: false, disabled: false }, { value: 'Inactive', prop: 'Inactive', checked: false, disabled: false }, { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }];
        this.flagJSON.isAllSelected = false;
        this.varJson.PageIndex = 1;
        // this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", priority: "", status: -1, filtered_statuses: "", follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null, sorted_by: "", order_by: "", commentShow: 'false' };
        // this.instituteData.filtered_statuses = this.statusString.join(',');
        var tempCustomArr = [];
        this.customComponents.forEach(function (el) {
            if (el.is_searchable == 'Y' && el.value != "") {
                if (el.type == '5') {
                    var obj = { component_id: el.id, enq_custom_id: "0", enq_custom_value: _this.getDateFormated(el.value, "YYYY-MM-DD") };
                    tempCustomArr.push(obj);
                }
                else if (el.type != '5') {
                    var obj = { component_id: el.id, enq_custom_id: "0", enq_custom_value: el.value };
                    tempCustomArr.push(obj);
                }
            }
        });
        if (tempCustomArr.length != 0) {
            this.advancedFilterForm.enqCustomLi = tempCustomArr;
        }
        else if (tempCustomArr.length == 0) {
            this.advancedFilterForm.enqCustomLi = null;
        }
        this.sourceEnquiry = [];
        this.selectedRowGroup = [];
        this.selectedRow = null;
        this.closeEnquiryFullDetails();
        this.flagJSON.isSideBar = false;
        //Update Date To And From Filter
        if (this.advancedFilterForm.updateDateFrom != "" && this.advancedFilterForm.updateDateFrom != null && this.advancedFilterForm.updateDateTo != "" && this.advancedFilterForm.updateDateTo != null) {
            if (__WEBPACK_IMPORTED_MODULE_7_moment__(this.advancedFilterForm.updateDateFrom) <= __WEBPACK_IMPORTED_MODULE_7_moment__(this.advancedFilterForm.updateDateTo)) {
                this.advancedFilterForm.updateDateFrom = this.getDateFormated(this.advancedFilterForm.updateDateFrom, 'YYYY-MM-DD');
                this.advancedFilterForm.updateDateTo = this.getDateFormated(this.advancedFilterForm.updateDateTo, 'YYYY-MM-DD');
            }
            else {
                this.showErrorMessage(this.messageService.toastTypes.error, '', 'Please enter valid Enquiry Changes From and To Dates');
                return;
            }
        }
        else if (this.advancedFilterForm.updateDateFrom != "" && this.advancedFilterForm.updateDateFrom != null) {
            if (this.advancedFilterForm.updateDateTo == "" || this.advancedFilterForm.updateDateTo == null) {
                this.showErrorMessage(this.messageService.toastTypes.error, '', 'Please enter valid Enquiry Changes To Dates');
                return;
            }
        }
        else if (this.advancedFilterForm.updateDateTo != "" && this.advancedFilterForm.updateDateTo != null) {
            if (this.advancedFilterForm.updateDateFrom == "" || this.advancedFilterForm.updateDateFrom == null) {
                this.showErrorMessage(this.messageService.toastTypes.error, '', 'Please enter valid Enquiry Changes From Dates');
                return;
            }
        }
        else {
            this.advancedFilterForm.updateDateFrom = "";
            this.advancedFilterForm.updateDateTo = "";
        }
        if (this.advancedFilterForm.followUpDate != null &&
            this.advancedFilterForm.followUpDate != ''
            && this.advancedFilterForm.followUpDate != 'Invalid date') {
            this.advancedFilterForm.is_recent = "Y";
        }
        else {
            this.advancedFilterForm.is_recent = "N";
        }
        this.instituteData = this.advancedFilterForm;
        this.flagJSON.isRippleLoad = true;
        this.enquire.getAllEnquiry(this.advancedFilterForm).subscribe(function (data) {
            _this.flagJSON.isRippleLoad = false;
            _this.sourceEnquiry = data;
            if (_this.sourceEnquiry.length != 0) {
                _this.varJson.totalEnquiry = data[0].totalcount;
                _this.cd.markForCheck();
                _this.closeAdFilter();
            }
            else {
                _this.varJson.fetchingDataMessage = 2;
                // this.showErrorMessage(this.messageService.toastTypes.error, '', 'We did not find any enquiry for the specified query');
                _this.varJson.totalEnquiry = 0;
                _this.cd.markForCheck();
                _this.closeAdFilter();
            }
        }, function (err) {
            _this.flagJSON.isRippleLoad = false;
        });
    };
    /* Function to clear the advance filter Manually */
    EnquiryHomeComponent.prototype.clearFilterAdvanced = function () {
        this.varJson.isFilterApplied = false;
        this.advancedFilterForm = {
            name: "", phone: "", email: "",
            enquiry_no: "", priority: "", status: -1, filtered_statuses: "",
            follow_type: "", followUpDate: this.getDateFormated(null, 'YYYY-MM-DD'),
            enquiry_date: "",
            assigned_to: -1, standard_id: -1, subjectIdArray: null,
            master_course_name: '', courseIdArray: null,
            subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "",
            isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "",
            updateDateFrom: "", updateDateTo: "", start_index: 0,
            batch_size: this.varJson.displayBatchSize, closedReason: "",
            enqCustomLi: null, commentShow: 'false'
        };
        this.customComponents.forEach(function (el) { el.selectedString = ''; el.selected = []; el.value = ''; });
        this.varJson.PageIndex = 1;
        this.enqSubject = [];
        this.course_course = [];
        this.cd.markForCheck();
    };
    EnquiryHomeComponent.prototype.closeUpdatePop = function (e) {
        this.pops.changeMessage('');
        this.timeJson = { hour: '', minute: '', meridian: '' };
        this.updateFormData = { comment: "", status: "", institution_id: sessionStorage.getItem('institute_id'), isEnquiryUpdate: "Y", closedReason: null, slot_id: null, priority: "", follow_type: "", followUpDate: "", commentDate: this.getDateFormated(null, 'YYYY-MM-DD'), followUpTime: "", isEnquiryV2Update: "N", isRegisterFeeUpdate: "N", amount: null, paymentMode: null, paymentDate: null, reference: null, walkin_followUpDate: '', walkin_followUpTime: { hour: '', minute: '', }, is_follow_up_time_notification: 0, };
        this.loadTableDatatoSource(this.instituteData);
    };
    /* common function to close popups */
    EnquiryHomeComponent.prototype.closePopup = function () {
        this.pops.changeMessage('');
        this.timeJson = { hour: '', minute: '', meridian: '' };
        this.flagJSON.isApprovedTab = true;
        this.flagJSON.isOpenTab = false;
        this.flagJSON.isMessageAddOpen = false;
        this.flagJSON.smsBtnToggle = false;
        this.newSmsString.data = "";
        this.smsSelectedRows = null;
        this.selectedSMS = { message: "", message_id: "", sms_type: "", status: "", statusValue: "", date: "", feature_type: "", institute_name: "", };
        this.varJson.sendSmsFormData = { baseIds: [], messageArray: [] };
        this.registrationForm = { institute_enquiry_id: "", amount: "", paymentDate: this.getDateFormated(null, 'YYYY-MM-DD'), paymentMode: "", reference: "", };
        this.updateFormData = { comment: "", status: "", institution_id: sessionStorage.getItem('institute_id'), isEnquiryUpdate: "Y", closedReason: null, slot_id: null, priority: "", follow_type: "", followUpDate: "", commentDate: this.getDateFormated(null, 'YYYY-MM-DD'), followUpTime: "", isEnquiryV2Update: "N", isRegisterFeeUpdate: "N", amount: null, paymentMode: null, paymentDate: null, reference: null, walkin_followUpDate: '', walkin_followUpTime: { hour: '', minute: '', }, is_follow_up_time_notification: 0, };
        this.flagJSON.summaryOptions = false;
        this.varJson.summaryReport = { from_date: "", to_date: "", };
        this.flagJSON.showDateRange = false;
        this.cd.markForCheck();
    };
    /* fetch subject when user selects any standard on select menu */
    EnquiryHomeComponent.prototype.fetchEnquirySubject = function () {
        var _this = this;
        this.flagJSON.isRippleLoad = true;
        if (this.advancedFilterForm.standard_id != null || this.advancedFilterForm.standard_id != '-1') {
            this.advancedFilterForm.subjectIdArray = null;
            this.enqSubject = [];
            this.prefill.getEnqSubjects(this.advancedFilterForm.standard_id).subscribe(function (data) { _this.flagJSON.isRippleLoad = false; _this.enqSubject = data; _this.cd.markForCheck(); }, function (err) { _this.flagJSON.isRippleLoad = false; });
        }
        else {
            this.flagJSON.isRippleLoad = false;
            this.advancedFilterForm.subject_id = '-1';
            this.enqSubject = [];
        }
    };
    EnquiryHomeComponent.prototype.courseMasterChange = function (e) {
        var _this = this;
        if (e != '-1') {
            this.masterCourseData.map(function (el) {
                if (el.master_course == e) {
                    if (el.coursesList == null || el.coursesList.length == 0) {
                        _this.course_course = [];
                    }
                    else {
                        _this.course_course = el.coursesList;
                    }
                }
            });
        }
        else {
            this.course_course = [];
        }
    };
    /*** pagination functions */
    /* Fetch next set of data from server and update table */
    EnquiryHomeComponent.prototype.fetchNext = function () {
        this.varJson.PageIndex++;
        this.fectchTableDataByPage(this.varJson.PageIndex);
    };
    /* Fetch previous set of data from server and update table */
    EnquiryHomeComponent.prototype.fetchPrevious = function () {
        this.varJson.PageIndex--;
        this.fectchTableDataByPage(this.varJson.PageIndex);
    };
    /* Fetch table data by page index */
    EnquiryHomeComponent.prototype.fectchTableDataByPage = function (index) {
        this.varJson.PageIndex = index;
        var startindex = this.varJson.displayBatchSize * (index - 1);
        if (this.varJson.isFilterApplied) {
            this.advancedFilterForm.start_index = startindex;
            this.advancedFilterForm.sorted_by = sessionStorage.getItem('sorted_by') != null ? sessionStorage.getItem('sorted_by') : '';
            this.advancedFilterForm.order_by = sessionStorage.getItem('order_by') != null ? sessionStorage.getItem('order_by') : '';
            this.loadTableDatatoSource(this.advancedFilterForm);
        }
        else {
            this.instituteData.start_index = startindex;
            this.instituteData.sorted_by = sessionStorage.getItem('sorted_by') != null ? sessionStorage.getItem('sorted_by') : '';
            this.instituteData.order_by = sessionStorage.getItem('order_by') != null ? sessionStorage.getItem('order_by') : '';
            this.instituteData.filtered_statuses = this.statusString.join(',');
            this.loadTableDatatoSource(this.instituteData);
        }
    };
    /* Fetches Data as per the user selected batch size */
    EnquiryHomeComponent.prototype.updateTableBatchSize = function (num) {
        this.varJson.PageIndex = 1;
        this.varJson.displayBatchSize = parseInt(num);
        this.instituteData.batch_size = this.varJson.displayBatchSize;
        this.instituteData.start_index = 0;
        this.statusString = [];
        this.statFilter = [{ value: 'All', prop: 'All', checked: true, disabled: false }, { value: 'Pending Followup', prop: 'Pending', checked: false, disabled: false }, { value: 'Open', prop: 'Open', checked: false, disabled: false }, { value: 'In_Progress', prop: 'In_Progress', checked: false, disabled: false }, { value: 'Registered', prop: 'Registered', checked: false, disabled: false }, { value: 'Student_Admitted', prop: 'Student_Admitted', checked: false, disabled: false }, { value: 'Inactive', prop: 'Inactive', checked: false, disabled: false }, { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }];
        this.instituteData.filtered_statuses = this.statusString.join(',');
        this.loadTableDatatoSource(this.instituteData);
    };
    /* Function to store the data of Custom Component in to Base64 encoded array string */
    EnquiryHomeComponent.prototype.customComponentUpdated = function (val, data) {
        this.componentListObject[data.component_id].enq_custom_value = val;
    };
    /* Fetch all the enquiries as xls file */
    EnquiryHomeComponent.prototype.downloadAllEnquiries = function () {
        var _this = this;
        this.cd.markForCheck();
        this.flagJSON.isRippleLoad = true;
        var courseArray = [];
        if (this.advancedFilterForm.courseIdArray == null) {
            courseArray = [""];
        }
        else {
            courseArray = this.advancedFilterForm.courseIdArray;
        }
        var subjectArray = [];
        if (this.advancedFilterForm.subjectIdArray == null) {
            subjectArray = [""];
        }
        else {
            subjectArray = this.advancedFilterForm.subjectIdArray;
        }
        var obj = {
            name: this.instituteData.name,
            phone: this.instituteData.phone,
            email: this.instituteData.email,
            enquiry_no: this.instituteData.enquiry_no,
            priority: this.advancedFilterForm.priority,
            status: this.advancedFilterForm.status,
            filtered_statuses: this.advancedFilterForm.filtered_statuses,
            follow_type: this.advancedFilterForm.follow_type,
            followUpDate: this.advancedFilterForm.followUpDate == '' ? "" : __WEBPACK_IMPORTED_MODULE_7_moment__(this.advancedFilterForm.followUpDate).format('YYYY-MM-DD'),
            enquiry_date: this.advancedFilterForm.enquiry_date,
            assigned_to: this.advancedFilterForm.assigned_to,
            standard_id: this.advancedFilterForm.standard_id,
            subjectIdArray: subjectArray,
            master_course_name: this.advancedFilterForm.master_course_name,
            courseIdArray: courseArray,
            subject_id: this.advancedFilterForm.subject_id,
            is_recent: this.advancedFilterForm.is_recent,
            slot_id: this.advancedFilterForm.slot_id,
            filtered_slots: this.advancedFilterForm.filtered_slots,
            isDashbord: this.instituteData.isDashbord,
            enquireDateFrom: this.advancedFilterForm.enquireDateFrom == "" ? "" : __WEBPACK_IMPORTED_MODULE_7_moment__(this.advancedFilterForm.enquireDateFrom).format('YYYY-MM-DD'),
            // this.getDateFormated(this.advancedFilterForm.enquireDateFrom, "YYYY-MM-DD"),
            enquireDateTo: this.advancedFilterForm.enquireDateTo == "" ? "" : __WEBPACK_IMPORTED_MODULE_7_moment__(this.advancedFilterForm.enquireDateTo).format('YYYY-MM-DD'),
            // moment(this.advancedFilterForm.enquireDateTo, "YYYY-MM-DD"),
            updateDate: this.advancedFilterForm.updateDate == "" ? "" : __WEBPACK_IMPORTED_MODULE_7_moment__(this.advancedFilterForm.updateDate).format('YYYY-MM-DD'),
            // this.getDateFormated(this.advancedFilterForm.updateDate, "YYYY-MM-DD"),
            updateDateFrom: this.advancedFilterForm.updateDateFrom == "" ? "" : __WEBPACK_IMPORTED_MODULE_7_moment__(this.advancedFilterForm.updateDateFrom).format('YYYY-MM-DD'),
            // this.getDateFormated(this.advancedFilterForm.updateDateFrom, "YYYY-MM-DD"),
            updateDateTo: this.advancedFilterForm.updateDateTo == "" ? "" : __WEBPACK_IMPORTED_MODULE_7_moment__(this.advancedFilterForm.updateDateTo).format('YYYY-MM-DD'),
            // this.getDateFormated(this.advancedFilterForm.updateDateTo, "YYYY-MM-DD"),
            start_index: 0,
            batch_size: this.varJson.displayBatchSize,
            closedReason: "",
            enqCustomLi: this.advancedFilterForm.enqCustomLi,
            sorted_by: "",
            order_by: "",
            commentShow: 'false',
            source_id: this.advancedFilterForm.source_id,
            school_id: this.advancedFilterForm.school_id,
            list_id: this.advancedFilterForm.list_id
        };
        this.enquire.fetchAllEnquiryAsXls(obj).subscribe(function (res) {
            _this.flagJSON.isRippleLoad = false;
            var byteArr = _this._commService.convertBase64ToArray(res.document);
            var fileName = res.docTitle;
            var file = new Blob([byteArr], { type: 'application/vnd.ms-excel' });
            var url = URL.createObjectURL(file);
            var dwldLink = __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('enq_download');
            _this.cd.markForCheck();
            dwldLink.setAttribute("href", url);
            dwldLink.setAttribute("download", fileName);
            __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].body.appendChild(dwldLink);
            _this.cd.markForCheck();
            dwldLink.click();
            _this.cd.markForCheck();
        }, function (err) {
            _this.flagJSON.isRippleLoad = false;
        });
    };
    ///// Download Summary Report
    EnquiryHomeComponent.prototype.toggleDateSection = function () {
        if (this.flagJSON.showDateRange == false) {
            this.flagJSON.showDateRange = true;
            __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('anchTagToggle').text = "Hide";
        }
        else {
            this.flagJSON.showDateRange = false;
            __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('anchTagToggle').text = "Download By Date Range";
        }
    };
    EnquiryHomeComponent.prototype.downloadSummaryReport = function () {
        this.flagJSON.summaryOptions = true;
        setTimeout(function () {
            __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('anchTagToggle').text = "Download By Date Range";
        }, 100);
    };
    EnquiryHomeComponent.prototype.downloadSummaryReportXl = function () {
        var _this = this;
        switch (Number(this.varJson.downloadReportOption)) {
            case 1:
                this.showErrorMessage(this.messageService.toastTypes.error, 'Selection', 'Please select other options');
                break;
            case 2:
                {
                    this.flagJSON.isRippleLoad = true;
                    this.enquire.getSummaryReportOfThisMonth().subscribe(function (res) {
                        _this.flagJSON.isRippleLoad = false;
                        _this.performDownloadAction(res);
                    }, function (err) {
                        _this.flagJSON.isRippleLoad = false;
                    });
                }
                break;
            case 3:
                {
                    this.flagJSON.isRippleLoad = true;
                    this.enquire.getPreviousMSummary().subscribe(function (res) {
                        _this.flagJSON.isRippleLoad = false;
                        _this.performDownloadAction(res);
                    }, function (err) { _this.flagJSON.isRippleLoad = false; });
                }
                break;
            case 4: {
                this.flagJSON.isRippleLoad = true;
                this.enquire.getSummaryReportOfLastTwoMonth().subscribe(function (res) {
                    _this.flagJSON.isRippleLoad = false;
                    _this.performDownloadAction(res);
                }, function (err) { _this.flagJSON.isRippleLoad = false; });
            }
        }
    };
    EnquiryHomeComponent.prototype.downloadSummaryReportXlDateWise = function () {
        var _this = this;
        if (this.varJson.summaryReport.to_date != "" && this.varJson.summaryReport.from_date != "") {
            this.flagJSON.isRippleLoad = true;
            var obj = { to_date: this.getDateFormated(this.varJson.summaryReport.to_date, 'YYYY-MM-DD'), from_date: this.getDateFormated(this.varJson.summaryReport.from_date, 'YYYY-MM-DD') };
            this.enquire.getSummaryReportFromDates(obj).subscribe(function (res) { _this.flagJSON.isRippleLoad = false; _this.performDownloadAction(res); }, function (err) { _this.flagJSON.isRippleLoad = false; });
        }
        else {
            this.showErrorMessage(this.messageService.toastTypes.error, '', 'Please enter dates');
        }
    };
    EnquiryHomeComponent.prototype.performDownloadAction = function (res) {
        var byteArr = this._commService.convertBase64ToArray(res.document);
        var format = res.format;
        var fileName = res.docTitle;
        var file = new Blob([byteArr], { type: 'text/csv;charset=utf-8;' });
        var url = URL.createObjectURL(file);
        var dwldLink = __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('downloadSummaryReport121');
        dwldLink.setAttribute("href", url);
        dwldLink.setAttribute("download", fileName);
        __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].body.appendChild(dwldLink);
        dwldLink.click();
    };
    /* Convert enquiry to student */
    EnquiryHomeComponent.prototype.convertRow = function (ev) {
        var _this = this;
        var institute_id = sessionStorage.getItem("institute_id");
        if (this.flagJSON.isProfessional) {
            this.selectedRow.standard_id = this.selectedRow.master_course_name;
        }
        console.log(ev, this.selectedRow);
        return this.enquire.fetchEnquiryStudentData(institute_id, this.selectedRow.institute_enquiry_id).subscribe(function (data) {
            _this.flagJSON.isRippleLoad = false;
            _this.selectedRow.standard_id = data.standard_id;
            _this.selectedRow.address = data.curr_address;
            _this.selectedRow.curr_address = data.curr_address;
            _this.selectedRow.country_id = data.country_id;
            _this.selectedRow.phone = data.phone;
            sessionStorage.setItem('studentPrefill', JSON.stringify(_this.selectedRow));
            _this.router.navigate(['/view/students/add']);
            _this.closePopup();
            _this.cd.markForCheck();
        }, function (err) {
            _this.flagJSON.isRippleLoad = false;
            _this.showErrorMessage(_this.messageService.toastTypes.error, 'Unable To Connect To Server', 'Please check your internet connection or contact proctur support if the issue persist');
            _this.cd.markForCheck();
        });
    };
    /* Download Receipt API */
    EnquiryHomeComponent.prototype.downloadReceiptPdf = function () {
        var _this = this;
        this.flagJSON.isRippleLoad = true;
        this.enquire.fetchReceiptPdf(this.selectedRow.invoice_no).subscribe(function (res) {
            _this.flagJSON.isRippleLoad = false;
            _this.cd.markForCheck();
            var byteArr = _this._commService.convertBase64ToArray(res.document);
            var format = res.format;
            var fileName = res.docTitle;
            var file = new Blob([byteArr], { type: 'application/pdf' });
            var url = URL.createObjectURL(file);
            var dwldLink = __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('reg-pdf-link');
            if (dwldLink.getAttribute('href') == "" || dwldLink.getAttribute('href') == null) {
                dwldLink.setAttribute("href", url);
                dwldLink.setAttribute("download", fileName);
                dwldLink.click();
                _this.cd.markForCheck();
            }
        }, function (err) {
            _this.flagJSON.isRippleLoad = false;
        });
    };
    EnquiryHomeComponent.prototype.sortTableById = function (id) {
        this.varJson.sortBy = id;
        // console.log(this.varJson.sortBy);
        if (id == 'followUpDateTime') {
            id = 'followUpDate';
        }
        this.instituteData.sorted_by = id;
        //this.varJson.currentDirection = this.varJson.currentDirection == 'desc' ? 'asc' : 'desc';
        this.instituteData.order_by = this.varJson.currentDirection;
        this.instituteData.filtered_statuses = this.statusString.join(',');
        this.cd.markForCheck();
        this.loadTableDatatoSource(this.instituteData);
    };
    EnquiryHomeComponent.prototype.clearSearchDate = function () {
        this.varJson.searchBarDate = "";
        this.instituteData.followUpDate = "";
        this.instituteData.enquireDateFrom = "";
        this.instituteData.enquireDateTo = "";
    };
    EnquiryHomeComponent.prototype.clearFilterType = function (object) {
        this.advancedFilterForm[object] = "";
    };
    EnquiryHomeComponent.prototype.clearupdateDate = function () {
        this.updateFormData.followUpDate = "";
        this.timeJson.hour = '';
        this.timeJson.minute = '';
        this.timeJson.meridian = '';
    };
    EnquiryHomeComponent.prototype.updateSlotSelected = function (data) {
        /* slot checked */
        var selectedSlotsID;
        if (data.status) {
            this.slotIdArr.push(data.value.slot_id);
            this.selectedSlots.push(data.value.slot_name);
            if (this.selectedSlots.length != 0) {
                __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('slotwrapper').classList.add('has-value');
            }
            else {
                __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('slotwrapper').classList.remove('has-value');
            }
            selectedSlotsID = this.slotIdArr.join(',');
            this.varJson.selectedSlotsString = this.selectedSlots.join(',');
            this.advancedFilterForm.filtered_slots = selectedSlotsID;
        }
        else {
            if (this.selectedSlots.length < 0) {
                __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('slotwrapper').classList.add('has-value');
            }
            else if (this.selectedSlots.length == 0) {
                __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('slotwrapper').classList.remove('has-value');
            }
            else if (this.selectedSlots.length == 1) {
                __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('slotwrapper').classList.remove('has-value');
            }
            var index = this.selectedSlots.indexOf(data.value.slot_name);
            if (index > -1) {
                this.selectedSlots.splice(index, 1);
            }
            this.varJson.selectedSlotsString = this.selectedSlots.join(',');
            var index2 = this.slotIdArr.indexOf(data.value.slot_id);
            if (index2 > -1) {
                this.slotIdArr.splice(index, 1);
            }
            selectedSlotsID = this.slotIdArr.join(',');
            this.advancedFilterForm.filtered_slots = selectedSlotsID;
        }
    };
    EnquiryHomeComponent.prototype.getPriority = function (id) {
        var temp = "";
        this.enqPriority.forEach(function (el) {
            if (el.data_key === id) {
                temp = el.data_value;
            }
        });
        return temp;
    };
    EnquiryHomeComponent.prototype.getFollowUp = function (id) {
        var temp = "";
        this.enqFollowType.forEach(function (el) {
            if (el.data_key === id) {
                temp = el.data_value;
            }
        });
        return temp;
    };
    EnquiryHomeComponent.prototype.getFollowUpReverse = function (id) {
        var temp = "";
        this.enqFollowType.forEach(function (el) {
            if (el.data_value === id) {
                temp = el.data_key;
            }
        });
        return temp;
    };
    EnquiryHomeComponent.prototype.getPriorityReverse = function (id) {
        var temp = "";
        this.enqPriority.forEach(function (el) {
            if (el.data_value === id) {
                temp = el.data_key;
            }
        });
        //console.log(temp);
        return temp;
    };
    EnquiryHomeComponent.prototype.openEnquiryFullDetails = function (id) {
        var _this = this;
        this.closeAdFilter();
        var mySidenavWidth = '27%';
        if (window.innerWidth < 768)
            mySidenavWidth = '100%';
        this.mySidenav.nativeElement.style.width = mySidenavWidth;
        this.mySidenav.nativeElement.style.display = 'block';
        this.enqPage.nativeElement.style.width = "70%";
        this.enqPage.nativeElement.style.marginRight = mySidenavWidth;
        // this.optMenu.nativeElement.classList.add('shorted');
        this.flagJSON.isRippleLoad = true;
        this.cd.markForCheck();
        this.customCompid = [];
        this.prefill.fetchCustomComponentById(id).subscribe(function (res) {
            _this.flagJSON.isRippleLoad = false;
            _this.cd.markForCheck();
            if (res != null) {
                _this.customCompid = res;
            }
            _this.flagJSON.isSideBar = true;
        }, function (err) {
            _this.flagJSON.isRippleLoad = false;
        });
    };
    EnquiryHomeComponent.prototype.closeEnquiryFullDetails = function () {
        this.flagJSON.isRippleLoad = true;
        this.flagJSON.isSideBar = false;
        this.mySidenav.nativeElement.style.width = "0";
        this.mySidenav.nativeElement.style.display = 'none';
        this.enqPage.nativeElement.style.width = "100%";
        this.enqPage.nativeElement.style.marginRight = "0";
        // this.optMenu.nativeElement.classList.remove('shorted');
        this.flagJSON.isRippleLoad = false;
    };
    /*  Handler for row click event */
    EnquiryHomeComponent.prototype.userRowSelect = function (ev) {
        if (ev != null) {
            this.openEnquiryFullDetails(ev.institute_enquiry_id);
            this.cd.markForCheck();
            this.enquiryFullDetail = ev.institute_enquiry_id;
            this.selectedRow = ev;
            this.flagJSON.isConverted = this.selectedRow.status == 12 ? true : false;
            if ((this.selectedRow.status == 11) && (this.selectedRow.invoice_no != 0)) {
                this.flagJSON.hasReceipt = true;
                sessionStorage.setItem("institute_enquiry_id", this.selectedRow.institute_enquiry_id);
            }
            else {
                if (this.selectedRow.status == 0 || this.selectedRow.status == 3 || this.selectedRow.status == 2) {
                    this.flagJSON.notClosednAdmitted = true;
                    this.flagJSON.isadmitted = false;
                    this.flagJSON.isClosed = false;
                    this.flagJSON.hasReceipt = false;
                }
                else if (this.selectedRow.status == 11) {
                    this.flagJSON.notClosednAdmitted = false;
                    this.flagJSON.isadmitted = true;
                    this.flagJSON.isClosed = false;
                    this.flagJSON.hasReceipt = false;
                }
                else if (this.selectedRow.status == 1 || this.selectedRow.status == 12) {
                    this.flagJSON.notClosednAdmitted = false;
                    this.flagJSON.isadmitted = false;
                    this.flagJSON.isClosed = true;
                    this.flagJSON.hasReceipt = false;
                }
                sessionStorage.setItem("institute_enquiry_id", this.selectedRow.institute_enquiry_id);
            }
        }
        else {
            this.closeEnquiryFullDetails();
            this.flagJSON.isSideBar = false;
        }
    };
    EnquiryHomeComponent.prototype.virtualUpdateEnquiry = function (obj) {
        var _this = this;
        this.updateFormData = obj;
        this.cd.markForCheck();
        this.flagJSON.isRippleLoad = true;
        this.postdata.updateEnquiryForm(this.selectedRow.institute_enquiry_id, this.updateFormData)
            .subscribe(function (res) {
            _this.flagJSON.isRippleLoad = false;
            _this.cd.markForCheck();
            _this.showErrorMessage(_this.messageService.toastTypes.success, _this.messageService.object.enquiryMessages.update, 'Your enquiry has been successfully submitted');
            _this.closePopup();
            _this.loadTableDatatoSource(_this.instituteData);
        }, function (err) {
            _this.flagJSON.isRippleLoad = false;
            _this.showErrorMessage(_this.messageService.toastTypes.error, _this.messageService.object.enquiryMessages.failUpdate, 'There was an error processing your request');
        });
    };
    EnquiryHomeComponent.prototype.getRowCount = function (ev) {
        this.varJson.selectedRowCount = ev;
    };
    EnquiryHomeComponent.prototype.getSelectedEnquiries = function (ev) {
        this.cd.markForCheck();
        this.selectedRowGroup = ev;
    };
    EnquiryHomeComponent.prototype.getDirection = function (e) {
        if (e) {
            this.varJson.currentDirection = "asc";
        }
        else {
            this.varJson.currentDirection = "desc";
        }
    };
    EnquiryHomeComponent.prototype.roleManagementForBulkAdd = function () {
        var _this = this;
        this.bulkAddItems = [];
        var permissionArray = sessionStorage.getItem('permissions');
        if (permissionArray == "" || permissionArray == null) {
            this.giveFullPermisionOfBulfAction();
        }
        else {
            if (permissionArray != undefined) {
                if (permissionArray.indexOf('115') != -1) {
                    this.giveFullPermisionOfBulfAction();
                }
                else {
                    this.bulkAddItems = [{ label: 'Send SMS', icon: 'fa-envelope-o', command: function () { _this.sendBulkSms(); } }];
                }
            }
        }
    };
    EnquiryHomeComponent.prototype.giveFullPermisionOfBulfAction = function () {
        var _this = this;
        this.bulkAddItems = [
            { label: 'Send Notification', icon: 'fa-envelope-o', command: function () { _this.sendBulkSms(); } },
            { label: 'Delete Enquiries', icon: 'fa-trash-o', command: function () { _this.bulkDeleteEnquiries(); } },
            { label: 'Assign Enquiries', icon: 'fa-buysellads', command: function () { _this.bulkAssignEnquiriesOpen(); } }
        ];
    };
    // Multi Branch Check
    EnquiryHomeComponent.prototype.checkMultiBranchStatus = function () {
        var _this = this;
        var permissionArray = sessionStorage.getItem('permissions');
        if (permissionArray == "" || permissionArray == null) {
            this.auth.isMainBranch.subscribe(function (value) {
                _this.isMainBranch = value;
                if (_this.isMainBranch == "Y") {
                    _this.updateFormData.source_instituteId = _this.varJson.insttitueId;
                    _this.multiBranchInstituteFound(_this.varJson.insttitueId);
                    _this.branchUpdated(_this.updateFormData.source_instituteId);
                }
            });
            this.multiBranchService.subBranchSelected.subscribe(function (res) {
                _this.flagJSON.subBranchSelected = res;
                if (res == true) {
                    _this.updateFormData.source_instituteId = _this.varJson.insttitueId;
                    var mainBranchId = sessionStorage.getItem('mainBranchId');
                    if (mainBranchId != null) {
                        _this.multiBranchInstituteFound(mainBranchId);
                        _this.branchUpdated(_this.updateFormData.source_instituteId);
                    }
                }
            });
        }
        else {
            this.isMainBranch = "N";
            this.flagJSON.subBranchSelected = false;
        }
    };
    EnquiryHomeComponent.prototype.multiBranchInstituteFound = function (id) {
        var _this = this;
        this.prefill.getAllSubBranches(id).subscribe(function (res) { _this.branchesList = res; }, function (err) { console.log(err); });
    };
    EnquiryHomeComponent.prototype.branchUpdated = function (e) {
        var _this = this;
        this.enqAssignTo = [];
        this.prefill.fetchAssignedToData(e).subscribe(function (res) { _this.enqAssignTo = res; }, function (err) { console.log(err); });
    };
    EnquiryHomeComponent.prototype.updateStatFilterStatus = function (id, check) {
        this.statFilter.forEach(function (e) { if (e.prop == id) {
            e.checked = check;
        } });
    };
    /* Function to toggle table data on checkbox click */
    EnquiryHomeComponent.prototype.statusFilter = function (checkerObj) {
        this.clearFilterAdvanced();
        this.varJson.searchBarData = '';
        this.updateStatFilterStatus(checkerObj.prop, checkerObj.checked);
        if (checkerObj.prop == "All") {
            this.statusString = [];
            if (checkerObj.checked) {
                this.statFilter = [{ value: 'All', prop: 'All', checked: true, disabled: false }, { value: 'Pending Followup', prop: 'Pending', checked: false, disabled: false }, { value: 'Open', prop: 'Open', checked: false, disabled: false }, { value: 'In_Progress', prop: 'In_Progress', checked: false, disabled: false }, { value: 'Registered', prop: 'Registered', checked: false, disabled: false }, { value: 'Student_Admitted', prop: 'Student_Admitted', checked: false, disabled: false }, { value: 'Inactive', prop: 'Inactive', checked: false, disabled: false }, { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }];
                this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                this.advancedFilterForm = this.instituteData;
                this.loadTableDatatoSource(this.instituteData);
            }
        }
        else if (checkerObj.prop == "Pending") {
            if (checkerObj.checked) {
                this.statFilter = [{ value: 'All', prop: 'All', checked: false, disabled: false }, { value: 'Pending Followup', prop: 'Pending', checked: true, disabled: false }, { value: 'Open', prop: 'Open', checked: false, disabled: false }, { value: 'In_Progress', prop: 'In_Progress', checked: false, disabled: false }, { value: 'Registered', prop: 'Registered', checked: false, disabled: false }, { value: 'Student_Admitted', prop: 'Student_Admitted', checked: false, disabled: false }, { value: 'Inactive', prop: 'Inactive', checked: false, disabled: false }, { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }];
                this.advancedFilterForm.followUpDate = this.getDateFormated(new Date(), "YYYY-MM-DD");
                this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, follow_type: "", followUpDate: this.getDateFormated(new Date(), "YYYY-MM-DD"), enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                this.advancedFilterForm = this.instituteData;
                this.loadTableDatatoSource(this.instituteData);
            }
        }
        else if (checkerObj.prop == "Student_Admitted") {
            if (checkerObj.checked) {
                this.statusString.push('12');
                var stat = this.statusString.join(',');
                this.instituteData = { name: "", phone: "", email: "", commentShow: 'false', enquiry_no: "", priority: "", status: -1, filtered_statuses: stat, follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                this.advancedFilterForm = this.instituteData;
                this.loadTableDatatoSource(this.instituteData);
            }
            else {
                var index = this.statusString.indexOf('12');
                if (index !== -1) {
                    this.statusString.splice(index, 1);
                }
                if (this.statusString.length == 0) {
                    this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.advancedFilterForm = this.instituteData;
                    this.loadTableDatatoSource(this.instituteData);
                }
                else if (this.statusString.length != 0) {
                    var stat = this.statusString.join(',');
                    this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: stat, follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.advancedFilterForm = this.instituteData;
                    this.loadTableDatatoSource(this.instituteData);
                }
            }
        }
        else if (checkerObj.prop == "Inactive") {
            if (checkerObj.checked) {
                this.statusString.push('1');
                var stat = this.statusString.join(',');
                this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: stat, follow_type: "", followUpDate: this.varJson.searchBarDate, enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                this.advancedFilterForm = this.instituteData;
                this.loadTableDatatoSource(this.instituteData);
            }
            else {
                var index = this.statusString.indexOf('1');
                if (index !== -1) {
                    this.statusString.splice(index, 1);
                }
                if (this.statusString.length == 0) {
                    this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, follow_type: "", followUpDate: this.varJson.searchBarDate, enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.advancedFilterForm = this.instituteData;
                    this.loadTableDatatoSource(this.instituteData);
                }
                else if (this.statusString.length != 0) {
                    var stat = this.statusString.join(',');
                    this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: stat, follow_type: "", followUpDate: this.varJson.searchBarDate, enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.advancedFilterForm = this.instituteData;
                    this.loadTableDatatoSource(this.instituteData);
                }
            }
        }
        else if (checkerObj.prop == "Open") {
            if (checkerObj.checked) {
                this.statusString.push('0');
                var stat = this.statusString.join(',');
                this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: stat, follow_type: "", followUpDate: this.varJson.searchBarDate, enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                this.advancedFilterForm = this.instituteData;
                this.loadTableDatatoSource(this.instituteData);
            }
            else {
                var index = this.statusString.indexOf('0');
                if (index !== -1) {
                    this.statusString.splice(index, 1);
                }
                if (this.statusString.length == 0) {
                    this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, follow_type: "", followUpDate: this.varJson.searchBarDate, enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.advancedFilterForm = this.instituteData;
                    this.loadTableDatatoSource(this.instituteData);
                }
                else if (this.statusString.length != 0) {
                    var stat = this.statusString.join(',');
                    this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: stat, follow_type: "", followUpDate: this.varJson.searchBarDate, enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.advancedFilterForm = this.instituteData;
                    this.loadTableDatatoSource(this.instituteData);
                }
            }
        }
        else if (checkerObj.prop == "In_Progress") {
            if (checkerObj.checked) {
                this.statusString.push('3');
                var stat = this.statusString.join(',');
                this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: stat, follow_type: "", followUpDate: this.varJson.searchBarDate, enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                this.advancedFilterForm = this.instituteData;
                this.loadTableDatatoSource(this.instituteData);
            }
            else {
                var index2 = this.statusString.indexOf('3');
                if (index2 !== -1) {
                    this.statusString.splice(index2, 1);
                }
                if (this.statusString.length == 0) {
                    this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, follow_type: "", followUpDate: this.varJson.searchBarDate, enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.advancedFilterForm = this.instituteData;
                    this.loadTableDatatoSource(this.instituteData);
                }
                else if (this.statusString.length != 0) {
                    var stat = this.statusString.join(',');
                    this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: stat, follow_type: "", followUpDate: this.varJson.searchBarDate, enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.advancedFilterForm = this.instituteData;
                    this.loadTableDatatoSource(this.instituteData);
                }
            }
        }
        else if (checkerObj.prop == "Registered") {
            if (checkerObj.checked) {
                this.statusString.push('11');
                var stat = this.statusString.join(',');
                this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: stat, follow_type: "", followUpDate: this.varJson.searchBarDate, enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                this.advancedFilterForm = this.instituteData;
                this.loadTableDatatoSource(this.instituteData);
            }
            else {
                var index = this.statusString.indexOf('11');
                if (index !== -1) {
                    this.statusString.splice(index, 1);
                }
                if (this.statusString.length == 0) {
                    this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, follow_type: "", followUpDate: this.varJson.searchBarDate, enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.advancedFilterForm = this.instituteData;
                    this.loadTableDatatoSource(this.instituteData);
                }
                else if (this.statusString.length != 0) {
                    var stat = this.statusString.join(',');
                    this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: stat, follow_type: "", followUpDate: this.varJson.searchBarDate, enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                    this.advancedFilterForm = this.instituteData;
                    this.loadTableDatatoSource(this.instituteData);
                }
            }
        }
        else if (checkerObj.prop == "Walkin") {
            if (checkerObj.checked) {
                this.statusString = [];
                var stat = this.statusString.join(',');
                this.advancedFilterForm.followUpDate = this.getDateFormated(new Date(), "YYYY-MM-DD");
                this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, follow_type: "Walkin", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_statuses: stat, filtered_slots: "", isDashbord: "N", enquireDateFrom: "", enquireDateTo: "", updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                this.advancedFilterForm = this.instituteData;
                this.loadTableDatatoSource(this.instituteData);
            }
        }
    };
    EnquiryHomeComponent.prototype.checkIfRoutedFromEnquiry = function () {
        this.statFilter = [
            { value: 'All', prop: 'All', checked: false, disabled: false },
            { value: 'Pending Followup', prop: 'Pending', checked: true, disabled: false },
            { value: 'Open', prop: 'Open', checked: false, disabled: false },
            { value: 'In_Progress', prop: 'In_Progress', checked: false, disabled: false },
            { value: 'Registered', prop: 'Registered', checked: false, disabled: false },
            { value: 'Student_Admitted', prop: 'Student_Admitted', checked: false, disabled: false },
            { value: 'Inactive', prop: 'Inactive', checked: false, disabled: false },
            { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }
        ];
        this.varJson.PageIndex = 1;
        if (sessionStorage.getItem('dashBoardParam') == "" || sessionStorage.getItem('dashBoardParam') == null || sessionStorage.getItem('dashBoardParam') == undefined) {
            return;
        }
        else {
            var obj = JSON.parse(sessionStorage.getItem('dashBoardParam'));
            var filter = obj.type;
            var fromDate = obj.dateR[0];
            var toDate = obj.dateR[1];
            this.varJson.searchBarData = '';
            this.statusString = [];
            switch (filter) {
                case "total":
                    {
                        this.statusString = [];
                        this.statFilter = [{ value: 'All', prop: 'All', checked: true, disabled: false }, { value: 'Pending Followup', prop: 'Pending', checked: false, disabled: false }, { value: 'Open', prop: 'Open', checked: false, disabled: false }, { value: 'In_Progress', prop: 'In_Progress', checked: false, disabled: false }, { value: 'Registered', prop: 'Registered', checked: false, disabled: false }, { value: 'Student_Admitted', prop: 'Student_Admitted', checked: false, disabled: false }, { value: 'Inactive', prop: 'Inactive', checked: false, disabled: false }, { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }];
                        this.instituteData = { name: "", phone: "", email: "", commentShow: 'false', enquiry_no: "", priority: "", status: -1, filtered_statuses: "", follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: this.getDateFormated(fromDate, "YYYY-MM-DD"), enquireDateTo: this.getDateFormated(toDate, "YYYY-MM-DD"), updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                        this.loadTableDatatoSource(this.instituteData);
                    }
                    break;
                case "Admitted":
                    {
                        this.statusString.push('12');
                        this.statFilter = [{ value: 'All', prop: 'All', checked: false, disabled: false }, { value: 'Pending Followup', prop: 'Pending', checked: false, disabled: false }, { value: 'Open', prop: 'Open', checked: false, disabled: false }, { value: 'In_Progress', prop: 'In_Progress', checked: false, disabled: false }, { value: 'Registered', prop: 'Registered', checked: false, disabled: false }, { value: 'Student_Admitted', prop: 'Student_Admitted', checked: true, disabled: false }, { value: 'Inactive', prop: 'Inactive', checked: false, disabled: false }, { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }];
                        this.instituteData = { name: "", phone: "", email: "", commentShow: 'false', enquiry_no: "", priority: "", status: -1, filtered_statuses: "12", follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: this.getDateFormated(fromDate, "YYYY-MM-DD"), enquireDateTo: this.getDateFormated(toDate, "YYYY-MM-DD"), updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                        this.loadTableDatatoSource(this.instituteData);
                    }
                    break;
                case "Closed":
                    {
                        this.statusString.push('1');
                        this.statFilter = [{ value: 'All', prop: 'All', checked: false, disabled: false }, { value: 'Pending Followup', prop: 'Pending', checked: false, disabled: false }, { value: 'Open', prop: 'Open', checked: false, disabled: false }, { value: 'In_Progress', prop: 'In_Progress', checked: false, disabled: false }, { value: 'Registered', prop: 'Registered', checked: false, disabled: false }, { value: 'Student_Admitted', prop: 'Student_Admitted', checked: false, disabled: false }, { value: 'Inactive', prop: 'Inactive', checked: true, disabled: false }, { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }
                        ];
                        this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: "1", follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: this.getDateFormated(fromDate, "YYYY-MM-DD"), enquireDateTo: this.getDateFormated(toDate, "YYYY-MM-DD"), updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                        this.loadTableDatatoSource(this.instituteData);
                    }
                    break;
                case "Open":
                    {
                        this.statusString.push('0');
                        this.statFilter = [{ value: 'All', prop: 'All', checked: false, disabled: false }, { value: 'Pending Followup', prop: 'Pending', checked: false, disabled: false }, { value: 'Open', prop: 'Open', checked: true, disabled: false }, { value: 'In_Progress', prop: 'In_Progress', checked: false, disabled: false }, { value: 'Registered', prop: 'Registered', checked: false, disabled: false }, { value: 'Student_Admitted', prop: 'Student_Admitted', checked: false, disabled: false }, { value: 'Inactive', prop: 'Inactive', checked: false, disabled: false }, { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }];
                        this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: "0", follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: this.getDateFormated(fromDate, "YYYY-MM-DD"), enquireDateTo: this.getDateFormated(toDate, "YYYY-MM-DD"), updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                        this.loadTableDatatoSource(this.instituteData);
                    }
                    break;
                case "InProgress":
                    {
                        this.statusString.push('3');
                        this.statFilter = [{ value: 'All', prop: 'All', checked: false, disabled: false }, { value: 'Pending Followup', prop: 'Pending', checked: false, disabled: false }, { value: 'Open', prop: 'Open', checked: false, disabled: false }, { value: 'In_Progress', prop: 'In_Progress', checked: true, disabled: false }, { value: 'Registered', prop: 'Registered', checked: false, disabled: false }, { value: 'Student_Admitted', prop: 'Student_Admitted', checked: false, disabled: false }, { value: 'Inactive', prop: 'Inactive', checked: false, disabled: false }, { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }];
                        this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: "3", follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: this.getDateFormated(fromDate, "YYYY-MM-DD"), enquireDateTo: this.getDateFormated(toDate, "YYYY-MM-DD"), updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                        this.loadTableDatatoSource(this.instituteData);
                    }
                    break;
                case "Registered":
                    {
                        this.statusString.push('11');
                        this.statFilter = [{ value: 'All', prop: 'All', checked: false, disabled: false }, { value: 'Pending Followup', prop: 'Pending', checked: false, disabled: false }, { value: 'Open', prop: 'Open', checked: false, disabled: false }, { value: 'In_Progress', prop: 'In_Progress', checked: false, disabled: false }, { value: 'Registered', prop: 'Registered', checked: true, disabled: false }, { value: 'Student_Admitted', prop: 'Student_Admitted', checked: false, disabled: false }, { value: 'Inactive', prop: 'Inactive', checked: false, disabled: false }, { value: 'Walkin', prop: 'Walkin', checked: false, disabled: false }];
                        this.instituteData = { name: "", phone: "", email: "", enquiry_no: "", commentShow: 'false', priority: "", status: -1, filtered_statuses: "11", follow_type: "", followUpDate: "", enquiry_date: "", assigned_to: -1, standard_id: -1, subjectIdArray: null, master_course_name: '', courseIdArray: null, subject_id: -1, is_recent: "Y", slot_id: -1, filtered_slots: "", isDashbord: "N", enquireDateFrom: this.getDateFormated(fromDate, "YYYY-MM-DD"), enquireDateTo: this.getDateFormated(toDate, "YYYY-MM-DD"), updateDate: "", updateDateFrom: "", updateDateTo: "", start_index: 0, batch_size: this.varJson.displayBatchSize, closedReason: "", enqCustomLi: null };
                        this.loadTableDatatoSource(this.instituteData);
                    }
                    break;
                default:
            }
        }
    };
    EnquiryHomeComponent.prototype.showApproveButtons = function (data) {
        var enableApprove = sessionStorage.getItem('allow_sms_approve_feature');
        var permissionArray = sessionStorage.getItem('permissions');
        if (permissionArray == "" || permissionArray == null) {
            if (enableApprove == '1' && data.statusValue == "Open") {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    };
    EnquiryHomeComponent.prototype.approveRejectSms = function (data, statusCode) {
        var _this = this;
        var msg = "";
        if (statusCode == 1) {
            msg = "approve";
        }
        else {
            msg = "reject";
        }
        if (confirm('Are you sure, You want  to ' + msg + ' the message?')) {
            this.prefill.changesSMSStatus({ 'status': statusCode }, data.message_id).subscribe(function (res) {
                var msg = { title: '' };
                if (statusCode == 1) {
                    msg.title = "SMS Approved";
                }
                else {
                    msg.title = "SMS Rejected";
                }
                _this.smsServicesInvoked();
                _this.showErrorMessage(_this.messageService.toastTypes.success, msg.title, '');
            }, function (err) {
                _this.showErrorMessage(_this.messageService.toastTypes.error, '', err.error.message);
            });
        }
    };
    // Advance filter City Selection
    EnquiryHomeComponent.prototype.onCitySelection = function (event) {
        var _this = this;
        this.areaList = [];
        if (event != "") {
            var obj = {
                city: event
            };
            this.prefill.getAreaList(obj).subscribe(function (res) {
                _this.areaList = res;
            }, function (err) {
                //console.log(err);
            });
        }
    };
    // This function gives you full information of enquiry selected which is fetched from server
    EnquiryHomeComponent.prototype.completeEnquiryDeatils = function (event) {
        this.selectedRow.gender = event.gender;
        this.selectedRow.institute_enquiry_id = event.institute_enquiry_id;
        this.selectedRow.school_id = event.school_id;
        if (this.flagJSON.isProfessional) {
            this.selectedRow.standard_id = event.standard_id;
        }
        else {
            this.selectedRow.master_course_name = event.master_course_name;
        }
    };
    // toast function
    EnquiryHomeComponent.prototype.showErrorMessage = function (objType, massage, body) {
        this._commService.showErrorMessage(objType, massage, body);
    };
    // Customizable Table Function
    EnquiryHomeComponent.prototype.setDefaultValues = function () {
        this.tableSetting.keys = [
            { primaryKey: 'enquiry_no', header: 'Enquiry No', priority: 1, allowSortingFlag: true },
            { primaryKey: 'name', header: 'Name', priority: 2, allowSortingFlag: true },
            { primaryKey: 'phone', header: "Contact No", priority: 3, allowSortingFlag: true },
            { primaryKey: 'statusValue', header: 'Status', priority: 4, allowSortingFlag: true },
            { primaryKey: 'priority', header: 'Priority', priority: 5, allowSortingFlag: true },
            { primaryKey: 'source_name', header: 'Source', priority: 6, allowSortingFlag: true },
            { primaryKey: 'followUpDate', header: 'Follow up Date', priority: 7, allowSortingFlag: true },
            { primaryKey: 'updateDate', header: 'Last Updated', priority: 8, allowSortingFlag: true }
        ];
        this.displayKeys = this.tableSetting.keys;
        this._tablePreferencesService.setTablePreferences(this.tableSetting.tableDetails.key, this.displayKeys);
    };
    EnquiryHomeComponent.prototype.openPreferences = function () {
        this.flagJSON.showPreference = true;
    };
    EnquiryHomeComponent.prototype.closePreferncesPopup = function (obj) {
        console.log(obj);
        this.flagJSON.showPreference = false;
        if (obj != undefined) {
            if (obj.hasOwnProperty('displayKeys')) {
                this.displayKeys = obj.displayKeys.sort(function (a, b) {
                    return a.priority - b.priority;
                });
            }
            this.cd.markForCheck();
        }
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('skelton'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], EnquiryHomeComponent.prototype, "skel", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('mySidenav'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], EnquiryHomeComponent.prototype, "mySidenav", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('enqPage'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], EnquiryHomeComponent.prototype, "enqPage", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('tablemain'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], EnquiryHomeComponent.prototype, "tablemain", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('pager'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], EnquiryHomeComponent.prototype, "pager", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('optMenu'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], EnquiryHomeComponent.prototype, "optMenu", void 0);
    EnquiryHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-enquiry-home',
            template: __webpack_require__("./src/app/components/leads/enquiry/enquiry-home/enquiry-home.component.html"),
            styles: [__webpack_require__("./src/app/components/leads/enquiry/enquiry-home/enquiry-home.component.scss")],
            changeDetection: __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectionStrategy"].OnPush
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_enquiry_services_fetchenquiry_service__["a" /* FetchenquiryService */],
            __WEBPACK_IMPORTED_MODULE_3__services_fetchprefilldata_service__["a" /* FetchprefilldataService */],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_5__services_enquiry_services_popup_handler_service__["a" /* PopupHandlerService */],
            __WEBPACK_IMPORTED_MODULE_4__services_enquiry_services_post_enquiry_data_service__["a" /* PostEnquiryDataService */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["ActivatedRoute"],
            __WEBPACK_IMPORTED_MODULE_9__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_10__services_multiBranchdata_service__["a" /* MultiBranchDataService */],
            __WEBPACK_IMPORTED_MODULE_11__services_common_service__["a" /* CommonServiceFactory */],
            __WEBPACK_IMPORTED_MODULE_12__services_message_show_service__["a" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_13__services_table_preference_table_preferences_service__["a" /* TablePreferencesService */],
            __WEBPACK_IMPORTED_MODULE_14__services_http_service__["a" /* HttpService */]])
    ], EnquiryHomeComponent);
    return EnquiryHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-home/enquiry-sidebar/enquiry-sidebar.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"sidebar-wrapper\">\r\n\r\n    <div class=\"row pull-left fixed-header\" style=\"margin:0px\">\r\n        <enquiry-actions [rowData]=\"rowData\"></enquiry-actions>\r\n    </div>\r\n\r\n    <div class=\"row header-row\">\r\n        <div class=\"c-lg-9 c-md-9 c-sm-9\" style=\"padding-top: 7px;\">\r\n            <ul>\r\n                <li style=\"border-top: none;\">\r\n                    <h2>Enquiry No. {{rowData.enquiry_no}}</h2>\r\n                </li>\r\n                <li class=\"header-name\" style=\"border-top: none;\">\r\n                    {{rowData.name}}\r\n                </li>\r\n                <li>\r\n                    <span style=\"color: #a5a5a5;font-weight: 600\">{{rowData.enquiry_date | date:'dd MMMM yyyy'}}</span>\r\n                    <a style=\"cursor: pointer;font-size: 12px;\" class=\"pull-right\" *ngIf=\"rowData.statusValue == 'Open' && openEnquiryFeature == '1'\"\r\n                        (click)=\"onEnquiryTakeIt()\">Take this Enquiry</a>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n        <div class=\"c-lg-3 c-md-3 c-sm-3\" style=\"padding-top: 7px;\">\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"acc-wrapper\">\r\n        <ul>\r\n            <li #one class=\"\">\r\n                <div class=\"row lihead\" (click)=\"toggleAccordian('one')\">\r\n                    <i class=\"nav\"></i>\r\n                    <h2>Update Enquiry</h2>\r\n                </div>\r\n                <section>\r\n                    <div class=\"update-form-wrapper AdFilter-field\">\r\n                        <div class=\"form-wrap\">\r\n                            <!-- Status -->\r\n                            <div class=\"form-wrapper \">\r\n                                <label for=\"enquiryStatusEdit\">Status</label>\r\n                                <div class=\"questionInfo\">\r\n                                    <span class=\"qInfoIcon notify-div\">?</span>\r\n                                    <div class=\"tooltip-box-field\">\r\n                                        Status Regarding The Enquiry\r\n                                    </div>\r\n                                </div>\r\n                                <select id=\"enquiryStatusEdit\" class=\"side-form-ctrl\" [(ngModel)]=\"updateFormData.statusValue\" name=\"statusValue\" [disabled]=\"updateFormData.statusValue == 'Student Admitted'\">\r\n                                    <option value=\"-1\"></option>\r\n                                    <option *ngFor=\"let status of statusArr\" [value]=\"status.data_value\" [attr.selected]=\"status.data_value == updateFormData.statusValue ? '' : null\"\r\n                                        [hidden]=\"status.data_key == 12 ? true : false\">\r\n                                        {{status.data_value}}\r\n                                    </option>\r\n                                </select>\r\n                            </div>\r\n\r\n                            <!-- Closing Reason -->\r\n                            <div class=\"form-wrapper\" *ngIf=\"updateFormData.statusValue == 'Closed'\">\r\n                                <label for=\"closingReason\">Closing Reason<span class=\"text-danger\">*</span></label>\r\n                                <select id=\"closingReason\" class=\"side-form-ctrl\" [(ngModel)]=\"updateFormData.closing_reason_id\" name=\"closingReason\">\r\n                                    <option value=\"0\"></option>\r\n                                    <option *ngFor=\"let status of closingReasonDataSource\" [value]=\"status.closing_reason_id\">{{status.closing_desc}}</option>\r\n                                </select>\r\n                            </div>\r\n\r\n                            <!-- Priority -->\r\n                            <div class=\"form-wrapper\">\r\n                                <label for=\"priorityEdit\">Priority</label>\r\n                                <select id=\"priorityEdit\" class=\"side-form-ctrl\" [(ngModel)]=\"updateFormData.priority\" name=\"priority\">\r\n                                    <option value=\"-1\"></option>\r\n                                    <option *ngFor=\"let priority of priorityArr\" [value]=\"priority.data_value\" [attr.selected]=\"priority.data_value == updateFormData.priority ? '' : null\">\r\n                                        {{priority.data_value}}\r\n                                    </option>\r\n                                </select>\r\n                            </div>\r\n\r\n                            <!-- Followup type -->\r\n                            <div class=\"form-wrapper \">\r\n                                <label for=\"selectFollowupEdit\">Follow Up Type</label>\r\n                                <select id=\"selectFollowupEdit\" class=\"side-form-ctrl \" [(ngModel)]=\"updateFormData.follow_type\" name=\"follow_type\">\r\n                                    <option value=\"-1\"></option>\r\n                                    <option *ngFor=\"let followT of followupArr\" [value]=\"followT.data_key\">\r\n                                        {{followT.data_value}}\r\n                                    </option>\r\n                                </select>\r\n                            </div>\r\n\r\n                            <!-- Branch -->\r\n                            <div class=\"form-wrapper \" *ngIf=\"mainBranchAdmin == 'Y' || subBranchAdmin == true\">\r\n                                <label for=\"brchList\">Branch</label>\r\n                                <select id=\"brchList\" class=\"side-form-ctrl\" name=\"brchList\" [(ngModel)]=\"updateFormData.source_instituteId\" (ngModelChange)=\"changeAssignList($event)\">\r\n                                    <option value=\"-1\"></option>\r\n                                    <option *ngFor=\"let branch of branchesList\" [value]=\"branch.institute_id\">\r\n                                        {{ branch.institute_name }}\r\n                                    </option>\r\n                                </select>\r\n                            </div>\r\n\r\n                            <!-- Assigned To -->\r\n                            <div class=\"form-wrapper \" *ngIf=\"isEnquiryAdmin\">\r\n                                <label for=\"assignedTo\">Assigned To</label>\r\n                                <select id=\"assignedTo\" class=\"side-form-ctrl\" name=\"assignedTo\" [(ngModel)]=\"updateFormData.assigned_to\">\r\n                                    <option value=\"-1\"></option>\r\n                                    <option *ngFor=\"let assigned of enqAssignTo\" [value]=\"assigned.userid\">\r\n                                        {{ assigned.name }}\r\n                                    </option>\r\n                                </select>\r\n                            </div>\r\n\r\n                            <!-- Followup Date -->\r\n                            <div class=\"form-wrapper datepicker \">\r\n                                <label for=\"followUPdateEdit\">Follow Up Date</label>\r\n                                <input type=\"text\" class=\"side-form-ctrl bsDatepicker\" value=\"\" placeholder=\"\" [(ngModel)]=\"updateFormData.followUpDate\"\r\n                                    (ngModelChange)=\"isNotifyDisplayed()\" id=\"followUPdateEdit\" readonly=\"true\" bsDatepicker/>\r\n                                <span class=\"date-clear\" name=\"followupdate\" (click)=\"updateFormData.followUpDate = ''\">X</span>\r\n                            </div>\r\n\r\n\r\n                            <!-- Followup Time -->\r\n                            <div class=\" wrapper-class\">\r\n                                <div class=\" followUpTime\">\r\n                                    <div class=\"form-wrapper  timepick\">\r\n                                        <label for=\"followuptime\">Follow Up Time</label>\r\n                                        <div class=\"tbox\">\r\n                                            <div class=\"times\">\r\n                                                <select id=\"followuptime\" class=\"mins side-form-ctrl\" [(ngModel)]=\"followUpTime.hour\" (change)=\"isNotifyDisplayed()\" name=\"followuptime\">\r\n                                                    <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                                                        {{time}}\r\n                                                    </option>\r\n                                                </select>\r\n                                            </div>\r\n                                            <div class=\"times\">\r\n                                                <select id=\"minute\" class=\"mers side-form-ctrl\" [(ngModel)]=\"followUpTime.minute\" name=\"minute\" (change)=\"isNotifyDisplayed()\">\r\n                                                    <option *ngFor=\"let minute of minuteArr\" [value]=\"minute\">\r\n                                                        {{minute}}\r\n                                                    </option>\r\n                                                </select>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n\r\n                                <div *ngIf=\"isNotifyVisible\">\r\n                                    <div class=\"form-checkbox-wrapper\">\r\n                                        <div class=\"field-checkbox-wrapper\">\r\n                                            <input type=\"checkbox\" [(ngModel)]=\"notifyme\" (ngModelChange)=\"notifyMe($event)\" class=\"form-checkbox\" style=\"display:inline-block;\"\r\n                                                id=\"notifyMe\">\r\n                                            <label for=\"notifyme\">Notify Me</label>\r\n                                            <div class=\"questionInfo\">\r\n                                                <span class=\"qInfoIcon\">!</span>\r\n                                                <div class=\"tooltip-box-field\">\r\n\r\n                                                    Follow up Time and Follow\r\n                                                    <br>up Date is Mandatory\r\n                                                </div>\r\n                                            </div>\r\n\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n\r\n                            </div>\r\n\r\n\r\n\r\n\r\n                            <!-- Walkin Date  -->\r\n\r\n                            <div class=\"form-wrapper datepicker\" *ngIf=\"updateFormData.follow_type == 'Walkin'\">\r\n                                <label for=\"walkindate\">Walkin Date</label>\r\n                                <input type=\"text\" class=\"side-form-ctrl bsDatepicker\" [(ngModel)]=\"updateFormData.walkin_followUpDate\" value=\"\" placeholder=\"\"\r\n                                    id=\"walkindate\" readonly=\"true\" bsDatepicker/>\r\n                                <span class=\"date-clear\" name=\"walkindate\" (click)=\"updateFormData.walkin_followUpDate =''\">X</span>\r\n                            </div>\r\n\r\n\r\n                            <!-- Walkin Time -->\r\n                            <div class=\"wrapper-class\" *ngIf=\"updateFormData.follow_type == 'Walkin'\">\r\n                                <div class=\"form-wrapper timepick\">\r\n                                    <label for=\"walkintime\">Walkin Time</label>\r\n                                    <div class=\"tbox\">\r\n                                        <div class=\"times \">\r\n                                            <select id=\"walkintime\" class=\"side-form-ctrl mins\" [(ngModel)]=\"walkin_followUpTime.hour\" name=\"walkintime\">\r\n                                                <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                                                    {{time}}\r\n                                                </option>\r\n                                            </select>\r\n                                        </div>\r\n                                        <div class=\"times \">\r\n                                            <select id=\"minute\" class=\"side-form-ctrl mers\" [(ngModel)]=\"walkin_followUpTime.minute\" name=\"minute\">\r\n                                                <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                                                    {{minute}}\r\n                                                </option>\r\n                                            </select>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n\r\n\r\n                            <!-- Branch -->\r\n                            <!-- <div class=\"form-wrapper c-sm-6 c-xs-6\">\r\n                                 <label for=\"branch\">Branch</label>\r\n                                 <select id=\"branch\" class=\"side-form-ctrl\" [(ngModel)]=\"updateFormData.no_of_branches\" name=\"branch\">\r\n                                 <option value=\"-1\"></option>\r\n                                 <option value=\"\"></option>\r\n                                 <option value=\"\"></option>\r\n                                 </select>\r\n                                 </div>\r\n                            -->\r\n\r\n                            <!-- Comments -->\r\n                            <div class=\"form-wrapper c-xs-12\" style=\"padding-left:10px;width:68%;\">\r\n                                <div class=\"field-wrapper\" style=\"padding-top: 25px;\">\r\n                                    <label style=\"top: 0px; padding-left:10px;\" for=\"commies\">Comments</label>\r\n                                    <textarea placeholder=\"Max 1000 characters\" rows=\"1\" cols=\"1\" style=\"height: 85px;border: solid 2px rgba(53, 53, 53, 0.26);padding: 5px 5px 5px 0px;\"\r\n                                        id=\"addcommentEdit\" class=\"form-ctrl\" [(ngModel)]=\"updateFormData.comment\">\r\n                                    </textarea>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n\r\n                        <div class=\"footer-wrap\">\r\n                            <!-- Submitter -->\r\n                            <div class=\"\">\r\n                                <div class=\"pull-left submitter\">\r\n                                    <div class=\"clearfix\">\r\n                                        <aside class=\"pull-left popup-btn\">\r\n                                            <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closeSideNav()\" id=\"BtncloseSideNav\">\r\n                                            <input type=\"button\" value=\"Update\" class=\"fullBlue btn\" (click)=\"createUpdateForm()\" id=\"BtnupdtaeForm\">\r\n                                        </aside>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </section>\r\n            </li>\r\n            <li #two class=\"liclosed\">\r\n                <div class=\"row lihead\" (click)=\"toggleAccordian('two')\">\r\n                    <i class=\"nav\"></i>\r\n                    <h2>Previous Comments</h2>\r\n                </div>\r\n                <section>\r\n                    <div class=\"comment-wrapper\" *ngIf=\"updateFormComments != null\">\r\n                        <div class=\"comment-card\" *ngFor=\"let comments of updateFormComments; let i = index;\">\r\n                            <div class=\"comment-box\">\r\n                                <div class=\"comment-head\">\r\n                                    <i style=\"font-family: FontAwesome\" class=\"far fa-user-circle\"></i>\r\n                                    <h6 class=\"comment-name\">\r\n                                        <a id=\"commentAnch1\">{{updateFormCommentsBy[i]}}</a>\r\n                                    </h6>\r\n                                    <span>{{getCommentDate(updateFormCommentsOn[i])}}</span>\r\n                                </div>\r\n                                <div class=\"comment-content\">\r\n                                    {{comments}}\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"comment-wrapper\" *ngIf=\"updateFormComments == null\">\r\n                        <h3 style=\"padding: 10px;text-align: center;\">No Comments Updated</h3>\r\n                    </div>\r\n                </section>\r\n            </li>\r\n            <li #three class=\"liclosed\">\r\n                <div class=\"row lihead\" (click)=\"toggleAccordian('three')\">\r\n                    <i class=\"nav\"></i>\r\n                    <h2>Basic Details</h2>\r\n                </div>\r\n                <section>\r\n                    <div class=\"basic-wrapper\">\r\n                        <div class=\"form-wrapper \">\r\n                            <label for=\"Email\">Email</label>\r\n                            <input readonly=\"true\" class=\"side-form-ctrl blocked\" [(ngModel)]=\"rowData.email\" type=\"text\" name=\"Email\" id=\"Email\">\r\n                        </div>\r\n\r\n                        <div class=\"form-wrapper \">\r\n                            <label for=\"Email\">DOB</label>\r\n                            <input readonly=\"true\" id=\"Email\" class=\"side-form-ctrl blocked\" [(ngModel)]=\"rowData.dob\" type=\"text\" name=\"dob\">\r\n                        </div>\r\n\r\n                        <div class=\"form-wrapper \">\r\n                            <label for=\"ParentName\">Parent Name</label>\r\n                            <input readonly=\"true\" class=\"side-form-ctrl blocked\" [(ngModel)]=\"rowData.parent_name\" type=\"text\" name=\"ParentName\" id=\"ParentName\">\r\n                        </div>\r\n\r\n                        <!-- Non Professional Institute -->\r\n                        <div *ngIf=\"!isLangInstitute\" class=\"form-wrapper \">\r\n                            <label for=\"Standard\">Standard</label>\r\n                            <input readonly=\"true\" id=\"Standard\" class=\"side-form-ctrl blocked\" [(ngModel)]=\"rowData.standard\" type=\"text\" name=\"Standard\">\r\n                        </div>\r\n                        <div *ngIf=\"!isLangInstitute\" class=\"form-wrapper \">\r\n                            <label for=\"Subject\">Subject</label>\r\n                            <input readonly=\"true\" id=\"Subject\" class=\"side-form-ctrl blocked\" [(ngModel)]=\"rowData.subjects\" type=\"text\" name=\"Subject\">\r\n                        </div>\r\n\r\n                        <!-- Non Professional Institute -->\r\n                        <div *ngIf=\"!isLangInstitute\" class=\"form-wrapper \">\r\n                            <label for=\"StandardMC\">Master Course</label>\r\n                            <input readonly=\"true\" id=\"StandardMC\" class=\"side-form-ctrl blocked\" [(ngModel)]=\"rowData.master_course_name\" type=\"text\"\r\n                                name=\"StandardMC\">\r\n                        </div>\r\n                        <div *ngIf=\"!isLangInstitute\" class=\"form-wrapper \">\r\n                            <label for=\"SubjectMC\">Course</label>\r\n                            <input readonly=\"true\" id=\"SubjectMC\" class=\"side-form-ctrl blocked\" [(ngModel)]=\"courseIdArray\" type=\"text\" name=\"SubjectMC\">\r\n                        </div>\r\n\r\n\r\n                        <!-- Professional institute -->\r\n                        <div *ngIf=\"isLangInstitute\" class=\"form-wrapper \">\r\n                            <label for=\"Standard\">Master Course</label>\r\n                            <input readonly=\"true\" id=\"Standard\" class=\"side-form-ctrl blocked\" [(ngModel)]=\"proMc\" type=\"text\" name=\"Standard\">\r\n                        </div>\r\n                        <div *ngIf=\"isLangInstitute\" class=\"form-wrapper \">\r\n                            <label for=\"Subject\">Course</label>\r\n                            <input readonly=\"true\" id=\"Subject\" class=\"side-form-ctrl blocked\" [(ngModel)]=\"proC\" type=\"text\" name=\"Subject\">\r\n                        </div>\r\n\r\n\r\n                        <div class=\"form-wrapper \">\r\n                            <label for=\"Subject\">Source</label>\r\n                            <input readonly=\"true\" id=\"idSource\" class=\"side-form-ctrl blocked\" [(ngModel)]=\"sourceName\" type=\"text\" name=\"Subject\">\r\n                        </div>\r\n                    </div>\r\n                </section>\r\n            </li>\r\n            <li #four class=\"liclosed\">\r\n                <div class=\"row lihead\" (click)=\"toggleAccordian('four')\">\r\n                    <i class=\"nav\"></i>\r\n                    <h2>Other Details</h2>\r\n                </div>\r\n                <section>\r\n                    <div class=\"other-wrapper\">\r\n                        <div *ngFor=\"let cus of customComp\">\r\n                            <div class=\"form-wrapper\">\r\n                                <label for=\"{{cus.label}}\">{{cus.label}}</label>\r\n                                <input readonly=\"true\" class=\"side-form-ctrl blocked\" [(ngModel)]=\"cus.enq_custom_value\" type=\"text\" name=\"{{cus.label}}\"\r\n                                    id=\"{{cus.label}}\">\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </section>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-home/enquiry-sidebar/enquiry-sidebar.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/*  */\n.sidebar-wrapper ::-webkit-scrollbar {\n  display: block; }\n.sidebar-wrapper .update-form-wrapper .form-wrap {\n  padding-top: 5px;\n  width: 100%;\n  background: rgba(239, 239, 239, 0.55);\n  max-height: 360px;\n  overflow: auto; }\n.sidebar-wrapper .update-form-wrapper .footer-wrap {\n  background: white;\n  border-top: 1px solid #efefef; }\n.sidebar-wrapper .update-form-wrapper .form-wrapper {\n  background: transparent;\n  margin: 5px 0px;\n  width: 100%; }\n.sidebar-wrapper .update-form-wrapper .form-wrapper.datepicker {\n    padding-top: 3px; }\n.sidebar-wrapper .update-form-wrapper .form-wrapper.datepicker span {\n      position: relative;\n      right: 25px;\n      font-weight: 600;\n      font-size: 16px;\n      color: red;\n      cursor: pointer;\n      width: 20px;\n      text-align: center;\n      /* &::before {\r\n                        content: '';\r\n                        background: url('/assets/images/calendar.svg') no-repeat;\r\n                        position: absolute;\r\n                        right: 25px;\r\n                        top: 0px;\r\n                        width: 21px;\r\n                        height: 21px;\r\n                        z-index: 0;\r\n                    } */ }\n.sidebar-wrapper .update-form-wrapper .form-wrapper label {\n    padding-left: 10px;\n    font-size: 12px;\n    font-weight: 400;\n    color: rgba(0, 0, 0, 0.77);\n    text-decoration: none;\n    text-transform: uppercase;\n    -webkit-font-smoothing: antialiased;\n    width: 100%; }\n.sidebar-wrapper .update-form-wrapper .form-wrapper .side-form-ctrl {\n    background: white;\n    border: 1px solid rgba(119, 119, 119, 0.419608);\n    width: 60%;\n    padding-left: 10px;\n    margin-left: 10px;\n    height: 30px;\n    padding: 0px 5px;\n    font-weight: 600;\n    font-size: 14px;\n    color: black; }\n.sidebar-wrapper .update-form-wrapper .form-wrapper .side-form-ctrl.bsDatepicker {\n      width: 60%; }\n.sidebar-wrapper .update-form-wrapper .form-wrapper.timepick {\n    width: 100%;\n    padding-top: 0px; }\n.sidebar-wrapper .update-form-wrapper .form-wrapper.timepick .tbox {\n      width: 100%; }\n.sidebar-wrapper .update-form-wrapper .form-wrapper.timepick .tbox .times {\n        display: inline-block; }\n.sidebar-wrapper .update-form-wrapper .form-wrapper.timepick .tbox .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        padding: 0px 5px;\n        font-weight: 600;\n        font-size: 14px;\n        color: black; }\n.sidebar-wrapper .update-form-wrapper .form-wrapper.timepick .tbox .side-form-ctrl.mins {\n          width: 100%; }\n.sidebar-wrapper .update-form-wrapper .form-wrapper.timepick .tbox .side-form-ctrl.mers {\n          width: 100%; }\n.sidebar-wrapper .update-form-wrapper .form-checkbox-wrapper {\n  padding: 0px 15px 0px 10px; }\n.sidebar-wrapper .update-form-wrapper .form-checkbox-wrapper .field-checkbox-wrapper .form-checkbox {\n    opacity: 0;\n    position: absolute;\n    left: 0;\n    top: 2px;\n    width: 20px;\n    height: 20px;\n    z-index: 1; }\n.sidebar-wrapper .update-form-wrapper .form-checkbox-wrapper .field-checkbox-wrapper .form-checkbox + label::before {\n    width: 1px;\n    height: 1px;\n    left: 8px;\n    top: 12px;\n    position: absolute;\n    content: '';\n    border-top: 0;\n    border-right: 0;\n    border-left: 2px solid transparent;\n    border-bottom: 2px solid transparent;\n    -webkit-transform: rotate(-45deg);\n            transform: rotate(-45deg); }\n.sidebar-wrapper .update-form-wrapper .form-checkbox-wrapper .field-checkbox-wrapper .form-checkbox + label::after {\n    content: '';\n    width: 16px;\n    height: 16px;\n    border: 2px solid #ccc;\n    border-radius: 2px;\n    position: absolute;\n    left: 0;\n    top: 8px; }\n.sidebar-wrapper .update-form-wrapper .form-checkbox-wrapper .field-checkbox-wrapper .form-checkbox:checked + label::before {\n    border-left: 2px solid #0084f6;\n    border-bottom: 2px solid #0084f6;\n    width: 12px;\n    height: 5px;\n    left: 2px;\n    top: 13px; }\n.sidebar-wrapper .update-form-wrapper .form-checkbox-wrapper .field-checkbox-wrapper .form-checkbox:checked + label::after {\n    content: '';\n    width: 16px;\n    height: 16px;\n    border: 2px solid #ccc;\n    border-radius: 2px;\n    position: absolute;\n    left: 0;\n    top: 8px; }\n.sidebar-wrapper .update-form-wrapper .row {\n  margin: 0; }\n.sidebar-wrapper .update-form-wrapper .sixty .field-wrapper {\n  position: relative;\n  padding-top: 20px; }\n.sidebar-wrapper .update-form-wrapper .sixty .field-wrapper.datePickerBox .bsDatepicker {\n    cursor: pointer;\n    position: relative;\n    z-index: 1;\n    background: transparent; }\n.sidebar-wrapper .update-form-wrapper .sixty .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"/./assets/images/calendar.svg\") no-repeat;\n    position: absolute;\n    right: 40%;\n    top: 18px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.sidebar-wrapper .update-form-wrapper .sixty .field-wrapper .date-clear {\n    position: relative;\n    right: 60%;\n    top: 50px;\n    color: #0084f6; }\n.sidebar-wrapper .update-form-wrapper .sixty .field-wrapper .form-ctrl {\n  display: block;\n  width: 75%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 10px 0 5px;\n  outline: none;\n  border: 0;\n  border-bottom: solid 1px #e2ebee;\n  height: 36px;\n  font: 400 12px 'Open sans',sans-serif;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n  border-radius: 0;\n  line-height: 24px; }\n.sidebar-wrapper .update-form-wrapper .sixty .field-wrapper label {\n  position: absolute;\n  top: 22px;\n  font-size: 14px;\n  left: 0px;\n  -webkit-transition: all 0.1s ease-in-out;\n  transition: all 0.1s ease-in-out;\n  color: #777; }\n.sidebar-wrapper .update-form-wrapper .sixty .field-wrapper .form-ctrl:focus {\n  padding: 12px 0 6px;\n  border-bottom: solid 2px #0084f6;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n  line-height: 26px; }\n.sidebar-wrapper .update-form-wrapper .sixty .field-wrapper.has-value .form-ctrl + label,\n.sidebar-wrapper .update-form-wrapper .sixty .field-wrapper .form-ctrl:focus + label {\n  font-size: 8px;\n  top: 6px;\n  left: 0px; }\n.sidebar-wrapper .update-form-wrapper .sixty .field-wrapper.has-value .form-ctrl + label,\n.sidebar-wrapper .update-form-wrapper .sixty .field-wrapper .form-ctrl:focus + label {\n  color: #0084f6;\n  font-size: 13px; }\n.sidebar-wrapper .update-form-wrapper .time-picker .field-wrapper {\n  position: relative;\n  padding-top: 20px; }\n.sidebar-wrapper .update-form-wrapper .time-picker .field-wrapper .form-ctrl {\n  display: block;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 10px 0 5px;\n  outline: none;\n  border: 0;\n  border-bottom: solid 1px #e2ebee;\n  height: 36px;\n  font: 400 12px 'Open sans',sans-serif;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n  border-radius: 0;\n  line-height: 24px; }\n.sidebar-wrapper .update-form-wrapper .time-picker .field-wrapper label {\n  position: absolute;\n  top: 22px;\n  font-size: 14px;\n  left: 0px;\n  -webkit-transition: all 0.1s ease-in-out;\n  transition: all 0.1s ease-in-out;\n  color: #777; }\n.sidebar-wrapper .update-form-wrapper .time-picker .field-wrapper .form-ctrl:focus {\n  padding: 12px 0 6px;\n  border-bottom: solid 2px #0084f6;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n  line-height: 26px; }\n.sidebar-wrapper .update-form-wrapper .time-picker .field-wrapper.has-value .form-ctrl + label,\n.sidebar-wrapper .update-form-wrapper .time-picker .field-wrapper .form-ctrl:focus + label {\n  font-size: 8px;\n  top: 6px;\n  left: 0px; }\n.sidebar-wrapper .update-form-wrapper .time-picker .field-wrapper.has-value .form-ctrl + label,\n.sidebar-wrapper .update-form-wrapper .time-picker .field-wrapper .form-ctrl:focus + label {\n  color: #0084f6;\n  font-size: 13px; }\n.sidebar-wrapper .row {\n  margin: 5px 0px; }\n.sidebar-wrapper .header-row .header-name {\n  text-transform: capitalize;\n  font-weight: 600; }\n.sidebar-wrapper .header-row ul {\n  list-style: none; }\n.sidebar-wrapper .header-row ul li {\n    padding: 5px 0px 0px 0px; }\n.AdFilter-field .field-wrapper {\n  margin: 15px 0; }\n.AdFilter-field .field-wrapper .date-clear {\n    position: absolute;\n    right: 15px;\n    top: 63px;\n    cursor: pointer;\n    color: #0084f6; }\n.AdFilter-field .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    left: 94% !important;\n    top: 33px !important;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n/* Style the buttons that are used to open and close the accordion panel */\n.accordion {\n  background-color: #eee;\n  color: #444;\n  cursor: pointer;\n  padding: 18px;\n  width: 100%;\n  text-align: left;\n  border: none;\n  outline: none;\n  -webkit-transition: 0.4s;\n  transition: 0.4s; }\n/* Add a background color to the button if it is clicked on (add the .active class with JS), and when you move the mouse over it (hover) */\n.active,\n.accordion:hover {\n  background-color: #ccc; }\n/* Style the accordion panel. Note: hidden by default */\n.panel {\n  padding: 0 18px;\n  background-color: white;\n  display: none; }\n.submitter {\n  margin: 10px 0px; }\n.acc-wrapper {\n  display: inline-block;\n  /* position: relative;\r\n    left: 50%; */\n  margin: 10px 0;\n  padding: 0px 5px;\n  width: 100%;\n  height: 100%; }\n.acc-wrapper i.nav {\n    position: absolute;\n    -webkit-transform: translate(-6px, 0);\n            transform: translate(-6px, 0);\n    margin-top: 12px;\n    right: 10px; }\n.acc-wrapper i.nav:before, .acc-wrapper i.nav:after {\n      content: \"\";\n      position: absolute;\n      background-color: #000000;\n      width: 3px;\n      height: 9px; }\n.acc-wrapper i.nav:before {\n      -webkit-transform: translate(-2px, 0) rotate(45deg);\n              transform: translate(-2px, 0) rotate(45deg); }\n.acc-wrapper i.nav:after {\n      -webkit-transform: translate(2px, 0) rotate(-45deg);\n              transform: translate(2px, 0) rotate(-45deg); }\n.acc-wrapper .liclosed i.nav:before {\n    -webkit-transform: translate(2px, 0) rotate(45deg);\n            transform: translate(2px, 0) rotate(45deg); }\n.acc-wrapper .liclosed i.nav:after {\n    -webkit-transform: translate(-2px, 0) rotate(-45deg);\n            transform: translate(-2px, 0) rotate(-45deg); }\n.acc-wrapper .liclosed section {\n    height: 0; }\n.acc-wrapper section {\n    color: rgba(25, 27, 29, 0.8);\n    line-height: 26px;\n    letter-spacing: 1px;\n    position: relative;\n    overflow-x: hidden;\n    overflow-y: auto;\n    height: 100%;\n    opacity: 1;\n    -webkit-transform: translate(0, 0);\n            transform: translate(0, 0);\n    margin-top: 0px;\n    z-index: 2; }\n.acc-wrapper .row {\n    margin: 0; }\n.acc-wrapper .row.lihead h2 {\n      font-size: 14px;\n      line-height: 40px;\n      font-weight: 600;\n      letter-spacing: 1px;\n      display: block;\n      background-color: #ffffff;\n      color: rgba(0, 0, 0, 0.72);\n      padding-left: 10px;\n      border-radius: 0px;\n      margin: 0;\n      border-bottom: 1px solid rgba(218, 218, 218, 0.74);\n      border-top: 1px solid rgba(218, 218, 218, 0.74);\n      cursor: pointer; }\n.acc-wrapper section {\n    -webkit-transition: all 0.25s ease-in-out;\n    transition: all 0.25s ease-in-out; }\n.acc-wrapper section .comment-wrapper .comment-card .comment-box::after {\n      content: '';\n      height: 0;\n      width: 0;\n      position: absolute;\n      display: block;\n      border-width: 10px 12px 10px 0;\n      border-style: solid;\n      border-color: transparent #FCFCFC;\n      top: 8px;\n      left: -11px; }\n.acc-wrapper section .comment-wrapper .comment-card .comment-box::before {\n      border-width: 11px 13px 11px 0;\n      border-color: transparent rgba(0, 0, 0, 0.05);\n      left: -12px; }\n.acc-wrapper section .comment-wrapper .comment-card .comment-box .comment-head {\n      background: #FCFCFC;\n      padding: 5px 12px;\n      overflow: hidden;\n      border-radius: 4px 4px 0 0; }\n.acc-wrapper section .comment-wrapper .comment-card .comment-box .comment-head span {\n        float: left;\n        color: #999;\n        font-size: 13px;\n        position: relative;\n        top: 0; }\n.acc-wrapper section .comment-wrapper .comment-card .comment-box .comment-head i {\n        float: left;\n        margin-right: 5px;\n        font-size: 24px;\n        position: relative;\n        top: 0;\n        color: #0060a3;\n        cursor: pointer;\n        -webkit-transition: color 0.3s ease;\n        transition: color 0.3s ease; }\n.acc-wrapper section .comment-wrapper .comment-card .comment-box .comment-name {\n      color: #283035;\n      font-size: 14px;\n      font-weight: 700;\n      float: left;\n      margin-right: 10px; }\n.acc-wrapper section .comment-wrapper .comment-card .comment-box .comment-name a {\n        color: #283035; }\n.acc-wrapper section .comment-wrapper .comment-card .comment-box .comment-content {\n      background: #FFF;\n      padding: 0px 42px 20px 42px;\n      font-size: 15px;\n      color: #595959;\n      border-radius: 0 0 4px 4px; }\n.acc-wrapper section .basic-wrapper .form-wrapper {\n      background: transparent;\n      margin: 5px 0px; }\n.acc-wrapper section .basic-wrapper .form-wrapper.datepicker span {\n        position: absolute;\n        top: 30%;\n        right: 30%;\n        font-weight: 600;\n        font-size: 16px;\n        color: red;\n        cursor: pointer;\n        width: 20px;\n        text-align: center;\n        /* &::before {\r\n                            content: '';\r\n                            background: url('/assets/images/calendar.svg') no-repeat;\r\n                            position: absolute;\r\n                            right: 25px;\r\n                            top: 0px;\r\n                            width: 21px;\r\n                            height: 21px;\r\n                            z-index: 0;\r\n                        } */ }\n.acc-wrapper section .basic-wrapper .form-wrapper label {\n        font-size: 12px;\n        font-weight: 400;\n        color: rgba(0, 0, 0, 0.77);\n        padding-bottom: 2px;\n        text-decoration: none;\n        text-transform: uppercase;\n        -webkit-font-smoothing: antialiased; }\n.acc-wrapper section .basic-wrapper .form-wrapper .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        padding: 2px 5px;\n        font-weight: 600;\n        font-size: 14px;\n        color: black;\n        cursor: context-menu; }\n.acc-wrapper section .basic-wrapper .form-wrapper .side-form-ctrl.bsDatepicker {\n          padding: 5px;\n          width: 100%; }\n.acc-wrapper section .basic-wrapper .form-wrapper .side-form-ctrl.blocked {\n          background-color: #efefef; }\n.acc-wrapper section .basic-wrapper .form-wrapper.timepick {\n        width: 50%;\n        padding: 1px 15px; }\n.acc-wrapper section .basic-wrapper .form-wrapper.timepick .tbox {\n          width: 100%; }\n.acc-wrapper section .basic-wrapper .form-wrapper.timepick .tbox .times {\n            display: inline-block; }\n.acc-wrapper section .basic-wrapper .form-wrapper.timepick .tbox .side-form-ctrl {\n            background: white;\n            border: 1px solid rgba(119, 119, 119, 0.419608);\n            width: 100%;\n            height: 80%;\n            padding: 2px 5px;\n            font-weight: 600;\n            font-size: 14px;\n            color: black; }\n.acc-wrapper section .basic-wrapper .form-wrapper.timepick .tbox .side-form-ctrl.mins {\n              width: 80px; }\n.acc-wrapper section .basic-wrapper .form-wrapper.timepick .tbox .side-form-ctrl.mers {\n              width: 50px; }\n.acc-wrapper section .other-wrapper .form-wrapper {\n      background: transparent;\n      margin: 5px 0px; }\n.acc-wrapper section .other-wrapper .form-wrapper.datepicker span {\n        position: absolute;\n        top: 35px;\n        right: 20px;\n        font-weight: 600;\n        font-size: 16px;\n        color: red;\n        cursor: pointer;\n        width: 20px;\n        text-align: center; }\n.acc-wrapper section .other-wrapper .form-wrapper label {\n        font-size: 12px;\n        font-weight: 400;\n        color: rgba(0, 0, 0, 0.77);\n        padding-bottom: 2px;\n        text-decoration: none;\n        text-transform: uppercase;\n        -webkit-font-smoothing: antialiased; }\n.acc-wrapper section .other-wrapper .form-wrapper .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        height: 50%;\n        padding: 2px 5px;\n        font-weight: 600;\n        font-size: 14px;\n        color: black;\n        cursor: context-menu; }\n.acc-wrapper section .other-wrapper .form-wrapper .side-form-ctrl.bsDatepicker {\n          padding: 5px;\n          width: 100%; }\n.acc-wrapper section .other-wrapper .form-wrapper .side-form-ctrl.blocked {\n          background-color: #efefef; }\n.acc-wrapper section .other-wrapper .form-wrapper.timepick {\n        width: 50%;\n        padding: 1px 15px; }\n.acc-wrapper section .other-wrapper .form-wrapper.timepick .tbox {\n          width: 100%; }\n.acc-wrapper section .other-wrapper .form-wrapper.timepick .tbox .times {\n            display: inline-block; }\n.acc-wrapper section .other-wrapper .form-wrapper.timepick .tbox .side-form-ctrl {\n            background: white;\n            border: 1px solid rgba(119, 119, 119, 0.419608);\n            width: 100%;\n            height: 50%;\n            padding: 2px 5px;\n            font-weight: 600;\n            font-size: 14px;\n            color: black; }\n.acc-wrapper section .other-wrapper .form-wrapper.timepick .tbox .side-form-ctrl.mins {\n              width: 80px; }\n.acc-wrapper section .other-wrapper .form-wrapper.timepick .tbox .side-form-ctrl.mers {\n              width: 50px; }\n.acc-wrapper h1,\n  .acc-wrapper h2 {\n    color: #000000; }\n.acc-wrapper h1 {\n    text-transform: uppercase;\n    font-size: 36px;\n    line-height: 42px;\n    letter-spacing: 3px;\n    font-weight: 100; }\n.acc-wrapper ul {\n    list-style: none;\n    -webkit-perspective: 900;\n            perspective: 900;\n    padding: 0;\n    margin: 0; }\n.acc-wrapper ul li {\n      position: relative;\n      padding: 0;\n      margin: 0;\n      padding-bottom: 3px 5px; }\n.wrapper-class .followUpTime {\n  padding-left: 0px; }\n.wrapper-class .followUpTime .side-form-ctrl.mins {\n    width: 100% !important; }\n.wrapper-class .followUpTime .side-form-ctrl.mers {\n    width: 100% !important; }\n.wrapper-class .followUpTime .form-wrapper .tbox .times .side-form-ctrl.mins {\n    width: 100% !important; }\n.wrapper-class .followUpTime .form-wrapper .tbox .times .side-form-ctrl.mers {\n    width: 100% !important; }\n.questionInfo {\n  position: relative;\n  left: 60px;\n  top: -25px;\n  height: 20px;\n  width: 15px;\n  z-index: 2; }\n.questionInfo .qInfoIcon {\n    width: 20px;\n    margin-left: 22px;\n    margin-top: 4px;\n    height: 20px;\n    border: 1px solid #ccc;\n    border-radius: 50%;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    line-height: 20px;\n    font-weight: 600;\n    font-size: 12px;\n    cursor: pointer;\n    -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n            box-shadow: 0px 0px 1px 0px #ccc inset;\n    color: #888;\n    -webkit-transition: all 0.2s linear;\n    transition: all 0.2s linear; }\n.questionInfo .qInfoIcon.notify-div {\n      margin-left: 11px; }\n.questionInfo .qInfoIcon:hover {\n      border-color: #0060A3;\n      -webkit-box-shadow: 0px 0px 1px 0px #0060A3 inset;\n              box-shadow: 0px 0px 1px 0px #0060A3 inset;\n      color: #0060A3; }\n.tooltip-box-field {\n  width: 190px;\n  min-height: 0px;\n  white-space: nowrap;\n  padding: 0px;\n  padding-left: 3px; }\n.field-checkbox-wrapper {\n  position: relative;\n  padding-left: 25px;\n  margin-bottom: -20px; }\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-home/enquiry-sidebar/enquiry-sidebar.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EnquirySidebarComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_fetchprefilldata_service__ = __webpack_require__("./src/app/services/fetchprefilldata.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var EnquirySidebarComponent = /** @class */ (function () {
    function EnquirySidebarComponent(prefill, cd, appC, auth) {
        this.prefill = prefill;
        this.cd = cd;
        this.appC = appC;
        this.auth = auth;
        this.times = ['', '1 AM', '2 AM', '3 AM', '4 AM', '5 AM', '6 AM', '7 AM', '8 AM', '9 AM', '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM', '4 PM', '5 PM', '6 PM', '7 PM', '8 PM', '9 PM', '10 PM', '11 PM', '12 AM'];
        this.minArr = ['', '00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55'];
        this.meridianArr = ['', "AM", "PM"];
        this.isEnquiryAdmin = false;
        this.proMc = "";
        this.proC = "";
        this.isLangInstitute = false;
        this.notifyme = false;
        this.walkin_followUpTime = {
            hour: '',
            minute: ''
        };
        this.followUpTime = {
            hour: '',
            minute: ''
        };
        this.updateFormData = {
            assigned_to: '-1',
            closedReason: null,
            comment: "",
            commentDate: __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD'),
            demo_account_end_date: "",
            demo_account_password: "",
            demo_account_status: "",
            demo_account_userid: "",
            followUpDate: "",
            followUpTime: "",
            follow_type: "-1",
            institution_id: sessionStorage.getItem('institute_id'),
            interested_in: "",
            isEnquiryUpdate: "Y",
            is_follow_up_time_notification: 0,
            next_follow_type: "",
            no_of_branches: "",
            no_of_students: "",
            occupation_id: null,
            priority: "-1",
            slot_id: null,
            source_instituteId: sessionStorage.getItem('institute_id'),
            status: "-1",
            statusValue: "",
            followUpDateTime: '',
            isEnquiryV2Update: "N",
            isRegisterFeeUpdate: "N",
            walkin_followUpDate: __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD'),
            walkin_followUpTime: "",
            amount: null,
            paymentMode: null,
            paymentDate: null,
            reference: null,
            closing_reason_id: ''
        };
        this.updateFormComments = [];
        this.updateFormCommentsBy = [];
        this.updateFormCommentsOn = [];
        this.sourceName = "";
        this.isNotifyVisible = false;
        this.openEnquiryFeature = '0';
        this.minuteArr = ['', '00', '15', '30', '45'];
        this.updateEnq = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.cancelUpdate = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.getUserList = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.fullEnquiryDetails = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.isEnquiryAdministrator();
        this.checkInstituteType();
    }
    EnquirySidebarComponent.prototype.ngOnChanges = function () {
        this.cd.markForCheck();
        this.enquiryRow;
        this.priorityArr;
        this.statusArr;
        this.priorityArr;
        this.row;
        this.customComp;
        this.instituteEnqId = this.enquiryRow;
        this.masterCourseData;
        this.rowData = this.row;
        this.branchesList;
        this.enqAssignTo;
        this.mainBranchAdmin;
        this.subBranchAdmin;
        this.updateFormData.priority = "";
        this.updateFormData.follow_type = "";
        this.updateFormData.statusValue = "";
        this.getDetailsById(this.instituteEnqId);
    };
    EnquirySidebarComponent.prototype.ngOnInit = function () {
        this.openEnquiryFeature = sessionStorage.getItem('open_enq_Visibility_feature');
    };
    EnquirySidebarComponent.prototype.ngOnDestroy = function () {
    };
    EnquirySidebarComponent.prototype.getDetailsById = function (id) {
        var _this = this;
        this.cd.markForCheck();
        this.updateFormData.priority = this.rowData.priority;
        this.updateFormData.follow_type = this.rowData.follow_type;
        this.updateFormData.statusValue = this.rowData.statusValue;
        this.followUpTime = {
            hour: '',
            minute: ''
        };
        this.walkin_followUpTime = {
            hour: '',
            minute: ''
        };
        this.prefill.fetchAllDataEnquiry(id).subscribe(function (res) {
            _this.fullEnquiryDetails.emit(res);
            _this.rowData.dob = res.dob;
            _this.rowData.parent_name = res.parent_name;
            _this.rowData.parent_email = res.parent_email;
            _this.rowData.parent_phone = res.parent_phone;
            _this.updateFormData.followUpDate = res.followUpDate;
            _this.cd.markForCheck();
            _this.updateFormData.assigned_to = res.assigned_to;
            _this.updateFormData.walkin_followUpDate = res.walkin_followUpDate;
            if (res.followUpTime != '' && res.followUpTime != null) {
                _this.followUpTime = _this.breakTimeInToHrAndMin(res.followUpTime);
            }
            if (res.walkin_followUpTime != '' && res.walkin_followUpTime != null) {
                _this.walkin_followUpTime = _this.breakTimeInToHrAndMin(res.walkin_followUpTime);
            }
            _this.updateFormComments = res.comments;
            _this.updateFormCommentsOn = res.commentedOn;
            _this.updateFormCommentsBy = res.commentedBy;
            if (res.followUpDate != "" && res.followUpDate != null && res.followUpTime != "" && res.followUpTime != null) {
                if (res.is_follow_up_time_notification == 1) {
                    _this.notifyme = true;
                }
                else {
                    _this.notifyme = false;
                }
            }
            else {
                _this.notifyme = false;
            }
            _this.getSourceName(res.source_id);
            if (!_this.isLangInstitute) {
                _this.courseIdArray = _this.getCourseArrayList(res);
                _this.rowData.master_course_name = res.master_course_name;
            }
            else if (_this.isLangInstitute) {
                _this.proMc = _this.getMasterCoursePro(res);
                _this.prefill.getEnqSubjects(res.standard_id).subscribe(function (sub) {
                    _this.subjectArr = sub;
                    _this.proC = _this.getCoursePro(res);
                });
            }
            _this.updateFormData.status = res.status;
            _this.updateFormData.closing_reason_id = res.closing_reason_id;
            _this.updateFormData.follow_type = res.follow_type;
        });
    };
    EnquirySidebarComponent.prototype.getMasterCoursePro = function (res) {
        var temp = "";
        this.standardArr.forEach(function (s) {
            if (s.standard_id == res.standard_id) {
                temp = s.standard_name;
            }
        });
        return temp;
    };
    EnquirySidebarComponent.prototype.getCoursePro = function (res) {
        var _this = this;
        var temp = [];
        res.subjectIdArray.forEach(function (ss) {
            _this.subjectArr.forEach(function (su) {
                if (ss == su.subject_id) {
                    temp.push(su.subject_name);
                }
            });
        });
        return temp.join(",");
    };
    EnquirySidebarComponent.prototype.getCourseArrayList = function (res) {
        var courseArr = res.courseIdArray;
        var temp = [];
        /* finding course name */
        this.masterCourseData.forEach(function (e) {
            if (e.master_course == res.master_course_name) {
                courseArr.forEach(function (ca) {
                    e.coursesList.forEach(function (c) {
                        if (c.course_id == ca) {
                            temp.push(c.course_name);
                        }
                    });
                });
            }
        });
        return temp.join(" , ");
    };
    EnquirySidebarComponent.prototype.getPriority = function (id) {
        var temp = "";
        this.priorityArr.forEach(function (el) {
            if (el.data_key === id) {
                temp = el.data_value;
            }
        });
        return temp;
    };
    EnquirySidebarComponent.prototype.getStatus = function (id) {
        var temp = "";
        this.statusArr.forEach(function (el) {
            if (el.data_key === id) {
                temp = el.data_value;
            }
        });
        return temp;
    };
    EnquirySidebarComponent.prototype.getFollowUp = function (id) {
        var temp = "";
        this.followupArr.forEach(function (el) {
            if (el.data_key === id) {
                temp = el.data_value;
            }
        });
        return temp;
    };
    EnquirySidebarComponent.prototype.getStatusReverse = function (id) {
        var temp = "";
        this.statusArr.forEach(function (el) {
            if (el.data_value === id) {
                temp = el.data_key;
            }
        });
        return temp;
    };
    EnquirySidebarComponent.prototype.getFollowUpReverse = function (id) {
        var temp = "";
        this.followupArr.forEach(function (el) {
            if (el.data_value === id) {
                temp = el.data_key;
            }
        });
        return temp;
    };
    EnquirySidebarComponent.prototype.getPriorityReverse = function (id) {
        var temp = "";
        this.priorityArr.forEach(function (el) {
            if (el.data_value === id) {
                temp = el.data_key;
            }
        });
        return temp;
    };
    EnquirySidebarComponent.prototype.closeSideNav = function () {
        this.cancelUpdate.emit(null);
    };
    EnquirySidebarComponent.prototype.createUpdateForm = function () {
        var check = this.validateWalkinAndFollowUpDateTime();
        if (check) {
            // Closing reason mandatory
            if (this.updateFormData.statusValue == 'Closed') {
                if (this.updateFormData.closing_reason_id == '0' || this.updateFormData.closing_reason_id == '-1') {
                    this.appC.popToast({ type: 'error', title: '', body: 'Please enter the closing reason' });
                    return;
                }
                this.updateFormData.followUpDate = ""; // closed enquiry should not have a follow up date --laxmi
            }
            // Follow Up Type Walkin Manadatory
            if (this.updateFormData.follow_type == 'Walkin') {
                if (this.updateFormData.walkin_followUpDate == "" || this.updateFormData.walkin_followUpDate == null || this.updateFormData.walkin_followUpDate == "Invalid Date") {
                    this.appC.popToast({ type: 'error', title: '', body: 'Please enter walkin date for follow up type walkin' });
                    return;
                }
                else {
                    this.updateFormData.walkin_followUpDate = __WEBPACK_IMPORTED_MODULE_1_moment__(this.updateFormData.walkin_followUpDate).format('YYYY-MM-DD');
                }
                if (this.walkin_followUpTime.hour == "" || this.walkin_followUpTime.minute == "") {
                    this.appC.popToast({ type: 'error', title: '', body: 'Please enter walkin time for follow up type walkin' });
                    return;
                }
                else {
                    var time = this.walkin_followUpTime.hour.split(' ');
                    this.updateFormData.walkin_followUpTime = time[0] + ":" + this.walkin_followUpTime.minute + " " + time[1];
                }
            }
            else {
                if (this.updateFormData.walkin_followUpDate == "" || this.updateFormData.walkin_followUpDate == null || this.updateFormData.walkin_followUpDate == "Invalid Date") {
                    this.updateFormData.walkin_followUpDate = "";
                }
                else {
                    this.updateFormData.walkin_followUpDate = __WEBPACK_IMPORTED_MODULE_1_moment__(this.updateFormData.walkin_followUpDate).format('YYYY-MM-DD');
                }
                if (this.walkin_followUpTime.hour == "" || this.walkin_followUpTime.minute == "") {
                    this.updateFormData.walkin_followUpTime = "";
                }
                else {
                    var time = this.walkin_followUpTime.hour.split(' ');
                    this.updateFormData.walkin_followUpTime = time[0] + ":" + this.walkin_followUpTime.minute + " " + time[1];
                }
            }
            this.updateFormData.comment = this.updateFormData.comment;
            this.updateFormData.priority = this.updateFormData.priority == "" ? "" : this.getPriorityReverse(this.updateFormData.priority);
            this.updateFormData.status = this.updateFormData.statusValue == "" ? "" : this.getStatusReverse(this.updateFormData.statusValue);
            if (this.updateFormData.followUpDate != "" && this.updateFormData.followUpDate != null && this.updateFormData.followUpDate != "Invalid Date") {
                this.updateFormData.followUpDate = __WEBPACK_IMPORTED_MODULE_1_moment__(this.updateFormData.followUpDate).format('YYYY-MM-DD');
            }
            else {
                this.updateFormData.followUpDate = "";
            }
            if (this.followUpTime.hour != "" && this.followUpTime.minute != "" && this.followUpTime.hour != ": ") {
                var time = this.followUpTime.hour.split(' ');
                this.updateFormData.followUpTime = time[0] + ":" + this.followUpTime.minute + " " + time[1];
            }
            else {
                this.updateFormData.followUpTime = "";
            }
            if (this.notifyme) {
                this.updateFormData.is_follow_up_time_notification = 1;
            }
            else {
                this.updateFormData.is_follow_up_time_notification = 0;
            }
            this.pushUpdatedEnquiry(this.updateFormData);
        }
        else {
            return;
        }
    };
    /* Push the updated enquiry to server */
    EnquirySidebarComponent.prototype.pushUpdatedEnquiry = function (obj) {
        this.updateEnq.emit(obj);
        this.updateFormData.comment = "";
        this.updateFormData.priority = this.updateFormData.priority == "" ? "" : this.getPriority(this.updateFormData.priority);
        this.updateFormData.status = this.updateFormData.statusValue == "" ? "" : this.getStatus(this.updateFormData.statusValue);
        this.updateFormData.follow_type = this.updateFormData.follow_type == "" ? "" : this.getFollowUp(this.updateFormData.follow_type);
    };
    EnquirySidebarComponent.prototype.validateWalkinAndFollowUpDateTime = function () {
        var check = false;
        if (this.validatefollowuptime()) {
            check = true;
        }
        else {
            return false;
        }
        if (this.validatewalkintime()) {
            check = true;
        }
        else {
            return false;
        }
        return check;
    };
    EnquirySidebarComponent.prototype.getCommentDate = function (upDate) {
        return __WEBPACK_IMPORTED_MODULE_1_moment__(upDate).fromNow();
    };
    EnquirySidebarComponent.prototype.validatefollowuptime = function () {
        if ((this.followUpTime.hour != '' && this.followUpTime.minute != '') || (this.followUpTime.hour == '' && this.followUpTime.minute == '')) {
            return true;
        }
        else {
            var msg = {
                type: 'error',
                title: '',
                body: 'Please select a valid follow up time'
            };
            this.appC.popToast(msg);
            return false;
        }
    };
    EnquirySidebarComponent.prototype.validatewalkintime = function () {
        /* some time selected by user or nothing*/
        if ((this.walkin_followUpTime.hour != '' && this.walkin_followUpTime.minute != '') || (this.walkin_followUpTime.hour == '' && this.walkin_followUpTime.minute == '')) {
            return true;
        }
        else {
            var msg = {
                type: 'error',
                title: '',
                body: 'Please select a valid walkin time'
            };
            this.appC.popToast(msg);
            return false;
        }
    };
    EnquirySidebarComponent.prototype.toggleAccordian = function (id) {
        if (id === 'one') {
            this.one.nativeElement.classList.toggle('liclosed');
            this.two.nativeElement.classList.add('liclosed');
            this.three.nativeElement.classList.add('liclosed');
            this.four.nativeElement.classList.add('liclosed');
        }
        else if (id === 'two') {
            this.two.nativeElement.classList.toggle('liclosed');
            this.one.nativeElement.classList.add('liclosed');
            this.three.nativeElement.classList.add('liclosed');
            this.four.nativeElement.classList.add('liclosed');
        }
        else if (id === 'three') {
            this.three.nativeElement.classList.toggle('liclosed');
            this.two.nativeElement.classList.add('liclosed');
            this.one.nativeElement.classList.add('liclosed');
            this.four.nativeElement.classList.add('liclosed');
        }
        else if (id === 'four') {
            this.four.nativeElement.classList.toggle('liclosed');
            this.two.nativeElement.classList.add('liclosed');
            this.three.nativeElement.classList.add('liclosed');
            this.one.nativeElement.classList.add('liclosed');
        }
    };
    EnquirySidebarComponent.prototype.notifyMe = function (e) {
        if (e) {
            this.updateFormData.is_follow_up_time_notification = 1;
        }
        else {
            this.updateFormData.is_follow_up_time_notification = 0;
        }
    };
    EnquirySidebarComponent.prototype.isEnquiryAdministrator = function () {
        if (sessionStorage.getItem('permissions') == null || sessionStorage.getItem('permissions') == undefined
            || sessionStorage.getItem('permissions') == '' || sessionStorage.getItem('username') == 'admin') {
            this.isEnquiryAdmin = true;
        }
        else {
            var permissions = [];
            permissions = JSON.parse(sessionStorage.getItem('permissions'));
            /* User has permission to view all enquiries */
            if (permissions.includes('115')) {
                this.isEnquiryAdmin = true;
            }
            else {
                this.isEnquiryAdmin = false;
            }
        }
    };
    // get source name
    EnquirySidebarComponent.prototype.getSourceName = function (data) {
        for (var i = 0; i < this.sourceList.length; i++) {
            if (this.sourceList[i].id == data) {
                this.sourceName = this.sourceList[i].name;
                break;
            }
        }
    };
    EnquirySidebarComponent.prototype.checkInstituteType = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isLangInstitute = true;
            }
            else {
                _this.isLangInstitute = false;
            }
        });
    };
    EnquirySidebarComponent.prototype.isNotifyDisplayed = function () {
        this.cd.markForCheck();
        if (this.updateFormData.followUpDate != '' && this.updateFormData.followUpDate != null && this.updateFormData.followUpDate != "Invalid date") {
            if (this.followUpTime.hour != '' || this.followUpTime.minute != '') {
                this.cd.markForCheck();
                this.isNotifyVisible = true;
            }
            else {
                this.cd.markForCheck();
                this.isNotifyVisible = false;
            }
        }
        else {
            this.cd.markForCheck();
            this.isNotifyVisible = false;
        }
    };
    EnquirySidebarComponent.prototype.changeAssignList = function (event) {
        this.getUserList.emit(event);
    };
    // On Enquiry Take It Click//
    EnquirySidebarComponent.prototype.onEnquiryTakeIt = function () {
        this.updateFormData.statusValue = "In Progress";
        this.updateFormData.assigned_to = sessionStorage.getItem('userid');
        this.createUpdateForm();
    };
    EnquirySidebarComponent.prototype.breakTimeInToHrAndMin = function (time) {
        var obj = {
            hour: '',
            minute: ''
        };
        obj.hour = time.split(':')[0] + " " + time.split(':')[1].split(' ')[1];
        obj.minute = time.split(':')[1].split(' ')[0];
        return obj;
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], EnquirySidebarComponent.prototype, "enquiryRow", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], EnquirySidebarComponent.prototype, "priorityArr", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], EnquirySidebarComponent.prototype, "enqAssignTo", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], EnquirySidebarComponent.prototype, "statusArr", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], EnquirySidebarComponent.prototype, "followupArr", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], EnquirySidebarComponent.prototype, "row", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], EnquirySidebarComponent.prototype, "customComp", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], EnquirySidebarComponent.prototype, "sourceList", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], EnquirySidebarComponent.prototype, "mainBranchAdmin", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], EnquirySidebarComponent.prototype, "subBranchAdmin", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], EnquirySidebarComponent.prototype, "branchesList", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], EnquirySidebarComponent.prototype, "masterCourseData", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], EnquirySidebarComponent.prototype, "standardArr", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], EnquirySidebarComponent.prototype, "subjectArr", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], EnquirySidebarComponent.prototype, "closingReasonDataSource", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], EnquirySidebarComponent.prototype, "updateEnq", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], EnquirySidebarComponent.prototype, "cancelUpdate", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], EnquirySidebarComponent.prototype, "getUserList", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], EnquirySidebarComponent.prototype, "fullEnquiryDetails", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('acc'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], EnquirySidebarComponent.prototype, "acc", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('one'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], EnquirySidebarComponent.prototype, "one", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('two'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], EnquirySidebarComponent.prototype, "two", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('three'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], EnquirySidebarComponent.prototype, "three", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('four'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], EnquirySidebarComponent.prototype, "four", void 0);
    EnquirySidebarComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'enquiry-sidebar',
            template: __webpack_require__("./src/app/components/leads/enquiry/enquiry-home/enquiry-sidebar/enquiry-sidebar.component.html"),
            styles: [__webpack_require__("./src/app/components/leads/enquiry/enquiry-home/enquiry-sidebar/enquiry-sidebar.component.scss")],
            changeDetection: __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectionStrategy"].OnPush
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_fetchprefilldata_service__["a" /* FetchprefilldataService */], __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"], __WEBPACK_IMPORTED_MODULE_3__app_component__["a" /* AppComponent */], __WEBPACK_IMPORTED_MODULE_4__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], EnquirySidebarComponent);
    return EnquirySidebarComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-home/sms-option.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SmsOptionComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_enquiry_services_popup_handler_service__ = __webpack_require__("./src/app/services/enquiry-services/popup-handler.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var SmsOptionComponent = /** @class */ (function () {
    function SmsOptionComponent(router, pops, cd) {
        var _this = this;
        this.router = router;
        this.pops = pops;
        this.cd = cd;
        // <div class="sms-options" (copyEvent)="enquiryManager.copySMS()">
        this.sms = "";
        this.pops.currentMessage.subscribe(function (data) { return _this.sms = data; });
    }
    /* OnInit function to listen the changes in message value from service */
    SmsOptionComponent.prototype.ngOnInit = function () {
        this.cd.markForCheck();
    };
    SmsOptionComponent.prototype.emitEdit = function () {
        this.pops.changeSmsMessage('edit');
        this.cd.markForCheck();
    };
    SmsOptionComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'enquiry-sms-action',
            template: 
            /* HTML content for the rendered component with CSS style as well */
            "\n  <style>\n    .sms-option-list{\n        list-style: none;\n    }\n    .sms-option-list li{\n        display:inline;\n    }\n    .cursor{\n        cursor:pointer;\n    }\n  </style>\n\n  <div class=\"sms-options\" >\n    <ul class=\"sms-option-list\">\n    <li class=\"cursor\"><a class=\"cursor\" (click)=\"emitEdit()\">Edit</a></li>\n    </ul>\n  </div>\n    ",
            changeDetection: __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectionStrategy"].OnPush
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"], __WEBPACK_IMPORTED_MODULE_2__services_enquiry_services_popup_handler_service__["a" /* PopupHandlerService */], __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"]])
    ], SmsOptionComponent);
    return SmsOptionComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-pop-up/enquiry-pop-up.component.html":
/***/ (function(module, exports) {

module.exports = "<section id=\"popup\" class=\"popupWrapper fadeIn\">\r\n  <div class=\"popup pos-abs\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <!-- Project content for close button here -->\r\n      <ng-content select=\"[close-button]\"></ng-content>\r\n      <div class=\"popup-content\">\r\n        <!-- project content for header here -->\r\n        <ng-content select=\"[popup-header]\"></ng-content>\r\n\r\n        <div class=\"update-enquiry-form overflowHidden\">\r\n\r\n          <!-- project content for popup here -->\r\n          <ng-content select=\"[popup-content]\"></ng-content>\r\n\r\n          <!-- project footer for popup here -->\r\n          <ng-content select=\"[popup-footer]\"></ng-content>\r\n\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-pop-up/enquiry-pop-up.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.table-data-overflow table tbody td {\n  max-width: 100px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap; }\n.middle-section {\n  padding: 15px; }\n.boxPadding15, .middle-left, .middle-right {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 0 15px; }\n.middle-left {\n  width: 70%; }\n.middle-right {\n  width: 30%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 0 15px; }\n.accordian-section {\n  padding: 15px 10px 0; }\n.accordian-section .accordian-heading h4 {\n    font-size: 14px;\n    font-weight: 600;\n    color: #ddd; }\n.accordian-section .accordian-heading h4 .open-accor {\n      display: none;\n      float: right;\n      width: 24px;\n      font-size: 24px;\n      height: 24px;\n      text-align: center;\n      border: none;\n      border-radius: 50%;\n      line-height: 24px;\n      margin-right: 4px;\n      margin-top: 3px;\n      cursor: pointer;\n      color: #0084f6; }\n.accordian-section .accordian-heading h4 .close-accor {\n      float: right;\n      width: 24px;\n      font-size: 31px;\n      height: 24px;\n      text-align: center;\n      border: none;\n      border-radius: 50%;\n      line-height: 16px;\n      margin-right: 4px;\n      margin-top: 5px;\n      cursor: pointer;\n      color: #0084f6;\n      font-weight: 400; }\n.accordian-section .accordian-content {\n    padding-left: 50px; }\n.accordian-section .accordian > li {\n    position: relative;\n    padding-bottom: 25px; }\n.accordian-section .accordian > li:before {\n      content: '';\n      width: 1px;\n      height: 90.5%;\n      position: absolute;\n      background: #cccccc;\n      z-index: 0;\n      left: 15px;\n      top: 34px;\n      display: block; }\n.accordian-section .accordian > li:last-child:before {\n      display: none; }\n.accordian-section .accordian > li.active .circle-accor, .accordian-section .accordian > li.data-filled .circle-accor {\n      background: #0084f6;\n      color: #fff;\n      border-color: #0084f6; }\n.accordian-section .accordian > li.active .accordian-heading h4, .accordian-section .accordian > li.data-filled .accordian-heading h4 {\n      color: #333; }\n.accordian-section .accordian > li.data-filled .accordian-content {\n      display: none; }\n.accordian-section .accordian > li.data-filled .accordian-heading h4 {\n      color: #444;\n      border: 1px solid #eaecee;\n      padding: 1px;\n      border-radius: 20px;\n      background: #e6f2fe; }\n.accordian-section .accordian > li.data-filled .accordian-heading h4 .open-accor {\n        display: block; }\n.accordian-section .accordian > li.data-filled .accordian-heading h4 .close-accor {\n        display: none; }\n.accordian-section .accordian > li.data-filled.active .accordian-content {\n      display: block; }\n.accordian-section .accordian > li.data-filled.active .accordian-heading h4 .open-accor {\n      display: none; }\n.accordian-section .accordian > li.data-filled.active .accordian-heading h4 .close-accor {\n      display: block; }\n.more-detail {\n  margin-top: 10px;\n  font-size: 12px; }\n.circle-accor {\n  display: inline-block;\n  width: 32px;\n  border-radius: 50%;\n  text-align: center;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding-top: 4px;\n  font-size: 14px;\n  background: #f0f0f0;\n  height: 32px;\n  border: 1px solid #bbb;\n  margin-right: 5px;\n  color: #ceced1;\n  padding: 0;\n  line-height: 30px; }\n.form-type2,\n.form-type1 {\n  max-width: 360px; }\n.paddingR30 {\n  padding-right: 30px; }\n.form-type2 .field-wrapper {\n  padding-right: 35px; }\n.form-type2 .customSelectWrapper:after {\n  right: 35px; }\n.questionInfo {\n  position: absolute;\n  right: 0px;\n  bottom: 5px;\n  height: 20px;\n  width: 20px;\n  z-index: 2; }\n.questionInfo .qInfoIcon {\n    width: 20px;\n    height: 20px;\n    border: 1px solid #ccc;\n    border-radius: 50%;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    line-height: 20px;\n    font-weight: 600;\n    font-size: 12px;\n    cursor: pointer;\n    -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n            box-shadow: 0px 0px 1px 0px #ccc inset;\n    color: #888;\n    -webkit-transition: all 0.6s linear;\n    transition: all 0.6s linear; }\n.questionInfo .qInfoIcon:hover {\n      border-color: #0060A3;\n      -webkit-box-shadow: 0px 0px 1px 0px #0060A3 inset;\n              box-shadow: 0px 0px 1px 0px #0060A3 inset;\n      color: #0060A3; }\n.create-institution {\n  position: absolute;\n  right: -98px;\n  white-space: nowrap;\n  bottom: 6px;\n  font-size: 12px;\n  font-weight: 600; }\n.shadow-box {\n  -webkit-box-shadow: 0px 2px 2px #7d7d7d;\n          box-shadow: 0px 2px 2px #7d7d7d;\n  padding: 7px;\n  border-radius: 2px;\n  background: #eff7ff; }\n.last-added-info {\n  font-size: 12px; }\n.last-added-info ul li {\n    line-height: normal;\n    padding: 2px 0;\n    display: inline-block;\n    width: 100%;\n    vertical-align: top; }\n.last-added-info strong {\n    font-weight: 600;\n    color: #28384a; }\n.last-added-info .view-details {\n    float: right;\n    font-size: 11px; }\n.last-added-info .view-details a:hover {\n      text-decoration: underline; }\n.last-added-info .enquiry-time {\n    float: right;\n    font-size: 10px;\n    color: #28384a;\n    margin-top: 4px; }\n/*=======================Right bottom lite shadow box======================*/\n.box-shadow-lite {\n  -webkit-box-shadow: 0px 1px 2px 0px #ccc;\n          box-shadow: 0px 1px 2px 0px #ccc;\n  padding: 10px 0 10px 10px;\n  border-top: 1px solid #e8e8e8; }\n.box-shadow-lite .field-wrapper {\n    padding-right: 40px; }\n.box-shadow-lite .field-wrapper .open-accor {\n      width: 17px;\n      font-size: 17px;\n      height: 17px;\n      line-height: 18px;\n      position: absolute;\n      right: 4px;\n      top: 19px;\n      z-index: 2; }\n.box-shadow-lite .field-wrapper:first-child {\n      margin-top: -10px; }\n.common-right-section {\n  margin-top: 30px; }\n.common-right-section h4 {\n    margin-bottom: 7px;\n    color: #28383A;\n    font-size: 16px; }\n.common-right-section h4 strong {\n      font-weight: 600; }\n.common-right-section .clear-detail {\n    margin-top: 10px;\n    font-size: 12px;\n    margin-bottom: 10px; }\n.follow-up-date-icon {\n  position: absolute;\n  position: absolute;\n  right: 7px;\n  top: 20px;\n  cursor: pointer; }\n.follow-up-date-icon img {\n    width: 21px; }\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 850px;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 22px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n/*=========================================registration popup form css==================*/\n.registration-fee-form {\n  overflow: hidden; }\n.print-output-section {\n  margin: 35px 0 25px;\n  border-top: 1px solid #deeaee;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  border-bottom: 1px solid #deeaee;\n  text-align: center;\n  font-size: 0; }\n.print-output-section li {\n    display: inline-block;\n    padding: 0 15px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    width: 25%;\n    border-right: 1px solid #deeaee;\n    font-size: 15px;\n    cursor: pointer;\n    color: #929292; }\n.print-output-section li:last-child {\n      border-right: 0; }\n.print-output-section li:hover {\n      color: #0084f6; }\n.print-output-section li svg {\n      width: 30px;\n      display: inline-block;\n      vertical-align: middle;\n      margin-right: 8px; }\n.print-output-section li svg .cls-1 {\n        stroke: none;\n        stroke: #929292; }\n.print-output-section li.svg-icon .cls-1 {\n      stroke: none; }\n.print-output-section li.svg-icon .cls-2 {\n      stroke: #929292; }\n.print-output-section li.svg-icon:hover .cls-2 {\n      stroke: #0084f6; }\n.print-output-section li:first-child:hover svg .cls-1 {\n      stroke: #0084f6; }\n/*=======================================confirmation =========================*/\n.confirmation-popup-content {\n  line-height: normal; }\n.confirmation-popup-content > div {\n    margin-bottom: 10px; }\n.confirmation-popup-content > div:first-child {\n      margin-bottom: 20px; }\n.confirmation-popup-content > div a,\n    .confirmation-popup-content > div p {\n      font-size: 16px;\n      line-height: 22px; }\n.confirmation-popup-content > div a {\n      font-weight: 600; }\n.confirmation-popup-content > div a:hover {\n      text-decoration: underline; }\n.confirmation-popup-content strong {\n    font-weight: 600; }\n.confirmation-popup-content .add-form-btns a {\n    margin-left: 20px;\n    font-size: 14px; }\n.popup-btn {\n  margin-top: 20px; }\n.popup-btn .btn {\n    font-size: 16px;\n    height: 40px;\n    /* color: #333; */ }\n.popup-btn .btn.redBtn {\n      color: #fff;\n      min-width: 160px; }\n.update-enquiry-form table th {\n  text-align: left;\n  padding: 10px;\n  font-size: 14px; }\n.update-enquiry-form table td {\n  text-align: left;\n  padding: 10px;\n  font-size: 14px; }\n.enquiry-update-history {\n  max-height: 110px;\n  overflow: auto; }\n.update-enquiry-form .row {\n  margin: 10px -15px 20px; }\n.confirmation-popup-content:after {\n  content: '';\n  height: 8px;\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  width: 100%;\n  background: #8bc34a; }\n.row.extraMargin {\n  margin: 10px -15px 20px; }\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-pop-up/enquiry-pop-up.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EnquiryPopUpComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var EnquiryPopUpComponent = /** @class */ (function () {
    function EnquiryPopUpComponent() {
    }
    EnquiryPopUpComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'enquiry-pop-up',
            template: __webpack_require__("./src/app/components/leads/enquiry/enquiry-pop-up/enquiry-pop-up.component.html"),
            styles: [__webpack_require__("./src/app/components/leads/enquiry/enquiry-pop-up/enquiry-pop-up.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], EnquiryPopUpComponent);
    return EnquiryPopUpComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EnquiryRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__enquiry_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__enquiry_bulkadd_enquiry_bulkadd_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry-bulkadd/enquiry-bulkadd.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__enquiry_edit_enquiry_edit_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry-edit/enquiry-edit.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__enquiry_home_enquiry_home_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry-home/enquiry-home.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var EnquiryRoutingModule = /** @class */ (function () {
    function EnquiryRoutingModule() {
    }
    EnquiryRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__enquiry_component__["a" /* EnquiryComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                component: __WEBPACK_IMPORTED_MODULE_5__enquiry_home_enquiry_home_component__["a" /* EnquiryHomeComponent */]
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_5__enquiry_home_enquiry_home_component__["a" /* EnquiryHomeComponent */]
                            },
                            {
                                path: 'edit/:id',
                                component: __WEBPACK_IMPORTED_MODULE_4__enquiry_edit_enquiry_edit_component__["a" /* EnquiryEditComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'upload',
                                component: __WEBPACK_IMPORTED_MODULE_3__enquiry_bulkadd_enquiry_bulkadd_component__["a" /* EnquiryBulkaddComponent */],
                                pathMatch: 'prefix'
                            }
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], EnquiryRoutingModule);
    return EnquiryRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry.component.css":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EnquiryComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var EnquiryComponent = /** @class */ (function () {
    function EnquiryComponent() {
    }
    /* OnInit recheck the status of li tab and set it to active here */
    EnquiryComponent.prototype.ngOnInit = function () {
        var array = ['litwo', 'lithree', 'lifour', 'lifive', 'lisix', 'liseven', 'lieight', 'linine', 'lizero'];
        if (document.getElementById('lione')) {
            document.getElementById('lione').classList.add('active');
        }
        array.forEach(function (id) {
            if (document.getElementById(id)) {
                document.getElementById(id).classList.remove('active');
            }
        });
    };
    EnquiryComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-enquiry',
            template: __webpack_require__("./src/app/components/leads/enquiry/enquiry.component.html"),
            styles: [__webpack_require__("./src/app/components/leads/enquiry/enquiry.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], EnquiryComponent);
    return EnquiryComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry/enquiry.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EnquiryModule", function() { return EnquiryModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__enquiry_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__enquiry_bulkadd_enquiry_bulkadd_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry-bulkadd/enquiry-bulkadd.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__enquiry_routing_module__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__enquiry_home_action_button_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry-home/action-button.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__enquiry_home_comment_tooltip_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry-home/comment-tooltip.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__enquiry_home_sms_option_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry-home/sms-option.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__enquiry_edit_enquiry_edit_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry-edit/enquiry-edit.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__enquiry_pop_up_enquiry_pop_up_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry-pop-up/enquiry-pop-up.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__enquiry_home_enquiry_sidebar_enquiry_sidebar_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry-home/enquiry-sidebar/enquiry-sidebar.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__enquiry_home_enquiry_home_component__ = __webpack_require__("./src/app/components/leads/enquiry/enquiry-home/enquiry-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14_ngx_bootstrap_custome_timepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/timepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15_primeng_primeng__ = __webpack_require__("./node_modules/primeng/primeng.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15_primeng_primeng___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_15_primeng_primeng__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__services_enquiry_services_popup_handler_service__ = __webpack_require__("./src/app/services/enquiry-services/popup-handler.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_18__services_closing_reason_service__ = __webpack_require__("./src/app/components/leads/services/closing-reason.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_19__leads_module__ = __webpack_require__("./src/app/components/leads/leads.module.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












/* Modules */








var EnquiryModule = /** @class */ (function () {
    function EnquiryModule() {
    }
    EnquiryModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_12__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_12__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_4__enquiry_routing_module__["a" /* EnquiryRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_13_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_14_ngx_bootstrap_custome_timepicker__["a" /* TimepickerModule */],
                __WEBPACK_IMPORTED_MODULE_15_primeng_primeng__["FileUploadModule"],
                __WEBPACK_IMPORTED_MODULE_15_primeng_primeng__["SplitButtonModule"],
                __WEBPACK_IMPORTED_MODULE_15_primeng_primeng__["MenuModule"],
                __WEBPACK_IMPORTED_MODULE_16__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_19__leads_module__["LeadsModule"]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_2__enquiry_component__["a" /* EnquiryComponent */],
                __WEBPACK_IMPORTED_MODULE_3__enquiry_bulkadd_enquiry_bulkadd_component__["a" /* EnquiryBulkaddComponent */],
                __WEBPACK_IMPORTED_MODULE_5__enquiry_home_action_button_component__["a" /* ActionButtonComponent */],
                __WEBPACK_IMPORTED_MODULE_7__enquiry_home_sms_option_component__["a" /* SmsOptionComponent */],
                __WEBPACK_IMPORTED_MODULE_8__enquiry_edit_enquiry_edit_component__["a" /* EnquiryEditComponent */],
                __WEBPACK_IMPORTED_MODULE_9__enquiry_pop_up_enquiry_pop_up_component__["a" /* EnquiryPopUpComponent */],
                __WEBPACK_IMPORTED_MODULE_11__enquiry_home_enquiry_home_component__["a" /* EnquiryHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_6__enquiry_home_comment_tooltip_component__["a" /* CommentTooltipComponent */],
                __WEBPACK_IMPORTED_MODULE_10__enquiry_home_enquiry_sidebar_enquiry_sidebar_component__["a" /* EnquirySidebarComponent */]
            ],
            entryComponents: [
                __WEBPACK_IMPORTED_MODULE_5__enquiry_home_action_button_component__["a" /* ActionButtonComponent */],
                __WEBPACK_IMPORTED_MODULE_7__enquiry_home_sms_option_component__["a" /* SmsOptionComponent */],
                __WEBPACK_IMPORTED_MODULE_6__enquiry_home_comment_tooltip_component__["a" /* CommentTooltipComponent */],
                __WEBPACK_IMPORTED_MODULE_10__enquiry_home_enquiry_sidebar_enquiry_sidebar_component__["a" /* EnquirySidebarComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_17__services_enquiry_services_popup_handler_service__["a" /* PopupHandlerService */],
                __WEBPACK_IMPORTED_MODULE_18__services_closing_reason_service__["a" /* ClosingReasonService */]
            ],
            exports: [__WEBPACK_IMPORTED_MODULE_11__enquiry_home_enquiry_home_component__["a" /* EnquiryHomeComponent */]]
        })
    ], EnquiryModule);
    return EnquiryModule;
}());



/***/ })

});
//# sourceMappingURL=enquiry.module.chunk.js.map