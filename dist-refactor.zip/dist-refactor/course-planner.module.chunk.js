webpackJsonp(["course-planner.module"],{

/***/ "./src/app/components/course-module/course-planner/class/class.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<div class=\"middle-section clear-fix\">\r\n  <section class=\"middle-top clearFix bulk-header\">\r\n\r\n    <div>\r\n      <h1 class=\"pull-left\">\r\n        <a routerLink=\"/view/course\"  *ngIf=\"!jsonFlag.isProfessional\" style=\"padding:0px; \">\r\n          Course\r\n        </a>\r\n        <a routerLink=\"/view/batch\" *ngIf=\"jsonFlag.isProfessional\" style=\"padding:0px; \">\r\n          Batch\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n         <span>Class Planner</span>\r\n      </h1>\r\n    </div>\r\n\r\n  </section>\r\n\r\n  <section>\r\n    <div class=\"header-section\">\r\n      <div class=\"header-item active\" id=\"class\" routerLink=\"/view/course/coursePlanner/class\">\r\n        <div class=\"img-container\">\r\n          <img src=\"./assets/images/course_planner/class_white.svg\" alt=\"class\">\r\n        </div>\r\n        <div class=\"model-name-container\">\r\n          <span>Class</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"header-item non-active\" id=\"exam\" routerLink=\"/view/course/coursePlanner/exam\">\r\n        <div class=\"img-container\">\r\n          <img src=\"./assets/images/course_planner/exam.svg\" alt=\"exam\">\r\n        </div>\r\n        <div class=\"model-name-container\">\r\n          <span>Exam</span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n\r\n\r\n\r\n<!-- All Pop Up  -->\r\n\r\n<!-- Reschedule pop -->\r\n<!-- Modal -->\r\n<div class=\"modal fade\" id=\"rescheduleModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalCenterTitle\" aria-hidden=\"true\" *ngIf=\"isReschedulePop\">\r\n  <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">\r\n    <div class=\"modal-content\">\r\n      <div class=\"modal-header\">\r\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n          <span aria-hidden=\"true\">&times;</span>\r\n        </button>\r\n        <h5 class=\"modal-title\" id=\"exampleModalLongTitle\">{{classMarkedForAction.batch_name}}</h5>\r\n      </div>\r\n      <div class=\"modal-body\">\r\n        <div class=\"row dueDate\" style=\"margin-left: -15px;\">\r\n\r\n          <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n            <div class=\"field-wrapper datePickerBox\" style=\"padding-top:0px\">\r\n              <label for=\"reschDate\">Reschedule Date</label>\r\n              <input type=\"text\" id=\"reschDate\" name=\"reschDate\" readonly=\"true\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"reschedDate\"\r\n                bsDatepicker style=\"height:30px\">\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"c-sm-4 c-md-4 c-lg-4\" style=\"margin-top:-15px;\">\r\n            <div class=\"form-wrapper timepick rescheduleTime\" style=\"padding-left: 15px;\">\r\n              <label for=\"startTime\">Start Time</label>\r\n              <div class=\"tbox\">\r\n                <div class=\"times \">\r\n                  <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"timepicker.reschedStartTime.hour\" name=\"startTime\">\r\n                    <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                      {{time}}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n                <div class=\"times\">\r\n                  <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"timepicker.reschedStartTime.minute\" name=\"minute\">\r\n                    <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                      {{minute}}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"c-sm-4 c-md-4 c-lg-4\" style=\"margin-top:-15px;\">\r\n            <div class=\"form-wrapper timepick rescheduleTime\">\r\n              <label for=\"endtime\">End Time</label>\r\n              <div class=\"tbox\">\r\n                <div class=\"times\">\r\n                  <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"timepicker.reschedEndTime.hour\" name=\"endtime\">\r\n                    <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                      {{time}}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n                <div class=\"times\">\r\n                  <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"timepicker.reschedEndTime.minute\" name=\"minute\">\r\n                    <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                      {{minute}}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n          </div>\r\n\r\n        </div>\r\n\r\n        <div class=\"row\">\r\n          <div class=\"field-wrapper\" style=\"width: 50%; margin-left: 3%;\">\r\n            <textarea type=\"text\" style=\"height:50px;\" id=\"reschreason\" name=\"reschreason\" [(ngModel)]=\"reschedReason\" value=\"\" placeholder=\"Reschedule Reason\"\r\n              class=\"form-ctrl textbox\">\r\n            </textarea>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"modal-footer\">\r\n        <div class=\"clearfix\">\r\n          <aside class=\"pull-left\">\r\n            <div class=\"field-checkbox-wrapper\" style=\"margin-top: 5px\">\r\n              <input type=\"checkbox\" value=\"\" class=\"form-checkbox\" id=\"is_reshedule_notified\" [checked]=\"getCheckedStatus('resheduleNotified')\"\r\n                (change)=\"notifyRescheduleUpdate($event)\">\r\n              <label for=\"is_reshedule_notified\">Notify Students</label>\r\n            </div>\r\n          </aside>\r\n          <aside class=\"pull-right popup-btn\">\r\n            <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closeRescheduleClass()\" data-dismiss=\"modal\">\r\n            <input type=\"button\" value=\"Reschedule Class\" data-dismiss=\"modal\" (click)=\"rescheduleClass()\" class=\"fullBlue btn\" [disabled]=\"isRippleLoad\">\r\n          </aside>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n\r\n<!-- Notify pop -->\r\n<!-- Modal -->\r\n<div class=\"modal fade\" id=\"notifyModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"notifyModalCenterTitle\" aria-hidden=\"true\" *ngIf=\"isReminderPop\">\r\n  <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">\r\n    <div class=\"modal-content\">\r\n      <div class=\"modal-header\">\r\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n          <span aria-hidden=\"true\">&times;</span>\r\n        </button>\r\n        <h5 class=\"modal-title\" id=\"notifyModalCenterTitle\">Send Reminder For\r\n          <span style=\"font-weight: 600;\" *ngIf=\"jsonFlag.isProfessional\">{{classMarkedForAction.batch_name}}</span>\r\n          <span style=\"font-weight: 600;\" *ngIf=\"!jsonFlag.isProfessional\">{{classMarkedForAction.batch_name}}</span>\r\n        </h5>\r\n      </div>\r\n      <div class=\"modal-body\">\r\n        <div class=\"row\" style=\"margin: 10px 0px;\">\r\n          The reminder for the selected schedule will be sent!! click continue to proceed.\r\n        </div>\r\n        <div class=\"add_remarks\">\r\n          <div class=\"\" style=\"margin-left: 38%\">\r\n            <span>Limit</span>\r\n            <span class=\"button_type\">{{remarksLimit}}</span>\r\n          </div>\r\n          <div class=\"field-wrapper\" style=\"width: 50%;\">\r\n            <textarea type=\"text\" style=\"height:50px; border: 1px solid #d3d4d5;\" id=\"reminderRemarks\" name=\"reminderRemarks\" [(ngModel)]=\"reminderRemarks\" value=\"\" placeholder=\"Remarks\"\r\n              class=\"form-ctrl textbox\" maxlength=\"50\" (ngModelChange)=\"countRemarksLimit()\">\r\n            </textarea>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"modal-footer\">\r\n        <aside class=\"pull-right popup-btn\">\r\n          <input type=\"button\" value=\"Cancel\" data-dismiss=\"modal\" class=\"btn\" (click)=\"closeRemiderClass()\">\r\n          <input type=\"button\" value=\"Continue\" data-dismiss=\"modal\" (click)=\"sendReminder()\" class=\"btn fullBlue\" [disabled]=\"isRippleLoad\">\r\n        </aside>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n\r\n<!-- Cancel pop up for Course Model-->\r\n<!-- Modal  -->\r\n<div class=\"modal\" id=\"cancelModal\" role=\"dialog\" aria-labelledby=\"exampleModalCenterTitle\" aria-hidden=\"true\"> <!---*ngIf=\"isCancelPop\"--->\r\n  <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">\r\n    <div class=\"modal-content\">\r\n      <div class=\"modal-header\">\r\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n          <span aria-hidden=\"true\">&times;</span>\r\n        </button>\r\n        <h5 class=\"modal-title\" id=\"exampleModalLongTitle\">Cancel Class\r\n          <span style=\"font-weight: 600;\">{{classMarkedForAction?.batch_name}}</span>\r\n        </h5>\r\n      </div>\r\n      <div class=\"modal-body\">\r\n        <div class=\"CancelWrapper\">\r\n          <div class=\"row cancelField\">\r\n            <div class=\"c-lg-12 c-md-12 c-sm-12\">\r\n              <div class=\"field-wrapper\">\r\n                <textarea class=\"form-ctrl textBox\" style=\"height: 100px;\" placeholder=\"Cancellation Reason:\" value=\"\" [(ngModel)]=\"cancellationReason\">\r\n                </textarea>\r\n              </div>\r\n            </div>\r\n            <div class=\"c-lg-12 c-md-12 c-sm-12\" style=\"margin-top: 20px\">\r\n              <div class=\"field-checkbox-wrapper\">\r\n                <input type=\"checkbox\" value=\"\" class=\"form-checkbox\" id=\"notifyCancel\" [checked]=\"getCheckedStatus('notifyCancel')\" (change)=\"notifyCancelUpdate($event)\">\r\n                <label for=\"notifyCancel\">Notify Students For Class Cancellation</label>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"modal-footer\">\r\n        <aside class=\"pull-right popup-btn\">\r\n          <input type=\"button\" value=\"Cancel\" data-dismiss=\"modal\" class=\"btn\" (click)=\"closeCancelClass()\">\r\n          <input type=\"button\" value=\"Cancel Class\" data-dismiss=\"modal\" (click)=\"cancelClass()\" [disabled]=\"jsonFlag.isRippleLoad\" class=\"btn fullBlue\">\r\n        </aside>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<!-- Cancel pop up for Batch Model-->\r\n<!-- Modal  -->\r\n<div class=\"modal\" id=\"cancelBatchModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalCenterTitle\" aria-hidden=\"true\" *ngIf=\"isCourseCancel\">\r\n  <div class=\"modal-dialog modal-dialog-centered\" role=\"document\">\r\n    <div class=\"modal-content\">\r\n      <div class=\"modal-header\">\r\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n          <span aria-hidden=\"true\">&times;</span>\r\n        </button>\r\n        <h5 class=\"modal-title\" id=\"exampleModalLongTitle\">Cancel Schedule\r\n          <span style=\"font-weight: 600;\">{{classMarkedForAction.batch_name}}</span>\r\n          <span style=\"font-weight: 600;\" *ngIf=\"!jsonFlag.isProfessional\">{{classMarkedForAction.master_course}} &#8594; {{classMarkedForAction.coursee_names}} </span>\r\n          <span style=\"font-weight: 600;\" *ngIf=\"jsonFlag.isProfessional\">{{classMarkedForAction.batch_name}}</span>\r\n        </h5>\r\n      </div>\r\n      <div class=\"modal-body\">\r\n        <div class=\"CancelWrapper\">\r\n          <div class=\"row cancelField\">\r\n            <div class=\"c-lg-12 c-md-12 c-sm-12\">\r\n              <div class=\"field-wrapper\">\r\n                <textarea class=\"form-ctrl textBox\" style=\"height: 100px;\" placeholder=\"Cancellation Reason:\" value=\"\" [(ngModel)]=\"cancellationReason\">\r\n                </textarea>\r\n              </div>\r\n            </div>\r\n            <div class=\"c-lg-12 c-md-12 c-sm-12\" style=\"margin-top: 20px\">\r\n              <div class=\"field-checkbox-wrapper\">\r\n                <input type=\"checkbox\" value=\"\" class=\"form-checkbox\" id=\"notifyCancel\" [checked]=\"getCheckedStatus('notifyCancel')\" (change)=\"notifyCancelUpdate($event)\">\r\n                <label for=\"notifyCancel\">Notify Students For Class Cancellation</label>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"modal-footer\">\r\n        <aside class=\"pull-right popup-btn\">\r\n          <input type=\"button\" value=\"Cancel\" data-dismiss=\"modal\" class=\"btn\" (click)=\"closeCourseCancelClass()\">\r\n          <input *ngIf=\"!jsonFlag.isProfessional\" data-dismiss=\"modal\" type=\"button\" value=\"Update Schedule\" (click)=\"cancelCourseClass()\" class=\"fullBlue btn\" [disabled]=\"jsonFlag.isRippleLoad\">\r\n          <input *ngIf=\"jsonFlag.isProfessional\" data-dismiss=\"modal\" type=\"button\" value=\"Cancel Class\" (click)=\"cancelBatchClass()\" class=\"fullBlue btn\" [disabled]=\"jsonFlag.isRippleLoad\">\r\n        </aside>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n\r\n<!-- Main section started -->\r\n<section>\r\n\r\n  <section class=\"filter-head\">\r\n    <div class=\"filter-header-container\">\r\n      <div class=\"filter-item-1\">\r\n        <!-- FOR COURSE MODEL -->\r\n        <div class=\"header-item\" *ngIf=\"!jsonFlag.isProfessional\">\r\n          <span>Master Course <span class=\"danger\">*</span></span>\r\n          <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.masterCourse\" (ngModelChange)=\"updateCoursesList()\">\r\n            <option value=\"-1\">Select Master Course</option>\r\n            <option [value]=\"masterCourse.master_course\" *ngFor=\"let masterCourse of masterCourseList\">{{masterCourse.master_course}}</option>\r\n          </select>\r\n        </div>\r\n        <div class=\"header-item\" *ngIf=\"!jsonFlag.isProfessional\">\r\n          <span>Course</span>\r\n          <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.course\" (ngModelChange)=\"updateSubjectsList()\">\r\n            <option value=\"-1\">Select Course</option>\r\n            <option [value]=\"course.course_id\" *ngFor=\"let course of courseList\">{{course.course_name}}</option>\r\n          </select>\r\n          <span *ngIf=\"inputElements.course != '-1' && !jsonFlag.isProfessional\" style=\"font-size: 10px;\">Duration: {{courseStartDate}} {{courseEndDate}}</span>\r\n        </div>\r\n        <div class=\"header-item\" *ngIf=\"!jsonFlag.isProfessional\">\r\n          <span>Subject</span>\r\n          <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.subject\" (ngModelChange)=\"updateSubject()\">\r\n            <option value=\"-1\">Select Subject</option>\r\n            <option [value]=\"subject.batch_id\" *ngFor=\"let subject of subjectList\">{{subject.subject_name}}</option>\r\n          </select>\r\n        </div>\r\n\r\n        <!-- FOR BATCH MODEL -->\r\n        <div class=\"header-item\" *ngIf=\"jsonFlag.isProfessional\">\r\n          <span>Master Course <span class=\"danger\">*</span></span>\r\n          <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.standard_id\" (ngModelChange)=\"updateCoursesList()\">\r\n            <option value=\"-1\">Select Master Course</option>\r\n            <option [value]=\"standard.standard_id\" *ngFor=\"let standard of masterCourseList\">{{standard.standard_name}}</option>\r\n          </select>\r\n          <span *ngIf=\"inputElements.standard_id != '-1' && jsonFlag.isProfessional\" style=\"font-size: 10px;\">Duration: {{courseStartDate}} {{courseEndDate}}</span>\r\n        </div>\r\n        <div class=\"header-item\" *ngIf=\"jsonFlag.isProfessional\">\r\n          <span>Course</span>\r\n          <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.subject_id\" (ngModelChange)=\"updateSubjectsList()\">\r\n            <option value=\"-1\">Select Course</option>\r\n            <option [value]=\"subject.subject_id\" *ngFor=\"let subject of courseList\">{{subject.subject_name}}</option>\r\n          </select>\r\n        </div>\r\n        <div class=\"header-item\" *ngIf=\"jsonFlag.isProfessional\">\r\n          <span>Batch</span>\r\n          <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.batch_id\" (ngModelChange)=\"updateSubject()\">\r\n            <option value=\"-1\">Select Batch</option>\r\n            <option [value]=\"batch.batch_id\" *ngFor=\"let batch of batchList\">{{batch.batch_name}}</option>\r\n          </select>\r\n        </div>\r\n\r\n        <div class=\"header-item\" style=\"width: 25%;\">\r\n          <span>Filter</span>\r\n          <div class=\"input-container\">\r\n            <i class=\"fa fa-filter\" aria-hidden=\"true\"></i>\r\n            <input type=\"text\" name=\"\" value=\"\" class=\"filer-input\" placeholder=\"Choose filter from dropdown\">\r\n            <i class=\"fa fa-caret-down\" aria-hidden=\"true\" (click)=\"toggleFilter()\" *ngIf=\"!filterShow\"></i>\r\n            <i class=\"fa fa-caret-up\" aria-hidden=\"true\" (click)=\"toggleFilter()\" *ngIf=\"filterShow\"></i>\r\n          </div>\r\n          <span style=\"font-size: 10px;\">From: {{coursePlannerFilters.from_date | date: 'dd-MMM-yyyy'}} &nbsp; To: {{coursePlannerFilters.to_date | date: 'dd-MMM-yyyy'}}</span>\r\n          <div class=\"filter-container\" *ngIf=\"filterShow\">\r\n\r\n            <div class=\"date-container\">\r\n              <div class=\"date-title\">\r\n                <span>Date</span>\r\n              </div>\r\n              <div class=\"date-values-container\">\r\n                <div class=\"field-checkbox-wrapper date-value-item\">\r\n                  <input type=\"checkbox\" id=\"thisWeek\" name=\"thisWeek\" [(ngModel)]=\"filterDateInputs.thisWeek\"\r\n                      class=\"form-checkbox\" (change)=\"updateDateFilter('thisWeek', $event)\">\r\n                  <label for=\"thisWeek\">This Week</label>\r\n                </div>\r\n                <div class=\"field-checkbox-wrapper date-value-item\">\r\n                  <input type=\"checkbox\" id=\"lastWeek\" name=\"lastWeek\" [(ngModel)]=\"filterDateInputs.lastWeek\"\r\n                      class=\"form-checkbox\" (change)=\"updateDateFilter('lastWeek', $event)\">\r\n                  <label for=\"lastWeek\">Last Week</label>\r\n                </div>\r\n                <div class=\"field-checkbox-wrapper date-value-item\">\r\n                  <input type=\"checkbox\" id=\"thisMonth\" name=\"thisMonth\" [(ngModel)]=\"filterDateInputs.thisMonth\"\r\n                      class=\"form-checkbox\" (change)=\"updateDateFilter('thisMonth', $event)\">\r\n                  <label for=\"thisMonth\">This Month</label>\r\n                </div>\r\n                <div class=\"field-checkbox-wrapper date-value-item\">\r\n                  <input type=\"checkbox\" id=\"custom\" name=\"custom\" [(ngModel)]=\"filterDateInputs.custom\"\r\n                      class=\"form-checkbox\" (change)=\"updateDateFilter('custom', $event)\">\r\n                  <label for=\"custom\">Custom</label>\r\n                  <input style=\"margin-left:10%;visibility:hidden;\" type=\"text\" value=\"\" id=\"customeDate\" class=\"widgetDatepicker bsDatepicker\" name=\"schedWidDate\"\r\n                    [(ngModel)]=\"filterDateRange\" (ngModelChange)=\"updateFilterDateRange($event)\" readonly=\"true\" bsDaterangepicker/>\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"status-container\">\r\n              <div class=\"status-title\">\r\n                <span>Status</span>\r\n              </div>\r\n              <div class=\"status-values-container\">\r\n                <div class=\"field-checkbox-wrapper status-value-item\">\r\n                  <input type=\"checkbox\" id=\"upcoming\" name=\"\" [(ngModel)]=\"filterStatusInputs.upcoming\"\r\n                      class=\"form-checkbox\" (change)=\"updateStatusFilter($event, 'upcoming')\">\r\n                  <label for=\"upcoming\" style=\"color: #ff6c24;\">Upcoming</label>\r\n                </div>\r\n                <div class=\"field-checkbox-wrapper status-value-item\">\r\n                  <input type=\"checkbox\" id=\"attendancePending\" name=\"\" [(ngModel)]=\"filterStatusInputs.attendancePending\"\r\n                      class=\"form-checkbox\" (change)=\"updateStatusFilter($event, 'pending')\">\r\n                  <label for=\"attendancePending\" style=\"color: #8d8d8d;\">Attendance Pending</label>\r\n                </div>\r\n                <div class=\"field-checkbox-wrapper status-value-item\">\r\n                  <input type=\"checkbox\" id=\"completed\" name=\"\" [(ngModel)]=\"filterStatusInputs.completed\"\r\n                      class=\"form-checkbox\" (change)=\"updateStatusFilter($event, 'completed')\">\r\n                  <label for=\"completed\" style=\"color: #00b55a;\">Completed</label>\r\n                </div>\r\n                <div class=\"field-checkbox-wrapper status-value-item\">\r\n                  <input type=\"checkbox\" id=\"cancelled\" name=\"\" [(ngModel)]=\"filterStatusInputs.cancelled\"\r\n                      class=\"form-checkbox\" (change)=\"updateStatusFilter($event, 'cancelled')\">\r\n                  <label for=\"cancelled\" style=\"color: #df0d2f;\">Cancelled</label>\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"faculty-container\" *ngIf=\"userType!=3\">\r\n              <div class=\"faculty-title\">\r\n                <span>Faculty</span>\r\n              </div>\r\n              <div class=\"faculty-dropdown-container\">\r\n                <select class=\"faculty-select-box\" name=\"\" [(ngModel)]=\"inputElements.faculty\" (ngModelChange)=\"updateFacultyInFilter()\">\r\n                  <option value=\"-1\">Select Faculty</option>\r\n                  <option [value]=\"faculty.teacher_id\" *ngFor=\"let faculty of facultyList\">{{faculty.teacher_name}}</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n          </div>\r\n        </div>\r\n        <div class=\"go-btn-container\">\r\n          <button type=\"button\" name=\"button\" class=\"fullBlue gobtn\" (click)=\"getData()\">GO</button>\r\n        </div>\r\n      </div>\r\n      <div class=\"filter-item-2\">\r\n        <button type=\"button\" name=\"button\" class=\"add-class-btn\" (click)=\"redirect()\">\r\n          <i class=\"fa fa-plus\" aria-hidden=\"true\"></i>\r\n          &nbsp;\r\n          Add Class\r\n        </button>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <section class=\"table-holder\" *ngIf=\"coursePlannerData?.length > 0\" (click)=\"closeAll()\">\r\n    <div class=\"table-container\">\r\n      <div class=\"table-header-container\">\r\n        <div class=\"table-heading-item small\" style=\"padding-left: 15px;\">\r\n          <span>Date</span>\r\n        </div>\r\n        <div class=\"table-heading-item small\">\r\n          <span>Time</span>\r\n        </div>\r\n        <div class=\"table-heading-item medium\" *ngIf=\"showHideColumns.masterCourse\">\r\n          <span>Mastercourse</span>\r\n        </div>\r\n        <div class=\"table-heading-item medium\" *ngIf=\"showHideColumns.course\">\r\n          <span>Course</span>\r\n        </div>\r\n        <div class=\"table-heading-item medium\" *ngIf=\"showHideColumns.subject\">\r\n          <span *ngIf=\"!jsonFlag.isProfessional\">Subject</span>\r\n          <span *ngIf=\"jsonFlag.isProfessional\">Batch</span>\r\n        </div>\r\n        <div class=\"table-heading-item medium\" *ngIf=\"showHideColumns.description\">\r\n          <span>Description</span>\r\n        </div>\r\n        <div class=\"table-heading-item medium\" *ngIf=\"showHideColumns.homework\">\r\n          <span>Homework</span>\r\n        </div>\r\n        <div class=\"table-heading-item medium\" *ngIf=\"showHideColumns.teacher\">\r\n          <span>Teacher</span>\r\n        </div>\r\n        <div class=\"table-heading-item large\" *ngIf=\"showHideColumns.topic\">\r\n          <span>Topic(s)</span>\r\n        </div>\r\n        <div class=\"table-heading-item small align-center\">\r\n          <span>Status</span>\r\n        </div>\r\n        <div class=\"table-heading-item medium align-center action\">\r\n          <span>Action</span>\r\n          <i class=\"fa fa-cog\" aria-hidden=\"true\" (click)=\"showHideCol()\"></i>\r\n          <div class=\"show-hide-container\" *ngIf=\"jsonFlag.showHideColumn\">\r\n            <div class=\"show-hide-header\">\r\n              <span>Choose Show/Hide Column</span>\r\n              <i class=\"fa fa-times\" aria-hidden=\"true\" (click)=\"hideShowHideMenu()\"></i>\r\n            </div>\r\n            <div class=\"show-hide-value-container\">\r\n              <!-- <div class=\"field-checkbox-wrapper show-hide-item\">\r\n                <input type=\"checkbox\" id=\"masterCourse\" name=\"\" [(ngModel)]=\"showHideColumns.masterCourse\"\r\n                    class=\"form-checkbox\" (change)=\"hideCol($event)\">\r\n                <label for=\"masterCourse\">Master Course</label>\r\n              </div> -->\r\n              <div class=\"field-checkbox-wrapper show-hide-item\">\r\n                <input type=\"checkbox\" id=\"course\" name=\"\" [(ngModel)]=\"showHideColumns.course\"\r\n                    class=\"form-checkbox\" (change)=\"hideCol($event)\" [disabled]=\"!showHideColumns.course && checkedColCounter == dynamicColCounter\">\r\n                <label for=\"course\">Course</label>\r\n              </div>\r\n              <div class=\"field-checkbox-wrapper show-hide-item\">\r\n                <input type=\"checkbox\" id=\"subject\" name=\"\" [(ngModel)]=\"showHideColumns.subject\"\r\n                    class=\"form-checkbox\" (change)=\"hideCol($event)\" [disabled]=\"!showHideColumns.subject && checkedColCounter == dynamicColCounter\">\r\n                <label for=\"subject\" *ngIf=\"!jsonFlag.isProfessional\">Subject</label>\r\n                <label for=\"subject\" *ngIf=\"jsonFlag.isProfessional\">Batch</label>\r\n              </div>\r\n              <div class=\"field-checkbox-wrapper show-hide-item\" *ngIf=\"!jsonFlag.isProfessional\">\r\n                <input type=\"checkbox\" id=\"topic\" name=\"\" [(ngModel)]=\"showHideColumns.topic\"\r\n                    class=\"form-checkbox\" (change)=\"hideCol($event)\" [disabled]=\"!showHideColumns.topic && checkedColCounter == dynamicColCounter\">\r\n                <label for=\"topic\">Topic</label>\r\n              </div>\r\n              <div class=\"field-checkbox-wrapper show-hide-item\">\r\n                <input type=\"checkbox\" id=\"teacher\" name=\"\" [(ngModel)]=\"showHideColumns.teacher\"\r\n                    class=\"form-checkbox\" (change)=\"hideCol($event)\" [disabled]=\"!showHideColumns.teacher && checkedColCounter == dynamicColCounter\">\r\n                <label for=\"teacher\">Teacher</label>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"show-hide-value-container\">\r\n              <div class=\"show-hide-item\" style=\"margin-bottom: 10px;\">\r\n                <span style=\"font-weight: 600;color:#585574;\">NOTE : </span>\r\n                <span style=\"font-weight: 400;color:#585574;\">To selct the below option(s) please unselect above option(s)</span>\r\n              </div>\r\n              <div class=\"field-checkbox-wrapper show-hide-item\">\r\n                <input type=\"checkbox\" id=\"description\" name=\"\" [(ngModel)]=\"showHideColumns.description\"\r\n                    class=\"form-checkbox\" (change)=\"hideCol($event)\" [disabled]=\"!showHideColumns.description && checkedColCounter == dynamicColCounter\">\r\n                <label for=\"description\">Description</label>\r\n              </div>\r\n              <div class=\"field-checkbox-wrapper show-hide-item\">\r\n                <input type=\"checkbox\" id=\"homework\" name=\"\" [(ngModel)]=\"showHideColumns.homework\"\r\n                    class=\"form-checkbox\" (change)=\"hideCol($event)\" [disabled]=\"!showHideColumns.homework && checkedColCounter == dynamicColCounter\">\r\n                <label for=\"homework\">Homework</label>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"bg-container\">\r\n              <img src=\"./assets/images/course_planner/setting-illustration.svg\" alt=\"\">\r\n            </div>\r\n\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"table-value-outer-container\">\r\n        <div class=\"table-value-container\"\r\n          [ngClass]=\"{'border-cancelled-class': course.status == 'Cancelled' || course.status == 'Cancel(Class)',\r\n                      'border-completed-class': course.status == 'Completed',\r\n                      'border-pending-class': course.status == 'Att. Pending',\r\n                      'border-upcoming-class': course.status == 'Upcoming'}\"\r\n          *ngFor=\"let course of coursePlannerData; let i = index;\">\r\n          <div class=\"table-value-item small\" style=\"padding-left: 15px;\">\r\n            <span>{{course.date | date: 'dd-MMM-yyyy' }}</span>\r\n            <span>&nbsp;</span>\r\n            <span>({{course.date | date :'EEE'}})</span>\r\n          </div>\r\n          <div class=\"table-value-item small\">\r\n            <span>{{course.start_time}}</span>\r\n            <span>&nbsp;- &nbsp;</span>\r\n            <span>{{course.end_time}}</span>\r\n          </div>\r\n          <div class=\"table-value-item medium\"  *ngIf=\"showHideColumns.course\">\r\n            <span title=\"{{course.course_name}}\">{{ (course.course_name.length > 20) ? (course.course_name | slice:0:20) + '...' : course.course_name }}</span>\r\n          </div>\r\n          <div class=\"table-value-item medium\"  *ngIf=\"showHideColumns.subject && !jsonFlag.isProfessional\">\r\n            <span title=\"{{course.subject_name}}\">{{ (course.subject_name.length > 20) ? (course.subject_name | slice:0:20) + '...' : course.subject_name }}</span>\r\n          </div>\r\n          <div class=\"table-value-item medium\"  *ngIf=\"showHideColumns.subject && jsonFlag.isProfessional\">\r\n            <span title=\"{{course.batch_name}}\">{{ (course.batch_name.length > 20) ? (course.batch_name | slice:0:20) + '...' : course.batch_name }}</span>\r\n          </div>\r\n          <div class=\"table-value-item medium\" *ngIf=\"showHideColumns.description\">\r\n            <span title=\"{{course.description}}\">{{ (course.description.length > 20) ? (course.description | slice:0:20) + '...' : course.description }}</span>\r\n          </div>\r\n          <div class=\"table-value-item medium\" *ngIf=\"showHideColumns.homework\">\r\n            <span title=\"{{course.homework_assigned}}\">{{ (course.homework_assigned.length > 20) ? (course.homework_assigned | slice:0:20) + '...' : course.homework_assigned }}</span>\r\n          </div>\r\n          <div class=\"table-value-item medium\" *ngIf=\"showHideColumns.teacher\">\r\n            <span title=\"{{course.teacher_name}}\">{{ (course.teacher_name.length > 20) ? (course.teacher_name | slice:0:20) + '...' : course.teacher_name }}</span>\r\n          </div>\r\n          <div class=\"table-value-item large\"  *ngIf=\"showHideColumns.topic\">\r\n            <span title=\"{{course.topics_covered}}\">{{ (course.topics_covered.length > 25) ? (course.topics_covered | slice:0:25) + '...' : course.topics_covered }}</span>\r\n          </div>\r\n          <div class=\"table-value-item small align-center\">\r\n            <button type=\"button\" name=\"button\" class=\"upcoming-btn\" *ngIf=\"course.status == 'Upcoming'\">Upcoming</button>\r\n            <button type=\"button\" name=\"button\" class=\"pending-btn\" *ngIf=\"course.status == 'Att. Pending'\">Att. Pending</button>\r\n            <button type=\"button\" name=\"button\" class=\"cancelled-btn\" *ngIf=\"course.status == 'Cancelled' || course.status == 'Cancel(Class)'\">Cancelled</button>\r\n            <button type=\"button\" name=\"button\" class=\"completed-btn\" *ngIf=\"course.status == 'Completed'\">Completed</button>\r\n          </div>\r\n          <div class=\"table-value-item medium align-center action \">\r\n            <div class=\"action-container\" *ngIf=\"course.status == 'Upcoming'\">  <!--  upcoming classes action -->\r\n              <img src=\"./assets/images/reschedule.svg\" alt=\"Reschedule\" title=\"Reschedule\" data-toggle=\"modal\" data-target=\"#rescheduleModal\" *ngIf=\"getVisibility(course) && course.is_attendance_marked != 'Y'\" (click)=\"initiateRescheduleClass(course)\">\r\n              <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4\" title=\"Notify\" data-toggle=\"modal\" data-target=\"#notifyModal\" *ngIf=\"getVisibility(course) && course.is_attendance_marked != 'Y'\" (click)=\"initiateRemiderClass(course)\"></i>\r\n              <!-- <i class=\"fa fa-pencil\" aria-hidden=\"true\" style=\"color: #1283f4;\" title=\"Edit\"></i> -->\r\n              <i class=\"fa fa-times-circle\" aria-hidden=\"true\" style=\"color: red;\" title=\"Cancel\" data-toggle=\"modal\" data-target=\"#cancelModal\" *ngIf=\"!jsonFlag.isProfessional && course.is_attendance_marked != 'Y'\" (click)=\"initiateCancelClass(course)\"></i>\r\n              <i class=\"fa fa-times-circle\" aria-hidden=\"true\" style=\"color: red;\" title=\"Cancel\" data-toggle=\"modal\" data-target=\"#cancelBatchModal\" *ngIf=\"jsonFlag.isProfessional && course.is_attendance_marked != 'Y'\" (click)=\"initiateCourseCancelClass(course)\"></i>\r\n            </div>\r\n            <div class=\"action-container\" *ngIf=\"course.status == 'Att. Pending'\">  <!--  pending classes action -->\r\n              <img src=\"./assets/images/checked-att.svg\" alt=\"Mark Attendance\" title=\"Update Attendance\" *ngIf=\"course.is_attendance_marked == 'Y'\" (click)=\"initiateMarkAttendance(course)\">\r\n              <img src=\"./assets/images/att.svg\" alt=\"Mark Attendance\" title=\"Mark Attendance\" *ngIf=\"course.is_attendance_marked == 'N'\" (click)=\"initiateMarkAttendance(course)\">\r\n              <img src=\"./assets/images/reschedule.svg\" alt=\"Reschedule\" title=\"Reschedule\" data-toggle=\"modal\" data-target=\"#rescheduleModal\" *ngIf=\"getVisibility(course) && course.is_attendance_marked != 'Y'\" (click)=\"initiateRescheduleClass(course)\">\r\n              <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4\" title=\"Notify\" data-toggle=\"modal\" data-target=\"#notifyModal\" *ngIf=\"getVisibility(course) && course.is_attendance_marked != 'Y'\" (click)=\"initiateRemiderClass(course)\"></i>\r\n              <!-- <i class=\"fa fa-pencil\" aria-hidden=\"true\" style=\"color: #1283f4;\" title=\"Edit\"></i> -->\r\n              <i class=\"fa fa-times-circle\" aria-hidden=\"true\" style=\"color: red;\" title=\"Cancel\" data-toggle=\"modal\" data-target=\"#cancelModal\" *ngIf=\"!jsonFlag.isProfessional && course.is_attendance_marked != 'Y'\" (click)=\"initiateCancelClass(course)\"></i>\r\n              <i class=\"fa fa-times-circle\" aria-hidden=\"true\" style=\"color: red;\" title=\"Cancel\" data-toggle=\"modal\" data-target=\"#cancelBatchModal\" *ngIf=\"jsonFlag.isProfessional && course.is_attendance_marked != 'Y'\" (click)=\"initiateCourseCancelClass(course)\"></i>\r\n            </div>\r\n            <div class=\"action-container\" *ngIf=\"course.status == 'Cancelled' || course.status == 'Cancel(Class)'\">  <!--  cancelled classes action -->\r\n              <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4;\" title=\"Notify\" (click)=\"notifyCancelClass(course)\"></i>\r\n            </div>\r\n            <div class=\"action-container\" *ngIf=\"course.status == 'Completed'\">  <!--  completed classes action -->\r\n              <img src=\"./assets/images/checked-att.svg\" alt=\"Mark Attendance\" title=\"Update Attendance\" *ngIf=\"course.is_attendance_marked == 'Y'\" (click)=\"initiateMarkAttendance(course)\">\r\n              <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4\" title=\"Notify\" data-toggle=\"modal\" data-target=\"#notifyModal\" *ngIf=\"getVisibility(course) && course.is_attendance_marked != 'Y'\" (click)=\"initiateRemiderClass(course)\"></i>\r\n              <!-- <i class=\"fa fa-pencil\" aria-hidden=\"true\" style=\"color: #1283f4;\" title=\"Edit\"></i> -->\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n</section>\r\n\r\n<div class=\"row filter-res pagination\" #pager id=\"pager\" style=\"width: 100%;\">\r\n  <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n    <pagination (goPage)=\"fectchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\"\r\n      [pagesToShow]=\"10\" [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [sizeArr]=\"sizeArr\"\r\n      (sizeChange)=\"updateTableBatchSize($event)\" [count]=\"totalCount\">\r\n    </pagination>\r\n  </div>\r\n</div>\r\n\r\n\r\n<!-- Illustration container -->\r\n<section *ngIf=\"coursePlannerData?.length == 0\" (click)=\"closeAll()\">\r\n  <div class=\"illustration-container\">\r\n    <img src=\"./assets/images/course_planner/blank-illustration.svg\" alt=\"illustration\" class=\"illustration-img\">\r\n  </div>\r\n</section>\r\n\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/course-planner/class/class.component.scss":
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n.middle-section {\n  padding: 1%; }\n.header-section {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  width: 20%;\n  margin-left: 40%;\n  margin-bottom: 20px; }\n.header-section .header-item {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    padding: 5px;\n    width: 50%;\n    cursor: pointer; }\n.header-section .header-item .img-container img {\n      width: 20px;\n      height: 20px;\n      margin: 0px 10px; }\n.header-section .header-item .model-name-container {\n      width: 50%;\n      margin-top: 3px; }\n.header-section .header-item .model-name-container span {\n        font-size: 14px;\n        font-weight: 600; }\n.header-section #class {\n    border-top-left-radius: 25px;\n    border-bottom-left-radius: 25px;\n    border: 2px solid #3a65f8; }\n.header-section #exam {\n    border-top-right-radius: 25px;\n    border-bottom-right-radius: 25px;\n    border: 2px solid #3a65f8; }\n.active {\n  background: #3a66fa;\n  color: #fdfdfd; }\n.non-active {\n  background: #ffffff;\n  color: #b0b0b0; }\n.middle {\n  margin-top: 10px; }\n.filter-header-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  padding: 5px 0px;\n  border-top: 1px solid #d4d4d4;\n  border-bottom: 1px solid #d4d4d4;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between; }\n.filter-header-container .filter-item-1 {\n    width: 80%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between; }\n.filter-header-container .filter-item-1 .header-item {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      font-size: 12px;\n      color: #3e3d4a;\n      width: 18%;\n      position: relative; }\n.filter-header-container .filter-item-1 .header-item .header-select-box {\n        border-radius: 4px;\n        border: 1px solid #d4d4d4;\n        margin: 5px 0px;\n        padding: 5px 0px; }\n.filter-header-container .filter-item-1 .header-item .input-container {\n        position: relative; }\n.filter-header-container .filter-item-1 .header-item .input-container .fa-filter {\n          position: absolute;\n          left: 2px;\n          background: white;\n          padding: 8px 10px;\n          top: 6px;\n          border-right: 1px solid #ccc; }\n.filter-header-container .filter-item-1 .header-item .input-container .fa-caret-down, .filter-header-container .filter-item-1 .header-item .input-container .fa-caret-up {\n          position: absolute;\n          right: 2px;\n          background: white;\n          padding: 7px 10px;\n          top: 7px;\n          z-index: 1;\n          cursor: pointer; }\n.filter-header-container .filter-item-1 .header-item .filer-input {\n        margin: 5px 0px;\n        border-radius: 4px;\n        border: 1px solid #d4d4d4;\n        padding: 8px 5px;\n        width: 100%;\n        padding-left: 35px;\n        height: 30px; }\n.filter-header-container .filter-item-1 .go-btn-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      font-size: 12px;\n      color: #3e3d4a;\n      width: auto; }\n.filter-header-container .filter-item-1 .go-btn-container .gobtn {\n        border: 1px solid #3a66fa;\n        border-radius: 4px;\n        -webkit-box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n                box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n        padding: 4px 10px;\n        background: #3a66fa;\n        color: #ffffff;\n        font-weight: 600;\n        height: 30px;\n        margin-top: 20px; }\n.filter-header-container .filter-item-2 {\n    width: 10%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: end;\n        -ms-flex-pack: end;\n            justify-content: flex-end; }\n.filter-header-container .filter-item-2 .add-class-btn {\n      border: 1px solid #3a66fa;\n      border-radius: 4px;\n      -webkit-box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n              box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n      padding: 4px 10px;\n      background: white;\n      color: #1283f4;\n      font-weight: 600;\n      height: 30px;\n      margin-top: 15px; }\n.filter-header-container .filter-container {\n    position: absolute;\n    width: 100%;\n    background: white;\n    -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n            box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n    border-radius: 4px;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    top: 55px;\n    -webkit-animation-name: slideInDown;\n            animation-name: slideInDown;\n    -webkit-animation-duration: 0.5s;\n            animation-duration: 0.5s;\n    z-index: 20; }\n.filter-header-container .filter-container .date-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      padding: 10px;\n      border-bottom: 1px solid #ccc;\n      padding-bottom: 0px; }\n.filter-header-container .filter-container .date-container .date-title {\n        font-weight: 600;\n        padding: 5px 0px; }\n.filter-header-container .filter-container .date-container .date-values-container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        -ms-flex-wrap: wrap;\n            flex-wrap: wrap; }\n.filter-header-container .filter-container .date-container .date-values-container .date-value-item {\n          width: 50%; }\n.filter-header-container .filter-container .date-container .date-values-container .date-value-item input, .filter-header-container .filter-container .date-container .date-values-container .date-value-item label {\n            cursor: pointer;\n            font-size: 12px; }\n.filter-header-container .filter-container .status-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      padding: 10px;\n      border-bottom: 1px solid #ccc;\n      padding-bottom: 0px; }\n.filter-header-container .filter-container .status-container .status-title {\n        font-weight: 600;\n        padding: 5px 0px; }\n.filter-header-container .filter-container .status-container .status-values-container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        -ms-flex-wrap: wrap;\n            flex-wrap: wrap; }\n.filter-header-container .filter-container .status-container .status-values-container .status-value-item {\n          width: 50%; }\n.filter-header-container .filter-container .status-container .status-values-container .status-value-item input, .filter-header-container .filter-container .status-container .status-values-container .status-value-item label {\n            cursor: pointer;\n            font-size: 12px; }\n.filter-header-container .filter-container .faculty-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      padding: 10px; }\n.filter-header-container .filter-container .faculty-container .faculty-title {\n        font-weight: 600;\n        padding: 5px 0px; }\n.filter-header-container .filter-container .faculty-container .faculty-dropdown-container {\n        width: 100%; }\n.filter-header-container .filter-container .faculty-container .faculty-dropdown-container .faculty-select-box {\n          border-bottom: 1px solid #d4d4d4;\n          margin: 5px 0px;\n          padding: 5px 0px;\n          width: 100%; }\n.illustration-container {\n  display: block; }\n.illustration-container .illustration-img {\n    width: 40%;\n    /* height: 34%; */\n    margin-left: 12%;\n    margin-top: -2%; }\n.table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%;\n  margin-top: 10px; }\n.table-container .table-header-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    margin-bottom: 10px;\n    padding-bottom: 10px;\n    margin-right: 10px;\n    padding-left: 5px;\n    border-bottom: 1px solid #ccc; }\n.table-container .table-header-container .table-heading-item {\n      color: #585574;\n      font-weight: 600;\n      font-size: 12px;\n      padding: 0px 5px; }\n.table-container .table-header-container .table-heading-item .fa-cog {\n        position: absolute;\n        right: 20px;\n        cursor: pointer;\n        color: #9898a3;\n        font-size: 14px; }\n.table-container .table-header-container .table-heading-item .show-hide-container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        width: 230px;\n        right: 35px;\n        height: auto;\n        position: absolute;\n        top: 0px;\n        border-radius: 4px;\n        -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n                box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n        z-index: 10;\n        background: white;\n        -webkit-animation-name: slideInRight;\n                animation-name: slideInRight;\n        -webkit-animation-duration: 0.5s;\n                animation-duration: 0.5s; }\n.table-container .table-header-container .table-heading-item .show-hide-container .show-hide-header {\n          padding: 10px;\n          background: #f9f9f9;\n          color: #585574;\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-pack: justify;\n              -ms-flex-pack: justify;\n                  justify-content: space-between; }\n.table-container .table-header-container .table-heading-item .show-hide-container .show-hide-header .fa-times {\n            font-weight: 400;\n            cursor: pointer; }\n.table-container .table-header-container .table-heading-item .show-hide-container .show-hide-value-container {\n          padding: 10px;\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: vertical;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: column;\n                  flex-direction: column;\n          border-bottom: 1px solid #ccc; }\n.table-container .table-header-container .table-heading-item .show-hide-container .show-hide-value-container .show-hide-item {\n            width: 100%;\n            text-align: left; }\n.table-container .table-header-container .table-heading-item .show-hide-container .show-hide-value-container .show-hide-item input, .table-container .table-header-container .table-heading-item .show-hide-container .show-hide-value-container .show-hide-item label {\n              font-size: 12px;\n              font-weight: 400; }\n.table-container .table-header-container .table-heading-item .show-hide-container .bg-container {\n          position: absolute;\n          bottom: 0px;\n          right: 0px; }\n.table-container .table-header-container .table-heading-item .show-hide-container .bg-container img {\n            width: 75%;\n            margin-left: 25%; }\n.table-container .table-value-outer-container {\n    height: 59vh;\n    overflow-y: auto; }\n.table-container .table-value-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    background: #ffffff;\n    border-radius: 4px;\n    -webkit-box-shadow: 0 3px 5px 0 rgba(0, 0, 0, 0.16);\n            box-shadow: 0 3px 5px 0 rgba(0, 0, 0, 0.16);\n    margin-bottom: 10px;\n    padding: 5px 0px;\n    position: relative; }\n.table-container .table-value-container .table-value-item {\n      color: #585574;\n      font-weight: 400;\n      font-size: 12px;\n      line-height: 1.5;\n      display: -webkit-box;\n      -webkit-box-align: center;\n      padding: 0px 5px;\n      word-break: break-all; }\n.table-container .table-value-container .table-value-item .upcoming-btn {\n        color: #ffffff;\n        border-radius: 4px;\n        border: 1px solid #ffffff;\n        background: #ff6c24;\n        cursor: default;\n        padding: 2px 10px;\n        width: 95px;\n        font-weight: 600; }\n.table-container .table-value-container .table-value-item .pending-btn {\n        color: #ffffff;\n        border-radius: 4px;\n        border: 1px solid #ffffff;\n        background: #8d8d8d;\n        cursor: default;\n        padding: 2px 10px;\n        width: 95px;\n        font-weight: 600; }\n.table-container .table-value-container .table-value-item .cancelled-btn {\n        color: #ffffff;\n        border-radius: 4px;\n        border: 1px solid #ffffff;\n        background: #df0d2f;\n        cursor: default;\n        padding: 2px 10px;\n        width: 95px;\n        font-weight: 600; }\n.table-container .table-value-container .table-value-item .completed-btn {\n        color: #ffffff;\n        border-radius: 4px;\n        border: 1px solid #ffffff;\n        background: #00b55a;\n        cursor: default;\n        padding: 2px 10px;\n        width: 95px;\n        font-weight: 600; }\n.table-container .border-cancelled-class {\n    border-left: 5px solid #df0d2f; }\n.table-container .border-completed-class {\n    border-left: 5px solid #00b55a; }\n.table-container .border-pending-class {\n    border-left: 5px solid #8d8d8d; }\n.table-container .border-upcoming-class {\n    border-left: 5px solid #ff6c24; }\n.table-container .align-center {\n    text-align: center; }\n.table-container .small {\n    width: 11%;\n    font-size: 12px; }\n.table-container .medium {\n    width: 13%;\n    font-size: 12px; }\n.table-container .large {\n    width: 15%;\n    font-size: 12px; }\n.table-container .action {\n    position: absolute;\n    right: 0px; }\n.table-container .action-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: end;\n        -ms-flex-pack: end;\n            justify-content: flex-end;\n    width: 85%;\n    margin-right: 15%;\n    margin-top: 7px; }\n.table-container .action-container i, .table-container .action-container img {\n      margin: 0px 5px;\n      max-width: 14px;\n      height: 14px;\n      cursor: pointer; }\n.header-item .field-checkbox-wrapper .form-checkbox + label {\n  vertical-align: middle;\n  font-size: 14px;\n  display: inline-block; }\n.header-item .field-checkbox-wrapper .form-checkbox + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 2px;\n  position: absolute;\n  left: 0;\n  top: 0; }\n.header-item .field-checkbox-wrapper .form-checkbox:checked + label:after {\n  border: 2px solid #0084f6; }\n.header-item .field-checkbox-wrapper .form-checkbox + label:before {\n  width: 1px;\n  height: 1px;\n  left: 8px;\n  top: 9px;\n  position: absolute;\n  content: '';\n  border-top: 0;\n  border-right: 0;\n  border-left: 2px solid transparent;\n  border-bottom: 2px solid transparent;\n  -webkit-transform: rotate(-45deg);\n          transform: rotate(-45deg); }\n.header-item .field-checkbox-wrapper .form-checkbox:checked + label:before {\n  border-left: 2px solid #0084f6;\n  border-bottom: 2px solid #0084f6;\n  width: 12px;\n  height: 5px;\n  left: 2px;\n  top: 5px; }\n.header-item .field-checkbox-wrapper .form-checkbox:checked + label {\n  color: #0084f6; }\n.filter-res.pagination {\n  width: 100%; }\n.pagination {\n  margin: 0px; }\n.pagination .first:before {\n    content: \"« \";\n    font-size: 16px;\n    font-weight: 800; }\n.pagination .last:after {\n    content: \" »\";\n    font-size: 16px;\n    font-weight: 800; }\n.pagination .batch-size {\n    font-size: 16px;\n    font-weight: 800; }\n.pagination li {\n    border-right: 1px solid #ccc;\n    padding: 0px 7px;\n    margin: 0;\n    line-height: 10px;\n    font-weight: 800;\n    cursor: pointer; }\n.pagination li a {\n      line-height: 10px;\n      font-size: 16px;\n      font-weight: 800;\n      border: none;\n      padding: 0px 14px; }\n.pagination li :hover {\n      background-color: transparent !important; }\n.pagination li:last-child {\n  border-right: 0;\n  padding-right: 0; }\n@-webkit-keyframes slideInDown {\n  from {\n    -webkit-transform: translate3d(0, -10%, 0);\n    transform: translate3d(0, -10%, 0);\n    visibility: visible; }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n    transform: translate3d(0, 0, 0); } }\n@keyframes slideInDown {\n  from {\n    -webkit-transform: translate3d(0, -10%, 0);\n    transform: translate3d(0, -10%, 0);\n    visibility: visible; }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n    transform: translate3d(0, 0, 0); } }\n@-webkit-keyframes slideInRight {\n  from {\n    -webkit-transform: translate3d(5%, 0, 0);\n    transform: translate3d(5%, 0, 0);\n    visibility: visible; }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n    transform: translate3d(0, 0, 0); } }\n@keyframes slideInRight {\n  from {\n    -webkit-transform: translate3d(5%, 0, 0);\n    transform: translate3d(5%, 0, 0);\n    visibility: visible; }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n    transform: translate3d(0, 0, 0); } }\n.form-wrapper {\n  background: transparent;\n  margin: 5px 0px; }\n.form-wrapper.datepicker span {\n    position: absolute;\n    top: 35px;\n    right: 20px;\n    font-weight: 600;\n    font-size: 14px;\n    color: red;\n    cursor: pointer;\n    width: 20px;\n    text-align: center; }\n.form-wrapper.datepicker span::before {\n      content: '';\n      background: url(\"/assets/images/calendar.svg\") no-repeat;\n      position: absolute;\n      right: 20px;\n      top: 20px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n.form-wrapper.datepicker span:after {\n      content: '';\n      background: url(\"/assets/images/calendar.svg\") no-repeat;\n      position: absolute;\n      right: 0;\n      top: 20px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n.form-wrapper label {\n    font-size: 12px;\n    font-weight: 400;\n    color: rgba(0, 0, 0, 0.77);\n    padding-bottom: 2px;\n    text-decoration: none;\n    text-transform: uppercase;\n    -webkit-font-smoothing: antialiased; }\n.form-wrapper .side-form-ctrl {\n    background: white;\n    border: 1px solid rgba(119, 119, 119, 0.419608);\n    width: 100%;\n    padding: 8px 5px;\n    font-weight: 600;\n    font-size: 14px;\n    color: black; }\n.form-wrapper .side-form-ctrl.bsDatepicker {\n      padding: 5px;\n      width: 100%; }\n.form-wrapper.timepick {\n    padding: 1px 0px; }\n.form-wrapper.timepick .tbox {\n      display: inline-block;\n      width: 100%; }\n.form-wrapper.timepick .tbox .times {\n        display: inline-block; }\n.form-wrapper.timepick .tbox .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        padding: 8px 5px;\n        font-weight: 400;\n        font-size: 14px;\n        color: black; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mins {\n          width: 70px;\n          font-size: 12px;\n          height: 30px; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mers {\n          width: 50px;\n          font-size: 12px;\n          height: 30px; }\n.field-wrapper.datePickerBox:after {\n  content: '';\n  background: url(/./assets/images/calendar.svg) no-repeat;\n  position: absolute;\n  right: 5px;\n  top: 20px;\n  width: 21px;\n  height: 21px;\n  z-index: 0; }\n.schedule-scroller .ct-disable-wrapper pos-rel ul li {\n  padding-top: 15px;\n  padding-bottom: 1px;\n  text-align: center;\n  float: left;\n  font-weight: 800; }\n#next_tab {\n  margin-top: 10px; }\n.rescheduleTime label {\n  text-transform: none; }\n.rescheduleTime .tbox {\n  padding: 0px 0px; }\n.rescheduleTime .tbox .times .side-form-ctrl.mins {\n    padding: 0px 0px; }\n.rescheduleTime .tbox .times .side-form-ctrl.mers {\n    padding: 0px 0px; }\n.borderWithText {\n  display: block;\n  margin: 10px 0px; }\n.borderWithText h2 {\n    font-size: 15px;\n    text-align: center;\n    border-bottom: 2px solid #f1f1f1;\n    position: relative; }\n.borderWithText h2 span {\n      background-color: white;\n      position: relative;\n      top: 10px;\n      padding: 0 10px; }\n.button_type {\n  padding: 0px 10px;\n  border: 1px solid #d4d4d4;\n  border-radius: 11px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/course-planner/class/class.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ClassComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_rxjs_Rx__ = __webpack_require__("./node_modules/rxjs/_esm5/Rx.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_course_services_class_schedule_service__ = __webpack_require__("./src/app/services/course-services/class-schedule.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__course_planner_model__ = __webpack_require__("./src/app/components/course-module/course-planner/course-planner.model.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__session_filter_model__ = __webpack_require__("./src/app/components/course-module/course-planner/session-filter.model.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__services_widget_service__ = __webpack_require__("./src/app/services/widget.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};










var ClassComponent = /** @class */ (function () {
    function ClassComponent(router, auth, msgService, classService, widgetService) {
        this.router = router;
        this.auth = auth;
        this.msgService = msgService;
        this.classService = classService;
        this.widgetService = widgetService;
        // global variables
        this.jsonFlag = {
            isProfessional: false,
            institute_id: '',
            isRippleLoad: false,
            showHideColumn: false
        };
        this.coursePlannerFor = "class";
        // apis variables to send
        this.inputElements = {
            masterCourse: "-1",
            course: "-1",
            subject: "-1",
            standard_id: "-1",
            subject_id: "-1",
            batch_id: "-1",
            faculty: "-1",
            isAssigned: "N"
        };
        // Duration filter for course planner data
        this.filterDateInputs = {
            thisWeek: true,
            lastWeek: false,
            thisMonth: false,
            custom: false
        };
        //  class status filter for course planner data
        this.filterStatusInputs = {
            upcoming: true,
            attendancePending: true,
            completed: true,
            cancelled: true,
        };
        // Default col show hide status
        this.showHideColumns = {
            course: true,
            subject: true,
            teacher: true,
            topic: true,
            description: false,
            homework: false
        };
        // for show hide table columns
        this.checkedColCounter = 2;
        this.dynamicColCounter = 2;
        this.userType = 0;
        // Array Elements
        this.facultyList = [];
        this.coursePlannerData = []; // saved course planner fetched data
        this.allData = []; // used for pagination purpose
        // course model array
        this.masterCourseList = [];
        this.courseList = [];
        this.subjectList = [];
        // batch model array
        this.batchList = [];
        this.coursePlannerFilters = new __WEBPACK_IMPORTED_MODULE_7__course_planner_model__["a" /* CoursePlanner */]();
        this.sessionFiltersArr = new __WEBPACK_IMPORTED_MODULE_8__session_filter_model__["a" /* SessionFilter */]();
        this.filterShow = false;
        this.filterDateRange = "";
        // FOR PAGINATION
        this.pageIndex = 1;
        this.displayBatchSize = 20;
        this.totalCount = 0;
        this.sizeArr = [20, 50, 100, 150, 200, 500];
        this.times = ['', '1 AM', '2 AM', '3 AM', '4 AM', '5 AM', '6 AM', '7 AM', '8 AM', '9 AM', '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM', '4 PM', '5 PM', '6 PM', '7 PM', '8 PM', '9 PM', '10 PM', '11 PM', '12 AM'];
        this.minArr = ['', '00', '15', '30', '45'];
        this.isReminderPop = false;
        this.isReschedulePop = false;
        this.isCancelPop = false; // For Course MODEL
        this.isCourseCancel = false; // For Batch Model
        // FOR Reschedule
        this.reschedDate = new Date();
        this.reschedReason = "";
        this.resheduleNotified = "Y";
        this.timepicker = {
            reschedStartTime: {
                hour: '12 PM',
                minute: '00',
                meridian: ''
            },
            reschedEndTime: {
                hour: '1 PM',
                minute: '00',
                meridian: ''
            },
        };
        // FOR NOTIFY
        this.reminderRemarks = '';
        this.remarksLimit = 50;
        // FOR CANCEL PopUP
        this.cancellationReason = '';
        this.is_notified = 'Y';
    }
    ClassComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userType = sessionStorage.getItem('userType');
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.jsonFlag.isProfessional = true;
            }
            else {
                _this.jsonFlag.isProfessional = false;
            }
        });
        this.coursePlannerFilters.isMarksUpdate = "N";
        this.showHideColForModel();
        this.fetchPreFillData();
        this.jsonFlag.institute_id = sessionStorage.getItem('institute_id');
        var filters = sessionStorage.getItem('coursePlannerFilter');
        if (filters) {
            this.sessionFilters(filters);
        }
    };
    ClassComponent.prototype.showHideColForModel = function () {
        if (this.jsonFlag.isProfessional) {
            this.dynamicColCounter = 1;
            this.checkedColCounter = 1;
            this.showHideColumns.description = true;
            this.showHideColumns.topic = false;
        }
    };
    ClassComponent.prototype.clearFilters = function () {
        sessionStorage.setItem('batch_info', '');
        sessionStorage.setItem('isSubjectView', '');
        sessionStorage.setItem('isFromCoursePlanner', '');
        sessionStorage.setItem('coursePlannerFilter', '');
        this.sessionFiltersArr = new __WEBPACK_IMPORTED_MODULE_8__session_filter_model__["a" /* SessionFilter */]();
    };
    ClassComponent.prototype.sessionFilters = function (filters) {
        var _this = this;
        this.sessionFiltersArr = JSON.parse(filters);
        this.inputElements.masterCourse = this.sessionFiltersArr.masterCourse;
        this.inputElements.course = this.sessionFiltersArr.courseId;
        this.inputElements.standard_id = this.sessionFiltersArr.standardId;
        this.inputElements.subject_id = this.sessionFiltersArr.subjectId;
        if (!this.jsonFlag.isProfessional) {
            this.inputElements.subject = this.sessionFiltersArr.batchId;
        }
        else {
            this.inputElements.batch_id = this.sessionFiltersArr.batchId;
        }
        this.inputElements.faculty = this.sessionFiltersArr.facultyId;
        this.filterStatusInputs.completed = this.sessionFiltersArr.isCompleted;
        this.filterStatusInputs.attendancePending = this.sessionFiltersArr.isPending;
        this.filterStatusInputs.cancelled = this.sessionFiltersArr.isCancelled;
        this.filterStatusInputs.upcoming = this.sessionFiltersArr.isUpcoming;
        this.filterDateInputs.thisWeek = this.sessionFiltersArr.thisWeek;
        this.filterDateInputs.lastWeek = this.sessionFiltersArr.lastWeek;
        this.filterDateInputs.thisMonth = this.sessionFiltersArr.thisMonth;
        this.filterDateInputs.custom = this.sessionFiltersArr.custom;
        this.coursePlannerFilters.master_course_name = this.sessionFiltersArr.masterCourse;
        this.coursePlannerFilters.course_id = this.sessionFiltersArr.courseId;
        this.coursePlannerFilters.batch_id = this.sessionFiltersArr.batchId;
        this.coursePlannerFilters.teacher_id = this.sessionFiltersArr.facultyId;
        if (!this.filterStatusInputs.completed) {
            this.coursePlannerFilters.isCompleted = "N";
        }
        if (!this.filterStatusInputs.attendancePending) {
            this.coursePlannerFilters.isPending = "N";
        }
        if (!this.filterStatusInputs.cancelled) {
            this.coursePlannerFilters.isCancelled = "N";
        }
        if (!this.filterStatusInputs.upcoming) {
            this.coursePlannerFilters.isUpcoming = "N";
        }
        this.coursePlannerFilters.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.sessionFiltersArr.from_date).format("YYYY-MM-DD");
        this.coursePlannerFilters.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.sessionFiltersArr.to_date).format("YYYY-MM-DD");
        sessionStorage.setItem('isFromCoursePlanner', String(false));
        sessionStorage.setItem('coursePlannerFilter', '');
        setTimeout(function () {
            _this.getData();
        }, 2000);
    };
    ClassComponent.prototype.fetchPreFillData = function () {
        var _this = this;
        // get master course - course - subject data  for course model
        if (!this.jsonFlag.isProfessional) {
            this.jsonFlag.isRippleLoad = true;
            this.classService.getAllMasterCourse().subscribe(function (res) {
                _this.masterCourseList = res;
                if (_this.sessionFiltersArr.masterCourse != "-1") {
                    _this.updateCoursesList();
                }
                _this.jsonFlag.isRippleLoad = false;
            }, function (err) {
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', 'Please check your internet connection or contact at support@proctur.com if the issue persist');
                _this.jsonFlag.isRippleLoad = false;
            });
        }
        else {
            // get master course - course - subject data  for Batch model
            this.jsonFlag.isRippleLoad = true;
            this.classService.getStandardSubjectList(this.inputElements.standard_id, this.inputElements.subject_id, this.inputElements.isAssigned).subscribe(function (res) {
                _this.masterCourseList = res.standardLi;
                _this.batchList = res.batchLi;
                if (_this.sessionFiltersArr.standardId != "-1") {
                    _this.updateCoursesList();
                }
                _this.jsonFlag.isRippleLoad = false;
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', 'Please check your internet connection or contact at support@proctur.com if the issue persist');
            });
        }
        // get active faculty list
        this.classService.getAllTeachersList().subscribe(function (res) {
            _this.facultyList = res;
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', 'Please check your internet connection or contact at support@proctur.com if the issue persist');
        });
    };
    ClassComponent.prototype.updateCoursesList = function () {
        var _this = this;
        // For Course Model
        if (!this.jsonFlag.isProfessional) {
            this.coursePlannerFilters.master_course_name = this.inputElements.masterCourse;
            if (this.sessionFiltersArr.courseId != "-1" && this.sessionFiltersArr.courseId != "") {
                this.inputElements.course = this.sessionFiltersArr.courseId;
            }
            else {
                this.inputElements.course = "-1";
                this.inputElements.subject = "-1";
                this.coursePlannerFilters.course_id = "-1";
                this.coursePlannerFilters.batch_id = "-1";
            }
            if (this.inputElements.masterCourse == "") {
                this.courseList = [];
                this.subjectList = [];
            }
            else {
                for (var i = 0; i < this.masterCourseList.length; i++) {
                    if (this.masterCourseList[i].master_course == this.inputElements.masterCourse) {
                        this.courseList = this.masterCourseList[i].coursesList;
                        if (this.sessionFiltersArr.courseId != "-1" && this.sessionFiltersArr.courseId != "") {
                            this.updateSubjectsList();
                        }
                        else {
                            this.subjectList = [];
                            return;
                        }
                    }
                }
            }
        }
        else {
            this.coursePlannerFilters.standard_id = this.inputElements.standard_id;
            this.inputElements.subject_id = "-1";
            this.coursePlannerFilters.subject_id = "-1";
            if (this.inputElements.standard_id == "-1") {
                this.courseList = [];
            }
            else {
                // Fetch batches according to standard and subject id for all active batches
                this.jsonFlag.isRippleLoad = true;
                this.classService.getStandardSubjectList(this.inputElements.standard_id, this.inputElements.subject_id, this.inputElements.isAssigned).subscribe(function (res) {
                    _this.jsonFlag.isRippleLoad = false;
                    _this.courseList = res.subjectLi;
                    _this.batchList = res.batchLi;
                    _this.jsonFlag.isRippleLoad = false;
                    for (var i = 0; i < _this.masterCourseList.length; i++) {
                        if (_this.masterCourseList[i].standard_id == _this.inputElements.standard_id) {
                            _this.courseStartDate = _this.masterCourseList[i].start_date;
                            _this.courseEndDate = _this.masterCourseList[i].end_date;
                            if (_this.sessionFiltersArr.subjectId != "-1" && _this.sessionFiltersArr.subjectId != "") {
                                _this.inputElements.subject_id = _this.sessionFiltersArr.subjectId;
                                _this.updateSubjectsList();
                            }
                            return;
                        }
                    }
                }, function (err) {
                    _this.jsonFlag.isRippleLoad = false;
                    _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err);
                });
            }
        }
    };
    ClassComponent.prototype.updateSubjectsList = function () {
        var _this = this;
        // For Course Model
        if (!this.jsonFlag.isProfessional) {
            this.coursePlannerFilters.course_id = this.inputElements.course;
            if (this.inputElements.course == "" || this.inputElements.course == "-1") {
                this.subjectList = [];
                this.inputElements.subject = "-1";
                this.coursePlannerFilters.batch_id = this.inputElements.subject;
            }
            else {
                for (var i = 0; i < this.courseList.length; i++) {
                    if (this.courseList[i].course_id == this.inputElements.course) {
                        this.subjectList = this.courseList[i].batchesList;
                        this.courseStartDate = this.courseList[i].start_date;
                        this.courseEndDate = this.courseList[i].end_date;
                        if (this.sessionFiltersArr.standardId != "-1" && this.sessionFiltersArr.standardId != "") {
                            this.inputElements.subject = this.sessionFiltersArr.batchId;
                        }
                        this.clearFilters(); // after updating all the filter values clear session filter
                        return;
                    }
                }
            }
        }
        else {
            this.jsonFlag.isRippleLoad = true;
            this.coursePlannerFilters.subject_id = this.inputElements.subject_id;
            this.classService.getStandardSubjectList(this.inputElements.standard_id, this.inputElements.subject_id, this.inputElements.isAssigned).subscribe(function (res) {
                _this.jsonFlag.isRippleLoad = false;
                _this.batchList = res.batchLi;
                _this.clearFilters();
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err);
            });
        }
    };
    ClassComponent.prototype.updateSubject = function () {
        if (!this.jsonFlag.isProfessional) {
            this.coursePlannerFilters.batch_id = this.inputElements.subject;
        }
        else {
            this.coursePlannerFilters.batch_id = this.inputElements.batch_id;
        }
    };
    ClassComponent.prototype.updateFacultyInFilter = function () {
        this.coursePlannerFilters.teacher_id = this.inputElements.faculty;
    };
    ClassComponent.prototype.toggleFilter = function () {
        if (this.filterShow) {
            this.filterShow = false;
        }
        else {
            this.filterShow = true;
        }
    };
    ClassComponent.prototype.updateDateFilter = function (inputDateFilter, e) {
        this.filterDateInputs.thisWeek = false;
        this.filterDateInputs.lastWeek = false;
        this.filterDateInputs.thisMonth = false;
        this.filterDateInputs.custom = false;
        if (inputDateFilter == 'custom') {
            this.openCalendar('customeDate');
            this.filterDateInputs.custom = true;
            e.currentTarget.checked = true;
        }
        else if (inputDateFilter == 'lastWeek') {
            this.coursePlannerFilters.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__().subtract(1, 'weeks').startOf('isoWeek').format("YYYY-MM-DD");
            this.coursePlannerFilters.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__().subtract(1, 'weeks').endOf('isoWeek').format("YYYY-MM-DD");
            this.filterDateInputs.lastWeek = true;
            e.currentTarget.checked = true;
        }
        else if (inputDateFilter == 'thisMonth') {
            this.coursePlannerFilters.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-01");
            this.coursePlannerFilters.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-") + __WEBPACK_IMPORTED_MODULE_3_moment__().daysInMonth();
            this.filterDateInputs.thisMonth = true;
            e.currentTarget.checked = true;
        }
        else if (inputDateFilter == 'thisWeek') {
            this.coursePlannerFilters.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__().isoWeekday("Monday").format("YYYY-MM-DD");
            this.coursePlannerFilters.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__().weekday(7).format("YYYY-MM-DD");
            this.filterDateInputs.thisWeek = true;
            e.currentTarget.checked = true;
        }
    };
    ClassComponent.prototype.updateStatusFilter = function (e, statusFilter) {
        if (!e.currentTarget.checked) {
            if (statusFilter == 'upcoming') {
                this.coursePlannerFilters.isUpcoming = "N";
            }
            else if (statusFilter == 'pending') {
                this.coursePlannerFilters.isPending = "N";
            }
            else if (statusFilter == 'completed') {
                this.coursePlannerFilters.isCompleted = "N";
            }
            else if (statusFilter == 'cancelled') {
                this.coursePlannerFilters.isCancelled = "N";
            }
        }
        else if (e.currentTarget.checked) {
            if (statusFilter == 'upcoming') {
                this.coursePlannerFilters.isUpcoming = "Y";
            }
            else if (statusFilter == 'pending') {
                this.coursePlannerFilters.isPending = "Y";
            }
            else if (statusFilter == 'completed') {
                this.coursePlannerFilters.isCompleted = "Y";
            }
            else if (statusFilter == 'cancelled') {
                this.coursePlannerFilters.isCancelled = "Y";
            }
        }
    };
    ClassComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    ClassComponent.prototype.updateFilterDateRange = function (e) {
        if (this.filterDateInputs.custom) {
            this.coursePlannerFilters.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__(e[0]).format("YYYY-MM-DD");
            this.coursePlannerFilters.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__(e[1]).format("YYYY-MM-DD");
        }
    };
    ClassComponent.prototype.getData = function () {
        var _this = this;
        this.filterShow = false;
        this.jsonFlag.showHideColumn = false;
        this.jsonFlag.isRippleLoad = true;
        // Course/bacth model and master course is selected
        if ((!this.jsonFlag.isProfessional && this.coursePlannerFilters.master_course_name == "-1") ||
            (this.jsonFlag.isProfessional && this.coursePlannerFilters.standard_id == "-1")) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please select master course');
            this.jsonFlag.isRippleLoad = false;
            return;
        }
        else {
            this.classService.getCoursePlannerData(this.coursePlannerFilters, this.coursePlannerFor).subscribe(function (res) {
                _this.jsonFlag.isRippleLoad = false;
                _this.allData = res;
                if (_this.allData.length == 0) {
                    _this.msgService.showErrorMessage(_this.msgService.toastTypes.info, 'Info', "No result found");
                }
                else {
                    _this.totalCount = _this.allData.length;
                    _this.pageIndex = 1;
                    _this.fectchTableDataByPage(_this.pageIndex);
                }
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            });
        }
    };
    ClassComponent.prototype.showHideCol = function () {
        if (this.jsonFlag.showHideColumn) {
            this.jsonFlag.showHideColumn = false;
        }
        else {
            this.jsonFlag.showHideColumn = true;
        }
    };
    ClassComponent.prototype.hideCol = function (e) {
        if (!e.currentTarget.checked) {
            this.checkedColCounter++;
        }
        else {
            this.checkedColCounter--;
        }
    };
    ClassComponent.prototype.hideShowHideMenu = function () {
        this.jsonFlag.showHideColumn = false;
    };
    /*** pagination functions */
    /* Fetch next set of data from server and update table */
    ClassComponent.prototype.fetchNext = function () {
        this.pageIndex++;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch previous set of data from server and update table */
    ClassComponent.prototype.fetchPrevious = function () {
        this.pageIndex--;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch table data by page index */
    ClassComponent.prototype.fectchTableDataByPage = function (index) {
        this.pageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.coursePlannerData = this.getDataFromDataSource(startindex);
    };
    // get  appropriate course planner data according to page
    ClassComponent.prototype.getDataFromDataSource = function (startindex) {
        var t = this.allData.slice(startindex, startindex + this.displayBatchSize);
        return t;
    };
    /* Fetches Data as per the user selected batch size */
    ClassComponent.prototype.updateTableBatchSize = function (num) {
        this.pageIndex = 1;
        this.displayBatchSize = parseInt(num);
        this.getData();
    };
    // All pop up section with their functions
    ClassComponent.prototype.initiateRescheduleClass = function (selected) {
        this.classMarkedForAction = selected;
        this.isReschedulePop = true;
    };
    ClassComponent.prototype.initiateRemiderClass = function (selected) {
        this.classMarkedForAction = selected;
        this.isReminderPop = true;
    };
    ClassComponent.prototype.initiateCancelClass = function (selected) {
        this.classMarkedForAction = selected;
        this.isCancelPop = true;
    };
    ClassComponent.prototype.initiateCourseCancelClass = function (selected) {
        this.classMarkedForAction = selected;
        this.isCourseCancel = true;
    };
    ClassComponent.prototype.getVisibility = function (c) {
        var d = __WEBPACK_IMPORTED_MODULE_3_moment__(c.class_date).format("YYYY-MM-DD");
        if (d >= __WEBPACK_IMPORTED_MODULE_3_moment__(new Date()).format("YYYY-MM-DD")) {
            return true;
        }
        else {
            return false;
        }
    };
    ClassComponent.prototype.getCheckedStatus = function (id) {
        if (id === "notifyCancel") {
            return true;
        }
        else if (id === 'resheduleNotified') {
            return true;
        }
    };
    ClassComponent.prototype.notifyRescheduleUpdate = function (e) {
        if (e.target.checked) {
            this.resheduleNotified = "Y";
        }
        else {
            this.resheduleNotified = "N";
        }
    };
    ClassComponent.prototype.closeRescheduleClass = function () {
        this.isReschedulePop = false;
        this.reschedDate = new Date();
        this.reschedReason = "";
        this.timepicker = {
            reschedStartTime: {
                hour: '12 PM',
                minute: '00',
                meridian: ''
            },
            reschedEndTime: {
                hour: '1 PM',
                minute: '00',
                meridian: ''
            },
        };
    };
    ClassComponent.prototype.rescheduleClass = function () {
        var _this = this;
        if (this.reschedReason == null || this.reschedReason == "") {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter reschedule reason');
            return;
        }
        if (__WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD') > __WEBPACK_IMPORTED_MODULE_3_moment__(this.reschedDate).format('YYYY-MM-DD')) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter future reschedule date');
            return;
        }
        var check = this.checkIfTimeProvided(this.timepicker.reschedStartTime.hour);
        if (check) {
            var startTime = this.timepicker.reschedStartTime.hour.split(' ');
            this.timepicker.reschedStartTime.hour = startTime[0];
            this.timepicker.reschedStartTime.meridian = startTime[1];
        }
        else {
            return;
        }
        var check1 = this.checkIfTimeProvided(this.timepicker.reschedEndTime.hour);
        if (check1) {
            var endTime = this.timepicker.reschedEndTime.hour.split(' ');
            this.timepicker.reschedEndTime.hour = endTime[0];
            this.timepicker.reschedEndTime.meridian = endTime[1];
        }
        else {
            return;
        }
        if (this.reSheduleFormValid()) {
            var temp1 = {
                cancel_note: this.reschedReason,
                schd_id: this.classMarkedForAction.schedule_id,
                is_notified: this.resheduleNotified
            };
            var temp2 = {
                class_date: __WEBPACK_IMPORTED_MODULE_3_moment__(this.reschedDate).format("YYYY-MM-DD"),
                start_time: this.timepicker.reschedStartTime.hour + ":" + this.timepicker.reschedStartTime.minute + " " + this.timepicker.reschedStartTime.meridian,
                end_time: this.timepicker.reschedEndTime.hour + ":" + this.timepicker.reschedEndTime.minute + " " + this.timepicker.reschedEndTime.meridian,
                duration: this.getDifference()
            };
            var obj = {
                batch_id: this.classMarkedForAction.batch_id,
                cancelSchd: [],
                extraSchd: []
            };
            obj.cancelSchd.push(temp1);
            obj.extraSchd.push(temp2);
            this.jsonFlag.isRippleLoad = true;
            this.widgetService.reScheduleClass(obj).subscribe(function (res) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, '', 'The request has been processed');
                _this.closeRescheduleClass();
                _this.getData();
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            });
        }
        else {
            this.timepicker.reschedStartTime.hour = this.timepicker.reschedStartTime.hour + " " + this.timepicker.reschedStartTime.meridian;
            this.timepicker.reschedEndTime.hour = this.timepicker.reschedEndTime.hour + " " + this.timepicker.reschedEndTime.meridian;
        }
    };
    ClassComponent.prototype.checkIfTimeProvided = function (data) {
        if (data == "" || data == null) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter correct time');
            return false;
        }
        else {
            return true;
        }
    };
    ClassComponent.prototype.getDifference = function () {
        var startTime = this.timepicker.reschedStartTime.hour + ":" + this.timepicker.reschedStartTime.minute + " " + this.timepicker.reschedStartTime.meridian;
        var endTime = this.timepicker.reschedEndTime.hour + ":" + this.timepicker.reschedEndTime.minute + " " + this.timepicker.reschedEndTime.meridian;
        var start = __WEBPACK_IMPORTED_MODULE_3_moment__["utc"](startTime, "HH:mm A");
        var end = __WEBPACK_IMPORTED_MODULE_3_moment__["utc"](endTime, "HH:mm A");
        if (end.isBefore(start)) {
            end.add(1, 'day');
        }
        var d = __WEBPACK_IMPORTED_MODULE_3_moment__["duration"](end.diff(start));
        return d._milliseconds / 60000;
    };
    ClassComponent.prototype.isTimeValid = function () {
        if (this.timepicker.reschedStartTime.hour.trim() != '' && this.timepicker.reschedStartTime.minute.trim() != '' && this.timepicker.reschedStartTime.meridian.trim() != '' && this.timepicker.reschedEndTime.hour.trim() != '' && this.timepicker.reschedEndTime.minute.trim() != '' && this.timepicker.reschedEndTime.meridian.trim() != '') {
            var startTime = this.timepicker.reschedStartTime.hour + ":" + this.timepicker.reschedStartTime.minute + " " + this.timepicker.reschedStartTime.meridian;
            var endTime = this.timepicker.reschedEndTime.hour + ":" + this.timepicker.reschedEndTime.minute + " " + this.timepicker.reschedEndTime.meridian;
            var start = __WEBPACK_IMPORTED_MODULE_3_moment__["utc"](startTime, "HH:mm A");
            var end = __WEBPACK_IMPORTED_MODULE_3_moment__["utc"](endTime, "HH:mm A");
            if ((parseInt(start.format("HH")) < parseInt(end.format("HH")))) {
                return true;
            }
            else if ((parseInt(start.format("HH")) == parseInt(end.format("HH"))) && (parseInt(start.format("mm")) < parseInt(end.format("mm")))) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    };
    ClassComponent.prototype.reSheduleFormValid = function () {
        /* Date Validation */
        if (this.reschedDate != '' && this.reschedDate != 'Invalid Date') {
            /* Reschedule Reason */
            if (this.reschedReason.trim() != '') {
                /* Validate Time */
                if (this.isTimeValid()) {
                    return true;
                }
                else {
                    this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter a complete start and end time for rescheduling');
                    return false;
                }
            }
            else {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, 'Reschedule Reason Missing', 'Please mention a reason for rescheduling the class');
                return false;
            }
        }
        else {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, 'Date Missing', 'Please select a date to reschedule class');
            return false;
        }
    };
    // FOR NOTIFY POP UP
    ClassComponent.prototype.closeRemiderClass = function () {
        this.isReminderPop = false;
        this.reminderRemarks = "";
        this.remarksLimit = 50;
    };
    ClassComponent.prototype.countRemarksLimit = function () {
        this.remarksLimit = 50 - this.reminderRemarks.length;
    };
    ClassComponent.prototype.sendReminder = function () {
        var _this = this;
        var obj = {
            batch_id: this.classMarkedForAction.batch_id,
            class_schedule_id: this.classMarkedForAction.schedule_id,
            is_exam_schedule: "N",
            remarks: this.reminderRemarks
        };
        this.jsonFlag.isRippleLoad = true;
        this.widgetService.notifyStudentSchedule(obj).subscribe(function (res) {
            _this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Reminder Sent', 'Students have been notified');
            _this.closeRemiderClass();
        }, function (err) {
            _this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassComponent.prototype.initiateCourseRemiderClass = function () {
        var _this = this;
        var obj = {
            course_ids: this.classMarkedForAction.course_id,
            inst_id: this.jsonFlag.institute_id,
            master_course: this.classMarkedForAction.master_course_name,
            requested_date: __WEBPACK_IMPORTED_MODULE_3_moment__(this.classMarkedForAction.date).format("YYYY-MM-DD"),
            remarks: this.reminderRemarks
        };
        this.jsonFlag.isRippleLoad = true;
        this.widgetService.remindCourseLevel(obj).subscribe(function (res) {
            _this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Reminder Sent', 'The student have been notified');
            _this.reminderRemarks = "";
            _this.closeRemiderClass();
        }, function (err) {
            _this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, 'Unable to Send Reminder', err.error.message);
        });
    };
    // Cancel class  For Course Model pop Section
    ClassComponent.prototype.closeCancelClass = function () {
        // this.isCancelPop = false;
        this.cancellationReason = '';
    };
    ClassComponent.prototype.cancelClass = function () {
        var _this = this;
        var obj = {
            batch_id: this.classMarkedForAction.batch_id,
            cancelSchd: []
        };
        var schd = {
            cancel_note: this.cancellationReason,
            schd_id: this.classMarkedForAction.schedule_id,
            is_notified: this.is_notified
        };
        obj.cancelSchd.push(schd);
        // this.jsonFlag.isRippleLoad = true;
        this.widgetService.cancelClassSchedule(obj).subscribe(function (res) {
            // this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, '', 'The requested scheduled has been cancelled');
            _this.closeCancelClass();
            _this.getData();
        }, function (err) {
            // this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassComponent.prototype.notifyCancelUpdate = function (e) {
        if (e.target.checked) {
            this.is_notified = "Y";
        }
        else {
            this.is_notified = "N";
        }
    };
    //  Cancel class for batch model pop up
    ClassComponent.prototype.closeCourseCancelClass = function () {
        this.isCourseCancel = false;
        this.cancellationReason = '';
    };
    ClassComponent.prototype.cancelCourseClass = function () {
        var _this = this;
        var obj = {
            cancel_reason: this.cancellationReason,
            course_ids: this.classMarkedForAction.course_id,
            inst_id: this.jsonFlag.institute_id,
            is_cancel_notify: this.is_notified,
            master_course: this.classMarkedForAction.master_course_name,
            requested_date: __WEBPACK_IMPORTED_MODULE_3_moment__(this.classMarkedForAction.date).format("YYYY-MM-DD")
        };
        // this.jsonFlag.isRippleLoad = true;
        this.widgetService.cancelCourseSchedule(obj).subscribe(function (res) {
            // this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Course ', 'The requested scheduled has been cancelled');
            _this.closeCourseCancelClass();
            _this.getData();
        }, function (err) {
            // this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassComponent.prototype.cancelBatchClass = function () {
        var _this = this;
        if (this.cancellationReason == "" || this.cancellationReason == null) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, 'Cancellation Reason', 'Please enter cancellation reason');
            return;
        }
        var obj = {
            batch_id: this.classMarkedForAction.batch_id,
            cancelSchd: this.getCancelReason()
        };
        // this.jsonFlag.isRippleLoad = true;
        this.widgetService.cancelBatchSchedule(obj).subscribe(function (res) {
            _this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Batch ', 'The requested scheduled has been cancelled');
            _this.closeCourseCancelClass();
            _this.getData();
        }, function (err) {
            _this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassComponent.prototype.getCancelReason = function () {
        var temp = [];
        var obj = {
            cancel_note: this.cancellationReason,
            is_notified: this.is_notified,
            schd_id: this.classMarkedForAction.schedule_id
        };
        temp.push(obj);
        return temp;
    };
    //  Notify to Cancel Class
    ClassComponent.prototype.notifyCancelClass = function (selected) {
        var _this = this;
        if (confirm('Are you sure you want to notify?')) {
            var obj = {};
            if (!this.jsonFlag.isProfessional) {
                obj = {
                    "institute_id": this.jsonFlag.institute_id,
                    "schedule_id": selected.schedule_id,
                    "to_date": selected.date,
                    "course_id": selected.course_id
                };
            }
            else {
                obj = {
                    "institute_id": this.jsonFlag.institute_id,
                    "schedule_id": selected.schedule_id,
                    "to_date": selected.date,
                    "batch_id": selected.batch_id
                };
            }
            this.jsonFlag.isRippleLoad = true;
            this.classService.notifyCancelClass(obj, 'class').subscribe(function (res) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Cancelled schedule notification', 'Notification has been sent successfully');
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            });
        }
    };
    // Mark Attendance Section
    ClassComponent.prototype.initiateMarkAttendance = function (selected) {
        var obj = {
            batch_id: selected.batch_id,
            schd_id: selected.schedule_id,
            batch_name: selected.batch_name,
            subject_id: selected.subject_id,
            topics_covered: selected.topic_covered_ids,
            course_name: selected.course_name,
            master_course_name: selected.master_course_name,
            forCourseWise: false,
            forSubjectWise: true,
            isExam: false,
            is_attendance_marked: selected.is_attendance_marked
        };
        var batch_info = JSON.stringify(obj);
        this.storeSession();
        sessionStorage.setItem('batch_info', btoa(batch_info));
        sessionStorage.setItem('isSubjectView', String(true));
        this.router.navigate(['/view/home/mark-attendance']);
    };
    ClassComponent.prototype.redirect = function () {
        this.storeSession();
        this.router.navigate(['/view/course/create/class/add']);
    };
    ClassComponent.prototype.storeSession = function () {
        this.sessionFiltersArr.isCompleted = this.filterStatusInputs.completed;
        this.sessionFiltersArr.isPending = this.filterStatusInputs.attendancePending;
        this.sessionFiltersArr.isCancelled = this.filterStatusInputs.cancelled;
        this.sessionFiltersArr.isUpcoming = this.filterStatusInputs.upcoming;
        this.sessionFiltersArr.from_date = String(this.coursePlannerFilters.from_date);
        this.sessionFiltersArr.to_date = String(this.coursePlannerFilters.to_date);
        this.sessionFiltersArr.masterCourse = this.inputElements.masterCourse;
        this.sessionFiltersArr.courseId = this.inputElements.course;
        this.sessionFiltersArr.batchId = this.inputElements.subject;
        this.sessionFiltersArr.standardId = this.inputElements.standard_id;
        this.sessionFiltersArr.subjectId = this.inputElements.subject_id;
        if (!this.jsonFlag.isProfessional) {
            this.sessionFiltersArr.batchId = this.inputElements.subject;
        }
        else {
            this.sessionFiltersArr.batchId = this.inputElements.batch_id;
        }
        this.sessionFiltersArr.facultyId = this.inputElements.faculty;
        this.sessionFiltersArr.thisWeek = this.filterDateInputs.thisWeek;
        this.sessionFiltersArr.lastWeek = this.filterDateInputs.lastWeek;
        this.sessionFiltersArr.thisMonth = this.filterDateInputs.thisMonth;
        this.sessionFiltersArr.custom = this.filterDateInputs.custom;
        var filter_info = JSON.stringify(this.sessionFiltersArr);
        sessionStorage.setItem('isFromCoursePlanner', String(true));
        sessionStorage.setItem('isClass', String(true));
        sessionStorage.setItem('coursePlannerFilter', filter_info);
    };
    ClassComponent.prototype.closeAll = function () {
        this.filterShow = false;
    };
    ClassComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-class',
            template: __webpack_require__("./src/app/components/course-module/course-planner/class/class.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/course-planner/class/class.component.scss")],
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_5__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_6__services_message_show_service__["a" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_4__services_course_services_class_schedule_service__["a" /* ClassScheduleService */],
            __WEBPACK_IMPORTED_MODULE_9__services_widget_service__["a" /* WidgetService */]])
    ], ClassComponent);
    return ClassComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/course-planner/course-planner-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CoursePlannerRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__course_planner_component__ = __webpack_require__("./src/app/components/course-module/course-planner/course-planner.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__class_class_component__ = __webpack_require__("./src/app/components/course-module/course-planner/class/class.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__exam_exam_component__ = __webpack_require__("./src/app/components/course-module/course-planner/exam/exam.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var CoursePlannerRoutingModule = /** @class */ (function () {
    function CoursePlannerRoutingModule() {
    }
    CoursePlannerRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__course_planner_component__["a" /* CoursePlannerComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                component: __WEBPACK_IMPORTED_MODULE_3__class_class_component__["a" /* ClassComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_3__class_class_component__["a" /* ClassComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'class',
                                component: __WEBPACK_IMPORTED_MODULE_3__class_class_component__["a" /* ClassComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'exam',
                                component: __WEBPACK_IMPORTED_MODULE_4__exam_exam_component__["a" /* ExamComponent */],
                                pathMatch: 'prefix'
                            }
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], CoursePlannerRoutingModule);
    return CoursePlannerRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/course-planner/course-planner.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/course-planner/course-planner.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  padding: 1%; }\n\n.header-section {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  width: 20%;\n  margin-left: 40%;\n  margin-bottom: 20px; }\n\n.header-section .header-item {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    padding: 5px;\n    width: 50%;\n    cursor: pointer; }\n\n.header-section .header-item .img-container img {\n      width: 20px;\n      height: 20px;\n      margin: 0px 10px; }\n\n.header-section .header-item .model-name-container {\n      width: 50%;\n      margin-top: 3px; }\n\n.header-section .header-item .model-name-container span {\n        font-size: 14px;\n        font-weight: 600; }\n\n.header-section #class {\n    border-top-left-radius: 25px;\n    border-bottom-left-radius: 25px;\n    border: 2px solid #3a65f8; }\n\n.header-section #exam {\n    border-top-right-radius: 25px;\n    border-bottom-right-radius: 25px;\n    border: 2px solid #3a65f8; }\n\n.active {\n  background: #3a66fa;\n  color: #fdfdfd; }\n\n.non-active {\n  background: #ffffff;\n  color: #b0b0b0; }\n\n.middle {\n  margin-top: 10px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/course-planner/course-planner.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CoursePlannerComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var CoursePlannerComponent = /** @class */ (function () {
    function CoursePlannerComponent(auth, appC, router) {
        this.auth = auth;
        this.appC = appC;
        this.router = router;
        this.isRippleLoad = false;
        this.isProfessional = false;
        this.activeModule = true; //  true for class   // false for exam
    }
    CoursePlannerComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.checkForSessionStorage();
    };
    CoursePlannerComponent.prototype.checkForSessionStorage = function () {
        var isClass = sessionStorage.getItem('isClass');
        if (isClass != null && isClass != "") {
            isClass = JSON.parse(isClass);
            if (isClass) {
                this.showMenuOf('class');
            }
            else {
                this.showMenuOf('exam');
            }
        }
        sessionStorage.setItem('isClass', "");
    };
    CoursePlannerComponent.prototype.showMenuOf = function (activeModuleName) {
        if (activeModuleName == 'class') {
            this.activeModule = true;
        }
        else if (activeModuleName == 'exam') {
            this.activeModule = false;
        }
    };
    CoursePlannerComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-course-planner',
            template: __webpack_require__("./src/app/components/course-module/course-planner/course-planner.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/course-planner/course-planner.component.scss")],
            encapsulation: __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewEncapsulation"].Emulated
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_3__angular_router__["Router"]])
    ], CoursePlannerComponent);
    return CoursePlannerComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/course-planner/course-planner.model.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CoursePlanner; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_moment__);

var CoursePlanner = /** @class */ (function () {
    function CoursePlanner() {
        this.standard_id = "-1";
        this.subject_id = "-1";
        this.master_course_name = "-1";
        this.course_id = "-1";
        this.batch_id = "-1";
        this.from_date = __WEBPACK_IMPORTED_MODULE_0_moment__().isoWeekday("Monday").format("YYYY-MM-DD");
        this.to_date = __WEBPACK_IMPORTED_MODULE_0_moment__().weekday(7).format("YYYY-MM-DD");
        this.isCompleted = "Y";
        this.isPending = "Y";
        this.isCancelled = "Y";
        this.isUpcoming = "Y";
        this.isMarksUpdate = "Y";
        this.teacher_id = "-1";
    }
    return CoursePlanner;
}());

;


/***/ }),

/***/ "./src/app/components/course-module/course-planner/course-planner.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoursePlannerModule", function() { return CoursePlannerModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__course_planner_routing_module__ = __webpack_require__("./src/app/components/course-module/course-planner/course-planner-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__course_planner_component__ = __webpack_require__("./src/app/components/course-module/course-planner/course-planner.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__class_class_component__ = __webpack_require__("./src/app/components/course-module/course-planner/class/class.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__exam_exam_component__ = __webpack_require__("./src/app/components/course-module/course-planner/exam/exam.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__services_course_services_class_schedule_service__ = __webpack_require__("./src/app/services/course-services/class-schedule.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__services_widget_service__ = __webpack_require__("./src/app/services/widget.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












var CoursePlannerModule = /** @class */ (function () {
    function CoursePlannerModule() {
    }
    CoursePlannerModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_6__course_planner_routing_module__["a" /* CoursePlannerRoutingModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_7__course_planner_component__["a" /* CoursePlannerComponent */],
                __WEBPACK_IMPORTED_MODULE_8__class_class_component__["a" /* ClassComponent */],
                __WEBPACK_IMPORTED_MODULE_9__exam_exam_component__["a" /* ExamComponent */],
            ],
            entryComponents: [
                __WEBPACK_IMPORTED_MODULE_7__course_planner_component__["a" /* CoursePlannerComponent */]
            ],
            exports: [],
            providers: [
                __WEBPACK_IMPORTED_MODULE_10__services_course_services_class_schedule_service__["a" /* ClassScheduleService */],
                __WEBPACK_IMPORTED_MODULE_11__services_widget_service__["a" /* WidgetService */]
            ]
        })
    ], CoursePlannerModule);
    return CoursePlannerModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/course-planner/exam/exam.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n\r\n\r\n<div class=\"middle-section clear-fix\">\r\n\r\n  <section class=\"middle-top clearFix bulk-header\">\r\n\r\n    <div>\r\n      <h1 class=\"pull-left\">\r\n        <a routerLink=\"/view/course\"  *ngIf=\"!jsonFlag.isProfessional\" style=\"padding:0px; \">\r\n          Course\r\n        </a>\r\n        <a routerLink=\"/view/batch\" *ngIf=\"jsonFlag.isProfessional\" style=\"padding:0px; \">\r\n          Batch\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n         <span>Exam Planner</span>\r\n      </h1>\r\n    </div>\r\n\r\n  </section>\r\n\r\n  <section>\r\n    <div class=\"header-section\">\r\n      <div class=\"header-item non-active\" id=\"class\" routerLink=\"/view/course/coursePlanner/class\">\r\n        <div class=\"img-container\">\r\n          <img src=\"./assets/images/course_planner/class.svg\" alt=\"class\" >\r\n        </div>\r\n        <div class=\"model-name-container\">\r\n          <span>Class</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"header-item active\" id=\"exam\" routerLink=\"/view/course/coursePlanner/exam\">\r\n        <div class=\"img-container\">\r\n          <img src=\"./assets/images/course_planner/exam_white.svg\" alt=\"exam\">\r\n        </div>\r\n        <div class=\"model-name-container\">\r\n          <span>Exam</span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <section>\r\n    <section class=\"filter-head\">\r\n      <div class=\"filter-header-container\">\r\n        <div class=\"filter-item-1\">\r\n          <!-- FOR COURSE MODEL -->\r\n          <div class=\"header-item\" *ngIf=\"!jsonFlag.isProfessional\">\r\n            <span>Master Course <span class=\"danger\">*</span></span>\r\n            <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.masterCourse\" (ngModelChange)=\"updateCoursesList()\">\r\n              <option value=\"-1\">Select Master Course</option>\r\n              <option [value]=\"masterCourse.master_course\" *ngFor=\"let masterCourse of masterCourseList\">{{masterCourse.master_course}}</option>\r\n            </select>\r\n          </div>\r\n          <div class=\"header-item\" *ngIf=\"!jsonFlag.isProfessional\">\r\n            <span>Course</span>\r\n            <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.course\" (ngModelChange)=\"updateSubjectsList()\">\r\n              <option value=\"-1\">Select Course</option>\r\n              <option [value]=\"course.course_id\" *ngFor=\"let course of courseList\">{{course.course_name}}</option>\r\n            </select>\r\n            <span *ngIf=\"inputElements.course != '-1' && !jsonFlag.isProfessional\" style=\"font-size: 10px;\">Duration: {{courseStartDate}} {{courseEndDate}}</span>\r\n          </div>\r\n          <div class=\"header-item\" *ngIf=\"!jsonFlag.isProfessional\">\r\n            <span>Subject</span>\r\n            <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.subject\" (ngModelChange)=\"updateSubject()\">\r\n              <option value=\"-1\">Select Subject</option>\r\n              <option [value]=\"subject.batch_id\" *ngFor=\"let subject of subjectList\">{{subject.subject_name}}</option>\r\n            </select>\r\n          </div>\r\n\r\n          <!-- FOR BATCH MODEL -->\r\n          <div class=\"header-item\" *ngIf=\"jsonFlag.isProfessional\">\r\n            <span>Master Course <span class=\"danger\">*</span></span>\r\n            <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.standard_id\" (ngModelChange)=\"updateCoursesList()\">\r\n              <option value=\"-1\">Select Master Course</option>\r\n              <option [value]=\"standard.standard_id\" *ngFor=\"let standard of masterCourseList\">{{standard.standard_name}}</option>\r\n            </select>\r\n            <span *ngIf=\"inputElements.standard_id != '-1' && jsonFlag.isProfessional\" style=\"font-size: 10px;\">Duration: {{courseStartDate}} {{courseEndDate}}</span>\r\n          </div>\r\n          <div class=\"header-item\" *ngIf=\"jsonFlag.isProfessional\">\r\n            <span>Course</span>\r\n            <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.subject_id\" (ngModelChange)=\"updateSubjectsList()\">\r\n              <option value=\"-1\">Select Course</option>\r\n              <option [value]=\"subject.subject_id\" *ngFor=\"let subject of courseList\">{{subject.subject_name}}</option>\r\n            </select>\r\n          </div>\r\n          <div class=\"header-item\" *ngIf=\"jsonFlag.isProfessional\">\r\n            <span>Batch</span>\r\n            <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.batch_id\" (ngModelChange)=\"updateSubject()\">\r\n              <option value=\"-1\">Select Batch</option>\r\n              <option [value]=\"batch.batch_id\" *ngFor=\"let batch of batchList\">{{batch.batch_name}}</option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"header-item\" style=\"width: 25%;\">\r\n            <span>Filter</span>\r\n            <div class=\"input-container\">\r\n              <i class=\"fa fa-filter\" aria-hidden=\"true\"></i>\r\n              <input type=\"text\" name=\"\" value=\"\" class=\"filer-input\" placeholder=\"Choose filter from dropdown\">\r\n              <i class=\"fa fa-caret-down\" aria-hidden=\"true\" (click)=\"toggleFilter()\" *ngIf=\"!filterShow\"></i>\r\n              <i class=\"fa fa-caret-up\" aria-hidden=\"true\" (click)=\"toggleFilter()\" *ngIf=\"filterShow\"></i>\r\n            </div>\r\n            <span style=\"font-size: 10px;\">From: {{coursePlannerFilters.from_date | date: 'dd-MMM-yyyy'}} &nbsp; To: {{coursePlannerFilters.to_date | date: 'dd-MMM-yyyy'}}</span>\r\n            <div class=\"filter-container\" *ngIf=\"filterShow\">\r\n\r\n              <div class=\"date-container\">\r\n                <div class=\"date-title\">\r\n                  <span>Date</span>\r\n                </div>\r\n                <div class=\"date-values-container\">\r\n                  <div class=\"field-checkbox-wrapper date-value-item\">\r\n                    <input type=\"checkbox\" id=\"thisWeek\" name=\"thisWeek\" [(ngModel)]=\"filterDateInputs.thisWeek\"\r\n                        class=\"form-checkbox\" (change)=\"updateDateFilter('thisWeek', $event)\">\r\n                    <label for=\"thisWeek\">This Week</label>\r\n                  </div>\r\n                  <div class=\"field-checkbox-wrapper date-value-item\">\r\n                    <input type=\"checkbox\" id=\"lastWeek\" name=\"lastWeek\" [(ngModel)]=\"filterDateInputs.lastWeek\"\r\n                        class=\"form-checkbox\" (change)=\"updateDateFilter('lastWeek', $event)\">\r\n                    <label for=\"lastWeek\">Last Week</label>\r\n                  </div>\r\n                  <div class=\"field-checkbox-wrapper date-value-item\">\r\n                    <input type=\"checkbox\" id=\"thisMonth\" name=\"thisMonth\" [(ngModel)]=\"filterDateInputs.thisMonth\"\r\n                        class=\"form-checkbox\" (change)=\"updateDateFilter('thisMonth', $event)\">\r\n                    <label for=\"thisMonth\">This Month</label>\r\n                  </div>\r\n                  <div class=\"field-checkbox-wrapper date-value-item\">\r\n                    <input type=\"checkbox\" id=\"custom\" name=\"custom\" [(ngModel)]=\"filterDateInputs.custom\"\r\n                        class=\"form-checkbox\" (change)=\"updateDateFilter('custom', $event)\">\r\n                    <label for=\"custom\">Custom</label>\r\n                    <input style=\"margin-left:10%;visibility:hidden;\" type=\"text\" value=\"\" id=\"customeDate\" class=\"widgetDatepicker bsDatepicker\" name=\"schedWidDate\"\r\n                      [(ngModel)]=\"filterDateRange\" (ngModelChange)=\"updateFilterDateRange($event)\" readonly=\"true\" bsDaterangepicker/>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"status-container\">\r\n                <div class=\"status-title\">\r\n                  <span>Status</span>\r\n                </div>\r\n                <div class=\"status-values-container\">\r\n                  <div class=\"field-checkbox-wrapper status-value-item\">\r\n                    <input type=\"checkbox\" id=\"upcoming\" name=\"\" [(ngModel)]=\"filterStatusInputs.upcoming\"\r\n                        class=\"form-checkbox\" (change)=\"updateStatusFilter($event, 'upcoming')\">\r\n                    <label for=\"upcoming\" style=\"color: #ff6c24;\">Upcoming</label>\r\n                  </div>\r\n                  <div class=\"field-checkbox-wrapper status-value-item\">\r\n                    <input type=\"checkbox\" id=\"attendancePending\" name=\"\" [(ngModel)]=\"filterStatusInputs.attendancePending\"\r\n                        class=\"form-checkbox\" (change)=\"updateStatusFilter($event, 'pending')\">\r\n                    <label for=\"attendancePending\" style=\"color: #8d8d8d;\">Attendance Pending</label>\r\n                  </div>\r\n                  <div class=\"field-checkbox-wrapper status-value-item\">\r\n                    <input type=\"checkbox\" id=\"completed\" name=\"\" [(ngModel)]=\"filterStatusInputs.marksUpdated\"\r\n                        class=\"form-checkbox\" (change)=\"updateStatusFilter($event, 'marksUpdated')\">\r\n                    <label for=\"completed\" style=\"color: #00b55a;\">Marks Updated</label>\r\n                  </div>\r\n                  <div class=\"field-checkbox-wrapper status-value-item\">\r\n                    <input type=\"checkbox\" id=\"marksPending\" name=\"\" [(ngModel)]=\"filterStatusInputs.marksPending\"\r\n                        class=\"form-checkbox\" (change)=\"updateStatusFilter($event, 'marksPending')\">\r\n                    <label for=\"marksPending\" style=\"color: #8771FF;\">Marks Pending</label>\r\n                  </div>\r\n                  <div class=\"field-checkbox-wrapper status-value-item\">\r\n                    <input type=\"checkbox\" id=\"cancelled\" name=\"\" [(ngModel)]=\"filterStatusInputs.cancelled\"\r\n                        class=\"form-checkbox\" (change)=\"updateStatusFilter($event, 'cancelled')\">\r\n                    <label for=\"cancelled\" style=\"color: #df0d2f;\">Cancelled</label>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n\r\n              <!-- <div class=\"faculty-container\">\r\n                <div class=\"faculty-title\">\r\n                  <span>Faculty</span>\r\n                </div>\r\n                <div class=\"faculty-dropdown-container\">\r\n                  <select class=\"faculty-select-box\" name=\"\" [(ngModel)]=\"inputElements.faculty\" (ngModelChange)=\"updateFacultyInFilter()\">\r\n                    <option value=\"-1\">Select Faculty</option>\r\n                    <option [value]=\"faculty.teacher_id\" *ngFor=\"let faculty of facultyList\">{{faculty.teacher_name}}</option>\r\n                  </select>\r\n                </div>\r\n              </div> -->\r\n\r\n            </div>\r\n          </div>\r\n          <div class=\"go-btn-container\">\r\n            <button type=\"button\" name=\"button\" class=\"fullBlue gobtn\" (click)=\"getData()\">GO</button>\r\n          </div>\r\n        </div>\r\n        <div class=\"filter-item-2\">\r\n          <button type=\"button\" name=\"button\" class=\"add-class-btn\" (click)=\"redirect()\">\r\n            <i class=\"fa fa-plus\" aria-hidden=\"true\"></i>\r\n            &nbsp;\r\n            Add Exam\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </section>\r\n\r\n    <section class=\"table-holder\" *ngIf=\"coursePlannerData?.length > 0\" (click)=\"closeAll()\">\r\n      <div class=\"table-container\">\r\n        <div class=\"table-header-container\">\r\n          <div class=\"table-heading-item small\" style=\"padding-left: 15px;\">\r\n            <span>Date</span>\r\n          </div>\r\n          <div class=\"table-heading-item small\">\r\n            <span>Time</span>\r\n          </div>\r\n          <div class=\"table-heading-item medium\">\r\n            <span>Course</span>\r\n          </div>\r\n          <div class=\"table-heading-item medium\" *ngIf=\"showHideColumns.subject\">\r\n            <span *ngIf=\"!jsonFlag.isProfessional\">Subject(s)</span>\r\n            <span *ngIf=\"jsonFlag.isProfessional\">Batch</span>\r\n          </div>\r\n          <div class=\"table-heading-item medium\" *ngIf=\"showHideColumns.topic\">\r\n            <span>Topic(s)</span>\r\n          </div>\r\n          <div class=\"table-heading-item medium\" *ngIf=\"showHideColumns.description\">\r\n            <span>Description</span>\r\n          </div>\r\n          <div class=\"table-heading-item small\">\r\n            <span>Total Marks</span>\r\n          </div>\r\n          <!-- <div class=\"table-heading-item small\">\r\n            <span>Passing Marks</span>\r\n          </div> -->\r\n          <div class=\"table-heading-item small\">\r\n            <span>Room No.</span>\r\n          </div>\r\n          <div class=\"table-heading-item small align-center\">\r\n            <span>Status</span>\r\n          </div>\r\n          <div class=\"table-heading-item medium align-center action\">\r\n            <span>Action</span>\r\n            <i class=\"fa fa-cog\" aria-hidden=\"true\" (click)=\"showHideCol()\" *ngIf=\"jsonFlag.setting\"></i>\r\n            <div class=\"show-hide-container\" *ngIf=\"jsonFlag.showHideColumn\">\r\n              <div class=\"show-hide-header\">\r\n                <span>Choose Show/Hide Column</span>\r\n                <i class=\"fa fa-times\" aria-hidden=\"true\" (click)=\"hideShowHideMenu()\"></i>\r\n              </div>\r\n              <div class=\"show-hide-value-container\">\r\n                  <div class=\"field-checkbox-wrapper show-hide-item\">\r\n                  <input type=\"checkbox\" id=\"subject\" name=\"\" [(ngModel)]=\"showHideColumns.subject\"\r\n                      class=\"form-checkbox\" (change)=\"hideCol($event)\" [disabled]=\"!showHideColumns.subject && checkedColCounter == 1\">\r\n                  <label for=\"subject\"  *ngIf=\"!jsonFlag.isProfessional\">Subject</label>\r\n                  <label for=\"subject\"  *ngIf=\"jsonFlag.isProfessional\">Batch</label>\r\n                </div>\r\n                <div class=\"field-checkbox-wrapper show-hide-item\">\r\n                  <input type=\"checkbox\" id=\"topic\" name=\"\" [(ngModel)]=\"showHideColumns.topic\"\r\n                      class=\"form-checkbox\" (change)=\"hideCol($event)\" [disabled]=\"!showHideColumns.topic && checkedColCounter == 1\">\r\n                  <label for=\"topic\">Topic</label>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"show-hide-value-container\">\r\n                <div class=\"show-hide-item\" style=\"margin-bottom: 10px;\">\r\n                  <span style=\"font-weight: 600;color:#585574;\">NOTE : </span>\r\n                  <span style=\"font-weight: 400;color:#585574;\">To selct the below option(s) please unselect above option(s)</span>\r\n                </div>\r\n                <div class=\"field-checkbox-wrapper show-hide-item\">\r\n                  <input type=\"checkbox\" id=\"description\" name=\"\" [(ngModel)]=\"showHideColumns.description\"\r\n                      class=\"form-checkbox\" (change)=\"hideCol($event)\" [disabled]=\"!showHideColumns.description && checkedColCounter == 1\">\r\n                  <label for=\"description\">Description</label>\r\n                </div>\r\n                <!-- <div class=\"field-checkbox-wrapper show-hide-item\">\r\n                  <input type=\"checkbox\" id=\"homework\" name=\"\" [(ngModel)]=\"showHideColumns.roomNo\"\r\n                      class=\"form-checkbox\" (change)=\"hideCol($event)\" [disabled]=\"!showHideColumns.roomNo && checkedColCounter == 2\">\r\n                  <label for=\"homework\">Room No.</label>\r\n                </div> -->\r\n              </div>\r\n\r\n              <div class=\"bg-container\">\r\n                <img src=\"./assets/images/course_planner/setting-illustration.svg\" alt=\"\">\r\n              </div>\r\n\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"table-value-outer-container\">\r\n          <div class=\"table-value-container\"\r\n            [ngClass]=\"{'border-cancelled-class': course.status == 'Cancelled' || course.status == 'Cancel(Class)',\r\n                        'border-completed-class': course.status == 'Mks. Updated',\r\n                        'border-marksPending-class': course.status == 'Mks. pending',\r\n                        'border-pending-class': course.status == 'Att. Pending',\r\n                        'border-upcoming-class': course.status == 'Upcoming'}\"\r\n            *ngFor=\"let course of coursePlannerData; let i = index;\">\r\n            <div class=\"table-value-item small flex-item\" style=\"padding-left: 15px;\">\r\n              <span>{{course.date | date: 'dd-MMM-yyyy' }}</span>\r\n              <!-- <span>&nbsp;</span> -->\r\n              <span>({{course.date | date :'EEEE'}})</span>\r\n            </div>\r\n            <div class=\"table-value-item small flex-item\">\r\n              <span>{{course.start_time}}</span>\r\n              <!-- <span>&nbsp;- &nbsp;</span>   -->\r\n              <span>{{course.end_time}}</span>\r\n            </div>\r\n            <div class=\"table-value-item medium\">\r\n              <span title=\"{{course.course_name}}\">{{ (course.course_name.length > 50) ? (course.course_name | slice:0:50) + '...' : course.course_name }}</span>\r\n            </div>\r\n            <div class=\"table-value-item medium\"  *ngIf=\"showHideColumns.subject\">\r\n              <span *ngIf=\"!jsonFlag.isProfessional\" title=\"{{course.subject_name}}\">{{ (course.subject_name.length > 50) ? (course.subject_name | slice:0:50) + '...' : course.subject_name }}</span>\r\n              <span *ngIf=\"jsonFlag.isProfessional\" title=\"{{course.batch_name}}\">{{ (course.batch_name.length > 50) ? (course.batch_name | slice:0:50) + '...' : course.batch_name }}</span>\r\n            </div>\r\n            <div class=\"table-value-item medium\"  *ngIf=\"showHideColumns.topic\">\r\n              <span title=\"{{course.topics_covered}}\">{{ (course.topics_covered.length > 50) ? (course.topics_covered | slice:0:50) + '...' : course.topics_covered }}</span>\r\n            </div>\r\n            <div class=\"table-value-item medium\" *ngIf=\"showHideColumns.description\">\r\n              <span title=\"{{course.description}}\">{{ (course.description.length > 50) ? (course.description | slice:0:50) + '...' : course.description }}</span>\r\n            </div>\r\n            <div class=\"table-value-item small\">\r\n              <span>{{course.total_marks}}</span>\r\n            </div>\r\n            <!-- <div class=\"table-value-item small\">\r\n              <span>-</span>\r\n            </div> -->\r\n            <div class=\"table-value-item small\">\r\n              <span>{{course.room_no}}</span>\r\n            </div>\r\n            <div class=\"table-value-item small align-center\">\r\n              <button type=\"button\" name=\"button\" class=\"upcoming-btn\" *ngIf=\"course.status == 'Upcoming'\">Upcoming</button>\r\n              <button type=\"button\" name=\"button\" class=\"pending-btn\" *ngIf=\"course.status == 'Att. Pending'\">Att. Pending</button>\r\n              <button type=\"button\" name=\"button\" class=\"cancelled-btn\" *ngIf=\"course.status == 'Cancelled' || course.status == 'Cancel(Class)'\">Cancelled</button>\r\n              <button type=\"button\" name=\"button\" class=\"completed-btn\" *ngIf=\"course.status == 'Mks. Updated'\">Mks. Updated</button>\r\n              <button type=\"button\" name=\"button\" class=\"marksPending-btn\" *ngIf=\"course.status == 'Mks. pending'\">Mks. Pending</button>\r\n            </div>\r\n            <div class=\"table-value-item medium align-center action \">\r\n              <div class=\"action-container\" *ngIf=\"course.status == 'Upcoming'\">  <!--  upcoming exam action -->\r\n                <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4\" title=\"Notify\" *ngIf=\"!jsonFlag.isProfessional\" (click)=\"sendReminderForCourse(course)\"></i>\r\n                <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4\" title=\"Notify\" *ngIf=\"jsonFlag.isProfessional\" (click)=\"notifyExamSchedule(course)\"></i>\r\n                <!-- <i class=\"fa fa-pencil\" aria-hidden=\"true\" style=\"color: #1283f4;\" title=\"Edit\"></i> -->\r\n                <i class=\"fa fa-times-circle\" aria-hidden=\"true\" style=\"color: red;\" title=\"Cancel\" data-toggle=\"modal\" data-target=\"#cancelModal\" *ngIf=\"!jsonFlag.isProfessional\" (click)=\"onCancelExamClickCourse(course)\"></i>\r\n                <i class=\"fa fa-times-circle\" aria-hidden=\"true\" style=\"color: red;\" title=\"Cancel\" data-toggle=\"modal\" data-target=\"#cancelBatchModal\" *ngIf=\"jsonFlag.isProfessional\" (click)=\"onCancelExamClick(course)\"></i>\r\n              </div>\r\n              <div class=\"action-container\" *ngIf=\"course.status == 'Att. Pending'\">  <!--  pending exam action -->\r\n                <img src=\"./assets/images/att.svg\" alt=\"Mark Attendance\" title=\"Mark Attendance\" (click)=\"markAttendanceExamCourse(course)\">\r\n                <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4\" title=\"Notify\" *ngIf=\"!jsonFlag.isProfessional\" (click)=\"sendReminderForCourse(course)\"></i>\r\n                <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4\" title=\"Notify\" *ngIf=\"jsonFlag.isProfessional\" (click)=\"notifyExamSchedule(course)\"></i>\r\n                <!-- <i class=\"fa fa-pencil\" aria-hidden=\"true\" style=\"color: #1283f4;\" title=\"Edit\"></i> -->\r\n                <i class=\"fa fa-times-circle\" aria-hidden=\"true\" style=\"color: red;\" title=\"Cancel\" data-toggle=\"modal\" data-target=\"#cancelModal\" *ngIf=\"!jsonFlag.isProfessional\" (click)=\"onCancelExamClickCourse(course)\"></i>\r\n                <i class=\"fa fa-times-circle\" aria-hidden=\"true\" style=\"color: red;\" title=\"Cancel\" data-toggle=\"modal\" data-target=\"#cancelBatchModal\" *ngIf=\"jsonFlag.isProfessional\" (click)=\"onCancelExamClick(course)\"></i>\r\n              </div>\r\n              <div class=\"action-container\" *ngIf=\"course.status == 'Cancelled' || course.status == 'Cancel(Class)'\">  <!--  cancelled exam action -->\r\n                <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4\" title=\"Notify\" (click)=\"notifyCancelClass(course)\"></i>\r\n              </div>\r\n              <div class=\"action-container\" *ngIf=\"course.status == 'Mks. Updated'\">  <!--  marks updated exam action -->\r\n                <img src=\"./assets/images/checked-att.svg\" alt=\"Update Attendance\" title=\"Update Attendance\" (click)=\"markAttendanceExamCourse(course)\">\r\n                <img src=\"./assets/images/exam-update.svg\" alt=\"Update Exam Marks\" title=\"Exam Marks\" style=\"cursor:pointer\"  *ngIf=\"!jsonFlag.isProfessional\" (click)=\"examMarksUpdateCourse(course)\">\r\n                <img src=\"./assets/images/exam-update.svg\" alt=\"Update Exam Marks\" title=\"Exam Marks\" style=\"cursor:pointer\"  *ngIf=\"jsonFlag.isProfessional\" (click)=\"examMarksUpdate(course)\">\r\n                <!-- <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4\" title=\"Notify\" *ngIf=\"!jsonFlag.isProfessional\" (click)=\"sendReminderForCourse(course)\"></i>\r\n                <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4\" title=\"Notify\" *ngIf=\"jsonFlag.isProfessional\" (click)=\"notifyExamSchedule(course)\"></i> -->\r\n                <!-- <i class=\"fa fa-pencil\" aria-hidden=\"true\" style=\"color: #1283f4;\" title=\"Edit\"></i> -->\r\n              </div>\r\n              <div class=\"action-container\" *ngIf=\"course.status == 'Mks. pending'\">  <!--  marks pending exam action -->\r\n                <img src=\"./assets/images/checked-att.svg\" alt=\"Update Attendance\" title=\"Update Attendance\" (click)=\"markAttendanceExamCourse(course)\">\r\n                <img src=\"./assets/images/exam-non.svg\" alt=\"Exam Marks\" title=\"Exam Marks\" style=\"cursor:pointer\"  *ngIf=\"!jsonFlag.isProfessional\" (click)=\"examMarksUpdateCourse(course)\">\r\n                <img src=\"./assets/images/exam-non.svg\" alt=\"Exam Marks\" title=\"Exam Marks\" style=\"cursor:pointer\"  *ngIf=\"jsonFlag.isProfessional\" (click)=\"examMarksUpdate(course)\">\r\n                <!-- <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4\" title=\"Notify\" *ngIf=\"!jsonFlag.isProfessional\" (click)=\"sendReminderForCourse(course)\"></i>\r\n                <i class=\"fa fa-bell\" aria-hidden=\"true\" style=\"color: #1283f4\" title=\"Notify\" *ngIf=\"jsonFlag.isProfessional\" (click)=\"notifyExamSchedule(course)\"></i> -->\r\n                <!-- <i class=\"fa fa-pencil\" aria-hidden=\"true\" style=\"color: #1283f4;\" title=\"Edit\"></i> -->\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </section>\r\n\r\n  </section>\r\n\r\n  <div class=\"row filter-res pagination\" #pager id=\"pager\" style=\"width: 100%;\">\r\n    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n      <pagination (goPage)=\"fectchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\"\r\n        [pagesToShow]=\"10\" [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [sizeArr]=\"sizeArr\"\r\n        (sizeChange)=\"updateTableBatchSize($event)\" [count]=\"totalCount\">\r\n      </pagination>\r\n    </div>\r\n  </div>\r\n\r\n\r\n  <!-- Illustration container -->\r\n  <section *ngIf=\"coursePlannerData?.length == 0\" (click)=\"closeAll()\">\r\n    <div class=\"illustration-container\">\r\n      <img src=\"./assets/images/course_planner/blank-illustration.svg\" alt=\"illustration\" class=\"illustration-img\">\r\n    </div>\r\n  </section>\r\n\r\n\r\n  <!-- ALL POPUP SECTION -->\r\n  <!-- CANCEL EXAM POP UP Course Model -->\r\n  <div id=\"cancelModal\" class=\"modal\" role=\"dialog\" *ngIf=\"courseCommonExamCancelPopUP\">\r\n    <div class=\"modal-dialog\">\r\n\r\n      <!-- Modal content-->\r\n      <div class=\"modal-content\">\r\n        <div class=\"modal-header\">\r\n          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\r\n          <h4 class=\"modal-title\">Cancel Exam Schedule</h4>\r\n        </div>\r\n        <div class=\"modal-body\">\r\n\r\n          <div class=\"details row\">\r\n            <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n              <h5>Master Course : {{courseTempData.master_course_name}} </h5>\r\n            </div>\r\n            <div class=\"c-sm-6 c-md-6 c-lg-6\" style=\"text-align: right;\">\r\n              <h5>Exam Schedule Date : {{courseTempData.date | date: 'dd-MMM-yyyy'}} </h5>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"content-wraper\">\r\n            <div class=\"row button-Section\" style=\"margin-bottom: 10px;margin-top: 10px;\">\r\n              <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n                <h4>Course : {{courseTempData.course_name}}</h4>\r\n              </div>\r\n              <!-- <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n                <div class=\"pull-right\" *ngIf=\"showReasonSection == ''\">\r\n                  <button class=\"btn fullBlue\" (click)=\"cancelExamCourseWise()\">Cancel</button>\r\n                </div>\r\n              </div> -->\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"cancel-reason-container\">\r\n            <label for=\"cancelTxtBx\">Cancellation Reason<span class=\"text-danger\">*</span></label>\r\n            <textarea class=\"cancel-input\" [(ngModel)]=\"cancelPopUpData.reason\" id=\"cancelTxtBx\" name=\"cancelTxtBx\"></textarea>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"modal-footer\">\r\n\r\n          <div class=\"cancel-section\">\r\n            <div class=\"cancel-Class-Wrapper\">\r\n              <div class=\"clearfix\" style=\"padding-top: 10px;\">\r\n                <aside class=\"pull-left\" style=\"display: flex; flex-direction: row;\">\r\n                  <div class=\"field-checkbox-wrapper\" style=\"margin-top: 10px;\">\r\n                    <input type=\"checkbox\" value=\"\" id=\"chkBxNotifyStudent\" name=\"chkBxNotifyStudent\" class=\"form-checkbox\" [(ngModel)]=\"cancelPopUpData.notify\">\r\n                    <label for=\"chkBxNotifyStudent\">Notify Students</label>\r\n                  </div>\r\n                </aside>\r\n                <aside class=\"pull-right popup-btn\">\r\n                  <input type=\"button\" value=\"Close\" class=\"btn\" data-dismiss=\"modal\" (click)=\"closePopUpCommon()\">\r\n                  <input type=\"button\" value=\"Cancel Exam\" data-dismiss=\"modal\" (click)=\"cancelExamCall()\" class=\"fullBlue btn\" [disabled]=jsonFlag.isRippleLoad>\r\n                </aside>\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n\r\n\r\n  <!-- MODAL -->\r\n  <!-- CANCEL EXAM FOR BATCH MODEL -->\r\n  <div id=\"cancelBatchModal\" class=\"modal\" role=\"dialog\" *ngIf=\"cancelExamPopUP\">\r\n    <div class=\"modal-dialog\">\r\n\r\n      <!-- Modal content-->\r\n      <div class=\"modal-content\">\r\n        <div class=\"modal-header\">\r\n          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\r\n          <h4 class=\"modal-title\">Course Exam Schedule Cancellation</h4>\r\n        </div>\r\n        <div class=\"modal-body\">\r\n          <div class=\"cancel-Class-Wrapper\">\r\n            <div class=\"row attendance-Note\" style=\"margin-left:0px; margin-right: 0px;\">\r\n              <div class=\"cancel-reason-container\">\r\n                <label for=\"cancelTxtBx\">Cancellation Reason<span class=\"text-danger\">*</span></label>\r\n                <textarea class=\"cancel-input\" [(ngModel)]=\"cancelPopUpData.reason\" id=\"cancelTxtBx\" name=\"cancelTxtBx\"></textarea>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"modal-footer\">\r\n          <div class=\"clearfix\" style=\"margin-top: 10px\">\r\n            <aside class=\"pull-left\" style=\"margin-top: 10px\">\r\n              <div class=\"field-checkbox-wrapper\">\r\n                <input type=\"checkbox\" value=\"\" id=\"chkBxNotifyStudent\" name=\"chkBxNotifyStudent\" class=\"form-checkbox\" [(ngModel)]=\"cancelPopUpData.notify\">\r\n                <label for=\"chkBxNotifyStudent\">Notify Students</label>\r\n              </div>\r\n            </aside>\r\n            <aside class=\"pull-right popup-btn\">\r\n              <input type=\"button\" value=\"Close\" class=\"btn\" data-dismiss=\"modal\" (click)=\"closeExamPopup()\">\r\n              <input type=\"button\" value=\"Cancel Class\" data-dismiss=\"modal\" (click)=\"cancelExamClassSchedule()\" class=\"fullBlue btn\" [disabled]=\"jsonFlag.isRippleLoad\">\r\n            </aside>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/course-planner/exam/exam.component.scss":
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n.middle-section {\n  padding: 1%; }\n.header-section {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  width: 20%;\n  margin-left: 40%;\n  margin-bottom: 20px; }\n.header-section .header-item {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    padding: 5px;\n    width: 50%;\n    cursor: pointer; }\n.header-section .header-item .img-container img {\n      width: 20px;\n      height: 20px;\n      margin: 0px 10px; }\n.header-section .header-item .model-name-container {\n      width: 50%;\n      margin-top: 3px; }\n.header-section .header-item .model-name-container span {\n        font-size: 14px;\n        font-weight: 600; }\n.header-section #class {\n    border-top-left-radius: 25px;\n    border-bottom-left-radius: 25px;\n    border: 2px solid #3a65f8; }\n.header-section #exam {\n    border-top-right-radius: 25px;\n    border-bottom-right-radius: 25px;\n    border: 2px solid #3a65f8; }\n.active {\n  background: #3a66fa;\n  color: #fdfdfd; }\n.non-active {\n  background: #ffffff;\n  color: #b0b0b0; }\n.middle {\n  margin-top: 10px; }\n.filter-header-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  padding: 5px 0px;\n  border-top: 1px solid #d4d4d4;\n  border-bottom: 1px solid #d4d4d4;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between; }\n.filter-header-container .filter-item-1 {\n    width: 80%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between; }\n.filter-header-container .filter-item-1 .header-item {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      font-size: 12px;\n      color: #3e3d4a;\n      width: 18%;\n      position: relative; }\n.filter-header-container .filter-item-1 .header-item .header-select-box {\n        border-radius: 4px;\n        border: 1px solid #d4d4d4;\n        margin: 5px 0px;\n        padding: 5px 0px; }\n.filter-header-container .filter-item-1 .header-item .input-container {\n        position: relative; }\n.filter-header-container .filter-item-1 .header-item .input-container .fa-filter {\n          position: absolute;\n          left: 2px;\n          background: white;\n          padding: 8px 10px;\n          top: 6px;\n          border-right: 1px solid #ccc; }\n.filter-header-container .filter-item-1 .header-item .input-container .fa-caret-down, .filter-header-container .filter-item-1 .header-item .input-container .fa-caret-up {\n          position: absolute;\n          right: 2px;\n          background: white;\n          padding: 7px 10px;\n          top: 7px;\n          z-index: 1;\n          cursor: pointer; }\n.filter-header-container .filter-item-1 .header-item .filer-input {\n        margin: 5px 0px;\n        border-radius: 4px;\n        border: 1px solid #d4d4d4;\n        padding: 8px 5px;\n        width: 100%;\n        padding-left: 35px;\n        height: 30px; }\n.filter-header-container .filter-item-1 .go-btn-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      font-size: 12px;\n      color: #3e3d4a;\n      width: auto; }\n.filter-header-container .filter-item-1 .go-btn-container .gobtn {\n        border: 1px solid #3a66fa;\n        border-radius: 4px;\n        -webkit-box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n                box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n        padding: 4px 10px;\n        background: #3a66fa;\n        color: #ffffff;\n        font-weight: 600;\n        height: 30px;\n        margin-top: 20px; }\n.filter-header-container .filter-item-2 {\n    width: 10%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: end;\n        -ms-flex-pack: end;\n            justify-content: flex-end; }\n.filter-header-container .filter-item-2 .add-class-btn {\n      border: 1px solid #3a66fa;\n      border-radius: 4px;\n      -webkit-box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n              box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n      padding: 4px 10px;\n      background: white;\n      color: #1283f4;\n      font-weight: 600;\n      height: 30px;\n      margin-top: 15px; }\n.filter-header-container .filter-container {\n    position: absolute;\n    width: 100%;\n    background: white;\n    -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n            box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n    border-radius: 4px;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    top: 55px;\n    -webkit-animation-name: slideInDown;\n            animation-name: slideInDown;\n    -webkit-animation-duration: 0.5s;\n            animation-duration: 0.5s;\n    z-index: 20; }\n.filter-header-container .filter-container .date-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      padding: 10px;\n      border-bottom: 1px solid #ccc;\n      padding-bottom: 0px; }\n.filter-header-container .filter-container .date-container .date-title {\n        font-weight: 600;\n        padding: 5px 0px; }\n.filter-header-container .filter-container .date-container .date-values-container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        -ms-flex-wrap: wrap;\n            flex-wrap: wrap; }\n.filter-header-container .filter-container .date-container .date-values-container .date-value-item {\n          width: 50%; }\n.filter-header-container .filter-container .date-container .date-values-container .date-value-item input, .filter-header-container .filter-container .date-container .date-values-container .date-value-item label {\n            cursor: pointer;\n            font-size: 12px; }\n.filter-header-container .filter-container .status-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      padding: 10px;\n      border-bottom: 1px solid #ccc;\n      padding-bottom: 0px; }\n.filter-header-container .filter-container .status-container .status-title {\n        font-weight: 600;\n        padding: 5px 0px; }\n.filter-header-container .filter-container .status-container .status-values-container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        -ms-flex-wrap: wrap;\n            flex-wrap: wrap; }\n.filter-header-container .filter-container .status-container .status-values-container .status-value-item {\n          width: 50%; }\n.filter-header-container .filter-container .status-container .status-values-container .status-value-item input, .filter-header-container .filter-container .status-container .status-values-container .status-value-item label {\n            cursor: pointer;\n            font-size: 12px; }\n.filter-header-container .filter-container .faculty-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      padding: 10px; }\n.filter-header-container .filter-container .faculty-container .faculty-title {\n        font-weight: 600;\n        padding: 5px 0px; }\n.filter-header-container .filter-container .faculty-container .faculty-dropdown-container {\n        width: 100%; }\n.filter-header-container .filter-container .faculty-container .faculty-dropdown-container .faculty-select-box {\n          border-bottom: 1px solid #d4d4d4;\n          margin: 5px 0px;\n          padding: 5px 0px;\n          width: 100%; }\n.illustration-container {\n  display: block; }\n.illustration-container .illustration-img {\n    width: 40%;\n    /* height: 34%; */\n    margin-left: 12%;\n    margin-top: -2%; }\n.table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%;\n  margin-top: 10px; }\n.table-container .table-header-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    margin-bottom: 10px;\n    padding-bottom: 10px;\n    margin-right: 10px;\n    padding-left: 5px;\n    border-bottom: 1px solid #ccc; }\n.table-container .table-header-container .table-heading-item {\n      color: #585574;\n      font-weight: 600;\n      font-size: 12px;\n      padding: 0px 5px; }\n.table-container .table-header-container .table-heading-item .fa-cog {\n        position: absolute;\n        right: 20px;\n        cursor: pointer;\n        color: #9898a3;\n        font-size: 14px; }\n.table-container .table-header-container .table-heading-item .show-hide-container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        width: 230px;\n        right: 35px;\n        height: auto;\n        position: absolute;\n        top: 0px;\n        border-radius: 4px;\n        -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n                box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n        z-index: 10;\n        background: white;\n        -webkit-animation-name: slideInRight;\n                animation-name: slideInRight;\n        -webkit-animation-duration: 0.5s;\n                animation-duration: 0.5s; }\n.table-container .table-header-container .table-heading-item .show-hide-container .show-hide-header {\n          padding: 10px;\n          background: #f9f9f9;\n          color: #585574;\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-pack: justify;\n              -ms-flex-pack: justify;\n                  justify-content: space-between; }\n.table-container .table-header-container .table-heading-item .show-hide-container .show-hide-header .fa-times {\n            font-weight: 400;\n            cursor: pointer; }\n.table-container .table-header-container .table-heading-item .show-hide-container .show-hide-value-container {\n          padding: 10px;\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: vertical;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: column;\n                  flex-direction: column;\n          border-bottom: 1px solid #ccc; }\n.table-container .table-header-container .table-heading-item .show-hide-container .show-hide-value-container .show-hide-item {\n            width: 100%;\n            text-align: left; }\n.table-container .table-header-container .table-heading-item .show-hide-container .show-hide-value-container .show-hide-item input, .table-container .table-header-container .table-heading-item .show-hide-container .show-hide-value-container .show-hide-item label {\n              font-size: 12px;\n              font-weight: 400; }\n.table-container .table-header-container .table-heading-item .show-hide-container .bg-container {\n          position: absolute;\n          bottom: 0px;\n          right: 0px; }\n.table-container .table-header-container .table-heading-item .show-hide-container .bg-container img {\n            width: 75%;\n            margin-left: 25%; }\n.table-container .table-value-outer-container {\n    height: 59vh;\n    overflow-y: auto; }\n.table-container .table-value-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    background: #ffffff;\n    border-radius: 4px;\n    -webkit-box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.16);\n            box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.16);\n    margin-bottom: 10px;\n    padding: 5px 0px;\n    position: relative; }\n.table-container .table-value-container .table-value-item {\n      color: #585574;\n      font-weight: 400;\n      font-size: 12px;\n      line-height: 1.5;\n      display: -webkit-box;\n      -webkit-box-align: center;\n      padding: 0px 5px; }\n.table-container .table-value-container .table-value-item .upcoming-btn {\n        color: #ffffff;\n        border-radius: 4px;\n        border: 1px solid #ffffff;\n        background: #ff6c24;\n        cursor: default;\n        padding: 2px 5px;\n        width: 95px;\n        font-weight: 600; }\n.table-container .table-value-container .table-value-item .pending-btn {\n        color: #ffffff;\n        border-radius: 4px;\n        border: 1px solid #ffffff;\n        background: #8d8d8d;\n        cursor: default;\n        padding: 2px 5px;\n        width: 95px;\n        font-weight: 600; }\n.table-container .table-value-container .table-value-item .cancelled-btn {\n        color: #ffffff;\n        border-radius: 4px;\n        border: 1px solid #ffffff;\n        background: #df0d2f;\n        cursor: default;\n        padding: 2px 5px;\n        width: 95px;\n        font-weight: 600; }\n.table-container .table-value-container .table-value-item .completed-btn {\n        color: #ffffff;\n        border-radius: 4px;\n        border: 1px solid #ffffff;\n        background: #00b55a;\n        cursor: default;\n        padding: 2px 5px;\n        width: 95px;\n        font-weight: 600; }\n.table-container .table-value-container .table-value-item .marksPending-btn {\n        color: #ffffff;\n        border-radius: 4px;\n        border: 1px solid #ffffff;\n        background: #8771FF;\n        cursor: default;\n        padding: 2px 5px;\n        width: 95px;\n        font-weight: 600; }\n.table-container .table-value-container .flex-item {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column; }\n.table-container .border-cancelled-class {\n    border-left: 5px solid #df0d2f; }\n.table-container .border-completed-class {\n    border-left: 5px solid #00b55a; }\n.table-container .border-pending-class {\n    border-left: 5px solid #8d8d8d; }\n.table-container .border-upcoming-class {\n    border-left: 5px solid #ff6c24; }\n.table-container .border-marksPending-class {\n    border-left: 5px solid #8771FF; }\n.table-container .align-center {\n    text-align: center; }\n.table-container .small {\n    width: 8%;\n    font-size: 12px; }\n.table-container .medium {\n    width: 15%;\n    font-size: 12px; }\n.table-container .action {\n    position: absolute;\n    right: 0px; }\n.table-container .action-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: end;\n        -ms-flex-pack: end;\n            justify-content: flex-end;\n    width: 85%;\n    margin-right: 15%;\n    margin-top: 15px; }\n.table-container .action-container i, .table-container .action-container img {\n      margin: 0px 5px;\n      max-width: 14px;\n      height: 14px;\n      cursor: pointer; }\n.field-checkbox-wrapper .form-checkbox {\n  opacity: 0;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px;\n  z-index: 1;\n  border: 2px solid #0084f6; }\n.field-checkbox-wrapper .form-checkbox + label {\n  vertical-align: middle;\n  font-size: 14px;\n  display: inline-block; }\n.field-checkbox-wrapper .form-checkbox + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 2px;\n  position: absolute;\n  left: 0;\n  top: 0; }\n.field-checkbox-wrapper .form-checkbox:checked + label:after {\n  border: 2px solid #0084f6; }\n.field-checkbox-wrapper .form-checkbox + label:before {\n  width: 1px;\n  height: 1px;\n  left: 8px;\n  top: 9px;\n  position: absolute;\n  content: '';\n  border-top: 0;\n  border-right: 0;\n  border-left: 2px solid transparent;\n  border-bottom: 2px solid transparent;\n  -webkit-transform: rotate(-45deg);\n          transform: rotate(-45deg); }\n.field-checkbox-wrapper .form-checkbox:checked + label:before {\n  border-left: 2px solid #0084f6;\n  border-bottom: 2px solid #0084f6;\n  width: 12px;\n  height: 5px;\n  left: 2px;\n  top: 5px; }\n.field-checkbox-wrapper .form-checkbox:checked + label {\n  color: #0084f6; }\n.filter-res.pagination {\n  width: 100%; }\n.pagination {\n  margin: 0px; }\n.pagination .first:before {\n    content: \"« \";\n    font-size: 16px;\n    font-weight: 800; }\n.pagination .last:after {\n    content: \" »\";\n    font-size: 16px;\n    font-weight: 800; }\n.pagination .batch-size {\n    font-size: 16px;\n    font-weight: 800; }\n.pagination li {\n    border-right: 1px solid #ccc;\n    padding: 0px 7px;\n    margin: 0;\n    line-height: 10px;\n    font-weight: 800;\n    cursor: pointer; }\n.pagination li a {\n      line-height: 10px;\n      font-size: 16px;\n      font-weight: 800;\n      border: none;\n      padding: 0px 14px; }\n.pagination li :hover {\n      background-color: transparent !important; }\n.pagination li:last-child {\n  border-right: 0;\n  padding-right: 0; }\n@-webkit-keyframes slideInDown {\n  from {\n    -webkit-transform: translate3d(0, -10%, 0);\n    transform: translate3d(0, -10%, 0);\n    visibility: visible; }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n    transform: translate3d(0, 0, 0); } }\n@keyframes slideInDown {\n  from {\n    -webkit-transform: translate3d(0, -10%, 0);\n    transform: translate3d(0, -10%, 0);\n    visibility: visible; }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n    transform: translate3d(0, 0, 0); } }\n@-webkit-keyframes slideInRight {\n  from {\n    -webkit-transform: translate3d(5%, 0, 0);\n    transform: translate3d(5%, 0, 0);\n    visibility: visible; }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n    transform: translate3d(0, 0, 0); } }\n@keyframes slideInRight {\n  from {\n    -webkit-transform: translate3d(5%, 0, 0);\n    transform: translate3d(5%, 0, 0);\n    visibility: visible; }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n    transform: translate3d(0, 0, 0); } }\n.cancel-reason-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%;\n  text-align: left; }\n.cancel-reason-container .cancel-input {\n    width: 50%;\n    height: 100px;\n    border: 1px solid #ccc; }\n.cancelExamWrapper .details {\n  margin: 10px -15px; }\n.cancelExamWrapper .content-wraper .button-Section {\n  margin: 10px 0px 10px -15px; }\n.cancelExamWrapper .content-wraper .cancel-table {\n  max-height: 150px;\n  overflow-x: hidden;\n  overflow-y: scroll; }\n.table-responsive {\n  max-width: 100%;\n  overflow: auto; }\ntable {\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  border-collapse: collapse; }\nth,\ntd {\n  font-size: 12px;\n  padding: 6px 2px;\n  vertical-align: middle; }\nth {\n  background: #004a7e;\n  font-size: 11px;\n  color: #fff;\n  font-weight: normal; }\ntd {\n  border-bottom: 1px solid #fff; }\ntable tr {\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s; }\ntable tr:nth-child(even) {\n  background: #efefef; }\ntable tr:nth-child(odd) {\n  background: #f7f7f7; }\ntable tr:nth-child(even):hover {\n  background: #ececec; }\ntable tr:nth-child(odd):hover {\n  background: #eaeaea; }\ntable tr.selected {\n  background: #dceff7 !important; }\n.table-responsive tr td:first-child .field-checkbox-wrapper,\n.table-responsive tr th:first-child .field-checkbox-wrapper {\n  width: 20px;\n  overflow: hidden;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 20px;\n  padding-left: 20px;\n  margin-bottom: 0;\n  margin-left: 5px;\n  background: #fff;\n  border-radius: 2px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/course-planner/exam/exam.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ExamComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_rxjs_Rx__ = __webpack_require__("./node_modules/rxjs/_esm5/Rx.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_course_services_class_schedule_service__ = __webpack_require__("./src/app/services/course-services/class-schedule.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__course_planner_model__ = __webpack_require__("./src/app/components/course-module/course-planner/course-planner.model.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__session_filter_model__ = __webpack_require__("./src/app/components/course-module/course-planner/session-filter.model.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__services_widget_service__ = __webpack_require__("./src/app/services/widget.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};










var ExamComponent = /** @class */ (function () {
    function ExamComponent(router, auth, msgService, classService, widgetService) {
        this.router = router;
        this.auth = auth;
        this.msgService = msgService;
        this.classService = classService;
        this.widgetService = widgetService;
        // global variables
        this.jsonFlag = {
            isProfessional: false,
            institute_id: '',
            isRippleLoad: false,
            showHideColumn: false,
            setting: true
        };
        this.coursePlannerFor = "exam";
        // apis variables to send
        this.inputElements = {
            masterCourse: "-1",
            course: "-1",
            subject: "-1",
            standard_id: "-1",
            subject_id: "-1",
            batch_id: "-1",
            faculty: "-1",
            isAssigned: "N"
        };
        // Duration filter for course planner data
        this.filterDateInputs = {
            thisWeek: true,
            lastWeek: false,
            thisMonth: false,
            custom: false
        };
        //  class status filter for course planner data
        this.filterStatusInputs = {
            upcoming: true,
            attendancePending: true,
            marksUpdated: true,
            marksPending: true,
            cancelled: true,
        };
        // Default col show hide status
        this.showHideColumns = {
            subject: true,
            topic: true,
            description: false,
        };
        // for show hide table columns
        this.checkedColCounter = 1;
        // Array Elements
        this.facultyList = [];
        this.coursePlannerData = []; // saved course planner fetched data
        this.allData = []; // used for pagination purpose
        // course model array
        this.masterCourseList = [];
        this.courseList = [];
        this.subjectList = [];
        // batch model array
        this.batchList = [];
        this.coursePlannerFilters = new __WEBPACK_IMPORTED_MODULE_7__course_planner_model__["a" /* CoursePlanner */]();
        this.sessionFiltersArr = new __WEBPACK_IMPORTED_MODULE_8__session_filter_model__["a" /* SessionFilter */]();
        this.filterShow = false;
        this.filterDateRange = "";
        // FOR PAGINATION
        this.pageIndex = 1;
        this.displayBatchSize = 20;
        this.totalCount = 0;
        this.sizeArr = [20, 50, 100, 150, 200, 500];
        // pop up section variables
        // Cancel Exam
        this.tempData = [];
        this.courseTempData = '';
        this.courseCommonExamCancelPopUP = false;
        this.showReasonSection = '';
        this.cancelPopUpData = {
            reason: "",
            notify: true
        };
        this.cancelExamPopUP = false;
    }
    ExamComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.jsonFlag.isProfessional = true;
            }
            else {
                _this.jsonFlag.isProfessional = false;
            }
        });
        this.showHideColForModel();
        this.jsonFlag.institute_id = sessionStorage.getItem('institute_id');
        this.fetchPreFillData();
        var filters = sessionStorage.getItem('coursePlannerFilter');
        if (filters) {
            this.sessionFilters(filters);
        }
    };
    ExamComponent.prototype.showHideColForModel = function () {
        if (this.jsonFlag.isProfessional) {
            this.showHideColumns.description = true;
            this.showHideColumns.topic = false;
            this.jsonFlag.setting = false;
        }
    };
    ExamComponent.prototype.sessionFilters = function (filters) {
        var _this = this;
        this.sessionFiltersArr = JSON.parse(filters);
        this.inputElements.masterCourse = this.sessionFiltersArr.masterCourse;
        this.inputElements.course = this.sessionFiltersArr.courseId;
        this.inputElements.standard_id = this.sessionFiltersArr.standardId;
        this.inputElements.subject_id = this.sessionFiltersArr.subjectId;
        this.inputElements.faculty = this.sessionFiltersArr.facultyId;
        if (!this.jsonFlag.isProfessional) {
            this.inputElements.subject = this.sessionFiltersArr.batchId;
        }
        else {
            this.inputElements.batch_id = this.sessionFiltersArr.batchId;
        }
        this.filterDateInputs.thisWeek = this.sessionFiltersArr.thisWeek;
        this.filterDateInputs.lastWeek = this.sessionFiltersArr.lastWeek;
        this.filterDateInputs.thisMonth = this.sessionFiltersArr.thisMonth;
        this.filterDateInputs.custom = this.sessionFiltersArr.custom;
        this.filterStatusInputs.marksUpdated = this.sessionFiltersArr.isCompleted;
        this.filterStatusInputs.attendancePending = this.sessionFiltersArr.isPending;
        this.filterStatusInputs.cancelled = this.sessionFiltersArr.isCancelled;
        this.filterStatusInputs.upcoming = this.sessionFiltersArr.isUpcoming;
        this.filterStatusInputs.marksPending = this.sessionFiltersArr.isMarksUpdate;
        this.coursePlannerFilters.master_course_name = this.sessionFiltersArr.masterCourse;
        this.coursePlannerFilters.course_id = this.sessionFiltersArr.courseId;
        this.coursePlannerFilters.batch_id = this.sessionFiltersArr.batchId;
        this.coursePlannerFilters.teacher_id = this.sessionFiltersArr.facultyId;
        if (!this.filterStatusInputs.upcoming) {
            this.coursePlannerFilters.isUpcoming = "N";
        }
        else if (!this.filterStatusInputs.attendancePending) {
            this.coursePlannerFilters.isPending = "N";
        }
        else if (!this.filterStatusInputs.marksUpdated) {
            this.coursePlannerFilters.isCompleted = "N";
        }
        else if (!this.filterStatusInputs.marksPending) {
            this.coursePlannerFilters.isMarksUpdate = "N";
        }
        else if (!this.filterStatusInputs.cancelled) {
            this.coursePlannerFilters.isCancelled = "N";
        }
        this.coursePlannerFilters.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.sessionFiltersArr.from_date).format("YYYY-MM-DD");
        this.coursePlannerFilters.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.sessionFiltersArr.to_date).format("YYYY-MM-DD");
        if (this.sessionFiltersArr.masterCourse != "-1") {
            this.updateCoursesList();
        }
        sessionStorage.setItem('isFromCoursePlanner', String(false));
        sessionStorage.setItem('coursePlannerFilter', '');
        setTimeout(function () {
            _this.getData();
        }, 2000);
    };
    ExamComponent.prototype.clearFilters = function () {
        sessionStorage.setItem('batch_info', '');
        sessionStorage.setItem('isSubjectView', '');
        sessionStorage.setItem('isFromCoursePlanner', '');
        sessionStorage.setItem('coursePlannerFilter', '');
        this.sessionFiltersArr = new __WEBPACK_IMPORTED_MODULE_8__session_filter_model__["a" /* SessionFilter */]();
    };
    ExamComponent.prototype.fetchPreFillData = function () {
        var _this = this;
        // get master course - course - subject data  for course model
        if (!this.jsonFlag.isProfessional) {
            this.jsonFlag.isRippleLoad = true;
            this.classService.getAllMasterCourse().subscribe(function (res) {
                _this.masterCourseList = res;
                if (_this.sessionFiltersArr.masterCourse != "-1") {
                    _this.updateCoursesList();
                }
                _this.jsonFlag.isRippleLoad = false;
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', 'Please check your internet connection or contact at support@proctur.com if the issue persist');
            });
        }
        else {
            // get master course - course - subject data  for Batch model
            this.jsonFlag.isRippleLoad = true;
            this.classService.getStandardSubjectList(this.inputElements.standard_id, this.inputElements.subject_id, this.inputElements.isAssigned).subscribe(function (res) {
                _this.masterCourseList = res.standardLi;
                _this.batchList = res.batchLi;
                if (_this.sessionFiltersArr.standardId != "-1") {
                    _this.updateCoursesList();
                }
                _this.jsonFlag.isRippleLoad = false;
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', 'Please check your internet connection or contact at support@proctur.com if the issue persist');
            });
        }
        // get active faculty list
        this.classService.getAllTeachersList().subscribe(function (res) {
            _this.facultyList = res;
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', 'Please check your internet connection or contact at support@proctur.com if the issue persist');
        });
    };
    ExamComponent.prototype.updateCoursesList = function () {
        var _this = this;
        if (!this.jsonFlag.isProfessional) {
            this.coursePlannerFilters.master_course_name = this.inputElements.masterCourse;
            if (this.sessionFiltersArr.courseId != "-1" && this.sessionFiltersArr.courseId != "") {
                this.inputElements.course = this.sessionFiltersArr.courseId;
            }
            else {
                this.inputElements.course = "-1";
                this.inputElements.subject = "-1";
                this.coursePlannerFilters.course_id = "-1";
                this.coursePlannerFilters.batch_id = "-1";
            }
            if (this.inputElements.masterCourse == "") {
                this.courseList = [];
                this.subjectList = [];
            }
            else {
                for (var i = 0; i < this.masterCourseList.length; i++) {
                    if (this.masterCourseList[i].master_course == this.inputElements.masterCourse) {
                        this.courseList = this.masterCourseList[i].coursesList;
                        if (this.sessionFiltersArr.courseId != "-1" && this.sessionFiltersArr.courseId != "") {
                            this.updateSubjectsList();
                        }
                        else {
                            this.subjectList = [];
                            return;
                        }
                    }
                }
            }
        }
        else {
            this.coursePlannerFilters.standard_id = this.inputElements.standard_id;
            this.inputElements.subject_id = "-1";
            this.coursePlannerFilters.subject_id = "-1";
            if (this.inputElements.standard_id == "-1") {
                this.courseList = [];
            }
            else {
                this.jsonFlag.isRippleLoad = true;
                this.classService.getStandardSubjectList(this.inputElements.standard_id, this.inputElements.subject_id, this.inputElements.isAssigned).subscribe(function (res) {
                    _this.jsonFlag.isRippleLoad = false;
                    _this.courseList = res.subjectLi;
                    _this.batchList = res.batchLi;
                    _this.jsonFlag.isRippleLoad = false;
                    for (var i = 0; i < _this.masterCourseList.length; i++) {
                        if (_this.masterCourseList[i].standard_id == _this.inputElements.standard_id) {
                            _this.courseStartDate = _this.masterCourseList[i].start_date;
                            _this.courseEndDate = _this.masterCourseList[i].end_date;
                            if (_this.sessionFiltersArr.subjectId != "-1" && _this.sessionFiltersArr.subjectId != "") {
                                _this.inputElements.subject_id = _this.sessionFiltersArr.subjectId;
                                _this.updateSubjectsList();
                            }
                            _this.clearFilters();
                            return;
                        }
                    }
                }, function (err) {
                    _this.jsonFlag.isRippleLoad = false;
                    _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err);
                });
            }
        }
    };
    ExamComponent.prototype.updateSubjectsList = function () {
        var _this = this;
        if (!this.jsonFlag.isProfessional) {
            this.coursePlannerFilters.course_id = this.inputElements.course;
            if (this.inputElements.course == "" || this.inputElements.course == "-1") {
                this.subjectList = [];
                this.inputElements.subject = "-1";
                this.coursePlannerFilters.batch_id = this.inputElements.subject;
            }
            else {
                for (var i = 0; i < this.courseList.length; i++) {
                    if (this.courseList[i].course_id == this.inputElements.course) {
                        this.subjectList = this.courseList[i].batchesList;
                        this.courseStartDate = this.courseList[i].start_date;
                        this.courseEndDate = this.courseList[i].end_date;
                        if (this.sessionFiltersArr.standardId != "-1" && this.sessionFiltersArr.standardId != "") {
                            this.inputElements.subject = this.sessionFiltersArr.batchId;
                        }
                        this.clearFilters();
                        return;
                    }
                }
            }
        }
        else {
            this.jsonFlag.isRippleLoad = true;
            this.coursePlannerFilters.subject_id = this.inputElements.subject_id;
            this.classService.getStandardSubjectList(this.inputElements.standard_id, this.inputElements.subject_id, this.inputElements.isAssigned).subscribe(function (res) {
                _this.jsonFlag.isRippleLoad = false;
                _this.batchList = res.batchLi;
                _this.clearFilters();
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err);
                _this.clearFilters();
            });
        }
    };
    ExamComponent.prototype.updateSubject = function () {
        if (!this.jsonFlag.isProfessional) {
            this.coursePlannerFilters.batch_id = this.inputElements.subject;
        }
        else {
            this.coursePlannerFilters.batch_id = this.inputElements.batch_id;
        }
    };
    ExamComponent.prototype.updateFacultyInFilter = function () {
        this.coursePlannerFilters.teacher_id = this.inputElements.faculty;
    };
    ExamComponent.prototype.toggleFilter = function () {
        if (this.filterShow) {
            this.filterShow = false;
        }
        else {
            this.filterShow = true;
        }
    };
    ExamComponent.prototype.updateDateFilter = function (inputDateFilter, e) {
        this.filterDateInputs.thisWeek = false;
        this.filterDateInputs.lastWeek = false;
        this.filterDateInputs.thisMonth = false;
        this.filterDateInputs.custom = false;
        if (inputDateFilter == 'custom') {
            this.openCalendar('customeDate');
            this.filterDateInputs.custom = true;
            e.currentTarget.checked = true;
        }
        else if (inputDateFilter == 'lastWeek') {
            this.coursePlannerFilters.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__().subtract(1, 'weeks').startOf('isoWeek').format("YYYY-MM-DD");
            this.coursePlannerFilters.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__().subtract(1, 'weeks').endOf('isoWeek').format("YYYY-MM-DD");
            this.filterDateInputs.lastWeek = true;
            e.currentTarget.checked = true;
        }
        else if (inputDateFilter == 'thisMonth') {
            this.coursePlannerFilters.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-01");
            this.coursePlannerFilters.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-") + __WEBPACK_IMPORTED_MODULE_3_moment__().daysInMonth();
            this.filterDateInputs.thisMonth = true;
            e.currentTarget.checked = true;
        }
        else if (inputDateFilter == 'thisWeek') {
            this.coursePlannerFilters.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__().isoWeekday("Monday").format("YYYY-MM-DD");
            this.coursePlannerFilters.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__().weekday(7).format("YYYY-MM-DD");
            this.filterDateInputs.thisWeek = true;
            e.currentTarget.checked = true;
        }
    };
    ExamComponent.prototype.updateStatusFilter = function (e, statusFilter) {
        if (!e.currentTarget.checked) {
            if (statusFilter == 'upcoming') {
                this.coursePlannerFilters.isUpcoming = "N";
            }
            else if (statusFilter == 'pending') {
                this.coursePlannerFilters.isPending = "N";
            }
            else if (statusFilter == 'marksUpdated') {
                this.coursePlannerFilters.isCompleted = "N";
            }
            else if (statusFilter == 'marksPending') {
                this.coursePlannerFilters.isMarksUpdate = "N";
            }
            else if (statusFilter == 'cancelled') {
                this.coursePlannerFilters.isCancelled = "N";
            }
        }
        else if (e.currentTarget.checked) {
            if (statusFilter == 'upcoming') {
                this.coursePlannerFilters.isUpcoming = "Y";
            }
            else if (statusFilter == 'pending') {
                this.coursePlannerFilters.isPending = "Y";
            }
            else if (statusFilter == 'marksUpdated') {
                this.coursePlannerFilters.isCompleted = "Y";
            }
            else if (statusFilter == 'marksPending') {
                this.coursePlannerFilters.isMarksUpdate = "Y";
            }
            else if (statusFilter == 'cancelled') {
                this.coursePlannerFilters.isCancelled = "Y";
            }
        }
    };
    ExamComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    ExamComponent.prototype.updateFilterDateRange = function (e) {
        if (this.filterDateInputs.custom) {
            this.coursePlannerFilters.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__(e[0]).format("YYYY-MM-DD");
            this.coursePlannerFilters.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__(e[1]).format("YYYY-MM-DD");
        }
    };
    ExamComponent.prototype.getData = function () {
        var _this = this;
        this.filterShow = false;
        this.jsonFlag.showHideColumn = false;
        this.jsonFlag.isRippleLoad = true;
        // Course/bacth model and master course is selected check
        if ((!this.jsonFlag.isProfessional && this.coursePlannerFilters.master_course_name == "-1") ||
            (this.jsonFlag.isProfessional && this.coursePlannerFilters.standard_id == "-1")) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please select master course');
            this.jsonFlag.isRippleLoad = false;
            return;
        }
        else {
            this.classService.getCoursePlannerData(this.coursePlannerFilters, this.coursePlannerFor).subscribe(function (res) {
                console.log(res);
                _this.jsonFlag.isRippleLoad = false;
                _this.allData = res;
                if (_this.allData.length == 0) {
                    _this.msgService.showErrorMessage(_this.msgService.toastTypes.info, 'Info', "No result found");
                }
                else {
                    _this.totalCount = _this.allData.length;
                    _this.pageIndex = 1;
                    _this.fectchTableDataByPage(_this.pageIndex);
                }
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            });
        }
    };
    ExamComponent.prototype.showHideCol = function () {
        if (this.jsonFlag.showHideColumn) {
            this.jsonFlag.showHideColumn = false;
        }
        else {
            this.jsonFlag.showHideColumn = true;
        }
    };
    ExamComponent.prototype.hideCol = function (e) {
        if (!e.currentTarget.checked) {
            this.checkedColCounter++;
        }
        else {
            this.checkedColCounter--;
        }
    };
    ExamComponent.prototype.hideShowHideMenu = function () {
        this.jsonFlag.showHideColumn = false;
    };
    /*** pagination functions */
    /* Fetch next set of data from server and update table */
    ExamComponent.prototype.fetchNext = function () {
        this.pageIndex++;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch previous set of data from server and update table */
    ExamComponent.prototype.fetchPrevious = function () {
        this.pageIndex--;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch table data by page index */
    ExamComponent.prototype.fectchTableDataByPage = function (index) {
        this.pageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.coursePlannerData = this.getDataFromDataSource(startindex);
    };
    ExamComponent.prototype.getDataFromDataSource = function (startindex) {
        var t = this.allData.slice(startindex, startindex + this.displayBatchSize);
        return t;
    };
    /* Fetches Data as per the user selected batch size */
    ExamComponent.prototype.updateTableBatchSize = function (num) {
        this.pageIndex = 1;
        this.displayBatchSize = parseInt(num);
        this.getData();
    };
    ExamComponent.prototype.getVisibility = function (c) {
        var d = __WEBPACK_IMPORTED_MODULE_3_moment__(c.class_date).format("YYYY-MM-DD");
        if (d >= __WEBPACK_IMPORTED_MODULE_3_moment__(new Date()).format("YYYY-MM-DD")) {
            return true;
        }
        else {
            return false;
        }
    };
    ExamComponent.prototype.closeAll = function () {
        this.filterShow = false;
    };
    // Send Reminder pop up section///
    // Course Model
    ExamComponent.prototype.sendReminderForCourse = function (data) {
        var _this = this;
        if (confirm('Are you sure you want to notify?')) {
            var obj = {
                course_exam_schedule_id: data.schedule_id,
                course_id: data.course_id,
                requested_date: __WEBPACK_IMPORTED_MODULE_3_moment__(data.date).format('YYYY-MM-DD')
            };
            this.jsonFlag.isRippleLoad = true;
            this.widgetService.sendReminder(obj).subscribe(function (res) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Reminder Sent', 'Reminder Sent Successfull');
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                console.log(err);
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            });
        }
    };
    // Batch Model
    ExamComponent.prototype.notifyExamSchedule = function (data) {
        var _this = this;
        if (confirm('Are you sure you want to send Exam Schedule SMS to the batch?')) {
            this.jsonFlag.isRippleLoad = true;
            this.widgetService.notifyStudentExam(data.schedule_id).subscribe(function (res) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Notified', 'Notification Sent Successfully');
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                //console.log(err);
            });
        }
    };
    // Cancel Exam section
    // Cancel Exam for Course model
    ExamComponent.prototype.onCancelExamClickCourse = function (data) {
        this.tempData = data;
        this.courseTempData = data;
        this.courseCommonExamCancelPopUP = true;
    };
    // cancelExamCourseWise() {
    //   this.showReasonSection = "Course";
    //   this.cancelPopUpData = {
    //     reason: "",
    //     notify: true
    //   };
    // }
    // cancelSubjectWiseExam(data) {
    //   this.showReasonSection = "Subject";
    //   this.tempData = data;
    //   this.cancelPopUpData = {
    //     reason: "",
    //     notify: true
    //   };
    // }
    ExamComponent.prototype.cancelExamCall = function () {
        var _this = this;
        var notify;
        if (this.cancelPopUpData.notify) {
            notify = 'Y';
        }
        else {
            notify = 'N';
        }
        if (this.cancelPopUpData.reason.trim() == "" || null) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter reason');
            return false;
        }
        var obj = {
            cancel_reason: this.cancelPopUpData.reason,
            course_exam_schedule_id: this.tempData.schedule_id,
            course_id: this.tempData.course_id,
            is_cancel_notify: notify,
            requested_date: __WEBPACK_IMPORTED_MODULE_3_moment__(this.tempData.date).format('YYYY-MM-DD')
        };
        // this.jsonFlag.isRippleLoad = true;
        this.widgetService.cancelExamScheduleCourse(obj).subscribe(function (res) {
            // this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Cancelled', 'Exam Cancelled Successfully');
            _this.closePopUpCommon();
            _this.getData();
        }, function (err) {
            // this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ExamComponent.prototype.closePopUpCommon = function () {
        this.tempData = "";
        this.subjectList = [];
        this.courseCommonExamCancelPopUP = false;
        this.showReasonSection = "";
        this.courseTempData = '';
        this.cancelPopUpData.reason = "";
    };
    // Cancel Exam for Batch MODEL
    ExamComponent.prototype.onCancelExamClick = function (data) {
        this.cancelExamPopUP = true;
        this.tempData = data;
    };
    ExamComponent.prototype.closeExamPopup = function () {
        this.cancelExamPopUP = false;
        this.tempData = "";
        this.cancelPopUpData = {
            reason: "",
            notify: true
        };
    };
    ExamComponent.prototype.cancelExamClassSchedule = function () {
        var _this = this;
        if (this.cancelPopUpData.reason.trim() == "" || null) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter cancellation reason');
            return;
        }
        var notify = "";
        if (this.cancelPopUpData.notify) {
            notify = "Y";
        }
        else {
            notify = "N";
        }
        var obj = {
            batch_id: this.tempData.batch_id,
            exam_freq: "OTHER",
            cancelSchd: [{
                    schd_id: this.tempData.schedule_id,
                    exam_desc: this.cancelPopUpData.reason,
                    is_notified: notify
                }]
        };
        // this.jsonFlag.isRippleLoad = true;
        this.widgetService.cancelExamSchedule(obj).subscribe(function (res) {
            // this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Successfully Cancelled', 'Exam Schedule Cancelled Successfully');
            _this.closeExamPopup();
            _this.getData();
        }, function (err) {
            // this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    //  Notify to Cancel Class
    ExamComponent.prototype.notifyCancelClass = function (selected) {
        var _this = this;
        if (confirm('Are you sure you want to notify?')) {
            var obj = {};
            if (!this.jsonFlag.isProfessional) {
                obj = {
                    "institute_id": this.jsonFlag.institute_id,
                    "schedule_id": selected.schedule_id,
                    "to_date": selected.date,
                    "course_id": selected.course_id
                };
            }
            else {
                obj = {
                    "institute_id": this.jsonFlag.institute_id,
                    "schedule_id": selected.schedule_id,
                    "to_date": selected.date,
                    "batch_id": selected.batch_id
                };
            }
            this.jsonFlag.isRippleLoad = true;
            this.classService.notifyCancelClass(obj, 'exam').subscribe(function (res) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Cancelled schedule notification', 'Notification has been sent successfully');
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            });
        }
    };
    // Update Attendance
    ExamComponent.prototype.markAttendanceExamCourse = function (exam) {
        var obj = {};
        if (this.jsonFlag.isProfessional) {
            obj = {
                batch_id: exam.batch_id,
                schd_id: exam.schedule_id,
                batch_name: exam.batch_name,
                topics_covered: exam.topic_covered_ids,
                course_name: exam.standard_name,
                master_course_name: exam.batch_name,
                subject_id: exam,
                forCourseWise: true,
                forSubjectWise: false,
                isExam: true,
                is_attendance_marked: exam.is_attendance_marked
            };
        }
        else {
            obj = {
                course_exam_schedule_id: exam.schedule_id,
                course_name: exam.course_name,
                master_course_name: exam.master_course_name,
                batch_name: exam.course_name,
                forCourseWise: true,
                forSubjectWise: false,
                isExam: true,
                schedDate: __WEBPACK_IMPORTED_MODULE_3_moment__(exam.date).format('YYYY-MM-DD'),
                is_attendance_marked: exam.is_attendance_marked
            };
        }
        var batch_info = JSON.stringify(obj);
        this.storeSession();
        sessionStorage.setItem('batch_info', btoa(batch_info));
        sessionStorage.setItem('isSubjectView', String(false));
        this.router.navigate(['/view/home/mark-attendance']);
    };
    // Update Exam Marks for course model
    ExamComponent.prototype.examMarksUpdateCourse = function (data) {
        var examInfoObj = {
            "course_exam_schedule_id": data.schedule_id,
            "course_marks_update_level": data.course_mark_level_level,
            "is_exam_grad_feature": "",
            "batch_name": data.master_course_name + "-" + data.course_name + "-" + data.subject_name
        };
        var obj = {
            data: examInfoObj
        };
        var exam_info = JSON.stringify(obj);
        this.storeSession();
        sessionStorage.setItem('exam_info', btoa(exam_info));
        sessionStorage.setItem('isSubjectView', String(false));
        this.router.navigate(['/view/home/exam-marks']);
    };
    // Update Exam marks for Batch model
    ExamComponent.prototype.examMarksUpdate = function (data) {
        var examInfoObj = {
            "schd_id": data.schedule_id,
            "batch_id": data.batch_id,
            "class_schedule_id": data.schedule_id
        };
        var obj = {
            data: examInfoObj
        };
        var exam_info = JSON.stringify(obj);
        this.storeSession();
        sessionStorage.setItem('exam_info', btoa(exam_info));
        sessionStorage.setItem('isSubjectView', String(false));
        this.router.navigate(['/view/home/exam-marks-batch']);
    };
    ExamComponent.prototype.storeSession = function () {
        this.sessionFiltersArr.isCompleted = this.filterStatusInputs.marksUpdated;
        this.sessionFiltersArr.isPending = this.filterStatusInputs.attendancePending;
        this.sessionFiltersArr.isCancelled = this.filterStatusInputs.cancelled;
        this.sessionFiltersArr.isUpcoming = this.filterStatusInputs.upcoming;
        this.sessionFiltersArr.isMarksUpdate = this.filterStatusInputs.marksPending;
        this.sessionFiltersArr.from_date = String(this.coursePlannerFilters.from_date);
        this.sessionFiltersArr.to_date = String(this.coursePlannerFilters.to_date);
        this.sessionFiltersArr.masterCourse = this.inputElements.masterCourse;
        this.sessionFiltersArr.courseId = this.inputElements.course;
        this.sessionFiltersArr.batchId = this.inputElements.subject;
        this.sessionFiltersArr.standardId = this.inputElements.standard_id;
        this.sessionFiltersArr.subjectId = this.inputElements.subject_id;
        if (!this.jsonFlag.isProfessional) {
            this.sessionFiltersArr.batchId = this.inputElements.subject;
        }
        else {
            this.sessionFiltersArr.batchId = this.inputElements.batch_id;
        }
        this.sessionFiltersArr.facultyId = this.inputElements.faculty;
        this.sessionFiltersArr.thisWeek = this.filterDateInputs.thisWeek;
        this.sessionFiltersArr.lastWeek = this.filterDateInputs.lastWeek;
        this.sessionFiltersArr.thisMonth = this.filterDateInputs.thisMonth;
        this.sessionFiltersArr.custom = this.filterDateInputs.custom;
        var filter_info = JSON.stringify(this.sessionFiltersArr);
        sessionStorage.setItem('isClass', String(false));
        sessionStorage.setItem('isFromCoursePlanner', String(true));
        sessionStorage.setItem('coursePlannerFilter', filter_info);
    };
    ExamComponent.prototype.redirect = function () {
        this.storeSession();
        this.router.navigate(['/view/course/create/exam']);
    };
    ExamComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-exam',
            template: __webpack_require__("./src/app/components/course-module/course-planner/exam/exam.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/course-planner/exam/exam.component.scss")],
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_5__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_6__services_message_show_service__["a" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_4__services_course_services_class_schedule_service__["a" /* ClassScheduleService */],
            __WEBPACK_IMPORTED_MODULE_9__services_widget_service__["a" /* WidgetService */]])
    ], ExamComponent);
    return ExamComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/course-planner/session-filter.model.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SessionFilter; });
var SessionFilter = /** @class */ (function () {
    function SessionFilter() {
        this.isCompleted = true;
        this.isPending = true;
        this.isCancelled = true;
        this.isUpcoming = true;
        this.isMarksUpdate = true;
        this.from_date = "";
        this.to_date = "";
        this.masterCourse = "";
        this.courseId = "";
        this.batchId = "";
        this.standardId = "";
        this.subjectId = "";
        this.facultyId = "";
        this.thisWeek = true;
        this.lastWeek = false;
        this.thisMonth = false;
        this.custom = false;
    }
    return SessionFilter;
}());

;


/***/ })

});
//# sourceMappingURL=course-planner.module.chunk.js.map