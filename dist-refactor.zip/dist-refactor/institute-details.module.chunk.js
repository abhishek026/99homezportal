webpackJsonp(["institute-details.module"],{

/***/ "./src/app/components/institute-details/institute-details.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n<div class=\"middle-section clearFix middle-one\">\r\n\r\n  <section id=\"divGeneral\" class=\"setting-visible\">\r\n    <h2 class=\"heading-setting-main\">General</h2>\r\n\r\n    <div class=\"general-setting\">\r\n      <div class=\"row\">\r\n        <div class=\"c-lg-10 c-sm-10 c-md-10\">\r\n          <h3 class=\"heading-setting\">Basic Information</h3>\r\n        </div>\r\n        <div class=\"c-lg-2 c-sm-2 c-md-2\">\r\n          <a (click)=\"toggleUpAndDownButton('0')\">\r\n            <i *ngIf='!dividersObj[0]' id=\"showAddBtn\" class=\"fa fa-angle-up\" style=\"border:none;margin-top: 15px;font-weight: bold;\"></i>\r\n            <i *ngIf='dividersObj[0]' id=\"showCloseBtn\" style=\"border:none;margin-top: 15px;font-weight: bold;\" class=\"fa fa-angle-down\"></i>\r\n          </a>\r\n        </div>\r\n      </div>\r\n      <div [hidden]='!dividersObj[0]' class=\"show-left\">\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch3\">Institute Name\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.institute_name != ''}\">\r\n              <input type=\"text\" disabled class=\"form-ctrl newDisabled\" name=\"slotNew\" id=\"ch3\" [(ngModel)]=\"instDetails.institute_name\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch4\">Institute Contact\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.institute_primary_phone != ''}\">\r\n              <input type=\"text\" disabled class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.institute_primary_phone\"\r\n                id=\"ch4\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch5\">Institute Address\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.institute_primary_addr != ''}\">\r\n              <input type=\"text\" disabled class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.institute_primary_addr\"\r\n                id=\"ch5\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch6\">Email ID\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.institute_primary_email != ''}\">\r\n              <input type=\"text\" id=\"ch6\" class=\"form-ctrl newDisabled\" name=\"slotNew\" disabled [(ngModel)]=\"instDetails.institute_primary_email\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"row\">\r\n        <div class=\"c-lg-10 c-sm-10 c-md-10\">\r\n          <h3 class=\"heading-setting\">Owner Details</h3>\r\n        </div>\r\n        <div class=\"c-lg-2 c-sm-2 c-md-2\">\r\n          <a (click)=\"toggleUpAndDownButton('1')\">\r\n            <i *ngIf='!dividersObj[1]' id=\"showAddBtn\" class=\"fa fa-angle-up\" style=\"border:none;margin-top: 15px;font-weight: bold;\"></i>\r\n            <i *ngIf='dividersObj[1]' id=\"showCloseBtn\" style=\"border:none;margin-top: 15px;font-weight: bold;\" class=\"fa fa-angle-down\"></i>\r\n          </a>\r\n        </div>\r\n      </div>\r\n      <div [hidden]='!dividersObj[1]' class=\"show-left\">\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch7\">Owner Name(s)\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.owner_name != ''}\">\r\n              <input type=\"text\" id=\"ch7\" disabled class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.owner_name\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch8\">\r\n              Owner Contact No(s)\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.owner_primary_phone != ''}\">\r\n              <input type=\"text\" disabled class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.owner_primary_phone\" id=\"ch8\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch9\">Owner Primary Email ID\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.owner_primary_email != ''}\">\r\n              <input type=\"text\" disabled class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.owner_primary_email\" id=\"ch9\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch10\">Owner Secondary Email ID\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.owner_secondary_email != ''}\">\r\n              <input type=\"text\" disabled class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.owner_secondary_email\"\r\n                id=\"ch10\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\">\r\n        <div class=\"c-lg-10 c-md-10 c-sm-10\">\r\n          <h3 class=\"heading-setting\">Admin Details</h3>\r\n        </div>\r\n        <div class=\"c-lg-2 c-sm-2 c-md-2\">\r\n          <a (click)=\"toggleUpAndDownButton('2')\">\r\n            <i id=\"showAddBtn\" *ngIf='!dividersObj[2]' class=\"fa fa-angle-up\" style=\"border:none;margin-top: 15px;font-weight: bold;\"></i>\r\n            <i id=\"showCloseBtn\" *ngIf='dividersObj[2]' style=\"border:none;margin-top: 15px;font-weight: bold;\" class=\"fa fa-angle-down\"></i>\r\n          </a>\r\n        </div>\r\n      </div>\r\n      <div [hidden]='!dividersObj[2]' class=\"show-left\">\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch11\">Admin Name\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.admin_name != ''}\">\r\n              <input type=\"text\" class=\"form-ctrl newDisabled\" id=\"ch11\" name=\"slotNew\" [(ngModel)]=\"instDetails.admin_name\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch12\">Admin Contact No.\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.admin_primary_phone != ''}\">\r\n              <input type=\"text\" maxlength=\"10\" id=\"ch12\" class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.admin_primary_phone\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch13\">Admin Email ID</label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.admin_primary_email != ''}\">\r\n              <input type=\"text\" id=\"ch11\" class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.admin_primary_email\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"row\">\r\n        <div class=\"c-lg-10 c-sm-10 c-md-10\">\r\n          <h3 class=\"heading-setting\">Additional Details</h3>\r\n        </div>\r\n        <div class=\"c-lg-2 c-sm-2 c-md-2\">\r\n          <a (click)=\"toggleUpAndDownButton('3')\">\r\n            <i *ngIf='!dividersObj[3]' id=\"showAddBtn\" class=\"fa fa-angle-up\" style=\"border:none;margin-top: 15px;font-weight: bold;\"></i>\r\n            <i *ngIf='dividersObj[3]' id=\"showCloseBtn\" style=\"border:none;margin-top: 15px;font-weight: bold;\" class=\"fa fa-angle-down\"></i>\r\n          </a>\r\n        </div>\r\n      </div>\r\n      <div [hidden]='!dividersObj[3]' class=\"show-left\">\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"hour\">KYC Document Type</label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.kyc_document_type != ''}\">\r\n              <select id=\"hour\" class=\"form-ctrl ng-valid ng-touched ng-dirty newDisabled\" name=\"hour\" [(ngModel)]=\"instDetails.kyc_document_type\"\r\n                (ngModelChange)=\"changeKYCInformation($event)\">\r\n                <option value=\"-1\">Select KYC Document Type</option>\r\n                <option *ngFor=\"let opt of kycType\" [value]=\"opt.data_key\">\r\n                  {{opt.data_value}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n          </div>\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3\" *ngIf=\"instDetails.kyc_document_type != '-1'\">\r\n            <div class=\"field-wrapper\">\r\n              <input type=\"file\" class=\"hide\" #idUploadDoc accept=\"image/gif,image/jpeg,image/jpg,image/png\">\r\n              <button class=\"btn\" (click)=\"uploadDocument()\">Upload Document</button>\r\n              <i class=\"fa fa-download hide\" *ngIf=\"instDetails.kyc_document_type!=''\"></i>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch14\">FB Page Url\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.fb_page_url != ''}\">\r\n              <input type=\"text\" class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.fb_page_url\" id=\"ch14\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch15\">Website Url\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.website_url != ''}\">\r\n              <input type=\"text\" class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.website_url\" id=\"ch15\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <h2 class=\"heading-setting-main\">Plan</h2>\r\n\r\n    <div class=\"general-setting\">\r\n      <div class=\"row\">\r\n        <div class=\"c-lg-8\">\r\n          <h3 class=\"heading-setting\">Current Plans</h3>\r\n        </div>\r\n        <div class=\"c-lg-2\">\r\n\r\n        </div>\r\n        <div class=\"c-lg-2\" style=\"padding-right: 5%;\">\r\n          <a class=\"pull-right\" style=\"cursor: pointer;padding-top: 15px;\" (click)=\"getPaymentDeatils()\">View History</a>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"table-scroll-wrapper show-left\">\r\n        <div class=\"table table-responsive\">\r\n          <table class=\"assign-width\">\r\n\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  Plan Name\r\n                </th>\r\n                <th>\r\n                  Students Limit\r\n                </th>\r\n                <th>\r\n                  Expiry Date\r\n                </th>\r\n                <th>\r\n                  No. of SMS\r\n                </th>\r\n                <th>\r\n                  Download Limit(GB)\r\n                </th>\r\n                <th>\r\n                  Price\r\n                </th>\r\n                <th>\r\n                  Tax(%)\r\n                </th>\r\n                <th>\r\n                  Total Price (Rs.)\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr id=\"rowPlan{{i}}\" *ngFor=\"let row of planDetail; let i = index; \">\r\n                <td>\r\n                  {{row.plan_name}}\r\n                </td>\r\n                <td>\r\n                  {{row.student_limit}}\r\n                </td>\r\n                <td>\r\n                  {{row.expiry_months}}\r\n                </td>\r\n                <td>\r\n                  {{row.sms_allocation}}\r\n                </td>\r\n                <td>\r\n                  {{row.download_limit}}\r\n                </td>\r\n                <td>\r\n                  {{row.subscription_price}}\r\n                </td>\r\n                <td>\r\n                  {{row.tax}}\r\n                </td>\r\n                <td>\r\n                  {{row.total_price}}\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\">\r\n        <div class=\"c-lg-10\">\r\n          <h3 class=\"heading-setting\">Additional Plans</h3>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"table-scroll-wrapper show-left\">\r\n        <div class=\"table table-responsive\">\r\n          <table class=\"assign-width\">\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  Option Name\r\n                </th>\r\n                <th>\r\n                  Price(1st Time in Rs)\r\n                </th>\r\n                <th>\r\n                  Price (2nd Time Onwards in Rs)\r\n                </th>\r\n                <th>\r\n                  Tax\r\n                </th>\r\n                <th>\r\n                  Total Price (Rs.)\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr id=\"rowPlan{{i}}\" *ngFor=\"let row of instituteOptions; let i = index; \">\r\n                <td>\r\n                  {{row.option_name}}\r\n                </td>\r\n                <td>\r\n                  {{row.subscription_price}}\r\n                </td>\r\n                <td>\r\n                  {{row.renewal_price}}\r\n                </td>\r\n                <td>\r\n                  {{row.tax}}\r\n                </td>\r\n                <td>\r\n                  {{row.total_price}}\r\n                </td>\r\n              </tr>\r\n              <tr *ngIf=\"instituteOptions.length == 0\">\r\n                <td colspan=\"5\">\r\n                  No Option Available\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row show-left\">\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting \">\r\n          <label for=\"ch16\">Total Price (Rs.)\r\n          </label>\r\n        </div>\r\n        <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.total_price_based_on_chosen_plan_and_option >= '0'}\">\r\n            <input type=\"text\" class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.total_price_based_on_chosen_plan_and_option\"\r\n              id=\"ch16\" disabled>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <h2 class=\"heading-setting-main\">General Settings</h2>\r\n\r\n    <div class=\"general-setting\">\r\n      <div class=\"row\">\r\n        <div class=\"c-lg-10\">\r\n          <h3 class=\"heading-setting\">Basic Information</h3>\r\n        </div>\r\n      </div>\r\n      <div class=\"show-left\">\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch17\">Institute code\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.institute_name != ''}\">\r\n              <input type=\"text\" disabled class=\"form-ctrl newDisabled\" name=\"slotNew\" id=\"ch17\" [(ngModel)]=\"instDetails.institute_name\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch18\">Generate student id manually\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <label class=\"switch switch-n\">\r\n              <input type=\"checkbox\" [checked]=\"!(this.instDetails.is_student_displayId_manual == 0)\" (click)=\"checkInputType($event)\"\r\n                name=\"sFilter\" class=\"form-radio\" value=\"Automatic\" id=\"idAutomatic\" disabled>\r\n              <span class=\"slider round\"></span>\r\n            </label>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\" *ngIf=\"(showPrefix == true)\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch20\">Student Id Prefix\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.student_id_prefix != ''}\">\r\n              <input type=\"text\" class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.student_id_prefix\" id=\"ch20\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n            <label for=\"ch21\">Tag Line\r\n            </label>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.tag_line != ''}\">\r\n              <input type=\"text\" class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.tag_line\" id=\"ch21\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <h2 class=\"heading-setting-main\">SMS Settings</h2>\r\n\r\n    <div class=\"general-setting show-left\">\r\n\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n          <label for=\"ch90\">SMS sender id\r\n            <span class=\"text-danger\">*</span>\r\n          </label>\r\n        </div>\r\n        <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n          <div class=\"field-wrapper\">\r\n            <input type=\"text\" disabled class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.sms_shortcode\" id=\"ch90\">\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n      <div class=\"row\">\r\n        <div class=\"row\">\r\n          <div class=\"c-lg-8 c-sm-8 c-md-8\">\r\n            <h3 class=\"heading-setting\">Transactional SMS</h3>\r\n          </div>\r\n          <div class=\"c-lg-4 c-sm-4 c-md-4\" style=\"padding-right: 5%;\">\r\n            <a class=\"pull-right\" style=\"cursor: pointer;padding-top: 15px;\" (click)=\"smsAllocationHistoryDeatils()\">SMS Allocation History\r\n            </a>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"table table-responsive show-left\">\r\n          <table class=\"assign-width\">\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  Allocated Quota\r\n                </th>\r\n                <th>\r\n                  Used Quota\r\n                </th>\r\n                <th>\r\n                  Available Quota\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr>\r\n                <td>\r\n                  {{instDetails.institute_sms_quota}}\r\n                </td>\r\n                <td>\r\n                  {{instDetails.institute_sms_quota_used}}\r\n                </td>\r\n                <td>\r\n                  {{instDetails.institute_sms_quota_available}}\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n      <div class=\"row\">\r\n        <div class=\"row\">\r\n          <div class=\"c-lg-10\">\r\n            <h3 class=\"heading-setting\">Promotional SMS</h3>\r\n          </div>\r\n        </div>\r\n        <div class=\"table table-responsive show-left\">\r\n          <table class=\"assign-width\">\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  Allocated Quota\r\n                </th>\r\n                <th>\r\n                  Used Quota\r\n                </th>\r\n                <th>\r\n                  Available Quota\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr>\r\n                <td>\r\n                  {{instDetails.institute_campaign_sms_quota}}\r\n                </td>\r\n                <td>\r\n                  {{instDetails.institute_campaign_sms_quota_used}}\r\n                </td>\r\n                <td>\r\n                  {{instDetails.institute_campaign_sms_quota_available}}\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <h2 class=\"heading-setting-main\">Email Settings</h2>\r\n\r\n    <div class=\"general-setting show-left\">\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n          <label for=\"ch28\">Email sender id\r\n          </label>\r\n        </div>\r\n        <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.email_sender_id != ''}\">\r\n            <input type=\"text\" disabled class=\"form-ctrl newDisabled\" id=\"ch28\" name=\"slotNew\" [(ngModel)]=\"instDetails.email_sender_id\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <h2 class=\"heading-setting-main\">FEE</h2>\r\n\r\n    <div class=\"general-setting show-left\">\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n          <label for=\"ch29\">GSTIN\r\n          </label>\r\n        </div>\r\n        <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.gst_in != null }\">\r\n            <input type=\"text\" id=\"ch29\" class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.gst_in\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <h2 class=\"heading-setting-main\">Storage</h2>\r\n\r\n    <div class=\"general-setting show-left\">\r\n      <div class=\"row\" *ngIf=\"(storageInfo != '')\">\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n          <label for=\"ch30\">Total Storage\r\n          </label>\r\n\r\n        </div>\r\n        <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value': (storageInfo.limit_allocated != '') }\">\r\n            <input type=\"text\" disabled id=\"ch30\" class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"storageInfo.storage_allocated\">\r\n          </div>\r\n        </div>\r\n        <div class=\"c-lg-3 c-md-3 c-sm-3\" style=\"padding: 2%;\">\r\n          <a style=\"cursor: pointer;padding-top: 15px;\" (click)=\"downLoadLimitAllocationHistory()\">Download Limit Allocation History</a>\r\n        </div>\r\n      </div>\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n          <label for=\"ch31\">Used\r\n          </label>\r\n        </div>\r\n        <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.sms_shortcode != ''}\">\r\n            <input type=\"text\" id=\"ch31\" disabled class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"storageInfo.limit_allocated\">\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n\r\n    <h2 class=\"heading-setting-main\">Mobile app details</h2>\r\n\r\n    <div class=\"general-setting show-left\" style=\"padding-bottom: 10%;\">\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n          <label for=\"ch32\">Announcement\r\n          </label>\r\n        </div>\r\n        <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.announcement != ''}\">\r\n            <input type=\"textbox\" id=\"ch32\" class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.announcement\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n          <label for=\"ch33\">About Us\r\n          </label>\r\n        </div>\r\n        <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.about_us_text != ''}\">\r\n            <input type=\"textbox\" id=\"ch33\" class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.about_us_text\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3 main-setting\">\r\n          <label for=\"ch34\">App Url\r\n          </label>\r\n        </div>\r\n        <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.student_app_url != ''}\">\r\n            <input type=\"textbox\" id=\"ch34\" class=\"form-ctrl newDisabled\" name=\"slotNew\" [(ngModel)]=\"instDetails.student_app_url\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <section class=\"row setting-footer\">\r\n      <button class=\"btn\" routerLink=\"/home\">Cancel</button>\r\n      <button class=\"btn fullBlue\" (click)=\"updateAllDetails()\">Update</button>\r\n    </section>\r\n  </section>\r\n\r\n  <!-- <section id=\"divPlanOption\">\r\n\r\n      </section>\r\n\r\n      <section id=\"divAccount\" class=\"general-wrapper\"></section>\r\n      <section id=\"divAppDetail\" class=\"general-wrapper\"></section> -->\r\n\r\n  <!-- <aside class=\"pull-right setting-right\" style=\"width:80%;\">\r\n\r\n      <section id=\"divGeneral\" class=\"general-wrapper\">\r\n\r\n\r\n\r\n\r\n        <div class=\"row\">\r\n\r\n          <fieldset style=\"margin-top: 10px;margin-left: 15px;\">\r\n            <legend>Student ID</legend>\r\n            <div class=\"c-sm-4 c-md-4 c-lg-4\" style=\"margin-top: 10px;margin-left: -15px;\">\r\n              <div class=\"radio-options\">\r\n                <div class=\"field-radio-wrapper\">\r\n                  <input type=\"radio\" disabled [checked]=\"(this.instDetails.is_student_displayId_manual == 0)\" (click)=\"checkInputType($event)\"\r\n                    name=\"sFilter\" class=\"form-radio\" value=\"Automatic\" id=\"idAutomatic\">\r\n                  <label for=\"active\">Automatic</label>\r\n                </div>\r\n                <div class=\"field-radio-wrapper\">\r\n                  <input type=\"radio\" disabled [checked]=\"(this.instDetails.is_student_displayId_manual == 1)\" (click)=\"checkInputType($event)\"\r\n                    name=\"sFilter\" value=\"Manual\" class=\"form-radio\" id=\"idManual\">\r\n                  <label for=\"Inactive\">Manual</label>\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"c-sm-4 c-md-4 c-lg-4\" *ngIf=\"(showPrefix == true)\">\r\n              <div class=\"field-wrapper\" [ngClass]=\"{'has-value':instDetails.student_id_prefix != ''}\">\r\n                <input type=\"text\" class=\"form-ctrl\" name=\"slotNew\" [(ngModel)]=\"instDetails.student_id_prefix\" id=\"ch20\">\r\n                <label for=\"ch20\">\r\n                  Student ID Prefix\r\n                </label>\r\n              </div>\r\n            </div>\r\n          </fieldset>\r\n\r\n\r\n        </div>\r\n\r\n\r\n\r\n\r\n        <div class=\"row borderClass\" style=\"margin-top:20px\">\r\n          <h3 class='c-sm-4 c-md-4 c-lg-4'>SMS Setting</h3>\r\n          <a class=\"pull-right\" style=\"cursor: pointer;padding-top: 15px;\" (click)=\"smsAllocationHistoryDeatils()\">SMS Allocation History\r\n          </a>\r\n        </div>\r\n\r\n\r\n        <div class=\"row borderClass\" style=\"margin-top:20px\">\r\n          <h3 class=\"c-sm-4 c-md-4 c-lg-4\">Storage Setting</h3>\r\n          <a class=\"pull-right\" style=\"cursor: pointer;padding-top: 15px;\" (click)=\"downLoadLimitAllocationHistory()\">Download Limit Allocation History</a>\r\n        </div>\r\n\r\n      </section>\r\n\r\n    </aside> -->\r\n\r\n\r\n\r\n</div>\r\n\r\n\r\n\r\n<!-- /////////////////////////////Pop UP HERERERERERRERER     /*///////// -->\r\n\r\n\r\n\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"showAllocationPopup\">\r\n  <div class=\"popup pos-abs\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closeDeletePopup()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n          <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n            <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n              <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n            </g>\r\n            <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n            />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content\" style=\"padding: 0px 15px;margin-bottom: 20px;\" *ngIf=\"openPopUpName == 'SMSHistory'\">\r\n        <div class=\"\">\r\n          <h2>SMS Allocation History Details</h2>\r\n        </div>\r\n        <div class=\"row\" style=\"margin-top: 30px;\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  SMS Type\r\n                </th>\r\n                <th>\r\n                  Quota Allocated\r\n                </th>\r\n                <th>\r\n                  Reason\r\n                </th>\r\n                <th>\r\n                  Updated On\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr id=\"row{{i}}\" *ngFor=\"let row of smsAllocation; let i = index; trackBy: i;\">\r\n                <td>\r\n                  {{row.quoto_type}}\r\n                </td>\r\n                <td>\r\n                  {{row.sms_quota_allocated}}\r\n                </td>\r\n                <td>\r\n                  {{row.reason}}\r\n                </td>\r\n                <td>\r\n                  {{row.created_date}}\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"popup-content\" style=\"padding: 0px 15px;margin-bottom: 20px;\" *ngIf=\"openPopUpName == 'PaymentHistory'\">\r\n\r\n        <div class=\"\">\r\n          <h2>Payment Details</h2>\r\n        </div>\r\n        <div class=\"\" style=\"margin-top: 30px;\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  Created Date\r\n                </th>\r\n                <th>\r\n                  Item\r\n                </th>\r\n                <th>\r\n                  Detail\r\n                </th>\r\n                <th>\r\n                  Due Date\r\n                </th>\r\n                <th>\r\n                  Added Date\r\n                </th>\r\n                <th>\r\n                  Amount Paid\r\n                </th>\r\n                <th>\r\n                  Payment Status\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr id=\"row{{i}}\" *ngFor=\"let row of paymentTable; let i = index; trackBy: i;\">\r\n                <td>\r\n                  {{row.added_date}}\r\n                </td>\r\n                <td>\r\n                  {{row.item}}\r\n                </td>\r\n                <td>\r\n                  {{row.detail}}\r\n                </td>\r\n                <td>\r\n                  {{row.due_date}}\r\n                </td>\r\n                <td>\r\n                  {{row.added_date}}\r\n                </td>\r\n                <td>\r\n                  <span *ngIf=\"row.amount_with_tax!=null\">\r\n                    {{ commonService.currency_default_symbol}}{{row.amount_with_tax.toLocaleString()}}\r\n                  </span>\r\n                </td>\r\n                <td>\r\n                  {{row.pmt_status}}\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n\r\n      </div>\r\n\r\n      <div class=\"popup-content\" style=\"padding: 0px 15px;margin-bottom: 20px;\" *ngIf=\"openPopUpName == 'DownloadLimit'\">\r\n\r\n        <div class=\"\">\r\n          <h2>Download Limit Allocation History Details</h2>\r\n        </div>\r\n        <div class=\"\" style=\"margin-top: 30px;\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  Download Limit(GB)\r\n                </th>\r\n                <th>\r\n                  Reason\r\n                </th>\r\n                <th>\r\n                  Updated On\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr id=\"row{{i}}\" *ngFor=\"let row of limitTable; let i = index; trackBy: i;\">\r\n                <td>\r\n                  {{row.limit_allocated}}\r\n                </td>\r\n                <td>\r\n                  {{row.reason}}\r\n                </td>\r\n                <td>\r\n                  {{row.created_date}}\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>"

/***/ }),

/***/ "./src/app/components/institute-details/institute-details.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.setting-footer {\n  margin-top: 5px;\n  position: fixed;\n  float: right;\n  bottom: 0%;\n  width: 100%;\n  background: white;\n  left: 0px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n  padding: 10px;\n  border-top: 1px solid #ccc;\n  margin: 0px; }\n.general-setting {\n  height: auto;\n  /* width: 70%; */\n  /* margin-left: 2%; */\n  background: white;\n  margin-bottom: 10px;\n  padding-bottom: 15px; }\n.assign-width {\n  width: 96%; }\n.show-left {\n  padding-left: 2%; }\n.heading-setting {\n  padding-top: 2%;\n  padding-left: 2%; }\n.switch {\n  margin-top: 25px;\n  position: relative;\n  display: inline-block;\n  width: 50px;\n  height: 21px; }\n.switch input {\n  display: none; }\n.slider {\n  position: absolute;\n  cursor: pointer;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background-color: #ccc;\n  -webkit-transition: .4s;\n  transition: .4s; }\n.slider:before {\n  position: absolute;\n  content: \"\";\n  height: 16px;\n  width: 16px;\n  left: 4px;\n  bottom: 4px;\n  background-color: white;\n  -webkit-transition: .4s;\n  transition: .4s;\n  top: 3px; }\n.switch-n input:checked + .slider {\n  background-color: #2196F3; }\n.switch-n input:focus + .slider {\n  -webkit-box-shadow: 0 0 1px #2196F3;\n          box-shadow: 0 0 1px #2196F3; }\n.switch-n input:checked + .slider:before {\n  -webkit-transform: translateX(26px);\n  transform: translateX(26px); }\n/* Rounded sliders */\n.slider.round {\n  border-radius: 34px; }\n.newDisabled:disabled {\n  background: #efefef !important; }\n.newDisabled {\n  width: 75%;\n  padding: 5px;\n  height: 30px; }\n.slider.round:before {\n  border-radius: 50%; }\n.heading-setting-main {\n  margin: 2% 0% 0% 0%; }\n.main-setting {\n  margin: 2% -1% 0% 1%; }\n.middle-section {\n  padding: 1%;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.showDivClass {\n  display: ''; }\n.hideDivClass {\n  display: none; }\n.extraMarginTen {\n  margin-top: 10px !important;\n  margin-bottom: 10px; }\ninput[type=number]::-webkit-inner-spin-button,\ninput[type=number]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0; }\n.borderClass {\n  border-top: 0.1px solid #f1f1f1;\n  margin-top: 20px; }\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 850px;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\ntable thead tr th {\n  padding-top: 10px;\n  padding-bottom: 10px; }\ntable tbody tr td {\n  padding-top: 10px;\n  padding-bottom: 10px; }\n.field-checkbox-wrapper,\n.field-radio-wrapper {\n  position: relative;\n  padding-left: 25px;\n  margin-bottom: 10px; }\n.field-radio-wrapper .form-radio {\n  opacity: 0;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px;\n  z-index: 1; }\n.field-radio-wrapper .form-radio + label {\n  vertical-align: middle;\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s; }\n.field-radio-wrapper .form-radio + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 50%;\n  position: absolute;\n  left: 0;\n  top: 0;\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s; }\n.field-radio-wrapper .form-radio:checked + label:after {\n  border: 2px solid #0084f6; }\n.field-radio-wrapper .form-radio + label:before {\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s;\n  width: 1px;\n  height: 1px;\n  left: 9px;\n  top: 9px;\n  position: absolute;\n  content: ''; }\n.field-radio-wrapper .form-radio:checked + label:before {\n  content: '';\n  width: 10px;\n  height: 10px;\n  background: #0084f6;\n  border-radius: 50%;\n  left: 3px;\n  top: 3px; }\n.field-radio-wrapper .form-radio:checked + label {\n  color: #0084f6; }\n"

/***/ }),

/***/ "./src/app/components/institute-details/institute-details.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return InstituteDetailsComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_institute_details_institute_details_service__ = __webpack_require__("./src/app/services/institute-details/institute-details.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var InstituteDetailsComponent = /** @class */ (function () {
    function InstituteDetailsComponent(apiService, commonService) {
        this.apiService = apiService;
        this.commonService = commonService;
        this.isRippleLoad = false;
        this.instituteLogoDetails = [];
        this.kycType = [];
        this.instituteOptions = [];
        this.instituteOptionDataSource = [];
        this.planDetail = [];
        this.planDetailDataSource = [];
        this.instDetails = {};
        this.showAllocationPopup = false;
        this.openPopUpName = '';
        this.smsAllocation = [];
        this.paymentTable = [];
        this.limitTable = [];
        this.storageInfo = {};
        this.showPrefix = false;
        this.createNewSlot = false;
        this.dividersObj = {
            0: true,
            1: true,
            2: true,
            3: true,
            4: true,
            5: true
        };
    }
    InstituteDetailsComponent.prototype.ngOnInit = function () {
        this.commonService.removeSelectionFromSideNav();
        this.updatePrefillData();
    };
    InstituteDetailsComponent.prototype.updatePrefillData = function () {
        this.getInstituteDetails();
        this.getInstituteKYCDetails();
        this.getOptionDetailsFromServer();
        this.getPlanDetailsFromServer();
        this.getStorageInformation();
    };
    InstituteDetailsComponent.prototype.getInstituteDetails = function () {
        var _this = this;
        this.apiService.getInstituDetailsAll().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.instituteDetailsAll = res;
            _this.instDetails = Object.assign({}, res);
            if (_this.instDetails.is_student_displayId_manual == 0) {
                _this.showPrefix = true;
            }
        }, function (err) {
            _this.isRippleLoad = false;
            //console.log(err);
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    InstituteDetailsComponent.prototype.getInstituteKYCDetails = function () {
        var _this = this;
        this.apiService.getKycTypeDetails().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.kycType = res;
        }, function (err) {
            _this.isRippleLoad = false;
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    InstituteDetailsComponent.prototype.getOptionDetailsFromServer = function () {
        var _this = this;
        this.apiService.getOptionDetails().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.instituteOptionDataSource = res;
        }, function (err) {
            _this.isRippleLoad = false;
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    InstituteDetailsComponent.prototype.getPlanDetailsFromServer = function () {
        var _this = this;
        this.apiService.getPlanDetails().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.planDetailDataSource = res;
            _this.instituteOptions = _this.getOptionOfInstitute(_this.instituteOptionDataSource);
            _this.planDetail = _this.getPlanOfInstitute(_this.planDetailDataSource);
        }, function (err) {
            _this.isRippleLoad = false;
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    InstituteDetailsComponent.prototype.updateAllDetails = function () {
        var _this = this;
        this.isRippleLoad = true;
        var dataToSend = this.formatDataJsonToSend();
        this.apiService.updateDetailsToServer(dataToSend).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.commonService.showErrorMessage('success', 'Updated Successfully', 'Details Updated Successfully');
        }, function (err) {
            _this.isRippleLoad = false;
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    InstituteDetailsComponent.prototype.getPaymentDeatils = function () {
        var _this = this;
        this.paymentTable = [];
        this.isRippleLoad = true;
        this.apiService.getPayementInfoFromServer().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.paymentTable = res;
            _this.showAllocationPopup = true;
            _this.openPopUpName = "PaymentHistory";
        }, function (err) {
            _this.isRippleLoad = false;
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    InstituteDetailsComponent.prototype.smsAllocationHistoryDeatils = function () {
        var _this = this;
        this.smsAllocation = [];
        this.isRippleLoad = true;
        this.apiService.getSmsInfoFromServer().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.smsAllocation = res;
            _this.showAllocationPopup = true;
            _this.openPopUpName = "SMSHistory";
        }, function (err) {
            _this.isRippleLoad = false;
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    InstituteDetailsComponent.prototype.downLoadLimitAllocationHistory = function () {
        var _this = this;
        this.limitTable = [];
        this.isRippleLoad = true;
        this.apiService.getDownloadLimitFromServer().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.limitTable = res;
            _this.showAllocationPopup = true;
            _this.openPopUpName = "DownloadLimit";
        }, function (err) {
            _this.isRippleLoad = false;
            //console.log(err);
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    InstituteDetailsComponent.prototype.getStorageInformation = function () {
        var _this = this;
        this.apiService.getStorageLimitFromServer().subscribe(function (res) {
            _this.storageInfo = res;
            _this.storageInfo.storage_allocated = _this.storageInfo.storage_allocated;
        }, function (err) {
            _this.isRippleLoad = false;
            //console.log(err);
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    InstituteDetailsComponent.prototype.closeDeletePopup = function () {
        this.showAllocationPopup = false;
        this.openPopUpName = "";
    };
    InstituteDetailsComponent.prototype.changeKYCInformation = function (event) {
        for (var i = 0; i < this.kycType.length; i++) {
            if (this.kycType[i].data_key == event) {
                this.instDetails.kyc_document_name = this.kycType[i].kyc_document_name;
                this.instDetails.kyc_document = this.kycType[i].kyc_document;
                this.instDetails.kyc_document_type = this.kycType[i].kyc_document_type.toString();
            }
            else {
                this.instDetails.kyc_document_name = '';
                this.instDetails.kyc_document = '';
                this.instDetails.kyc_document_type = event;
            }
        }
    };
    InstituteDetailsComponent.prototype.formatDataJsonToSend = function () {
        var obj = {};
        obj.institute_logo = this.instDetails.institute_logo;
        obj.institute_header1 = this.instDetails.institute_header1;
        obj.institute_header2 = this.instDetails.institute_header2;
        obj.institute_header3 = this.instDetails.institute_header3;
        obj.institute_footer = this.instDetails.institute_footer;
        obj.fb_page_url = this.instDetails.fb_page_url;
        obj.website_url = this.instDetails.website_url;
        obj.institute_short_code = this.instDetails.institute_short_code;
        obj.tag_line = this.instDetails.tag_line;
        obj.about_us_text = this.instDetails.about_us_text;
        obj.institute_testprep_logo = this.instDetails.institute_testprep_logo;
        obj.announcement = this.instDetails.announcement;
        obj.owner_name = this.instDetails.owner_name;
        obj.owner_primary_email = this.instDetails.owner_primary_email;
        obj.owner_secondary_email = this.instDetails.owner_secondary_email;
        obj.owner_primary_phone = this.instDetails.owner_primary_phone;
        obj.admin_name = this.instDetails.admin_name;
        if (!(this.validatePhoneNumber(this.instDetails.admin_primary_phone))) {
            this.commonService.showErrorMessage('error', '', 'Please check contact number');
            return;
        }
        if (!(this.validateCaseSensitiveEmail(this.instDetails.admin_primary_email))) {
            this.commonService.showErrorMessage('error', '', 'Please check email address');
            return;
        }
        obj.admin_primary_phone = this.instDetails.admin_primary_phone;
        obj.admin_primary_email = this.instDetails.admin_primary_email;
        if (this.instDetails.student_id_type == null) {
            obj.student_id_type = "Automatic";
        }
        else {
            obj.student_id_type = this.instDetails.student_id_type;
        }
        if (this.instDetails.student_id_type == "Manual") {
            obj.student_id_prefix = '';
        }
        else {
            obj.student_id_prefix = this.instDetails.student_id_prefix;
        } //Please check this case
        if (this.instDetails.gst_in == "" || this.instDetails.gst_in == null) {
            obj.gst_in = '';
        }
        else {
            obj.gst_in = this.instDetails.gst_in;
        }
        obj.kyc_document_name = this.instDetails.kyc_document_name;
        obj.kyc_document = this.instDetails.kyc_document;
        obj.student_app_url = this.instDetails.student_app_url;
        obj.kyc_document_type = this.instDetails.kyc_document_type;
        return obj;
    };
    InstituteDetailsComponent.prototype.checkInputType = function (event) {
        if (event.target.id == "idManual") {
            this.showPrefix = false;
            this.instDetails.student_id_type = "Manual";
        }
        else {
            this.showPrefix = true;
            this.instDetails.student_id_type = "Automatic";
        }
    };
    InstituteDetailsComponent.prototype.getPlanOfInstitute = function (data) {
        var obj = [];
        for (var i = 0; i < data.length; i++) {
            if (data[i].id == this.instDetails.plan_id) {
                obj.push(data[i]);
            }
        }
        return obj;
    };
    InstituteDetailsComponent.prototype.getOptionOfInstitute = function (data) {
        var obj = [];
        var arr = [];
        if (this.instDetails.hasOwnProperty('option_selected_id')) {
            if (this.instDetails.option_selected_id != null && this.instDetails.option_selected_id != "") {
                arr = this.instDetails.option_selected_id.split(',');
                for (var i = 0; i < data.length; i++) {
                    for (var j = 0; j < arr.length; j++) {
                        if (data[i].id == arr[i]) {
                            obj.push(data[i]);
                        }
                    }
                }
            }
            else {
                return obj;
            }
        }
        return obj;
    };
    InstituteDetailsComponent.prototype.toggleUpAndDownButton = function (index) {
        if (this.dividersObj[index] == true) {
            this.dividersObj[index] = false;
        }
        else {
            this.dividersObj[index] = true;
        }
    };
    InstituteDetailsComponent.prototype.uploadDocument = function () {
        this.uploadDoc.nativeElement.click();
    };
    InstituteDetailsComponent.prototype.validatePhoneNumber = function (data) {
        var check = false;
        if (data != "" && data != null) {
            if (isNaN(data) == false && data.length == 10) {
                check = true;
            }
            else {
                check = false;
            }
            return check;
        }
        else {
            return true;
        }
    };
    InstituteDetailsComponent.prototype.validateCaseSensitiveEmail = function (email) {
        if (email != '' && email != null) {
            var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
            if (reg.test(email)) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return true;
        }
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('idUploadDoc'),
        __metadata("design:type", Object)
    ], InstituteDetailsComponent.prototype, "uploadDoc", void 0);
    InstituteDetailsComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-institute-details',
            template: __webpack_require__("./src/app/components/institute-details/institute-details.component.html"),
            styles: [__webpack_require__("./src/app/components/institute-details/institute-details.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_institute_details_institute_details_service__["a" /* InstituteDetailService */],
            __WEBPACK_IMPORTED_MODULE_2__services_common_service__["a" /* CommonServiceFactory */]])
    ], InstituteDetailsComponent);
    return InstituteDetailsComponent;
}());



/***/ }),

/***/ "./src/app/components/institute-details/institute-details.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InstituteDetailsModule", function() { return InstituteDetailsModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__institute_details_component__ = __webpack_require__("./src/app/components/institute-details/institute-details.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_institute_details_institute_details_service__ = __webpack_require__("./src/app/services/institute-details/institute-details.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var InstituteDetailsModule = /** @class */ (function () {
    function InstituteDetailsModule() {
    }
    InstituteDetailsModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_4__institute_details_component__["a" /* InstituteDetailsComponent */],
                        pathMatch: 'prefix',
                    }
                ]),
                __WEBPACK_IMPORTED_MODULE_2__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_forms__["FormsModule"]
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_4__institute_details_component__["a" /* InstituteDetailsComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_5__services_institute_details_institute_details_service__["a" /* InstituteDetailService */]
            ]
        })
    ], InstituteDetailsModule);
    return InstituteDetailsModule;
}());



/***/ }),

/***/ "./src/app/services/institute-details/institute-details.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return InstituteDetailService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var InstituteDetailService = /** @class */ (function () {
    function InstituteDetailService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseURL = "";
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseURL = this.auth.getBaseUrl();
    }
    InstituteDetailService.prototype.successCallback = function (res) {
        return res;
    };
    InstituteDetailService.prototype.errorCallBack = function (error) {
        return error;
    };
    InstituteDetailService.prototype.getInstituDetailsAll = function () {
        var url = this.baseURL + "/api/v1/institutes/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    InstituteDetailService.prototype.getInstituteLogoDetailsFromServer = function () {
        var url = this.baseURL + "/api/v1/institutes/getlogo/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    InstituteDetailService.prototype.getSubBranchDetails = function () {
        var url = this.baseURL + "/api/v1/institutes/all/subBranches/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    InstituteDetailService.prototype.getPlanDetails = function () {
        var url = this.baseURL + "/api/v1/proctur/getAllPlans";
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    InstituteDetailService.prototype.getOptionDetails = function () {
        var url = this.baseURL + "/api/v1/proctur/getAllOptions";
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    InstituteDetailService.prototype.getKycTypeDetails = function () {
        var url = this.baseURL + "/api/v1/masterData/type/KYC_DOCUMENT_TYPE";
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    InstituteDetailService.prototype.updateDetailsToServer = function (data) {
        data.institute_id = this.institute_id;
        var url = this.baseURL + "/api/v1/institutes/" + this.institute_id;
        return this.http.put(url, data, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    InstituteDetailService.prototype.getPayementInfoFromServer = function () {
        var data = {
            inst_id: this.institute_id
        };
        var url = this.baseURL + "/api/v1/institute/payment/getReport/";
        return this.http.post(url, data, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    InstituteDetailService.prototype.getSmsInfoFromServer = function () {
        var data = {
            institution_id: this.institute_id
        };
        var url = this.baseURL + "/api/v1/institute/SMS/transaction/getReport";
        return this.http.post(url, data, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    InstituteDetailService.prototype.getDownloadLimitFromServer = function () {
        var data = {
            institution_id: this.institute_id
        };
        var url = this.baseURL + "/api/v1/institute/download_limit/transaction/getReport";
        return this.http.post(url, data, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    InstituteDetailService.prototype.getStorageLimitFromServer = function () {
        var url = this.baseURL + "/api/v1/instFileSystem/getUsedSpace/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    InstituteDetailService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */], __WEBPACK_IMPORTED_MODULE_2__authenticator_service__["a" /* AuthenticatorService */]])
    ], InstituteDetailService);
    return InstituteDetailService;
}());



/***/ })

});
//# sourceMappingURL=institute-details.module.chunk.js.map