webpackJsonp(["live-classes.module"],{

/***/ "./src/app/components/live-classes-module/add-class/add-class.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper black-bg\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n\r\n<div class=\"middle-section\">\r\n  <aside class=\"middle-full\">\r\n    <section class=\"middle-main clearFix activity-wrapper\">\r\n      <section class=\"row header\" style=\"margin-right: 0px; margin-left: 0px;margin-bottom: 5px;\">\r\n        <div class=\"row\" style=\"margin-left: 0px;margin-right: 0px;\">\r\n          <h2 class=\"pull-left\">\r\n          <a routerLink=\"/view/live-classes\">\r\n            Live class\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n            Add Live Class\r\n          </h2>\r\n        </div>\r\n      </section>\r\n\r\n      <!-- <h2 class=\"\" style=\"margin:10px 0px;\">\r\n        Add Live Class\r\n      </h2> -->\r\n\r\n      <div class=\"border-container\">\r\n      </div>\r\n\r\n      <section class=\"student-tab\">\r\n        <ul class=\"nav-tab\">\r\n          <li id=\"li-one\" class=\"active\">\r\n            <div class=\"navigator\" id=\"class-icon\" (click)=\"switchToView($event.target.id)\">\r\n              <span id=\"class-icon\">1</span>\r\n              <p id=\"class-icon\">Class Details</p>\r\n            </div>\r\n          </li>\r\n          <li class=\"\" id=\"li-two\">\r\n            <div class=\"navigator\" id=\"assignStudent-icon\" (click)=\"switchToView($event.target.id)\">\r\n              <span id=\"assignStudent-icon\">2</span>\r\n              <p id=\"assignStudent-icon\">Assign Students</p>\r\n            </div>\r\n          </li>\r\n        </ul>\r\n      </section>\r\n\r\n      <section id=\"classDetails\" *ngIf=\"isBasicActive\">\r\n        <div class=\"class_details_container\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"topicName\">Topic Name<span class=\"text-danger\">*</span> </label>\r\n            <input type=\"text\" value=\"\" id=\"topicName\" class=\"form-ctrl\" name=\"topicName\" required [(ngModel)]=\"topicName\" placeholder=\"Enter Topic Name\"/>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper-container\">\r\n\r\n            <div class=\"field-wrapper datePickerBox\" style=\"width: 25%;\">\r\n              <label for=\"date\">Date<span class=\"text-danger\">*</span></label>\r\n              <input type=\"text\" class=\"form-ctrl\" bsDatepicker readonly=\"true\" [(ngModel)]=\"scheduledateFrom\" (ngModelChange)=\"getEvent($event)\" id=\"date\" style=\"height: 36px;\">\r\n              <!-- <i class=\"fa fa-calendar\" style=\"cursor: pointer;color: #1283f4;\" (click)=\"openCalendar('date')\"></i> -->\r\n            </div>\r\n\r\n            <div class=\"field-wrapper\" style=\"width: 25%;\">\r\n              <label for=\"date\">From<span class=\"text-danger\">*</span></label>\r\n              <div class=\"from\">\r\n                <select class=\"made-out\" id=\"from1\" [(ngModel)]=\"hoursFrom\" (ngModelChange)=\"getEventHourFrom($event)\">\r\n                    <option value=\"\" disabled  selected=\"selected\" hidden>HH</option>\r\n                    <option *ngFor=\"let i of hour\" [value]=\"i\">\r\n                        {{i}}\r\n                    </option>\r\n                </select>\r\n                <select class=\"made-out\" id=\"from2\" style=\"margin-left:15px;\" [(ngModel)]=\"minuteFrom\" (ngModelChange)=\"getEventHourFrom($event)\">\r\n                    <option value=\"\" disabled  selected=\"selected\" hidden>MM</option>\r\n                    <option [value]=\"i\" *ngFor=\"let i of minutes\" >\r\n                        {{i}}\r\n                    </option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"field-wrapper\" style=\"width: 25%;\">\r\n              <label for=\"date\">To<span class=\"text-danger\">*</span></label>\r\n              <div class=\"from\">\r\n                <select class=\"made-out\" id=\"to1\" [(ngModel)]=\"hoursTo\" (ngModelChange)=\"getEventHourFrom()\">\r\n                    <option value=\"\" disabled  selected=\"selected\" hidden>HH</option>\r\n                    <option *ngFor=\"let i of hour\" [value]=\"i\">\r\n                        {{i}}\r\n                    </option>\r\n                </select>\r\n                <select class=\"made-out\" id=\"to2\" style=\"margin-left:15px;\" [(ngModel)]=\"minuteTo\" (ngModelChange)=\"getEventHourFrom($event)\">\r\n                    <option value=\"\" disabled  selected=\"selected\" hidden>MM</option>\r\n                    <option *ngFor=\"let i of minutes\" [value]=\"i\">\r\n                        {{i}}\r\n                    </option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n          </div>\r\n\r\n          <div class=\"field-wrapper faculty_container\">\r\n            <label for=\"faculty\">Faculty Name(s)<span class=\"text-danger\">*</span> </label>\r\n            <!-- <input type=\"text\" value=\"\" id=\"faculty\" class=\"form-ctrl\" name=\"faculty\" required /> -->\r\n            <ng-multiselect-dropdown\r\n              [placeholder]=\"'Select Faculty'\"\r\n              [data]=\"teachersAssigned\"\r\n              [settings]=\"facultySettings\"\r\n              [(ngModel)]=\"selectedFacultyList\">\r\n            </ng-multiselect-dropdown>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper moderator_container\">\r\n            <label for=\"moderator\">Moderator Name(s) </label>\r\n            <ng-multiselect-dropdown\r\n              [placeholder]=\"'Select Moderator'\"\r\n              [data]=\"userAssigned\"\r\n              [settings]=\"moderatorSettings\"\r\n              [(ngModel)]=\"selectedModeratorList\" >\r\n            </ng-multiselect-dropdown>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper moderator_container\" *ngIf=\"isShowProductOption\">\r\n            <label for=\"product\">Product(s) </label><br>\r\n              <select class=\"made-out\" id=\"product\" [(ngModel)]=\"product_id\" style=\"width: 100%;padding: 6px 12px;border: 1px solid #adadad;border-radius: 4px;\" (change)=\"onChangeProduct($event.target.value)\">\r\n                <option value=\"\">Select Product(s)</option>\r\n                <option *ngFor=\"let product of productData\" [value]=\"product.id\" >\r\n                      {{product.title}}\r\n                  </option>\r\n              </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper student_list_container\" *ngIf=\"isShowProductOption\" style=\"width: 73%\">\r\n            <label for=\"students\">User Name(s) </label>\r\n            <ng-multiselect-dropdown class=\"container\"\r\n              [placeholder]=\"'Select Users'\"\r\n              [data]=\"userData\"\r\n              [settings]=\"userListSetting\"\r\n              [(ngModel)]=\"selectedUserList\">\r\n            </ng-multiselect-dropdown>\r\n          </div>\r\n\r\n\r\n          <div class=\"action-button-container\">\r\n            <div class=\"action-btn-item-1\">\r\n              <!-- <button type=\"button\" name=\"button\" class=\"back-btn\" (click)=\"cancel()\">Back</button> -->\r\n            </div>\r\n            <div class=\"action-btn-item-2\">\r\n              <button type=\"button\" name=\"button\" class=\"cancel-btn\" (click)=\"cancel()\">Cancel</button>&nbsp;&nbsp;&nbsp;&nbsp;\r\n              <button type=\"button\" name=\"button\" class=\"next-btn\" (click)=\"checkMandatoryFields()\">Next</button>\r\n            </div>\r\n          </div>\r\n\r\n        </div>\r\n      </section>\r\n\r\n      <section id=\"assignStudent\" *ngIf=\"isOtherActive\">\r\n        <div class=\"add_student_container\">\r\n          <div class=\"field-wrapper\"  *ngIf=\"!isProfessional\">\r\n            <label for=\"master_course\">Master Course<span class=\"text-danger\">*</span> </label>\r\n            <select class=\"form-ctrl\" name=\"master_course\" id=\"master_course\" [(ngModel)]=\"courseValue\" (ngModelChange)=\"getCourses($event)\">\r\n              <option value=\"\" disabled  selected=\"selected\" hidden>Select Master Course</option>\r\n              <option *ngFor=\"let i of masters\" [value]=\"i.master_course\">\r\n                  {{i.master_course}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper\"  *ngIf=\"isProfessional\">\r\n            <label for=\"batch\">Batches<span class=\"text-danger\">*</span> </label>\r\n            <select class=\"form-ctrl\" name=\"batch\" id=\"batch\" [(ngModel)]=\"batchesIds\" (ngModelChange)=\"getBatchesCoursesIds($event)\">\r\n              <option value=\"\" disabled  selected=\"selected\" hidden>Select Batch</option>\r\n              <option *ngFor=\"let i of batches\" [value]=\"i.batch_id\">\r\n                  {{i.batch_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper\" *ngIf=\"!isProfessional\">\r\n            <label for=\"course\">Course<span class=\"text-danger\">*</span> </label>\r\n            <select class=\"form-ctrl\" name=\"course\" id=\"course\" [(ngModel)]=\"courseIds\" (ngModelChange)=\"getBatchesCoursesIds($event)\">\r\n              <option value=\"\"  disabled  selected=\"selected\" hidden>Select Course</option>\r\n              <option *ngFor=\"let i of courses\" [value]=\"i.course_id\">\r\n                  {{i.course_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper student_list_container\">\r\n            <label for=\"students\">Student Name(s)<span class=\"text-danger\">*</span> </label>\r\n            <ng-multiselect-dropdown class=\"container\"\r\n              [placeholder]=\"'Select Students'\"\r\n              [data]=\"studentList\"\r\n              [settings]=\"studentListSettings\"\r\n              [(ngModel)]=\"selectedStudentList\" >\r\n            </ng-multiselect-dropdown>\r\n          </div>\r\n\r\n\r\n              <div> \r\n                  <div class=\"AdvanceSetting\">\r\n                      <span style=\"font-weight: 600;\">Advance settings</span>\r\n                  </div>\r\n                      <div class=\"AdvanceSettingDiv\">\r\n                              <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;margin:5px;margin-top: 20px;margin-left: 10px;\">\r\n                                  <input type=\"checkbox\" name=\"expenses\" [(ngModel)]=\"addOnlineClass.sent_notification_flag\" [value]=\"0\" class=\"form-checkbox\" id=\"qun\">\r\n                                  <label for=\"qun\">Send Notification</label>\r\n                                  <div class=\"questionInfo inline-relative\">\r\n                                    <span class=\"qInfoIcon i-class\">i</span>\r\n                                    <div class=\"tooltip-box-field\">\r\n                                        All the members in \r\n                                        <br>meeting will recieve\r\n                                        <br>sms notification for \r\n                                        <br>the session.\r\n                                    </div>\r\n                                  </div>\r\n                                  <!-- <i class=\"fa fa-commenting\" aria-hidden=\"true\" style=\"color: #1283f4;margin-left: 5px;\"></i> -->\r\n                              </div>\r\n                \r\n                            <!-- Private Access -->\r\n                            <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;margin:5px;margin-top: 20px;\">\r\n                              <input type=\"checkbox\" name=\"private_access\" [(ngModel)]=\"addOnlineClass.private_access\" [value]=\"0\" class=\"form-checkbox\" id=\"private_access\">\r\n                              <label for=\"private_access\">Private Access</label>\r\n                              <div class=\"questionInfo inline-relative\">\r\n                                <span class=\"qInfoIcon i-class\">i</span>\r\n                                <div class=\"tooltip-box-field\">\r\n                                    Only the users invited\r\n                                    <br> using e-mail ID would\r\n                                    <br> be able to join. Direct\r\n                                    <br> link sharing of session \r\n                                    <br>won't work.\r\n                                </div>\r\n                              </div>\r\n                            </div>\r\n                \r\n                            <!-- Enable lobby -->\r\n                            <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;margin:5px;margin-top: 20px;margin-left: 10px;\">\r\n                              <input type=\"checkbox\" name=\"access_enable_lobby\" [(ngModel)]=\"addOnlineClass.access_enable_lobby\" [value]=\"0\" class=\"form-checkbox\" id=\"access_enable_lobby\">\r\n                              <label for=\"access_enable_lobby\">Access Enable Lobby</label>\r\n                              <div class=\"questionInfo inline-relative\">\r\n                                <span class=\"qInfoIcon i-class\">i</span>\r\n                                <div class=\"tooltip-box-field\">\r\n                                    All the students will \r\n                                    <br>wait in waiting room\r\n                                    <br> after joining the \r\n                                    <br> session. Teachers will\r\n                                    <br> have access to allow\r\n                                    <br> students in the \r\n                                    <br>meeting.\r\n                                </div>\r\n                              </div>\r\n                            </div>\r\n                \r\n                            <!-- Access before start -->\r\n                            <!-- <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;margin:5px;margin-top: 20px;\">\r\n                                <input type=\"checkbox\" name=\"access_before_start\" [(ngModel)]=\"addOnlineClass.access_before_start\" [value]=\"0\" class=\"form-checkbox\" id=\"access_before_start\">\r\n                                <label for=\"access_before_start\">Access before start</label>\r\n                                <div class=\"questionInfo inline-relative\">\r\n                                  <span class=\"qInfoIcon i-class\">i</span>\r\n                                  <div class=\"tooltip-box-field\">\r\n                                      The meeting can only \r\n                                      <br> be started one minute\r\n                                      <br> before the start time \r\n                                      <br>of the session.\r\n                                  </div>\r\n                                </div>\r\n                              </div> -->\r\n                      </div>\r\n                  </div>\r\n\r\n\r\n          <div class=\"action-button-container\">\r\n            <div class=\"action-btn-item-1\">\r\n              <button type=\"button\" name=\"button\" class=\"back-btn\" (click)=\"navigateTo('classDetails')\">Back</button>\r\n            </div>\r\n            <div class=\"action-btn-item-2\">\r\n              <button type=\"button\" name=\"button\" class=\"cancel-btn\" (click)=\"cancel()\">Cancel</button>&nbsp;&nbsp;&nbsp;&nbsp;\r\n              <button type=\"button\" name=\"button\" class=\"next-btn\" (click)=\"scheduleClass()\">Submit</button>\r\n            </div>\r\n          </div>\r\n\r\n        </div>\r\n      </section>\r\n\r\n    </section>\r\n  </aside>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/live-classes-module/add-class/add-class.component.scss":
/***/ (function(module, exports) {

module.exports = "html {\n  overflow-y: scroll; }\n\n.middle-section {\n  padding: 1%; }\n\n.border-container {\n  border-top: 1px solid #e3e3e3; }\n\n.student-tab .nav-tab {\n  margin-left: 35%; }\n\n.made-out {\n  border: 1px solid #efefef;\n  text-align: center; }\n\n.class_details_container {\n  width: 60%;\n  margin-left: 20%;\n  margin-right: 20%;\n  -webkit-box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.16);\n          box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.16);\n  padding: 30px;\n  margin-bottom: 20px; }\n\n.class_details_container .field-wrapper {\n    margin-top: 10px; }\n\n.class_details_container .field-wrapper #topicName {\n      width: 45%;\n      border-radius: 4px;\n      margin-top: 5px;\n      border-color: #c5c5cc; }\n\n.class_details_container .field-wrapper #faculty, .class_details_container .field-wrapper #moderator {\n      width: 40%;\n      border-radius: 4px;\n      margin-top: 5px;\n      border-color: #c5c5cc; }\n\n.class_details_container .field-wrapper {\n    position: relative; }\n\n.class_details_container .field-wrapper.datePickerBox .form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent; }\n\n.class_details_container .field-wrapper.datePickerBox:after {\n      content: '';\n      background: url(/./assets/images/calendar.svg) no-repeat;\n      position: absolute;\n      right: 57px;\n      top: 35px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n\n.class_details_container .faculty_container, .class_details_container .moderator_container {\n    width: 45%;\n    border-radius: 4px;\n    margin-top: 5px;\n    border-color: #c5c5cc;\n    font-size: 14px; }\n\n.class_details_container .faculty_container label, .class_details_container .moderator_container label {\n      margin-bottom: 5px; }\n\n.class_details_container .field-wrapper-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    width: 100%; }\n\n.class_details_container .field-wrapper-container .from {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start; }\n\n.class_details_container .field-wrapper-container .from #from1, .class_details_container .field-wrapper-container .from #to1 {\n        width: 40%;\n        border-radius: 4px;\n        margin-top: 5px;\n        border-color: #c5c5cc;\n        height: 36px; }\n\n.class_details_container .field-wrapper-container .from #from2, .class_details_container .field-wrapper-container .from #to2 {\n        width: 30%;\n        border-radius: 4px;\n        margin-top: 5px;\n        border-color: #c5c5cc;\n        height: 36px; }\n\n.class_details_container .field-wrapper-container #date {\n      width: 70%;\n      border-radius: 4px;\n      margin-top: 5px;\n      border-color: #c5c5cc; }\n\n.multiselect-dropdown {\n  font-size: 12px; }\n\n.multiselect-dropdown .dropdown-down {\n    border-top: 5px solid black;\n    border-left: 5px solid transparent;\n    border-right: 5px solid transparent; }\n\n.multiselect-dropdown .dropdown-up {\n    border-bottom: 5px solid black;\n    border-left: 5px solid transparent;\n    border-right: 5px solid transparent; }\n\n.action-button-container {\n  margin-top: 20px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  width: 100%; }\n\n.action-button-container .action-btn-item-1 {\n    width: 20%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: start;\n        -ms-flex-pack: start;\n            justify-content: flex-start; }\n\n.action-button-container .action-btn-item-1 .back-btn {\n      border: 1px solid #1283f4;\n      text-align: center;\n      color: #1283f4;\n      width: 80px;\n      height: 35px;\n      border-radius: 4px;\n      background: white; }\n\n.action-button-container .action-btn-item-2 {\n    width: 30%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between; }\n\n.action-button-container .action-btn-item-2 .cancel-btn {\n      border: 1px solid #f41212;\n      text-align: center;\n      color: #f41212;\n      width: 100px;\n      height: 35px;\n      border-radius: 4px;\n      background: white; }\n\n.action-button-container .action-btn-item-2 .next-btn {\n      border: 1px solid #1283f4;\n      text-align: center;\n      background: #1283f4;\n      color: white;\n      width: 100px;\n      height: 35px;\n      border-radius: 4px; }\n\n.add_student_container {\n  width: 60%;\n  margin-left: 20%;\n  margin-right: 20%;\n  -webkit-box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.16);\n          box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.16);\n  padding: 30px;\n  margin-bottom: 20px; }\n\n.add_student_container .field-wrapper {\n    margin-top: 10px; }\n\n.add_student_container .field-wrapper #master_course, .add_student_container .field-wrapper #course, .add_student_container .field-wrapper #batch {\n      width: 45%;\n      border-radius: 4px;\n      margin-top: 5px;\n      border-color: #c5c5cc; }\n\n.add_student_container .student_list_container {\n    width: 85%;\n    border-radius: 4px;\n    margin-top: 5px;\n    border-color: #c5c5cc;\n    font-size: 14px; }\n\n.add_student_container .student_list_container label {\n      margin-bottom: 5px; }\n\n@media screen and (max-width: 2000px) and (min-width: 1400px) {\n  .field-wrapper.datePickerBox:after {\n    content: '';\n    right: 65px !important; } }\n\n.black-bg {\n  background: rgba(12, 11, 11, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 6;\n  width: 100%; }\n\n.field-checkbox-wrapper, .field-radio-wrapper {\n  position: relative;\n  padding-left: 25px;\n  width: 40%; }\n\n.qInfoIcon {\n  width: 17px;\n  margin-left: 4px;\n  height: 20px;\n  border: 1px solid #ccc;\n  border-radius: 50%;\n  display: block;\n  text-align: center;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  line-height: 20px;\n  font-weight: 600;\n  font-size: 12px;\n  cursor: pointer;\n  -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n          box-shadow: 0px 0px 1px 0px #ccc inset;\n  color: #888;\n  -webkit-transition: all 0.2s linear;\n  transition: all 0.2s linear; }\n\n.tooltip-box-field {\n  white-space: nowrap;\n  min-height: 41px;\n  line-height: 12px;\n  padding: 5px 5px;\n  overflow: visible;\n  color: black;\n  font-weight: bold;\n  top: 30px; }\n\n.tooltip-box-field.lg {\n    width: 200px;\n    white-space: nowrap;\n    min-height: 50px;\n    line-height: 20px;\n    padding: 5px 5px; }\n\n.tooltip-box-field.sm {\n    width: 100px;\n    white-space: nowrap;\n    min-height: 40px;\n    padding: 5px 5px; }\n\n.AdvanceSetting {\n  position: relative; }\n\n.AdvanceSetting span {\n  background-color: white;\n  padding-right: 10px;\n  padding-left: 5px;\n  margin-left: 10px; }\n\n.AdvanceSetting:after,\n.AdvanceSetting:before {\n  content: \"\";\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  height: .5em;\n  border-top: 1px solid #ccc;\n  z-index: -1; }\n\n.AdvanceSettingDiv {\n  border-left: 1px solid #ccc;\n  border-right: 1px solid #ccc;\n  border-bottom: 1px solid #ccc;\n  margin-top: -1%;\n  padding-bottom: 5%;\n  margin-bottom: 1%; }\n"

/***/ }),

/***/ "./src/app/components/live-classes-module/add-class/add-class.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AddClassComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_live_classes_live_class_service__ = __webpack_require__("./src/app/services/live-classes/live-class.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_products_service__ = __webpack_require__("./src/app/services/products.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_http_service__ = __webpack_require__("./src/app/services/http.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8____ = __webpack_require__("./src/app/index.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var AddClassComponent = /** @class */ (function () {
    function AddClassComponent(auth, router, appC, service, product_service, http_service, msgService) {
        this.auth = auth;
        this.router = router;
        this.appC = appC;
        this.service = service;
        this.product_service = product_service;
        this.http_service = http_service;
        this.msgService = msgService;
        this.isProfessional = false;
        this.isBasicActive = true;
        this.isOtherActive = false;
        this.class_id = 0;
        this.hour = ['01 AM', '02 AM', '03 AM', '04 AM', '05 AM', '06 AM', '07 AM', '08 AM', '09 AM', '10 AM', '11 AM', '12 PM', '01 PM', '02 PM', '03 PM', '04 PM', '05 PM', '06 PM', '07 PM', '08 PM', '09 PM', '10 PM', '11 PM', '12 AM'];
        this.minutes = ['00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55'];
        this.isRippleLoad = false;
        this.selectedStudentList = [];
        this.selectedUserList = [];
        this.selectedFacultyList = [];
        this.selectedModeratorList = [];
        this.dropdownList = [];
        this.teachersAssigned = [];
        this.userAssigned = [];
        this.studentList = [];
        this.dropdownSettings = {};
        this.facultySettings = {};
        this.moderatorSettings = {};
        this.studentListSettings = {};
        this.userListSetting = {};
        this.product_id = "";
        this.productData = [];
        this.userData = [];
        this.facultyId = [];
        this.custUserIds = [];
        this.studentsId = [];
        this.eLearnCustUserIDs = [];
        this.batches = [];
        this.masters = [];
        this.courses = [];
        this.courseIds = [];
        this.batchesIds = [];
        this.courseId = [];
        this.dateTimeStatus = false;
        this.topicName = '';
        this.hoursFrom = '';
        this.minuteFrom = '';
        this.hoursTo = '';
        this.minuteTo = '';
        this.isShowProductOption = false;
        this.scheduledateFrom = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).format('YYYY-MM-DD');
        this.getPayloadBatch = {
            inst_id: this.service.institute_id,
            coursesArray: [''],
            role: 'student'
        };
        this.addOnlineClass = {
            custUserIds: [],
            end_datetime: "",
            institution_id: this.service.institute_id,
            sent_notification_flag: 0,
            session_name: "",
            start_datetime: "",
            studentIds: [],
            teacherIds: [],
            eLearnCustUserIDs: [],
            product_id: null,
            private_access: false,
            access_enable_lobby: false,
            access_before_start: 0,
        };
    }
    AddClassComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.facultySettings = {
            singleSelection: false,
            idField: 'teacher_id',
            textField: 'teacher_name',
            itemsShowLimit: 2,
            enableCheckAll: false
        };
        this.moderatorSettings = {
            singleSelection: false,
            idField: 'userid',
            textField: 'name',
            itemsShowLimit: 2,
            enableCheckAll: false
        };
        this.studentListSettings = {
            singleSelection: false,
            idField: 'student_id',
            textField: 'student_name',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 10,
            enableCheckAll: true
        };
        this.userListSetting = {
            singleSelection: false,
            idField: 'user_id',
            textField: 'name',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 10,
            enableCheckAll: true
        };
        this.getTeachers();
        this.getCustomUsers();
        this.checkIsEnableElearnFeature();
    };
    AddClassComponent.prototype.checkIsEnableElearnFeature = function () {
        var _this = this;
        var data = sessionStorage.getItem('enable_eLearn_feature');
        // let data: any;
        // data = atob(enable_eLearn_feature);
        // data = JSON.parse(data);
        // console.log(data);
        if (data == '1') {
            this.isShowProductOption = true;
            this.isRippleLoad = true;
            this.product_service.getMethod('product/get-product-list', null).subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.productData = data.result;
                console.log(_this.productData);
            }, function (error) {
                _this.isRippleLoad = false;
                // this.clearOnlineSchedulesObject() ;
                _this.appC.popToast({ type: "error", body: error.error.message });
            });
        }
        else {
            this.isShowProductOption = false;
        }
    };
    AddClassComponent.prototype.onChangeProduct = function (event) {
        var _this = this;
        var institute_id = sessionStorage.getItem('institute_id');
        var url = "/api/v1/meeting_manager/userDetailByProductID/" + institute_id + "/" + event;
        this.isRippleLoad = true;
        this.http_service.getData(url).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.userData = data;
            console.log(_this.userData);
        }, function (error) {
            _this.isRippleLoad = false;
            _this.appC.popToast({ type: "error", body: error.error.message });
        });
    };
    AddClassComponent.prototype.getEvent = function (event) {
        var proctur_live_expiry_date = sessionStorage.getItem('proctur_live_expiry_date');
        if (__WEBPACK_IMPORTED_MODULE_1_moment__(event).diff(__WEBPACK_IMPORTED_MODULE_1_moment__(), 'days') < 0) {
            var msg = {
                type: "info",
                body: "You cannot select past date"
            };
            this.appC.popToast(msg);
            this.scheduledateFrom = __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD');
        }
        if (new Date(proctur_live_expiry_date) < new Date(event) && new Date(proctur_live_expiry_date) != new Date(event)) {
            var tempMsg = 'Your live class subscription will get expired on '.concat(__WEBPACK_IMPORTED_MODULE_1_moment__(proctur_live_expiry_date).format('DD-MMM-YYYY')).concat(' hence you will not be able create live class. Renew your subscription to conduct live classes again!');
            this.msgService.showErrorMessage('info', '', tempMsg);
            this.scheduledateFrom = __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD');
        }
    };
    AddClassComponent.prototype.getEventHourFrom = function (e) {
        // this.minuteFrom = "00";
        if (this.hoursFrom != "" && this.hoursFrom != null && this.minuteFrom == "") {
            this.minuteFrom = "00";
        }
        else if (this.hoursTo != "" && this.hoursTo != null && this.minuteTo == "") {
            this.minuteTo = "00";
        }
        if (this.hoursFrom != "" && this.hoursFrom != null && this.minuteFrom != "" && this.minuteFrom != null
            && this.hoursTo != "" && this.hoursTo != null && this.minuteTo != "" && this.minuteTo != null) {
            this.getEventHourTo();
        }
    };
    AddClassComponent.prototype.getEventHourTo = function () {
        var fromTime = __WEBPACK_IMPORTED_MODULE_1_moment__(this.scheduledateFrom).format('YYYY-MM-DD') + " " + this.hoursFrom.split(' ')[0] + ":" + this.minuteFrom + " " + this.hoursFrom.split(' ')[1];
        var toTime = __WEBPACK_IMPORTED_MODULE_1_moment__(this.scheduledateFrom).format('YYYY-MM-DD') + " " + this.hoursTo.split(' ')[0] + ":" + this.minuteTo + " " + this.hoursTo.split(' ')[1];
        var fromTimeT = __WEBPACK_IMPORTED_MODULE_1_moment__(fromTime).format('YYYY-MM-DD hh:mm a');
        var toTimeT = __WEBPACK_IMPORTED_MODULE_1_moment__(toTime).format('YYYY-MM-DD hh:mm a');
        if (__WEBPACK_IMPORTED_MODULE_1_moment__(fromTimeT).diff(__WEBPACK_IMPORTED_MODULE_1_moment__(toTimeT), 'minutes') > 0) {
            this.appC.popToast({ type: "error", body: "From time cannot be greater than to time" });
            return false;
        }
        else if (this.hoursFrom == "" || this.hoursTo == "" || this.minuteFrom == "" || this.minuteTo == "") {
            this.appC.popToast({ type: "error", body: "All fields are required" });
            return false;
        }
        else if (__WEBPACK_IMPORTED_MODULE_1_moment__(fromTimeT).diff(__WEBPACK_IMPORTED_MODULE_1_moment__(), 'minutes') <= 0) {
            this.appC.popToast({ type: "error", body: "Class cannot be schedule before current time" });
            return false;
        }
        else if (fromTimeT == toTimeT) {
            this.appC.popToast({ type: "error", body: "From time and to time cannot be same" });
            return false;
        }
        else {
            this.dateTimeStatus = true;
        }
    };
    AddClassComponent.prototype.checkMandatoryFields = function () {
        // this.navigateTo("assignStudent")
        if (this.topicName != "" && this.topicName != null && this.selectedFacultyList.length != 0) {
            if (this.dateTimeStatus) {
                this.navigateTo("assignStudent");
            }
            else {
                this.getEventHourTo();
            }
        }
        else {
            this.appC.popToast({ type: "error", body: "All fields are required" });
        }
    };
    AddClassComponent.prototype.scheduleClass = function () {
        var _this = this;
        var validationFlag = false;
        if (!this.isProfessional) {
            if (this.courseIds != null && this.courseValue != null && this.courseValue != '') {
                validationFlag = true;
            }
            else {
                validationFlag = false;
                this.appC.popToast({ type: "error", body: "All fields are required" });
            }
        }
        else {
            if (this.batchesIds != null) {
                validationFlag = true;
            }
            else {
                validationFlag = false;
                this.appC.popToast({ type: "error", body: "All fields are required" });
            }
        }
        if (validationFlag) {
            this.facultyId = [];
            this.custUserIds = [];
            this.studentsId = [];
            this.selectedFacultyList.map(function (ele) {
                var x = ele.teacher_id.toString();
                _this.facultyId.push(x);
            });
            this.selectedModeratorList.map(function (ele) {
                var x = ele.userid.toString();
                _this.custUserIds.push(x);
            });
            this.selectedStudentList.map(function (ele) {
                var x = ele.student_id.toString();
                _this.studentsId.push(x);
            });
            if (this.selectedUserList.length != 0) {
                this.eLearnCustUserIDs = [];
                this.selectedUserList.map(function (ele) {
                    var x = ele.user_id.toString();
                    _this.eLearnCustUserIDs.push(x);
                });
                this.addOnlineClass.eLearnCustUserIDs = this.eLearnCustUserIDs;
            }
            else {
                this.addOnlineClass.eLearnCustUserIDs = [];
            }
            this.addOnlineClass.session_name = this.topicName;
            this.addOnlineClass.custUserIds = this.custUserIds;
            this.addOnlineClass.studentIds = this.studentsId;
            this.addOnlineClass.teacherIds = this.facultyId;
            if (this.product_id != null) {
                this.addOnlineClass.product_id = this.product_id;
            }
            else {
                this.addOnlineClass.product_id = null;
            }
            this.addOnlineClass.start_datetime = __WEBPACK_IMPORTED_MODULE_1_moment__(this.scheduledateFrom).format('YYYY-MM-DD') + " " + this.hoursFrom.split(' ')[0] + "" + ":" + this.minuteFrom + " " + this.hoursFrom.split(' ')[1];
            this.addOnlineClass.end_datetime = __WEBPACK_IMPORTED_MODULE_1_moment__(this.scheduledateFrom).format('YYYY-MM-DD') + " " + this.hoursTo.split(' ')[0] + "" + ":" + this.minuteTo + " " + this.hoursTo.split(' ')[1];
            if (this.addOnlineClass.sent_notification_flag) {
                this.addOnlineClass.sent_notification_flag = 1;
            }
            else if (!this.addOnlineClass.sent_notification_flag) {
                this.addOnlineClass.sent_notification_flag = 0;
            }
            if (this.addOnlineClass.access_before_start) {
                this.addOnlineClass.access_before_start = 1;
            }
            if (!this.addOnlineClass.access_before_start) {
                this.addOnlineClass.access_before_start = 0;
            }
            console.log(this.addOnlineClass);
            this.isRippleLoad = true;
            console.log(this.addOnlineClass);
            this.service.getOnlineClasses(this.addOnlineClass).subscribe(function (data) {
                _this.appC.popToast({ type: "success", body: "Live class session " + _this.topicName + " " + "created successfully" });
                _this.navigateTo("studentForm");
                _this.isRippleLoad = false;
                _this.clearOnlineSchedulesObject();
            }, function (error) {
                _this.isRippleLoad = false;
                // this.clearOnlineSchedulesObject() ;
                _this.facultyId = [];
                _this.custUserIds = [];
                _this.studentsId = [];
                _this.appC.popToast({ type: "error", body: error.error.message });
            });
        }
    };
    AddClassComponent.prototype.clearOnlineSchedulesObject = function () {
        this.addOnlineClass = {
            custUserIds: [],
            end_datetime: "",
            institution_id: this.service.institute_id,
            sent_notification_flag: 0,
            session_name: "",
            start_datetime: "",
            studentIds: [],
            teacherIds: [],
            product_id: [],
            eLearnCustUserIDs: [],
            private_access: false,
            access_enable_lobby: false,
            access_before_start: 0
        };
        this.topicName = "";
        this.studentsId = [];
        this.facultyId = [];
        this.scheduledateFrom = __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD');
        this.hoursFrom = "";
        this.minuteFrom = "";
        this.hoursTo = "";
        this.minuteTo = "";
        this.courseIds = [];
        this.batchesIds = [];
        this.courseValue = [];
        this.selectedStudentList = [];
        this.selectedFacultyList = [];
        this.selectedModeratorList = [];
        this.navigateTo('classDetails');
    };
    /** this function is used to fetch teacher details */
    AddClassComponent.prototype.getTeachers = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.service.fetchTeachers().subscribe(function (data) {
            _this.teachersAssigned = data;
            console.log(_this.teachersAssigned);
            // this.getCheckedBox(this.teachersAssigned);
            _this.isRippleLoad = false;
        }, function (error) {
            _this.teachersAssigned = [];
            _this.errorMessage(error);
            _this.isRippleLoad = false;
        });
    };
    /** this function is used to fetch customer details */
    AddClassComponent.prototype.getCustomUsers = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.service.fetchUsers().subscribe(function (data) {
            _this.userAssigned = data;
            console.log(_this.userAssigned);
            // this.getCheckedBox(this.userAssigned);
            _this.isRippleLoad = false;
        }, function (error) {
            _this.errorMessage(error);
            _this.userAssigned = [];
            _this.isRippleLoad = false;
        });
    };
    AddClassComponent.prototype.getBatchesCoursesIds = function (ids) {
        if (this.isProfessional) {
            this.batchesIds = ids;
            this.fetchStudentsApi(this.batchesIds);
            // this.getStudents();
        }
        else {
            this.courseIds = ids;
            this.fetchStudentsApi(this.courseIds);
            // this.getStudents();
        }
    };
    AddClassComponent.prototype.getBatchesCourses = function () {
        var _this = this;
        this.isRippleLoad = true;
        if (this.isProfessional) {
            this.service.fetchBatches().subscribe(function (data) {
                _this.batches = data;
                console.log(_this.batches);
                _this.isRippleLoad = false;
            }, function (error) {
                _this.isRippleLoad = false;
                _this.errorMessage(error);
            });
        }
        else {
            this.service.fetchMasters().subscribe(function (data) {
                _this.masters = data;
                // console.log(this.masters)
                _this.isRippleLoad = false;
            }, function (error) {
                console.log(error);
                _this.errorMessage(error);
                _this.isRippleLoad = false;
            });
        }
    };
    AddClassComponent.prototype.getCourses = function (master_course_name) {
        var _this = this;
        if (master_course_name == null || master_course_name == '') {
            this.courses = [];
        }
        else {
            this.isRippleLoad = true;
            this.service.fetchCourses(master_course_name).subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.courses = data.coursesList;
            }, function (error) {
                _this.errorMessage(error);
                _this.isRippleLoad = false;
            });
        }
    };
    AddClassComponent.prototype.getStudents = function () {
        this.studentList = [];
        var str = [];
        if (this.isProfessional) {
            // this.batchesIds.map(
            //   (ele: any) => {
            //     let x = ele.toString();
            //     str.push(x);
            //   }
            // )
            this.fetchStudentsApi(this.batchesIds);
        }
        else {
            // this.courseIds.map(
            //   (ele: any) => {
            //     let x = ele.toString();
            //     str.push(x);
            //   }
            // )
            this.fetchStudentsApi(this.courseIds);
        }
    };
    AddClassComponent.prototype.fetchStudentsApi = function (courseArray) {
        var _this = this;
        this.isRippleLoad = true;
        this.getPayloadBatch.coursesArray = [courseArray];
        this.service.fetchStudents(this.getPayloadBatch).subscribe(function (data) {
            _this.studentList = data.studentsAssigned;
            console.log(data.studentsAssigned);
            // this.getCheckedBox(this.studentsAssigned);
            _this.isRippleLoad = false;
        }, function (error) {
            _this.isRippleLoad = false;
            _this.errorMessage(error);
        });
    };
    AddClassComponent.prototype.errorMessage = function (error) {
        this.appC.popToast({ type: "error", body: error.error.message });
    };
    /* Function to navigate on icon click */
    AddClassComponent.prototype.switchToView = function (id) {
        switch (id) {
            case "class-icon": {
                this.navigateTo("classDetails");
                break;
            }
            case "assignStudent-icon": {
                this.navigateTo("assignStudent");
                break;
            }
            default: {
                this.navigateTo("classDetails");
                break;
            }
        }
    };
    /* Function to navigate through the Student Add Form on button Click Save/Submit*/
    AddClassComponent.prototype.navigateTo = function (text) {
        if (text === "classDetails") {
            if (this.class_id == 0 || this.class_id == null) {
                document.getElementById('li-one').classList.add('active');
                document.getElementById('li-two').classList.remove('active');
                this.isBasicActive = true;
                this.isOtherActive = false;
            }
            else {
                var msg = { type: 'info', title: 'Live Class Details Already Saved', body: '' };
                this.appC.popToast(msg);
            }
        }
        else if (text === "assignStudent") {
            if (this.class_id == 0 || this.class_id == null) {
                document.getElementById('li-one').classList.remove('active');
                document.getElementById('li-two').classList.add('active');
                this.isBasicActive = false;
                this.isOtherActive = true;
                this.getBatchesCourses();
            }
            else {
                var msg = { type: 'info', title: 'Live Class Details Already Saved', body: '' };
                this.appC.popToast(msg);
            }
        }
    };
    AddClassComponent.prototype.cancel = function () {
        this.router.navigateByUrl('/view/live-classes');
    };
    AddClassComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    AddClassComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-add-class',
            template: __webpack_require__("./src/app/components/live-classes-module/add-class/add-class.component.html"),
            styles: [__webpack_require__("./src/app/components/live-classes-module/add-class/add-class.component.scss")],
            encapsulation: __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewEncapsulation"].None
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_2__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_4__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_5__services_live_classes_live_class_service__["a" /* LiveClasses */],
            __WEBPACK_IMPORTED_MODULE_6__services_products_service__["a" /* ProductService */],
            __WEBPACK_IMPORTED_MODULE_7__services_http_service__["a" /* HttpService */],
            __WEBPACK_IMPORTED_MODULE_8____["h" /* MessageShowService */]])
    ], AddClassComponent);
    return AddClassComponent;
}());



/***/ }),

/***/ "./src/app/components/live-classes-module/edit-class/edit-class.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper black-bg\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n\r\n<div class=\"middle-section\">\r\n  <aside class=\"middle-full\">\r\n    <section class=\"middle-main clearFix activity-wrapper\">\r\n      <section class=\"row header\" style=\"margin-right: 0px; margin-left: 0px;margin-bottom: 5px;\">\r\n        <div class=\"row\" style=\"margin-left: 0px;margin-right: 0px;\">\r\n          <h2 class=\"pull-left\">\r\n           <a routerLink=\"/view/live-classes\">\r\n            Live class\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n            <span *ngIf=\"repeat_session == 1\">Add Live Class</span>\r\n            <span *ngIf=\"repeat_session == 0\">Edit Live Class</span>\r\n          </h2>\r\n        </div>\r\n      </section>\r\n\r\n      <!-- <h2 class=\"\" style=\"margin:10px 0px;\">\r\n        Add Live Class\r\n      </h2> -->\r\n\r\n      <div class=\"border-container\">\r\n      </div>\r\n\r\n      <section class=\"student-tab\">\r\n        <ul class=\"nav-tab\">\r\n          <li id=\"li-one\" class=\"active\">\r\n            <div class=\"navigator\" id=\"class-icon\" (click)=\"switchToView($event.target.id)\">\r\n              <span id=\"class-icon\">1</span>\r\n              <p id=\"class-icon\">Class Details</p>\r\n            </div>\r\n          </li>\r\n          <li class=\"\" id=\"li-two\">\r\n            <div class=\"navigator\" id=\"assignStudent-icon\" (click)=\"switchToView($event.target.id)\">\r\n              <span id=\"assignStudent-icon\">2</span>\r\n              <p id=\"assignStudent-icon\">Assign Students</p>\r\n            </div>\r\n          </li>\r\n        </ul>\r\n      </section>\r\n\r\n      <section id=\"classDetails\" *ngIf=\"isBasicActive\">\r\n        <div class=\"class_details_container\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"topicName\">Topic Name<span class=\"text-danger\">*</span> </label>\r\n            <input type=\"text\" value=\"\" id=\"topicName\" class=\"form-ctrl\" name=\"topicName\" required [(ngModel)]=\"topicName\" placeholder=\"Enter Topic Name\"/>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper-container\">\r\n\r\n            <div class=\"field-wrapper datePickerBox\" style=\"width: 25%;\">\r\n              <label for=\"date\">Date<span class=\"text-danger\">*</span></label>\r\n              <input type=\"text\" class=\"form-ctrl\" bsDatepicker readonly=\"true\" [(ngModel)]=\"scheduledateFrom\" (ngModelChange)=\"getEvent($event)\" id=\"date\" style=\"height: 36px;\">\r\n              <!-- <i class=\"fa fa-calendar\" style=\"cursor: pointer;color: #1283f4;\" (click)=\"openCalendar('date')\"></i> -->\r\n            </div>\r\n\r\n            <div class=\"field-wrapper\" style=\"width: 25%;\">\r\n              <label for=\"date\">From<span class=\"text-danger\">*</span></label>\r\n              <div class=\"from\">\r\n                <select class=\"made-out\" id=\"from1\" [(ngModel)]=\"hoursFrom\" (ngModelChange)=\"getEventHourFrom($event)\">\r\n                    <option value=\"\" disabled  selected=\"selected\" hidden>HH</option>\r\n                    <option *ngFor=\"let i of hour\" [value]=\"i\">\r\n                        {{i}}\r\n                    </option>\r\n                </select>\r\n                <select class=\"made-out\" id=\"from2\" style=\"margin-left:15px;\" [(ngModel)]=\"minuteFrom\" (ngModelChange)=\"getEventHourFrom($event)\">\r\n                    <option value=\"\" disabled  selected=\"selected\" hidden>MM</option>\r\n                    <option [value]=\"i\" *ngFor=\"let i of minutes\" >\r\n                        {{i}}\r\n                    </option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"field-wrapper\" style=\"width: 25%;\">\r\n              <label for=\"date\">To<span class=\"text-danger\">*</span></label>\r\n              <div class=\"from\">\r\n                <select class=\"made-out\" id=\"to1\" [(ngModel)]=\"hoursTo\" (ngModelChange)=\"getEventHourFrom()\">\r\n                    <option value=\"\" disabled  selected=\"selected\" hidden>HH</option>\r\n                    <option *ngFor=\"let i of hour\" [value]=\"i\">\r\n                        {{i}}\r\n                    </option>\r\n                </select>\r\n                <select class=\"made-out\" id=\"to2\" style=\"margin-left:15px;\" [(ngModel)]=\"minuteTo\" (ngModelChange)=\"getEventHourFrom($event)\">\r\n                    <option value=\"\" disabled  selected=\"selected\" hidden>MM</option>\r\n                    <option *ngFor=\"let i of minutes\" [value]=\"i\">\r\n                        {{i}}\r\n                    </option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n\r\n          </div>\r\n\r\n          <div class=\"field-wrapper faculty_container\">\r\n            <label for=\"faculty\">Faculty Name(s)<span class=\"text-danger\">*</span> </label>\r\n            <!-- <input type=\"text\" value=\"\" id=\"faculty\" class=\"form-ctrl\" name=\"faculty\" required /> -->\r\n            <ng-multiselect-dropdown\r\n              [placeholder]=\"'Select Faculty'\"\r\n              [data]=\"teachersAssigned\"\r\n              [settings]=\"facultySettings\"\r\n              [(ngModel)]=\"selectedFacultyList\">\r\n            </ng-multiselect-dropdown>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper moderator_container\">\r\n            <label for=\"moderator\">Moderator Name(s) </label>\r\n            <ng-multiselect-dropdown\r\n              [placeholder]=\"'Select Moderator'\"\r\n              [data]=\"userAssigned\"\r\n              [settings]=\"moderatorSettings\"\r\n              [(ngModel)]=\"selectedModeratorList\" >\r\n            </ng-multiselect-dropdown>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper moderator_container\" *ngIf=\"isShowProductOption\">\r\n            <label for=\"date\">Product(s)</label><br>\r\n              <select class=\"made-out\" id=\"product\" [(ngModel)]=\"product_id\" style=\"padding: 6px 12px;border: 1px solid #adadad;border-radius: 4px;\" (click)=\"onChangeProduct($event.target.value)\"disabled=\"true\">\r\n                  <option value=\"\">Select Product(s)</option>\r\n                  <option *ngFor=\"let product of productData\" [value]=\"product.id\" >\r\n                      {{product.title}}\r\n                  </option>\r\n              </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper student_list_container\" *ngIf=\"isShowProductOption\"  style=\"width: 73%\">\r\n            <label for=\"students\">User Name(s) </label>\r\n            <ng-multiselect-dropdown class=\"container disabled\"\r\n              [disabled]=\"true\"\r\n              [placeholder]=\"'Select Users'\"\r\n              [data]=\"userList\"\r\n              [settings]=\"userListSetting\"\r\n              [(ngModel)]=\"selectedUserList\" >\r\n            </ng-multiselect-dropdown>\r\n          </div>\r\n\r\n          <div class=\"action-button-container\">\r\n            <div class=\"action-btn-item-1\">\r\n              <!-- <button type=\"button\" name=\"button\" class=\"back-btn\" (click)=\"cancel()\">Back</button> -->\r\n            </div>\r\n            <div class=\"action-btn-item-2\">\r\n              <button type=\"button\" name=\"button\" class=\"cancel-btn\" (click)=\"cancel()\">Cancel</button>&nbsp;&nbsp;&nbsp;&nbsp;\r\n              <button type=\"button\" name=\"button\" class=\"next-btn\" (click)=\"checkMandatoryFields()\">Next</button>\r\n            </div>\r\n          </div>\r\n\r\n        </div>\r\n      </section>\r\n\r\n      <section id=\"assignStudent\" *ngIf=\"isOtherActive\">\r\n        <div class=\"add_student_container\">\r\n          <div class=\"field-wrapper\"  *ngIf=\"!isProfessional\">\r\n            <label for=\"master_course\">Master Course<span class=\"text-danger\">*</span> </label>\r\n            <select class=\"form-ctrl disabled\" name=\"master_course\" id=\"master_course\" disabled>\r\n              <option value=\"Select Master Course\" selected=\"selected\" >Select Master Course</option>\r\n              <!-- <option *ngFor=\"let i of masters\" [value]=\"i.master_course\">\r\n                  {{i.master_course}}\r\n              </option> -->\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper\"  *ngIf=\"isProfessional\">\r\n            <label for=\"batch\">Batches<span class=\"text-danger\">*</span> </label>\r\n            <select class=\"form-ctrl disabled\" name=\"batch\" id=\"batch\" disabled>\r\n              <option value=\"Select Batch\" selected=\"selected\">Select Batch</option>\r\n              <!-- <option *ngFor=\"let i of batches\" [value]=\"i.batch_id\">\r\n                  {{i.batch_name}}\r\n              </option> -->\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper\" *ngIf=\"!isProfessional\">\r\n            <label for=\"course\">Course<span class=\"text-danger\">*</span> </label>\r\n            <select class=\"form-ctrl disabled\" name=\"course\" id=\"course\"  disabled>\r\n              <option value=\"Select Course\" selected=\"selected\">Select Course</option>\r\n              <!-- <option *ngFor=\"let i of courses\" [value]=\"i.course_id\">\r\n                  {{i.course_name}}\r\n              </option> -->\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"field-wrapper student_list_container\" style=\"width: 85%;border-radius: 4px;margin-top: 5px;border-color: #c5c5cc;font-size: 14px;\">\r\n            <label for=\"students\" style=\"margin-bottom: 5px;\">Student Name(s)<span class=\"text-danger\">*</span> </label>\r\n            <ng-multiselect-dropdown class=\"container disabled\" style=\"color: #000;\r\n            font-weight: bold;\r\n            cursor: not-allowed;\"\r\n              [disabled]=\"true\"\r\n              [placeholder]=\"'Select Students'\"\r\n              [data]=\"studentList\"\r\n              [settings]=\"studentListSettings\"\r\n              [(ngModel)]=\"selectedStudentList\" >\r\n            </ng-multiselect-dropdown>\r\n          </div>\r\n\r\n          <div style=\"margin-top:10px\"> \r\n              <div class=\"AdvanceSetting\">\r\n                  <span style=\"font-weight: 600;\">Advance settings</span>\r\n              </div>\r\n                  <div class=\"AdvanceSettingDiv\">\r\n                          <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;margin:5px;margin-top: 20px;margin-left: 10px;\">\r\n                              <input type=\"checkbox\" name=\"expenses\" [(ngModel)]=\"editData.sent_notification_flag\" [value]=\"0\" class=\"form-checkbox\" id=\"qun\">\r\n                              <label for=\"qun\">Send Notification</label>\r\n                              <div class=\"questionInfo inline-relative\">\r\n                                <span class=\"qInfoIcon i-class\">i</span>\r\n                                <div class=\"tooltip-box-field\">\r\n                                    All the members in \r\n                                    <br>meeting will recieve\r\n                                    <br>sms notification for \r\n                                    <br>the session.\r\n                                </div>\r\n                              </div>\r\n                          </div>\r\n            \r\n                        <!-- Private Access -->\r\n                        <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;margin:5px;margin-top: 20px;\">\r\n                          <input type=\"checkbox\" name=\"private_access\" [(ngModel)]=\"editData.private_access\" [value]=\"0\" class=\"form-checkbox\" id=\"private_access\">\r\n                          <label for=\"private_access\">Private Access</label>\r\n                          <div class=\"questionInfo inline-relative\">\r\n                            <span class=\"qInfoIcon i-class\">i</span>\r\n                            <div class=\"tooltip-box-field\">\r\n                                Only the users invited\r\n                                <br> using e-mail ID would\r\n                                <br> be able to join. Direct\r\n                                <br> link sharing of session \r\n                                <br>won't work.\r\n                            </div>\r\n                          </div>\r\n                        </div>\r\n            \r\n                        <!-- Enable lobby -->\r\n                        <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;margin:5px;margin-top: 20px;margin-left: 10px;\">\r\n                          <input type=\"checkbox\" name=\"access_enable_lobby\" [(ngModel)]=\"editData.access_enable_lobby\" [value]=\"0\" class=\"form-checkbox\" id=\"access_enable_lobby\">\r\n                          <label for=\"access_enable_lobby\">Access Enable Lobby</label>\r\n                          <div class=\"questionInfo inline-relative\">\r\n                            <span class=\"qInfoIcon i-class\">i</span>\r\n                            <div class=\"tooltip-box-field\">\r\n                                All the students will \r\n                                <br>wait in waiting room\r\n                                <br> after joining the \r\n                                <br> session. Teachers will\r\n                                <br> have access to allow\r\n                                <br> students in the \r\n                                <br>meeting.\r\n                            </div>\r\n                          </div>\r\n                        </div>\r\n            \r\n                        <!-- Access before start -->\r\n                        <!-- <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;margin:5px;margin-top: 20px;\">\r\n                            <input type=\"checkbox\" name=\"access_before_start\" [(ngModel)]=\"editData.access_before_start\" [value]=\"0\" class=\"form-checkbox\" id=\"access_before_start\">\r\n                            <label for=\"access_before_start\">Access before start</label>\r\n                            <div class=\"questionInfo inline-relative\">\r\n                              <span class=\"qInfoIcon i-class\">i</span>\r\n                              <div class=\"tooltip-box-field\">\r\n                                  The meeting can only \r\n                                  <br> be started one minute\r\n                                  <br> before the start time \r\n                                  <br>of the session.\r\n                              </div>\r\n                            </div>\r\n                          </div> -->\r\n                  </div>\r\n              </div>\r\n\r\n          <div class=\"action-button-container\">\r\n            <div class=\"action-btn-item-1\">\r\n              <button type=\"button\" name=\"button\" class=\"back-btn\" (click)=\"navigateTo('classDetails')\">Back</button>\r\n            </div>\r\n            <div class=\"action-btn-item-2\">\r\n              <button type=\"button\" name=\"button\" class=\"cancel-btn\" (click)=\"cancel()\">Cancel</button>&nbsp;&nbsp;&nbsp;&nbsp;\r\n              <button type=\"button\" name=\"button\" class=\"next-btn\" (click)=\"scheduleClass()\">Submit</button>\r\n            </div>\r\n          </div>\r\n\r\n        </div>\r\n      </section>\r\n\r\n    </section>\r\n  </aside>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/live-classes-module/edit-class/edit-class.component.scss":
/***/ (function(module, exports) {

module.exports = "html {\n  overflow-y: scroll; }\n\n.disabled {\n  color: #000;\n  font-weight: bold;\n  cursor: not-allowed; }\n\n.middle-section {\n  padding: 1%; }\n\n.border-container {\n  border-top: 1px solid #e3e3e3; }\n\n.student-tab .nav-tab {\n  margin-left: 35%; }\n\n.made-out {\n  border: 1px solid #efefef;\n  text-align: center; }\n\n.class_details_container {\n  width: 60%;\n  margin-left: 20%;\n  margin-right: 20%;\n  -webkit-box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.16);\n          box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.16);\n  padding: 30px;\n  margin-bottom: 20px; }\n\n.class_details_container .field-wrapper {\n    margin-top: 10px; }\n\n.class_details_container .field-wrapper #topicName {\n      width: 45%;\n      border-radius: 4px;\n      margin-top: 5px;\n      border-color: #c5c5cc; }\n\n.class_details_container .field-wrapper #faculty, .class_details_container .field-wrapper #moderator {\n      width: 40%;\n      border-radius: 4px;\n      margin-top: 5px;\n      border-color: #c5c5cc; }\n\n.class_details_container .field-wrapper {\n    position: relative; }\n\n.class_details_container .field-wrapper.datePickerBox .form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent; }\n\n.class_details_container .field-wrapper.datePickerBox:after {\n      content: '';\n      background: url(/./assets/images/calendar.svg) no-repeat;\n      position: absolute;\n      right: 57px;\n      top: 35px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n\n.class_details_container .faculty_container, .class_details_container .moderator_container {\n    width: 45%;\n    border-radius: 4px;\n    margin-top: 5px;\n    border-color: #c5c5cc;\n    font-size: 14px; }\n\n.class_details_container .faculty_container label, .class_details_container .moderator_container label {\n      margin-bottom: 5px; }\n\n.class_details_container .field-wrapper-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    width: 100%; }\n\n.class_details_container .field-wrapper-container .from {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start; }\n\n.class_details_container .field-wrapper-container .from #from1, .class_details_container .field-wrapper-container .from #to1 {\n        width: 40%;\n        border-radius: 4px;\n        margin-top: 5px;\n        border-color: #c5c5cc;\n        height: 36px; }\n\n.class_details_container .field-wrapper-container .from #from2, .class_details_container .field-wrapper-container .from #to2 {\n        width: 30%;\n        border-radius: 4px;\n        margin-top: 5px;\n        border-color: #c5c5cc;\n        height: 36px; }\n\n.class_details_container .field-wrapper-container #date {\n      width: 70%;\n      border-radius: 4px;\n      margin-top: 5px;\n      border-color: #c5c5cc; }\n\n.multiselect-dropdown {\n  font-size: 12px; }\n\n.multiselect-dropdown .dropdown-down {\n    border-top: 5px solid black;\n    border-left: 5px solid transparent;\n    border-right: 5px solid transparent; }\n\n.multiselect-dropdown .dropdown-up {\n    border-bottom: 5px solid black;\n    border-left: 5px solid transparent;\n    border-right: 5px solid transparent; }\n\n.action-button-container {\n  margin-top: 20px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  width: 100%; }\n\n.action-button-container .action-btn-item-1 {\n    width: 20%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: start;\n        -ms-flex-pack: start;\n            justify-content: flex-start; }\n\n.action-button-container .action-btn-item-1 .back-btn {\n      border: 1px solid #1283f4;\n      text-align: center;\n      color: #1283f4;\n      width: 80px;\n      height: 35px;\n      border-radius: 4px;\n      background: white; }\n\n.action-button-container .action-btn-item-2 {\n    width: 30%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between; }\n\n.action-button-container .action-btn-item-2 .cancel-btn {\n      border: 1px solid #f41212;\n      text-align: center;\n      color: #f41212;\n      width: 100px;\n      height: 35px;\n      border-radius: 4px;\n      background: white; }\n\n.action-button-container .action-btn-item-2 .next-btn {\n      border: 1px solid #1283f4;\n      text-align: center;\n      background: #1283f4;\n      color: white;\n      width: 100px;\n      height: 35px;\n      border-radius: 4px; }\n\n.add_student_container {\n  width: 60%;\n  margin-left: 20%;\n  margin-right: 20%;\n  -webkit-box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.16);\n          box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.16);\n  padding: 30px;\n  margin-bottom: 20px; }\n\n.add_student_container .field-wrapper {\n    margin-top: 10px; }\n\n.add_student_container .field-wrapper #master_course, .add_student_container .field-wrapper #course, .add_student_container .field-wrapper #batch {\n      width: 45%;\n      border-radius: 4px;\n      margin-top: 5px;\n      border-color: #c5c5cc; }\n\n.add_student_container .student_list_container {\n    width: 85%;\n    border-radius: 4px;\n    margin-top: 5px;\n    border-color: #c5c5cc;\n    font-size: 14px; }\n\n.add_student_container .student_list_container label {\n      margin-bottom: 5px; }\n\n@media screen and (max-width: 2000px) and (min-width: 1400px) {\n  .field-wrapper.datePickerBox:after {\n    content: '';\n    right: 65px !important; } }\n\n.black-bg {\n  background: rgba(12, 11, 11, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 6;\n  width: 100%; }\n\n.field-checkbox-wrapper, .field-radio-wrapper {\n  position: relative;\n  padding-left: 25px;\n  width: 40%; }\n\n.qInfoIcon {\n  width: 17px;\n  margin-left: 4px;\n  height: 20px;\n  border: 1px solid #ccc;\n  border-radius: 50%;\n  display: block;\n  text-align: center;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  line-height: 20px;\n  font-weight: 600;\n  font-size: 12px;\n  cursor: pointer;\n  -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n          box-shadow: 0px 0px 1px 0px #ccc inset;\n  color: #888;\n  -webkit-transition: all 0.2s linear;\n  transition: all 0.2s linear; }\n\n.tooltip-box-field {\n  white-space: nowrap;\n  min-height: 41px;\n  line-height: 12px;\n  padding: 5px 5px;\n  overflow: visible;\n  color: black;\n  font-weight: bold;\n  top: 30px; }\n\n.tooltip-box-field.lg {\n    width: 200px;\n    white-space: nowrap;\n    min-height: 50px;\n    line-height: 20px;\n    padding: 5px 5px; }\n\n.tooltip-box-field.sm {\n    width: 100px;\n    white-space: nowrap;\n    min-height: 40px;\n    padding: 5px 5px; }\n\n.AdvanceSetting {\n  position: relative; }\n\n.AdvanceSetting span {\n  background-color: white;\n  padding-right: 10px;\n  padding-left: 5px;\n  margin-left: 10px; }\n\n.AdvanceSetting:after,\n.AdvanceSetting:before {\n  content: \"\";\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  height: .5em;\n  border-top: 1px solid #ccc;\n  z-index: -1; }\n\n.AdvanceSettingDiv {\n  border-left: 1px solid #ccc;\n  border-right: 1px solid #ccc;\n  border-bottom: 1px solid #ccc;\n  margin-top: -1%;\n  padding-bottom: 5%;\n  margin-bottom: 1%; }\n"

/***/ }),

/***/ "./src/app/components/live-classes-module/edit-class/edit-class.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EditClassComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_live_classes_live_class_service__ = __webpack_require__("./src/app/services/live-classes/live-class.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_products_service__ = __webpack_require__("./src/app/services/products.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_http_service__ = __webpack_require__("./src/app/services/http.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8____ = __webpack_require__("./src/app/index.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var EditClassComponent = /** @class */ (function () {
    function EditClassComponent(auth, router, appC, service, route, product_service, http_service, msgService) {
        this.auth = auth;
        this.router = router;
        this.appC = appC;
        this.service = service;
        this.route = route;
        this.product_service = product_service;
        this.http_service = http_service;
        this.msgService = msgService;
        this.isProfessional = false;
        this.isBasicActive = true;
        this.isOtherActive = false;
        this.class_id = 0;
        this.hour = ['01 AM', '02 AM', '03 AM', '04 AM', '05 AM', '06 AM', '07 AM', '08 AM', '09 AM', '10 AM', '11 AM', '12 PM', '01 PM', '02 PM', '03 PM', '04 PM', '05 PM', '06 PM', '07 PM', '08 PM', '09 PM', '10 PM', '11 PM', '12 AM'];
        this.minutes = ['00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55'];
        this.isRippleLoad = false;
        this.selectedStudentList = [];
        this.selectedUserList = [];
        this.selectedFacultyList = [];
        this.selectedModeratorList = [];
        this.dropdownList = [];
        this.teachersAssigned = [];
        this.userAssigned = [];
        this.studentList = [];
        this.userList = [];
        this.dropdownSettings = {};
        this.facultySettings = {};
        this.moderatorSettings = {};
        this.studentListSettings = {};
        this.userListSetting = {};
        this.facultyId = [];
        this.custUserIds = [];
        this.studentsId = [];
        this.eLearnCustUserIDs = [];
        this.productData = [];
        this.product_id = "";
        this.isShowProductOption = false;
        this.batches = [];
        this.masters = [];
        this.courses = [];
        this.courseIds = [];
        this.batchesIds = [];
        this.courseId = [];
        this.dateTimeStatus = false;
        this.topicName = '';
        this.hoursFrom = '';
        this.minuteFrom = '';
        this.hoursTo = '';
        this.minuteTo = '';
        this.scheduledateFrom = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).format('YYYY-MM-DD');
        this.getPayloadBatch = {
            inst_id: this.service.institute_id,
            coursesArray: [''],
            role: 'student'
        };
        this.updateOnlineClass = {
            custUserIds: [],
            end_datetime: "",
            institution_id: this.service.institute_id,
            sent_notification_flag: 0,
            session_name: "",
            start_datetime: "",
            studentIds: null,
            teacherIds: [],
            product_id: [],
            eLearnCustUserIDs: [],
            private_access: false,
            access_enable_lobby: false,
            access_before_start: 0,
        };
    }
    EditClassComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.facultySettings = {
            singleSelection: false,
            idField: 'teacher_id',
            textField: 'teacher_name',
            itemsShowLimit: 2,
            enableCheckAll: false
        };
        this.moderatorSettings = {
            singleSelection: false,
            idField: 'userid',
            textField: 'name',
            itemsShowLimit: 2,
            enableCheckAll: false
        };
        this.studentListSettings = {
            singleSelection: false,
            idField: 'student_id',
            textField: 'student_name',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 10,
            enableCheckAll: true
        };
        this.userListSetting = {
            singleSelection: false,
            idField: 'user_id',
            textField: 'user_name',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 10,
            enableCheckAll: true
        };
        this.editSessionId = this.route.snapshot.paramMap.get('id');
        this.repeat_session = this.route.snapshot.queryParams["repeat"];
        this.getLiveClassData();
        this.checkIsEnableElearnFeature();
    };
    EditClassComponent.prototype.checkIsEnableElearnFeature = function () {
        var _this = this;
        var enable_eLearn_feature = sessionStorage.getItem('enable_eLearn_feature');
        if (enable_eLearn_feature == '1') {
            this.isShowProductOption = true;
            this.isRippleLoad = true;
            this.product_service.getMethod('product/get-product-list', null).subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.productData = data.result;
                console.log(_this.productData);
            }, function (error) {
                _this.isRippleLoad = false;
                // this.clearOnlineSchedulesObject() ;
                _this.appC.popToast({ type: "error", body: error.error.message });
            });
        }
        else {
            this.isShowProductOption = false;
        }
    };
    EditClassComponent.prototype.onChangeProduct = function (event) {
        var _this = this;
        var institute_id = sessionStorage.getItem('institute_id');
        var url = "/api/v1/meeting_manager/userDetailByProductID/" + institute_id + "/" + event;
        this.http_service.getData(url).subscribe(function (data) {
            _this.userList = data.result;
            console.log(_this.userList);
        }, function (error) {
            _this.isRippleLoad = false;
            _this.appC.popToast({ type: "error", body: error.error.message });
        });
    };
    EditClassComponent.prototype.getLiveClassData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.service.getOnlineClass(this.editSessionId).subscribe(function (data) {
            console.log(data);
            _this.editData = data;
            _this.topicName = _this.editData.session_name;
            _this.product_id = _this.editData.product_id;
            if (_this.editData.sent_notification_flag == 1) {
                _this.editData.sent_notification_flag = true;
            }
            else {
                _this.editData.sent_notification_flag = false;
            }
            // if (this.editData.access_before_start == 1) {
            //   this.editData.access_before_start = true;
            // }
            // else {
            _this.editData.access_before_start = false;
            _this.editData.private_access = 0;
            // }
            if (_this.repeat_session == 0) {
                _this.scheduledateFrom = __WEBPACK_IMPORTED_MODULE_1_moment__(_this.editData.start_datetime).format('YYYY-MM-DD');
                var startTime = __WEBPACK_IMPORTED_MODULE_1_moment__(_this.editData.start_datetime).format('hh:mm A');
                var endTime = __WEBPACK_IMPORTED_MODULE_1_moment__(_this.editData.end_datetime).format('hh:mm A');
                _this.hoursFrom = startTime.split(':')[0] + " " + startTime.split(' ')[1];
                _this.minuteFrom = startTime.split(' ')[0].split(':')[1];
                _this.hoursTo = endTime.split(':')[0] + " " + endTime.split(' ')[1];
                _this.minuteTo = endTime.split(' ')[0].split(':')[1];
            }
            _this.getTeachers();
            _this.getCustomUsers();
            if (_this.editData.product_id != null) {
                _this.getUserpreFillData();
            }
        }, function (error) {
            _this.isRippleLoad = false;
            _this.appC.popToast({ type: "error", body: error.error.message });
        });
    };
    EditClassComponent.prototype.getEvent = function (event) {
        var proctur_live_expiry_date = sessionStorage.getItem('proctur_live_expiry_date');
        if (__WEBPACK_IMPORTED_MODULE_1_moment__(event).diff(__WEBPACK_IMPORTED_MODULE_1_moment__(), 'days') < 0) {
            var msg = {
                type: "info",
                body: "You cannot select past date"
            };
            this.appC.popToast(msg);
            this.scheduledateFrom = __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD');
        }
        if (new Date(proctur_live_expiry_date) < new Date(event) && new Date(proctur_live_expiry_date) != new Date(event)) {
            var tempMsg = 'Your live class subscription will get expired on '.concat(__WEBPACK_IMPORTED_MODULE_1_moment__(proctur_live_expiry_date).format('DD-MMM-YYYY')).concat(' hence you will not be able create live class. Renew your subscription to conduct live classes again!');
            this.msgService.showErrorMessage('info', '', tempMsg);
            this.scheduledateFrom = __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD');
        }
    };
    EditClassComponent.prototype.getEventHourFrom = function (e) {
        // this.minuteFrom = "00";
        if (this.hoursFrom != "" && this.hoursFrom != null && this.minuteFrom == "") {
            this.minuteFrom = "00";
        }
        else if (this.hoursTo != "" && this.hoursTo != null && this.minuteTo == "") {
            this.minuteTo = "00";
        }
        if (this.hoursFrom != "" && this.hoursFrom != null && this.minuteFrom != "" && this.minuteFrom != null
            && this.hoursTo != "" && this.hoursTo != null && this.minuteTo != "" && this.minuteTo != null) {
            this.getEventHourTo();
        }
    };
    EditClassComponent.prototype.getEventHourTo = function () {
        var fromTime = __WEBPACK_IMPORTED_MODULE_1_moment__(this.scheduledateFrom).format('YYYY-MM-DD') + " " + this.hoursFrom.split(' ')[0] + ":" + this.minuteFrom + " " + this.hoursFrom.split(' ')[1];
        var toTime = __WEBPACK_IMPORTED_MODULE_1_moment__(this.scheduledateFrom).format('YYYY-MM-DD') + " " + this.hoursTo.split(' ')[0] + ":" + this.minuteTo + " " + this.hoursTo.split(' ')[1];
        var fromTimeT = __WEBPACK_IMPORTED_MODULE_1_moment__(fromTime).format('YYYY-MM-DD hh:mm a');
        var toTimeT = __WEBPACK_IMPORTED_MODULE_1_moment__(toTime).format('YYYY-MM-DD hh:mm a');
        if (__WEBPACK_IMPORTED_MODULE_1_moment__(fromTimeT).diff(__WEBPACK_IMPORTED_MODULE_1_moment__(toTimeT), 'minutes') > 0) {
            this.appC.popToast({ type: "error", body: "From time cannot be greater than to time" });
            return false;
        }
        else if (this.hoursFrom == "" || this.hoursTo == "" || this.minuteFrom == "" || this.minuteTo == "") {
            this.appC.popToast({ type: "error", body: "All fields are required" });
            return false;
        }
        else if (__WEBPACK_IMPORTED_MODULE_1_moment__(fromTimeT).diff(__WEBPACK_IMPORTED_MODULE_1_moment__(), 'minutes') <= 0) {
            this.appC.popToast({ type: "error", body: "Class cannot be schedule before current time" });
            return false;
        }
        else if (fromTimeT == toTimeT) {
            this.appC.popToast({ type: "error", body: "From time and to time cannot be same" });
            return false;
        }
        else {
            this.dateTimeStatus = true;
        }
    };
    EditClassComponent.prototype.checkMandatoryFields = function () {
        this.getEventHourTo();
        if (this.topicName != "" && this.topicName != null && this.selectedFacultyList.length != 0) {
            if (this.dateTimeStatus) {
                this.navigateTo("assignStudent");
                this.getStudentpreFillData();
            }
            else {
                this.getEventHourTo();
            }
        }
        else {
            this.appC.popToast({ type: "error", body: "All fields are required" });
        }
    };
    EditClassComponent.prototype.getStudentpreFillData = function () {
        var studentIDS = this.editData.studentIDS.split(',');
        var studentName = this.editData.studentName.split(',');
        var temp = [];
        for (var i = 0; i < studentIDS.length; i++) {
            var x = {
                student_id: '',
                student_name: ''
            };
            x.student_id = studentIDS[i];
            x.student_name = studentName[i];
            temp.push(x);
        }
        this.studentList = temp;
        this.selectedStudentList = temp;
    };
    EditClassComponent.prototype.getUserpreFillData = function () {
        var userIDs = this.editData.elearnUserIds.split(',');
        var userName = this.editData.eLearnUserName.split(',');
        var temp = [];
        for (var i = 0; i < userIDs.length; i++) {
            var x = {
                user_id: '',
                user_name: ''
            };
            x.user_id = userIDs[i];
            x.user_name = userName[i];
            temp.push(x);
        }
        this.userList = temp;
        this.selectedUserList = temp;
    };
    EditClassComponent.prototype.scheduleClass = function () {
        var _this = this;
        var validationFlag = true;
        // if(!this.isProfessional){
        //   if(this.courseIds != null && this.courseValue != null && this.courseValue != ''){
        //     validationFlag = true;
        //   }
        //   else{
        //     validationFlag = false;
        //     this.appC.popToast({ type: "error", body: "All fields are required" })
        //   }
        // }
        // else{
        //   if(this.batchesIds != null){
        //     validationFlag = true;
        //   }
        //   else{
        //     validationFlag = false;
        //     this.appC.popToast({ type: "error", body: "All fields are required" })
        //   }
        // }
        if (validationFlag) {
            this.facultyId = [];
            this.custUserIds = [];
            this.studentsId = [];
            this.selectedFacultyList.map(function (ele) {
                var x = ele.teacher_id.toString();
                _this.facultyId.push(x);
            });
            this.selectedModeratorList.map(function (ele) {
                var x = ele.userid.toString();
                _this.custUserIds.push(x);
            });
            this.selectedStudentList.map(function (ele) {
                var x = ele.student_id.toString();
                _this.studentsId.push(x);
            });
            this.selectedUserList.map(function (ele) {
                var x = ele.user_id.toString();
                _this.eLearnCustUserIDs.push(x);
            });
            console.log(this.eLearnCustUserIDs);
            this.updateOnlineClass.session_name = this.topicName;
            this.updateOnlineClass.custUserIds = this.custUserIds;
            this.updateOnlineClass.studentIds = this.studentsId;
            this.updateOnlineClass.teacherIds = this.facultyId;
            this.updateOnlineClass.start_datetime = __WEBPACK_IMPORTED_MODULE_1_moment__(this.scheduledateFrom).format('YYYY-MM-DD') + " " + this.hoursFrom.split(' ')[0] + "" + ":" + this.minuteFrom + " " + this.hoursFrom.split(' ')[1];
            this.updateOnlineClass.end_datetime = __WEBPACK_IMPORTED_MODULE_1_moment__(this.scheduledateFrom).format('YYYY-MM-DD') + " " + this.hoursTo.split(' ')[0] + "" + ":" + this.minuteTo + " " + this.hoursTo.split(' ')[1];
            this.updateOnlineClass.eLearnCustUserIDs = this.eLearnCustUserIDs;
            this.updateOnlineClass.product_id = null;
            if (this.editData.sent_notification_flag) {
                this.updateOnlineClass.sent_notification_flag = 1;
            }
            else {
                this.updateOnlineClass.sent_notification_flag = 0;
            }
            if (this.editData.access_before_start) {
                this.updateOnlineClass.access_before_start = 1;
            }
            else {
                this.updateOnlineClass.access_before_start = 0;
            }
            if (this.repeat_session == 0) {
                this.isRippleLoad = true;
                this.service.updateOnlineClass(this.updateOnlineClass, this.editSessionId).subscribe(function (data) {
                    _this.appC.popToast({ type: "success", body: "Live class session " + _this.topicName + " " + "updated successfully" });
                    _this.router.navigate(['/view/live-classes']);
                    _this.isRippleLoad = false;
                }, function (error) {
                    _this.isRippleLoad = false;
                    // this.clearOnlineSchedulesObject() ;
                    _this.facultyId = [];
                    _this.custUserIds = [];
                    _this.studentsId = [];
                    _this.appC.popToast({ type: "error", body: error.error.message });
                });
            }
            if (this.repeat_session == 1) {
                this.updateOnlineClass.studentIds = this.studentsId;
                this.isRippleLoad = true;
                this.service.getOnlineClasses(this.updateOnlineClass).subscribe(function (data) {
                    _this.appC.popToast({ type: "success", body: _this.topicName + " " + "created successfully" });
                    _this.router.navigate(['/view/live-classes']);
                    _this.isRippleLoad = false;
                }, function (error) {
                    _this.isRippleLoad = false;
                    _this.facultyId = [];
                    _this.custUserIds = [];
                    _this.studentsId = [];
                    _this.appC.popToast({ type: "error", body: error.error.message });
                });
            }
        }
    };
    EditClassComponent.prototype.clearOnlineSchedulesObject = function () {
        this.updateOnlineClass = {
            custUserIds: [],
            end_datetime: "",
            institution_id: this.service.institute_id,
            sent_notification_flag: 0,
            session_name: "",
            start_datetime: "",
            studentIds: [],
            teacherIds: [],
            product_id: [],
            eLearnCustUserIDs: [],
            access_before_start: 0,
            access_enable_lobby: false,
            private_access: false
        };
        this.topicName = "";
        this.studentsId = [];
        this.facultyId = [];
        this.scheduledateFrom = __WEBPACK_IMPORTED_MODULE_1_moment__().format('YYYY-MM-DD');
        this.hoursFrom = "";
        this.minuteFrom = "";
        this.hoursTo = "";
        this.minuteTo = "";
        this.courseIds = [];
        this.batchesIds = [];
        this.courseValue = [];
        this.selectedStudentList = [];
        this.selectedFacultyList = [];
        this.selectedModeratorList = [];
        this.navigateTo('classDetails');
    };
    /** this function is used to fetch teacher details */
    EditClassComponent.prototype.getTeachers = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.service.fetchTeachers().subscribe(function (data) {
            _this.teachersAssigned = data;
            console.log(_this.teachersAssigned);
            // this.getCheckedBox(this.teachersAssigned);
            _this.isRippleLoad = false;
            var teachersIds = _this.editData.teachersIds.split(',');
            var teachersNames = _this.editData.teachersName.split(',');
            var temp = [];
            for (var i = 0; i < teachersIds.length; i++) {
                var x = {
                    teacher_id: 0,
                    teacher_name: ''
                };
                x.teacher_id = +teachersIds[i];
                x.teacher_name = teachersNames[i];
                temp.push(x);
            }
            _this.selectedFacultyList = temp;
        }, function (error) {
            _this.teachersAssigned = [];
            _this.errorMessage(error);
            _this.isRippleLoad = false;
        });
    };
    /** this function is used to fetch customer details */
    EditClassComponent.prototype.getCustomUsers = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.service.fetchUsers().subscribe(function (data) {
            _this.userAssigned = data;
            console.log(_this.userAssigned);
            // this.getCheckedBox(this.userAssigned);
            _this.isRippleLoad = false;
            var userid = _this.editData.moderatorIds.split(',');
            var name = _this.editData.moderatorName.split(',');
            var temp = [];
            for (var i = 0; i < userid.length; i++) {
                var x = {
                    userid: '',
                    name: ''
                };
                x.userid = userid[i];
                x.name = name[i];
                temp.push(x);
            }
            _this.selectedModeratorList = temp;
        }, function (error) {
            _this.errorMessage(error);
            _this.userAssigned = [];
            _this.isRippleLoad = false;
        });
    };
    EditClassComponent.prototype.getBatchesCoursesIds = function (ids) {
        if (this.isProfessional) {
            this.batchesIds = ids;
            this.fetchStudentsApi(this.batchesIds);
            // this.getStudents();
        }
        else {
            this.courseIds = ids;
            this.fetchStudentsApi(this.courseIds);
            // this.getStudents();
        }
    };
    EditClassComponent.prototype.getBatchesCourses = function () {
        var _this = this;
        this.isRippleLoad = true;
        if (this.isProfessional) {
            this.service.fetchBatches().subscribe(function (data) {
                _this.batches = data;
                console.log(_this.batches);
                _this.isRippleLoad = false;
            }, function (error) {
                _this.isRippleLoad = false;
                _this.errorMessage(error);
            });
        }
        else {
            this.service.fetchMasters().subscribe(function (data) {
                _this.masters = data;
                // console.log(this.masters)
                _this.isRippleLoad = false;
            }, function (error) {
                console.log(error);
                _this.errorMessage(error);
                _this.isRippleLoad = false;
            });
        }
    };
    EditClassComponent.prototype.getCourses = function (master_course_name) {
        var _this = this;
        if (master_course_name == null || master_course_name == '') {
            this.courses = [];
        }
        else {
            this.isRippleLoad = true;
            this.service.fetchCourses(master_course_name).subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.courses = data.coursesList;
            }, function (error) {
                _this.errorMessage(error);
                _this.isRippleLoad = false;
            });
        }
    };
    EditClassComponent.prototype.getStudents = function () {
        this.studentList = [];
        var str = [];
        if (this.isProfessional) {
            // this.batchesIds.map(
            //   (ele: any) => {
            //     let x = ele.toString();
            //     str.push(x);
            //   }
            // )
            this.fetchStudentsApi(this.batchesIds);
        }
        else {
            // this.courseIds.map(
            //   (ele: any) => {
            //     let x = ele.toString();
            //     str.push(x);
            //   }
            // )
            this.fetchStudentsApi(this.courseIds);
        }
    };
    EditClassComponent.prototype.fetchStudentsApi = function (courseArray) {
        var _this = this;
        this.isRippleLoad = true;
        this.getPayloadBatch.coursesArray = [courseArray];
        this.service.fetchStudents(this.getPayloadBatch).subscribe(function (data) {
            _this.studentList = data.studentsAssigned;
            console.log(data.studentsAssigned);
            // this.getCheckedBox(this.studentsAssigned);
            _this.isRippleLoad = false;
        }, function (error) {
            _this.isRippleLoad = false;
            _this.errorMessage(error);
        });
    };
    EditClassComponent.prototype.errorMessage = function (error) {
        this.appC.popToast({ type: "error", body: error.error.message });
    };
    /* Function to navigate on icon click */
    EditClassComponent.prototype.switchToView = function (id) {
        switch (id) {
            case "class-icon": {
                this.navigateTo("classDetails");
                break;
            }
            case "assignStudent-icon": {
                this.navigateTo("assignStudent");
                break;
            }
            default: {
                this.navigateTo("classDetails");
                break;
            }
        }
    };
    /* Function to navigate through the Student Add Form on button Click Save/Submit*/
    EditClassComponent.prototype.navigateTo = function (text) {
        if (text === "classDetails") {
            if (this.class_id == 0 || this.class_id == null) {
                document.getElementById('li-one').classList.add('active');
                document.getElementById('li-two').classList.remove('active');
                this.isBasicActive = true;
                this.isOtherActive = false;
            }
            else {
                var msg = { type: 'info', title: 'Live Class Details Already Saved', body: '' };
                this.appC.popToast(msg);
            }
        }
        else if (text === "assignStudent") {
            if (this.class_id == 0 || this.class_id == null) {
                document.getElementById('li-one').classList.remove('active');
                document.getElementById('li-two').classList.add('active');
                this.isBasicActive = false;
                this.isOtherActive = true;
                this.getBatchesCourses();
            }
            else {
                var msg = { type: 'info', title: 'Live Class Details Already Saved', body: '' };
                this.appC.popToast(msg);
            }
        }
    };
    EditClassComponent.prototype.cancel = function () {
        this.router.navigateByUrl('/view/live-classes');
    };
    EditClassComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    EditClassComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-edit-class',
            template: __webpack_require__("./src/app/components/live-classes-module/edit-class/edit-class.component.html"),
            styles: [__webpack_require__("./src/app/components/live-classes-module/edit-class/edit-class.component.scss")],
            encapsulation: __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewEncapsulation"].None
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_2__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_4__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_5__services_live_classes_live_class_service__["a" /* LiveClasses */],
            __WEBPACK_IMPORTED_MODULE_2__angular_router__["ActivatedRoute"],
            __WEBPACK_IMPORTED_MODULE_6__services_products_service__["a" /* ProductService */],
            __WEBPACK_IMPORTED_MODULE_7__services_http_service__["a" /* HttpService */],
            __WEBPACK_IMPORTED_MODULE_8____["h" /* MessageShowService */]])
    ], EditClassComponent);
    return EditClassComponent;
}());



/***/ }),

/***/ "./src/app/components/live-classes-module/live-classes-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LiveClassesRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__live_classes_live_classes_component__ = __webpack_require__("./src/app/components/live-classes-module/live-classes/live-classes.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__edit_class_edit_class_component__ = __webpack_require__("./src/app/components/live-classes-module/edit-class/edit-class.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__add_class_add_class_component__ = __webpack_require__("./src/app/components/live-classes-module/add-class/add-class.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__live_classes_live_classes_component__["a" /* LiveClassesComponent */]
    },
    {
        path: 'add',
        component: __WEBPACK_IMPORTED_MODULE_4__add_class_add_class_component__["a" /* AddClassComponent */]
    },
    {
        path: 'edit/:id',
        component: __WEBPACK_IMPORTED_MODULE_3__edit_class_edit_class_component__["a" /* EditClassComponent */]
    }
];
var LiveClassesRoutingModule = /** @class */ (function () {
    function LiveClassesRoutingModule() {
    }
    LiveClassesRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]]
        })
    ], LiveClassesRoutingModule);
    return LiveClassesRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/live-classes-module/live-classes.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LiveClassesModule", function() { return LiveClassesModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__live_classes_routing_module__ = __webpack_require__("./src/app/components/live-classes-module/live-classes-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__add_class_add_class_component__ = __webpack_require__("./src/app/components/live-classes-module/add-class/add-class.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__edit_class_edit_class_component__ = __webpack_require__("./src/app/components/live-classes-module/edit-class/edit-class.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_ng_multiselect_dropdown__ = __webpack_require__("./node_modules/ng-multiselect-dropdown/fesm5/ng-multiselect-dropdown.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__live_classes_live_classes_component__ = __webpack_require__("./src/app/components/live-classes-module/live-classes/live-classes.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_ngx_bootstrap_custome__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__services_live_classes_live_class_service__ = __webpack_require__("./src/app/services/live-classes/live-class.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__services_products_service__ = __webpack_require__("./src/app/services/products.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












var LiveClassesModule = /** @class */ (function () {
    function LiveClassesModule() {
    }
    LiveClassesModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_2__live_classes_routing_module__["a" /* LiveClassesRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_6__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_9_ngx_bootstrap_custome__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_9_ngx_bootstrap_custome__["b" /* TimepickerModule */],
                __WEBPACK_IMPORTED_MODULE_7_ng_multiselect_dropdown__["a" /* NgMultiSelectDropDownModule */].forRoot()
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_8__live_classes_live_classes_component__["a" /* LiveClassesComponent */],
                __WEBPACK_IMPORTED_MODULE_3__add_class_add_class_component__["a" /* AddClassComponent */],
                __WEBPACK_IMPORTED_MODULE_4__edit_class_edit_class_component__["a" /* EditClassComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_10__services_live_classes_live_class_service__["a" /* LiveClasses */],
                __WEBPACK_IMPORTED_MODULE_11__services_products_service__["a" /* ProductService */]
            ]
        })
    ], LiveClassesModule);
    return LiveClassesModule;
}());



/***/ }),

/***/ "./src/app/components/live-classes-module/live-classes/live-classes.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"JsonVars.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<div class=\"middle-section\">\r\n  <aside class=\"middle-full\">\r\n    <section class=\"middle-main clearFix activity-wrapper\">\r\n      <section class=\"middle-top clearFix bulk-header\">\r\n        <div>\r\n          <h1 class=\"pull-left\">\r\n             <span>Live Class</span>\r\n          </h1>\r\n        </div>\r\n\r\n      </section>\r\n      <section>\r\n        <div class=\"live-class-list\">\r\n          <div class=\"live-class-container\" style=\"width:50%;\">\r\n            <div class=\"field-radio-wrapper\">\r\n              <input type=\"radio\" [value]=\"false\" class=\"form-radio\" [(ngModel)]=\"liveClassFor\" (ngModelChange)=\"getClassesFor()\" name=\"liveClasses\" id=\"liveClasses1\">\r\n              <label for=\"liveClasses1\">Upcoming Classes</label>\r\n            </div>\r\n            <div class=\"field-radio-wrapper\">\r\n              <input type=\"radio\" [value]=\"true\"  class=\"form-radio\" [(ngModel)]=\"liveClassFor\" (ngModelChange)=\"getClassesFor()\" name=\"liveClasses\" id=\"liveClasses2\">\r\n              <label for=\"liveClasses2\">Previous Classes</label>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"search-add-class-container\">\r\n            <div class=\"search-filter-wrapper\"> \r\n              <i class=\"fa fa-search\" aria-hidden=\"true\"></i>\r\n              <input type=\"text\" class=\"normal-field\" placeholder=\"Search\" name=\"searchData\" [(ngModel)]=\"searchText\" (keyup)=\"searchInList()\">\r\n            </div>\r\n            <!-- <div class=\"filter-wrapper\">\r\n              <i class=\"fa fa-search\" aria-hidden=\"true\"></i>\r\n              <select class=\"filter\" name=\"\" *ngIf=\"liveClassFor\" [(ngModel)]=\"sortDate\" (ngModelChange)=\"dateRangeChanges()\">\r\n                <option value=\"-1\" selected=\"selected\" hidden disabled>Filter By Date</option>\r\n                <option value=\"last_week\">Last 7 Days</option>\r\n                <option value=\"this_month\">This Month</option>\r\n                <option value=\"last_month\">Last Month</option>\r\n                <option value=\"last_three_month\">Last 3 months</option>\r\n                <option value=\"custom_date_range\">Custom Date range</option>\r\n                <option value=\"all\">All</option>\r\n              </select>\r\n            </div> -->\r\n            <div class=\"add-class-container\">\r\n                <div class=\"questionInfo inline-relative\">\r\n                    <span class=\" i-class\">  \r\n                      <button type=\"button\" name=\"button\" class=\"add-class\" routerLink='/view/live-classes/add' [disabled]=\"proctur_live_expiry_date_check\" [ngStyle]=\"{'opacity':proctur_live_expiry_date_check ? '0.5' : '1' }\">\r\n                      <i class=\"fa fa-plus\" aria-hidden=\"true\" style=\"color: #0084f6;\"></i>&nbsp;Add Live Class </button></span>\r\n                    <div class=\"tooltip-box-field\" *ngIf=\"proctur_live_expiry_date_check\">\r\n                        Your Proctur Live<br>\r\n                        subscription is over.<br> \r\n                        Please pay quickly<br>\r\n                          to continue using it.\r\n                    </div>\r\n                  </div> \r\n                \r\n            </div>\r\n          </div>\r\n        </div>\r\n      </section>\r\n\r\n      <section class=\"live-class\">\r\n        <div class=\"live-class-list-container\" *ngIf=\"getClasses?.length !=0\">\r\n          <div class=\"live-class-item\" *ngFor=\"let class of getClasses\">\r\n            <div class=\"sub-item-1\">\r\n              <div class=\"session_name_and_id_container\" >\r\n                <div class=\"session_name\">\r\n                  <span>{{class.session_name}}</span>\r\n                </div>\r\n                <div class=\"session_id\">\r\n                  <span>Session Id : {{class.session_id}}</span>\r\n                </div>\r\n              </div>\r\n              <div class=\"notification_container\" *ngIf=\"!liveClassFor\">\r\n                <span class=\"upcoming_class\" *ngIf=\"timeLeft(today, class.start_datetime)\">Ongoing</span>\r\n                <!-- <div class=\"spinner\">\r\n                  <div class=\"bounce1\"></div>\r\n                  <div class=\"bounce2\"></div>\r\n                  <div class=\"bounce3\"></div>\r\n                </div> -->\r\n                <div class=\"questionInfo inline-relative\">\r\n                  <span class=\" i-class\">  \r\n                    <button type=\"button\" name=\"button\" class=\"notification_btn\" (click)=\"smsNotification(class.session_id)\" *ngIf=\"!timeLeft(today, class.start_datetime)\" [disabled]=\"proctur_live_expiry_date_check\" [ngStyle]=\"{'opacity':proctur_live_expiry_date_check ? '0.5' : '1' }\">\r\n                      Send SMS Notification\r\n                      <i class=\"fa fa-commenting\" aria-hidden=\"true\"></i>\r\n                    </button> \r\n                  </span>\r\n                  <div class=\"tooltip-box-field\" *ngIf=\"proctur_live_expiry_date_check\">\r\n                      Your Proctur Live<br>\r\n                      subscription is over.<br> \r\n                      Please pay quickly<br>\r\n                        to continue using it.\r\n                  </div>\r\n                </div> \r\n\r\n                \r\n              <div class=\"questionInfo inline-relative\">\r\n                <span class=\" i-class\">  \r\n                <button type=\"button\" name=\"button\" class=\"notification_btn\" (click)=\"pushNotification(class.session_id)\" *ngIf=\"!timeLeft(today, class.start_datetime)\" [disabled]=\"proctur_live_expiry_date_check\" [ngStyle]=\"{'opacity':proctur_live_expiry_date_check ? '0.5' : '1' }\">\r\n                  Send Push Notification\r\n                  <i class=\"fa fa-bell\" aria-hidden=\"true\"></i>\r\n                </button>\r\n                </span>\r\n                <div class=\"tooltip-box-field\" *ngIf=\"proctur_live_expiry_date_check\">\r\n                    Your Proctur Live<br>\r\n                    subscription is over.<br> \r\n                    Please pay quickly<br>\r\n                      to continue using it.\r\n                </div>\r\n               </div> \r\n              </div>\r\n              <div class=\"action_container\" *ngIf=\"!liveClassFor && !timeLeft(today, class.start_datetime)\" >\r\n                <div class=\"questionInfo inline-relative\">\r\n                  <span class=\" i-class\">  \r\n                  <button type=\"button\" name=\"button\" class=\"action_edit\" (click)=\"editStudent(class.session_id)\" [disabled]=\"proctur_live_expiry_date_check\" [ngStyle]=\"{'opacity':proctur_live_expiry_date_check ? '0.5' : '1' }\">\r\n                     Edit\r\n                  <i class=\"fa fa-pencil\" aria-hidden=\"true\"></i>\r\n                  </button>\r\n                  </span>\r\n                  <div class=\"tooltip-box-field\" *ngIf=\"proctur_live_expiry_date_check\">\r\n                      Your Proctur Live<br>\r\n                      subscription is over.<br> \r\n                      Please pay quickly<br>\r\n                      to continue using it.\r\n                  </div>\r\n                </div> \r\n                <div class=\"questionInfo inline-relative\">\r\n                    <span class=\" i-class\">  \r\n                <button type=\"button\" name=\"button\" class=\"action_delete\" (click)=\"cancel(class.session_id)\" [disabled]=\"proctur_live_expiry_date_check\" [ngStyle]=\"{'opacity':proctur_live_expiry_date_check ? '0.5' : '1' }\">\r\n                  Cancel\r\n                  <i class=\"fa fa-times\" aria-hidden=\"true\"></i>\r\n                </button>\r\n              </span>\r\n              <div class=\"tooltip-box-field\" *ngIf=\"proctur_live_expiry_date_check\">\r\n                  Your Proctur Live<br>\r\n                        subscription is over.<br> \r\n                        Please pay quickly<br>\r\n                          to continue using it.\r\n              </div>\r\n             </div> \r\n              </div>\r\n            </div>\r\n            <div class=\"sub-item-2\">\r\n              <div class=\"item_type_1\">\r\n                <span style=\"color: #9898a3;\">Faculty : </span>\r\n                <span style=\"color: #585574;font-weight: 600;\">{{class.teachersName}}</span>\r\n              </div>\r\n              <div class=\"item_type_1\">\r\n                <span  style=\"color: #585574;\">\r\n                  <span style=\"color: #9898a3;\">Date : </span>\r\n                  {{class.startDateTime | date: 'dd MMM yyyy'}}\r\n                 </span>\r\n                <span  style=\"color: #585574;\">\r\n                  <span style=\"color: #9898a3;\">Duration : </span>\r\n                  {{diffDate(class.startDateTime, class.endDateTime) }} hrs\r\n                </span>\r\n              </div>\r\n              <div class=\"item_type_1\">\r\n                <span style=\"color: #585574;\">\r\n                  <span style=\"color: #9898a3;\">Time : </span>\r\n                  <span>{{class.startDateTime | date: 'shortTime'}} - {{class.endDateTime | date: 'shortTime'}}</span>\r\n                </span>\r\n                <span style=\"color: #585574;\">\r\n                  <span style=\"color: #9898a3;\">Moderator : </span>\r\n                  <span *ngIf=\"class.moderatorName != '' && class.moderatorName != null\">{{class.moderatorName}}</span>\r\n                  <span *ngIf=\"class.moderatorName == '' || class.moderatorName == null\">-</span>\r\n                </span>\r\n              </div>\r\n              <div class=\"item_type_3\" *ngIf=\"!liveClassFor\">\r\n                <span style=\"color: #9898a3;\">Time left :</span>\r\n                <span  style=\"color: #585574;font-weight: 600;\">{{getTimeLeft(today, class.startDateTime) }}</span>\r\n              </div>\r\n              <div class=\"item_type_3\" *ngIf=\"liveClassFor\">\r\n                <span style=\"color: #9898a3;\">Attendees : </span>\r\n                <span  style=\"color: #585574;font-weight: 600;\">{{class.attendeesCount}} of {{class.totalAttendeesLimit}}</span>\r\n              </div>\r\n              <div class=\"item_type_2\">\r\n                  <div class=\"questionInfo inline-relative\">\r\n                      <span class=\" i-class\">  \r\n                          <button type=\"button\" name=\"button\" *ngIf=\"!liveClassFor && forUser && forTeacher(class.teachersUserIds)\" [ngClass]=\"checkForTime(class.startDateTime) ? 'start_session' : 'notAllowed'\" (click)=\"startLiveClass(class.session_link, class.startDateTime)\" [disabled]=\"proctur_live_expiry_date_check\" [ngStyle]=\"{'opacity':proctur_live_expiry_date_check ? '0.5' : '1' }\">\r\n                              <i class=\"fa fa-play\" aria-hidden=\"true\"></i>\r\n                              &nbsp;\r\n                              Start Class\r\n                          </button>\r\n                      </span>\r\n                      <div class=\"tooltip-box-field\" *ngIf=\"proctur_live_expiry_date_check\">\r\n                          Your Proctur Live<br>\r\n                          subscription is over.<br> \r\n                          Please pay quickly<br>\r\n                          to continue using it.\r\n                      </div>\r\n                    </div> \r\n               \r\n                    <div class=\"questionInfo inline-relative\">\r\n                        <span class=\" i-class\">  \r\n                            <button type=\"button\" name=\"button\" class=\"repeat_session\" *ngIf=\"liveClassFor\" [disabled]=\"proctur_live_expiry_date_check\" (click)=\"repeatSession(class.session_id)\"  [ngStyle]=\"{'opacity':proctur_live_expiry_date_check ? '0.5' : '1' }\">\r\n                                <i class=\"fa fa-repeat\" aria-hidden=\"true\"></i>\r\n                                &nbsp;\r\n                                Repeat Class\r\n                            </button>\r\n                        </span>\r\n                        <div class=\"tooltip-box-field\" *ngIf=\"proctur_live_expiry_date_check\">\r\n                            Your Proctur Live<br>\r\n                            subscription is over.<br> \r\n                            Please pay quickly<br>\r\n                            to continue using it.\r\n                        </div>\r\n                    </div>\r\n            \r\n              </div>\r\n              <div class=\"item_type_2\" *ngIf=\"liveClassFor && proctur_live_view_or_download_visibility!=0\" >\r\n                &nbsp;&nbsp;\r\n                  <button class=\"viewAction\" title=\"download/view\" (click)=\"viewdownload_links(class)\" [disabled]=\"class.download_links?.length==0\" [ngClass]=\"{'disabledButton': class.download_links?.length==0}\">\r\n                  <!-- <i class=\"fa fa-repeat\" aria-hidden=\"true\" ></i> &nbsp; -->\r\n                  View Recording\r\n                  </button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"live-class-list-container\" *ngIf=\"getClasses?.length ==0 && !liveClassFor && !JsonVars.isRippleLoad\" style=\"margin-top: 3%;\">\r\n          <div style=\"min-height: 60px;text-align: center;font-weight: 600;\">\r\n            No Upcoming Scheduled Found!\r\n          </div>\r\n        </div>\r\n      </section>\r\n\r\n      <!-- <section *ngIf=\"!liveClassFor\">\r\n        <div class=\"note-container\">\r\n          <span><span style=\"font-weight: 600;\">NOTE : </span> Sessions can only be started before 30 minutes of start time.</span>\r\n        </div>\r\n      </section> -->\r\n\r\n      <!-- Paginator Here -->\r\n      <div class=\"row filter-res pagination pagination-correct\" style=\"width: 100%;\">\r\n        <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n          <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n              [page]=\"PageIndex\" [perPage]=\"displayClassSize\" [count]=\"totalRow\">\r\n          </pagination>\r\n        </div>\r\n      </div>\r\n\r\n      </section>\r\n  </aside>\r\n</div>\r\n\r\n\r\n<section [hidden]=\"alertBox\">\r\n  <div class=\"confirmation_popup\">\r\n    <div class=\"confirm_title\">\r\n      <i class=\"fa fa-exclamation-triangle\" aria-hidden=\"true\" style=\"color: rgba(255,0,0,0.7);\"></i> &nbsp;\r\n      <span>Alert</span>\r\n    </div>\r\n    <div class=\"confirmation_msg_box\">\r\n      <span id=\"confirm_msg\">Are you sure you want to cancel the session?</span>\r\n    </div>\r\n    <br>\r\n    <!-- <div class=\"field-checkbox-wrapper\">\r\n      <input type=\"checkbox\" id=\"sms\" name=\"batch\" [(ngModel)]=\"sendSMSNotification\"\r\n          class=\"form-checkbox\">\r\n      <label for=\"sms\"> Send SMS Notification</label>\r\n    </div>\r\n\r\n    <div class=\"field-checkbox-wrapper\">\r\n      <input type=\"checkbox\" id=\"push\" name=\"batch\" [(ngModel)]=\"sendPushNotification\"\r\n          class=\"form-checkbox\">\r\n      <label for=\"push\"> Send Push Notification</label>\r\n    </div> -->\r\n    <div class=\"confirmation_button_container\">\r\n      <input type=\"button\" value=\"Yes\" class=\"btn\" (click)=\"cancelSession()\">\r\n      <input type=\"button\" value=\"No\" class=\"btn\" (click)=\"closeAlert()\">\r\n    </div>\r\n  </div>\r\n</section>\r\n<div class=\"black-bg\" id=\"black-bg\" [hidden]=\"alertBox\" (click)=\"closeAlert()\"></div>\r\n\r\n<section *ngIf=\"viewDownloadPopup\">\r\n    <div class=\"confirmation_popup download_popup\">\r\n      <div class=\"confirm_title\"style=\"font-size: 14px;margin-bottom: 10px;\">\r\n        <span>{{download_links.session_name}}</span>\r\n        <span style=\"cursor: pointer;float:right\"  (click)=\"viewDownloadPopup=false\" >X</span>\r\n      </div>\r\n    <section>\r\n      <div class=\"table-container\">\r\n      <div class=\"heading-container\">\r\n        <div class=\"heading-item\">\r\n          <span>Title</span>\r\n        </div>\r\n        <div class=\"heading-item\" style=\"width: 17%;\">\r\n          <span>Size</span>\r\n        </div>\r\n        <div class=\"heading-item\" style=\"width: 17%;\">\r\n          <span>Duration</span>\r\n        </div>\r\n        <div class=\"heading-item\" style=\"width: 11%;\" *ngIf=\"proctur_live_view_or_download_visibility==1 || proctur_live_view_or_download_visibility == 2|| proctur_live_view_or_download_visibility == 3\">\r\n          <span>Action</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"value-outer-container\">\r\n        <div class=\"value-container\" *ngFor=\"let data of download_links.download_links\" >\r\n          <div class=\"value-item\">\r\n            <span title=\"{{data.session_name}}\">{{(data.session_name.length > 80) ? (data.session_name | slice:0:80) + '...' : data.session_name}}</span>\r\n          </div>\r\n          <div class=\"value-item\" style=\"width: 17%;\">\r\n            <span title=\"{{data.video_size}}\" *ngIf=\"data.video_size!=null\">{{data.video_size}}&nbsp;MB</span>\r\n            <span *ngIf=\"data.video_size==null\">-</span>\r\n          </div>\r\n          <div class=\"value-item\" style=\"width: 17%;\">\r\n            <span title=\"{{data.video_duration}}\" *ngIf=\"data.video_duration!=null\">{{data.video_duration}}&nbsp;mins</span>\r\n            <span *ngIf=\"data.video_duration==null\">-</span>\r\n          </div>\r\n          <div class=\"value-item\" style=\"width: 11%;text-align: center;\">\r\n            <div style=\"float: left;\" *ngIf=\"proctur_live_view_or_download_visibility==1 || proctur_live_view_or_download_visibility==3\">\r\n            <button class=\"fa fa-download\" style=\"font-size: 17px; color: #0084f6; margin-left: 1%;background: none;\" title=\"Download\" (click)=\"downloadFile(data);\"\r\n            id=\"downloadFile\" [disabled]=\"data.download_link==null\" [ngStyle]=\"{'opacity':data.download_link==null ? '0.5' : '1' }\"></button>\r\n            <a id=\"downloadFileClick\" class=\"hide\"></a>        \r\n            </div>\r\n            <div (click)=\"getVdocipherVideoOtp(data)\" *ngIf=\"proctur_live_view_or_download_visibility==2 || proctur_live_view_or_download_visibility==3\">\r\n              <button class=\"fa fa-eye\" style=\"font-size: 17px; color: #0084f6; margin-left: 1%;background: none;\" title=\"View\" \r\n              [disabled]=\"data.video_id==null\" [ngStyle]=\"{'opacity':data.video_id==null ? '0.5' : '1' }\">\r\n              </button>\r\n            </div>\r\n          </div>\r\n      </div>\r\n    </div>\r\n    </div>\r\n  </section>\r\n    </div>\r\n  </section>\r\n<div class=\"black-bg\" id=\"black-bg\" *ngIf=\"viewDownloadPopup\" (click)=\"viewDownloadPopup=false\">\r\n</div>\r\n\r\n<div class=\"ga-modal-wrapper\" [hidden]=\"showVideo\">\r\n  <div class=\"ga-modal-container\">\r\n    <div class=\"ga-modal\" >\r\n      <div style=\"font-size: 14px;padding: 5px;font-weight: 600;\">\r\n        <span>{{tempVideoData.session_name}}</span>\r\n          <span (click)=\"stopVideo()\" style=\"float: right;cursor: pointer;padding-right: 5px;\">\r\n            <span >X</span>\r\n          </span>\r\n      </div>\r\n      <div class=\"ga-modal-body\">\r\n        <div class=\"row upload-box\">\r\n          <div id=\"embedBox\" style=\"width:700px;max-width:100%;height:auto;\"></div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n<!-- <div id=\"black-bg\" (click)=\"stopVideo()\"  [hidden]=\"showVideo\"></div> -->\r\n"

/***/ }),

/***/ "./src/app/components/live-classes-module/live-classes/live-classes.component.scss":
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\nhtml {\n  overflow-y: scroll; }\n.made {\n  border: 1px solid black;\n  border-radius: 50%;\n  height: 32px;\n  width: 32px;\n  padding-top: 8px; }\n.widget {\n  height: auto;\n  width: 85%;\n  background: white;\n  border: 1px solid #efefef;\n  margin-left: 6%;\n  -webkit-box-shadow: -1px -1px 9px 4px #efefef;\n          box-shadow: -1px -1px 9px 4px #efefef;\n  border-radius: 10px; }\n.skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 100%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n.skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n.madeNe {\n  width: 95%;\n  margin-left: 3%;\n  margin-top: 17px; }\n.made-out {\n  border: 1px solid #efefef; }\n.madeNe {\n  height: 180px;\n  overflow: hidden; }\n.madeNe .tabel-ne {\n    height: 180px;\n    overflow: auto; }\n.form-submit .field-radio-wrapper {\n  width: 20px;\n  overflow: hidden;\n  -webkit-box-sizing: border-box;\n  box-sizing: border-box;\n  height: 20px;\n  padding-left: 20px;\n  margin-bottom: 0;\n  margin-left: 5px;\n  background: transparent;\n  border-radius: 2px; }\n.form-submit .field-radio-wrapper .form-radio {\n    opacity: 0;\n    position: absolute;\n    left: 0;\n    top: 0;\n    width: 20px;\n    height: 20px;\n    z-index: 1; }\n.form-submit .field-radio-wrapper label {\n    cursor: pointer; }\n.alignment th {\n  text-align: left; }\n.alignment td {\n  text-align: left; }\n.pointed-one {\n  cursor: pointer; }\n.row-inner .field-wrapper {\n  position: relative; }\n.row-inner .field-wrapper.datePickerBox .form-ctrl {\n    cursor: pointer;\n    position: relative;\n    z-index: 1;\n    background: transparent; }\n.row-inner .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(/./assets/images/calendar.svg) no-repeat;\n    position: absolute;\n    right: 21px;\n    top: 33px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n.made-in .field-checkbox-wrapper .form-checkbox label:after {\n  content: '';\n  width: 16px;\n  height: 17px;\n  border: 2px solid #ccc;\n  border-radius: 2px;\n  position: absolute;\n  left: 0;\n  top: 4px; }\ntable thead tr th {\n  padding: 14px; }\n.view-class {\n  margin-right: 10%;\n  margin-top: -2%;\n  cursor: pointer; }\n.teacherId th {\n  text-align: left; }\n.teacherId td {\n  text-align: left; }\n.made-teacher {\n  width: 95%;\n  margin-left: 3%;\n  margin-top: 17px; }\n.made-teacher {\n  height: 292px;\n  overflow: hidden; }\n.made-teacher .table-teacher {\n    height: 292px;\n    overflow: auto; }\n.middle-section {\n  padding: 1%; }\n.border-container {\n  border-top: 1px solid #e3e3e3; }\n.live-class-list {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  margin: 10px 0px; }\n.live-class-list .live-class-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row; }\n.live-class-list .live-class-container .field-radio-wrapper {\n      position: relative;\n      margin-right: 20px;\n      margin-bottom: 0px;\n      margin-top: 10px; }\n.live-class-list .live-class-container .field-radio-wrapper label {\n        color: #333333;\n        font-weight: bold; }\n.search-add-class-container {\n  float: right;\n  margin-right: 30px;\n  width: 50%;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end; }\n.search-add-class-container .search-filter-wrapper {\n    width: 30%;\n    position: relative; }\n.search-add-class-container .search-filter-wrapper i {\n      position: absolute;\n      right: 15px;\n      padding: 7px 9px;\n      top: 1px;\n      background: white;\n      pointer-events: none; }\n.search-add-class-container .search-filter-wrapper .normal-field {\n      padding: 7px 10px;\n      border: 1px solid #ccc;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      margin: 0;\n      height: 35px;\n      font-size: 14px;\n      border-radius: 4px; }\n.search-add-class-container .filter-wrapper {\n    margin-left: 20px; }\n.search-add-class-container .filter-wrapper i {\n      position: absolute;\n      right: 7px;\n      padding: 7px 9px;\n      top: 1px;\n      background: white;\n      pointer-events: none; }\n.search-add-class-container .filter-wrapper .filter {\n      padding: 7px 10px;\n      border: 1px solid #ccc;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      height: 35px;\n      font-size: 14px; }\n.search-add-class-container .add-class-container {\n    margin-left: 20px; }\n.search-add-class-container .add-class-container .add-class {\n      background: white;\n      border-radius: 4px;\n      border: 1px solid #0084f6;\n      outline: none;\n      text-align: center;\n      padding: 8px 20px;\n      height: 35px;\n      font-weight: 600;\n      color: #0084f6;\n      -webkit-box-shadow: 0px 0px 1px #0084f6;\n      box-shadow: 0px 0px 1px #0084f6; }\n.live-class {\n  height: 66vh;\n  max-height: 66vh;\n  overflow-x: hidden;\n  overflow-y: auto; }\n.live-class ::-webkit-scrollbar {\n    width: 10px; }\n.live-class .live-class-list-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    width: 100%; }\n.live-class .live-class-list-container .live-class-item {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      margin-bottom: 10px;\n      border-radius: 4px;\n      -webkit-box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.16);\n              box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.16);\n      background-color: #ffffff;\n      padding: 15px;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      width: 98%;\n      margin-left: 1%;\n      margin-right: 1%;\n      margin-top: 1%; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .session_name_and_id_container {\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: vertical;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: column;\n                  flex-direction: column;\n          width: 58%;\n          text-align: left; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .session_name_and_id_container .session_name {\n            font-size: 16px;\n            font-weight: 600; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .session_name_and_id_container .session_id {\n            margin-top: 5px;\n            color: #acacac;\n            font-size: 14px; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .notification_container {\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: horizontal;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: row;\n                  flex-direction: row;\n          width: 45%;\n          -webkit-box-pack: end;\n              -ms-flex-pack: end;\n                  justify-content: flex-end; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .notification_container .upcoming_class {\n            color: #ec7600;\n            font-weight: 600;\n            margin-right: 5px;\n            margin-top: 5px; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .notification_container .spinner {\n            margin-top: 7px; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .notification_container .spinner > div {\n            width: 5px;\n            height: 5px;\n            background-color: #ec7600;\n            border-radius: 100%;\n            display: inline-block;\n            -webkit-animation: sk-bouncedelay 1.4s infinite ease-in-out both;\n            animation: sk-bouncedelay 1.4s infinite ease-in-out both; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .notification_container .spinner .bounce1 {\n            -webkit-animation-delay: -0.32s;\n            animation-delay: -0.32s; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .notification_container .spinner .bounce2 {\n            -webkit-animation-delay: -0.16s;\n            animation-delay: -0.16s; }\n@-webkit-keyframes sk-bouncedelay {\n  0%, 80%, 100% {\n    -webkit-transform: scale(0); }\n  40% {\n    -webkit-transform: scale(1); } }\n@keyframes sk-bouncedelay {\n  0%, 80%, 100% {\n    -webkit-transform: scale(0);\n    transform: scale(0); }\n  40% {\n    -webkit-transform: scale(1);\n    transform: scale(1); } }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .notification_container i {\n            margin-left: 5px; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .notification_container .notification_btn {\n            padding: 5px;\n            text-align: left;\n            color: #1283f4;\n            font-size: 13px;\n            border: 1px solid #daecfd;\n            background: white;\n            outline: none;\n            height: 30px;\n            width: 95%;\n            margin-right: 10px;\n            border-radius: 4px; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .action_container {\n          width: 15%;\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: horizontal;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: row;\n                  flex-direction: row;\n          -ms-flex-pack: distribute;\n              justify-content: space-around; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .action_container .action_edit {\n            padding: 5px;\n            text-align: center;\n            color: #1283f4;\n            font-size: 13px;\n            border: 1px solid #daecfd;\n            outline: none;\n            background: white;\n            height: 30px;\n            width: 100%;\n            border-radius: 4px; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .action_container .action_edit i {\n              margin-left: 10px; }\n.live-class .live-class-list-container .live-class-item .sub-item-1 .action_container .action_delete {\n            padding: 5px;\n            text-align: left;\n            color: #fa3145;\n            font-size: 13px;\n            border: 1px solid #ffe2e2;\n            outline: none;\n            background: white;\n            height: 30px;\n            width: 100%;\n            border-radius: 4px; }\n.live-class .live-class-list-container .live-class-item .sub-item-2 {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        margin-top: 5px;\n        height: 40px;\n        width: 100%; }\n.live-class .live-class-list-container .live-class-item .sub-item-2 .item_type_1 {\n          width: 26.25%;\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: vertical;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: column;\n                  flex-direction: column;\n          -webkit-box-pack: space-evenly;\n              -ms-flex-pack: space-evenly;\n                  justify-content: space-evenly;\n          height: 40px; }\n.live-class .live-class-list-container .live-class-item .sub-item-2 .item_type_2 {\n          width: 12%;\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-pack: end;\n              -ms-flex-pack: end;\n                  justify-content: flex-end; }\n.live-class .live-class-list-container .live-class-item .sub-item-2 .item_type_2 .start_session {\n            background: #67c967;\n            color: white;\n            border-radius: 4px;\n            text-align: center;\n            text-transform: uppercase;\n            padding: 10px 19px;\n            font-weight: 600; }\n.live-class .live-class-list-container .live-class-item .sub-item-2 .item_type_2 .notAllowed {\n            background: #acacac;\n            color: white;\n            border-radius: 4px;\n            text-align: center;\n            text-transform: uppercase;\n            padding: 10px 19px;\n            font-weight: 600; }\n.live-class .live-class-list-container .live-class-item .sub-item-2 .item_type_2 .repeat_session {\n            background: #1283f4;\n            color: white;\n            border-radius: 4px;\n            text-align: center;\n            text-transform: uppercase;\n            padding: 10px 19px;\n            font-weight: 600; }\n.live-class .live-class-list-container .live-class-item .sub-item-2 .item_type_3 {\n          width: 12%;\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-pack: space-evenly;\n              -ms-flex-pack: space-evenly;\n                  justify-content: space-evenly;\n          -webkit-box-orient: vertical;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: column;\n                  flex-direction: column;\n          text-align: right;\n          padding-right: 15px; }\n.note-container {\n  margin-left: 1%;\n  margin-top: 15px;\n  width: 98%;\n  border: 1px solid #c5c5cc;\n  border-radius: 4px;\n  padding: 10px;\n  color: #3f4260; }\n.filter-res.pagination {\n  width: 100%; }\n.pagination .first:before {\n  content: \"« \";\n  font-size: 16px;\n  font-weight: 800; }\n.pagination .last:after {\n  content: \" »\";\n  font-size: 16px;\n  font-weight: 800; }\n.pagination .batch-size {\n  font-size: 16px;\n  font-weight: 800;\n  border-bottom: 1px solid black; }\n.pagination li {\n  border-right: 1px solid #ccc;\n  padding: 0px 7px;\n  margin: 0;\n  line-height: 10px;\n  font-weight: 800;\n  cursor: pointer; }\n.pagination li a {\n    line-height: 10px;\n    font-size: 16px;\n    font-weight: 800;\n    border: none;\n    padding: 0px 14px; }\n.pagination li :hover {\n    background-color: transparent !important; }\n.pagination li:last-child {\n  border-right: 0;\n  padding-right: 0; }\n@media screen and (max-width: 2000px) and (min-width: 1400px) {\n  .search-filter-wrapper i {\n    right: 28px !important;\n    top: 4px !important; } }\n.black-bg {\n  background: rgba(10, 10, 10, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 1;\n  width: 100%; }\n.confirmation_popup {\n  position: fixed;\n  top: 35%;\n  left: 40%;\n  width: 300px;\n  background: white;\n  height: auto;\n  padding: 20px;\n  z-index: 100;\n  border-radius: 6px;\n  border-top: 4px solid rgba(255, 0, 0, 0.7);\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c; }\n.confirm_title {\n  font-size: 20px; }\n.confirmation_msg_box {\n  margin-top: 15px; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox {\n  opacity: 0;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px;\n  z-index: 1;\n  border: 2px solid #0084f6; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox + label {\n  vertical-align: middle;\n  font-size: 14px;\n  display: inline-block; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 2px;\n  position: absolute;\n  left: 0;\n  top: 0; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox:checked + label:after {\n  border: 2px solid #0084f6; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox + label:before {\n  width: 1px;\n  height: 1px;\n  left: 8px;\n  top: 9px;\n  position: absolute;\n  content: '';\n  border-top: 0;\n  border-right: 0;\n  border-left: 2px solid transparent;\n  border-bottom: 2px solid transparent;\n  -webkit-transform: rotate(-45deg);\n          transform: rotate(-45deg); }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox:checked + label:before {\n  border-left: 2px solid #0084f6;\n  border-bottom: 2px solid #0084f6;\n  width: 12px;\n  height: 5px;\n  left: 2px;\n  top: 5px; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox:checked + label {\n  color: #0084f6; }\n.confirmation_button_container {\n  margin-top: 20px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center; }\n.confirmation_button_container input {\n    width: 80px; }\n.qInfoIcon {\n  width: 17px;\n  margin-left: 4px;\n  height: 20px;\n  border: 1px solid #ccc;\n  border-radius: 50%;\n  display: block;\n  text-align: center;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  line-height: 20px;\n  font-weight: 600;\n  font-size: 12px;\n  cursor: pointer;\n  -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n          box-shadow: 0px 0px 1px 0px #ccc inset;\n  color: #888;\n  -webkit-transition: all 0.2s linear;\n  transition: all 0.2s linear; }\n.tooltip-box-field {\n  white-space: nowrap;\n  min-height: 41px;\n  line-height: 12px;\n  padding: 5px 5px;\n  overflow: visible;\n  color: black;\n  font-weight: bold;\n  top: 30px; }\n.tooltip-box-field.lg {\n    width: 200px;\n    white-space: nowrap;\n    min-height: 50px;\n    line-height: 20px;\n    padding: 5px 5px; }\n.tooltip-box-field.sm {\n    width: 100px;\n    white-space: nowrap;\n    min-height: 40px;\n    padding: 5px 5px; }\n.viewAction {\n  background: white;\n  border-radius: 4px;\n  border: 1px solid #0084f6;\n  outline: none;\n  text-align: center;\n  padding: 8px 20px;\n  height: 52px;\n  font-weight: 600;\n  color: #0084f6;\n  -webkit-box-shadow: 0px 0px 1px #0084f6;\n          box-shadow: 0px 0px 1px #0084f6;\n  cursor: pointer; }\n.download_popup {\n  border: none;\n  width: 40%;\n  top: 20%;\n  left: 35%; }\n.table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%; }\n.table-container .heading-container {\n    background: #e0eaec;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    font-size: 14px;\n    font-weight: 600;\n    text-align: left;\n    padding: 10px;\n    border: 1px solid #ccc; }\n.table-container .heading-container .heading-item {\n      width: 60%; }\n.table-container .value-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    min-height: 40vh;\n    max-height: 40vh;\n    overflow-x: hidden;\n    overflow-y: auto;\n    border: 1px solid #ccc; }\n.table-container .value-outer-container .value-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      text-align: left;\n      padding: 10px;\n      font-size: 12px;\n      border-bottom: 1px solid #ccc;\n      border-top: none; }\n.table-container .value-outer-container .value-container .value-item {\n        width: 60%; }\n.ga-modal-wrapper {\n  right: 0;\n  position: fixed;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  background: rgba(136, 136, 136, 0.6);\n  z-index: 999; }\n.ga-modal-wrapper .ga-modal-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    overflow-y: auto;\n    height: 100%; }\n.ga-modal-wrapper .ga-modal-container .ga-modal {\n      margin: auto;\n      background: #fff;\n      border: 2pt solid #fff;\n      border-radius: .2em;\n      -webkit-box-shadow: 0 2pt 3pt #999;\n              box-shadow: 0 2pt 3pt #999;\n      min-width: 30%; }\n.ga-modal-wrapper .ga-modal-container .ga-modal .ga-modal-head {\n        padding: .5em 1em;\n        border-bottom: 1pt solid #ddd;\n        font-weight: bold;\n        text-align: center; }\n.ga-modal-wrapper .ga-modal-container .ga-modal .ga-modal-body {\n        padding: 1em;\n        text-align: center; }\n.disabledButton {\n  cursor: no-drop;\n  opacity: 0.5; }\n"

/***/ }),

/***/ "./src/app/components/live-classes-module/live-classes/live-classes.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LiveClassesComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_live_classes_live_class_service__ = __webpack_require__("./src/app/services/live-classes/live-class.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6____ = __webpack_require__("./src/app/index.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var LiveClassesComponent = /** @class */ (function () {
    function LiveClassesComponent(auth, service, appC, router, _http, msgService) {
        this.auth = auth;
        this.service = service;
        this.appC = appC;
        this.router = router;
        this._http = _http;
        this.msgService = msgService;
        this.activeIndex = 1;
        this.studentForm = true;
        this.kyc = false;
        this.isProfessional = false;
        this.feeDetails = false;
        this.inventory = false;
        this.openClassPopup = false;
        this.pastClassesPopup = false;
        this.futureClassesPopup = false;
        this.allClasses = true;
        this.liveClassFor = false;
        this.validations = false;
        this.sendNotifyMe = false;
        this.rescheduleClass = false;
        this.PageIndex = 1;
        this.displayClassSize = 10;
        this.classListDataSource = [];
        this.classList = [];
        this.searchData = [];
        this.download_links = [];
        this.searchDataFlag = false;
        this.JsonVars = {
            isRippleLoad: false,
            selected: false,
            submitReq: false
        };
        this.batches = [];
        this.hour = ['01 AM', '02 AM', '03 AM', '04 AM', '05 AM', '06 AM', '07 AM', '08 AM', '09 AM', '10 AM', '11 AM', '12 AM', '01 PM', '02 PM', '03 PM', '04 PM', '05 PM', '06 PM', '07 PM', '08 PM', '09 PM', '10 PM', '11 PM', '12 PM'];
        this.minutes = ['00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55'];
        this.batchesIds = [];
        this.courseIds = [];
        this.studentsAssigned = [];
        this.teachersAssigned = [];
        this.userAssigned = [];
        this.masters = [];
        this.courses = [];
        this.isStudentCheckedArr = [];
        this.isUserCheckedArr = [];
        this.teacherIdArr = [];
        this.getClasses = [];
        this.getPastClasses = [];
        this.getFutureClasses = [];
        this.customId = [];
        this.studentId = [];
        this.columnMaps = [0, 1, 2, 3];
        this.hourFrom = "";
        this.hourTo = "";
        this.minuteTo = "";
        this.minuteFrom = "";
        this.teacherId = '';
        this.courseValue = '';
        this.session = "";
        this.hourFromReschedule = "";
        this.minuteFromReschedule = "";
        this.hourToReschedule = "";
        this.minuteToReschedule = "";
        this.classDetails = "";
        this.dateToday = __WEBPACK_IMPORTED_MODULE_2_moment__().format('YYYY-MM-DD');
        this.dateFrom = __WEBPACK_IMPORTED_MODULE_2_moment__(new Date()).format('YYYY-MM-DD');
        this.rescheduledateFrom = __WEBPACK_IMPORTED_MODULE_2_moment__(new Date()).format('YYYY-MM-DD');
        this.rescheduleclass = {
            end_datetime: "",
            institution_id: this.service.institute_id,
            session_id: "",
            start_datetime: ""
        };
        this.getOnlineClasses = {
            custUserIds: [],
            end_datetime: "",
            institution_id: this.service.institute_id,
            sent_notification_flag: 0,
            session_name: "",
            start_datetime: "",
            studentIds: [],
            teacherIds: []
        };
        this.getPayloadBatch = {
            inst_id: this.service.institute_id,
            coursesArray: [''],
            role: 'student'
        };
        this.previosLiveClasses = [];
        this.futureLiveClasses = [];
        this.today = new Date();
        this.liveClassSearchFilter = {
            from_date: '',
            to_date: ''
        };
        this.obj = {
            institution_id: '',
            user_id: ''
        };
        this.alertBox = true;
        this.sendSMSNotification = false;
        this.sendPushNotification = false;
        this.forUser = false;
        this.proctur_live_expiry_date_check = false;
        this.viewDownloadPopup = false;
        this.tempVideoData = {};
        this.showVideo = true;
        this.proctur_live_view_or_download_visibility = 0;
        this.searchText = "";
    }
    LiveClassesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        var userType = sessionStorage.getItem('userType');
        if (userType == '3') {
            this.forUser = true;
        }
        this.getClassesList();
    };
    LiveClassesComponent.prototype.checkLiveClassExpiry = function (proctur_live_expiry_date) {
        var currentDate = (new Date());
        proctur_live_expiry_date = (new Date(proctur_live_expiry_date));
        currentDate.setHours(0, 0, 0, 0);
        proctur_live_expiry_date.setHours(0, 0, 0, 0);
        if (proctur_live_expiry_date < currentDate) {
            this.proctur_live_expiry_date_check = true;
        }
        if (proctur_live_expiry_date == currentDate) {
            this.proctur_live_expiry_date_check = false;
        }
    };
    LiveClassesComponent.prototype.getClassesList = function () {
        var _this = this;
        this.PageIndex = 1;
        this.JsonVars.isRippleLoad = true;
        this.obj = {
            institution_id: this.service.institute_id,
        };
        var userType = sessionStorage.getItem('userType');
        if (userType != 0) {
            var userid = sessionStorage.getItem('userid');
            this.obj.user_id = userid;
        }
        this.service.fetchOnlineClasses(this.obj).subscribe(function (data) {
            _this.JsonVars.isRippleLoad = false;
            _this.previosLiveClasses = data.pastLiveClasses;
            _this.futureLiveClasses = data.upcomingLiveClasses;
            var proctur_live_expiry_date = data.proctur_live_expiry_date;
            sessionStorage.setItem('proctur_live_expiry_date', proctur_live_expiry_date);
            if (proctur_live_expiry_date != null) {
                _this.checkLiveClassExpiry(proctur_live_expiry_date);
            }
            _this.proctur_live_view_or_download_visibility = data.proctur_live_view_or_download_visibility;
            _this.getClassesFor();
            // console.log(this.getClasses)
            _this.totalRow = _this.getClasses.length;
            _this.fetchTableDataByPage(_this.PageIndex);
            _this.getClasses.map(function (ele) {
                ele.start_datetime = __WEBPACK_IMPORTED_MODULE_2_moment__(ele.start_datetime).format('YYYY-MM-DD hh:mm a');
            });
            _this.getClasses.map(function (ele) {
                ele.end_datetime = __WEBPACK_IMPORTED_MODULE_2_moment__(ele.end_datetime).format('YYYY-MM-DD hh:mm a');
            });
        }, function (error) {
            _this.JsonVars.isRippleLoad = false;
            _this.errorMessage(error);
        });
    };
    LiveClassesComponent.prototype.forTeacher = function (teachersUserIds) {
        var userId = sessionStorage.getItem('userid');
        if (teachersUserIds.includes(userId)) {
            return true;
        }
        else {
            return false;
        }
    };
    LiveClassesComponent.prototype.startLiveClass = function (link, start_time) {
        var time = this.diffDate(this.today, start_time);
        var splitedTime = time.split(":");
        var hrs = +splitedTime[0];
        var mins = +splitedTime[1];
        if (hrs <= 0 && mins <= 30) {
            window.open(link, "_blank");
        }
        else {
            this.appC.popToast({ type: "error", body: "Sessions can only be started before 30 minutes of start time." });
        }
    };
    LiveClassesComponent.prototype.checkForTime = function (start_time) {
        var time = this.diffDate(this.today, start_time);
        var splitedTime = time.split(":");
        var hrs = +splitedTime[0];
        var mins = +splitedTime[1];
        if (hrs <= 0 && mins <= 30) {
            return true;
        }
        else {
            return false;
        }
    };
    LiveClassesComponent.prototype.dateRangeChanges = function () {
        if (this.sortDate == "all") {
            // this.filteredDate = true;
            this.liveClassSearchFilter = {
                from_date: '',
                to_date: ''
            };
        }
        else if (this.sortDate == "last_week") {
            var begin = __WEBPACK_IMPORTED_MODULE_2_moment__().format('YYYY-MM-DD');
            var end = __WEBPACK_IMPORTED_MODULE_2_moment__().subtract('week', 1).format('YYYY-MM-DD');
            this.liveClassSearchFilter = {
                from_date: end,
                to_date: begin
            };
        }
        else if (this.sortDate == "this_month") {
            var begin = __WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-01");
            var end = __WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-") + __WEBPACK_IMPORTED_MODULE_2_moment__().daysInMonth();
            this.liveClassSearchFilter = {
                from_date: begin,
                to_date: end
            };
        }
        else if (this.sortDate == "last_month") {
            var begin = __WEBPACK_IMPORTED_MODULE_2_moment__().subtract('months', 1).format('YYYY-MM-01');
            var end = __WEBPACK_IMPORTED_MODULE_2_moment__().date(0).format("YYYY-MM-DD");
            this.liveClassSearchFilter = {
                from_date: begin,
                to_date: end
            };
        }
        else if (this.sortDate == "last_three_month") {
            var begin = __WEBPACK_IMPORTED_MODULE_2_moment__().format('YYYY-MM-DD');
            var end = __WEBPACK_IMPORTED_MODULE_2_moment__().subtract('months', 3).format('YYYY-MM-DD');
            this.liveClassSearchFilter = {
                from_date: end,
                to_date: begin
            };
        }
        else if (this.sortDate == "custom_date_range") {
            // this.openCalendar('dateRange');
        }
        var from_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.liveClassSearchFilter.from_date).format("DD MMM YYYY");
        var to_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.liveClassSearchFilter.to_date).format("DD MMM YYYY");
        console.log(this.liveClassSearchFilter);
    };
    LiveClassesComponent.prototype.editStudent = function (session_id) {
        this.router.navigate(['/view/live-classes/edit/' + session_id], { queryParams: { repeat: 0 } });
    };
    LiveClassesComponent.prototype.repeatSession = function (session_id) {
        this.router.navigate(['/view/live-classes/edit/' + session_id], { queryParams: { repeat: 1 } });
    };
    LiveClassesComponent.prototype.getClassesFor = function () {
        if (this.liveClassFor) {
            this.getClasses = this.previosLiveClasses;
            this.classListDataSource = this.previosLiveClasses;
        }
        else {
            this.getClasses = this.futureLiveClasses;
            this.classListDataSource = this.futureLiveClasses;
        }
        this.totalRow = this.getClasses.length;
        this.fetchTableDataByPage(this.PageIndex);
    };
    LiveClassesComponent.prototype.diffDate = function (date1, date2) {
        var dateOut1 = new Date(date1); // it will work if date1 is in ISO format
        var dateOut2 = new Date(date2);
        var timeDiff = dateOut2.getTime() / 1000 - dateOut1.getTime() / 1000;
        var hours = Math.floor(timeDiff / (60 * 60));
        var divisor_for_minutes = timeDiff % (60 * 60);
        var minutes = Math.floor(divisor_for_minutes / 60);
        var divisor_for_seconds = divisor_for_minutes % 60;
        var seconds = Math.ceil(divisor_for_seconds);
        if (hours.toString().length == 1) {
            hours = "0" + hours;
        }
        if (minutes.toString().length == 1) {
            minutes = "0" + minutes;
        }
        var time = hours + ":" + minutes;
        return time;
    };
    LiveClassesComponent.prototype.getTimeLeft = function (date1, date2) {
        var time = this.diffDate(date1, date2);
        var splitedTime = time.split(":");
        var hrs = +splitedTime[0];
        var mins = +splitedTime[1];
        var inDays = Math.floor(hrs / 24);
        if (inDays > 0) {
            if (inDays > 1) {
                return inDays + " days";
            }
            else {
                return inDays + " day";
            }
        }
        else if (hrs < 0) {
            return "00:00 hrs";
        }
        else {
            if (hrs == 0) {
                return mins + " mins";
            }
            else {
                return time + " hrs";
            }
        }
    };
    LiveClassesComponent.prototype.timeLeft = function (date1, date2) {
        var time = this.diffDate(date1, date2);
        var splitedTime = time.split(":");
        var hrs = +splitedTime[0];
        if (hrs < 0) {
            return true;
        }
        else {
            return false;
        }
    };
    LiveClassesComponent.prototype.searchInList = function () {
        var _this = this;
        console.log(1);
        if (this.searchText != "" && this.searchText != null) {
            var searchData = this.classListDataSource.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.searchData = searchData;
            console.log(this.searchData);
            this.totalRow = searchData.length;
            this.searchDataFlag = true;
            this.PageIndex = 1;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchDataFlag = false;
            this.fetchTableDataByPage(this.PageIndex);
            this.totalRow = this.classListDataSource.length;
        }
    };
    // pagination functions
    LiveClassesComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.displayClassSize * (index - 1);
        this.getClasses = this.getDataFromDataSource(startindex);
    };
    LiveClassesComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    LiveClassesComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    LiveClassesComponent.prototype.getDataFromDataSource = function (startindex) {
        var data = [];
        if (this.searchDataFlag) {
            data = this.searchData.slice(startindex, startindex + this.displayClassSize);
        }
        else {
            data = this.classListDataSource.slice(startindex, startindex + this.displayClassSize);
        }
        return data;
    };
    LiveClassesComponent.prototype.getTimeInfo = function () {
        var fromTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.dateFrom).format('YYYY-MM-DD') + " " + this.hourFrom.split(' ')[0] + ":" + this.minuteFrom + " " + this.hourFrom.split(' ')[1];
        var fromDate = __WEBPACK_IMPORTED_MODULE_2_moment__().format('YYYY-MM-DD');
        var toTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.dateFrom).format('YYYY-MM-DD') + " " + this.hourTo.split(' ')[0] + ":" + this.minuteTo + " " + this.hourTo.split(' ')[1];
        var fromTimeT = __WEBPACK_IMPORTED_MODULE_2_moment__(fromTime).format('YYYY-MM-DD hh:mm a');
        var toTimeT = __WEBPACK_IMPORTED_MODULE_2_moment__(toTime).format('YYYY-MM-DD hh:mm a');
        if (__WEBPACK_IMPORTED_MODULE_2_moment__(fromTimeT).diff(__WEBPACK_IMPORTED_MODULE_2_moment__(toTimeT), 'minutes') > 0) {
            this.appC.popToast({ type: "error", body: "From time cannot be greater than to time" });
            return false;
        }
        else if (this.hourFrom == "" || this.hourTo == "" || this.minuteFrom == "" || this.minuteTo == "" || this.getOnlineClasses.session_name == "") {
            this.appC.popToast({ type: "error", body: "All mandatory fields are required" });
            return false;
        }
        else if (__WEBPACK_IMPORTED_MODULE_2_moment__(fromTimeT).diff(__WEBPACK_IMPORTED_MODULE_2_moment__(), 'minutes') <= 20) {
            this.appC.popToast({ type: "error", body: "Class can be schedule 20 minutes from current time" });
            return false;
        }
        else if (fromTimeT == toTimeT) {
            this.appC.popToast({ type: "error", body: "From time and to time cannot be same" });
            return false;
        }
        else {
            // this.getBatchesCourses();
        }
    };
    LiveClassesComponent.prototype.close = function () {
        this.openClassPopup = false;
    };
    LiveClassesComponent.prototype.errorMessage = function (error) {
        this.appC.popToast({ type: "error", body: error.error.message });
    };
    LiveClassesComponent.prototype.sendNotify = function (notify) {
        if (notify == true) {
            this.getOnlineClasses.sent_notification_flag = 1;
        }
        else {
            this.getOnlineClasses.sent_notification_flag = 0;
        }
    };
    LiveClassesComponent.prototype.smsNotification = function (id) {
        var _this = this;
        var obj = {};
        if (confirm("Are you sure you want to send SMS notification ? ")) {
            this.service.smsNotification(id, obj).subscribe(function (data) {
                _this.appC.popToast({ type: "success", body: "SMS notification sent successfully" });
                // this.getClassesList();
            }, function (error) {
                _this.errorMessage(error);
            });
        }
    };
    LiveClassesComponent.prototype.pushNotification = function (id) {
        var _this = this;
        var obj = {};
        if (confirm("Are you sure you want to send push notification ?")) {
            this.service.pushNotification(id, obj).subscribe(function (data) {
                _this.appC.popToast({ type: "success", body: "Push notification sent successfully" });
                // this.getClassesList();
            }, function (error) {
                _this.errorMessage(error);
            });
        }
    };
    LiveClassesComponent.prototype.cancel = function (id) {
        this.alertBox = false;
        this.cancelSessionId = id;
    };
    LiveClassesComponent.prototype.cancelSession = function () {
        var _this = this;
        this.service.cancelSchedule(this.cancelSessionId).subscribe(function (data) {
            _this.appC.popToast({ type: "success", body: "Live class session cancelled successfully" });
            _this.alertBox = true;
            _this.getClassesList();
        }, function (error) {
            _this.errorMessage(error);
        });
    };
    LiveClassesComponent.prototype.closeAlert = function () {
        this.alertBox = true;
        this.cancelSessionId = "";
    };
    LiveClassesComponent.prototype.reschedule = function (id) {
        this.rescheduleClass = true;
        this.openClassPopup = false;
        this.rescheduleclass.session_id = id;
    };
    LiveClassesComponent.prototype.closeReschedule = function () {
        this.rescheduleClass = false;
        this.openClassPopup = true;
    };
    LiveClassesComponent.prototype.getRescheduleTime = function () {
        var fromTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.rescheduledateFrom).format('YYYY-MM-DD') + " " + this.hourFromReschedule.split(' ')[0] + ":" + this.minuteFromReschedule + " " + this.hourFromReschedule.split(' ')[1];
        var fromDate = __WEBPACK_IMPORTED_MODULE_2_moment__().format('YYYY-MM-DD');
        var toTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.rescheduledateFrom).format('YYYY-MM-DD') + " " + this.hourToReschedule.split(' ')[0] + ":" + this.minuteToReschedule + " " + this.hourToReschedule.split(' ')[1];
        var fromTimeT = __WEBPACK_IMPORTED_MODULE_2_moment__(fromTime).format('YYYY-MM-DD hh:mm a');
        var toTimeT = __WEBPACK_IMPORTED_MODULE_2_moment__(toTime).format('YYYY-MM-DD hh:mm a');
        if (__WEBPACK_IMPORTED_MODULE_2_moment__(fromTimeT).diff(__WEBPACK_IMPORTED_MODULE_2_moment__(toTimeT), 'minutes') > 0) {
            this.appC.popToast({ type: "error", body: "From time cannot be greater than to time" });
            return false;
        }
        else if (this.hourFromReschedule == "" || this.hourToReschedule == "" || this.minuteFromReschedule == "" || this.minuteToReschedule == "") {
            this.appC.popToast({ type: "error", body: "All fields are required" });
            return false;
        }
        else if (__WEBPACK_IMPORTED_MODULE_2_moment__(fromTimeT).diff(__WEBPACK_IMPORTED_MODULE_2_moment__(), 'minutes') <= 20) {
            this.appC.popToast({ type: "error", body: "Class can be schedule 20 minutes from current time" });
            return false;
        }
        else if (fromTimeT == toTimeT) {
            this.appC.popToast({ type: "error", body: "From time and to time cannot be same" });
            return false;
        }
        else {
            this.isReschedule();
        }
    };
    LiveClassesComponent.prototype.isReschedule = function () {
        var _this = this;
        this.rescheduleclass.end_datetime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.rescheduledateFrom).format('YYYY-MM-DD') + " " + this.hourToReschedule.split(' ')[0] + ":" + this.minuteToReschedule + " " + this.hourToReschedule.split(' ')[1];
        this.rescheduleclass.start_datetime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.rescheduledateFrom).format('YYYY-MM-DD') + " " + this.hourFromReschedule.split(' ')[0] + ":" + this.minuteFromReschedule + " " + this.hourToReschedule.split(' ')[1];
        this.service.rescheduleClass(this.rescheduleclass).subscribe(function (data) {
            _this.appC.popToast({ type: "success", body: "Class rescheduled successfully" });
            _this.rescheduleClass = false;
            _this.openClassPopup = false;
            _this.rescheduleclass = {
                end_datetime: "",
                institution_id: _this.service.institute_id,
                session_id: "",
                start_datetime: ""
            };
            _this.rescheduledateFrom = __WEBPACK_IMPORTED_MODULE_2_moment__().format('YYYY-MM-DD');
            _this.minuteFromReschedule = "";
            _this.minuteToReschedule = "";
            _this.hourFromReschedule = "";
            _this.hourToReschedule = "";
        }, function (error) {
            _this.errorMessage(error);
        });
    };
    LiveClassesComponent.prototype.downloadFile = function (object) {
        var url = object.download_link;
        var hiddenDownload = document.getElementById('downloadFileClick');
        hiddenDownload.href = url;
        hiddenDownload.download = object.session_name;
        hiddenDownload.click();
    };
    // Live class integration with VDOCipher
    LiveClassesComponent.prototype.getVdocipherVideoOtp = function (obj) {
        var _this = this;
        this.viewDownloadPopup = false;
        var url = "/api/v1/instFileSystem/videoOTP";
        var data = {
            "videoID": obj.video_id,
            "institute_id": sessionStorage.getItem("institute_id"),
            "user_id": sessionStorage.getItem("userid")
        };
        this.tempVideoData = obj;
        this.JsonVars.isRippleLoad = true;
        this._http.postData(url, data).subscribe(function (response) {
            _this.JsonVars.isRippleLoad = false;
            if (response == null) {
                var obj_1 = {
                    "otp": "20160313versASE323ND0ylfz5VIJXZEVtOIgZO8guUTY5fTa92lZgixRcokG2xm",
                    "playbackInfo": "eyJ2aWRlb0lkIjoiNGQ1YjRiMzA5YjQ5NGUzYTgxOGU1ZDE3NDZiNzU2ODAifQ=="
                };
                _this.ShowVideo(obj_1.otp, obj_1.playbackInfo);
            }
            else {
                var obj_2 = {
                    "otp": response['otp'],
                    "playbackInfo": response['playbackInfo']
                };
                _this.ShowVideo(obj_2.otp, obj_2.playbackInfo);
            }
        }, function (err) {
            _this.JsonVars.isRippleLoad = false;
            _this.msgService.showErrorMessage('error', '', err.error.message);
        });
    };
    LiveClassesComponent.prototype.ShowVideo = function (otpString, playbackInfoString) {
        this.showVideo = false;
        var video = new window.VdoPlayer({
            otp: otpString,
            playbackInfo: playbackInfoString,
            theme: "9ae8bbe8dd964ddc9bdb932cca1cb59a",
            container: document.querySelector("#embedBox"),
        });
        this.videoObject = video;
        // video.addEventListener(`mpmlLoad`, (data) => {
        //   video.play();
        // });
        var container = document.querySelector('.embedBox');
    };
    LiveClassesComponent.prototype.stopVideo = function () {
        this.showVideo = true;
        if (this.videoObject) {
            this.videoObject.pause(); // removes video 
        }
    };
    LiveClassesComponent.prototype.viewdownload_links = function (obj) {
        this.viewDownloadPopup = true;
        this.download_links = obj;
    };
    LiveClassesComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-live-classes',
            template: __webpack_require__("./src/app/components/live-classes-module/live-classes/live-classes.component.html"),
            styles: [__webpack_require__("./src/app/components/live-classes-module/live-classes/live-classes.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__services_live_classes_live_class_service__["a" /* LiveClasses */],
            __WEBPACK_IMPORTED_MODULE_5__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_6____["f" /* HttpService */],
            __WEBPACK_IMPORTED_MODULE_6____["h" /* MessageShowService */]])
    ], LiveClassesComponent);
    return LiveClassesComponent;
}());



/***/ }),

/***/ "./src/app/services/live-classes/live-class.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LiveClasses; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var LiveClasses = /** @class */ (function () {
    function LiveClasses(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_2__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    LiveClasses.prototype.fetchStudents = function (obj) {
        var url = this.baseUrl + '/api/v1/courseMaster/onlineClass/fetch/users';
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.fetchTeachers = function () {
        var url = this.baseUrl + '/api/v1/teachers/all/' + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.fetchUsers = function () {
        var url = this.baseUrl + '/api/v1/profiles/custUsers/' + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.fetchBatches = function () {
        var url = this.baseUrl + '/api/v1/batches/all/' + this.institute_id + '?active=Y';
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.fetchMasters = function () {
        var url = this.baseUrl + '/api/v1/courseMaster/fetch/' + this.institute_id + '/all';
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.fetchCourses = function (obj) {
        var url = this.baseUrl + '/api/v1/courseMaster/fetch/' + this.institute_id + '/' + obj;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.getOnlineClasses = function (obj) {
        var url = this.baseUrl + '/api/v1/meeting_manager/create';
        return this.http.put(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.fetchOnlineClasses = function (obj) {
        var url = this.baseUrl + '/api/v1/meeting_manager/getMeeting/' + this.institute_id;
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.getOnlineClass = function (sessionId) {
        var url = this.baseUrl + '/api/v1/meeting_manager/getMeeting/' + this.institute_id + "/" + sessionId;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.updateOnlineClass = function (obj, sessionId) {
        var url = this.baseUrl + '/api/v1/meeting_manager/update/' + this.institute_id + "/" + sessionId;
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.pushNotification = function (sessionId, obj) {
        var url = this.baseUrl + "/api/v1/meeting_manager/sendPushNotification/" + sessionId;
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.smsNotification = function (sessionId, obj) {
        var url = this.baseUrl + "/api/v1/meeting_manager/sendSMSNotification/" + sessionId;
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.cancelSchedule = function (sessionId) {
        var url = this.baseUrl + "/api/v1/meeting_manager/delete/" + this.institute_id + "/" + sessionId;
        return this.http.delete(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses.prototype.rescheduleClass = function (obj) {
        var url = this.baseUrl + "/api/v1/meeting_manager/reschedule/" + this.institute_id + "/" + obj.session_id;
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    LiveClasses = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__angular_common_http__["a" /* HttpClient */],
            __WEBPACK_IMPORTED_MODULE_1__authenticator_service__["a" /* AuthenticatorService */]])
    ], LiveClasses);
    return LiveClasses;
}());



/***/ })

});
//# sourceMappingURL=live-classes.module.chunk.js.map