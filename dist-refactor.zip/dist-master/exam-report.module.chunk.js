webpackJsonp(["exam-report.module"],{

/***/ "./src/app/components/course-module/reports/new-exam-report/course-wise/course-wise.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<div class=\"middle-section clear-fix\">\r\n  <section class=\"middle-top clearFix bulk-header\">\r\n    <div>\r\n      <h1 class=\"pull-left\">\r\n        <a routerLink=\"/view/{{jsonFlag.type}}/reports\" style=\"padding:0px; \">\r\n          Report\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n        <a routerLink=\"/view/{{jsonFlag.type}}/reports/new-exam\" style=\"padding:0px; \">\r\n          Exam Report\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n        <span>Course Wise</span>\r\n      </h1>\r\n    </div>\r\n  </section>\r\n\r\n  <section>\r\n    <div class=\"name-container\">\r\n      <div class=\"name-item\">\r\n        <span style=\"font-weight: 600;\">{{masterCourse}} </span>\r\n      </div>\r\n      <div class=\"name-item\">\r\n        <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"course\" (ngModelChange)=\"getExamReport()\" *ngIf=\"!jsonFlag.isProfessional\">\r\n          <option value=\"-1\">Select Course</option>\r\n          <option [value]=\"course.course_id\" *ngFor=\"let course of coursesList\">{{course.course_name}}</option>\r\n        </select>\r\n        <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"course\" (ngModelChange)=\"getExamReport()\" *ngIf=\"jsonFlag.isProfessional\">\r\n          <option value=\"-1\">Select Subject</option>\r\n          <option [value]=\"subject.subject_id\" *ngFor=\"let subject of coursesList\">{{subject.subject_name}}</option>\r\n        </select>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <!-- Graph section -->\r\n  <!-- <section>\r\n    <div class=\"graph-outer-container\">\r\n      <div class=\"graph-item-container\" style=\"justify-content: center;padding-top: 120px;\">\r\n        <div #chartWrap id=\"chartWrap\">\r\n        </div>\r\n      </div>\r\n      <div class=\"graph-item-container\" *ngIf=\"!jsonFlag.isProfessional\" style=\"justify-content: center;padding-top: 120px;\">\r\n        <div #subjectWise id=\"subjectWise\">\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section> -->\r\n\r\n\r\n\r\n  <!-- report container -->\r\n  <section>\r\n    <div class=\"report-table-container\">\r\n      <div class=\"table-header-container\">\r\n        <div class=\"header-item small-item\">\r\n          <span>Exam Date</span>\r\n        </div>\r\n        <div class=\"header-item large-item\">\r\n          <span>Subject</span>\r\n        </div>\r\n        <div class=\"header-item small-item\">\r\n          <span>Total Students</span>\r\n        </div>\r\n        <div class=\"header-item small-item\">\r\n          <span>Absent</span>\r\n        </div>\r\n        <div class=\"header-item small-item\">\r\n          <span>Leave</span>\r\n        </div>\r\n        <div class=\"header-item small-item\">\r\n          <span>Avg. Marks</span>\r\n        </div>\r\n        <div class=\"header-item small-item\">\r\n          <span>Total Marks</span>\r\n        </div>\r\n        <div class=\"header-item small-item\">\r\n          <span>Status</span>\r\n        </div>\r\n        <div class=\"header-item small-item align-center\">\r\n          <span>Actions</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"table-outer-container\" style=\"max-height: 70vh;\">\r\n        <div class=\"table-value-container\" *ngFor=\"let report of courseWiseReportList\"\r\n        [ngClass]=\"{'border-completed-class': report.exam_status == 'Mks. Updated', 'border-class': report.exam_status != 'Mks. Updated'}\">\r\n          <div class=\"value-item small-item\">\r\n            <span>{{report.exam_date | date: 'dd-MMM-yyyy'}}</span>\r\n          </div>\r\n          <div class=\"value-item large-item\">\r\n            <span *ngIf=\"!jsonFlag.isProfessional\" title=\"{{report.subject_name}}\">{{ (report.subject_name.length > 40) ? (report.subject_name | slice:0:40) + '...' : report.subject_name }}</span>\r\n            <span *ngIf=\"jsonFlag.isProfessional\" title=\"{{report.batch_name}}\">{{ (report.batch_name.length > 40) ? (report.batch_name | slice:0:40) + '...' : report.batch_name }}</span>\r\n          </div>\r\n          <div class=\"value-item small-item\">\r\n            <span>{{report.total_student}}</span>\r\n          </div>\r\n          <div class=\"value-item small-item\">\r\n            <span>{{report.total_absent_student}}</span>\r\n          </div>\r\n          <div class=\"value-item small-item\">\r\n            <span>{{report.total_leave_student_count}}</span>\r\n            <!-- <span>-</span> -->\r\n          </div>\r\n          <div class=\"value-item small-item\">\r\n            <span>{{report.avarage_marks}}</span>\r\n          </div>\r\n\r\n          <div class=\"value-item small-item\">\r\n            <span>{{report.total_marks}}</span>\r\n            <!-- <span>-</span> -->\r\n          </div>\r\n          <div class=\"value-item small-item\">\r\n            <span [ngClass]=\"{'completed-class': report.exam_status == 'Mks. Updated',\r\n                              'pending-class': report.exam_status == 'Att. Pending',\r\n                              'cancelled-class': report.exam_status == 'Cancelled',\r\n                              'marks-pending-class': report.exam_status == 'Mks. pending',\r\n                              'upcoming-class': report.exam_status == 'Upcoming'}\">\r\n              {{report.exam_status}}\r\n            </span>\r\n          </div>\r\n          <div class=\"value-item small-item align-center\">\r\n            <button *ngIf=\"report.exam_status == 'Mks. Updated'\" type=\"button\" name=\"button\" class=\"view-result-btn\" routerLink='/view/{{jsonFlag.type}}/reports/new-exam/examWise/{{report.exam_schd_id}}'>View Result</button>\r\n            <span *ngIf=\"report.exam_status != 'Mks. Updated'\">-</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"table-value-container\" *ngIf=\"courseWiseReportList?.length == 0\" style=\"justify-content: center; font-size: 14px; font-weight: 600;\">\r\n          <span>No Result Found</span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/course-wise/course-wise.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  padding: 1%; }\n\n.middle-top {\n  width: 100%;\n  padding: 10px 0px;\n  border-bottom: 1px solid #ccc; }\n\n.name-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  font-size: 12px;\n  padding: 5px 0px; }\n\n.name-container .name-item {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    -webkit-box-pack: start;\n        -ms-flex-pack: start;\n            justify-content: flex-start;\n    width: 15%; }\n\n.name-container .name-item span {\n      margin-top: 10px; }\n\n.name-container .name-item .header-select-box {\n      border-radius: 4px;\n      border: 1px solid #d4d4d4;\n      margin: 5px 0px;\n      padding: 2px 0px;\n      width: 100%; }\n\n.graph-outer-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  width: 100%; }\n\n.graph-outer-container .graph-item-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    width: 48%;\n    -webkit-box-shadow: 0px 3px 15px rgba(0, 0, 0, 0.16);\n            box-shadow: 0px 3px 15px rgba(0, 0, 0, 0.16);\n    height: 240px;\n    border-radius: 4px;\n    padding: 10px;\n    text-align: center;\n    overflow-x: auto;\n    overflow-y: hidden; }\n\n.label {\n  z-index: 1 !important; }\n\n.highcharts-tooltip span {\n  background-color: white;\n  border: 1 px solid green;\n  opacity: 1;\n  z-index: 9999 !important; }\n\n.report-table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%;\n  -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.15);\n          box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.15);\n  border-radius: 4px;\n  font-size: 12px;\n  margin: 30px 0px; }\n\n.report-table-container .table-header-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    width: 100%;\n    padding: 10px;\n    padding-right: 20px;\n    background: #FAFAFA; }\n\n.report-table-container .table-header-container .header-item {\n      font-weight: 600;\n      text-align: center; }\n\n.report-table-container .table-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    width: 100%;\n    border-top: 1px solid #ccc;\n    min-height: 30vh;\n    max-height: 30vh;\n    overflow-y: auto; }\n\n.report-table-container .table-value-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    width: 100%;\n    padding: 10px; }\n\n.report-table-container .table-value-container .value-item {\n      font-weight: 400;\n      text-align: center; }\n\n.report-table-container .table-value-container .value-item .view-result-btn {\n        padding: 2px 5px;\n        background: #ffffff;\n        border-radius: 4px;\n        border: 1px solid #248CF5;\n        color: #248CF5; }\n\n.report-table-container .small-item {\n    width: 10%; }\n\n.report-table-container .medium-item {\n    width: 17%; }\n\n.report-table-container .large-item {\n    width: 20%; }\n\n.report-table-container .align-center {\n    text-align: center; }\n\n.report-table-container .border-completed-class {\n    border-left: 3px solid #00E172;\n    background: #F4FFF4; }\n\n.report-table-container .border-class {\n    border-left: 3px solid white; }\n\n.report-table-container .completed-class {\n    color: #00E172; }\n\n.report-table-container .pending-class {\n    color: gray; }\n\n.report-table-container .cancelled-class {\n    color: red; }\n\n.report-table-container .marks-pending-class {\n    color: blueviolet; }\n\n.report-table-container .upcoming-class {\n    color: #ff6c24; }\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/course-wise/course-wise.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CourseWiseComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_highcharts__ = __webpack_require__("./node_modules/highcharts/highcharts.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_highcharts___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_highcharts__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_course_services_class_schedule_service__ = __webpack_require__("./src/app/services/course-services/class-schedule.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_course_services_course_list_service__ = __webpack_require__("./src/app/services/course-services/course-list.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__services_report_services_exam_service__ = __webpack_require__("./src/app/services/report-services/exam.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var CourseWiseComponent = /** @class */ (function () {
    function CourseWiseComponent(router, route, examdata, courseList, auth, msgService, classService) {
        var _this = this;
        this.router = router;
        this.route = route;
        this.examdata = examdata;
        this.courseList = courseList;
        this.auth = auth;
        this.msgService = msgService;
        this.classService = classService;
        this.chartType = "1";
        this.jsonFlag = {
            isProfessional: false,
            institute_id: '',
            isRippleLoad: false,
            type: 'batch'
        };
        this.course = "-1";
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.jsonFlag.isProfessional = true;
                _this.jsonFlag.type = 'batch';
            }
            else {
                _this.jsonFlag.isProfessional = false;
                _this.jsonFlag.type = 'course';
            }
        });
        if (this.jsonFlag.isProfessional) {
            this.preRequiredDataForBatchModel();
        }
        else {
            this.masterCourse = sessionStorage.getItem('masterCourseForReport');
        }
        this.course_id = this.route.snapshot.paramMap.get('id');
        this.getCourseWiseReport();
        this.updateCoursesList();
    }
    CourseWiseComponent.prototype.ngOnInit = function () {
    };
    CourseWiseComponent.prototype.getCourseWiseReport = function () {
        var _this = this;
        this.jsonFlag.isRippleLoad = true;
        this.examdata.getCourseWiseReport(this.course_id).subscribe(function (res) {
            _this.jsonFlag.isRippleLoad = false;
            _this.courseWiseReportList = res;
            _this.generateChartData(res);
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    CourseWiseComponent.prototype.updateCoursesList = function () {
        var _this = this;
        this.courseList.getCourseListFromServer().subscribe(function (res) {
            _this.jsonFlag.isRippleLoad = false;
            _this.masterCourseList = res;
            for (var i = 0; i < _this.masterCourseList.length; i++) {
                if (_this.masterCourseList[i].master_course == _this.masterCourse) {
                    _this.coursesList = _this.masterCourseList[i].coursesList;
                    _this.course = _this.course_id;
                }
            }
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', 'Please check your internet connection or contact at support@proctur.com if the issue persist');
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    CourseWiseComponent.prototype.getExamReport = function () {
        this.course_id = this.course;
        this.getCourseWiseReport();
    };
    CourseWiseComponent.prototype.preRequiredDataForBatchModel = function () {
        var _this = this;
        var standard_id = sessionStorage.getItem('subejctIdForReport');
        this.masterCourse = sessionStorage.getItem('masterCourseForReport');
        this.jsonFlag.isRippleLoad = true;
        this.classService.getStandardSubjectList(standard_id, "-1", "Y").subscribe(function (res) {
            _this.coursesList = res.subjectLi;
            _this.jsonFlag.isRippleLoad = false;
        }, function (err) {
            _this.jsonFlag.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', 'Please check your internet connection or contact at support@proctur.com if the issue persist');
        });
    };
    CourseWiseComponent.prototype.generateChartData = function (res) {
        var dateMap = [];
        var feeMap = [];
        var totalMarksMap = [];
        var subjectWiseMarks = [];
        res.map(function (e) {
            dateMap.push(__WEBPACK_IMPORTED_MODULE_2_moment__(e.exam_date).format('DD-MMM'));
            feeMap.push(e.avarage_marks);
            totalMarksMap.push(e.total_marks);
            subjectWiseMarks.push(e.subject_wise_statatics);
        });
        this.createChart(dateMap, feeMap, totalMarksMap);
        this.subjectWiseChart(dateMap, feeMap, subjectWiseMarks);
    };
    CourseWiseComponent.prototype.createChart = function (d, f, t) {
        __WEBPACK_IMPORTED_MODULE_3_highcharts__["chart"]('chartWrap', {
            chart: {
                renderTo: 'container',
                type: 'spline',
                scrollablePlotArea: {
                    minWidth: 1800
                }
            },
            title: {
                text: ''
            },
            xAxis: {
                type: 'datetime',
                labels: {
                    overflow: 'justify'
                },
                // min: 10,
                // scrollbar: {
                //     enabled: true
                // },
                title: {
                    text: 'Date'
                },
                categories: d
            },
            yAxis: {
                title: {
                    text: 'Percentage (%)'
                },
                min: 0,
                max: 100
            },
            tooltip: {
                // shared: true,
                useHTML: true,
                formatter: function () {
                    var point = this.point;
                    var tool = '';
                    tool += 'Avg Marks: ' + this.y + ' marks';
                    for (var i = 0; i < t.length; i++) {
                        tool += '<br>' + 'Total Marks: ' + t[this.point.index] + ' marks';
                        break;
                    }
                    return tool;
                },
                positioner: function (labelWidth, labelHeight, point) {
                    var tooltipX = point.plotX + 0;
                    var tooltipY = point.plotY - 50;
                    return {
                        x: tooltipX,
                        y: tooltipY
                    };
                }
            },
            plotOptions: {
                area: {
                    lineWidth: 1,
                    marker: {
                        enabled: false,
                        states: {
                            hover: {
                                enabled: true,
                                radius: 2
                            }
                        }
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    }
                },
                series: {
                    pointWidth: 20
                }
            },
            series: [{
                    name: '',
                    type: "spline",
                    marker: {
                        radius: 5
                    },
                    showInLegend: false,
                    data: f
                }]
        });
    };
    CourseWiseComponent.prototype.subjectWiseChart = function (d, f, s) {
        var subjectA = [];
        var subjectB = [];
        var subjectC = [];
        var subjectD = [];
        var subjectName1;
        var subjectName2;
        var subjectName3;
        var subjectName4;
        for (var i = 0; i < s.length; i++) {
            if (s[i][0] != undefined) {
                subjectA.push(s[i][0].subject_level_total_marks);
                subjectName1 = s[i][0].subject_name;
            }
            if (s[i][1] != undefined) {
                subjectB.push(s[i][1].subject_level_total_marks);
                subjectName2 = s[i][1].subject_name;
            }
            if (s[i][2] != undefined) {
                subjectC.push(s[i][2].subject_level_total_marks);
                subjectName3 = s[i][2].subject_name;
            }
            if (s[i][3] != undefined) {
                subjectD.push(s[i][3].subject_level_total_marks);
                subjectName4 = s[i][3].subject_name;
            }
        }
        var subject_series = [];
        if (subjectA.length > 0) {
            var subject = {
                name: subjectName1,
                data: subjectA
            };
            subject_series.push(subject);
        }
        if (subjectB.length > 0) {
            var subject = {
                name: subjectName2,
                data: subjectB
            };
            subject_series.push(subject);
        }
        if (subjectC.length > 0) {
            var subject = {
                name: subjectName3,
                data: subjectC
            };
            subject_series.push(subject);
        }
        if (subjectD.length > 0) {
            var subject = {
                name: subjectName4,
                data: subjectD
            };
            subject_series.push(subject);
        }
        __WEBPACK_IMPORTED_MODULE_3_highcharts__["chart"]('subjectWise', {
            chart: {
                renderTo: 'container',
                type: 'column',
            },
            scrollablePlotArea: {
                minWidth: 1800
            },
            title: {
                text: ''
            },
            xAxis: {
                categories: d,
                crosshair: true,
                title: {
                    text: 'Date'
                },
                type: 'datetime',
                labels: {
                    overflow: 'justify'
                },
            },
            yAxis: {
                min: 0,
                visible: true,
                tickAmount: 5,
                title: {
                    text: 'Marks'
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    '<td style="padding:0"><b>{point.y:.1f} marks</b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                series: {
                    pointWidth: 20
                }
            },
            series: subject_series,
        });
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('chartWrap'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], CourseWiseComponent.prototype, "chartWrap", void 0);
    CourseWiseComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-course-wise',
            template: __webpack_require__("./src/app/components/course-module/reports/new-exam-report/course-wise/course-wise.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/reports/new-exam-report/course-wise/course-wise.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["ActivatedRoute"],
            __WEBPACK_IMPORTED_MODULE_8__services_report_services_exam_service__["a" /* ExamService */],
            __WEBPACK_IMPORTED_MODULE_7__services_course_services_course_list_service__["a" /* CourseListService */],
            __WEBPACK_IMPORTED_MODULE_6__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_5__services_message_show_service__["a" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_4__services_course_services_class_schedule_service__["a" /* ClassScheduleService */]])
    ], CourseWiseComponent);
    return CourseWiseComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/exam-report-home/exam-report-home.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n\r\n<div class=\"middle-section clear-fix\">\r\n  <section class=\"middle-top mb0 clearFix sms-header\">\r\n    <h2 class=\"pull-left\" style=\"font-weight: bold;\">\r\n      <a routerLink=\"/view/course\" *ngIf=\"!isProfessional\">\r\n        Course\r\n      </a>\r\n      <a routerLink=\"/view/batch\" *ngIf=\"isProfessional\">\r\n        Batch\r\n      </a>\r\n      <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n      <a routerLink=\"/view/{{jsonFlag.type}}/reports\" style=\"padding:0px; \">\r\n        Report\r\n        <!-- <i style=\"font-family: 'FontAwesome';font-size: 24px; cursor: pointer;\" class=\"fas fa-home\"></i> -->\r\n      </a>\r\n      <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n      Exam Report\r\n    </h2>\r\n    <aside class=\"pull-right\">\r\n    </aside>\r\n  </section>\r\n\r\n  <div class=\"main-heading-container\">\r\n    <span>Dashboard</span>\r\n  </div>\r\n\r\n  <section>\r\n    <div class=\"main-container\">\r\n      <div class=\"left-container\">\r\n        <div class=\"left-outer-container\" *ngIf=\"!jsonFlag.isProfessional\">\r\n          <div class=\"left-item\">\r\n            <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"mastercourse\" (ngModelChange)=\"getExamReportForMasterCourse()\">\r\n              <option value=\"-1\">Select Master Course</option>\r\n              <option [value]=\"masterCourse.master_course\" *ngFor=\"let masterCourse of masterCourseList\">{{masterCourse.master_course}}</option>\r\n            </select>\r\n          </div>\r\n          <div class=\"left-item\">\r\n            <div class=\"table-container\">\r\n              <div class=\"table-header-container\">\r\n                <div class=\"header-item medium-item\">\r\n                  <span>Course</span>\r\n                </div>\r\n                <div class=\"header-item large-item\">\r\n                  <span>Subject</span>\r\n                </div>\r\n                <div class=\"header-item small-item align-center\">\r\n                  <span>No of test</span>\r\n                </div>\r\n                <div class=\"header-item small-item align-center\">\r\n                  <span>Att. Updated</span>\r\n                </div>\r\n                <div class=\"header-item small-item align-center\">\r\n                  <span>Marks Updated</span>\r\n                </div>\r\n                <div class=\"header-item small-item align-center\">\r\n                  <span>Actions</span>\r\n                </div>\r\n              </div>\r\n              <div class=\"table-outer-container\">\r\n                <div class=\"table-value-container\" *ngFor=\"let report of masterCourseExamReportData\">\r\n                  <div class=\"value-item medium-item\">\r\n                    <span title=\"{{report.course_name}}\">{{ (report.course_name.length > 15) ? (report.course_name | slice:0:15) + '...' : report.course_name\r\n                      }}</span>\r\n                  </div>\r\n                  <div class=\"value-item large-item\">\r\n                    <span title=\"{{report.subject_name}}\">{{ (report.subject_name.length > 25) ? (report.subject_name | slice:0:25) + '...' : report.subject_name\r\n                      }}</span>\r\n                  </div>\r\n                  <div class=\"value-item small-item align-center\">\r\n                    <span>{{report.total_exam}}</span>\r\n                  </div>\r\n                  <div class=\"value-item small-item align-center\">\r\n                    <span>{{report.total_attandance_updated}}</span>\r\n                  </div>\r\n                  <div class=\"value-item small-item align-center\">\r\n                    <span>{{report.total_marks_updated}}</span>\r\n                  </div>\r\n                  <div class=\"value-item small-item align-center\">\r\n                    <button type=\"button\" name=\"button\" class=\"view-result-btn\" (click)=\"routeTo(report.course_id)\">View Result</button>\r\n                    <!-- routerLink='./courseWise/{{report.course_id}}' -->\r\n                  </div>\r\n                </div>\r\n                <div class=\"table-value-container\" *ngIf=\"masterCourseExamReportData?.length == 0\" style=\"justify-content: flex-start; font-size: 14px; font-weight: 600;\">\r\n                  <img src=\"./assets/images/blank.svg\" alt=\"illustration\">\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <br>\r\n        <div class=\"left-outer-container\">\r\n          <div class=\"left-item\">\r\n            <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"standard\" (ngModelChange)=\"getExamReportForStandard()\" id=\"standard\">\r\n              <option value=\"-1\">Select Standard</option>\r\n              <option [value]=\"standard.standard_id\" *ngFor=\"let standard of standardtList\">{{standard.standard_name}}</option>\r\n            </select>\r\n            <select class=\"header-select-box\" style=\"margin-left: 10px;\" name=\"\" [(ngModel)]=\"subject\" *ngIf=\"jsonFlag.isProfessional\"\r\n              (ngModelChange)=\"getExamReportForStandardAndSubject()\">\r\n              <option value=\"-1\">Select Subject</option>\r\n              <option [value]=\"subject.subject_id\" *ngFor=\"let subject of subjectList\">{{subject.subject_name}}</option>\r\n            </select>\r\n          </div>\r\n          <div class=\"left-item\">\r\n            <div class=\"table-container\">\r\n              <div class=\"table-header-container\">\r\n                <div class=\"header-item large-item1\">\r\n                  <span>Subject</span>\r\n                </div>\r\n                <div class=\"header-item small-item align-center\">\r\n                  <span>No of Student</span>\r\n                </div>\r\n                <div class=\"header-item small-item align-center\">\r\n                  <span>No of test</span>\r\n                </div>\r\n                <div class=\"header-item small-item align-center\">\r\n                  <span>Att. Updated</span>\r\n                </div>\r\n                <div class=\"header-item small-item align-center\">\r\n                  <span>Marks Updated</span>\r\n                </div>\r\n                <div class=\"header-item small-item align-center\">\r\n                  <span>Actions</span>\r\n                </div>\r\n              </div>\r\n              <div class=\"table-outer-container\">\r\n                <div class=\"table-value-container\" *ngFor=\"let report of standardExamReportData\">\r\n                  <div class=\"value-item large-item1\">\r\n                    <span *ngIf=\"!jsonFlag.isProfessional\" title=\"{{report.subject_name}}\">{{ (report.subject_name.length > 15) ? (report.subject_name | slice:0:15) + '...' : report.subject_name\r\n                      }}</span>\r\n                    <span *ngIf=\"jsonFlag.isProfessional\" title=\"{{report.batch_name}}\">{{ (report.batch_name.length > 15) ? (report.batch_name | slice:0:15) + '...' : report.batch_name }}</span>\r\n                  </div>\r\n                  <div class=\"value-item small-item align-center\">\r\n                    <span>{{report.total_student}}</span>\r\n                  </div>\r\n                  <div class=\"value-item small-item align-center\">\r\n                    <span>{{report.total_exam}}</span>\r\n                  </div>\r\n                  <div class=\"value-item small-item align-center\">\r\n                    <span>{{report.total_attandance_updated}}</span>\r\n                  </div>\r\n                  <div class=\"value-item small-item align-center\">\r\n                    <span>{{report.total_marks_updated}}</span>\r\n                  </div>\r\n                  <div class=\"value-item small-item align-center\">\r\n                    <button type=\"button\" name=\"button\" class=\"view-result-btn\" (click)=\"routeForStandard(report.subject_id)\" *ngIf=\"!jsonFlag.isProfessional\">View Result</button>\r\n                    <button type=\"button\" name=\"button\" class=\"view-result-btn\" (click)=\"routeTo(report.batch_id)\" *ngIf=\"jsonFlag.isProfessional\">View Result</button>\r\n                  </div>\r\n                </div>\r\n                <div class=\"table-value-container\" *ngIf=\"standardExamReportData?.length == 0\" style=\"justify-content: flex-start; font-size: 14px; font-weight: 600;\">\r\n                  <img src=\"./assets/images/blank.svg\" alt=\"illustration\">\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n      <div class=\"right-container\">\r\n        <div class=\"right-item\">\r\n          <input type=\"text\" placeholder=\"Choose filter from dropdown\" id=\"addDate\" class=\"filter-input widgetDatepicker bsDatepicker\"\r\n            name=\"addDate\" [(ngModel)]=\"addDate\" (ngModelChange)=\"addNewDate($event)\" readonly=\"true\" bsDaterangepicker>\r\n          <i class=\"fa fa-calendar\" style=\"cursor: pointer;color: #1283f4;\" (click)=\"openCalendar('addDate')\"></i>\r\n        </div>\r\n        <div class=\"right-item\">\r\n          <div class=\"table-container\">\r\n            <div class=\"table-header-container\">\r\n              <div class=\"header-item custom-item\">\r\n                <span>Exam Date</span>\r\n              </div>\r\n              <div class=\"header-item custom-item\">\r\n                <span>Mastercourse</span>\r\n              </div>\r\n              <div class=\"header-item custom-item\">\r\n                <span>Course</span>\r\n              </div>\r\n              <div class=\"header-item custom-item\">\r\n                <span>Status</span>\r\n              </div>\r\n              <div class=\"header-item custom-item align-center\">\r\n                <span>Actions</span>\r\n              </div>\r\n            </div>\r\n            <div class=\"table-outer-container\" style=\"min-height: 73vh; max-height: 73vh;\">\r\n              <div class=\"table-value-container\" *ngFor=\"let report of weeklyExamReportData\" [ngClass]=\"{'border-completed-class': report.exam_status == 'Mks. Updated', 'border-class': report.exam_status != 'Mks. Updated'}\">\r\n                <div class=\"value-item custom-item\">\r\n                  <span>{{report?.exam_date | date: 'dd-MMM-yyyy'}}</span>\r\n                </div>\r\n                <div class=\"value-item custom-item\">\r\n                  <span title=\"{{report.master_course_name}}\">{{ (report?.master_course_name.length > 12) ? (report.master_course_name | slice:0:12) + '...' : report.master_course_name\r\n                    }}</span>\r\n                </div>\r\n                <div class=\"value-item custom-item\">\r\n                  <span title=\"{{report.course_name}}\">{{ (report?.course_name.length > 12) ? (report.course_name | slice:0:12) + '...' : report.course_name }}</span>\r\n                </div>\r\n                <div class=\"value-item custom-item\">\r\n                  <span [ngClass]=\"{'completed-class': report.exam_status == 'Mks. Updated',\r\n                                    'pending-class': report.exam_status == 'Att. Pending',\r\n                                    'cancelled-class': report.exam_status == 'Cancelled',\r\n                                    'marks-pending-class': report.exam_status == 'Mks. pending'}\">\r\n                    {{report?.exam_status}}\r\n                  </span>\r\n                </div>\r\n                <div class=\"value-item custom-item align-center\" *ngIf=\"report.exam_status == 'Mks. Updated'\">\r\n                  <button type=\"button\" name=\"button\" class=\"view-result-btn\" routerLink='/view/{{jsonFlag.type}}/reports/new-exam/examWise/{{report.exam_schd_id}}'>View Result</button>\r\n                </div>\r\n              </div>\r\n              <div class=\"table-value-container\" *ngIf=\"weeklyExamReportData?.length == 0\" style=\"justify-content: center; font-weight: 600;\">\r\n                <span>No schedule found</span>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/exam-report-home/exam-report-home.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  padding: 1%; }\n\n.main-heading-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  font-size: 14px;\n  font-weight: 600;\n  width: 100%;\n  padding: 10px;\n  border-bottom: 1px solid #ccc; }\n\n.main-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  width: 100%;\n  font-size: 12px;\n  margin-top: 10px; }\n\n.left-container {\n  width: 58%; }\n\n.left-container .left-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column; }\n\n.left-container .left-item {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: start;\n        -ms-flex-pack: start;\n            justify-content: flex-start; }\n\n.left-container .left-item .header-select-box {\n      border-radius: 4px;\n      border: 1px solid #d4d4d4;\n      margin: 5px 0px;\n      padding: 2px 0px;\n      width: 25%; }\n\n.right-container {\n  width: 40%; }\n\n.right-container .right-item {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: start;\n        -ms-flex-pack: start;\n            justify-content: flex-start;\n    position: relative; }\n\n.right-container .right-item .filter-input {\n      margin: 5px 0px;\n      border-radius: 4px;\n      border: 1px solid #d4d4d4;\n      padding: 2px 3px;\n      width: 40%;\n      height: 30px; }\n\n.right-container .right-item i {\n      position: absolute;\n      top: 15px;\n      left: 36%; }\n\n.table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%;\n  -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.15);\n          box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.15);\n  border-radius: 4px;\n  font-size: 12px;\n  margin-top: 5px;\n  border-top: 1px solid #ccc; }\n\n.table-container .table-header-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    width: 100%;\n    padding: 10px;\n    background: #FAFAFA; }\n\n.table-container .table-header-container .header-item {\n      font-weight: 600; }\n\n.table-container .table-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    width: 100%;\n    border-top: 1px solid #ccc;\n    min-height: 30vh;\n    max-height: 30vh;\n    overflow-y: auto; }\n\n.table-container .table-value-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    width: 100%;\n    padding: 10px; }\n\n.table-container .table-value-container .value-item {\n      font-weight: 400; }\n\n.table-container .table-value-container .value-item .view-result-btn {\n        padding: 2px 5px;\n        background: #ffffff;\n        border-radius: 4px;\n        border: 1px solid #248CF5;\n        color: #248CF5; }\n\n.table-container .table-value-container .completed-class {\n      color: #00E172; }\n\n.table-container .table-value-container .pending-class {\n      color: gray; }\n\n.table-container .table-value-container .cancelled-class {\n      color: red; }\n\n.table-container .table-value-container .marks-pending-class {\n      color: blueviolet; }\n\n.table-container .small-item {\n    width: 15%; }\n\n.table-container .medium-item {\n    width: 17%; }\n\n.table-container .large-item {\n    width: 23%; }\n\n.table-container .large-item1 {\n    width: 40%; }\n\n.table-container .custom-item {\n    width: 20%; }\n\n.table-container .align-center {\n    text-align: center; }\n\n.table-container .border-completed-class {\n    border-left: 3px solid #00E172;\n    background: #F4FFF4; }\n\n.table-container .border-class {\n    border-left: 3px solid white; }\n\n.table-value-container img {\n  max-width: 25%;\n  margin-left: 10%;\n  height: auto; }\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/exam-report-home/exam-report-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ExamReportHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_course_services_class_schedule_service__ = __webpack_require__("./src/app/services/course-services/class-schedule.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_course_services_course_list_service__ = __webpack_require__("./src/app/services/course-services/course-list.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_report_services_exam_service__ = __webpack_require__("./src/app/services/report-services/exam.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var ExamReportHomeComponent = /** @class */ (function () {
    function ExamReportHomeComponent(router, examdata, courseList, auth, msgService, classService) {
        this.router = router;
        this.examdata = examdata;
        this.courseList = courseList;
        this.auth = auth;
        this.msgService = msgService;
        this.classService = classService;
        this.jsonFlag = {
            isProfessional: false,
            institute_id: '',
            isRippleLoad: false,
            type: 'batch'
        };
        this.reportJSON = {
            master_course_name: "",
            standard_id: "",
            subject_id: "",
            from_date: __WEBPACK_IMPORTED_MODULE_2_moment__().isoWeekday("Monday").format("YYYY-MM-DD"),
            to_date: __WEBPACK_IMPORTED_MODULE_2_moment__().weekday(7).format("YYYY-MM-DD")
        };
        this.weeklyExamReportData = [];
        this.masterCourseExamReportData = [];
        this.standardExamReportData = [];
        this.mastercourse = "-1";
        this.standard = "-1";
        this.subject = "-1";
        this.addDate = __WEBPACK_IMPORTED_MODULE_2_moment__().isoWeekday("Monday").format("DD MMM YYYY") + " - " + __WEBPACK_IMPORTED_MODULE_2_moment__().weekday(7).format("DD MMM YYYY");
    }
    ExamReportHomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.jsonFlag.isProfessional = true;
                _this.jsonFlag.type = 'batch';
            }
            else {
                _this.jsonFlag.isProfessional = false;
                _this.jsonFlag.type = 'course';
            }
        });
        this.addDate = this.reportJSON.from_date + " - " + this.reportJSON.to_date; // this will fetch exam report for current week
        this.jsonFlag.institute_id = sessionStorage.getItem('institute_id');
        this.getPreRequiredData();
        this.getExamReport();
    };
    ExamReportHomeComponent.prototype.getExamReport = function () {
        var _this = this;
        this.examReport = [];
        this.jsonFlag.isRippleLoad = true;
        this.examdata.getAllExamReport(this.reportJSON).subscribe(function (res) {
            _this.jsonFlag.isRippleLoad = false;
            _this.examReport = res;
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.info, 'Info', err.error.message);
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    ExamReportHomeComponent.prototype.getPreRequiredData = function () {
        var _this = this;
        this.jsonFlag.isRippleLoad = true;
        this.courseList.getCourseListFromServer().subscribe(function (res) {
            _this.jsonFlag.isRippleLoad = false;
            _this.masterCourseList = res;
            // this.mastercourse = "12th commer";
            var master = sessionStorage.getItem('masterCourseForReport');
            if (master != "" && master != null && master != undefined) {
                _this.mastercourse = master;
                sessionStorage.setItem('masterCourseForReport', '');
                _this.getExamReportForMasterCourse();
            }
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', 'Please check your internet connection or contact at support@proctur.com if the issue persist');
            _this.jsonFlag.isRippleLoad = false;
        });
        this.jsonFlag.isRippleLoad = true;
        this.courseList.getStandardListFromServer().subscribe(function (res) {
            _this.jsonFlag.isRippleLoad = false;
            _this.standardtList = res;
            var stand = sessionStorage.getItem('standaradForReport');
            if (stand != "" && stand != null && stand != undefined) {
                _this.standard = stand;
                sessionStorage.setItem('standaradForReport', '');
                _this.getExamReportForStandard();
            }
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', 'Please check your internet connection or contact at support@proctur.com if the issue persist');
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    ExamReportHomeComponent.prototype.addNewDate = function (e) {
        var _this = this;
        var fromDate = __WEBPACK_IMPORTED_MODULE_2_moment__(e[0]).format("YYYY-MM-DD");
        var toDate = __WEBPACK_IMPORTED_MODULE_2_moment__(e[1]).format("YYYY-MM-DD");
        var result = __WEBPACK_IMPORTED_MODULE_2_moment__(toDate).diff(fromDate, 'days');
        if (result <= 30) {
            this.reportJSON.from_date = __WEBPACK_IMPORTED_MODULE_2_moment__(e[0]).format("YYYY-MM-DD");
            this.reportJSON.to_date = __WEBPACK_IMPORTED_MODULE_2_moment__(e[1]).format("YYYY-MM-DD");
            this.examReport = [];
            this.weeklyExamReportData = [];
            this.jsonFlag.isRippleLoad = true;
            this.examdata.getAllExamReport(this.reportJSON).subscribe(function (res) {
                _this.jsonFlag.isRippleLoad = false;
                _this.examReport = res;
                _this.weeklyExamReportData = _this.examReport;
            }, function (err) {
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.info, 'Info', err.error.message);
                _this.jsonFlag.isRippleLoad = false;
            });
        }
        else {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Date difference should not more than a month');
        }
    };
    ExamReportHomeComponent.prototype.getExamReportForMasterCourse = function () {
        var _this = this;
        this.clearJSON();
        this.reportJSON.master_course_name = this.mastercourse;
        this.examReport = [];
        this.masterCourseExamReportData = [];
        this.jsonFlag.isRippleLoad = true;
        this.examdata.getAllExamReport(this.reportJSON).subscribe(function (res) {
            _this.jsonFlag.isRippleLoad = false;
            _this.examReport = res;
            _this.masterCourseExamReportData = _this.examReport;
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    ExamReportHomeComponent.prototype.getExamReportForStandard = function () {
        var _this = this;
        if (!this.jsonFlag.isProfessional) {
            this.clearJSON();
            this.reportJSON.standard_id = this.standard;
            this.examReport = [];
            this.jsonFlag.isRippleLoad = true;
            this.examdata.getAllExamReport(this.reportJSON).subscribe(function (res) {
                _this.jsonFlag.isRippleLoad = false;
                _this.examReport = res;
                _this.standardExamReportData = _this.examReport;
            }, function (err) {
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
                _this.jsonFlag.isRippleLoad = false;
            });
        }
        else {
            // Get Subject List for Batch Model
            this.jsonFlag.isRippleLoad = true;
            this.classService.getStandardSubjectList(this.standard, "-1", "Y").subscribe(function (res) {
                _this.jsonFlag.isRippleLoad = false;
                _this.subjectList = res.subjectLi;
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err);
            });
        }
    };
    ExamReportHomeComponent.prototype.getExamReportForStandardAndSubject = function () {
        var _this = this;
        this.clearJSON();
        this.reportJSON.subject_id = this.subject;
        this.examReport = [];
        this.jsonFlag.isRippleLoad = true;
        this.examdata.getAllExamReport(this.reportJSON).subscribe(function (res) {
            _this.jsonFlag.isRippleLoad = false;
            _this.examReport = res;
            _this.standardExamReportData = _this.examReport;
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    ExamReportHomeComponent.prototype.clearJSON = function () {
        this.reportJSON.master_course_name = "";
        this.reportJSON.standard_id = "";
        this.reportJSON.subject_id = "";
        this.reportJSON.from_date = "";
        this.reportJSON.to_date = "";
    };
    ExamReportHomeComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    ExamReportHomeComponent.prototype.routeTo = function (course_id) {
        if (this.jsonFlag.isProfessional) {
            var standard_id = document.getElementById("standard").value;
            for (var i = 0; i < this.standardtList.length; i++) {
                if (this.standardtList[i].standard_id == standard_id) {
                    sessionStorage.setItem('masterCourseForReport', this.standardtList[i].standard_name);
                    sessionStorage.setItem('subejctIdForReport', this.standardtList[i].standard_id);
                }
            }
        }
        else {
            sessionStorage.setItem('masterCourseForReport', this.mastercourse);
        }
        this.router.navigate(['/view/' + this.jsonFlag.type + '/reports/new-exam/courseWise/' + course_id]);
    };
    ExamReportHomeComponent.prototype.routeForStandard = function (subject_id) {
        sessionStorage.setItem('standaradForReport', this.standard);
        this.router.navigate(['/view/' + this.jsonFlag.type + '/reports/new-exam/teacherWise/' + subject_id]);
    };
    ExamReportHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-exam-report-home',
            template: __webpack_require__("./src/app/components/course-module/reports/new-exam-report/exam-report-home/exam-report-home.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/reports/new-exam-report/exam-report-home/exam-report-home.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_7__services_report_services_exam_service__["a" /* ExamService */],
            __WEBPACK_IMPORTED_MODULE_6__services_course_services_course_list_service__["a" /* CourseListService */],
            __WEBPACK_IMPORTED_MODULE_5__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__services_message_show_service__["a" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_3__services_course_services_class_schedule_service__["a" /* ClassScheduleService */]])
    ], ExamReportHomeComponent);
    return ExamReportHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/exam-report-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ExamReportRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__new_exam_report_component__ = __webpack_require__("./src/app/components/course-module/reports/new-exam-report/new-exam-report.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__course_wise_course_wise_component__ = __webpack_require__("./src/app/components/course-module/reports/new-exam-report/course-wise/course-wise.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__exam_wise_exam_wise_component__ = __webpack_require__("./src/app/components/course-module/reports/new-exam-report/exam-wise/exam-wise.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__teacher_performance_teacher_performance_component__ = __webpack_require__("./src/app/components/course-module/reports/new-exam-report/teacher-performance/teacher-performance.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__exam_report_home_exam_report_home_component__ = __webpack_require__("./src/app/components/course-module/reports/new-exam-report/exam-report-home/exam-report-home.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var ExamReportRoutingModule = /** @class */ (function () {
    function ExamReportRoutingModule() {
    }
    ExamReportRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__new_exam_report_component__["a" /* NewExamReportComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                component: __WEBPACK_IMPORTED_MODULE_6__exam_report_home_exam_report_home_component__["a" /* ExamReportHomeComponent */]
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_6__exam_report_home_exam_report_home_component__["a" /* ExamReportHomeComponent */]
                            },
                            {
                                path: 'exam',
                                component: __WEBPACK_IMPORTED_MODULE_6__exam_report_home_exam_report_home_component__["a" /* ExamReportHomeComponent */]
                            },
                            {
                                path: 'courseWise/:id',
                                component: __WEBPACK_IMPORTED_MODULE_3__course_wise_course_wise_component__["a" /* CourseWiseComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'examWise/:id',
                                component: __WEBPACK_IMPORTED_MODULE_4__exam_wise_exam_wise_component__["a" /* ExamWiseComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'teacherWise/:id',
                                component: __WEBPACK_IMPORTED_MODULE_5__teacher_performance_teacher_performance_component__["a" /* TeacherPerformanceComponent */],
                                pathMatch: 'prefix'
                            },
                        ]
                    }
                ])],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], ExamReportRoutingModule);
    return ExamReportRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/exam-report.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExamReportModule", function() { return ExamReportModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__new_exam_report_component__ = __webpack_require__("./src/app/components/course-module/reports/new-exam-report/new-exam-report.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__course_wise_course_wise_component__ = __webpack_require__("./src/app/components/course-module/reports/new-exam-report/course-wise/course-wise.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__exam_wise_exam_wise_component__ = __webpack_require__("./src/app/components/course-module/reports/new-exam-report/exam-wise/exam-wise.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__teacher_performance_teacher_performance_component__ = __webpack_require__("./src/app/components/course-module/reports/new-exam-report/teacher-performance/teacher-performance.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__exam_report_routing_module__ = __webpack_require__("./src/app/components/course-module/reports/new-exam-report/exam-report-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_primeng_components_common_messageservice__ = __webpack_require__("./node_modules/primeng/components/common/messageservice.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_primeng_components_common_messageservice___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_primeng_components_common_messageservice__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10_primeng_primeng__ = __webpack_require__("./node_modules/primeng/primeng.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10_primeng_primeng___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10_primeng_primeng__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__exam_report_home_exam_report_home_component__ = __webpack_require__("./src/app/components/course-module/reports/new-exam-report/exam-report-home/exam-report-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__services_course_services_class_schedule_service__ = __webpack_require__("./src/app/services/course-services/class-schedule.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


/* Modules */












var ExamReportModule = /** @class */ (function () {
    function ExamReportModule() {
    }
    ExamReportModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_6__exam_report_routing_module__["a" /* ExamReportRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_9__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_9__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_6__exam_report_routing_module__["a" /* ExamReportRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_10_primeng_primeng__["SplitButtonModule"],
                __WEBPACK_IMPORTED_MODULE_10_primeng_primeng__["MenuModule"],
                __WEBPACK_IMPORTED_MODULE_12__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome__["c" /* TooltipModule */].forRoot(),
                __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_8_ngx_bootstrap_custome__["b" /* TimepickerModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_2__new_exam_report_component__["a" /* NewExamReportComponent */],
                __WEBPACK_IMPORTED_MODULE_3__course_wise_course_wise_component__["a" /* CourseWiseComponent */],
                __WEBPACK_IMPORTED_MODULE_4__exam_wise_exam_wise_component__["a" /* ExamWiseComponent */],
                __WEBPACK_IMPORTED_MODULE_5__teacher_performance_teacher_performance_component__["a" /* TeacherPerformanceComponent */],
                __WEBPACK_IMPORTED_MODULE_11__exam_report_home_exam_report_home_component__["a" /* ExamReportHomeComponent */]
            ],
            entryComponents: [
                __WEBPACK_IMPORTED_MODULE_11__exam_report_home_exam_report_home_component__["a" /* ExamReportHomeComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_7_primeng_components_common_messageservice__["MessageService"],
                __WEBPACK_IMPORTED_MODULE_13__services_course_services_class_schedule_service__["a" /* ClassScheduleService */]
            ],
            exports: []
        })
    ], ExamReportModule);
    return ExamReportModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/exam-wise/exam-wise.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<div class=\"middle-section clear-fix\">\r\n  <!-- <section class=\"middle-top clearFix bulk-header\">\r\n    <div>\r\n      <h1 class=\"pull-left\">\r\n        <a routerLink=\"/view/reports/home\" style=\"padding:0px; \">\r\n          Report\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n        <a routerLink=\"/view/reports/exam\" style=\"padding:0px; \">\r\n          Exam Report\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n        <span>Exam Wise</span>\r\n      </h1>\r\n      <a class=\"fa fa-download\" style=\"font-size: 17px; color: #0084f6; margin-right: 3%;cursor: pointer;float: right;\" title=\"Download Report\" (click)=\"downloadReportCard();\"\r\n      id=\"downloadFile\" ></a>\r\n      <a id=\"downloadFileClick\" class=\"hide\"></a>\r\n    </div>\r\n  </section> -->\r\n  <section class=\"middle-top mb0 clearFix sms-header\">\r\n    <h2 class=\"pull-left\" style=\"font-weight: bold;\">\r\n            <a routerLink=\"/view/course\" *ngIf=\"!isProfessional\">\r\n                Course\r\n              </a>\r\n              <a routerLink=\"/view/batch\" *ngIf=\"isProfessional\">\r\n                Batch\r\n              </a>\r\n    <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n        <a routerLink=\"/view/{{jsonFlag.type}}/reports\" style=\"padding:0px; \">\r\n            Report\r\n            <!-- <i style=\"font-family: 'FontAwesome';font-size: 24px; cursor: pointer;\" class=\"fas fa-home\"></i> -->\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n        Exam Report\r\n    </h2>\r\n    <a class=\"fa fa-download\" style=\"font-size: 17px; color: #0084f6; margin-right: 3%;cursor: pointer;float: right;\" title=\"Download Report\" (click)=\"downloadReportCard();\"\r\n    id=\"downloadFile\" ></a>\r\n    <a id=\"downloadFileClick\" class=\"hide\"></a>\r\n</section>\r\n\r\n<!-- Course and Subject wise containers -->\r\n  <section>\r\n    <div class=\"section-wise-container\">\r\n      <div class=\"course-wise-container\">\r\n        <div class=\"section-title\">\r\n          <span>Course-wise</span>\r\n        </div>\r\n        <div class=\"section-info-container\">\r\n          <div class=\"course-info\">\r\n            <div class=\"course-info-item course\">\r\n              <div class=\"course-info-title-container\">\r\n                <span>Course</span>\r\n              </div>\r\n              <div class=\"course-info-details\" *ngIf=\"!examSchdlType\">\r\n                <span>{{exam_wise_data?.course_name}}</span>\r\n              </div>\r\n              <div class=\"course-info-details\" *ngIf=\"examSchdlType\">\r\n                <span>{{exam_wise_data?.batch_name}}</span>\r\n              </div>\r\n            </div>\r\n            <div class=\"course-info-item exam-date\">\r\n              <div class=\"course-info-title-container\">\r\n                <span>Exam Date</span>\r\n              </div>\r\n              <div class=\"course-info-details\">\r\n                <span>{{exam_wise_data?.exam_date | date: 'dd-MMM-yyyy' }}</span>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"marks-info-container\">\r\n            <div class=\"marks-info-item\">\r\n              <span class=\"marks-title\">Total Marks</span>\r\n              <span class=\"marks\">{{exam_wise_data?.total_marks}}</span>\r\n            </div>\r\n            <!-- <div class=\"marks-info-item\">\r\n              <span class=\"marks-title\">Min. Marks</span>\r\n              <span class=\"marks\">100</span>\r\n            </div> -->\r\n            <!-- <div class=\"marks-info-item\" *ngIf=\"is_exam_grad_feature != 1\">\r\n              <span class=\"marks-title\">Avg. Marks</span>\r\n              <span class=\"marks\">{{exam_wise_data?.average_marks}}</span>\r\n            </div> -->\r\n            <div class=\"marks-info-item\">\r\n              <span class=\"marks-title\">Total Students</span>\r\n              <span class=\"marks\">{{exam_wise_data?.total_student}}</span>\r\n            </div>\r\n          </div>\r\n          <div class=\"ranking-info-container\">\r\n            <div class=\"marks-container highest-border\" *ngIf=\"is_exam_grad_feature != 1\">\r\n              <div class=\"marks-title highest\">\r\n                <span>Highest Marks</span>\r\n              </div>\r\n              <div class=\"marks-info highest-border\">\r\n                <span>{{exam_wise_data?.highest_marks}}</span>\r\n              </div>\r\n            </div>\r\n            <div class=\"marks-container lowest-border\" *ngIf=\"is_exam_grad_feature != 1\">\r\n              <div class=\"marks-title lowest\">\r\n                <span>Lowest Marks</span>\r\n              </div>\r\n              <div class=\"marks-info lowest-border\">\r\n                <span>{{exam_wise_data?.lowest_marks}}</span>\r\n              </div>\r\n            </div>\r\n            <div class=\"marks-container topper-border\">\r\n              <div class=\"marks-title topper\">\r\n                <span>Avg. Marks</span>\r\n              </div>\r\n              <div class=\"marks-info topper-border\">\r\n                <span>{{exam_wise_data?.average_marks}}</span>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"subject-wise-container\" *ngIf=\"!jsonFlag.isProfessional && !examSchdlType\">\r\n        <div class=\"section-title\">\r\n          <span>Subject-wise</span>\r\n        </div>\r\n        <div class=\"subject-wise-table-container\">\r\n          <div class=\"heading-container\">\r\n            <div class=\"heading-item\">\r\n              <span>Subjects</span>\r\n            </div>\r\n            <div class=\"heading-item\" style=\"text-align:right; margin-right: 10px;\">\r\n              <span>Total Marks</span>\r\n            </div>\r\n          </div>\r\n          <div class=\"value-outer-container\">\r\n            <div class=\"value-container\" *ngFor=\"let subject of subjectWiseData\">\r\n              <div class=\"value-item\">\r\n                <span>{{subject.subject_name}}</span>\r\n              </div>\r\n              <div class=\"value-item\" style=\"text-align:right; margin-right: 35px;\">\r\n                <span>{{subject.subject_level_total_marks}}</span>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"total-container\">\r\n            <div class=\"total-item\">\r\n              <span>Total Marks</span>\r\n            </div>\r\n            <div class=\"total-item\" style=\"text-align:right; margin-right: 35px;\">\r\n              <span>{{exam_wise_data?.total_marks}}</span>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n<!-- Student Wise container -->\r\n  <section>\r\n    <div class=\"student-wise-container\">\r\n      <div class=\"section-title\">\r\n        <span>Student-wise</span>\r\n      </div>\r\n      <div class=\"student-wise-table-container\">\r\n        <div class=\"student-wise-heading-container\">\r\n          <div class=\"student-wise-heading-item small-item\">\r\n            <span>#ID</span>\r\n          </div>\r\n          <div class=\"student-wise-heading-item medium-item\">\r\n            <span>Name</span>\r\n          </div>\r\n          <div class=\"student-wise-heading-item small-item\">\r\n            <span>Contact No.</span>\r\n          </div>\r\n          <div class=\"student-wise-heading-item very-small-item\" style=\"text-align:center;\">\r\n            <span>Attendance</span>\r\n          </div>\r\n          <div class=\"subject-wise-container\">\r\n            <div class=\"subject-wise-heading-item\" *ngFor=\"let subject of subjectWiseData\">\r\n              <span>{{subject.subject_name}}</span>\r\n            </div>\r\n          </div>\r\n          <div class=\"student-wise-heading-item small-item\" style=\"text-align:center;\" *ngIf=\"is_exam_grad_feature != 1\">\r\n            <span>Obtained Marks</span>\r\n          </div>\r\n          <div class=\"student-wise-heading-item small-item\" style=\"text-align:center;\" *ngIf=\"is_exam_grad_feature != 1\">\r\n            <span>Rank</span>\r\n          </div>\r\n          <!-- <div class=\"student-wise-heading-item small-item\">\r\n            <span>Status</span>\r\n          </div> -->\r\n        </div>\r\n        <div class=\"student-wise-value-outer-container\">\r\n          <div class=\"student-wise-value-container\" *ngFor=\"let student of studentWiseData\">\r\n            <div class=\"student-wise-value-item small-item\">\r\n              <span>{{student.student_display_id}}</span>\r\n            </div>\r\n            <div class=\"student-wise-value-item medium-item\">\r\n              <span>{{student.student_name}}</span>\r\n            </div>\r\n            <div class=\"student-wise-value-item small-item\">\r\n              <span>{{student.phone}}</span>\r\n            </div>\r\n            <div class=\"student-wise-value-item very-small-item\" style=\"text-align:center;\">\r\n              <span>{{student.attendance_type}}</span>\r\n            </div>\r\n            <div class=\"subject-wise-container\" *ngIf=\"is_exam_grad_feature != 1\">\r\n              <div class=\"subject-wise-value-item\" *ngFor=\"let subject of student.subjectWise_marks_obtained\">\r\n                <span>{{subject.subject_level_marks_obtained}}</span>\r\n              </div>\r\n            </div>\r\n            <div class=\"subject-wise-container\" *ngIf=\"is_exam_grad_feature == 1\">\r\n              <div class=\"subject-wise-value-item\">\r\n                <span *ngIf=\"student.grade != null\">{{student.grade}}</span>\r\n                <span *ngIf=\"student.grade == null\">-</span>\r\n              </div>\r\n            </div>\r\n            <div class=\"student-wise-value-item small-item\" style=\"text-align:center;\" *ngIf=\"is_exam_grad_feature != 1\">\r\n              <span *ngIf=\"student.attendance_type == 'P'\">{{student.total_marks_obtained}}</span>\r\n              <span *ngIf=\"student.attendance_type != 'P'\">-</span>\r\n            </div>\r\n            <div class=\"student-wise-value-item small-item\" style=\"text-align:center;\" *ngIf=\"is_exam_grad_feature != 1\">\r\n              <span *ngIf=\"student.attendance_type == 'P'\">\r\n                {{student.rank}}\r\n              </span>\r\n              <span *ngIf=\"student.rank == 1 && student.attendance_type == 'P'\" style=\"position: absolute; padding-left: 10px;color: #FFBF00;\">\r\n                <i class=\"fa fa-trophy\" aria-hidden=\"true\"></i>\r\n              </span>\r\n              <span *ngIf=\"student.attendance_type != 'P'\">-</span>\r\n            </div>\r\n          </div>\r\n          <div class=\"student-wise-value-container\" *ngIf=\"studentWiseData.length == 0\" style=\"justify-content: center;font-weight: 600;\">\r\n            <span>No Student Found</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/exam-wise/exam-wise.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  padding: 1%; }\n\n.middle-top {\n  width: 100%;\n  padding: 10px 0px;\n  border-bottom: 1px solid #ccc; }\n\n.section-wise-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  width: 100%;\n  margin: 0px 0px; }\n\n.course-wise-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 40%; }\n\n.course-wise-container .section-title {\n    margin: 10px 0px;\n    font-weight: 600;\n    font-size: 14px; }\n\n.course-wise-container .section-info-container {\n    -webkit-box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16);\n            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16);\n    padding: 15px;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    border-radius: 4px;\n    border-top: 1px solid #ccc;\n    font-size: 12px;\n    min-height: 200px; }\n\n.course-wise-container .section-info-container .course-info {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      -webkit-box-pack: justify;\n          -ms-flex-pack: justify;\n              justify-content: space-between;\n      width: 100%;\n      padding: 5px;\n      border-radius: 4px;\n      border: 1px solid #89C5F8;\n      background: #F2FFFC; }\n\n.course-wise-container .section-info-container .course-info .course-info-item {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column; }\n\n.course-wise-container .section-info-container .course-info .course-info-item .course-info-title-container {\n          margin: 5px 0px;\n          color: #52A7F6; }\n\n.course-wise-container .section-info-container .course-info .course-info-item .course-info {\n          font-weight: 600; }\n\n.course-wise-container .section-info-container .course-info .course {\n        width: 80%;\n        -webkit-box-pack: start;\n            -ms-flex-pack: start;\n                justify-content: flex-start; }\n\n.course-wise-container .section-info-container .course-info .exam-date {\n        width: 20%;\n        -webkit-box-pack: start;\n            -ms-flex-pack: start;\n                justify-content: flex-start; }\n\n.course-wise-container .section-info-container .marks-info-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 100%;\n      padding: 10px 0px;\n      border-bottom: 1px solid #ccc; }\n\n.course-wise-container .section-info-container .marks-info-container .marks-info-item {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        width: 20%;\n        -webkit-box-pack: center;\n            -ms-flex-pack: center;\n                justify-content: center;\n        text-align: center; }\n\n.course-wise-container .section-info-container .marks-info-container .marks-info-item .marks-title {\n          color: #ccc;\n          margin-bottom: 5px; }\n\n.course-wise-container .section-info-container .marks-info-container .marks-info-item .marks {\n          font-weight: 600; }\n\n.course-wise-container .section-info-container .ranking-info-container {\n      width: 100%;\n      margin: 10px 0px;\n      margin-bottom: 0px;\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      -webkit-box-pack: justify;\n          -ms-flex-pack: justify;\n              justify-content: space-between; }\n\n.course-wise-container .section-info-container .ranking-info-container .marks-container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        -webkit-box-pack: center;\n            -ms-flex-pack: center;\n                justify-content: center;\n        text-align: center;\n        width: 30%;\n        border-radius: 4px; }\n\n.course-wise-container .section-info-container .ranking-info-container .marks-title {\n        color: white;\n        padding: 5px 0px; }\n\n.course-wise-container .section-info-container .ranking-info-container .marks-info {\n        padding: 5px 0px; }\n\n.course-wise-container .section-info-container .ranking-info-container .highest-border {\n        border: 1px solid #79DC80;\n        color: #79DC80; }\n\n.course-wise-container .section-info-container .ranking-info-container .lowest-border {\n        border: 1px solid #DC8979;\n        color: #DC8979; }\n\n.course-wise-container .section-info-container .ranking-info-container .topper-border {\n        border: 1px solid #58BDE3;\n        color: #58BDE3; }\n\n.course-wise-container .section-info-container .ranking-info-container .highest {\n        background: #79DC80; }\n\n.course-wise-container .section-info-container .ranking-info-container .lowest {\n        background: #DC8979; }\n\n.course-wise-container .section-info-container .ranking-info-container .topper {\n        background: #58BDE3; }\n\n.subject-wise-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 58%; }\n\n.subject-wise-container .section-title {\n    margin: 10px 0px;\n    font-weight: 600;\n    font-size: 14px; }\n\n.subject-wise-container .subject-wise-table-container {\n    -webkit-box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16);\n            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16);\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    border-radius: 4px;\n    border-top: 1px solid #ccc;\n    font-size: 12px;\n    min-height: 200px; }\n\n.subject-wise-container .subject-wise-table-container .heading-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 100%;\n      background: #FAFAFA;\n      color: black;\n      padding: 10px;\n      font-weight: 600; }\n\n.subject-wise-container .subject-wise-table-container .value-outer-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      max-height: 130px;\n      overflow-y: auto; }\n\n.subject-wise-container .subject-wise-table-container .value-container, .subject-wise-container .subject-wise-table-container .total-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 100%;\n      padding: 10px; }\n\n.subject-wise-container .subject-wise-table-container .total-container {\n      font-weight: 600;\n      border-top: 1px solid #ccc; }\n\n.subject-wise-container .subject-wise-table-container .heading-item, .subject-wise-container .subject-wise-table-container .value-item, .subject-wise-container .subject-wise-table-container .total-item {\n      width: 50%; }\n\n.student-wise-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%;\n  font-size: 12px; }\n\n.student-wise-container .section-title {\n    margin: 10px 0px;\n    font-weight: 600;\n    font-size: 14px; }\n\n.student-wise-container .student-wise-table-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    width: 100%;\n    -webkit-box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16);\n            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16);\n    border-radius: 4px; }\n\n.student-wise-container .student-wise-table-container .student-wise-heading-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 100%;\n      padding: 8px;\n      padding-left: 13px; }\n\n.student-wise-container .student-wise-table-container .student-wise-heading-container .student-wise-heading-item {\n        font-size: 12px;\n        font-weight: 600; }\n\n.student-wise-container .student-wise-table-container .subject-wise-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 40%;\n      max-width: 40%; }\n\n.student-wise-container .student-wise-table-container .subject-wise-container .subject-wise-heading-item {\n        font-size: 12px;\n        font-weight: 600;\n        width: 25%;\n        text-align: center; }\n\n.student-wise-container .student-wise-table-container .subject-wise-container .subject-wise-value-item {\n        font-size: 12px;\n        font-weight: 400;\n        width: 25%;\n        text-align: center; }\n\n.student-wise-container .student-wise-table-container .student-wise-value-outer-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      width: 100%; }\n\n.student-wise-container .student-wise-table-container .student-wise-value-outer-container .student-wise-value-container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        width: 100%;\n        border-left: 5px solid white;\n        padding: 8px;\n        margin-bottom: 10px;\n        border-top: 1px solid #ccc; }\n\n.student-wise-container .student-wise-table-container .medium-item {\n      width: 15%; }\n\n.student-wise-container .student-wise-table-container .small-item {\n      width: 10%; }\n\n.student-wise-container .student-wise-table-container .very-small-item {\n      width: 10%; }\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/exam-wise/exam-wise.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ExamWiseComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_course_services_course_list_service__ = __webpack_require__("./src/app/services/course-services/course-list.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_report_services_exam_service__ = __webpack_require__("./src/app/services/report-services/exam.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var ExamWiseComponent = /** @class */ (function () {
    function ExamWiseComponent(router, route, examdata, courseList, auth, msgService, commonService) {
        this.router = router;
        this.route = route;
        this.examdata = examdata;
        this.courseList = courseList;
        this.auth = auth;
        this.msgService = msgService;
        this.commonService = commonService;
        this.jsonFlag = {
            isProfessional: false,
            institute_id: '',
            isRippleLoad: false,
            type: 'batch'
        };
        this.studentWiseData = [];
        this.examSchdlType = false;
    }
    ExamWiseComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.jsonFlag.isProfessional = true;
                _this.jsonFlag.type = 'batch';
            }
            else {
                _this.jsonFlag.isProfessional = false;
                _this.jsonFlag.type = 'course';
            }
        });
        var examschd = sessionStorage.getItem('examSchdType');
        if (examschd) {
            this.examSchdlType = JSON.parse(examschd);
        }
        this.exam_schd_id = this.route.snapshot.paramMap.get('id');
        this.getExamWiseReport();
    };
    ExamWiseComponent.prototype.getExamWiseReport = function () {
        var _this = this;
        this.jsonFlag.isRippleLoad = true;
        this.examdata.getExamWiseReport(this.exam_schd_id, this.examSchdlType).subscribe(function (res) {
            _this.jsonFlag.isRippleLoad = false;
            var reports = res;
            _this.exam_wise_data = reports.courseWise;
            _this.subjectWiseData = reports.courseWise.subjectWise_marks;
            _this.is_exam_grad_feature = reports.courseWise.is_exam_grad_feature;
            if (reports.courseWise.studentWise_report != null) {
                _this.studentWiseData = reports.courseWise.studentWise_report;
            }
            sessionStorage.setItem('examSchdType', "");
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            _this.jsonFlag.isRippleLoad = false;
            sessionStorage.setItem('examSchdType', "");
        });
    };
    ExamWiseComponent.prototype.downloadReportCard = function () {
        var _this = this;
        this.examdata.downloadExamReport(this.exam_schd_id, this.examSchdlType).subscribe(function (res) {
            console.log(res);
            if (res) {
                // let resp = res.response;
                if (res.document != "") {
                    var byteArr = _this.commonService.convertBase64ToArray(res.document);
                    var fileName = 'report.pdf'; //res.docTitle;
                    var file = new Blob([byteArr], { type: 'application/pdf;charset=utf-8;' });
                    var url = URL.createObjectURL(file);
                    var dwldLink = document.getElementById('downloadFileClick');
                    dwldLink.setAttribute("href", url);
                    dwldLink.setAttribute("download", fileName);
                    document.body.appendChild(dwldLink);
                    dwldLink.click();
                }
                else {
                    _this.msgService.showErrorMessage('info', 'Info', "Document does not have any data.");
                }
            }
            else {
                _this.msgService.showErrorMessage('info', 'Info', "Document does not have any data.");
            }
        }, function (err) {
            // info type msg will be displayed as it will be displayed if no. of subjects are more than 5 
            _this.msgService.showErrorMessage('info', '', err.error.message);
        });
    };
    ExamWiseComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-exam-wise',
            template: __webpack_require__("./src/app/components/course-module/reports/new-exam-report/exam-wise/exam-wise.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/reports/new-exam-report/exam-wise/exam-wise.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["ActivatedRoute"],
            __WEBPACK_IMPORTED_MODULE_5__services_report_services_exam_service__["a" /* ExamService */],
            __WEBPACK_IMPORTED_MODULE_4__services_course_services_course_list_service__["a" /* CourseListService */],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_2__services_message_show_service__["a" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_6__services_common_service__["a" /* CommonServiceFactory */]])
    ], ExamWiseComponent);
    return ExamWiseComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/new-exam-report.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/new-exam-report.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/new-exam-report.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return NewExamReportComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var NewExamReportComponent = /** @class */ (function () {
    function NewExamReportComponent() {
    }
    NewExamReportComponent.prototype.ngOnInit = function () {
    };
    NewExamReportComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-new-exam-report',
            template: __webpack_require__("./src/app/components/course-module/reports/new-exam-report/new-exam-report.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/reports/new-exam-report/new-exam-report.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], NewExamReportComponent);
    return NewExamReportComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/teacher-performance/teacher-performance.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<div class=\"middle-section clear-fix\">\r\n  <section class=\"middle-top clearFix bulk-header\">\r\n    <div>\r\n      <h1 class=\"pull-left\">\r\n        <a routerLink=\"/view/{{jsonFlag.type}}/reports\" style=\"padding:0px; \">\r\n          Report\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n        <a routerLink=\"/view/{{jsonFlag.type}}/reports/new-exam\" style=\"padding:0px; \">\r\n          Exam Report\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n        <span>Exam Wise</span>\r\n      </h1>\r\n    </div>\r\n  </section>\r\n\r\n  <section>\r\n    <div class=\"teacher-performance-container\">\r\n      <div class=\"section-title\">\r\n        <span>Teacher Performance</span>\r\n      </div>\r\n      <div class=\"teacher-table-container\">\r\n        <div class=\"table-heading-container\">\r\n          <div class=\"table-heading-item\">\r\n            <span>Faculty</span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span>Mastercourse</span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span>Course</span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span>No. of Test</span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span>Attendance updated</span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span>Marks Updated</span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span>Avg Marks</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"table-value-outer-container\">\r\n          <div class=\"table-value-container\" *ngFor=\"let report of teachersReport\">\r\n            <div class=\"table-value-item\">\r\n              <span title=\"{{report.subject_name}}\">{{ (report.teacher_name.length > 20) ? (report.teacher_name | slice:0:20) + '...' : report.teacher_name }}</span>\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <span title=\"{{report.master_course_name}}\">{{ (report.master_course_name.length > 20) ? (report.master_course_name | slice:0:20) + '...' : report.master_course_name }}</span>\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <span title=\"{{report.course_name}}\">{{ (report.course_name.length > 20) ? (report.course_name | slice:0:20) + '...' : report.course_name }}</span>\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <span>{{report.total_exam}}</span>\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <span>{{report.total_attandance_updated}}</span>\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <span>{{report.total_marks_updated}}</span>\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <span>{{report.avarage_marks}}</span>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <section>\r\n    <div class=\"subject-wise-container\">\r\n      <div class=\"section-title\">\r\n        <span>Subject-wise</span>\r\n      </div>\r\n      <div class=\"subject-wise-table-container\">\r\n        <div class=\"table-heading-container\">\r\n          <div class=\"table-heading-item\">\r\n            <span>Date</span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span>Mastercourse</span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span>Course</span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span>Faculty</span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span>Student Appeared</span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span>Total Marks</span>\r\n          </div>\r\n          <!-- <div class=\"table-heading-item\">\r\n            <span>Percentage</span>\r\n          </div> -->\r\n          <div class=\"table-heading-item\">\r\n            <span>Status</span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span></span>\r\n          </div>\r\n          <div class=\"table-heading-item\">\r\n            <span>Action</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"table-value-outer-container\">\r\n          <div class=\"table-value-container\" *ngFor=\"let report of subjectsReport\"\r\n            [ngClass]=\"{'border-completed-class': report.exam_status == 'Mks. Updated', 'border-class': report.exam_status != 'Mks. Updated'}\">\r\n            <div class=\"table-value-item\">\r\n              <span>{{report.exam_date | date: 'dd-MMM-yyyy'}}</span>\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <span title=\"{{report.master_course_name}}\">{{ (report.master_course_name.length > 20) ? (report.master_course_name | slice:0:20) + '...' : report.master_course_name }}</span>\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <span title=\"{{report.course_name}}\">{{ (report.course_name.length > 20) ? (report.course_name | slice:0:20) + '...' : report.course_name }}</span>\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <span>{{report.teacher_name}}</span>\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <!-- <span>{{report.total_student}}</span> -->\r\n              <span *ngIf=\"report.exam_status!='Att. Pending'\">{{report.total_student}}</span>\r\n              <span *ngIf=\"report.exam_status=='Att. Pending'\">-</span>\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <span>{{report.total_marks}}</span>\r\n            </div>\r\n            <!-- <div class=\"table-value-item\">\r\n              <span *ngIf=\"report.batch_marks_percentage\">{{report.batch_marks_percentage}}%</span>\r\n              <span *ngIf=\"!report.batch_marks_percentage\">-</span>\r\n            </div> -->\r\n            <div class=\"table-value-item\">\r\n              <span *ngIf=\"report.exam_status != 'Mks. Updated'\">{{report.exam_status}}</span>\r\n              <span *ngIf=\"report.exam_status == 'Mks. Updated'\" style=\"color: #00E172;\">{{report.exam_status}}</span>\r\n              <!-- <span *ngIf=\"report.attendance_Status != 'Attendance Marked'\">{{report.attendance_Status}}</span>\r\n              <span *ngIf=\"report.attendance_Status == 'Attendance Marked'\" style=\"color: #26D4EF;\">{{report.attendance_Status}}</span> -->\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <!-- <span *ngIf=\"report.exam_status != 'Mks. Updated'\">{{report.exam_status}}</span>\r\n              <span *ngIf=\"report.exam_status == 'Mks. Updated'\" style=\"color: #00E172;\">{{report.exam_status}}</span> -->\r\n            </div>\r\n            <div class=\"table-value-item\">\r\n              <button *ngIf=\"report.exam_status == 'Mks. Updated'\" type=\"button\" name=\"button\" class=\"view-result-btn\" (click)=\"routeTo(report.exam_schd_id)\">View Result</button>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n\r\n  </section>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/teacher-performance/teacher-performance.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  padding: 1%; }\n\n.middle-top {\n  width: 100%;\n  padding: 10px 0px;\n  border-bottom: 1px solid #ccc; }\n\n.section-title {\n  margin: 10px 0px;\n  font-weight: 600;\n  font-size: 14px; }\n\n.teacher-table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%;\n  -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n          box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n  border-radius: 4px;\n  border-top: 1px solid #ccc;\n  font-size: 12px; }\n\n.teacher-table-container .table-heading-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    text-align: left;\n    width: 100%;\n    padding: 8px;\n    padding-right: 18px;\n    font-weight: 600;\n    background: #FAFAFA; }\n\n.teacher-table-container .table-heading-container .table-heading-item {\n      width: 14.28%; }\n\n.teacher-table-container .table-value-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    min-height: 33vh;\n    max-height: 33vh;\n    overflow-y: auto; }\n\n.teacher-table-container .table-value-outer-container .table-value-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 100%;\n      padding: 8px;\n      text-align: left; }\n\n.teacher-table-container .table-value-outer-container .table-value-container .table-value-item {\n        width: 14.28%; }\n\n.subject-wise-container {\n  margin-top: 20px; }\n\n.subject-wise-table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%;\n  -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n          box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n  border-radius: 4px;\n  border-top: 1px solid #ccc;\n  font-size: 12px; }\n\n.subject-wise-table-container .table-heading-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    text-align: left;\n    width: 100%;\n    padding: 8px;\n    padding-right: 18px;\n    font-weight: 600;\n    background: #FAFAFA; }\n\n.subject-wise-table-container .table-heading-container .table-heading-item {\n      width: 10%; }\n\n.subject-wise-table-container .table-value-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    min-height: 33vh;\n    max-height: 33vh;\n    overflow-y: auto; }\n\n.subject-wise-table-container .table-value-outer-container .table-value-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 100%;\n      padding: 8px;\n      text-align: left; }\n\n.subject-wise-table-container .table-value-outer-container .table-value-container .table-value-item {\n        width: 10%; }\n\n.subject-wise-table-container .table-value-outer-container .table-value-container .view-result-btn {\n        padding: 2px 5px;\n        background: #ffffff;\n        border-radius: 4px;\n        border: 1px solid #248CF5;\n        color: #248CF5; }\n\n.border-completed-class {\n  border-left: 3px solid #00E172;\n  background: #F4FFF4; }\n\n.border-class {\n  border-left: 3px solid white; }\n"

/***/ }),

/***/ "./src/app/components/course-module/reports/new-exam-report/teacher-performance/teacher-performance.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TeacherPerformanceComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_report_services_exam_service__ = __webpack_require__("./src/app/services/report-services/exam.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_course_services_course_list_service__ = __webpack_require__("./src/app/services/course-services/course-list.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var TeacherPerformanceComponent = /** @class */ (function () {
    function TeacherPerformanceComponent(router, route, examdata, courseList, auth, msgService) {
        this.router = router;
        this.route = route;
        this.examdata = examdata;
        this.courseList = courseList;
        this.auth = auth;
        this.msgService = msgService;
        this.jsonFlag = {
            isProfessional: false,
            institute_id: '',
            isRippleLoad: false,
            type: 'batch'
        };
        this.teachersReport = [];
        this.subjectsReport = [];
    }
    TeacherPerformanceComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.jsonFlag.isProfessional = true;
                _this.jsonFlag.type = 'batch';
            }
            else {
                _this.jsonFlag.isProfessional = false;
                _this.jsonFlag.type = 'course';
            }
        });
        this.subject_id = this.route.snapshot.paramMap.get('id');
        this.getSubjectWiseReport();
    };
    TeacherPerformanceComponent.prototype.getSubjectWiseReport = function () {
        var _this = this;
        this.jsonFlag.isRippleLoad = true;
        this.examdata.getSubjectWiseReport(this.subject_id).subscribe(function (res) {
            _this.jsonFlag.isRippleLoad = false;
            var result = res;
            _this.teacherData = result.teacherPerformanceReport;
            _this.subjectData = result.subjectWisePerformance;
            for (var i = 0; i < _this.teacherData.length; i++) {
                var teacherName = _this.teacherData[i].teacher_name;
                var teacherId = _this.teacherData[i].teacher_id;
                for (var l = 0; l < _this.teacherData[i].performanceList.length; l++) {
                    _this.teacherData[i].performanceList[l].teacher_id = teacherId;
                    _this.teacherData[i].performanceList[l].teacher_name = teacherName;
                    _this.teachersReport.push(_this.teacherData[i].performanceList[l]);
                }
            }
            for (var i = 0; i < _this.subjectData.length; i++) {
                var teacherName = _this.subjectData[i].teacher_name;
                var teacherId = _this.subjectData[i].teacher_id;
                for (var l = 0; l < _this.subjectData[i].performanceList.length; l++) {
                    _this.subjectData[i].performanceList[l].teacher_id = teacherId;
                    _this.subjectData[i].performanceList[l].teacher_name = teacherName;
                    _this.subjectsReport.push(_this.subjectData[i].performanceList[l]);
                }
            }
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    TeacherPerformanceComponent.prototype.routeTo = function (exam_schd_id) {
        sessionStorage.setItem('examSchdType', "true");
        this.router.navigate(['/view/' + this.jsonFlag.type + '/reports/new-exam/examWise/' + exam_schd_id]);
    };
    TeacherPerformanceComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-teacher-performance',
            template: __webpack_require__("./src/app/components/course-module/reports/new-exam-report/teacher-performance/teacher-performance.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/reports/new-exam-report/teacher-performance/teacher-performance.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["ActivatedRoute"],
            __WEBPACK_IMPORTED_MODULE_2__services_report_services_exam_service__["a" /* ExamService */],
            __WEBPACK_IMPORTED_MODULE_3__services_course_services_course_list_service__["a" /* CourseListService */],
            __WEBPACK_IMPORTED_MODULE_4__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_5__services_message_show_service__["a" /* MessageShowService */]])
    ], TeacherPerformanceComponent);
    return TeacherPerformanceComponent;
}());



/***/ })

});
//# sourceMappingURL=exam-report.module.chunk.js.map