webpackJsonp(["data-setup.module"],{

/***/ "./src/app/components/fee-module/data-setup/data-setup-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DataSetupRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2____ = __webpack_require__("./src/app/components/fee-module/data-setup/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__ = __webpack_require__("./src/app/guards/auth.guard.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2____["a" /* DataSetupComponent */],
        pathMatch: 'prefix',
        children: [
            {
                path: '',
                component: __WEBPACK_IMPORTED_MODULE_2____["a" /* DataSetupComponent */],
                children: [
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2____["d" /* MenuComponent */]
                    },
                    {
                        path: 'fee-template',
                        loadChildren: 'app/components/fee-module/data-setup/fee-template/fee-template.module#FeeTemplateModule',
                        canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
                    },
                    {
                        path: 'discount-reason',
                        component: __WEBPACK_IMPORTED_MODULE_2____["b" /* DiscountReasonComponent */]
                    },
                    {
                        path: 'fee-type',
                        component: __WEBPACK_IMPORTED_MODULE_2____["c" /* FeeTypesComponent */]
                    }
                ]
            }
        ]
    }
];
var DataSetupRoutingModule = /** @class */ (function () {
    function DataSetupRoutingModule() {
    }
    DataSetupRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]]
        })
    ], DataSetupRoutingModule);
    return DataSetupRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/fee-module/data-setup/data-setup.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/data-setup.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/** these css for gear icon download options\r\n* created by laxmi\r\n*/\nsvg:hover #gearIcon {\n  fill: #0084f6; }\n.asHover:hover {\n  color: #0084f6 !important; }\n.download:hover {\n  cursor: pointer; }\n.made-in {\n  font-size: 17px;\n  font-weight: bold;\n  text-align: left; }\n.dropdown > ul {\n  background: #fff;\n  padding: 10px 20px;\n  border: 1px solid #eaeaeb;\n  border-top: 0;\n  margin-top: 3px;\n  -webkit-box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 6px 10px 0 rgba(0, 0, 0, 0.12);\n          box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 6px 10px 0 rgba(0, 0, 0, 0.12); }\n.dropdown > ul li {\n    color: #333; }\n.dropdown > ul li strong {\n      font-weight: 600;\n      display: block; }\n.dropdown > ul li a {\n      display: block;\n      color: #333; }\n.login-tube nav > ul > li {\n  display: inline-block;\n  position: relative; }\n.login-tube nav > ul > li > a {\n  color: #333;\n  text-decoration: none;\n  padding: 5px 10px;\n  display: block;\n  -webkit-transition: all .4s;\n  transition: all .4s; }\n.login-tube nav > ul > li > a:hover,\n.login-tube nav > ul > li:hover > a {\n  text-decoration: none;\n  background: #ccc; }\n.login-tube nav > ul > li .dropdown {\n  position: absolute;\n  visibility: hidden;\n  right: 0;\n  top: 100%;\n  min-width: 200px;\n  border-top: 0;\n  opacity: 0;\n  -webkit-transition: all 0.1s cubic-bezier(0.55, 0, 0.55, 0.2);\n  transition: all 0.1s cubic-bezier(0.55, 0, 0.55, 0.2);\n  -webkit-transition-duration: .25s;\n  transition-duration: .2s;\n  -webkit-transform: scale(0.5);\n          transform: scale(0.5); }\n.login-tube nav > ul > li .dropdown > ul li {\n    line-height: normal; }\n.login-tube nav > ul > li .dropdown > ul li a {\n      display: block;\n      margin: 5px 0; }\n.login-tube nav > ul > li .dropdown > ul li a:hover {\n        color: #0084f6; }\n.login-tube nav > ul > li .dropdown > ul ul {\n    padding-left: 15px;\n    padding-top: 10px; }\n.login-tube nav > ul > li .dropdown > ul ul ul {\n      padding-top: 0; }\n.login-tube nav > ul > li:hover .dropdown {\n  visibility: visible;\n  position: absolute;\n  opacity: 1;\n  right: 0;\n  top: 100%;\n  -webkit-transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);\n  transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);\n  -webkit-transition-duration: .5s;\n  transition-duration: .5s;\n  -webkit-transform: scale(1);\n          transform: scale(1); }\n.span-button {\n  border: 1px solid #0084f6;\n  padding: 4px 8px;\n  color: #0084f6;\n  font-size: .9em;\n  border-radius: 2px;\n  font-weight: 600;\n  cursor: pointer; }\n.span-button svg {\n    margin: -3px 0;\n    height: 14px; }\nlogin-nav > li {\n  display: inline-block;\n  padding: 0 7px;\n  cursor: pointer;\n  vertical-align: text-bottom; }\nlogin-nav > li .dropdown {\n    position: absolute;\n    right: 0;\n    top: 100%;\n    padding-top: 10px; }\nlogin-nav > li .icons {\n    width: 35px;\n    height: 35px;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    border-radius: 50%;\n    padding-top: 3px;\n    -webkit-transition: all 0.1s;\n    transition: all 0.1s;\n    border: 1px solid transparent; }\nlogin-nav > li .icons svg {\n      width: 25px;\n      color: #034979; }\nlogin-nav > li .icons svg .cls-1 {\n        stroke: #034979;\n        stroke-linejoin: unset;\n        border: none; }\nlogin-nav > li .user-info {\n    white-space: nowrap;\n    margin-right: 40px;\n    width: auto;\n    display: block;\n    position: relative; }\nlogin-nav > li .user-info > .icons {\n      display: inline-block;\n      vertical-align: middle; }\nlogin-nav > li .user-info > span {\n      vertical-align: middle;\n      display: inline-block; }\nlogin-nav > li .user-info:after {\n      display: inline-block;\n      font: normal normal normal 14px/1 FontAwesome;\n      font-size: inherit;\n      text-rendering: auto;\n      -webkit-font-smoothing: antialiased;\n      content: \"\\f107\";\n      font-size: 17px;\n      position: absolute;\n      right: -20px;\n      top: 10px; }\n/**\r\n  this css is for report section css for cards\r\n  added by laxmi\r\n*/\n.report-box {\n  width: 100%;\n  height: 100%;\n  padding: 10px; }\n.report-box ul.card-box li.card-row {\n    margin: 10px 0px; }\n.report-box ul.card {\n    padding: 15px 10px;\n    border: 1px solid #efefef;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 10px 0px;\n    -webkit-box-shadow: 0px 0px 2px 0px;\n            box-shadow: 0px 0px 2px 0px; }\n.report-box ul.card li {\n      padding: 5px; }\n.report-box ul.card li:first-child {\n        font-size: 14px;\n        font-weight: 600;\n        padding: 10px 5px; }\n.report-box ul.card li:nth-child(2n) {\n        font-size: 12px; }\n.disabled {\n  cursor: not-allowed;\n  background: lightgrey; }\n"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/data-setup.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DataSetupComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var DataSetupComponent = /** @class */ (function () {
    function DataSetupComponent() {
    }
    DataSetupComponent.prototype.ngOnInit = function () {
    };
    DataSetupComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-data-setup',
            template: __webpack_require__("./src/app/components/fee-module/data-setup/data-setup.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/data-setup/data-setup.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], DataSetupComponent);
    return DataSetupComponent;
}());



/***/ }),

/***/ "./src/app/components/fee-module/data-setup/data-setup.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataSetupModule", function() { return DataSetupModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__data_setup_routing_module__ = __webpack_require__("./src/app/components/fee-module/data-setup/data-setup-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3____ = __webpack_require__("./src/app/components/fee-module/data-setup/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__student_module_student_fee_service__ = __webpack_require__("./src/app/components/student-module/student_fee.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__menu_menu_component__ = __webpack_require__("./src/app/components/fee-module/data-setup/menu/menu.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_ngx_bootstrap_custome__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10_primeng_primeng__ = __webpack_require__("./node_modules/primeng/primeng.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10_primeng_primeng___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10_primeng_primeng__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__services_feeStruc_service__ = __webpack_require__("./src/app/services/feeStruc.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












var DataSetupModule = /** @class */ (function () {
    function DataSetupModule() {
    }
    DataSetupModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_6__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_6__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_2__data_setup_routing_module__["a" /* DataSetupRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_9_ngx_bootstrap_custome__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_10_primeng_primeng__["FileUploadModule"],
                __WEBPACK_IMPORTED_MODULE_10_primeng_primeng__["SplitButtonModule"],
                __WEBPACK_IMPORTED_MODULE_10_primeng_primeng__["MenuModule"],
                __WEBPACK_IMPORTED_MODULE_8__shared_shared_module__["a" /* SharedModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_3____["a" /* DataSetupComponent */],
                __WEBPACK_IMPORTED_MODULE_3____["b" /* DiscountReasonComponent */],
                __WEBPACK_IMPORTED_MODULE_7__menu_menu_component__["a" /* MenuComponent */],
                __WEBPACK_IMPORTED_MODULE_3____["c" /* FeeTypesComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_5__services_common_service__["a" /* CommonServiceFactory */],
                __WEBPACK_IMPORTED_MODULE_4__student_module_student_fee_service__["a" /* StudentFeeService */],
                __WEBPACK_IMPORTED_MODULE_11__services_feeStruc_service__["a" /* FeeStrucService */]
            ]
        })
    ], DataSetupModule);
    return DataSetupModule;
}());



/***/ }),

/***/ "./src/app/components/fee-module/data-setup/discount-reason/discount-reason.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"middle-section clearFix\">\r\n  <section class=\"middle-top mb0 clearFix\" style=\"margin-bottom: 10px;\">\r\n    <h1 class=\"pull-left\">\r\n      <a routerLink=\"/view/fee\">\r\n        Fees\r\n    </a>\r\n    <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n    <a routerLink=\"/view/fee/data-setup\">\r\n       Data-setup\r\n  </a>\r\n  <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>   Discount Reason\r\n    </h1>\r\n  </section>\r\n\r\n  <section class=\"middle-main clearFix\">\r\n\r\n    <div class=\"clearFix add-edit\">\r\n      <a (click)=\"toggleCreateNew()\">\r\n        <i id=\"showAddBtn\" class=\"addBtnClass\" style=\"border:none;\">+</i>\r\n        <i id=\"showCloseBtn\" style=\"display:none;border:none;\" class=\"closeBtnClass\">-</i>\r\n        <span>Add Discount Reason</span>\r\n      </a>\r\n    </div>\r\n    <section class=\"clearFix create-standard-form\" *ngIf=\"createNewDiscount\">\r\n      <div class=\"row create-standard-field\">\r\n\r\n        <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"newDiscount\">Reason</label>\r\n            <input type=\"text\" [(ngModel)]=\"discountReason\" class=\"form-ctrl\" name=\"newDiscount\">\r\n          </div>\r\n        </div>\r\n        <div class=\"c-lg-2 c-md-2 c-sm-2\">\r\n          <aside class=\"pull-left create-cancel-small\">\r\n            <button class=\"btn fullBlue\" (click)=\"addNewDiscountReason()\" style=\"margin-top:25px;\">Add</button>\r\n          </aside>\r\n        </div>\r\n      </div>\r\n\r\n    </section>\r\n    <div id=\"divSlotTable\">\r\n      <div class=\"table-scroll-wrapper\">\r\n        <div class=\"table table-responsive\" style=\"max-height: 400px;\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  Reason\r\n                </th>\r\n                <th>\r\n                  Created Date\r\n                </th>\r\n                <th>\r\n                  Action\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr id=\"row{{i}}\" class=\"displayComp\" *ngFor=\"let row of discountReasonArray; let i = index; trackBy: i;\">\r\n                <td class=\"view-comp\">\r\n                  {{row.reason}}\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper\">\r\n                    <input type=\"text\" class=\"form-ctrl editCellInput\" [(ngModel)]=\"row.reason\" name=\"label\">\r\n                  </div>\r\n                </td>\r\n\r\n                <td class=\"CreatedOn\">\r\n                  {{row.created_date}}\r\n                </td>\r\n\r\n                <td class=\"view-comp\">\r\n                  <a class=\"anchorTagCursor\" (click)=\"editRowTable(row , i)\">Edit</a>\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <a class=\"anchorTagCursor\" (click)=\"saveInformation(row , i)\"> Save </a>\r\n                  <a class=\"anchorTagCursor\" (click)=\"cancelEditRow(i)\"> Cancel </a>\r\n                </td>\r\n              </tr>\r\n              <tr *ngIf=\"discountReasonArray.length ==0\">\r\n                <td colspan=\"3\" style=\"text-align: center\">\r\n                  No Discount Reason Available\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <!-- Paginator Here -->\r\n    <!-- <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n      <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n        <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\"\r\n          [pagesToShow]=\"10\" [page]=\"PageIndex\" [perPage]=\"studentdisplaysize\" [count]=\"totalRow\">\r\n        </pagination>\r\n      </div>\r\n    </div> -->\r\n  </section>\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/discount-reason/discount-reason.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\ntable thead tr th {\n  padding-bottom: 10px;\n  padding-top: 10px; }\ntable tbody tr td {\n  padding-bottom: 10px;\n  padding-top: 10px; }\ntable tbody tr td .editOptions li {\n    display: inline-block; }\ntable tbody tr .field-wrapper {\n  padding: 0px !important; }\ntable tbody tr .field-wrapper .form-ctrl {\n    display: block;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 5px;\n    outline: none;\n    height: 30px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 25px;\n    border: 1px solid #e4dede;\n    width: 65%;\n    word-break: break-word;\n    background: #efefef;\n    border-radius: 2px; }\ntable tbody .displayComp .edit-comp {\n  display: none; }\ntable tbody .editComp .view-comp {\n  display: none; }\n.anchorTagCursor {\n  cursor: pointer; }\n@media screen and (max-width: 995px), screen and (max-height: 768px) {\n  #divSlotTable {\n    margin-left: 0px !important;\n    margin-top: 15px;\n    margin-right: 15px !important;\n    max-height: 480px;\n    overflow: hidden;\n    width: 100%; }\n    #divSlotTable .table-scroll-wrapper {\n      max-height: 430px; }\n    #divSlotTable ::-webkit-scrollbar {\n      display: block;\n      width: 7px;\n      height: 7px; } }\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.add-edit {\n  margin-bottom: 15px;\n  margin-top: 15px; }\n.add-edit i {\n    border: 1px solid #0084f6;\n    display: inline-block;\n    width: 17px;\n    height: 17px;\n    border-radius: 50%;\n    line-height: 16px;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle;\n    margin-right: 4px; }\n.add-edit span {\n    display: inline-block; }\n.add-edit .expend-box i {\n    line-height: 12px;\n    font-size: 22px; }\n.add-edit a {\n    cursor: pointer; }\n.create-standard-form {\n  padding: 10px;\n  background: #efefef;\n  border-top: 1px solid #d8d8d8; }\n.create-standard-form .form-ctrl {\n    background: white;\n    border-bottom: solid 1px #cccccc; }\n.closeBtnClass {\n  line-height: 11px !important; }\n.editCellInput {\n  margin: auto;\n  display: block; }\n"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/discount-reason/discount-reason.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DiscountReasonComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__student_module_student_fee_service__ = __webpack_require__("./src/app/components/student-module/student_fee.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var DiscountReasonComponent = /** @class */ (function () {
    function DiscountReasonComponent(apiService, commonService) {
        this.apiService = apiService;
        this.commonService = commonService;
        this.discountReasonArray = [];
        this.createNewDiscount = false;
        this.discountReason = "";
    }
    DiscountReasonComponent.prototype.ngOnInit = function () {
        this.getDiscountReson();
    };
    DiscountReasonComponent.prototype.getDiscountReson = function () {
        var _this = this;
        this.apiService.getAllDiscountReasons().subscribe(function (res) {
            _this.discountReasonArray = res;
        }, function (err) {
        });
    };
    DiscountReasonComponent.prototype.toggleCreateNew = function () {
        if (this.createNewDiscount == false) {
            this.createNewDiscount = true;
            document.getElementById('showCloseBtn').style.display = '';
            document.getElementById('showAddBtn').style.display = 'none';
        }
        else {
            this.createNewDiscount = false;
            document.getElementById('showCloseBtn').style.display = 'none';
            document.getElementById('showAddBtn').style.display = '';
        }
    };
    DiscountReasonComponent.prototype.addNewDiscountReason = function () {
        var _this = this;
        if (this.discountReason.trim() != "" && this.discountReason.trim().length > 0) {
            var obj = {
                reason: this.discountReason
            };
            this.apiService.createDiscountReason(obj).subscribe(function (res) {
                _this.commonService.showErrorMessage('success', 'Discount Reason Added', '');
                _this.getDiscountReson();
                _this.discountReason = "";
            }, function (err) {
                _this.commonService.showErrorMessage('error', err.error.message, '');
            });
        }
        else {
            this.commonService.showErrorMessage('error', '', 'Please enter discount reason');
        }
    };
    DiscountReasonComponent.prototype.editRowTable = function (row, index) {
        document.getElementById(("row" + index).toString()).classList.remove('displayComp');
        document.getElementById(("row" + index).toString()).classList.add('editComp');
    };
    DiscountReasonComponent.prototype.saveInformation = function (row, index) {
        var _this = this;
        if (row.reason != null && row.reason != "") {
            var obj = {};
            obj.reason = row.reason;
            this.apiService.updateDiscountReasons(obj, row.discount_reason_id).subscribe(function (data) {
                _this.cancelEditRow(index);
                _this.commonService.showErrorMessage('success', 'Discount Reason Updated', '');
                _this.getDiscountReson();
            }, function (error) {
                _this.commonService.showErrorMessage('error', '', error.error.message);
            });
        }
        else {
            this.commonService.showErrorMessage('error', '', 'Please enter discount reason');
        }
    };
    DiscountReasonComponent.prototype.cancelEditRow = function (index) {
        document.getElementById(("row" + index).toString()).classList.add('displayComp');
        document.getElementById(("row" + index).toString()).classList.remove('editComp');
        this.getDiscountReson();
    };
    DiscountReasonComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-discount-reason',
            template: __webpack_require__("./src/app/components/fee-module/data-setup/discount-reason/discount-reason.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/data-setup/discount-reason/discount-reason.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__student_module_student_fee_service__["a" /* StudentFeeService */],
            __WEBPACK_IMPORTED_MODULE_2__services_common_service__["a" /* CommonServiceFactory */]])
    ], DiscountReasonComponent);
    return DiscountReasonComponent;
}());



/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-types/fee-types.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"middle-section clearFix\">\r\n  <section class=\"middle-top mb0 clearFix\" style=\"margin-bottom: 10px;\">\r\n    <h1 class=\"pull-left\">\r\n      <a routerLink=\"/view/fee\">\r\n        Fees\r\n      </a>\r\n      <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n      <a routerLink=\"/view/fee/data-setup\">\r\n        Data-setup\r\n      </a>\r\n      <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i> Additional fees\r\n    </h1>\r\n  </section>\r\n\r\n  <section class=\"middle-main clearFix\">\r\n\r\n    <!-- <div class=\"note-wrapper\">\r\n      <h3>Note</h3>\r\n      <ul>\r\n        <li>\r\n          <span>1. Create only type of Fee.</span>\r\n        </li>\r\n        <li>\r\n          <span>2. No need to add amount (Amount will be added during student fee schedule).</span>\r\n        </li>\r\n        <li>\r\n          <span>3. Create Batch Fee Schedule if required.</span>\r\n        </li>\r\n      </ul>\r\n    </div> -->\r\n\r\n    <div class=\"clearFix add-edit\">\r\n      <a (click)=\"toggleCreate()\">\r\n        <i id=\"showAddBtn\" class=\"addBtnClass\">+</i>\r\n        <i id=\"showCloseBtn\" style=\"display:none\" class=\"closeBtnClass\">-</i>\r\n        <span>Add Fee Types</span>\r\n      </a>\r\n    </div>\r\n    <section class=\"clearFix create-standard-form\" *ngIf=\"createNewFeeType\">\r\n      <div class=\"row create-standard-field\">\r\n        <div class=\"c-lg-2 c-md-2 c-sm-2\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value' : addNewFee.fee_type != '' }\">\r\n            <label for=\"slotNew\">Fee Type <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <input type=\"text\" #idSlot class=\"form-ctrl\" [(ngModel)]=\"addNewFee.fee_type\" name=\"slotNew\">\r\n\r\n            <p>(Eg Registration Fee, Library)</p>\r\n          </div>\r\n        </div>\r\n        <div class=\"c-lg-2 c-md-2 c-sm-2\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value' : addNewFee.fee_type_desc != '' }\">\r\n            <label for=\"slotNew\">Description\r\n            </label>\r\n            <input type=\"text\" #idSlot class=\"form-ctrl\" [(ngModel)]=\"addNewFee.fee_type_desc\" name=\"slotNew\">\r\n          </div>\r\n        </div>\r\n        <div class=\"c-lg-2 c-md-2 c-sm-2\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value' : addNewFee.country_id != '' }\">\r\n            <label for=\"slotNew\">Country <span class=\"text-danger\">*</span></label>\r\n            <select id=\"country_id\" class=\"form-ctrl\" [(ngModel)]=\"addNewFee.country_id\" name=\"country_id\" style=\"height: 29px;padding: 0\">\r\n              <option value=\"\"></option>\r\n              <option [value]=\"data.id\" selected *ngFor='let data of countryDetails'>\r\n                {{data.country_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n        <div class=\"c-lg-2 c-md-2 c-sm-2\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value' : addNewFee.fee_amount != '' }\">\r\n            <label for=\"slotNew\">Fee Amount <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <input type=\"text\" onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" #idSlot class=\"form-ctrl\" [(ngModel)]=\"addNewFee.fee_amount\"\r\n              name=\"slotNew\">\r\n\r\n          </div>\r\n        </div>\r\n        <div class=\"c-lg-2 c-md-2 c-sm-2\" *ngIf=\"addNewFee.country_id==1\">\r\n          <div class=\"field-wrapper\" [ngClass]=\"{'has-value' : addNewFee.fee_type_tax >= 0 }\">\r\n            <label for=\"slotNew\">Tax(%)\r\n            </label>\r\n            <input type=\"number\" max=\"99\" #idSlot class=\"form-ctrl\" [readonly]=\"isTaxEnableFeeInstallments\" [(ngModel)]=\"addNewFee.fee_type_tax\"\r\n              name=\"slotNew\">\r\n\r\n          </div>\r\n        </div>\r\n        <div style=\"margin-top: 1.5%;\" class=\"pull-left create-cancel-small\">\r\n          <button class=\"btn fullBlue\" (click)=\"addNewFeeType()\">Add</button>\r\n        </div>\r\n      </div>\r\n    </section>\r\n\r\n    <div class=\"table-responsive\">\r\n      <table>\r\n        <thead>\r\n          <th>\r\n            Fee Type (Eg Registration Fee, Library)\r\n          </th>\r\n          <th>\r\n            Fee Type Description\r\n          </th>\r\n          <th>\r\n            Country\r\n          </th>\r\n          <th>\r\n            Fee Amount\r\n          </th>\r\n          <th>\r\n            Tax(%)\r\n            <div class=\"questionInfo inline-relative\">\r\n              <span class=\"qInfoIcon i-class\">i</span>\r\n              <div class=\"tooltip-box-field\">\r\n                Enable GST\r\n              </div>\r\n            </div>\r\n          </th>\r\n          <th>\r\n            Action\r\n          </th>\r\n        </thead>\r\n        <tbody>\r\n          <tr *ngFor=\"let row of feeTypeList; let i = index\">\r\n            <td>\r\n              <div class=\"field-wrapper\">\r\n                <input type=\"text\" class=\"form-ctrl editCellInput\" [(ngModel)]=\"row.fee_type\" name=\"label\">\r\n              </div>\r\n            </td>\r\n            <td>\r\n              <div class=\"field-wrapper\">\r\n                <input type=\"text\" class=\"form-ctrl editCellInput\" [(ngModel)]=\"row.fee_type_desc\" name=\"label\">\r\n              </div>\r\n            </td>\r\n            <td>\r\n              <select id=\"country_id\" class=\"form-ctrl input_txt\" [(ngModel)]=\"row.country_id\" \r\n              name=\"country_id\"  (ngModelChange)=\"onRowDataChange($event,row)\">\r\n                <option [value]=\"data.id\" selected *ngFor='let data of countryDetails'>\r\n                  {{data.country_name}}   \r\n                </option>\r\n              </select>\r\n    </td>\r\n    <td>\r\n        <span>{{getCountryDetails(row.fee_amount,row.country_id)}}</span>\r\n      <span class=\"field-wrapper\">\r\n       <input type=\"number\" class=\"form-ctrl editCellInput\" style=\"width:25%;display: inherit;\" [(ngModel)]=\"row.fee_amount\" name=\"label\">\r\n      </span>\r\n    </td>\r\n    <td>\r\n      <div class=\"field-wrapper\">\r\n        <!-- disabled =row.country_id!='1' && isTaxEnableFeeInstallments -->\r\n    <input type=\"number\"  class=\"form-ctrl editCellInput\" [disabled]=\"row.country_id!='1'\" [ngClass]=\"{'disable_input': row.country_id!='1'}\" style=\"width:25%\" [(ngModel)]=\"row.fee_type_tax\"\r\n          name=\"tax\">\r\n      </div>\r\n    </td>\r\n    <td>\r\n      <span *ngIf=\"row.fee_type_id == 0\" class=\"delete-btn\" style=\"font-family: FontAwesome; font-size: 19px\" (click)=\"deleteRow(row , i)\">\r\n        <i class=\"fa fa-trash-o \" aria-hidden=\"true \"></i>\r\n      </span>\r\n    </td>\r\n    </tr>\r\n    </tbody>\r\n    </table>\r\n</div>\r\n\r\n<div class=\"pull-right\" style=\"margin-top: 1.5%;\">\r\n  <button class=\"btn\" routerLink=\"/view/fee/home\">Back</button>\r\n  <button class=\"btn fullBlue\" (click)=\"updateDetails()\">Update</button>\r\n</div>\r\n\r\n</section>\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-types/fee-types.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.input_txt {\n  height: 29px;\n  padding: 0;\n  border: 1px solid #ccc;\n  background: transparent; }\n.note-wrapper {\n  padding: 10px 10px;\n  background: #efefef; }\n.note-wrapper h3 {\n    margin-top: 5px;\n    margin-bottom: 5px; }\n.note-wrapper ul li {\n    margin-top: 5px; }\n.table-responsive {\n  overflow-x: hidden; }\n.disable_input {\n  background: lightgrey !important;\n  cursor: not-allowed; }\n.add-edit {\n  margin-bottom: 15px;\n  margin-top: 15px; }\n.add-edit i {\n    display: inline-block;\n    width: 17px;\n    height: 17px;\n    border-radius: 50%;\n    line-height: 16px;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle;\n    margin-right: 4px; }\n.add-edit span {\n    display: inline-block; }\n.add-edit .expend-box i {\n    line-height: 12px;\n    font-size: 14px; }\n.add-edit a {\n    cursor: pointer; }\n.create-standard-form {\n  margin: 10px 0;\n  padding: 10px 20px 20px;\n  background: #efefef;\n  border-top: 1px solid #d8d8d8; }\n.create-standard-form .form-ctrl {\n    background: transparent;\n    border-bottom: solid 1px #cccccc; }\n.closeBtnClass {\n  line-height: 11px !important; }\n.editCellInput {\n  margin: auto; }\ntable thead tr th {\n  padding-top: 10px !important;\n  padding-bottom: 10px !important; }\ntable tbody tr td {\n  padding-top: 5px;\n  padding-bottom: 5px; }\ntable tbody tr .field-wrapper {\n  padding: 0px !important; }\ntable tbody tr .field-wrapper .form-ctrl {\n    display: block;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 0px 0px 0px 5px;\n    outline: none;\n    border: 0;\n    height: 26px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 25px;\n    background: transparent;\n    width: 50%;\n    text-align: center;\n    border: 1px solid #ccc; }\ninput[type=number]::-webkit-inner-spin-button,\ninput[type=number]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0; }\n"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-types/fee-types.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FeeTypesComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_feeStruc_service__ = __webpack_require__("./src/app/services/feeStruc.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var FeeTypesComponent = /** @class */ (function () {
    function FeeTypesComponent(apiService, commonService) {
        this.apiService = apiService;
        this.commonService = commonService;
        this.createNewFeeType = false;
        this.isTaxEnableFeeInstallments = false;
        this.isRippleLoad = false;
        this.addNewFee = {
            fee_type: '',
            fee_type_desc: '',
            fee_amount: '',
            fee_type_tax: 0,
            fee_type_id: 0,
            country_id: ''
        };
        this.feeTypeList = [];
        this.countryDetails = [];
    }
    FeeTypesComponent.prototype.ngOnInit = function () {
        this.getListOfFeeType();
        this.fetchDataForCountryDetails();
        this.isTaxEnableFeeInstallments = sessionStorage.getItem('enable_tax_applicable_fee_installments') == '0' ? true : false;
    };
    FeeTypesComponent.prototype.getCurrencyDetails = function (value, currency, lang) {
        if (value && currency && lang) {
            var formatted = value.toLocaleString(lang, {
                maximumFractionDigits: 4,
                style: 'currency',
                currency: currency
            });
            formatted = formatted.replace(/[,.]/g, '');
            return formatted.replace(/[0-9]/g, '');
        }
        else {
            return lang;
        }
    };
    FeeTypesComponent.prototype.onRowDataChange = function (country_id, row) {
        this.countryDetails.forEach(function (countryId) {
            if (countryId.id == country_id) {
                row.country_id = countryId.id;
            }
        });
        if (country_id != '1') {
            row.fee_type_tax = 0;
        }
    };
    FeeTypesComponent.prototype.getCountryDetails = function (amount, country_id) {
        var symbol;
        for (var i = 0; i < this.countryDetails.length; i++) {
            if (this.countryDetails[i].id == country_id) {
                symbol = this.countryDetails[i].symbol;
            }
        }
        return symbol;
    };
    FeeTypesComponent.prototype.fetchDataForCountryDetails = function () {
        var _this = this;
        var encryptedData = sessionStorage.getItem('country_data');
        var data = JSON.parse(encryptedData);
        if (data.length > 0) {
            this.countryDetails = data;
            this.countryDetails.forEach(function (country) {
                if (country) {
                    country.symbol = _this.getCurrencyDetails(1000, country.currency_code, country.country_code);
                    console.log('symbol', country.symbol);
                }
            });
        }
        console.log(data);
    };
    FeeTypesComponent.prototype.getListOfFeeType = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getAllFeeType().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.feeTypeList = res;
            _this.feeTypeList.forEach(function (element) {
                if (element.countryId) {
                    element.country_id = element.countryId.country_id;
                }
            });
        }, function (err) {
            _this.isRippleLoad = false;
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    FeeTypesComponent.prototype.updateDetails = function () {
        var _this = this;
        var data = this.makeDataJson();
        if (!this.isRippleLoad) {
            this.isRippleLoad = true;
            this.apiService.upadateFeeType(data).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.commonService.showErrorMessage('success', 'Updated', 'Details Updated Successfully');
                _this.getListOfFeeType();
            }, function (err) {
                _this.isRippleLoad = false;
                _this.commonService.showErrorMessage('error', '', err.error.message);
            });
        }
    };
    FeeTypesComponent.prototype.makeDataJson = function () {
        var data = [];
        for (var t = 0; t < this.feeTypeList.length; t++) {
            var obj = {};
            obj.fee_amount = this.feeTypeList[t].fee_amount;
            obj.fee_type = this.feeTypeList[t].fee_type;
            obj.fee_type_desc = this.feeTypeList[t].fee_type_desc;
            obj.fee_type_id = this.feeTypeList[t].fee_type_id;
            obj.country_id = this.feeTypeList[t].country_id;
            if (this.feeTypeList[t].fee_type_tax == "" || this.feeTypeList[t].fee_type_tax == null) {
                this.feeTypeList[t].fee_type_tax = 0;
            }
            obj.fee_type_tax = this.feeTypeList[t].fee_type_tax;
            data.push(obj);
        }
        return data;
    };
    FeeTypesComponent.prototype.addNewFeeType = function () {
        if (this.addNewFee.fee_type.trim() != "") {
            if (this.addNewFee.country_id != "") {
                if (this.addNewFee.fee_amount != "" && Number(this.addNewFee.fee_amount) > 0) {
                    var obj = this.addNewFee;
                    obj.country_id = Number(this.addNewFee.country_id);
                    this.onRowDataChange(obj.country_id, obj);
                    this.feeTypeList.push(obj);
                    this.addNewFee = {
                        fee_type: '',
                        fee_type_desc: '',
                        fee_amount: '',
                        fee_type_tax: 0,
                        fee_type_id: 0,
                        country_id: ''
                    };
                }
                else {
                    this.commonService.showErrorMessage('error', '', 'Please enter fee amount');
                }
            }
            else {
                this.commonService.showErrorMessage('error', '', 'Please select the country');
            }
        }
        else {
            this.commonService.showErrorMessage('error', '', 'Please enter fee type');
        }
    };
    FeeTypesComponent.prototype.deleteRow = function (row, index) {
        this.feeTypeList.splice(index, 1);
    };
    FeeTypesComponent.prototype.toggleCreate = function () {
        if (this.createNewFeeType == false) {
            this.createNewFeeType = true;
            document.getElementById('showCloseBtn').style.display = '';
            document.getElementById('showAddBtn').style.display = 'none';
        }
        else {
            this.createNewFeeType = false;
            document.getElementById('showCloseBtn').style.display = 'none';
            document.getElementById('showAddBtn').style.display = '';
        }
    };
    FeeTypesComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-fee-types',
            template: __webpack_require__("./src/app/components/fee-module/data-setup/fee-types/fee-types.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/data-setup/fee-types/fee-types.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_feeStruc_service__["a" /* FeeStrucService */],
            __WEBPACK_IMPORTED_MODULE_2__services_common_service__["a" /* CommonServiceFactory */]])
    ], FeeTypesComponent);
    return FeeTypesComponent;
}());



/***/ }),

/***/ "./src/app/components/fee-module/data-setup/index.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__data_setup_component__ = __webpack_require__("./src/app/components/fee-module/data-setup/data-setup.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_0__data_setup_component__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__discount_reason_discount_reason_component__ = __webpack_require__("./src/app/components/fee-module/data-setup/discount-reason/discount-reason.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "b", function() { return __WEBPACK_IMPORTED_MODULE_1__discount_reason_discount_reason_component__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__menu_menu_component__ = __webpack_require__("./src/app/components/fee-module/data-setup/menu/menu.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "d", function() { return __WEBPACK_IMPORTED_MODULE_2__menu_menu_component__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__fee_types_fee_types_component__ = __webpack_require__("./src/app/components/fee-module/data-setup/fee-types/fee-types.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "c", function() { return __WEBPACK_IMPORTED_MODULE_3__fee_types_fee_types_component__["a"]; });






/***/ }),

/***/ "./src/app/components/fee-module/data-setup/menu/menu.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"middle-section clearFix\">\r\n  <aside class=\"middle-full\" style=\"padding: 1%\">\r\n      <h1 class=\"pull-left\" style=\"padding-bottom: 10px\">\r\n          <a routerLink=\"/view/fee\">\r\n            Fees \r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n           Data-setup\r\n      </h1>\r\n    <section class=\"middle-main clearFix report-box\" style=\"padding: 0\">\r\n\r\n        <div class=\"course-menu-section-container\">\r\n            <div class=\"course-menu-item\" routerLink=\"./fee-type\">\r\n              <div class=\"menu-title\">\r\n                <img src=\"./assets/images/fee/Fee_types.svg\" alt=\"fee types\">\r\n                <span>Additional fees</span>\r\n              </div>\r\n              <div class=\"menu-description\">\r\n                <span>Define fees for every type and add a description to it.</span>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"course-menu-item\" routerLink=\"./fee-template\">\r\n              <div class=\"menu-title\">\r\n                <img src=\"./assets/images/fee/Fee_template.svg\" alt=\"fee template\">\r\n                <span>{{moduleState}} wise fees</span>\r\n              </div>\r\n              <div class=\"menu-description\">\r\n                <span>Create fee structure for {{moduleState}}. </span>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"course-menu-item\" routerLink=\"./discount-reason\">\r\n              <div class=\"menu-title\">\r\n                <img src=\"./assets/images/fee/discount_reason.svg\" alt=\"discount reason\">\r\n                <span> Discount Reason</span>\r\n              </div>\r\n              <div class=\"menu-description\">\r\n                <span>Add/Edit reasons for discounts.</span>\r\n              </div>\r\n            </div>\r\n\r\n\r\n            </div>\r\n    </section>\r\n  </aside>\r\n</div>"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/menu/menu.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/** these css for gear icon download options\r\n* created by laxmi\r\n*/\nsvg:hover #gearIcon {\n  fill: #0084f6; }\n.asHover:hover {\n  color: #0084f6 !important; }\n.download:hover {\n  cursor: pointer; }\n.made-in {\n  font-size: 17px;\n  font-weight: bold;\n  text-align: left; }\n.dropdown > ul {\n  background: #fff;\n  padding: 10px 20px;\n  border: 1px solid #eaeaeb;\n  border-top: 0;\n  margin-top: 3px;\n  -webkit-box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 6px 10px 0 rgba(0, 0, 0, 0.12);\n          box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 6px 10px 0 rgba(0, 0, 0, 0.12); }\n.dropdown > ul li {\n    color: #333; }\n.dropdown > ul li strong {\n      font-weight: 600;\n      display: block; }\n.dropdown > ul li a {\n      display: block;\n      color: #333; }\n.login-tube nav > ul > li {\n  display: inline-block;\n  position: relative; }\n.login-tube nav > ul > li > a {\n  color: #333;\n  text-decoration: none;\n  padding: 5px 10px;\n  display: block;\n  -webkit-transition: all .4s;\n  transition: all .4s; }\n.login-tube nav > ul > li > a:hover,\n.login-tube nav > ul > li:hover > a {\n  text-decoration: none;\n  background: #ccc; }\n.login-tube nav > ul > li .dropdown {\n  position: absolute;\n  visibility: hidden;\n  right: 0;\n  top: 100%;\n  min-width: 200px;\n  border-top: 0;\n  opacity: 0;\n  -webkit-transition: all 0.1s cubic-bezier(0.55, 0, 0.55, 0.2);\n  transition: all 0.1s cubic-bezier(0.55, 0, 0.55, 0.2);\n  -webkit-transition-duration: .25s;\n  transition-duration: .2s;\n  -webkit-transform: scale(0.5);\n          transform: scale(0.5); }\n.login-tube nav > ul > li .dropdown > ul li {\n    line-height: normal; }\n.login-tube nav > ul > li .dropdown > ul li a {\n      display: block;\n      margin: 5px 0; }\n.login-tube nav > ul > li .dropdown > ul li a:hover {\n        color: #0084f6; }\n.login-tube nav > ul > li .dropdown > ul ul {\n    padding-left: 15px;\n    padding-top: 10px; }\n.login-tube nav > ul > li .dropdown > ul ul ul {\n      padding-top: 0; }\n.login-tube nav > ul > li:hover .dropdown {\n  visibility: visible;\n  position: absolute;\n  opacity: 1;\n  right: 0;\n  top: 100%;\n  -webkit-transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);\n  transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);\n  -webkit-transition-duration: .5s;\n  transition-duration: .5s;\n  -webkit-transform: scale(1);\n          transform: scale(1); }\n.span-button {\n  border: 1px solid #0084f6;\n  padding: 4px 8px;\n  color: #0084f6;\n  font-size: .9em;\n  border-radius: 2px;\n  font-weight: 600;\n  cursor: pointer; }\n.span-button svg {\n    margin: -3px 0;\n    height: 14px; }\nlogin-nav > li {\n  display: inline-block;\n  padding: 0 7px;\n  cursor: pointer;\n  vertical-align: text-bottom; }\nlogin-nav > li .dropdown {\n    position: absolute;\n    right: 0;\n    top: 100%;\n    padding-top: 10px; }\nlogin-nav > li .icons {\n    width: 35px;\n    height: 35px;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    border-radius: 50%;\n    padding-top: 3px;\n    -webkit-transition: all 0.1s;\n    transition: all 0.1s;\n    border: 1px solid transparent; }\nlogin-nav > li .icons svg {\n      width: 25px;\n      color: #034979; }\nlogin-nav > li .icons svg .cls-1 {\n        stroke: #034979;\n        stroke-linejoin: unset;\n        border: none; }\nlogin-nav > li .user-info {\n    white-space: nowrap;\n    margin-right: 40px;\n    width: auto;\n    display: block;\n    position: relative; }\nlogin-nav > li .user-info > .icons {\n      display: inline-block;\n      vertical-align: middle; }\nlogin-nav > li .user-info > span {\n      vertical-align: middle;\n      display: inline-block; }\nlogin-nav > li .user-info:after {\n      display: inline-block;\n      font: normal normal normal 14px/1 FontAwesome;\n      font-size: inherit;\n      text-rendering: auto;\n      -webkit-font-smoothing: antialiased;\n      content: \"\\f107\";\n      font-size: 17px;\n      position: absolute;\n      right: -20px;\n      top: 10px; }\n/**\r\n  this css is for report section css for cards\r\n  added by laxmi\r\n*/\n.report-box {\n  width: 100%;\n  height: 100%;\n  padding: 10px; }\n.report-box ul.card-box li.card-row {\n    margin: 10px 0px; }\n.report-box ul.card {\n    padding: 15px 10px;\n    border: 1px solid #efefef;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 10px 0px;\n    -webkit-box-shadow: 0px 0px 2px 0px;\n            box-shadow: 0px 0px 2px 0px; }\n.report-box ul.card li {\n      padding: 5px; }\n.report-box ul.card li:first-child {\n        font-size: 14px;\n        font-weight: 600;\n        padding: 10px 5px; }\n.report-box ul.card li:nth-child(2n) {\n        font-size: 12px; }\n.disabled {\n  cursor: not-allowed;\n  background: lightgrey; }\n.course-menu-section-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  padding-top: 10px;\n  margin-top: 10px;\n  border-top: 1px solid rgba(10, 10, 10, 0.5);\n  width: 100%; }\n.course-menu-section-container .course-menu-item {\n    padding: 15px 10px;\n    width: 31%;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 1%;\n    -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24);\n    box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24); }\n.course-menu-section-container .course-menu-item .menu-title {\n      width: 100%;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start;\n      font-size: 14px;\n      font-weight: 600;\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row; }\n.course-menu-section-container .course-menu-item .menu-title img {\n        width: 25px;\n        height: 25px; }\n.course-menu-section-container .course-menu-item .menu-title span {\n        margin-left: 10px;\n        margin-top: 5px; }\n.course-menu-section-container .course-menu-item .menu-description {\n      padding: 10px;\n      font-size: 12px; }\n"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/menu/menu.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return MenuComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var MenuComponent = /** @class */ (function () {
    function MenuComponent(auth) {
        this.auth = auth;
    }
    MenuComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.moduleState = 'Batch';
            }
            else {
                _this.moduleState = 'Course';
            }
        });
    };
    MenuComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-menu',
            template: __webpack_require__("./src/app/components/fee-module/data-setup/menu/menu.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/data-setup/menu/menu.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], MenuComponent);
    return MenuComponent;
}());



/***/ })

});
//# sourceMappingURL=data-setup.module.chunk.js.map