webpackJsonp(["users-management.module"],{

/***/ "./src/app/components/users-management/users-management.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"middle-section clearFix\">\r\n\r\n  <section class=\"middle-main clearFix\">\r\n    <div class=\"common-tab\">\r\n      <ul>\r\n        <li id=\"liUser\" (click)=\"switchActiveView('liUser')\" class=\"\">\r\n          <a routerLink=\"/view/manage\">User</a>\r\n        </li>\r\n        <li id=\"liRole\" (click)=\"switchActiveView('liRole')\" class=\"active\">\r\n          <a routerLink=\"/view/manage/role\">Role</a>\r\n        </li>\r\n      </ul>\r\n    </div>\r\n\r\n    <div class=\"router-container\">\r\n      <router-outlet></router-outlet>\r\n    </div>\r\n  </section>\r\n</div>"

/***/ }),

/***/ "./src/app/components/users-management/users-management.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.middle-section {\n  padding: 1%; }\n.router-container {\n  width: 100%;\n  overflow-x: hidden;\n  overflow-y: auto; }\n.common-tab {\n  padding-top: 5px; }\n.common-tab ul {\n    font-size: 0; }\n.common-tab ul li {\n      margin-right: 1px;\n      display: inline-block;\n      width: 10%;\n      max-width: 158px;\n      cursor: pointer; }\n.common-tab ul li a {\n        display: block;\n        padding: 10px 5px;\n        background: #eff7ff;\n        border: 1px solid #cccdcd;\n        color: #0084f6;\n        text-align: center;\n        font-size: 14px;\n        font-weight: 600; }\n.common-tab ul li:hover a, .common-tab ul li.active a {\n        background: #0084f6;\n        color: #fff;\n        border-color: #0084f6;\n        font-weight: normal; }\n@media only screen and (max-width: 420px) {\n  .common-tab ul li {\n    width: auto; }\n    .common-tab ul li a {\n      font-size: 10px; }\n  .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 12px; } }\n@media only screen and (max-width: 767px) {\n  .common-tab ul li {\n    margin-right: 0;\n    width: 20%; }\n    .common-tab ul li a {\n      padding: 5px 5px;\n      font-size: 12px; } }\n"

/***/ }),

/***/ "./src/app/components/users-management/users-management.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UsersManagementComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var UsersManagementComponent = /** @class */ (function () {
    function UsersManagementComponent(router) {
        this.router = router;
    }
    UsersManagementComponent.prototype.ngOnInit = function () {
        this.removeSelectionFromSideNav();
        this.checkWhichTabIsOpen();
    };
    UsersManagementComponent.prototype.checkWhichTabIsOpen = function () {
        var url = this.router.url;
        if (url.includes('user')) {
            this.switchActiveView('liUser');
        }
        else {
            this.switchActiveView('liRole');
        }
    };
    UsersManagementComponent.prototype.switchActiveView = function (id) {
        document.getElementById('liUser').classList.remove('active');
        document.getElementById('liRole').classList.remove('active');
        document.getElementById(id).classList.add('active');
    };
    UsersManagementComponent.prototype.removeSelectionFromSideNav = function () {
        // let classArray = ['lione', 'litwo', 'lithree', 'lifour', 'lifive', 'lisix', 'liseven', 'lieight', 'linine', 'lizero'];
        // classArray.forEach(function (className) {
        //   document.getElementById(className).classList.remove('active');
        // });
    };
    UsersManagementComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-users',
            template: __webpack_require__("./src/app/components/users-management/users-management.component.html"),
            styles: [__webpack_require__("./src/app/components/users-management/users-management.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"]])
    ], UsersManagementComponent);
    return UsersManagementComponent;
}());



/***/ }),

/***/ "./src/app/components/users-management/users-management.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserManagementModule", function() { return UserManagementModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__users_management_component__ = __webpack_require__("./src/app/components/users-management/users-management.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__users_management_routing__ = __webpack_require__("./src/app/components/users-management/users-management.routing.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var UserManagementModule = /** @class */ (function () {
    function UserManagementModule() {
    }
    UserManagementModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            declarations: [
                __WEBPACK_IMPORTED_MODULE_3__users_management_component__["a" /* UsersManagementComponent */],
            ],
            exports: [],
            imports: [
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_4_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_6__users_management_routing__["a" /* UserManagementRouting */]
            ],
            providers: []
        })
    ], UserManagementModule);
    return UserManagementModule;
}());



/***/ }),

/***/ "./src/app/components/users-management/users-management.routing.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserManagementRouting; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__users_management_component__ = __webpack_require__("./src/app/components/users-management/users-management.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var UserManagementRouting = /** @class */ (function () {
    function UserManagementRouting() {
    }
    UserManagementRouting = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__users_management_component__["a" /* UsersManagementComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                redirectTo: 'user'
                            },
                            {
                                path: 'user',
                                loadChildren: 'app/components/users-management/users/users.module#UserModule'
                            },
                            {
                                path: 'role',
                                loadChildren: 'app/components/users-management/role-management/role-management.module#RoleManagementModule'
                            },
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], UserManagementRouting);
    return UserManagementRouting;
}());



/***/ })

});
//# sourceMappingURL=users-management.module.chunk.js.map