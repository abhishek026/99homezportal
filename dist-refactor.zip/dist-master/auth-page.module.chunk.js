webpackJsonp(["auth-page.module"],{

/***/ "./src/app/components/auth-page/auth-page-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AuthPageRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__auth_page_component__ = __webpack_require__("./src/app/components/auth-page/auth-page.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__login_page_login_page_component__ = __webpack_require__("./src/app/components/auth-page/login-page/login-page.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var AuthPageRoutingModule = /** @class */ (function () {
    function AuthPageRoutingModule() {
    }
    AuthPageRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__auth_page_component__["a" /* AuthPageComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                component: __WEBPACK_IMPORTED_MODULE_3__login_page_login_page_component__["a" /* LoginPageComponent */]
                            },
                            {
                                path: 'loginAuth',
                                component: __WEBPACK_IMPORTED_MODULE_3__login_page_login_page_component__["a" /* LoginPageComponent */],
                                pathMatch: 'prefix',
                            }
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], AuthPageRoutingModule);
    return AuthPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/auth-page/auth-page.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet>\r\n  </router-outlet>\r\n"

/***/ }),

/***/ "./src/app/components/auth-page/auth-page.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/auth-page/auth-page.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AuthPageComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var AuthPageComponent = /** @class */ (function () {
    function AuthPageComponent() {
    }
    AuthPageComponent.prototype.ngOnInit = function () {
    };
    AuthPageComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-auth-page',
            template: __webpack_require__("./src/app/components/auth-page/auth-page.component.html"),
            styles: [__webpack_require__("./src/app/components/auth-page/auth-page.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], AuthPageComponent);
    return AuthPageComponent;
}());



/***/ }),

/***/ "./src/app/components/auth-page/auth-page.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthPageModule", function() { return AuthPageModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__auth_page_component__ = __webpack_require__("./src/app/components/auth-page/auth-page.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__auth_page_routing_module__ = __webpack_require__("./src/app/components/auth-page/auth-page-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__login_page_login_page_component__ = __webpack_require__("./src/app/components/auth-page/login-page/login-page.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




/* Modules */


var AuthPageModule = /** @class */ (function () {
    function AuthPageModule() {
    }
    AuthPageModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_4__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_4__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_3__auth_page_routing_module__["a" /* AuthPageRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_2__auth_page_component__["a" /* AuthPageComponent */],
                __WEBPACK_IMPORTED_MODULE_5__login_page_login_page_component__["a" /* LoginPageComponent */]
            ],
            entryComponents: [],
            providers: []
        })
    ], AuthPageModule);
    return AuthPageModule;
}());



/***/ }),

/***/ "./src/app/components/auth-page/login-page/login-page.component.html":
/***/ (function(module, exports) {

module.exports = "<div #backgroundChange>\r\n  <div class=\"middle-section clearFix\">\r\n\r\n    <div class=\"auth-page-header\" *ngIf=\"isProcturVisible\">\r\n      <div class=\"row proctur-logo\">\r\n        <div class=\"c-lg-6\" [ngStyle]=\"dynamicImgSrc == ''  && {'visibility':'hidden'}\">\r\n          <img class=\"logo\" [src]=\"dynamicImgSrc\" alt=\"Logo\" height=\"\">\r\n        </div>\r\n        <div class=\"c-lg-6\" style=\"padding-top:10px;\">\r\n          <h5 *ngIf=\"isProcturVisible\">New to Proctur?\r\n            <input type=\"button\" value=\"Get Advice\" (click)=\"openGetAdvice()\" class=\"fullBlue btn login-btn\">\r\n          </h5>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"auth-page-virtual\" *ngIf=\"!isProcturVisible\">\r\n      <div class=\"row proctur-logo\">\r\n        <div class=\"c-lg-6\" [ngStyle]=\"dynamicImgSrc == ''  && {'visibility':'hidden'}\">\r\n          <img class=\"logo\" [src]=\"dynamicImgSrc\" alt=\"Logo\" height=\"\">\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"box\" *ngIf=\"isProcturVisible\">\r\n      <!-- Login Marketing Data DIV Start -->\r\n      <div class=\"login-wrapper\" *ngIf=\"isProcturVisible\">\r\n        <div class=\"row\">\r\n          <div class=\"c-xs-8\">\r\n            <ul class=\"social-icons\">\r\n              <li  class=\"procturSiliconDiv\">\r\n                <a href=\"https://education.siliconindia.com/others/institution/education-apps-2019-proctur-cid-11246.html\" style=\"cursor: pointer;\" target=\"_blank\">  \r\n                  <span style=\"font-size: 18px;\">Proctur</span>\r\n                <span> is now featured in</span>&nbsp;\r\n                <img src=\"../../../../assets/images/proctur_silicon.png\" class=\"procturSiliconImg\"></a>\r\n              </li>\r\n            </ul>\r\n          </div>\r\n          <div class=\"c-xs-4\"></div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"c-lg-8 detailslog\">\r\n            <div style=\"margin-top: 25px;\" class=\"second-left-div-wrapper row\">\r\n              <h2>Accept Fees Using Online Payments </h2>\r\n              <div class=\"left-p-div\">\r\n                <p>Instant transfer. Ease of access. Secured and hassle free mode of payment!</p>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"second-left-div-wrapper row\">\r\n              <h2>Introducing Smart Enquiry Management </h2>\r\n              <div class=\"left-p-div\">\r\n                <p>Add enquiries instantly with our easy to understand interface.</p>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"second-left-div-wrapper row\">\r\n              <h2>Easy Student Admission And Course Management </h2>\r\n              <div class=\"left-p-div\">\r\n                <p>Manage student admmission, fee and courses on the go.</p>\r\n              </div>\r\n            </div>\r\n\r\n          </div>\r\n          <div class=\"c-lg-4\">\r\n          </div>\r\n        </div>\r\n        <div class=\"footer-wrapper row\">\r\n          <hr style=\"margin: 0;\">\r\n        </div>\r\n        <!-- Contact Login Wrapper -->\r\n        <div class=\"row footer-contact-wrapper\">\r\n          <div class=\"c-xs-6\">\r\n            <div class=\"c-xs-1\">\r\n              <i class=\"fa fa-phone call-icon\"></i>\r\n            </div>\r\n            <div style=\"margin-left: 10px;\" class=\"c-xs-4 cursor-point\">\r\n              <p>\r\n                CALL FOR SUPPORT\r\n                <br>\r\n                <span>9971831677</span>\r\n                <br>\r\n                <span>9953366316</span>\r\n              </p>\r\n            </div>\r\n            <div class=\"c-xs-2\">\r\n              <a href=\"https://play.google.com/store/apps/details?id=com.proctur.adminV2\" target=\"_blanks\">\r\n                <img src=\"./assets/images/gapps1.png\" alt=\"Proctur Andriod Mobile Application for Coaching Institutes\">\r\n              </a>\r\n            </div>\r\n            <div class=\"c-xs-2\">\r\n              <a href=\"https://itunes.apple.com/us/app/proctur-admin/id1352882235\" target=\"_blanks\">\r\n                <img src=\"./assets/images/gapps2.png\" alt=\"Proctur iOS Mobile Application for Coaching Institutes\">\r\n              </a>\r\n            </div>\r\n            <div class=\"c-xs-3\">\r\n\r\n            </div>\r\n          </div>\r\n          <div class=\"c-xs-6\"></div>\r\n          <div class=\"row\">\r\n            <div class=\"c-xs-8\">\r\n              <ul class=\"social-icons\">\r\n                <li>\r\n                  <a href=\"https://www.facebook.com/proctur\" class=\"social-icon\" target=\"_blank\">\r\n                    <i class=\"icons fab fa-facebook-square\"></i>\r\n                  </a>\r\n                </li>\r\n  \r\n                <li>\r\n                  <a href=\"https://twitter.com/proctur_in\" class=\"social-icon\" target=\"_blank\">\r\n                    <i class=\"icons fab fa-twitter-square\"></i>\r\n                  </a>\r\n                </li>\r\n  \r\n                <li>\r\n                  <a href=\"https://bit.ly/2t4XFbM\" class=\"social-icon\" target=\"_blank\">\r\n                    <i class=\"icons fab fa-youtube-square\"></i>\r\n                  </a>\r\n                </li>\r\n                <li>\r\n                  <a href=\"https://www.instagram.com/proctur3300/\" class=\"social-icon\" target=\"_blank\">\r\n                    <i class=\"icons fab fa-instagram\"></i>\r\n                  </a>\r\n                </li>\r\n                <li>\r\n                  <a href=\"https://www.linkedin.com/company/proctur\" class=\"social-icon\" target=\"_blank\">\r\n                    <i class=\"icons fab fa-linkedin-square\"></i>\r\n                  </a>\r\n                </li>\r\n              </ul>\r\n            </div>\r\n            <div class=\"c-xs-4\"></div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <!-- Login Marketing Data DIV END -->\r\n    </div>\r\n    <!-- Login Box -->\r\n    <div #virtualStyle>\r\n      <div class=\"login-form-wrapper\">\r\n        <div class=\"row\">\r\n          <h2 *ngIf=\"!isGuestUserCourse\">Login to Dashboard</h2>\r\n          <h2 *ngIf=\"isGuestUserCourse\">Select your courses</h2>\r\n        </div>\r\n        <div class=\"row\" *ngIf=\"isLoginView &&(!isGuestUserCourse)\">\r\n          <div class=\"field-wrapper has-value\">\r\n            <input class=\"form-ctrl\" type=\"text\" [(ngModel)]=\"loginDataForm.alternate_email_id\" name=\"alternate_email_id\" id=\"emailid\"\r\n              placeholder=\"Enter your Mobile or Email\" #emailid=\"ngModel\" required (keyup.enter)=\"loginViaServer()\">\r\n            <div *ngIf=\"emailid.invalid && (emailid.dirty || emailid.touched || no_email_found)\" class=\"alert invalid-alert\">\r\n              <div *ngIf=\"emailid.errors.required\">\r\n                Please enter valid Email ID/Mobile number\r\n              </div>\r\n            </div>\r\n            <label for=\"emailid\"></label>\r\n          </div>\r\n          <div class=\"row\" style=\"margin:0;\">\r\n            <div class=\"field-wrapper has-value password\">\r\n              <input class=\"form-ctrl\" type=\"password\" [(ngModel)]=\"loginDataForm.password\" name=\"password\" id=\"password\" #password=\"ngModel\"\r\n                placeholder=\"Password\" required (keyup.enter)=\"loginViaServer()\">\r\n              <div *ngIf=\"password.invalid && (password.dirty || password.touched)\" class=\"alert invalid-alert\">\r\n                <div *ngIf=\"password.errors.required\">\r\n                  Please enter Password\r\n                </div>\r\n              </div>\r\n              <label for=\"password\"></label>\r\n            </div>\r\n          </div>\r\n          <div class=\"row\">\r\n            <div class=\"forgot-password\" (click)=\"forgotPassword()\">\r\n              <a style=\"cursor:pointer\">Forgot Password?</a>\r\n            </div>\r\n          </div>\r\n          <div class=\"row\" style=\"text-align:center\" *ngIf=\"isGuestUser\">\r\n            <div class=\"login-field-btn\">\r\n\r\n              <p class=\"user-ex\">\r\n                If you don't have account  ?\r\n              <a routerLink=\"/guest/register\" style=\"font-weight: 600;\"> &nbsp;&nbsp; Register here</a>\r\n              </p>\r\n            </div>\r\n          </div>\r\n          <div class=\"row\" style=\"text-align:center\">\r\n            <div class=\"login-field-btn\">\r\n              <input type=\"button\" value=\"Secure Login\" id=\"btnSecureLogin\" (click)=\"loginViaServer()\" class=\"fullBlue btn login-btn\">\r\n              <p class=\"user-ex\">\r\n                For best user experience use Google Chrome Browser\r\n              </p>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"row agreement-row\" *ngIf=\"isProcturVisible\">\r\n            <p>\r\n              By signing in you agree to our\r\n              <a style=\"cursor:pointer\" href=\"https://proctur.com/policy/index.html\" target=\"_blank\">Privacy Policy</a> and\r\n              <a style=\"cursor:pointer\" href=\"https://proctur.com/terms/index.html\" target=\"_blank\">terms of use</a>.\r\n            </p>\r\n          </div>\r\n        </div>\r\n        <!-- Show Insititue List -->\r\n        <div class=\"row\" *ngIf=\"!isLoginView && isInstituteListPop\">\r\n          <div class=\"field-wrapper\" style=\"margin:0;\">\r\n            <p>You are registered with multiple Institutes, Kindly select one to Continue</p>\r\n          </div>\r\n          <div class=\"insititue-field-wrapper\">\r\n            <div class=\"row\" *ngFor=\"let institute of instituteListArr\">\r\n              <div class=\"field-institute-wrapper\" (click)=\"alternateLoginMultiInstituteData(institute.userId, institute.institute_id)\">\r\n                {{institute.institute_name}}\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <!-- Show Insititute List End -->\r\n        <!-- Show User List -->\r\n        <div class=\"row\" *ngIf=\"!isLoginView && isUserListPop\">\r\n          <div class=\"field-wrapper\" style=\"margin:0;\">\r\n            <p>You are registered with multiple Roles, Kindly select one to Continue</p>\r\n          </div>\r\n          <div class=\"field-wrapper insititute-field-wrapper\">\r\n            <h2 class=\"insititue-list-header\">Login as</h2>\r\n          </div>\r\n          <div class=\"insititue-field-wrapper\">\r\n            <div class=\"row\" *ngFor=\"let user of userListArr\">\r\n              <div class=\"field-institute-wrapper\" (click)=\"alternateLoginMultiUserData(user.userID,user.user_role,user.institute_id)\">\r\n                {{user.userType}}\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <!-- Show User List End -->\r\n        <!-- OTP verification Start -->\r\n        <div class=\"row\" *ngIf=\"!isLoginView && OTPVerificationPopUp\">\r\n          <div class=\"field-wrapper insititute-field-wrapper\">\r\n            <h2 class=\"insititue-list-header\" style=\"padding-right:20px;\">Enter One Time Password</h2>\r\n          </div>\r\n          <div class=\"field-wrapper\" style=\"margin:0;\">\r\n            <p>One Time Password (OTP) has been sent to your mobile and/or email, please enter the same\r\n              here to login.</p>\r\n          </div>\r\n          <div class=\"form-type1\">\r\n            <div class=\"field-wrapper has-value\">\r\n              <label>OTP</label>\r\n              <input type=\"text\" value=\"\" class=\"form-ctrl\" [(ngModel)]=\"otpVerificationInfo.otp_code\" maxlength=\"4\" name=\"otpData\" id=\"otpData\"\r\n                #otpData=\"ngModel\" enquiryInput required style=\"margin-top: 18px;\">\r\n              <div *ngIf=\"otpData.invalid && (otpData.dirty || otpData.touched)\" class=\"alert invalid-alert\">\r\n                <div *ngIf=\"otpData.errors.required\">\r\n                  Please enter OTP.\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"row\" *ngIf=\"counter != 0\">\r\n            <div class=\"forgot-password\" style=\"margin-right:18%;\">\r\n              <a style=\"cursor:pointer\">Resend in 00:{{countDown | async}}</a>\r\n            </div>\r\n          </div>\r\n          <div class=\"row\" *ngIf=\"counter == 0\">\r\n            <div class=\"forgot-password\" style=\"margin-right:18%;\">\r\n              <!-- <span style=\"cursor:pointer\" (click)=\"alternateLoginOTPRegenerate()\">Resend</span> -->\r\n              <a style=\"cursor:pointer\" (click)=\"alternateLoginOTPRegenerate()\">Resend?</a>\r\n            </div>\r\n          </div>\r\n          <div class=\"row\" style=\"text-align:center; margin-top:2%; margin-bottom: 15px;\">\r\n            <div class=\"login-field-btn\">\r\n              <input type=\"button\" value=\"VERIFY\" (click)=\"alternateLoginOTPVerification()\" class=\"fullBlue btn\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <!-- OTP verification End -->\r\n\r\n        <!-- Show User List -->\r\n        <div class=\"row\" *ngIf=\"isGuestUserCourse\">\r\n          <div class=\"insititue-field-wrapper pull-left\" style=\"margin-left: 4rem;overflow-y: scroll;height: 250px;\">\r\n            <table>\r\n              <tbody>\r\n                <tr *ngFor=\"let data of courses ; let i=index\" style=\"border: unset;\">\r\n                  <td class=\"checkBoxCss\" style=\"border: unset;\r\n                  padding: 5px 0px\">\r\n                    <div class=\"field-checkbox-wrapper pull-left\">\r\n                      <input type=\"checkbox\" class=\"form-checkbox\" [checked]=\"data.checked\" (change)=\"toggleCheckbox($event,data)\" [id]=\"'checkbox-'+i\">\r\n                      <label [for]=\"'checkbox-'+i\"></label>\r\n                      <p style=\"    display: block; color:#0084f6;\r\n                      margin: 10px;     margin-bottom: 0px;\">{{data.course_type}}</p>\r\n                    </div>\r\n                  </td>\r\n                </tr>\r\n              </tbody>\r\n            </table>\r\n\r\n          </div>\r\n          <!-- Show User List End -->\r\n        </div>\r\n        <div class=\"row text-center\"  *ngIf=\"isGuestUserCourse\">\r\n          <div class=\"login-field-btn\">\r\n            <input type=\"button\" value=\"Select\" id=\"btnSecureLogin\" class=\"fullBlue btn \" (click)=\"updateCourseforGuestUser()\">\r\n            <input type=\"button\" value=\"Cancel\" id=\"btnSecureLogin\" class=\"btn\" (click)=\"gotoStudentPortal()\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n"

/***/ }),

/***/ "./src/app/components/auth-page/login-page/login-page.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/* Login Page Background */\n.bg-img {\n  top: 0px;\n  left: 0px;\n  bottom: 0px;\n  right: 0px;\n  width: 100%;\n  height: 100%;\n  position: fixed;\n  background-color: #004a7e;\n  background-size: cover;\n  /* background-color: #004a7e;\r\n    position: absolute;\r\n    overflow: auto;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    background: linear-gradient(to right bottom, rgba(0, 72, 126, .97), rgba(0, 74, 126, .97) 50%, rgba(114, 183, 227, .97)); */ }\n.bg-img:before {\n    content: '';\n    background-color: #004a7e;\n    position: absolute;\n    top: 0;\n    right: 0;\n    bottom: 0;\n    left: 0;\n    background-image: -webkit-gradient(linear, left top, right bottom, from(rgba(0, 72, 126, 0.97)), color-stop(50%, rgba(0, 74, 126, 0.97)), to(rgba(114, 183, 227, 0.97)));\n    background-image: linear-gradient(to right bottom, rgba(0, 72, 126, 0.97), rgba(0, 74, 126, 0.97) 50%, rgba(114, 183, 227, 0.97));\n    opacity: .6; }\n.user-ex {\n  margin-top: 15px;\n  /* margin-bottom: 30%; */\n  width: 75%;\n  margin-left: 15%;\n  text-align: left;\n  font-size: 11px; }\n.bg-img-virtual {\n  top: 0px;\n  left: 0px;\n  bottom: 0px;\n  right: 0px;\n  width: 100%;\n  height: 100%;\n  position: fixed;\n  background-size: cover; }\n.bg-img-virtual:before {\n    content: '';\n    position: absolute;\n    top: 0;\n    right: 0;\n    bottom: 0;\n    left: 0;\n    opacity: .6; }\n.detailslog {\n  padding: 10px 30px 10px 30px;\n  min-height: 300px; }\n.box {\n  position: relative;\n  margin: auto;\n  top: 25px;\n  left: 0;\n  right: 0;\n  width: 80%;\n  border-radius: 4px;\n  background: #eaeaea;\n  margin-bottom: 100px;\n  -webkit-box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2);\n          box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2);\n  overflow: hidden;\n  z-index: 1; }\n.login-box {\n  position: absolute;\n  margin: auto;\n  top: 75px;\n  right: 14%;\n  width: 320px;\n  border-radius: 4px;\n  background: white;\n  margin-bottom: 100px;\n  -webkit-box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.15), 0 0 2px 0 rgba(0, 0, 0, 0.2);\n          box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.15), 0 0 2px 0 rgba(0, 0, 0, 0.2);\n  overflow: hidden;\n  z-index: 2;\n  -webkit-transition: left 0.1s cubic-bezier(0.175, 0.885, 0.26, 1.055);\n  transition: left 0.1s cubic-bezier(0.175, 0.885, 0.26, 1.055); }\n#header {\n  background: #009688;\n  position: relative;\n  text-align: center;\n  height: 100px;\n  width: 100%;\n  margin-bottom: 30px; }\n#cont-lock {\n  width: 100%;\n  height: 65px;\n  position: relative;\n  padding: 10px;\n  font-size: 36px;\n  font-weight: normal;\n  color: white; }\n.lock {\n  text-align: center;\n  color: white;\n  position: absolute;\n  left: 0;\n  right: 0;\n  margin: 0;\n  top: 0;\n  bottom: 0;\n  line-height: 65px;\n  font-size: 28px; }\n#bottom-head {\n  position: relative;\n  background: #00796b;\n  height: 35px; }\n#bottom-head::after {\n  content: '';\n  width: 0px;\n  height: 0px;\n  display: block;\n  position: absolute;\n  margin: auto;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  border-bottom: 7px solid white;\n  border-right: 7px solid rgba(0, 0, 0, 0);\n  border-left: 7px solid rgba(0, 0, 0, 0);\n  border-top: 7px solid rgba(0, 0, 0, 0); }\n.box h1 {\n  margin: 0;\n  font-size: 24px;\n  font-weight: 300;\n  color: #cfd8dc;\n  line-height: 35px; }\n.box button {\n  background: #cfd8dc;\n  border: 0;\n  color: #009688;\n  padding: 10px;\n  font-size: 16px;\n  font-weight: 300;\n  width: 330px;\n  margin: 20px auto;\n  display: block;\n  cursor: pointer;\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s;\n  border-radius: 2px; }\n.box button:active {\n  background: #009688;\n  color: #263238; }\n.box button:hover {\n  background: #009688;\n  color: #FFF;\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s; }\n.box p {\n  font-size: 14px;\n  text-align: center; }\n.group {\n  position: relative;\n  margin-bottom: 35px;\n  margin-left: 40px; }\n.inputMaterial {\n  font-size: 18px;\n  padding: 10px 10px 10px 5px;\n  display: block;\n  width: 300px;\n  border: none;\n  border-bottom: 1px solid #757575; }\n.inputMaterial:focus {\n  outline: none; }\n/* LABEL ======================================= */\nlabel {\n  color: #999;\n  font-size: 14px;\n  font-weight: normal;\n  position: absolute;\n  pointer-events: none;\n  left: 5px;\n  top: 10px;\n  transition: 0.1s ease all;\n  -moz-transition: 0.1s ease all;\n  -webkit-transition: 0.1s ease all; }\n/* active state */\n.inputMaterial:focus ~ label,\n.inputMaterial:valid ~ label {\n  top: -20px;\n  font-size: 14px;\n  color: #009688; }\n/* BOTTOM BARS ================================= */\n.bar {\n  position: relative;\n  display: block;\n  width: 315px; }\n.bar:before,\n.bar:after {\n  content: '';\n  height: 2px;\n  width: 0;\n  bottom: 1px;\n  position: absolute;\n  background: #009688;\n  transition: 0.1s ease all;\n  -moz-transition: 0.1s ease all;\n  -webkit-transition: 0.1s ease all; }\n.bar:before {\n  left: 50%; }\n.bar:after {\n  right: 50%; }\n/* active state */\n.inputMaterial:focus ~ .bar:before,\n.inputMaterial:focus ~ .bar:after {\n  width: 50%; }\n.boxNew {\n  position: relative;\n  margin: auto;\n  top: 14vh;\n  left: 0;\n  right: 0;\n  width: 80%;\n  border-radius: 4px;\n  background: #eaeaea;\n  margin-bottom: 100px;\n  -webkit-box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2);\n          box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2);\n  overflow: hidden;\n  z-index: 1; }\n/* active state */\n.inputMaterial:focus ~ .highlight {\n  -webkit-animation: inputHighlighter 0.3s ease;\n  animation: inputHighlighter 0.3s ease; }\n/* ANIMATIONS ================ */\n@-webkit-keyframes inputHighlighter {\n  from {\n    background: #5264AE; }\n  to {\n    width: 0;\n    background: transparent; } }\n@keyframes inputHighlighter {\n  from {\n    background: #5264AE; }\n  to {\n    width: 0;\n    background: transparent; } }\n#footer-box {\n  width: 100%;\n  height: 50px;\n  background: #00695c;\n  position: absolute;\n  bottom: 0; }\n.footer-text {\n  color: #cfd8dc; }\n.sign-up {\n  color: white;\n  cursor: pointer; }\n.sign-up:hover {\n  color: #b2dfdb; }\n.field-radio-wrapper {\n  margin: 30px 10px; }\n.field-radio-wrapper .form-radio {\n    margin: 6px 0px;\n    padding: 0px; }\n.field-radio-wrapper label {\n    padding: 1px 20px; }\n.auth-page-header {\n  position: relative;\n  top: 0;\n  left: 0;\n  width: 100%; }\n.auth-page-header .row {\n    margin-left: 15%;\n    padding-top: 10px; }\n.auth-page-header h5 {\n    color: white; }\n.login-wrapper .row {\n  width: 100%;\n  margin: 0px;\n  padding: 5px;\n  color: #58666e; }\n.login-wrapper .row h2 {\n    color: #58666e;\n    font-weight: 600; }\n.login-wrapper .row hr {\n    border: 0.5px ridge #c1bfbf; }\n.login-wrapper .row .left-div-wrapper {\n    left: 5%;\n    top: 60px; }\n.login-wrapper .row .footer-wrapper {\n    margin-top: 25%;\n    width: 100%; }\n.login-wrapper .row .second-left-div-wrapper {\n    left: 5%;\n    top: 60px;\n    margin-top: 40px; }\n.login-wrapper .row .left-p-div {\n    margin-top: 12px; }\n.login-wrapper .row p {\n    text-align: left; }\n.login-wrapper .row .call-icon {\n    font-family: FontAwesome;\n    border: 1px solid;\n    width: 40px;\n    height: 40px;\n    padding-left: 8px;\n    vertical-align: middle;\n    border-radius: 10px;\n    font-size: 30px;\n    color: #17384b;\n    padding-top: 2px;\n    margin-top: 4px; }\n.login-wrapper .row .footer-contact-wrapper {\n    padding: 10px 40px 0px 10px; }\n.login-wrapper .row .footer-contact-wrapper .c-xs-6 {\n      padding-left: 30px;\n      color: #17384b; }\n.login-wrapper .row .footer-contact-wrapper span {\n      font-size: 22px; }\n.login-wrapper ul.social-icons {\n  padding: 5px 15px; }\n.login-wrapper ul.social-icons li {\n    display: inline; }\n.login-wrapper ul.social-icons li .icons {\n      font-family: FontAwesome;\n      margin: 0px 5px;\n      font-size: 20px; }\n.login-virtual {\n  height: auto;\n  padding-bottom: 4vh;\n  position: absolute;\n  left: 0px;\n  right: 0px;\n  margin: auto;\n  top: 157px;\n  /* right: 32%; */\n  width: 320px;\n  border-radius: 4px;\n  background: white;\n  margin-bottom: 100px;\n  -webkit-box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.15), 0 0 2px 0 rgba(0, 0, 0, 0.2);\n  box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.15), 0 0 2px 0 rgba(0, 0, 0, 0.2);\n  overflow: hidden;\n  z-index: 2;\n  -webkit-transition: left 0.1s cubic-bezier(0.175, 0.885, 0.26, 1.055);\n  transition: left 0.1s cubic-bezier(0.175, 0.885, 0.26, 1.055); }\n.auth-page-virtual {\n  position: relative;\n  top: 4vh;\n  left: 37%;\n  width: 100%; }\n.auth-page-virtual .row {\n    margin: 0 5%;\n    padding-top: 10px; }\n.login-form-wrapper .row {\n  margin: 0px; }\n.login-form-wrapper h2 {\n  padding: 40px 80px 10px 52px;\n  color: #58666e; }\n.login-form-wrapper .field-wrapper {\n  width: 70%;\n  left: 15%;\n  margin-top: 10%; }\n.login-form-wrapper .password {\n  margin-top: 5%; }\n.login-form-wrapper .forgot-password {\n  float: right;\n  margin-right: 12%;\n  padding-top: 5px; }\n.login-form-wrapper .login-field-btn .login-btn {\n  margin-top: 5%;\n  width: 70%; }\n.login-form-wrapper .agreement-row {\n  margin-top: 20%;\n  margin-bottom: 30%;\n  width: 75%;\n  margin-left: 15%; }\n.login-form-wrapper .insititute-field-wrapper {\n  width: 90%;\n  left: 0%;\n  margin: 0; }\n.login-form-wrapper .insititute-field-wrapper .insititue-list-header {\n    padding: 10px 80px 0px 52px; }\n.login-form-wrapper .insititue-field-wrapper {\n  height: 350px;\n  overflow-y: auto; }\n.login-form-wrapper .insititue-field-wrapper .row {\n    margin: 0px; }\n.login-form-wrapper .insititue-field-wrapper .field-institute-wrapper {\n    margin: 10px 40px;\n    margin-bottom: 0;\n    cursor: pointer;\n    padding: 15px;\n    -webkit-box-shadow: 1px 1px 10px 0 rgba(0, 0, 0, 0.15), 0 0 2px 0 rgba(0, 0, 0, 0.2);\n            box-shadow: 1px 1px 10px 0 rgba(0, 0, 0, 0.15), 0 0 2px 0 rgba(0, 0, 0, 0.2); }\n.login-form-wrapper .insititue-field-wrapper .field-institute-wrapper::after {\n      content: '\\2794';\n      color: #58666e;\n      font-size: 20px;\n      float: right; }\n.field-wrapper .invalid-alert {\n  color: red;\n  background: rgba(255, 255, 255, 0);\n  -webkit-box-shadow: none;\n          box-shadow: none; }\n.field-radio-wrapper .form-radio + label:after {\n  left: 2px !important;\n  top: 2px !important; }\n.cursor-point {\n  cursor: pointer; }\n@media only screen and (max-width: 1200px) {\n  .login-box {\n    top: 115px !important; }\n  .detailslog {\n    width: 60%; } }\n@media only screen and (max-width: 985px) {\n  .detailslog {\n    width: 50%; } }\n@media only screen and (max-width: 800px) {\n  .box {\n    display: none; }\n  .auth-page-header {\n    position: relative;\n    top: 0;\n    left: 35%;\n    width: 100%; }\n    .auth-page-header .row {\n      margin: 0 5%;\n      padding-top: 10px; }\n  .login-box {\n    top: 135px !important;\n    height: 70%;\n    left: 30%; } }\n@media only screen and (max-width: 550px) {\n  .box {\n    display: none; }\n  .auth-page-header {\n    position: relative;\n    top: 0;\n    left: 15%;\n    width: 100%; }\n    .auth-page-header .row {\n      margin: 0 5%;\n      padding-top: 10px; }\n  .login-box {\n    top: 135px !important;\n    height: 70%;\n    left: 10%; } }\ntable tr:nth-child(even):hover {\n  background: white; }\ntable tr:nth-child(odd):hover {\n  background: white; }\n.procturSiliconDiv {\n  font-weight: 600;\n  font-size: 14px;\n  cursor: pointer;\n  text-decoration: none;\n  color: #0084f6; }\n.procturSiliconDiv :hover {\n    text-decoration: underline;\n    color: #0084f6; }\n.procturSiliconDiv .procturSiliconImg {\n    min-height: 30%;\n    max-height: 30%;\n    min-width: 30%;\n    max-width: 30%;\n    vertical-align: middle; }\n"

/***/ }),

/***/ "./src/app/components/auth-page/login-page/login-page.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LoginPageComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_rxjs__ = __webpack_require__("./node_modules/rxjs/Rx.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_rxjs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_rxjs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_platform_browser__ = __webpack_require__("./node_modules/@angular/platform-browser/esm5/platform-browser.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_login_services_login_service__ = __webpack_require__("./src/app/services/login-services/login.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_table_preference_table_preferences_service__ = __webpack_require__("./src/app/services/table-preference/table-preferences.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};










var LoginPageComponent = /** @class */ (function () {
    function LoginPageComponent(login, route, msgService, auth, titleService, _tablePreferencesService, activatedRoute, _commService) {
        var _this = this;
        this.login = login;
        this.route = route;
        this.msgService = msgService;
        this.auth = auth;
        this.titleService = titleService;
        this._tablePreferencesService = _tablePreferencesService;
        this.activatedRoute = activatedRoute;
        this._commService = _commService;
        this.selectedCourseNames = [];
        this.courses = [];
        this.userListArr = [];
        this.instituteListArr = [];
        this.dynamicImgSrc = '';
        this.baseUrl = '';
        this.counter = 30;
        this.no_email_found = false;
        this.isProcturVisible = false;
        this.isLoginView = true;
        this.isInstituteListPop = false;
        this.OTPVerificationPopUp = false;
        this.isUserListPop = false;
        this.loading = false;
        this.isGuestUser = false;
        this.isGuestUserCourse = false;
        this.countryDetails = [{}];
        this.instituteListObj = {
            institute_id: "",
            institute_name: "",
            userId: ""
        };
        this.multiUserListObj = {
            alternate_email_id: "",
            password: "",
            institution_id: "",
            userID: "",
            userType: "",
            user_role: ""
        };
        this.multiInstituteLoginInfo = {
            alternate_email_id: "",
            password: "",
            userid: "",
            institution_id: ""
        };
        this.multiUserLoginInfo = {
            alternate_email_id: "",
            password: "",
            userid: "",
            institution_id: "",
            user_role: ""
        };
        this.otpVerificationInfo = {
            otp_code: "",
            mobile_no: "",
            alternate_email_id: "",
            password: "",
            userid: "",
            otp_validate_mode: 1
        };
        this.messages = msgService.getMessages();
        if (sessionStorage.getItem('userid') != null) {
            this.loginDataForm = {
                alternate_email_id: "",
                password: ""
            };
            this.createRoleBasedSidenav();
        }
        else {
            this.loginDataForm = {
                alternate_email_id: "",
                password: ""
            };
        }
        //     sessionStorage.clear();
        //     this.auth.clearStoredData();
        //     this.auth.getAuthToken();
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_3__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrlStudent();
    }
    LoginPageComponent.prototype.ngOnInit = function () {
        var _this = this;
        var url = window.location.href;
        if (url.indexOf("?") > -1) {
            var arr = url.split('?');
            if (url.length > 1 && arr[1] !== '') {
                this.activatedRoute.queryParams.subscribe(function (params) {
                    _this.loginDataForm.alternate_email_id = params['user'];
                    _this.loginDataForm.password = atob(params['pass']);
                    _this.loginViaServer();
                });
            }
        }
        this.checkWebUrlForGenerics();
    };
    LoginPageComponent.prototype.ngOnDestroy = function () {
        this.isProcturVisible = true;
    };
    LoginPageComponent.prototype.createTablePreferences = function () {
        console.log(sessionStorage.getItem('course_structure_flag'));
        if (sessionStorage.getItem('userid') != null && sessionStorage.getItem('course_structure_flag')) {
            if (!this._tablePreferencesService.getTablePreferences('procturTablePreference')) {
                this._tablePreferencesService.createdLocalStorageStructure({ userId: sessionStorage.getItem('userid'), role: sessionStorage.getItem('course_structure_flag') });
            }
        }
    };
    LoginPageComponent.prototype.checkWebUrlForGenerics = function () {
        var url = window.location.href;
        var test = url.split("/")[2];
        if (test === "webtest.proctur.com" || test === "web.proctur.com" || test === "localhost:4200") {
            this.isProcturVisible = true;
            this.backgroundChange.nativeElement.className = "bg-img";
            this.dynamicImgSrc = "./assets/images/logoProctur.png";
            this.virtualStyle.nativeElement.className = "login-box";
            this.titleService.setTitle('Proctur - Your Pocket Classroom');
            sessionStorage.setItem('institute_title_web', 'Proctur - Your Pocket Classroom');
            sessionStorage.setItem('institute_logo_web', this.dynamicImgSrc);
            // this.checkForVirtualHost("webtest.proctur.com"); // for guest user
            // this.isProcturVisible = false;
            // this.backgroundChange.nativeElement.className = "bg-img-virtual"
            // this.virtualStyle.nativeElement.className = "login-virtual"
            // this.titleService.setTitle("Login");
            // sessionStorage.setItem('institute_title_web', 'Login');
        }
        else {
            this.checkForVirtualHost(test);
            this.isProcturVisible = false;
            this.backgroundChange.nativeElement.className = "bg-img-virtual";
            this.virtualStyle.nativeElement.className = "login-virtual";
            this.titleService.setTitle("Login");
            sessionStorage.setItem('institute_title_web', 'Login');
        }
    };
    LoginPageComponent.prototype.checkForVirtualHost = function (str) {
        var _this = this;
        this.login.getLogoAndFavcon(str).subscribe(function (res) {
            if (res != null) {
                _this.isGuestUser = true;
                sessionStorage.setItem('institution_id', res[0].instituteId); // this id is used for guest user registration do not change it
                if (res[0].logoPath != null && res[0].logoPath != "") {
                    _this.dynamicImgSrc = res[0].logoPath;
                }
                if (res[0].favIconPath != null && res[0].favIconPath != "") {
                    sessionStorage.setItem('institute_logo_web', _this.dynamicImgSrc);
                    _this.changeFavICon(res[0].favIconPath);
                }
                if (res[0].title != null && res[0].title != "") {
                    _this.titleService.setTitle(res[0].title + " Login");
                    sessionStorage.setItem('institute_title_web', res[0].title + " Login");
                }
            }
        }, function (err) {
            console.log(err);
        });
    };
    LoginPageComponent.prototype.changeFavICon = function (str) {
        var link = document.getElementById('favIconLink');
        link.type = 'image/x-icon';
        link.rel = 'icon';
        link.href = str;
    };
    /*
      When user fill the login form and tries to login : ( START - 0)
        1. Check if email or password is not empty
        2. Send login Info to Server
    */
    LoginPageComponent.prototype.loginViaServer = function () {
        var _this = this;
        if (this.loginDataForm.alternate_email_id.trim() == "" && this.loginDataForm.password.trim() == "") {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, this.messages.loginMsg.invalid.title, this.messages.loginMsg.invalid.body);
        }
        else if (this.loginDataForm.password.trim() == "") {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, this.messages.loginMsg.invalidPass.title, this.messages.loginMsg.invalidPass.body);
        }
        else {
            this.login.postLoginDetails(this.loginDataForm).subscribe(function (res) {
                console.log(res);
                _this.checkForAuthOptions(res);
            }, function (err) {
                console.log(err);
            });
        }
    };
    //  created by: Nalini Walunj;
    //  description: Below function is written to get country code details of institution based on login details.
    LoginPageComponent.prototype.getCountryDetails = function (institute_id) {
        var _this = this;
        this.login.getInstituteCountryDetails(institute_id).subscribe(function (res) {
            _this.countryDetails = res;
            var country_info = JSON.stringify(res);
            // console.log(country_info);
            sessionStorage.setItem('country_data', country_info);
            for (var i = 0; i < _this.countryDetails.length; i++) {
                var row = _this.countryDetails[i];
                if (row.is_default == 'Y') {
                    var symbol = _this.getCurrencyDetails(900, row.currency_code, row.country_code);
                    _this._commService.setDefaultCurrencySymbol(symbol);
                }
            }
        }, function (err) {
            console.log(err);
        });
    };
    LoginPageComponent.prototype.getCurrencyDetails = function (value, currency, lang) {
        if (value && currency && lang) {
            var formatted = value.toLocaleString(lang, {
                maximumFractionDigits: 4,
                style: 'currency',
                currency: currency
            });
            formatted = formatted.replace(/[,.]/g, '');
            return formatted.replace(/[0-9]/g, '');
        }
        else {
            return lang;
        }
    };
    //END - 0
    //Method to decide where to take user when he/she Logs in (START - 1)
    LoginPageComponent.prototype.checkForAuthOptions = function (res) {
        var login_option = res.login_option;
        switch (login_option) {
            case 1:
                this.OTPVerification(res);
                break;
            case 4:
                this.alternateLoginFailure(res.login_error_message);
                break;
            case 3:
                this.setAuthToken(res.data);
                this.alternateLoginSuccess(res);
                break;
            case 7:
                this.alternateLoginEmailNotVerified();
                break;
            case 6:
                this.alternateLoginMultiInstitute(res);
                break;
            case 5:
                this.alternateLoginMultiUser(res);
                break;
        }
    };
    LoginPageComponent.prototype.setAuthToken = function (institute_data) {
        sessionStorage.setItem('userid', institute_data.userid);
        sessionStorage.setItem('userType', institute_data.userType);
        sessionStorage.setItem('password', institute_data.password);
        sessionStorage.setItem('institute_id', institute_data.institution_id);
        this.auth.getAuthToken();
    };
    //End - 1
    //if login is fails ( Start - 2)
    LoginPageComponent.prototype.alternateLoginFailure = function (obj) {
        this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', obj);
    };
    //End -2
    LoginPageComponent.prototype.validInstituteCheck = function (res) {
        /* Open For All Institute Currently */
        if (res.data.inst_branding_feature == "N" && res.user_type == 99) {
            return false;
        }
        return true;
        /* Code to Resrict Users from login without invitation */
        /* let instIdArr = this.login.getAllInstituteId();
        if (instIdArr.indexOf(data.institution_id) == -1) {
          return false;
        } else {
          return true;
        } */
    };
    //if login is successfull ( Start - 3)
    LoginPageComponent.prototype.alternateLoginSuccess = function (res) {
        if (!this.validInstituteCheck(res)) {
            this.route.navigateByUrl('/authPage');
            //console.log('Institute ID Not Found');
            this.msgService.showErrorMessage(this.msgService.toastTypes.success, "", "There is no access for Open User login in web..Kindly access the same through APP");
            sessionStorage.clear();
            localStorage.clear();
            return;
        }
        else {
            if (res.institution_id != null) {
                this.getCountryDetails(res.institution_id);
            }
            this.serverUserData = res;
            sessionStorage.setItem('institute_info', JSON.stringify(res.data));
            var institute_data = JSON.parse(sessionStorage.getItem('institute_info'));
            var Authorization = btoa(institute_data.userid + "|" + institute_data.userType + ":" + institute_data.password + ":" + institute_data.institution_id);
            this.auth.changeAuthenticationKey(Authorization);
            this.auth.changeInstituteId(institute_data.institution_id);
            sessionStorage.setItem('institute_id', institute_data.institution_id);
            sessionStorage.setItem('institution_id', institute_data.institution_id);
            sessionStorage.setItem('about_us_image', institute_data.about_us_image);
            sessionStorage.setItem('about_us_text', institute_data.about_us_text);
            sessionStorage.setItem('accountId', institute_data.accountId);
            sessionStorage.setItem('alternate_email_id', institute_data.alternate_email_id);
            sessionStorage.setItem('biometric_attendance_feature', institute_data.biometric_attendance_feature);
            sessionStorage.setItem('courseType', institute_data.courseType);
            sessionStorage.setItem('course_structure_flag', institute_data.course_structure_flag);
            this.auth.course_flag.next(institute_data.course_structure_flag);
            sessionStorage.setItem('enable_fee_payment_mandatory_student_creation', institute_data.enable_fee_payment_mandatory_student_creation);
            sessionStorage.setItem('enable_fee_templates', institute_data.enable_fee_templates);
            sessionStorage.setItem('enable_tax_applicable_fee_installments', institute_data.enable_tax_applicable_fee_installments);
            sessionStorage.setItem('enable_vdoCipher_feature', institute_data.enable_vdoCipher_feature);
            sessionStorage.setItem('exam_grading_system', institute_data.exam_grading_system);
            sessionStorage.setItem('fb_page_url', institute_data.fb_page_url);
            sessionStorage.setItem('fee_functionality', institute_data.fee_functionality);
            sessionStorage.setItem('fetaures_map', institute_data.fetaures_map);
            sessionStorage.setItem('inst_email', institute_data.inst_email);
            sessionStorage.setItem('inst_phone', institute_data.inst_phone);
            sessionStorage.setItem('inst_reg_code', institute_data.inst_reg_code);
            sessionStorage.setItem('inst_set_up', institute_data.inst_set_up);
            sessionStorage.setItem('institute_type', institute_data.institute_type);
            this.auth.institute_type.next(institute_data.institute_type);
            this.auth.instituteType_name.next(institute_data.institute_type);
            this.auth.makeInstituteType(institute_data.institute_type, institute_data.course_structure_flag);
            sessionStorage.setItem('institution_footer', institute_data.institution_footer);
            sessionStorage.setItem('institution_header1', institute_data.institution_header1);
            sessionStorage.setItem('institution_header2', institute_data.institution_header2);
            sessionStorage.setItem('institution_header3', institute_data.institution_header3);
            sessionStorage.setItem('institution_logo', institute_data.institution_logo);
            sessionStorage.setItem('institution_name', institute_data.institution_name);
            sessionStorage.setItem('institute_name', institute_data.institute_name);
            sessionStorage.setItem('is_campaign_message_approve_feature', institute_data.is_campaign_message_approve_feature);
            sessionStorage.setItem('allow_sms_approve_feature', res.data.allow_sms_approve_feature);
            sessionStorage.setItem('is_main_branch', institute_data.is_main_branch);
            this.auth.changeMainBranchValue(institute_data.is_main_branch);
            sessionStorage.setItem('is_student_bulk_upload_byClient', institute_data.is_student_bulk_upload_byClient);
            sessionStorage.setItem('is_student_mgmt_flag', institute_data.is_student_mgmt_flag);
            sessionStorage.setItem('login_student_id', institute_data.login_student_id);
            sessionStorage.setItem('login_teacher_id', institute_data.teacherId);
            sessionStorage.setItem('manual_student_disp_id', institute_data.manual_student_disp_id);
            sessionStorage.setItem('online_payment_feature', institute_data.online_payment_feature);
            sessionStorage.setItem('password', institute_data.password);
            sessionStorage.setItem('promoCode', institute_data.promoCode);
            sessionStorage.setItem('religion_feature', institute_data.religion_feature);
            sessionStorage.setItem('student_report_card_fee_module', institute_data.student_report_card_fee_module);
            sessionStorage.setItem('studwise_fee_mod_with_amt', institute_data.studwise_fee_mod_with_amt);
            sessionStorage.setItem('tag_line', institute_data.tag_line);
            sessionStorage.setItem('test_feature', institute_data.test_feature);
            sessionStorage.setItem('testprepEnabled', institute_data.testprepEnabled);
            sessionStorage.setItem('userCat', institute_data.userCat);
            sessionStorage.setItem('userTimeGrp', institute_data.userTimeGrp);
            sessionStorage.setItem('userType', institute_data.userType);
            this.login.changeUserType(institute_data.userType);
            sessionStorage.setItem('user_permission', institute_data.user_permission);
            sessionStorage.setItem('user_type_name', institute_data.user_type_name);
            sessionStorage.setItem('username', institute_data.username);
            sessionStorage.setItem('userid', institute_data.userid);
            sessionStorage.setItem('name', institute_data.name);
            sessionStorage.setItem('about_us_text', institute_data.about_us_text);
            sessionStorage.setItem('mobile_no', institute_data.mobile_no);
            sessionStorage.setItem('inst_announcement', institute_data.inst_announcement);
            sessionStorage.setItem('logo_url', institute_data.logo_url);
            sessionStorage.setItem('permitted_roles', JSON.stringify(res.data.featureDivMapping));
            sessionStorage.setItem('is_exam_grad_feature', institute_data.is_exam_grad_feature);
            sessionStorage.setItem('enable_routing', institute_data.enable_routing);
            sessionStorage.setItem('enable_online_payment_feature', institute_data.enable_online_payment_feature);
            sessionStorage.setItem('open_enq_Visibility_feature', institute_data.open_enq_Visibility_feature);
            sessionStorage.setItem('institute_setup_type', institute_data.institute_setup_type);
            sessionStorage.setItem('enable_elearn_course_mapping_feature', institute_data.enable_elearn_course_mapping_feature);
            sessionStorage.setItem('enable_eLearn_feature', institute_data.enable_eLearn_feature);
            sessionStorage.setItem('website_url', institute_data.website_url);
            if (res.data.permissions == undefined || res.data.permissions == undefined || res.data.permissions == null) {
                sessionStorage.setItem('permissions', '');
                this.login.changePermissions('');
            }
            else {
                sessionStorage.setItem('permissions', JSON.stringify(res.data.permissions.split(',')));
                this.login.changePermissions(JSON.stringify(res.data.permissions.split(',')));
            }
            if (sessionStorage.getItem('userType') == '0' || sessionStorage.getItem('userType') == '3') {
                this.createTablePreferences();
                this.createRoleBasedSidenav();
            }
            else if (sessionStorage.getItem('userType') == '1') {
                sessionStorage.setItem('student_id', res.data.studentId);
                sessionStorage.setItem('institution_id', res.institution_id);
                sessionStorage.setItem('user_type_name', 'Student');
                sessionStorage.setItem('inst_set_up', res.data.institute_setup_type);
                sessionStorage.setItem('institution_name', res.data.institute_name);
                sessionStorage.setItem('is_cobranding', res.data.is_cobranding);
                window.location.href = this.baseUrl + "/sPortal/dashboard.html#/Dashboard";
            }
            else if (sessionStorage.getItem('userType') == '5') {
                sessionStorage.setItem('student_id', res.data.parentStudentList[0].student_id);
                sessionStorage.setItem('user_type_name', 'Parent');
                sessionStorage.setItem('institution_id', res.institution_id);
                sessionStorage.setItem('inst_set_up', res.data.institute_setup_type);
                sessionStorage.setItem('institution_name', res.data.institute_name);
                sessionStorage.setItem('is_cobranding', res.data.is_cobranding);
                window.location.href = this.baseUrl + "/sPortal/dashboard.html#/Dashboard";
            }
            else if (sessionStorage.getItem('userType') == '99' && sessionStorage.getItem('testprepEnabled')
                && institute_data.courseType == "") {
                sessionStorage.setItem('student_id', "0");
                sessionStorage.setItem('institution_id', res.institution_id);
                sessionStorage.setItem('institution_name', res.data.institute_name);
                sessionStorage.setItem('userid', this.serverUserData.userid);
                sessionStorage.setItem('user_type', this.serverUserData.user_type);
                this.getGuestUserCourser(sessionStorage.getItem('institute_id'));
            }
            else if (sessionStorage.getItem('userType') == '99' && sessionStorage.getItem('testprepEnabled')
                && institute_data.courseType != "") {
                sessionStorage.setItem('student_id', "0");
                sessionStorage.setItem('userid', this.serverUserData.userid);
                sessionStorage.setItem('user_type', this.serverUserData.user_type);
                sessionStorage.setItem('institution_id', res.institution_id);
                sessionStorage.setItem('institution_name', res.data.institute_name);
                this.gotoStudentPortal();
            }
        }
    };
    LoginPageComponent.prototype.getGuestUserCourser = function (institute_id) {
        var _this = this;
        this.login.getGuestUserCourses(institute_id).subscribe(function (res) {
            console.log(res);
            if (res.length != 0) {
                _this.isGuestUserCourse = true;
                _this.courses = res;
            }
            else {
                _this.gotoStudentPortal();
            }
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, "", err.error.message);
        });
    };
    LoginPageComponent.prototype.updateCourseforGuestUser = function () {
        var _this = this;
        var obj = {
            userid: sessionStorage.getItem('userid'),
            courseType: this.selectedCourseNames.toString()
        };
        this.login.updateCourseforGuestUser(obj).subscribe(function (res) {
            console.log(res);
            sessionStorage.setItem("courseType", _this.selectedCourseNames.toString());
            _this.gotoStudentPortal();
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, "", err.error.message);
        });
    };
    LoginPageComponent.prototype.gotoStudentPortal = function () {
        if (sessionStorage.getItem('testprepEnabled') != 'false') {
            window.location.href = this.baseUrl + "/sPortal/dashboard.html#/Dashboard";
        }
        else {
            window.location.href = this.baseUrl + "/sPortal/dashboard.html#/Documents";
        }
    };
    LoginPageComponent.prototype.toggleCheckbox = function (course, data) {
        console.log(course, data);
        var index = this.selectedCourseNames.indexOf(data.course_type);
        if (index == -1) {
            this.selectedCourseNames.push(data.course_type);
        }
        else {
            this.selectedCourseNames.splice(index, 1);
        }
    };
    //End - 3
    //if login email is not verified ( Start - 4 )
    LoginPageComponent.prototype.alternateLoginEmailNotVerified = function () {
        this.msgService.showErrorMessage(this.msgService.toastTypes.warning, this.messages.loginMsg.invalidEmail.title, this.messages.loginMsg.invalidEmail.body);
    };
    //End - 4
    //if login email is registered in multi insititute ( Start - 5 )
    LoginPageComponent.prototype.alternateLoginMultiInstitute = function (data) {
        var _this = this;
        this.instituteListArr = [];
        data.institutesList.forEach(function (el) {
            _this.instituteListObj.institute_id = el.institute_id;
            _this.instituteListObj.institute_name = el.institute_name;
            _this.instituteListObj.userId = el.userId;
            _this.instituteListArr.push({ 'institute_id': _this.instituteListObj.institute_id, 'institute_name': _this.instituteListObj.institute_name, 'userId': _this.instituteListObj.userId });
        });
        this.isLoginView = false;
        //console.log(this.instituteListArr);
        this.showInstituteList();
    };
    //End - 5
    LoginPageComponent.prototype.alternateLoginMultiInstituteData = function (u_id, inst_id) {
        var _this = this;
        this.multiInstituteLoginInfo.userid = u_id;
        this.multiInstituteLoginInfo.institution_id = inst_id;
        this.multiInstituteLoginInfo.alternate_email_id = this.loginDataForm.alternate_email_id;
        this.multiInstituteLoginInfo.password = this.loginDataForm.password;
        //console.log(this.multiInstituteLoginInfo);
        this.closeInstituteList();
        this.login.postLoginDetails(this.multiInstituteLoginInfo).subscribe(function (el) {
            //console.log(el);
            _this.checkForAuthOptions(el);
            if (el.institution_id != null) {
                _this.getCountryDetails(el.institution_id);
            }
        });
    };
    //if user mobile no. is not verified ( Start - 6 )
    LoginPageComponent.prototype.OTPVerification = function (res) {
        var _this = this;
        this.OTPRegenerateData = res;
        var phone_no = res.mobile_no;
        this.otpVerificationInfo.alternate_email_id = this.loginDataForm.alternate_email_id;
        this.otpVerificationInfo.password = this.loginDataForm.password;
        this.otpVerificationInfo.mobile_no = res.mobile_no;
        this.otpVerificationInfo.userid = res.userid;
        this.isLoginView = false;
        this.showOTPValidationModal();
        this.countDown = __WEBPACK_IMPORTED_MODULE_1_rxjs__["Observable"].timer(0, 1000)
            .take(this.counter)
            .map(function () { return --_this.counter; });
    };
    //END - 6
    //if login email is registered as multi user ( Start - 7 )
    LoginPageComponent.prototype.alternateLoginMultiUser = function (data) {
        var _this = this;
        this.userListArr = [];
        this.multiUserListObj.institute_id = data.institution_id;
        data.userTypeMappingList.forEach(function (el) {
            if (el.userType == 0) {
                _this.multiUserListObj.userType = "Custom";
            }
            else if (el.userType == 3) {
                _this.multiUserListObj.userType = "Teacher";
            }
            else if (el.userType == 5) {
                _this.multiUserListObj.userType = "Parent";
            }
            _this.multiUserListObj.userID = el.userID;
            _this.multiUserListObj.user_role = el.userType;
            _this.userListArr.push({ 'institute_id': _this.multiUserListObj.institute_id, 'userID': _this.multiUserListObj.userID, 'userType': _this.multiUserListObj.userType, 'user_role': _this.multiUserListObj.user_role });
        });
        this.isLoginView = false;
        this.showUserList();
    };
    LoginPageComponent.prototype.alternateLoginMultiUserData = function (u_id, u_role, inst_id) {
        var _this = this;
        this.multiUserLoginInfo.userid = u_id;
        this.multiUserLoginInfo.user_role = u_role;
        this.multiUserLoginInfo.institution_id = inst_id;
        this.multiUserLoginInfo.alternate_email_id = this.loginDataForm.alternate_email_id;
        this.multiUserLoginInfo.password = this.loginDataForm.password;
        this.closeUserList();
        this.login.postLoginDetails(this.multiUserLoginInfo).subscribe(function (el) {
            //console.log(el);
            _this.checkForAuthOptions(el);
            if (el.institution_id != null) {
                _this.getCountryDetails(el.institution_id);
            }
        });
    };
    //END - 7
    LoginPageComponent.prototype.alternateLoginOTPVerification = function () {
        var _this = this;
        //console.log("##### trying to Validate OTP #####");
        //console.log(this.otpVerificationInfo);
        if (this.otpVerificationInfo.otp_code == null || this.otpVerificationInfo.otp_code == "") {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, this.messages.loginMsg.opt.notFound.title, this.messages.loginMsg.opt.notFound.body);
        }
        else {
            this.login.validateOTPCode(this.otpVerificationInfo).subscribe(function (el) {
                //console.log(el);
                if (el.otp_status == 1) {
                    //console.log("OTP Expired");
                    _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, _this.messages.loginMsg.opt.expired.title, _this.messages.loginMsg.opt.expired.body);
                }
                else if (el.otp_status == 2) {
                    //console.log("Incorrect OTP");
                    _this.msgService.showErrorMessage(_this.msgService.toastTypes.warning, _this.messages.loginMsg.opt.inCorrect.title, _this.messages.loginMsg.opt.inCorrect.body);
                }
                else if (el.login_option == 3) {
                    //console.log("OTP Verified Success");
                    _this.alternateLoginSuccess(el);
                    _this.closeOTPValidationModal();
                }
            });
        }
    };
    LoginPageComponent.prototype.alternateLoginOTPRegenerate = function () {
        var _this = this;
        //console.log("##### in Regenerate Method ######");
        //console.log(this.OTPRegenerateData);
        this.login.regenerateOTP(this.OTPRegenerateData).subscribe(function (el) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, '', 'OTP sent successfully');
            //console.log("OTP Regenerate Success");
            //console.log(el);
            _this.OTPVerification(el);
        }, function (err) {
            console.log(err);
        });
    };
    LoginPageComponent.prototype.forgotPassword = function () {
        var _this = this;
        var forgotPasswordData = {
            alternate_email_id: ""
        };
        if (this.loginDataForm.alternate_email_id == "") {
            this.no_email_found = true;
        }
        else {
            if (confirm('New password will be sent to your registered number. Click Ok to continue.')) {
                forgotPasswordData.alternate_email_id = this.loginDataForm.alternate_email_id;
                this.login.forgotPassowrdServiceMethod(forgotPasswordData).subscribe(function (el) {
                    _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, '', _this.messages.loginMsg.success.body);
                }, function (err) {
                    _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, "", err.error.message);
                });
            }
        }
    };
    LoginPageComponent.prototype.showInstituteList = function () {
        this.isInstituteListPop = true;
    };
    LoginPageComponent.prototype.showUserList = function () {
        this.isUserListPop = true;
    };
    LoginPageComponent.prototype.closeUserList = function () {
        this.isUserListPop = false;
    };
    /* function to hide isInstituteList popup */
    LoginPageComponent.prototype.closeInstituteList = function () {
        this.isInstituteListPop = false;
    };
    LoginPageComponent.prototype.showOTPValidationModal = function () {
        this.OTPVerificationPopUp = true;
    };
    /* function to hide popup to add institute */
    LoginPageComponent.prototype.closeOTPValidationModal = function () {
        this.OTPVerificationPopUp = false;
    };
    LoginPageComponent.prototype.openGetAdvice = function () {
        var url = "https://proctur.com/contact_us/index.html";
        window.open(url);
    };
    LoginPageComponent.prototype.createRoleBasedSidenav = function () {
        var _this = this;
        this.auth.currentInstituteId.subscribe(function (id) {
            /* If Id has been updated to the services then proceed */
            if (id != null && id != "null") {
                if (sessionStorage.getItem('userType') == '0' || sessionStorage.getItem('userType') == '3') {
                    _this.login.storeInstituteInfoToSession().subscribe(function (res) {
                        sessionStorage.setItem('manual_student_disp_id', res.is_student_displayId_manual);
                        _this.login.changeSidenavStatus('authorized');
                        _this.route.navigateByUrl('/view/home');
                    }, function (err) {
                        _this.login.changeSidenavStatus('authorized');
                        _this.route.navigateByUrl('/view/home');
                    });
                }
                else if (sessionStorage.getItem('userType') == '1' && _this.serverUserData) {
                    //sessionStorage.setItem('student_id', this.serverUserData.data.studentId);
                    //sessionStorage.setItem('user_type_name', 'Student');
                    //window.location.href = "http://127.0.0.1:8001/sPortal/dashboard.html#/Dashboard";
                    sessionStorage.setItem('student_id', _this.serverUserData.data.studentId);
                    sessionStorage.setItem('institution_id', _this.serverUserData.institution_id);
                    sessionStorage.setItem('user_type_name', 'Student');
                    sessionStorage.setItem('inst_set_up', _this.serverUserData.data.institute_setup_type);
                    sessionStorage.setItem('institution_name', _this.serverUserData.data.institute_name);
                    sessionStorage.setItem('is_cobranding', _this.serverUserData.data.is_cobranding);
                    window.location.href = _this.baseUrl + "/sPortal/dashboard.html#/Dashboard";
                }
                else if (sessionStorage.getItem('userType') == '5' && _this.serverUserData) {
                    // sessionStorage.setItem('student_id', this.serverUserData.data.parentStudentList[0].student_id);
                    // sessionStorage  .setItem('user_type_name', 'Parent');
                    sessionStorage.setItem('student_id', _this.serverUserData.data.parentStudentList[0].student_id);
                    sessionStorage.setItem('user_type_name', 'Parent');
                    sessionStorage.setItem('institution_id', _this.serverUserData.institution_id);
                    sessionStorage.setItem('inst_set_up', _this.serverUserData.data.institute_setup_type);
                    sessionStorage.setItem('institution_name', _this.serverUserData.data.institute_name);
                    sessionStorage.setItem('is_cobranding', _this.serverUserData.data.is_cobranding);
                    window.location.href = _this.baseUrl + "/sPortal/dashboard.html#/Dashboard";
                }
            }
            else {
                setTimeout(_this.reCheckLogin(), 3000);
            }
        });
    };
    LoginPageComponent.prototype.reCheckLogin = function () {
        var id = sessionStorage.getItem('institute_id');
        var institute_data = JSON.parse(sessionStorage.getItem('institute_info'));
        if (id != null && id != "null") {
            if (institute_data != null && institute_data != undefined) {
                var Authorization = btoa(institute_data.userid + "|" + institute_data.userType + ":" + institute_data.password + ":" + institute_data.institution_id);
                this.auth.changeAuthenticationKey(Authorization);
            }
            this.auth.changeInstituteId(sessionStorage.getItem('institute_id'));
            this.createRoleBasedSidenav();
        }
    };
    LoginPageComponent.prototype.getBaseUrlStudent = function () {
        var test = window.location.href.split("/")[2];
        if (test === "webtest.proctur.com") {
            return "http://webtest.proctur.com";
        }
        else if (test === "web.proctur.com") {
            return "https://web.proctur.com";
        }
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('viewChange'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], LoginPageComponent.prototype, "changeView", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('backgroundChange'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], LoginPageComponent.prototype, "backgroundChange", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('virtualStyle'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], LoginPageComponent.prototype, "virtualStyle", void 0);
    LoginPageComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-login-page',
            template: __webpack_require__("./src/app/components/auth-page/login-page/login-page.component.html"),
            styles: [__webpack_require__("./src/app/components/auth-page/login-page/login-page.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_5__services_login_services_login_service__["a" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_2__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_8__services_message_show_service__["a" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_6__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__angular_platform_browser__["Title"],
            __WEBPACK_IMPORTED_MODULE_7__services_table_preference_table_preferences_service__["a" /* TablePreferencesService */],
            __WEBPACK_IMPORTED_MODULE_2__angular_router__["ActivatedRoute"],
            __WEBPACK_IMPORTED_MODULE_9__services_common_service__["a" /* CommonServiceFactory */]])
    ], LoginPageComponent);
    return LoginPageComponent;
}());



/***/ })

});
//# sourceMappingURL=auth-page.module.chunk.js.map