webpackJsonp(["course-exam.module"],{

/***/ "./src/app/components/course-module/create-course/course-exam/course-exam.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper black-bg\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<section class=\"middle-section\">\r\n    <section class=\"exam-schedule\">\r\n        <div class=\"heading-section\">\r\n            <h1>\r\n                Exam Schedule Details\r\n            </h1>\r\n        </div>\r\n\r\n        <div class=\"common-search-filter\">\r\n            <div *ngIf=\"isLangInstitute\">\r\n                <div class=\"row\">\r\n                    <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': batchData.standard_id != '-1'}\">\r\n                          <label for=\"ddnMAsterCourse\">Master Course<span class=\"text-danger\">*</span></label>\r\n                          <select id=\"ddnMAsterCourse\" name=\"ddnMAsterCourse\" class=\"form-ctrl\" [(ngModel)]=\"batchData.standard_id\" (ngModelChange)=\"onBatchMasterCourseSelection($event)\">\r\n                            <option value=\"-1\">Select Master Course</option>\r\n                            <option [value]=\"master.standard_id\" *ngFor=\"let  master of masterCourseList\">\r\n                                {{master.standard_name}}\r\n                            </option>\r\n                          </select>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': batchData.subject_id != '-1'}\">\r\n                            <label for=\"ddnMAsterCourse\">Course<span class=\"text-danger\">*</span></label>\r\n                            <select id=\"ddnMAsterCourse\" name=\"ddnMAsterCourse\" class=\"form-ctrl\" [(ngModel)]=\"batchData.subject_id\" (ngModelChange)=\"onBatchCourseSelection($event)\">\r\n                                <option value=\"-1\">Select Course</option>\r\n                                <option [value]=\"master.subject_id\" *ngFor=\"let  master of courseList\">\r\n                                    {{master.subject_name}}\r\n                                </option>\r\n                            </select>\r\n\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': batchData.batch_id != '-1'}\">\r\n                            <label for=\"sc\">Batch<span class=\"text-danger\">*</span></label>\r\n                            <select id=\"sc\" class=\"form-ctrl\" [(ngModel)]=\"batchData.batch_id\">\r\n                                <option value=\"-1\">Select Batch</option>\r\n                                <option [value]=\"subject.batch_id\" *ngFor=\"let subject of batchesList\">\r\n                                    {{subject.batch_name}}\r\n                                </option>\r\n                            </select>\r\n\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"c-sm-3 c-md-3 c-lg-3\" style=\"margin-top: 25px\">\r\n                        <button class=\"btn fullBlue\" (click)=\"batchModelGoClick()\">Go</button>\r\n                    </div>\r\n                </div>\r\n                <div class=\"row\" *ngIf=\"showCourseStartEndDate\">\r\n                  <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n                      <span class=\"spanText\">Course Start Date : {{batchStartDate}}</span>\r\n                      &emsp;\r\n                      <span class=\"spanText\">Course End Date : {{batchEndDate}} </span>\r\n                  </div>\r\n                </div>\r\n            </div>\r\n\r\n            <div *ngIf=\"!isLangInstitute\">\r\n\r\n                <div class=\"row\">\r\n\r\n                    <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': courseData.master_course != ''}\">\r\n                            <label for=\"ddnMAsterCourse\">Master Course\r\n                               <span class=\"text-danger\">*</span>\r\n                            </label>\r\n                            <select id=\"ddnMAsterCourse\" name=\"ddnMAsterCourse\" class=\"form-ctrl\" [(ngModel)]=\"courseData.master_course\" (ngModelChange)=\"getCourseList(event)\">\r\n                                <option value=\"-1\">Select Master Course</option>\r\n                                <option [value]=\"master.master_course\" *ngFor=\"let  master of masterCourseList\">\r\n                                    {{master.master_course}}\r\n                                </option>\r\n                            </select>\r\n\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': courseData.course_id != -1}\">\r\n                            <label for=\"ddnMAsterCourse\">Course\r\n                               <span class=\"text-danger\">*</span>\r\n                            </label>\r\n                            <select id=\"ddnMAsterCourse\" name=\"ddnMAsterCourse\" class=\"form-ctrl\" [(ngModel)]=\"courseData.course_id\" (ngModelChange)=\"displayCourseDate()\">\r\n                                <option value=\"-1\">Select Course</option>\r\n                                <option [value]=\"master.course_id\" *ngFor=\"let  master of courseList.coursesList\">\r\n                                    {{master.course_name}}\r\n                                </option>\r\n                            </select>\r\n\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n\r\n                        <div class=\"field-wrapper datePickerBox has-value\">\r\n                            <label for=\"reqDate\">Exam Schedule Date\r\n                               <span class=\"text-danger\">*</span>\r\n                            </label>\r\n                            <input type=\"text\" value=\"\" id=\"reqDate\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"courseData.requested_date\" readonly=\"true\"\r\n                                name=\"reqDate\" bsDatepicker style=\"z-index: 1;\">\r\n\r\n                        </div>\r\n\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-md-3 c-lg-3\" style=\"margin-top: 25px\">\r\n                        <button class=\"btn fullBlue\" (click)=\"getExamSchedule()\">Go</button>\r\n                    </div>\r\n                </div>\r\n\r\n                <div class=\"row\" *ngIf=\"showCourseStartEndDate\" style=\"margin-top: 5px;\">\r\n                  <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n                      <span class=\"spanText\">Course Start Date : <span style=\"font-weight: 600;\">{{batchStartDate}}</span></span>\r\n                      &emsp;\r\n                      <span class=\"spanText\">Course End Date : <span style=\"font-weight: 600;\">{{batchEndDate}}</span></span>\r\n                  </div>\r\n                </div>\r\n\r\n            </div>\r\n\r\n        </div>\r\n\r\n        <div class=\"content-section\" *ngIf=\"showContentSection\">\r\n\r\n\r\n            <div *ngIf=\"isLangInstitute\" class=\"langModelCss\">\r\n\r\n                <div class=\"row\">\r\n\r\n                    <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n                        <span class=\"spanText\">{{batchStartDate}} to {{batchEndDate}}</span>\r\n                    </div>\r\n\r\n                </div>\r\n\r\n                <div class=\"row examAdder\" *ngIf=\"jsonVar.isSheduleBatch\">\r\n\r\n                    <div class=\"c-lg-2 c-md-2 c-sm-2 \">\r\n                        <div class=\"form-wrapper datePickerBox\">\r\n                            <label for=\"csd\">Date\r\n                               <span class=\"text-danger\">*</span>\r\n                            </label>\r\n                            <input type=\"text\" value=\"\" id=\"csd\" class=\"side-form-ctrl bsDatepicker constantHeight\" [(ngModel)]=\"batchAdderData.exam_date\"\r\n                                readonly=\"true\" name=\"csd\" bsDatepicker>\r\n                        </div>\r\n                    </div>\r\n\r\n                     <div class=\"c-lg-1 c-md-1 c-sm-1\" style=\"padding: 0;\">\r\n                        <div class=\"form-wrapper topicsBox\">\r\n                            <label>\r\n                                <span>Topic</span>\r\n                            </label><br>\r\n                            <input type=\"text\" class=\"side-form-ctrl text-center\" *ngIf=\"!selectedTopicsListObj.length\" (click)=\"fetchTopics()\" style=\"height: 30px;cursor:pointer\" value=\"\" placeholder=\"Link\"/>\r\n                            <i class=\"fa fa-link\" (click)=\"fetchTopics()\" *ngIf=\"!selectedTopicsListObj.length\" style=\"position: absolute;  top: 28px; right: 10px;cursor: pointer\"></i>\r\n\r\n                            <!--when topics are not linked-->\r\n                            <input type=\"text\" class=\"side-form-ctrl text-center\" *ngIf=\"selectedTopicsListObj.length\" (click)=\"fetchSelectedTopics()\" style=\"height: 30px;cursor:pointer;    border-color: blue;\r\n                            color: blue;\" value=\"\" placeholder=\"Linked\"/>\r\n                            <i class=\"fa fa-link\" (click)=\"fetchSelectedTopics()\" *ngIf=\"selectedTopicsListObj.length\" style=\"position: absolute;  top: 28px; right: 10px;cursor: pointer;color:blue\"></i>\r\n                        </div>\r\n                    </div> \r\n\r\n                    <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n\r\n                        <div class=\"form-wrapper timepick\">\r\n                            <label for=\"startTime\">Start Time</label>\r\n                            <div class=\"tbox\">\r\n                                <div class=\"times\">\r\n                                    <select id=\"\" class=\"mins side-form-ctrl constantHeight\" [(ngModel)]=\"batchAdderData.start_time.hour\" name=\"startTime\">\r\n                                        <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                                            {{time}}\r\n                                        </option>\r\n                                    </select>\r\n                                </div>\r\n                                <div class=\"times\">\r\n                                    <select id=\"\" class=\"mers side-form-ctrl constantHeight\" [(ngModel)]=\"batchAdderData.start_time.minute\" name=\"minute\">\r\n                                        <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                                            {{minute}}\r\n                                        </option>\r\n                                    </select>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n\r\n                        <div class=\"form-wrapper timepick\">\r\n                            <label for=\"startTime\">End Time</label>\r\n                            <div class=\"tbox\">\r\n                                <div class=\"times\">\r\n                                    <select id=\"\" class=\"mins side-form-ctrl constantHeight\" [(ngModel)]=\"batchAdderData.end_time.hour\" name=\"startTime\">\r\n                                        <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                                            {{time}}\r\n                                        </option>\r\n                                    </select>\r\n                                </div>\r\n                                <div class=\"times\">\r\n                                    <select id=\"\" class=\"mers side-form-ctrl constantHeight\" [(ngModel)]=\"batchAdderData.end_time.minute\" name=\"minute\">\r\n                                        <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                                            {{minute}}\r\n                                        </option>\r\n                                    </select>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                        <div class=\"form-wrapper\">\r\n                            <label for=\"customDescTxt\">Description</label>\r\n                            <textarea class=\"side-form-ctrl constantHeight\" [(ngModel)]=\"batchAdderData.exam_desc\" id=\"customDescTxt\" name=\"customDescTxt\" placeholder=\"Enter Exam Description\"></textarea>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-2 c-lg-2 c-md-2\" *ngIf=\"examScheduleData.is_exam_grad_feature == 0\">\r\n                        <div class=\"form-wrapper\" style=\"width: 75px\">\r\n                            <label for=\"inpTotalMarks\">Total Marks</label>\r\n                            <input type=\"text\" onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" class=\"side-form-ctrl constantHeight\"\r\n                                [(ngModel)]=\"batchAdderData.total_marks\">\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"btnAdd\">\r\n                        <i class=\"fas fa-plus-circle\" style=\"font-family: FontAwesome;font-size: 25px;color: #0083f6;cursor: pointer;\" (click)=\"addNewExamSchedule()\"></i>\r\n                        <!-- <button class=\"btn fullBlue\">Add</button> -->\r\n                    </div>\r\n\r\n                </div>\r\n                <div class=\"row text-center\" style=\"color: red; margin-bottom: 10px;font-weight: 600;\" *ngIf=\"!jsonVar.isSheduleBatch\">\r\n                    You are not allowed to schedule Class/Exam as current Batch is expired !!!!!!\r\n                </div>\r\n                <div class=\"table-wrapper-Lang\">\r\n                    <div class=\"\">\r\n                        <table>\r\n                            <thead>\r\n                                <tr>\r\n                                    <th>\r\n                                        Date\r\n                                    </th>\r\n                                    <th>\r\n                                        Topics\r\n                                    </th>\r\n                                    <th>\r\n                                        Start Time\r\n                                    </th>\r\n                                    <th>\r\n                                        End Time\r\n                                    </th>\r\n                                    <th *ngIf=\"examScheduleData.is_exam_grad_feature == 0\">\r\n                                        Total Marks\r\n                                    </th>\r\n                                    <th>\r\n                                        Description\r\n                                    </th>\r\n                                    <th *ngIf=\"jsonVar.isSheduleBatch\">\r\n                                        Action\r\n                                    </th>\r\n                                </tr>\r\n                            </thead>\r\n                            <tbody>\r\n                                <tr *ngFor=\"let row of examSchedule ; let i= index ; trackBy : index\">\r\n                                    <td>\r\n                                        {{row.exam_date | dateMonthYear}}\r\n                                    </td>\r\n                                    <td>\r\n                                        <input type=\"textbox\" class=\"side-form-ctrl topic-link\" *ngIf=\"row.topics_covered != '' && row.topics_covered != null\" name=\"label\" style=\"height: 30px;border:1px solid blue;text-align:center;cursor:pointer\" id=\"classDetailsTxt9\" placeholder=\"Linked\"\r\n                        readonly (click)=\"editTopics(row)\" />\r\n                        <i class=\"fa fa-link\" (click)=\"editTopics(row)\" *ngIf=\"row.topics_covered != '' && row.topics_covered != null\" style=\"cursor: pointer;font-size: 15px;margin-left: -30px;margin-top:6px;color:#0084f6\"></i>\r\n\r\n                        <input type=\"textbox\" class=\"side-form-ctrl topic-link\" *ngIf=\"row.topics_covered == '' || row.topics_covered == null\" name=\"label\" style=\"height: 30px;cursor:pointer;text-align:center;border:1px solid lightgrey\" id=\"classDetailsTxt9\" placeholder=\"Link\"\r\n                        readonly (click)=\"editTopics(row)\"/>\r\n                        <i class=\"fa fa-link\" (click)=\"editTopics(row)\" *ngIf=\"row.topics_covered == '' || row.topics_covered == null\" style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;margin-left: -30px;margin-top:6px\"></i>\r\n                                    </td>\r\n                                    <td>\r\n                                        {{row.start_time}}\r\n                                    </td>\r\n                                    <td>\r\n                                        {{row.end_time}}\r\n                                    </td>\r\n                                    <td *ngIf=\"examScheduleData.is_exam_grad_feature == 0\">\r\n                                        <div class=\"form-wrapper\">\r\n                                            <input type=\"text\" onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" class=\"side-form-ctrl torlMarksWidth\"\r\n                                                name=\"label\" [(ngModel)]=\"row.total_marks\">\r\n                                        </div>\r\n                                    </td>\r\n                                    <td>\r\n                                        <div class=\"form-wrapper\">\r\n                                            <input type=\"textbox\" class=\"side-form-ctrl\" name=\"label\" [(ngModel)]=\"row.exam_desc\">\r\n                                        </div>\r\n                                    </td>\r\n                                    <td *ngIf=\"jsonVar.isSheduleBatch\">\r\n\r\n                                        <div class=\"action-box\">\r\n                                            <span class=\"mail-notification\" *ngIf=\"row.schd_id != 0 && (currentDate <= row.exam_date)\" (click)=\"notifyExamSchedule(row)\"\r\n                                                title=\"Notify\">\r\n                                            </span>\r\n                                            <span class=\"delete-btn\" style=\"font-family: FontAwesome;font-size: 20px\" *ngIf=\"row.schd_id == 0 || (currentDate < row.exam_date)\"\r\n                                                (click)=\"deleteExamSchedule(row,i)\" title=\"Delete\">\r\n                                                <i class=\"fa fa-trash-o \" aria-hidden=\"true \"></i>\r\n                                            </span>\r\n                                            <!-- <span *ngIf=\"row.schd_id != 0\" (click)=\"markAttendanceSchedule(row)\" title=\"Mark Attendance\">\r\n                                                <img src=\"../../../../assets/images/attendance.png\" width=\"20px\" height=\"20px\" style=\"position: relative;top: 2px;\">\r\n                                            </span> -->\r\n                                            <span *ngIf=\"row.schd_id != 0 && (currentDate <= row.exam_date)\" (click)=\"cancelExamSchedule(row)\" title=\"Cancel Exam\">\r\n                                                <i class=\"fa fa-times\" style=\"font-family: FontAwesome;font-size: 20px; position: relative;top: -1px\" aria-hidden=\"true\"></i>\r\n                                            </span>\r\n                                        </div>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr *ngIf=\"examSchedule.length == 0\">\r\n                                    <td colspan=\"6\">\r\n                                        No Schedule OF Exam\r\n                                    </td>\r\n                                </tr>\r\n                            </tbody>\r\n                        </table>\r\n                    </div>\r\n                </div>\r\n\r\n                <div class=\"row btn-Group\">\r\n                  <div class=\"pull-left\" style=\"margin-left: 7%\">\r\n                    <button type=\"button\" class=\"btn\" Style=\"margin-left: 0px;\" name=\"button\" routerLink=\"/view/course/coursePlanner/exam\" *ngIf=\"coursePlannerStatus=='true'\">Back</button>\r\n                  </div>\r\n                    <button class=\"btn fullBlue pull-right\" *ngIf=\"examSchedule.length > 0\" [disabled]=\"isRippleLoad\" (click)=\"addDataToExamSchedule()\">Create Exam Schedule</button>\r\n                    <!-- <button class=\"btn fullBlue pull-right\" *ngIf=\"examScheduleData.otherSchd.length !=0\" (click)=\"addDataToExamSchedule()\">Update</button> -->\r\n                </div>\r\n\r\n                <h3 class=\"row\">Cancelled Exams</h3>\r\n\r\n                <div class=\"cancelClass-table\">\r\n                    <div class=\"\">\r\n                        <table>\r\n                            <thead>\r\n                                <tr>\r\n                                    <th>Date</th>\r\n                                    <th>Start Time</th>\r\n                                    <th>End Time</th>\r\n                                    <th *ngIf=\"examScheduleData.is_exam_grad_feature == 0\">Total Marks</th>\r\n                                    <th>Cancel Reason</th>\r\n                                    <th *ngIf=\"jsonVar.isSheduleBatch\">Action</th>\r\n                                </tr>\r\n                            </thead>\r\n                            <tbody>\r\n                                <tr *ngFor=\"let row of cancelledSchedule ; let i= index ; trackBy : index\">\r\n                                    <td>\r\n                                        {{row.exam_date}}\r\n                                    </td>\r\n                                    <td>\r\n                                        {{row.start_time}}\r\n                                    </td>\r\n                                    <td>\r\n                                        {{row.end_time}}\r\n                                    </td>\r\n                                    <td *ngIf=\"examScheduleData.is_exam_grad_feature == 0\">\r\n                                        {{row.total_marks}}\r\n                                    </td>\r\n                                    <td>\r\n                                        {{row.exam_desc}}\r\n                                    </td>\r\n                                    <td *ngIf=\"jsonVar.isSheduleBatch\">\r\n                                        <div class=\"action-Menu\">\r\n\r\n                                            <div class=\"action-box\">\r\n                                                <span class=\"mail-notification\" title=\"Send notification for cancelled exam schedule\" (click)=\"notifyCancelClass(row)\">\r\n                                                </span>\r\n                                                <span class=\"delete-btn\" style=\"font-family: FontAwesome;font-size: 20px\" title=\"Uncancel Schedule\" *ngIf=\"(currentDate < row.exam_date)\"\r\n                                                    (click)=\"unCancelClass(row)\">\r\n                                                    <i class=\"fa fa-trash-o \" aria-hidden=\"true \"></i>\r\n                                                </span>\r\n                                            </div>\r\n\r\n                                            <!-- <a title=\"Send notification for cancelled exam schedule\" (click)=\"notifyCancelClass(row)\">Notify</a>\r\n                                            <a title=\"Uncancel Schedule\" *ngIf=\"(currentDate < row.exam_date)\" (click)=\"unCancelClass(row)\">Uncancel Class</a> -->\r\n                                        </div>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr *ngIf=\"cancelledSchedule.length ==0\">\r\n                                    <td colspan=\"6\">\r\n                                        No Cancelled Schedule\r\n                                    </td>\r\n                                </tr>\r\n                            </tbody>\r\n                        </table>\r\n                    </div>\r\n                </div>\r\n\r\n\r\n            </div>\r\n\r\n            <div *ngIf=\"!isLangInstitute\" class=\"courseModelWrapper\">\r\n\r\n                <!-- <div class=\"row spli-Btn\"> -->\r\n\r\n                    <!-- <p-selectButton [options]=\"types\" [(ngModel)]=\"selectedType\" (onChange)=\"onChanged($event)\"></p-selectButton> -->\r\n\r\n                    <!-- <div class=\"pull-right\" *ngIf=\"selectedType == 'course' && examScheduleData.coursesList[0].courseClassSchdList\" style=\"margin-right:10px;\">\r\n                        <button class=\"btn fullBlue small-btn add_exam_btn\" (click)=\"addMoreSchedule()\" title=\"Used to create an additional/ multiple exams in same course on same day but with different timings.\">+ Add Exam</button>\r\n                    </div> -->\r\n\r\n                <!-- </div> -->\r\n\r\n                <div class=\"row course-model\" *ngIf=\"selectedType == 'course'\">\r\n\r\n                <!-- Add new Exam HTML -->\r\n\r\n                  <div class=\"exam_adder_div\">\r\n\r\n                    <div class=\"row dateInfo\">\r\n\r\n                      <div class=\"c-sm-3 c-lg-3 c-md-3\">\r\n\r\n                          <div class=\"form-wrapper timepick\">\r\n                              <label for=\"startTime\">Exam Start Time</label>\r\n                              <div class=\"tbox\">\r\n                                  <div class=\"times\">\r\n                                      <select id=\"\" class=\"mins side-form-ctrl constantHeight\" [(ngModel)]=\"newExamData.startTimeHrs\" name=\"startTime\">\r\n                                          <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                                              {{time}}\r\n                                          </option>\r\n                                      </select>\r\n                                  </div>\r\n                                  <div class=\"times\">\r\n                                      <select id=\"\" class=\"mers side-form-ctrl constantHeight\" [(ngModel)]=\"newExamData.startTimeMins\" name=\"minute\">\r\n                                          <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                                              {{minute}}\r\n                                          </option>\r\n                                      </select>\r\n                                  </div>\r\n                              </div>\r\n                          </div>\r\n\r\n                      </div>\r\n\r\n                      <div class=\"c-sm-3 c-lg-3 c-md-3\">\r\n\r\n                          <div class=\"form-wrapper timepick\">\r\n                              <label for=\"startTime\">Exam End Time</label>\r\n                              <div class=\"tbox\">\r\n                                  <div class=\"times\">\r\n                                      <select id=\"\" class=\"mins side-form-ctrl constantHeight\" [(ngModel)]=\"newExamData.endTimeHrs\" name=\"startTime\">\r\n                                          <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                                              {{time}}\r\n                                          </option>\r\n                                      </select>\r\n                                  </div>\r\n                                  <div class=\"times\">\r\n                                      <select id=\"\" class=\"mers side-form-ctrl constantHeight\" [(ngModel)]=\"newExamData.endTimeMins\" name=\"minute\">\r\n                                          <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                                              {{minute}}\r\n                                          </option>\r\n                                      </select>\r\n                                  </div>\r\n                              </div>\r\n                          </div>\r\n\r\n                      </div>\r\n\r\n                        <div class=\"pull-right\" style=\"margin-right:10px;\">\r\n                            <button (click)=\"clearField()\" class=\"btn fullBlue small-btn\">Clear</button>\r\n                        </div>\r\n\r\n                    </div>\r\n\r\n                    <div class=\"row basic-detail\">\r\n\r\n                      <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                        <div class=\"form-wrapper\">\r\n                            <label for=\"subject\">Subject\r\n                             <span class=\"text-danger\">*</span>\r\n                            </label>\r\n                            <select id=\"subject\" class=\"side-form-ctrl constantHeight subjectName\" [(ngModel)]=\"subject_id\" (ngModelChange)=\"subjectChanged()\">\r\n                                <option value=\"-1\" selected=\"selected\">Select Subject</option>\r\n                                <option [value]=\"time.subject_id\" *ngFor=\"let time of subjectListData[0]\">\r\n                                    {{time.subject_name}}\r\n                                </option>\r\n                            </select>\r\n                          </div>\r\n                        </div>\r\n\r\n                        <div class=\"c-sm-1 c-lg-1 c-md-1\">\r\n                            <div class=\"form-wrapper\" style=\"width: 75px\">\r\n                                <label for=\"marks\">Marks\r\n                                 <span class=\"text-danger\">*</span>\r\n                                </label>\r\n                                <input type=\"number\" class=\"side-form-ctrl constantHeight\" style=\"width:90px;\" (ngModelChange)=\"checkNgetiveValue($event)\"  [(ngModel)]=\"exam_marks\" id=\"marks\">\r\n                            </div>\r\n                        </div>\r\n\r\n                        <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                          <div class=\"form-wrapper\">\r\n                            <label for=\"topics\">Topic</label>\r\n                            <input type=\"textbox\" class=\"side-form-ctrl constantHeight\" name=\"label\"\r\n                              style=\"height: 31px;\" id=\"classDetailsTxt9\" placeholder=\"Link Topic\" readonly (click)=\"topicListing()\" [ngClass]=\"topicsName.length > 0 && subject_id != '' ? 'topic-linked' : 'topic-link'\">\r\n                              <i class=\"fa fa-link\" aria-hidden=\"true\" (click)=\"topicListing()\" style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;position: absolute; top: 28px; right: 25px;\"></i>\r\n                          </div>\r\n                        </div>\r\n\r\n                          <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                              <div class=\"form-wrapper\">\r\n                                  <label for=\"customDescTxt\">Description</label>\r\n                                  <textarea class=\"side-form-ctrl constantHeight\" [(ngModel)]=\"exam_desc\" id=\"customDescTxt\" name=\"customDescTxt\" placeholder=\"Enter Exam Description\"></textarea>\r\n                              </div>\r\n                          </div>\r\n\r\n                          <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                              <div class=\"form-wrapper\" style=\"width: 75px\">\r\n                                  <label for=\"inpTotalMarks\">Room No</label>\r\n                                  <input type=\"string\" class=\"side-form-ctrl constantHeight\" [(ngModel)]=\"exam_room_no\" id=\"inpTotalMarks\">\r\n                              </div>\r\n                          </div>\r\n\r\n                          <div class=\"c-sm-2 c-lg-2 c-md-2 pull-right\" style=\"margin-top: 15px;\">\r\n                            <button type=\"button\" name=\"button\" (click)=\"addNewExamSubject()\" class=\"btn  small-btn action_btn pull-right\">Add Subject &nbsp;<i class=\"fas fa-plus-circle\" style=\"font-family: FontAwesome;font-size: 14px;color: #0083f6;cursor: pointer;\"></i></button>\r\n                          </div>\r\n\r\n                      </div>\r\n\r\n\r\n                      <div class=\"row displayComp\" *ngFor=\"let row of newExamSubjectData; let i= index ; trackBy : index\" style=\"padding:0px 6px;\" id=\"row{{i}}\">\r\n\r\n                        <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                          <span class=\"view-comp\">{{row.subject_name}}</span>\r\n                          <span class=\"edit-comp\">{{row.subject_name}}</span>\r\n                          <!-- <div class=\"form-wrapper edit-comp\">\r\n                            <select id=\"subject\" class=\"side-form-ctrl constantHeight subjectName\" [(ngModel)]=\"edit_subject_id\">\r\n                                <option value=\"-1\" selected=\"selected\">Select Subject</option>\r\n                                <option [value]=\"time.subject_id\" *ngFor=\"let time of subjectListData[0]\">\r\n                                    {{time.subject_name}}\r\n                                </option>\r\n                            </select>\r\n                          </div> -->\r\n                        </div>\r\n\r\n                        <div class=\"c-sm-1 c-lg-1 c-md-1\">\r\n                          <span class=\"view-comp\">{{row.exam_marks}} marks</span>\r\n                          <div class=\"form-wrapper edit-comp\">\r\n                            <input type=\"number\" class=\"side-form-ctrl constantHeight\" style=\"width:90px;\" [(ngModel)]=\"edit_exam_marks\">\r\n                          </div>\r\n                        </div>\r\n\r\n                        <div class=\"c-sm-2 c-lg-2 c-md-2 topictext\">\r\n                          <span class=\"view-comp\" title={{row.subject_topics}}>{{row.subject_topics | slice:0:20}}</span>\r\n                          <div class=\"form-wrapper edit-comp\">\r\n                            <input type=\"textbox\" class=\"side-form-ctrl constantHeight\" name=\"label\"\r\n                              style=\"height: 31px;\" id=\"classDetailsTxt9\" placeholder=\"Link Topic\" readonly (click)=\"preSelectedTopicListing()\" [ngClass]=\"row.subject_topics ? 'topic-linked' : 'topic-link'\">\r\n                              <i class=\"fa fa-link\" aria-hidden=\"true\" (click)=\"preSelectedTopicListing()\" style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;position: absolute; top: 10px; right: 25px;\"></i>\r\n                          </div>\r\n                        </div>\r\n\r\n\r\n                          <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                            <span class=\"view-comp\">{{row.exam_desc}}</span>\r\n                            <div class=\"form-wrapper edit-comp\">\r\n                              <textarea class=\"side-form-ctrl constantHeight\" [(ngModel)]=\"edit_exam_desc\" id=\"customDescTxt\" name=\"customDescTxt\" placeholder=\"Enter Exam Description\"></textarea>\r\n                            </div>\r\n                          </div>\r\n\r\n                          <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                            <span class=\"view-comp\">{{row.exam_room_no}}</span>\r\n                            <div class=\"form-wrapper edit-comp\">\r\n                              <input type=\"string\" class=\"side-form-ctrl constantHeight\" [(ngModel)]=\"edit_exam_room_no\">\r\n                            </div>\r\n                          </div>\r\n\r\n                          <div class=\"c-sm-2 c-lg-2 c-md-2 pull-right\" >\r\n                            <div class=\"action-Menu view-comp\" *ngIf=\"row.isReferenced != 'Y'\">\r\n                              <i class=\"fa fa-trash-o pull-right\" style=\"color:red;margin: 0px 10px;\" aria-hidden=\"true\" (click)=\"deleteSubject(row.subject_id)\" title=\"Delete\"></i>\r\n                              <i class=\"fa fa-pencil pull-right\" style=\"color:#1283f4;margin: 0px 10px;\" aria-hidden=\"true\" (click)=\"editSubject(i , row)\" title=\"Edit\"></i>\r\n                            </div>\r\n                            <div class=\"action-Menu edit-comp\" *ngIf=\"row.isReferenced != 'Y'\">\r\n                              <i class=\"fa fa-trash-o pull-right\" style=\"color:red;margin: 0px 10px;\" aria-hidden=\"true\" (click)=\"deleteSubject(row.subject_id)\" title=\"Delete\"></i>\r\n                              <!-- <i class=\"fa fa-pencil pull-right\" style=\"color:#1283f4;margin: 0px 10px;\" aria-hidden=\"true\" (click)=\"editSubject(i , row)\" title=\"Edit\"></i> -->\r\n                              <span style=\"color:#1283f4;margin: 0px 10px;\" class=\"pull-right\" (click)=\"updateSubject(i , row)\">Save</span>\r\n                            </div>\r\n                          </div>\r\n\r\n                      </div>\r\n\r\n                      <div class=\"row\" style=\"padding: 6px; border-top: 1px solid rgba(119, 119, 119, 0.419608);\" *ngIf=\"newExamSubjectData.length > 0\">\r\n                        <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                          <span style=\"font-weight: 600;\">Total Marks</span>\r\n                        </div>\r\n\r\n                        <div class=\"c-sm-1 c-lg-1 c-md-1\">\r\n                          <span class=\"view-comp\" style=\"font-weight: 600;\">{{total_marks_to_show}} marks</span>\r\n                        </div>\r\n                      </div>\r\n\r\n                  </div>\r\n\r\n                  <!-- Showing Already Scheduled Exam List with their edit option -->\r\n                  <div class=\"\" *ngIf=\"viewList?.length\">\r\n                    <div class=\"loopingDiv\" *ngFor=\"let data of viewList;let j= index ; trackBy : index\">\r\n\r\n                        <div class=\"row dateInfo\"  *ngIf=\"data.courseTableList.length > 0\">\r\n\r\n                          <div class=\"c-sm-3 c-lg-3 c-md-3\">\r\n\r\n                              <div class=\"form-wrapper timepick\">\r\n                                  <label for=\"startTime\">Exam Start Time</label>\r\n                                  <div class=\"tbox\">\r\n                                      <div class=\"times\">\r\n                                          <select id=\"\" class=\"mins side-form-ctrl constantHeight\" [(ngModel)]=\"data.courseModelAdder.start_time.hour\" name=\"startTime\">\r\n                                              <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                                                  {{time}}\r\n                                              </option>\r\n                                          </select>\r\n                                      </div>\r\n                                      <div class=\"times\">\r\n                                          <select id=\"\" class=\"mers side-form-ctrl constantHeight\" [(ngModel)]=\"data.courseModelAdder.start_time.minute\" name=\"minute\">\r\n                                              <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                                                  {{minute}}\r\n                                              </option>\r\n                                          </select>\r\n                                      </div>\r\n                                  </div>\r\n                              </div>\r\n\r\n                          </div>\r\n\r\n                          <div class=\"c-sm-3 c-lg-3 c-md-3\">\r\n\r\n                              <div class=\"form-wrapper timepick\">\r\n                                  <label for=\"startTime\">Exam End Time</label>\r\n                                  <div class=\"tbox\">\r\n                                      <div class=\"times\">\r\n                                          <select id=\"\" class=\"mins side-form-ctrl constantHeight\" [(ngModel)]=\"data.courseModelAdder.end_time.hour\" name=\"startTime\">\r\n                                              <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                                                  {{time}}\r\n                                              </option>\r\n                                          </select>\r\n                                      </div>\r\n                                      <div class=\"times\">\r\n                                          <select id=\"\" class=\"mers side-form-ctrl constantHeight\" [(ngModel)]=\"data.courseModelAdder.end_time.minute\" name=\"minute\">\r\n                                              <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                                                  {{minute}}\r\n                                              </option>\r\n                                          </select>\r\n                                      </div>\r\n                                  </div>\r\n                              </div>\r\n\r\n                          </div>\r\n\r\n                            <div class=\"pull-right\" style=\"margin-right:10px;\">\r\n                                <button *ngIf=\"data.selectedCourseList.course_exam_schedule_id == -1\" (click)=\"deleteWholeCourse(data, j)\" class=\"btn fullBlue small-btn\">Delete</button>\r\n                                <button (click)=\"cancelExamForFullCourse(data,j)\" class=\"btn  small-btn action_btn\">Cancel Exam</button>\r\n                                <button (click)=\"sendReminderForCourse(data,j)\" class=\"btn  small-btn action_btn\">Notify</button>\r\n                            </div>\r\n\r\n                        </div>\r\n\r\n\r\n                       <div class=\"row basic-detail\" *ngIf=\"data.courseTableList.length > 0\">\r\n\r\n                        <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                          <div class=\"form-wrapper\">\r\n                              <label for=\"subject\">Subject\r\n                               <span class=\"text-danger\">*</span>\r\n                              </label>\r\n                              <select id=\"subject\" class=\"side-form-ctrl constantHeight subjectName\" [(ngModel)]=\"data.coursetableAdder.batch_id\" name=\"startTime\" (ngModelChange)=\"subjectChanged()\">\r\n                                  <option value=\"-1\">Select Subject</option>\r\n                                  <option [value]=\"time.batch_id\" *ngFor=\"let time of data.subjectList\">\r\n                                      {{time.subject_name}}\r\n                                  </option>\r\n                              </select>\r\n                            </div>\r\n                          </div>\r\n\r\n                          <div class=\"c-sm-1 c-lg-1 c-md-1\" *ngIf=\"(data.selectedCourseList.is_exam_grad_feature == 0)\">\r\n                              <div class=\"form-wrapper\" style=\"width: 75px\">\r\n                                  <label for=\"marks\">Marks\r\n                                   <span class=\"text-danger\">*</span>\r\n                                  </label>\r\n                                  <input type=\"number\" class=\"side-form-ctrl constantHeight\" style=\"width:90px;\" (ngModelChange)=\"checkNgetiveValue($event)\" [(ngModel)]=\"data.coursetableAdder.total_marks\" id=\"marks\">\r\n                              </div>\r\n                          </div>\r\n\r\n                          <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                            <div class=\"form-wrapper\">\r\n                              <label for=\"topics\">Topic</label>\r\n                              <input type=\"textbox\" class=\"side-form-ctrl constantHeight\" name=\"label\"\r\n                                style=\"height: 31px;\" id=\"classDetailsTxt9\" placeholder=\"Link Topic\" readonly (click)=\"topicLinking(data.subjectList, j)\" [ngClass]=\"changeColor ? 'topic-linked' : 'topic-link'\">    <!----   [ngClass]=\"checkedKeys.length > 0 ? 'topic-linked' : 'topic-link'\"   ----->\r\n                                <i class=\"fa fa-link\" aria-hidden=\"true\" (click)=\"topicLinking(data.subjectList, j)\" style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;position: absolute; top: 28px; right: 25px;\"></i>\r\n                            </div>\r\n                          </div>\r\n\r\n                            <!-- <div class=\"c-sm-2 c-lg-2 c-md-2\" *ngIf=\"(data.selectedCourseList.is_exam_grad_feature == 0)\">\r\n                                <div class=\"form-wrapper\" style=\"width: 70px\">\r\n                                    <label for=\"inpTotalMarks\">Total Marks</label>\r\n                                    <input type=\"number\" class=\"side-form-ctrl constantHeight\" [(ngModel)]=\"data.courseModelAdder.total_marks\">\r\n                                </div>\r\n                            </div> -->\r\n\r\n                            <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                                <div class=\"form-wrapper\">\r\n                                    <label for=\"customDescTxt\">Description</label>\r\n                                    <textarea class=\"side-form-ctrl constantHeight\" [(ngModel)]=\"data.coursetableAdder.exam_desc\" id=\"customDescTxt\" name=\"customDescTxt\" placeholder=\"Enter Exam Description\"></textarea>\r\n                                </div>\r\n                            </div>\r\n\r\n                            <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                                <div class=\"form-wrapper\" style=\"width: 75px\">\r\n                                    <label for=\"inpTotalMarks\">Room No</label>\r\n                                    <input type=\"string\" class=\"side-form-ctrl constantHeight\" [(ngModel)]=\"data.coursetableAdder.room_no\" id=\"inpTotalMarks\">\r\n                                </div>\r\n                            </div>\r\n\r\n                            <div class=\"c-sm-2 c-lg-2 c-md-2 pull-right\" style=\"margin-top: 15px;\">\r\n                              <button type=\"button\" name=\"button\" (click)=\"addNewExamSubjectCourse(j)\" class=\"btn  small-btn action_btn pull-right\">Add Subject &nbsp;<i class=\"fas fa-plus-circle\" style=\"font-family: FontAwesome;font-size: 14px;color: #0083f6;cursor: pointer;\"></i></button>\r\n                            </div>\r\n\r\n                        </div>\r\n\r\n\r\n                        <div class=\"row displayComp\" *ngFor=\"let row of data.courseTableList; let i= index ; trackBy : index\" id=\"row_already{{i}}_{{j}}\" style=\"padding:0px 6px;\">\r\n                          <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                            <span class=\"view-comp\">{{row.subject_name}}</span>\r\n                            <span class=\"edit-comp\">{{row.subject_name}}</span>\r\n                            <!-- <div class=\"form-wrapper edit-comp\">\r\n                              <select id=\"subject\" class=\"side-form-ctrl constantHeight subjectName\" [(ngModel)]=\"edit_subject_id\">\r\n                                  <option value=\"-1\" selected=\"selected\">Select Subject</option>\r\n                                  <option [value]=\"time.subject_id\" *ngFor=\"let time of subjectListData[0]\">\r\n                                      {{time.subject_name}}\r\n                                  </option>\r\n                              </select>\r\n                            </div> -->\r\n                          </div>\r\n\r\n                          <div class=\"c-sm-1 c-lg-1 c-md-1\">\r\n                            <span class=\"view-comp\">{{row.total_marks}} marks</span>\r\n                            <div class=\"form-wrapper edit-comp\">\r\n                              <input type=\"number\" class=\"side-form-ctrl constantHeight\" style=\"width:90px;\" [(ngModel)]=\"row_edit_exam_marks\">\r\n                            </div>\r\n                          </div>\r\n\r\n                          <div class=\"c-sm-2 c-lg-2 c-md-2 topictext\">\r\n                            <span class=\"view-comp \" title={{row.topicName}}>{{row.topicName | slice:0:20}}</span>\r\n                            <div class=\"form-wrapper edit-comp\">\r\n                              <input type=\"textbox\" class=\"side-form-ctrl constantHeight\" name=\"label\"\r\n                                style=\"height: 31px;\" id=\"classDetailsTxt9\" placeholder=\"Link Topic\" readonly (click)=\"topicLinkingForPreSelectedTopics(data.subjectList)\" [ngClass]=\"row_edit_subject_topicId != '' && row_edit_subject_topicId != undefined ? 'topic-linked' : 'topic-link'\">\r\n                                <i class=\"fa fa-link\" aria-hidden=\"true\" (click)=\"topicLinkingForPreSelectedTopics(data.subjectList)\" style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;position: absolute; top: 10px; right: 25px;\"></i>\r\n                            </div>\r\n                          </div>\r\n\r\n\r\n                            <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                              <span class=\"view-comp\">{{row.class_desc}}</span>\r\n                              <div class=\"form-wrapper edit-comp\">\r\n                                <textarea class=\"side-form-ctrl constantHeight\" [(ngModel)]=\"row_edit_exam_desc\" id=\"customDescTxt\" name=\"customDescTxt\" placeholder=\"Enter Exam Description\"></textarea>\r\n                              </div>\r\n                            </div>\r\n\r\n                            <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                              <span class=\"view-comp\">{{row.room_no}}</span>\r\n                              <div class=\"form-wrapper edit-comp\">\r\n                                <input type=\"string\" class=\"side-form-ctrl constantHeight\" [(ngModel)]=\"row_edit_exam_room_no\">\r\n                              </div>\r\n                            </div>\r\n\r\n\r\n                            <div class=\"c-sm-2 c-lg-2 c-md-2 pull-right\" >\r\n                              <div class=\"action-Menu view-comp\" *ngIf=\"row.isReferenced != 'Y'\">\r\n                                <i class=\"fa fa-trash-o pull-right\" style=\"color:red;margin: 0px 10px;\" aria-hidden=\"true\" (click)=\"deleteFromCourse(row , i , j)\" title=\"Delete\"></i>\r\n                                <i class=\"fa fa-pencil pull-right\" style=\"color:#1283f4;margin: 0px 10px;\" aria-hidden=\"true\" (click)=\"editFromCourse(row , i , j)\" title=\"Edit\"></i>\r\n                              </div>\r\n                              <div class=\"action-Menu edit-comp\" *ngIf=\"row.isReferenced != 'Y'\">\r\n                                <i class=\"fa fa-trash-o pull-right\" style=\"color:red;margin: 0px 10px;\" aria-hidden=\"true\" (click)=\"deleteFromCourse(row.subject_id)\" title=\"Delete\"></i>\r\n                                <!-- <i class=\"fa fa-pencil pull-right\" style=\"color:#1283f4;margin: 0px 10px;\" aria-hidden=\"true\" (click)=\"editSubject(i , row)\" title=\"Edit\"></i> -->\r\n                                <span style=\"color:#1283f4;margin: 0px 10px;\" class=\"pull-right\" (click)=\"updateEditedSubject(row , i , j)\">Save</span>\r\n                              </div>\r\n                            </div>\r\n\r\n                        </div>\r\n\r\n                        <div class=\"row\" style=\"padding: 6px; border-top: 1px solid rgba(119, 119, 119, 0.419608);\" *ngIf=\"data.courseTableList.length > 0\" >                             <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n                            <span style=\"font-weight: 600;\">Total Marks</span>\r\n                          </div>\r\n\r\n                          <div class=\"c-sm-1 c-lg-1 c-md-1\">\r\n                            <span class=\"view-comp\" style=\"font-weight: 600;\">{{data.courseModelAdder.total_marks}} marks</span>\r\n                          </div>\r\n                        </div>\r\n\r\n                    </div>\r\n                  </div>\r\n                    <div class=\"row\" style=\"padding-right:25px;\" class=\"save_btn_container\" >\r\n                      <div class=\"pull-left\" style=\"margin-left: 7%\">\r\n                        <button type=\"button\" class=\"btn\" Style=\"margin-left: 0px;\" name=\"button\" routerLink=\"/view/course/coursePlanner/exam\" *ngIf=\"coursePlannerStatus=='true'\">Back</button>\r\n                      </div>\r\n                      <div class=\"pull-right\">\r\n                        <button class=\"btn fullBlue pull-right\" (click)=\"saveExamScheduleCourse()\" [disabled]=\"multiClickDisabled\">Save</button>\r\n                        <button type=\"button\" name=\"button\" class=\"btn pull-right\">Cancel</button>\r\n                      </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </section>\r\n\r\n</section>\r\n\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n\r\n<section [hidden]=\"topicBox\">\r\n  <div class=\"topicBox\">\r\n    <div class=\"close-btn\">\r\n      <span (click)=\"closeAlert()\">X</span>\r\n    </div>\r\n    <div class=\"header-container\">\r\n      <div class=\"sub-header\">\r\n        <span style=\"font-weight: 600;\">Subject : </span>\r\n        <span id=\"topicSubName\">{{subject_name}}</span>\r\n      </div>\r\n      <div class=\"total-topic\">\r\n        <span style=\"font-weight: 600;\">Total Topic : </span>\r\n        <span id=\"topicCount\">{{topicsData?.length}}</span>\r\n      </div>\r\n    </div>\r\n    <!-- <div class=\"field-checkbox-wrapper\" style=\"margin:10px;\">\r\n      <input type=\"checkbox\" name=\"checkbx\" id=\"select_all_topics\" [(ngModel)]=\"selectAllTopics\" (ngModelChange)=\"checkAllTopics()\"\r\n        class=\"form-checkbox\">\r\n      <label for=\"select_all_topics\">\r\n        Select All\r\n      </label>\r\n    </div> -->\r\n    <div class=\"topic-listing-container\">\r\n      <kendo-treeview\r\n          [nodes]=\"topicsData\"\r\n          [hasChildren]=\"hasChildren\"\r\n          [children]=\"children\"\r\n          kendoTreeViewSelectable\r\n          kendoTreeViewHierarchyBinding\r\n          kendoTreeViewExpandable\r\n          textField=\"topicName\"\r\n          [kendoTreeViewCheckable]=\"checkableSettings\"\r\n          [(checkedKeys)]=\"checkedKeys\"\r\n          checkBy=\"topicId\"\r\n          (checkedChange)=\"handleChecking($event)\"\r\n      >\r\n       </kendo-treeview>\r\n    </div>\r\n    <!-- <div class=\"example-config\">\r\n           Checked keys: {{checkedKeys.join(\"|\")}}\r\n       </div> -->\r\n    <div class=\"extraMargin row  pull-right\" style=\"margin: 15px\">\r\n      <button class=\"btn\" (click)=\"closeAlert()\">Cancel</button>\r\n      <button class=\"btn fullBlue\"  (click)=\"saveTopic()\">Save</button>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n<section *ngIf=\"showTopicsPopUp\">\r\n    <div class=\"topicBox\">\r\n        <div class=\"close-btn\">\r\n          <span (click)=\"closeTopicModal()\">X</span>\r\n        </div>\r\n        <div class=\"header-container\">\r\n          <div class=\"sub-header\">\r\n            <span style=\"font-weight: 600;\">Subject : </span>\r\n            <span id=\"topicSubName\">{{selectedCourseName}}</span>\r\n          </div>\r\n         \r\n        </div>\r\n        <div class=\"topic-listing-container\" style=\"overflow-x: hidden;\">\r\n           <ng-container *ngTemplateOutlet=\"topicsRecursiveList; context:{$implicit: topicsList, level: 1 }\"></ng-container> \r\n        </div>\r\n        <div class=\"extraMargin row  pull-right\" style=\"margin: 15px\">\r\n          <button class=\"btn\" (click)=\"closeTopicModal()\">Cancel</button>\r\n          <button class=\"btn fullBlue\" *ngIf=\"showTopicsPopUp && !showExamEditModal\" (click)=\"saveSelectedTopics()\">Save</button>\r\n          <button class=\"btn fullBlue\" *ngIf=\"showExamEditModal\" (click)=\"linkTopics()\">Save</button>\r\n        </div>\r\n      </div>\r\n</section>\r\n<ng-template #topicsRecursiveList let-topicsList let-level=\"level\">\r\n <div style=\"margin:2px !important\" *ngFor=\"let topic of topicsList\">\r\n    <div class=\"topic-container\" [ngClass]=\"level == 1 ? 'level1Topic': 'subTopicLevel'\">\r\n        <div class=\"arrow-icon\"  [style.visibility]=\"topic.subTopic.length ? 'visible':'hidden'\" (click)=\"toggleArrow(topic)\">\r\n          <i [ngClass]=\"topic.isExpand ? 'fa fa-caret-down': 'fa fa-caret-right'\" style=\"font-size: 15px!important;\"></i>\r\n        </div>\r\n        <div class=\"field-checkbox-wrapper\" style=\"margin-bottom: 5px !important;padding-left:0px !important\">\r\n        <input type=\"checkbox\" [(ngModel)]=\"topic.checked\"  class=\"form-checkbox\" value=\"{{topic.checked}}\" (click)=\"selectTopics(topic,$event)\" id=\"topic-{{topic.topicId}}\" />\r\n        <label for=\"topic-{{topic.topicId}}\" style=\"margin-left:25px !important\">{{topic.topicName}}</label>\r\n        <div *ngIf=\"topic.isExpand\" >\r\n            <ng-container  *ngTemplateOutlet=\"topicsRecursiveList; context:{ $implicit: topic.subTopic, level: level + 1  }\">\r\n            </ng-container>\r\n        </div>\r\n    </div>\r\n        \r\n    </div> \r\n </div>\r\n</ng-template>\r\n\r\n<div class=\"black-bg\" id=\"black-bg\" [hidden]=\"topicBox\" (click)=\"closeAlert()\">\r\n\r\n</div>\r\n<div class=\"black-bg\" id=\"black-bg\" [hidden]=\"!showTopicsPopUp\" >\r\n\r\n</div>\r\n\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n\r\n<section id=\"popup \" class=\"popupWrapper fadeIn \" *ngIf=\"markAttendancePopUp\">\r\n    <div class=\"popup pos-abs popup-body-container \">\r\n        <div class=\"popup-wrapper pos-rel \">\r\n            <span class=\"closePopup pos-abs fbold show \" id=\"popupCloseBtn \" (click)=\"closeCourseLevelAttendance()\">\r\n                <svg xmlns=\"http://www.w3.org/2000/svg \" viewBox=\"9310 2185 16 16 \">\r\n                    <g id=\"Group_1228 \" data-name=\"Group 1228 \" transform=\"translate(8298 1888) \">\r\n                        <g id=\"Group_1213 \" data-name=\"Group 1213 \" transform=\"translate(34.189 -7.77) \">\r\n                            <line id=\"Line_274 \" data-name=\"Line 274 \" class=\"cls-1 \" y2=\"19.798 \" transform=\"translate(992.81 305.77)\r\n                      rotate(45) \" />\r\n                            <line id=\"Line_275 \" data-name=\"Line 275 \" class=\"cls-1 \" x1=\"19.798 \" transform=\"translate(978.81 305.77)\r\n                      rotate(45) \" />\r\n                        </g>\r\n                        <rect id=\"Rectangle_686 \" data-name=\"Rectangle 686 \" style=\"stroke:none; \" class=\"cls-2 \" width=\"16\r\n                      \" height=\"16 \" transform=\"translate(1012 297) \" />\r\n                    </g>\r\n                </svg>\r\n            </span>\r\n            <div class=\"popup-content\">\r\n                <h2>Mark/Update Exam Attendance</h2>\r\n\r\n                <div class=\"attendanceWrapperCourse\">\r\n\r\n                    <div class=\"row attendance-Note\">\r\n                        <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n                            <div class=\"form-wrapper\">\r\n                                <label for=\"attedNote\">Exam Description</label>\r\n                                <textarea class=\"side-form-ctrl\" [(ngModel)]=\"attendanceNote\" id=\"attedNote\" name=\"attedNote\" placeholder=\"Enter Exam Description\"></textarea>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"c-sm-6 c-md-6 c-lg-6\" style=\"margin-top: 20px;\">\r\n                            <div class=\"field-checkbox-wrapper\">\r\n\r\n                                <input type=\"checkbox\" value=\"\" id=\"msgAbsentees\" name=\"msgAbsentees\" class=\"form-checkbox\" [(ngModel)]=\"smsAbsenteesChkbx\">\r\n                                <label for=\"msgAbsentees\">Send Sms For Absentees</label>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row filterSection\">\r\n                        <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                            <h3>Total Students : {{studentList.length}} </h3>\r\n                        </div>\r\n\r\n                        <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n\r\n                            <span class=\"leave\">{{leaveCount}}</span>\r\n                            <h5>Leave</h5>\r\n\r\n                            <span class=\"absent\">{{absentCount}}</span>\r\n                            <h5>Absent</h5>\r\n\r\n                            <span class=\"present\">{{presentCount}}</span>\r\n                            <h5>Present</h5>\r\n                        </div>\r\n\r\n                        <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                            <div class=\"field-checkbox-wrapper\">\r\n\r\n                                <input type=\"checkbox\" value=\"\" class=\"form-checkbox\" id=\"MarkPresent\" [checked]=\"checkCheckAllChkboxStatus()\" (change)=\"markAllPresent($event)\">\r\n                                <label for=\"MarkAllPresent\">Mark All Present</label>\r\n                            </div>\r\n                        </div>\r\n\r\n                    </div>\r\n\r\n                    <div class=\"attendanceMain\">\r\n                        <div class=\"table-scroll-wrapper\">\r\n                            <div class=\"table table-responsive\">\r\n                                <table>\r\n                                    <thead>\r\n                                        <tr>\r\n                                            <th style=\"font-size: 14px;font-weight: 600;\">Student Id</th>\r\n                                            <th style=\"font-size: 14px;font-weight: 600;\">Student Name</th>\r\n                                            <th style=\"font-size: 14px;font-weight: 600;\">Attendance</th>\r\n                                        </tr>\r\n                                    </thead>\r\n                                    <tbody>\r\n                                        <tr *ngFor=\"let s of studentList; let i=index;\">\r\n                                            <td>\r\n                                                {{s.student_disp_id}}\r\n                                            </td>\r\n                                            <td>\r\n                                                {{s.student_name}}\r\n                                            </td>\r\n                                            <td>\r\n                                                <div class=\"btnGroup\">\r\n                                                    <button id=\"leaveBtnCourse{{s.student_id}}\" [disabled]=\"getDisability(s)\" (click)=\"markAttendaceBtnClickCourse($event , s , i)\"\r\n                                                        class=\"btn\" [ngClass]=\"getClassForLeave(s)\">L</button>\r\n                                                    <button id=\"absentBtnCourse{{s.student_id}}\" [disabled]=\"getDisability(s)\" (click)=\"markAttendaceBtnClickCourse($event , s, i)\"\r\n                                                        class=\"btn\" [ngClass]=\"getClassForAbsent(s)\">A</button>\r\n                                                    <button id=\"presentBtnCourse{{s.student_id}}\" [disabled]=\"getDisability(s)\" (click)=\"markAttendaceBtnClickCourse($event , s, i)\"\r\n                                                        class=\"btn\" [ngClass]=\"getClassForPresent(s)\">P</button>\r\n                                                </div>\r\n                                            </td>\r\n\r\n                                        </tr>\r\n                                        <tr *ngIf=\"studentList.length == 0\">\r\n                                            <td colspan=\"3\">\r\n                                                No Students Record\r\n                                            </td>\r\n                                        </tr>\r\n                                    </tbody>\r\n                                </table>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"clearfix\" style=\"margin-top: 10px\">\r\n                        <aside class=\"pull-right popup-btn\">\r\n                            <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closeCourseLevelAttendance()\">\r\n                            <input type=\"button\" value=\"Mark Attendance\" (click)=\"updateCourseAttendance()\" class=\"fullBlue btn\">\r\n                        </aside>\r\n                    </div>\r\n\r\n                </div>\r\n\r\n            </div>\r\n        </div>\r\n    </div>\r\n</section>\r\n\r\n\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n\r\n<section id=\"popup \" class=\"popupWrapper fadeIn \" *ngIf=\"cancelExamPopUp\">\r\n    <div class=\"popup pos-abs popup-body-container \">\r\n        <div class=\"popup-wrapper pos-rel \">\r\n            <span class=\"closePopup pos-abs fbold show \" id=\"popupCloseBtn \" (click)=\"closeCancelExamPopUp()\">\r\n              <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n                <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" style=\"fill: currentColor\"></path>\r\n              </svg>\r\n            </span>\r\n            <div class=\"popup-content\">\r\n                <h2 *ngIf=\"isLangInstitute\">Batch Exam Schedule ({{cancelExamData.exam_date}} ({{cancelExamData.start_time}} - {{cancelExamData.end_time}}))\r\n                    Cancellation\r\n                </h2>\r\n                <h2 *ngIf=\"!isLangInstitute\">\r\n                    Do you want to cancel scheduled Exam?\r\n                </h2>\r\n\r\n                <div class=\"cancel-Class-Wrapper\">\r\n\r\n                    <div class=\"row attendance-Note\">\r\n                        <div class=\"c-sm-12 c-md-12 c-lg-12\" style=\"padding: 0px 0px;\">\r\n                            <div class=\"form-wrapper\">\r\n                                <label for=\"cancelTxtBx\">Cancellation Reason\r\n                                 <span class=\"text-danger\">*</span>\r\n                                </label>\r\n                                <textarea class=\"side-form-ctrl\" style=\"height: 90px;\" [(ngModel)]=\"cancelPopUpData.reason\" id=\"cancelTxtBx\" name=\"cancelTxtBx\"></textarea>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"clearfix\" style=\"margin-top: 10px\">\r\n                        <aside class=\"pull-left\" style=\"margin-top: 10px\">\r\n                            <div class=\"field-checkbox-wrapper\">\r\n                                <input type=\"checkbox\" value=\"\" id=\"chkBxNotifyStudent\" name=\"chkBxNotifyStudent\" class=\"form-checkbox\" [(ngModel)]=\"cancelPopUpData.notify\">\r\n                                <label for=\"chkBxNotifyStudent\">Notify Students</label>\r\n                            </div>\r\n                        </aside>\r\n                        <aside *ngIf=\"isLangInstitute\" class=\"pull-right popup-btn\">\r\n                            <input type=\"button\" value=\"No\" class=\"btn\" (click)=\"closeCancelExamPopUp()\" style=\"width:70px;\">\r\n                            <input type=\"button\" value=\"Yes\" (click)=\"cancelExamClassSchedule()\" class=\"fullBlue btn\" style=\"width:70px;\">\r\n                        </aside>\r\n                        <aside *ngIf=\"!isLangInstitute\" class=\"pull-right popup-btn\">\r\n                            <input type=\"button\" value=\"No\" class=\"btn\" (click)=\"closeCancelExamPopUp()\" style=\"width:70px;\">\r\n                            <input *ngIf=\"jsonVar.cancelCourseLevel\" type=\"button\" value=\"Yes\" (click)=\"cancelCourseLevelExam()\" class=\"fullBlue btn\" style=\"width:70px;\">\r\n                            <input *ngIf=\"!jsonVar.cancelCourseLevel\" type=\"button\" value=\"Yes\" (click)=\"cancelCourseExam()\" class=\"fullBlue btn\" style=\"width:70px;\">\r\n                        </aside>\r\n                    </div>\r\n\r\n                </div>\r\n\r\n            </div>\r\n        </div>\r\n    </div>\r\n</section>\r\n\r\n\r\n<!--\r\n<div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n  <span>{{row.subject_name}}</span>\r\n\r\n</div>\r\n\r\n<div class=\"c-sm-1 c-lg-1 c-md-1\" *ngIf=\"(data.selectedCourseList.is_exam_grad_feature == 0)\">\r\n  <span>{{row.total_marks}}</span>\r\n  <input type=\"text\" class=\"side-form-ctrl torlMarksWidth\" name=\"label\" [(ngModel)]=\"row.total_marks\">\r\n</div>\r\n\r\n<div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n  <span>{{row.class_desc}}</span>\r\n  <input type=\"text\" class=\"side-form-ctrl torlMarksWidth\" name=\"label\" [(ngModel)]=\"row.total_marks\">\r\n  <input type=\"Text\" class=\"side-form-ctrl  constantHeight\" placeholder=\"Topics\" id=\"topics\">\r\n</div>\r\n\r\n\r\n  <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n    <span>{{row.exam_desc}}</span>\r\n    <textarea class=\"side-form-ctrl constantHeight\" [(ngModel)]=\"data.courseModelAdder.exam_desc\" id=\"customDescTxt\" name=\"customDescTxt\"></textarea>\r\n  </div>\r\n\r\n  <div class=\"c-sm-2 c-lg-2 c-md-2\">\r\n    <span>{{row.room_no}}</span>\r\n    <input type=\"string\" class=\"side-form-ctrl constantHeight\" [(ngModel)]=\"data.courseModelAdder.room_no\" id=\"inpTotalMarks\">\r\n  </div> -->\r\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-exam/course-exam.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.middle-section {\n  padding: 10px 10px; }\n.langModelCss .examAdder .btnAdd {\n  margin-top: 20px; }\n.langModelCss .row {\n  margin-top: 10px; }\n.langModelCss .btn-Group {\n  margin-right: 5px;\n  margin-bottom: 5px; }\n.langModelCss .cancelClass-table {\n  margin-top: 5px; }\n.langModelCss h3 {\n  margin-top: 10px;\n  margin-left: 0px; }\n.common-search-filter {\n  border-bottom: 1px solid #d3d4d5;\n  padding: 5px 5px 10px 5px; }\n.common-search-filter .field-wrapper {\n    background: transparent; }\n.common-search-filter .field-wrapper .form-ctrl {\n      border-radius: 4px; }\n.common-search-filter .batchTimeDet {\n    margin-top: 5px; }\n.content-section {\n  margin: 5px 0px; }\n.content-section .action-Menu {\n    cursor: pointer; }\n.content-section .action-Menu span {\n      margin-right: 5px; }\n.constantHeight {\n  height: 30px; }\n.form-wrapper {\n  background: transparent; }\n.form-wrapper.datepicker span {\n    position: absolute;\n    top: 35px;\n    right: 20px;\n    font-weight: 600;\n    font-size: 16px;\n    color: red;\n    cursor: pointer;\n    width: 20px;\n    text-align: center;\n    /* &::before {\r\n                content: '';\r\n                background: url('/assets/images/calendar.svg') no-repeat;\r\n                position: absolute;\r\n                right: 25px;\r\n                top: 0px;\r\n                width: 21px;\r\n                height: 21px;\r\n                z-index: 0;\r\n            } */ }\n.form-wrapper label {\n    font-size: 12px;\n    color: rgba(0, 0, 0, 0.77);\n    padding-bottom: 2px;\n    text-decoration: none;\n    -webkit-font-smoothing: antialiased;\n    font-weight: 600; }\n.form-wrapper .side-form-ctrl {\n    background: white;\n    border: 1px solid rgba(119, 119, 119, 0.419608);\n    width: 100%;\n    padding: 8px 5px;\n    border-radius: 4px;\n    font-size: 14px;\n    color: black; }\n.form-wrapper .side-form-ctrl.bsDatepicker {\n      padding: 5px;\n      width: 100%; }\n.form-wrapper.timepick {\n    padding: 1px 0px; }\n.form-wrapper.timepick .tbox {\n      display: inline-block; }\n.form-wrapper.timepick .tbox .times {\n        display: inline-block; }\n.form-wrapper.timepick .tbox .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        padding: 4px 5px;\n        font-size: 14px;\n        border-radius: 4px;\n        color: black; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mins {\n          width: auto; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mers {\n          width: 50px; }\n.save_btn_container {\n  position: absolute;\n  bottom: 0px;\n  right: 0px;\n  width: 94%;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  background: white; }\n.field-wrapper.datePickerBox:after {\n  content: '';\n  background: url(/./assets/images/calendar.svg) no-repeat;\n  position: absolute;\n  right: 5px;\n  top: 28px;\n  width: 21px;\n  height: 21px;\n  z-index: 0; }\n.attendanceWrapperCourse {\n  border-top: 2px solid #eee;\n  margin-top: 15px;\n  max-height: 480px;\n  overflow: hidden; }\n.attendanceWrapperCourse .filterSection {\n    padding: 20px 0px 10px 0px !important;\n    margin: 0px !important;\n    background-color: #efefef; }\n.attendanceWrapperCourse .filterSection span {\n      padding: 4px 12px;\n      margin-left: 4px; }\n.attendanceWrapperCourse .filterSection h5 {\n      margin-left: 4px;\n      display: inline-block;\n      font-weight: 200;\n      font-size: 13px; }\n.attendanceWrapperCourse .filterSection .absent {\n      color: white;\n      background: #fe552a;\n      border-radius: 5px; }\n.attendanceWrapperCourse .filterSection .present {\n      color: white;\n      background: #4191da;\n      border-radius: 5px; }\n.attendanceWrapperCourse .filterSection .leave {\n      color: white;\n      background: #7a7a7a;\n      border-radius: 5px; }\n.attendanceWrapperCourse .attendanceMain .table-scroll-wrapper {\n    max-height: 375px;\n    overflow: auto; }\n.attendanceWrapperCourse .attendanceMain ::-webkit-scrollbar {\n    display: block; }\n.attendanceWrapperCourse tr td {\n    padding: 0px 20px !important; }\n.attendanceWrapperCourse .form-wrapper .form-ctrl {\n    border: 2px solid #efefef; }\n.btnGroup {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  margin-bottom: 4px !important; }\n.btnGroup .btn {\n    padding: 0px 8px 0px 8px;\n    margin: 0px 5px;\n    width: 29%;\n    height: 22px;\n    font-size: 14px;\n    border-radius: 6px; }\n.btnGroup .classLeaveBtn {\n    color: white;\n    text-align: center;\n    background: #7a7a7a; }\n.btnGroup .classAbsentBtn {\n    color: white;\n    text-align: center;\n    background: #fe552a; }\n.btnGroup .classPresentBtn {\n    color: white;\n    background: #4191da;\n    color: white;\n    text-align: center; }\n@media only screen and (max-width: 767px) {\n  .attendanceWrapper {\n    border-top: 2px solid #eee;\n    margin-top: 15px;\n    max-height: 420px;\n    overflow: hidden; }\n    .attendanceWrapper .row {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex; }\n      .attendanceWrapper .row .tableSection {\n        display: inline-block;\n        width: 100%;\n        padding: 10px;\n        background: #fff; }\n        .attendanceWrapper .row .tableSection .button-row {\n          position: relative;\n          height: 45px;\n          padding: 0px 10px; }\n          .attendanceWrapper .row .tableSection .button-row button {\n            position: absolute;\n            right: 10px;\n            border: 2px solid #0084f6; }\n        .attendanceWrapper .row .tableSection .filterSection {\n          padding: 20px 0px 10px 0px !important;\n          margin: 0px !important;\n          background-color: #efefef; }\n          .attendanceWrapper .row .tableSection .filterSection span {\n            padding: 4px 12px; }\n          .attendanceWrapper .row .tableSection .filterSection .absent {\n            color: white;\n            background: #fe552a;\n            border-radius: 5px; }\n          .attendanceWrapper .row .tableSection .filterSection .present {\n            color: white;\n            background: #4191da;\n            border-radius: 5px; }\n          .attendanceWrapper .row .tableSection .filterSection .leave {\n            color: white;\n            background: #7a7a7a;\n            border-radius: 5px; }\n        .attendanceWrapper .row .tableSection .studentTableWrapper {\n          width: 100%; }\n          .attendanceWrapper .row .tableSection .studentTableWrapper .schedule-bottom {\n            width: 100%; }\n            .attendanceWrapper .row .tableSection .studentTableWrapper .schedule-bottom ul {\n              border-left: 2px solid rgba(211, 212, 213, 0.5);\n              border-right: 2px solid rgba(211, 212, 213, 0.5); }\n        .attendanceWrapper .row .tableSection .row {\n          margin-left: 10px; } }\n.torlMarksWidth {\n  width: 50px !important; }\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 40%;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 10%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff;\n  border-radius: 6px; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n.spanText {\n  font-size: 12px; }\ninput[type=number]::-webkit-inner-spin-button,\ninput[type=number]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0; }\n.courseModelWrapper {\n  margin-bottom: 35px; }\n.courseModelWrapper .row {\n    margin: 5px 0px; }\n.courseModelWrapper table thead tr th {\n    padding: 5px 0px !important; }\n.subjectName {\n  width: 200px !important;\n  padding: 0px 0px !important; }\n.exam_adder_div {\n  margin-top: 10px;\n  margin-bottom: 10px;\n  border-spacing: 0px 2px;\n  -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n          box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16); }\n.exam_adder_div .dateInfo, .exam_adder_div .basic-detail {\n    background: #f9f9f9;\n    padding: 6px; }\n.exam_adder_div .dateInfo {\n    margin-bottom: 0px; }\n.exam_adder_div .basic-detail {\n    margin-top: 0px; }\n.exam_adder_div .topic-link {\n    cursor: pointer;\n    border: 1px solid #cccccc; }\n.exam_adder_div .topic-linked {\n    cursor: pointer;\n    border: 1px solid #1283f4; }\n.exam_adder_div .topic-linked::-webkit-input-placeholder {\n    color: #1283f4; }\n.exam_adder_div .topic-linked:-ms-input-placeholder {\n    color: #1283f4; }\n.exam_adder_div .topic-linked::-ms-input-placeholder {\n    color: #1283f4; }\n.exam_adder_div .topic-linked::placeholder {\n    color: #1283f4; }\n.topic-link {\n  cursor: pointer;\n  border: 1px solid #cccccc; }\n.topic-link::-webkit-input-placeholder {\n  color: #cccccc; }\n.topic-link:-ms-input-placeholder {\n  color: #cccccc; }\n.topic-link::-ms-input-placeholder {\n  color: #cccccc; }\n.topic-link::placeholder {\n  color: #cccccc; }\n.topic-linked {\n  cursor: pointer;\n  border: 1px solid #1283f4 !important; }\n.topic-linked::-webkit-input-placeholder {\n  color: #1283f4; }\n.topic-linked:-ms-input-placeholder {\n  color: #1283f4; }\n.topic-linked::-ms-input-placeholder {\n  color: #1283f4; }\n.topic-linked::placeholder {\n  color: #1283f4; }\n.topictext {\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  max-width: 12%; }\n.displayComp .edit-comp {\n  display: none; }\n.editComp .view-comp {\n  display: none; }\n.black-bg {\n  background: rgba(10, 10, 10, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 1;\n  width: 100%; }\n.topicBox {\n  position: fixed;\n  top: 20%;\n  left: 20%;\n  right: 20%;\n  width: 60%;\n  z-index: 100;\n  background: #f7f5f5;\n  -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n          box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n  border-radius: 4px; }\n.close-btn {\n  position: absolute;\n  right: 10px;\n  top: 10px;\n  font-size: 16px;\n  font-weight: 600; }\n.close-btn span {\n    cursor: pointer; }\n.header-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  padding: 10px;\n  margin-top: 20px;\n  border-bottom: 1px solid rgba(10, 10, 10, 0.7); }\n.sub-header {\n  width: 30%; }\n.total-topic {\n  width: 20%;\n  margin-left: 10%; }\n.topic-listing-container {\n  overflow-y: scroll;\n  max-height: 270px; }\n.tooltip {\n  position: relative;\n  display: inline-block;\n  border-bottom: 1px dotted black;\n  /* If you want dots under the hoverable text */ }\n/* Tooltip text */\n.tooltip .tooltiptext {\n  visibility: hidden;\n  width: 120px;\n  background-color: black;\n  color: #fff;\n  text-align: center;\n  padding: 5px 0;\n  border-radius: 6px;\n  /* Position the tooltip text - see examples below! */\n  position: absolute;\n  z-index: 1; }\n/* Show the tooltip text when you mouse over the tooltip container */\n.tooltip:hover .tooltiptext {\n  visibility: visible; }\n.k-treeview .k-in.k-state-selected {\n  background-color: transparent;\n  color: #656565; }\n.k-checkbox:indeterminate + .k-checkbox-label::after {\n  background-color: #0084f6; }\n.k-checkbox:checked + .k-checkbox-label::before {\n  border-color: #0084f6;\n  background-color: #0084f6; }\n.k-treeview .k-content, .k-treeview > .k-group, .k-treeview .k-item > .k-group {\n  padding: 10px; }\n.k-checkbox:indeterminate + .k-checkbox-label::after {\n  background-color: #0084f6; }\n.k-checkbox:indeterminate + .k-checkbox-label::after {\n  content: \"\";\n  -webkit-transform: scale(1);\n  transform: scale(1);\n  width: 8px;\n  height: 8px;\n  top: 4px;\n  left: 4px; }\n.loopingDiv {\n  margin-top: 10px;\n  margin-bottom: 10px;\n  border-spacing: 0px 2px;\n  -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n          box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16); }\n.loopingDiv .dateInfo, .loopingDiv .basic-detail {\n    background: #f9f9f9;\n    padding: 6px; }\n.loopingDiv .dateInfo {\n    margin-bottom: 0px; }\n.loopingDiv .basic-detail {\n    margin-top: 0px; }\n.small-btn {\n  height: auto !important;\n  padding: 0.4em 0.8em !important;\n  border-radius: 0.2em !important; }\n.action_btn {\n  background: white;\n  color: #3d89f0;\n  border-radius: 4px; }\n.add_exam_btn {\n  background: #3d89f0;\n  color: white;\n  border-radius: 4px; }\n.mail-notification {\n  width: 20px;\n  height: 20px;\n  background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%223872.5 2200.5 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-3 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %2395989a%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        fill%3A %230084f6%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1424%22 data-name%3D%22Group 1424%22 transform%3D%22translate(2798 1737)%22%3E%0D    %3Cg id%3D%22Group_1414%22 data-name%3D%22Group 1414%22 transform%3D%22translate(-174 -64)%22%3E%0D      %3Cg id%3D%22Group_1453%22 data-name%3D%22Group 1453%22%3E%0D        %3Cellipse id%3D%22Ellipse_63%22 data-name%3D%22Ellipse 63%22 class%3D%22cls-1%22 cx%3D%222.595%22 cy%3D%222.595%22 rx%3D%222.595%22 ry%3D%222.595%22 transform%3D%22translate(1260.811 530)%22%2F%3E%0D        %3Cpath id%3D%22Path_547%22 data-name%3D%22Path 547%22 class%3D%22cls-1%22 d%3D%22M15.7%2C9.838v4.541a1.735%2C1.735%2C0%2C0%2C1-1.73%2C1.73H2.73A1.735%2C1.735%2C0%2C0%2C1%2C1%2C14.378V5.73A1.735%2C1.735%2C0%2C0%2C1%2C2.73%2C4h7.308%22 transform%3D%22translate(1249 527.297)%22%2F%3E%0D        %3Cpath id%3D%22Path_548%22 data-name%3D%22Path 548%22 class%3D%22cls-1%22 d%3D%22M1%2C8l7.351%2C4.324%2C3.027-1.73%22 transform%3D%22translate(1249 525.027)%22%2F%3E%0D      %3C%2Fg%3E%0D      %3Ccircle id%3D%22Ellipse_64%22 data-name%3D%22Ellipse 64%22 class%3D%22cls-2%22 cx%3D%221.73%22 cy%3D%221.73%22 r%3D%221.73%22 transform%3D%22translate(1261.676 530.865)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Cpath id%3D%22Path_552%22 data-name%3D%22Path 552%22 class%3D%22cls-3%22 d%3D%22M.5.5h18v18H.5Z%22 transform%3D%22translate(1074 463)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n  cursor: pointer;\n  display: inline-block; }\n.form-wrapper.datePickerBox:after {\n  content: '';\n  background: url(/./assets/images/calendar.svg) no-repeat;\n  position: absolute;\n  right: 18px;\n  top: 28px;\n  width: 21px;\n  height: 21px;\n  z-index: 0; }\n.black-bg {\n  background: rgba(12, 11, 11, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 6;\n  width: 100%; }\n.topic-container {\n  margin-right: 0 !important;\n  margin-left: 0 !important;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row; }\n.arrow-icon {\n  padding: 0 5px; }\n.level1Topic {\n  padding-top: 4px;\n  padding-bottom: 2px; }\n.subTopicLevel {\n  padding-top: 8px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-exam/course-exam.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CourseExamComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return DateMonthFormat; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_course_services_exam_schedule_service__ = __webpack_require__("./src/app/services/course-services/exam-schedule.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_rxjs_observable_of__ = __webpack_require__("./node_modules/rxjs/_esm5/observable/of.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_course_services_topic_listing_service__ = __webpack_require__("./src/app/services/course-services/topic-listing.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var CourseExamComponent = /** @class */ (function () {
    function CourseExamComponent(apiService, toastCtrl, auth, topicService, cd) {
        this.apiService = apiService;
        this.toastCtrl = toastCtrl;
        this.auth = auth;
        this.topicService = topicService;
        this.cd = cd;
        this.masterCourseList = [];
        this.courseList = [];
        this.batchesList = [];
        this.examScheduleData = [];
        this.cancelledSchedule = [];
        this.studentList = [];
        this.examSchedule = [];
        this.viewList = [];
        this.subjectListData = [];
        this.newExamSubjectData = [];
        this.subjectListDataSource = [];
        this.subject_topics = [];
        this.row_edit_subject_topicId = [];
        this.checkedKeys = [];
        this.topicsName = [];
        this.isLangInstitute = false;
        this.showContentSection = false;
        this.showCourseStartEndDate = false;
        this.markAttendancePopUp = false;
        this.cancelExamPopUp = false;
        this.smsAbsenteesChkbx = false;
        this.absentCount = 0;
        this.presentCount = 0;
        this.leaveCount = 0;
        this.attendanceNote = "";
        this.batchAdderData = {
            exam_date: __WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-DD"),
            exam_desc: "",
            start_time: {
                hour: "12 PM",
                minute: '00'
            },
            end_time: {
                hour: "1 PM",
                minute: "00"
            },
            total_marks: 0,
            topics_covered: ''
        };
        this.batchData = {
            standard_id: -1,
            subject_id: -1,
            batch_id: -1,
        };
        this.cancelPopUpData = {
            reason: "",
            notify: true
        };
        this.courseData = {
            master_course: '-1',
            course_id: -1,
            requested_date: __WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-DD")
        };
        this.types = [
            { label: 'Course', value: 'course' },
            { label: 'Subject', value: 'subject' }
        ];
        this.batchStartDate = "";
        this.batchEndDate = "";
        this.markAttendanceData = "";
        this.cancelExamData = "";
        this.times = ['1 AM', '2 AM', '3 AM', '4 AM', '5 AM', '6 AM', '7 AM', '8 AM', '9 AM', '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM', '4 PM', '5 PM', '6 PM', '7 PM', '8 PM', '9 PM', '10 PM', '11 PM', '12 AM'];
        this.minArr = ['00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55'];
        this.selectedType = "course";
        this.currentDate = __WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-DD");
        this.jsonVar = {
            isSheduleBatch: true,
            cancelCourseLevel: false
        };
        this.newExamData = {
            startTimeHrs: '12 PM',
            startTimeMins: '00',
            endTimeHrs: '1 PM',
            endTimeMins: '00',
            total_marks: ''
        };
        this.exam_desc = '';
        this.exam_room_no = '';
        this.subject_id = '';
        this.subject_name = '';
        this.exam_marks = '';
        this.edit_subject_id = '';
        this.edit_subject_name = '';
        this.edit_exam_marks = '';
        this.edit_subject_topics = '';
        this.edit_exam_desc = '';
        this.edit_exam_room_no = '';
        this.row_edit_subject_id = '';
        this.row_edit_subject_name = '';
        this.row_edit_exam_marks = '';
        this.row_edit_subject_topics = '';
        this.row_edit_exam_desc = '';
        this.row_edit_exam_room_no = '';
        this.total_marks_to_show = 0;
        // Topic listing variables
        this.topicBox = true;
        this.selectAllTopics = false;
        this.showTopicsPopUp = false;
        this.topicsList = [];
        this.totalTopicsList = [];
        this.subjectsList = [];
        this.selectedTopicsListObj = [];
        this.selectedTopics = '';
        this.getSubjectObject = '';
        this.showExamEditModal = false;
        this.enableCheck = true;
        this.checkChildren = true;
        this.checkParents = true;
        this.checkOnClick = true;
        this.checkMode = 'multiple';
        this.topicLinkColor = false;
        this.changeColor = false;
        this.multiClickDisabled = false;
        this.isRippleLoad = false;
        this.selectedRow = "";
        this.coursePlannerStatus = false;
    }
    Object.defineProperty(CourseExamComponent.prototype, "checkableSettings", {
        get: function () {
            return {
                checkChildren: this.checkChildren,
                checkParents: this.checkParents,
                enabled: this.enableCheck,
                mode: this.checkMode,
                checkOnClick: this.checkOnClick
            };
        },
        enumerable: true,
        configurable: true
    });
    CourseExamComponent.prototype.ngOnInit = function () {
        this.checkInstituteType();
        this.fetchPrefillData();
        this.checkForCoursePlannerRoute();
    };
    CourseExamComponent.prototype.checkForCoursePlannerRoute = function () {
        this.coursePlannerStatus = sessionStorage.getItem('isFromCoursePlanner');
    };
    CourseExamComponent.prototype.fetchPrefillData = function () {
        if (this.isLangInstitute) {
            this.getMasterCourseBatchData();
        }
        else {
            this.getMasterCourseList();
        }
    };
    CourseExamComponent.prototype.getMasterCourseBatchData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getCombinedList(this.batchData.standard_id, this.batchData.subject_id).subscribe(function (res) {
            _this.isRippleLoad = false;
            if (_this.masterCourseList.length == 0) {
                _this.masterCourseList = res.standardLi;
            }
            if (res.batchLi != null && res.batchLi.length > 0) {
                _this.batchesList = res.batchLi;
                _this.subjectsList = res.subjectLi;
            }
            if (res.subjectLi != null && res.subjectLi.length > 0) {
                _this.courseList = res.subjectLi;
                _this.subjectsList = res.subjectLi;
            }
        }, function (err) {
            console.log(err);
            _this.isRippleLoad = false;
        });
    };
    CourseExamComponent.prototype.fetchTopics = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.totalTopicsList = [];
        this.selectedTopics = '';
        this.selectedTopicsListObj = [];
        this.topicService.getAllTopicsSubTopics(this.batchData.subject_id).subscribe(function (data) {
            _this.topicsList = [];
            _this.topicsList = data;
            if (_this.topicsList.length && _this.topicsList != null) {
                _this.showTopicsPopUp = true;
                _this.isRippleLoad = false;
                _this.topicsList.forEach(function (tpc) {
                    _this.totalTopicsList.push(tpc);
                    tpc.checked = false;
                    if (tpc.subTopic.length) {
                        _this.getAllTopics(tpc.subTopic);
                    }
                });
            }
            else {
                _this.isRippleLoad = false;
                _this.messageNotifier('info', 'Info', 'No topics available to link !');
            }
        }, function (err) {
            _this.isRippleLoad = false;
            _this.messageNotifier('error', '', err.error.message);
        });
    };
    CourseExamComponent.prototype.saveSelectedTopics = function () {
        /* if(this.totalTopicsList.filter(el => el.checked == true).length == 0){
          this.messageNotifier('info','Info', 'Please select topics to save !')    }
        else { */
        this.isRippleLoad = true;
        this.selectedTopicsListObj = [];
        this.selectedTopicsListObj = this.totalTopicsList.filter(function (obj) { return obj.checked == true; });
        if (this.selectedTopicsListObj != undefined) {
            this.selectedTopics = this.selectedTopicsListObj.map(function (obj) {
                return obj.topicId;
            });
            this.selectedTopics = this.selectedTopics.join('|');
        }
        this.messageNotifier('success', '', 'Topics linked successfully');
        this.isRippleLoad = false;
        this.showTopicsPopUp = false;
        // }
    };
    CourseExamComponent.prototype.fetchSelectedTopics = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.showTopicsPopUp = true;
        this.selectedTopicsListObj.forEach(function (obj) {
            var getTopicObject = _this.totalTopicsList.find(function (ele) { return ele.topicId == obj.topicId; });
            getTopicObject.checked = true;
        });
        this.isRippleLoad = false;
    };
    CourseExamComponent.prototype.getAllTopics = function (topic) {
        var _this = this;
        topic.forEach(function (obj) {
            _this.totalTopicsList.push(obj);
            obj.checked = false;
            if (obj.subTopic.length) {
                _this.getAllTopics(obj.subTopic);
            }
        });
    };
    CourseExamComponent.prototype.toggleArrow = function (topic) {
        topic.isExpand = !(topic.isExpand);
    };
    CourseExamComponent.prototype.closeTopicModal = function (topic) {
        this.showTopicsPopUp = false;
        this.showExamEditModal = false;
    };
    CourseExamComponent.prototype.linkTopics = function () {
        var _this = this;
        /* if(this.totalTopicsList.filter(el => el.checked == true).length == 0){
         this.messageNotifier('info','Info','No topics selected')
        }
        else { */
        this.isRippleLoad = true;
        var getSelectedTopics = this.totalTopicsList.filter(function (el) { return el.checked == true; });
        var getTopicIds;
        ;
        if (getSelectedTopics != undefined) {
            getTopicIds = getSelectedTopics.map(function (obj) {
                return obj.topicId;
            });
            getTopicIds = getTopicIds.join('|');
            this.getSubjectObject.topics_covered = getTopicIds;
            this.examSchedule.find(function (ele) { return ele.schd_id == _this.getSubjectObject.schd_id; }).topics_covered = getTopicIds;
        }
        this.showTopicsPopUp = false;
        this.isRippleLoad = false;
        this.showExamEditModal = false;
        this.messageNotifier('success', '', 'Topics updated successfully');
        // }
    };
    //on checkbox check
    CourseExamComponent.prototype.selectTopics = function (topic, event) {
        topic.checked = !topic.checked;
        if (topic.subTopic.length) {
            this.checkAllSubTopics(topic.subTopic, event.target.checked);
        }
        if (!event.target.checked) {
            if (topic.parentTopicId != 0) {
                this.uncheckParent(topic);
            }
        }
        this.checkParent(topic);
    };
    // check/uncheck all subtopics if parent is checked/unchecked
    CourseExamComponent.prototype.checkAllSubTopics = function (topic, param) {
        var _this = this;
        topic.forEach(function (obj) {
            if (param) {
                obj.checked = true;
            }
            else {
                obj.checked = false;
            }
            if (obj.subTopic.length) {
                _this.checkAllSubTopics(obj.subTopic, param);
            }
        });
    };
    //check parent if all subtopics are checked
    CourseExamComponent.prototype.checkParent = function (topic) {
        var checkAll = true;
        if (this.totalTopicsList.find(function (el) { return el.topicId == topic.topicId; }) != undefined) {
            var parentTopic = this.totalTopicsList.find(function (ele) { return ele.topicId == topic.parentTopicId; });
            if (parentTopic != undefined) {
                if (parentTopic.subTopic.length) {
                    parentTopic.subTopic.forEach(function (subTpc) {
                        if (!subTpc.checked) {
                            checkAll = false;
                        }
                    });
                    if (checkAll) {
                        parentTopic.checked = true;
                        if (parentTopic.parentTopicId != 0) {
                            this.checkParent(parentTopic);
                        }
                    }
                }
            }
        }
    };
    //uncheck parent if any of the child is deselected
    CourseExamComponent.prototype.uncheckParent = function (topic) {
        var getParentTopic = this.totalTopicsList.find(function (obj) { return obj.topicId == topic.parentTopicId; });
        if (getParentTopic != undefined) {
            getParentTopic.checked = false;
            if (getParentTopic.parentTopicId != 0) {
                this.uncheckParent(getParentTopic);
            }
        }
    };
    CourseExamComponent.prototype.editTopics = function (row) {
        var _this = this;
        console.log('inside edit topics:', row);
        this.getSubjectObject = '';
        this.getSubjectObject = row;
        this.isRippleLoad = true;
        if (row.topics_covered != '' && row.topics_covered != null) {
            var selectedTopicIds = row.topics_covered.split('|');
        }
        var list = [];
        this.topicService.getAllTopicsSubTopics(this.batchData.subject_id).subscribe(function (res) {
            _this.topicsList = [];
            _this.topicsList = res;
            if (_this.topicsList != null && _this.topicsList.length) {
                _this.showTopicsPopUp = true;
                _this.showExamEditModal = true;
                _this.isRippleLoad = false;
                _this.topicsList.forEach(function (obj) {
                    list.push(obj);
                    if (selectedTopicIds != undefined) {
                        if (selectedTopicIds.indexOf((obj.topicId).toString()) > -1) {
                            obj.checked = true;
                        }
                    }
                    if (obj.subTopic.length) {
                        _this.fetchAllTopics(obj.subTopic, list, selectedTopicIds);
                    }
                });
                _this.totalTopicsList = [];
                _this.totalTopicsList = list;
            }
            else {
                _this.isRippleLoad = false;
                // this.msgService.showErrorMessage(this.msgService.toastTypes.error, 'Error', "No topics available to Link");
                _this.messageNotifier('info', 'Info', 'No topics available to link');
            }
        }, function (err) {
            _this.isRippleLoad = false;
            // this.msgService.showErrorMessage(this.msgService.toastTypes.error, 'Error', err.error.message);
            _this.messageNotifier('error', '', err.error.message);
        });
    };
    CourseExamComponent.prototype.fetchAllTopics = function (topic, list, idList) {
        var _this = this;
        topic.forEach(function (key) {
            if (idList != undefined && idList != null) {
                if (idList.indexOf((key.topicId).toString()) > -1) {
                    key.checked = true;
                }
            }
            list.push(key);
            if (key.subTopic.length) {
                _this.fetchAllTopics(key.subTopic, list, idList);
            }
        });
    };
    CourseExamComponent.prototype.onBatchMasterCourseSelection = function (event) {
        this.batchData.subject_id = -1;
        this.batchData.batch_id = -1;
        this.courseList = [];
        this.batchesList = [];
        this.getMasterCourseBatchData();
    };
    CourseExamComponent.prototype.onBatchCourseSelection = function (event) {
        this.batchData.batch_id = -1;
        if (this.batchData.subject_id != -1) {
            this.batchesList = [];
            this.getMasterCourseBatchData();
        }
        this.getCourseName(event);
    };
    CourseExamComponent.prototype.getCourseName = function (eve) {
        this.selectedCourseName = '';
        this.selectedCourseName = this.subjectsList.find(function (ob) { return ob.subject_id == eve; }).subject_name;
    };
    CourseExamComponent.prototype.batchModelGoClick = function () {
        var _this = this;
        if (this.batchData.batch_id != -1) {
            this.cancelledSchedule = [];
            this.examSchedule = [];
            this.isRippleLoad = true;
            this.apiService.getExamSchedule(this.batchData.batch_id).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.showContentSection = true;
                _this.jsonVar.isSheduleBatch = true;
                _this.examScheduleData = res;
                _this.batchStartDate = _this.examScheduleData.batch_start_date;
                _this.batchEndDate = _this.examScheduleData.batch_end_date;
                if (__WEBPACK_IMPORTED_MODULE_3_moment__(_this.batchEndDate).format("YYYY-MM-DD") < __WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-DD")) {
                    _this.jsonVar.isSheduleBatch = false;
                }
                else {
                    _this.jsonVar.isSheduleBatch = true;
                }
                if (res.otherSchd != "" && res.otherSchd != null) {
                    if (res.otherSchd.length > 0) {
                        _this.examSchedule = res.otherSchd;
                    }
                }
                if (res.cancelSchd != "" && res.cancelSchd != null) {
                    if (res.cancelSchd.length > 0) {
                        _this.cancelledSchedule = res.cancelSchd;
                    }
                }
            }, function (err) {
                _this.isRippleLoad = false;
                //console.log(err);
                _this.messageNotifier('error', '', err.error.message);
            });
        }
        else {
            if (this.batchData.standard_id == -1) {
                this.messageNotifier('error', '', 'Please Select Master Course, Course and then Batch or Batch');
            }
            else if (this.batchData.subject_id == -1) {
                this.messageNotifier('error', '', 'Please Select Course and then Batch or Batch');
            }
            else if (this.batchData.batch_id == -1) {
                this.messageNotifier('error', '', 'Please Select Batch');
            }
        }
    };
    CourseExamComponent.prototype.addNewExamSchedule = function () {
        if (this.examScheduleData.is_exam_grad_feature <= 0) {
            this.batchAdderData.total_marks = Number(this.batchAdderData.total_marks);
            if (this.batchAdderData.total_marks == 0) {
                this.messageNotifier('error', '', 'Please Provide Total Marks');
                return;
            }
        }
        var obj = {};
        obj.total_marks = this.batchAdderData.total_marks;
        obj.exam_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.batchAdderData.exam_date).format('YYYY-MM-DD');
        var start_time = __WEBPACK_IMPORTED_MODULE_3_moment__(this.createTimeInFormat(this.batchAdderData.start_time.hour, this.batchAdderData.start_time.minute, 'comp'), 'h:mma');
        var end_time = __WEBPACK_IMPORTED_MODULE_3_moment__(this.createTimeInFormat(this.batchAdderData.end_time.hour, this.batchAdderData.end_time.minute, 'comp'), 'h:mma');
        if (!(start_time.isBefore(end_time))) {
            this.messageNotifier('error', '', 'Please enter correct start time and end time');
            return false;
        }
        else {
            obj.start_time = this.createTimeInFormat(this.batchAdderData.start_time.hour, this.batchAdderData.start_time.minute, '');
            obj.end_time = this.createTimeInFormat(this.batchAdderData.end_time.hour, this.batchAdderData.end_time.minute, '');
            obj.duration = end_time.diff(start_time, 'minutes');
        }
        obj.exam_desc = this.batchAdderData.exam_desc;
        obj.topics_covered = this.selectedTopics;
        obj.schd_id = 0;
        obj.isReferenced = "Y";
        this.examSchedule.push(obj);
        this.batchAdderData = {
            exam_date: __WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-DD"),
            exam_desc: "",
            start_time: {
                hour: "12 PM",
                minute: '00'
            },
            end_time: {
                hour: "1 PM",
                minute: "00"
            },
            total_marks: 0,
            topics_covered: ''
        };
        this.selectedTopics = '';
        this.selectedTopicsListObj = [];
    };
    CourseExamComponent.prototype.addDataToExamSchedule = function () {
        var _this = this;
        var dataToSend = this.makeJsonToSendData();
        if (dataToSend == false) {
            return;
        }
        var type = "";
        if (this.examScheduleData.otherSchd == 0) {
            type = "post";
        }
        else if (this.examScheduleData.otherSchd == null) {
            type = "post";
        }
        else if (this.examScheduleData.otherSchd == undefined) {
            type = "post";
        }
        else {
            type = "put";
        }
        if (!this.isRippleLoad) {
            this.isRippleLoad = true;
            this.apiService.serverRequestToSaveSchedule(dataToSend, type).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.messageNotifier('success', 'Successfully', 'Schedule Created Successfully');
                _this.batchModelGoClick();
            }, function (err) {
                _this.isRippleLoad = false;
                //console.log(err);
                _this.messageNotifier('error', '', err.error.message);
            });
        }
        this.selectedTopics = '';
        this.selectedTopicsListObj = [];
    };
    CourseExamComponent.prototype.makeJsonToSendData = function () {
        var obj = {};
        obj.batch_id = this.batchData.batch_id;
        obj.exam_freq = "OTHER";
        obj.otherSchd = [];
        if (this.examSchedule.length > 0) {
            for (var i = 0; i < this.examSchedule.length; i++) {
                var test = {};
                test.exam_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.examSchedule[i].exam_date).format('YYYY-MM-DD'),
                    test.start_time = this.examSchedule[i].start_time;
                test.end_time = this.examSchedule[i].end_time;
                test.total_marks = this.examSchedule[i].total_marks;
                test.exam_desc = this.examSchedule[i].exam_desc;
                test.isReferenced = this.examSchedule[i].isReferenced;
                test.duration = this.examSchedule[i].duration;
                test.schd_id = this.examSchedule[i].schd_id;
                test.topics_covered = this.examSchedule[i].topics_covered;
                obj.otherSchd.push(test);
            }
        }
        return obj;
    };
    // Table Action Menu
    CourseExamComponent.prototype.clearExam = function () {
        if (this.examScheduleData.coursesList[0].courseClassSchdList) {
            this.calculateTotalMarks();
            this.clearAllField();
        }
        else {
            this.messageNotifier('error', '', "Only class present");
        }
    };
    CourseExamComponent.prototype.editSubject = function (row_no, subject_data) {
        if (this.selectedRow !== "") {
            if (this.row_edit_subject_id != "" && this.row_edit_subject_id != undefined) {
                document.getElementById(("row_already" + this.selectedRow).toString()).classList.add('displayComp');
                document.getElementById(("row_already" + this.selectedRow).toString()).classList.remove('editComp');
            }
            else {
                document.getElementById(("row" + this.selectedRow).toString()).classList.add('displayComp');
                document.getElementById(("row" + this.selectedRow).toString()).classList.remove('editComp');
            }
        }
        this.selectedRow = row_no;
        document.getElementById(("row" + row_no).toString()).classList.remove('displayComp');
        document.getElementById(("row" + row_no).toString()).classList.add('editComp');
        this.edit_subject_id = subject_data.subject_id;
        this.edit_subject_name = subject_data.subject_name;
        this.edit_exam_marks = subject_data.exam_marks;
        this.edit_subject_topics = subject_data.subject_topics;
        this.edit_subject_topicId = subject_data.topicsId;
        this.edit_exam_desc = subject_data.exam_desc;
        this.edit_exam_room_no = subject_data.exam_room_no;
        this.checkedKeys = subject_data.topicsId;
        console.log(subject_data);
    };
    CourseExamComponent.prototype.updateSubject = function (row_no, subject_data) {
        var _this = this;
        if (this.edit_subject_id == null || this.edit_subject_id == '') {
            this.messageNotifier('error', '', 'No subject(s) added!');
            return;
        }
        if (this.edit_exam_marks == '' || this.edit_exam_marks == null) {
            this.messageNotifier('error', '', 'Please Provide Marks');
            return;
        }
        var subjectName = "";
        if (this.subjectListData.length > 0) {
            this.subjectListData[0].forEach(function (ele) {
                if (_this.edit_subject_id == ele.subject_id) {
                    subjectName = ele.subject_name;
                }
            });
        }
        var topic_names = this.topicsName.join(", ");
        this.newExamSubjectData[row_no].subject_id = this.edit_subject_id;
        this.newExamSubjectData[row_no].subject_name = subjectName;
        this.newExamSubjectData[row_no].exam_marks = this.edit_exam_marks;
        this.newExamSubjectData[row_no].subject_topics = topic_names;
        this.newExamSubjectData[row_no].topicsId = this.checkedKeys;
        this.newExamSubjectData[row_no].exam_desc = this.edit_exam_desc;
        this.newExamSubjectData[row_no].exam_room_no = this.edit_exam_room_no;
        this.edit_subject_id = '';
        this.edit_subject_name = '';
        this.edit_exam_marks = '';
        this.edit_subject_topics = '';
        this.edit_exam_desc = '';
        this.edit_exam_room_no = '';
        this.edit_subject_topicId = [];
        this.calculateTotalMarks();
        document.getElementById(("row" + row_no).toString()).classList.add('displayComp');
        document.getElementById(("row" + row_no).toString()).classList.remove('editComp');
        this.selectedRow = "";
    };
    CourseExamComponent.prototype.clearAllField = function () {
        this.newExamSubjectData = [];
        this.newExamData.startTimeHrs = '12 PM';
        this.newExamData.startTimeMins = '00';
        this.newExamData.endTimeHrs = '1 PM';
        this.newExamData.endTimeMins = '00';
        this.newExamData.total_marks = '';
        this.clearField();
    };
    CourseExamComponent.prototype.deleteExamSchedule = function (data, index) {
        this.examSchedule.splice(index, 1);
    };
    CourseExamComponent.prototype.notifyExamSchedule = function (data) {
        var _this = this;
        if (confirm('Are you sure u want to send Exam Schedule SMS to the batch?')) {
            this.apiService.notifyStudentExam(data.schd_id).subscribe(function (res) {
                _this.messageNotifier('success', 'Notified', 'Notification Sent Successfully');
            }, function (err) {
                //console.log(err);
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    //cancelExamSchedule
    CourseExamComponent.prototype.cancelExamSchedule = function (data) {
        this.cancelExamPopUp = true;
        this.cancelExamData = data;
    };
    CourseExamComponent.prototype.closeCancelExamPopUp = function () {
        this.jsonVar.cancelCourseLevel = false;
        this.cancelExamPopUp = false;
        this.cancelExamData = "";
        this.cancelPopUpData = {
            reason: "",
            notify: true
        };
    };
    CourseExamComponent.prototype.cancelExamClassSchedule = function () {
        var _this = this;
        if (this.cancelPopUpData.reason.trim() == "" || null) {
            this.messageNotifier('error', '', 'Please enter cancellation reason');
            return;
        }
        var notify = "";
        if (this.cancelPopUpData.notify) {
            notify = "Y";
        }
        else {
            notify = "N";
        }
        if (!this.isRippleLoad) {
            this.isRippleLoad = true;
            var obj = {
                batch_id: this.batchData.batch_id,
                exam_freq: "OTHER",
                cancelSchd: [{
                        schd_id: this.cancelExamData.schd_id,
                        exam_desc: this.cancelPopUpData.reason,
                        is_notified: notify
                    }]
            };
            this.apiService.cancelExamSchedule(obj).subscribe(function (res) {
                _this.messageNotifier('success', 'Successfully Cancelled', 'Scheduled exam cancelled successfully');
                _this.isRippleLoad = false;
                _this.batchModelGoClick();
                _this.closeCancelExamPopUp();
            }, function (err) {
                //console.log(err);
                _this.isRippleLoad = false;
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    // Mark Attendance Popup
    CourseExamComponent.prototype.markAttendanceSchedule = function (data) {
        this.markAttendancePopUp = true;
        this.markAttendanceData = data;
        this.getStudentList();
    };
    CourseExamComponent.prototype.getStudentList = function () {
        var _this = this;
        var obj = {
            attendanceSchdId: this.markAttendanceData.schd_id,
            batch_id: this.batchData.batch_id
        };
        this.isRippleLoad = true;
        this.apiService.fetchStudentList(obj).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.studentList = res;
            _this.getTotalCountForCourse(res);
            if (res.length > 0) {
                _this.attendanceNote = res[0].dateLi[0].attendance_note;
            }
            else {
                _this.attendanceNote = "";
            }
        }, function (err) {
            //console.log(err);
            _this.isRippleLoad = false;
            _this.messageNotifier('error', '', err.error.message);
            _this.closeCourseLevelAttendance();
        });
    };
    CourseExamComponent.prototype.getDisability = function (s) {
        if (s.dateLi[0].status == "L" && s.dateLi[0].isStatusModified == "N") {
            return true;
        }
        else {
            return false;
        }
    };
    CourseExamComponent.prototype.markAttendaceBtnClickCourse = function (event, rowData, index) {
        document.getElementById('leaveBtnCourse' + rowData.student_id).classList.remove('classLeaveBtn');
        document.getElementById('absentBtnCourse' + rowData.student_id).classList.remove('classAbsentBtn');
        document.getElementById('presentBtnCourse' + rowData.student_id).classList.remove('classPresentBtn');
        if (event.target.innerText == "L") {
            document.getElementById('leaveBtnCourse' + rowData.student_id).classList.add('classLeaveBtn');
            this.studentList[index].dateLi[0].status = "L";
            this.studentList[index].dateLi[0].isStatusModified = "Y";
        }
        else if (event.target.innerText == "A") {
            document.getElementById('absentBtnCourse' + rowData.student_id).classList.add('classAbsentBtn');
            this.studentList[index].dateLi[0].status = "A";
            this.studentList[index].dateLi[0].isStatusModified = "Y";
        }
        else {
            document.getElementById('presentBtnCourse' + rowData.student_id).classList.add('classPresentBtn');
            this.studentList[index].dateLi[0].status = "P";
            this.studentList[index].dateLi[0].isStatusModified = "Y";
        }
        this.getTotalCountForCourse(this.studentList);
    };
    CourseExamComponent.prototype.getTotalCountForCourse = function (data) {
        this.absentCount = 0;
        this.presentCount = 0;
        this.leaveCount = 0;
        for (var i = 0; i < data.length; i++) {
            if (data[i].dateLi[0].status == "P") {
                this.presentCount++;
            }
            else if (data[i].dateLi[0].status == "A") {
                this.absentCount++;
            }
            else {
                this.leaveCount++;
            }
        }
    };
    CourseExamComponent.prototype.getClassForLeave = function (data) {
        if (data.dateLi[0].status == "L") {
            return "classLeaveBtn";
        }
        else {
            return "";
        }
    };
    CourseExamComponent.prototype.getClassForAbsent = function (data) {
        if (data.dateLi[0].status == "A") {
            return "classAbsentBtn";
        }
        else {
            return "";
        }
    };
    CourseExamComponent.prototype.getClassForPresent = function (data) {
        if (data.dateLi[0].status == "P") {
            return "classPresentBtn";
        }
        else {
            return "";
        }
    };
    CourseExamComponent.prototype.closeCourseLevelAttendance = function () {
        this.markAttendancePopUp = false;
        this.studentList = [];
        this.absentCount = 0;
        this.presentCount = 0;
        this.leaveCount = 0;
        this.attendanceNote = "";
        this.smsAbsenteesChkbx = false;
        this.markAttendanceData = "";
    };
    CourseExamComponent.prototype.markAllPresent = function (e) {
        if (e.target.checked) {
            this.studentList.forEach(function (e) {
                if (e.dateLi[0].status == "L" && e.dateLi[0].isStatusModified == "N") {
                    //Do Nothing
                }
                else {
                    document.getElementById('leaveBtnCourse' + e.student_id).classList.remove('classLeaveBtn');
                    document.getElementById('absentBtnCourse' + e.student_id).classList.remove('classAbsentBtn');
                    document.getElementById('presentBtnCourse' + e.student_id).classList.remove('classPresentBtn');
                    document.getElementById('presentBtnCourse' + e.student_id).classList.add('classPresentBtn');
                    e.dateLi[0].status = "P";
                    e.dateLi[0].isStatusModified = "Y";
                }
            });
        }
        else {
            this.studentList.forEach(function (e) {
                if (e.dateLi[0].status == "L" && e.dateLi[0].isStatusModified == "N") {
                    //Do Nothing
                }
                else {
                    document.getElementById('leaveBtnCourse' + e.student_id).classList.remove('classLeaveBtn');
                    document.getElementById('absentBtnCourse' + e.student_id).classList.remove('classAbsentBtn');
                    document.getElementById('presentBtnCourse' + e.student_id).classList.remove('classPresentBtn');
                    e.dateLi[0].status = "A";
                    e.dateLi[0].isStatusModified = "Y";
                }
            });
        }
        this.getTotalCountForCourse(this.studentList);
    };
    CourseExamComponent.prototype.checkCheckAllChkboxStatus = function () {
        var check = false;
        for (var i = 0; i < this.studentList.length; i++) {
            if (this.studentList[i].dateLi[0].status == "P") {
                check = true;
            }
            else {
                check = false;
                break;
            }
        }
        return check;
    };
    CourseExamComponent.prototype.updateCourseAttendance = function () {
        var _this = this;
        this.isRippleLoad = true;
        var dataToSend = this.makeJsonForAttendceMark();
        this.apiService.markAttendance(dataToSend).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.messageNotifier('success', 'Attendance Marked', 'Attendance Marked Successfully');
            _this.closeCourseLevelAttendance();
        }, function (err) {
            _this.isRippleLoad = false;
            //console.log(err);
            _this.messageNotifier('error', '', err.error.message);
        });
    };
    CourseExamComponent.prototype.makeJsonForAttendceMark = function () {
        var notify = "";
        if (this.smsAbsenteesChkbx) {
            notify = "Y";
        }
        else {
            notify = "N";
        }
        var obj = [];
        for (var i = 0; i < this.studentList.length; i++) {
            var test = {};
            test.batch_id = this.batchData.batch_id;
            test.isNotify = notify;
            test.student_id = this.studentList[i].student_id;
            test.dateLi = [{
                    date: this.studentList[i].dateLi[0].date,
                    status: this.studentList[i].dateLi[0].status,
                    isStatusModified: this.studentList[i].dateLi[0].isStatusModified,
                    attendance_note: this.attendanceNote,
                    schId: this.studentList[i].dateLi[0].schId.toString()
                }];
            obj.push(test);
        }
        return obj;
    };
    // Cancel table Action///////
    CourseExamComponent.prototype.notifyCancelClass = function (data) {
        var _this = this;
        if (confirm('Are you sure, You want to notify?')) {
            var obj = {
                batch_id: this.batchData.batch_id,
                class_schedule_id: data.schd_id,
                is_exam_schedule: 'Y'
            };
            this.apiService.notifyCancelledClass(obj).subscribe(function (res) {
                _this.messageNotifier('success', 'Success', 'Notified Successfully');
            }, function (err) {
                //console.log(err);
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    CourseExamComponent.prototype.unCancelClass = function (data) {
        var _this = this;
        if (confirm("Are you sure, you want  to uncancel the exam schedule??")) {
            var obj = {
                batch_id: this.batchData.batch_id,
                cancelSchd: [{
                        schd_id: data.schd_id
                    }]
            };
            this.apiService.uncancelClassSchedule(obj).subscribe(function (res) {
                _this.messageNotifier('success', 'Uncancelled Succesfully', 'Exam Uncancelled Successfully');
                _this.batchModelGoClick();
            }, function (err) {
                //console.log(err);
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    ////////// Course Model
    CourseExamComponent.prototype.getMasterCourseList = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getMasterCourse().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.masterCourseList = res;
        }, function (err) {
            console.log(err);
            _this.isRippleLoad = false;
        });
    };
    CourseExamComponent.prototype.getCourseList = function (event) {
        var _this = this;
        this.courseList = [];
        this.courseData.course_id = -1;
        if (event != -1) {
            this.isRippleLoad = true;
            this.apiService.fetchCourseListData(this.courseData.master_course).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.courseList = res;
            }, function (err) {
                console.log(err);
                _this.isRippleLoad = false;
            });
        }
    };
    CourseExamComponent.prototype.displayCourseDate = function () {
        console.log(this.courseData.course_id);
        this.showCourseStartEndDate = true;
        for (var i = 0; i < this.courseList.coursesList.length; i++) {
            if (this.courseList.coursesList[i].course_id == this.courseData.course_id) {
                this.batchStartDate = this.courseList.coursesList[i].start_date;
                this.batchEndDate = this.courseList.coursesList[i].end_date;
            }
        }
    };
    CourseExamComponent.prototype.validateDateRange = function () {
        var _this = this;
        var selectedCourse = {};
        var check = true;
        if (this.courseList.coursesList.length > 0) {
            selectedCourse = this.courseList.coursesList.filter(function (el) { return el.course_id == _this.courseData.course_id; });
            if (__WEBPACK_IMPORTED_MODULE_3_moment__(selectedCourse[0].start_date).format('YYYY-MM-DD') <= __WEBPACK_IMPORTED_MODULE_3_moment__(this.courseData.requested_date).format('YYYY-MM-DD') && __WEBPACK_IMPORTED_MODULE_3_moment__(this.courseData.requested_date).format('YYYY-MM-DD') <= __WEBPACK_IMPORTED_MODULE_3_moment__(selectedCourse[0].end_date).format('YYYY-MM-DD')) {
                check = true;
            }
            else {
                this.messageNotifier('error', 'Date Out Of Range', 'You have selected date out of course start date ' + selectedCourse[0].start_date + " and course end date " + selectedCourse[0].end_date);
                check = false;
            }
        }
        return check;
    };
    CourseExamComponent.prototype.getExamSchedule = function () {
        var _this = this;
        if (this.courseData.master_course != "" && this.courseData.course_id != -1) {
            if (!this.validateDateRange()) {
                this.showContentSection = false;
                return false;
            }
            this.clearAllField();
            this.isRippleLoad = true;
            this.courseData.requested_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.courseData.requested_date).format('YYYY-MM-DD');
            this.apiService.getSchedule(this.courseData).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.multiClickDisabled = false;
                _this.examScheduleData = res;
                _this.calculateDataAsPerSelection(res);
                // console.log(this.subjectListData);
                _this.showContentSection = true;
                //console.log(res);
            }, function (err) {
                _this.isRippleLoad = false;
                //console.log(err);
                _this.messageNotifier('error', '', err.error.message);
            });
        }
        else {
            this.messageNotifier('error', '', 'Please Provide Mandatory Fields');
        }
    };
    CourseExamComponent.prototype.subjectChanged = function () {
        this.checkedKeys = [];
        this.changeColor = false;
        this.topicsName = [];
    };
    CourseExamComponent.prototype.calculateDataAsPerSelection = function (result) {
        this.subjectListData = [];
        this.viewList = [];
        if (result != null) {
            if (result.coursesList.length > 0) {
                var _loop_1 = function (i) {
                    // if(result.coursesList[i].courseClassSchdList != null && result.coursesList[i].courseClassSchdList.length > 0){
                    if (this_1.courseData.course_id == result.coursesList[i].course_id) {
                        this_1.subjectListData.push(result.coursesList[i].batchesList);
                        var obj_1 = {};
                        obj_1.selectedCourseList = result.coursesList[i];
                        obj_1.subjectList = result.coursesList[i].batchesList;
                        obj_1.courseModelAdder = {
                            start_time: {
                                hour: "12 PM",
                                minute: '00'
                            },
                            end_time: {
                                hour: "1 PM",
                                minute: "00"
                            },
                            total_marks: "",
                            exam_desc: "",
                            room_no: ""
                        };
                        obj_1.coursetableAdder = {
                            batch_id: -1,
                            total_marks: ""
                        };
                        if (result.coursesList[i].courseClassSchdList != null && result.coursesList[i].courseClassSchdList.length > 0) {
                            obj_1.courseTableList = result.coursesList[i].courseClassSchdList;
                            obj_1.courseModelAdder.start_time = this_1.breakTimeFormat(result.coursesList[i].courseClassSchdList[0].start_time);
                            obj_1.courseModelAdder.end_time = this_1.breakTimeFormat(result.coursesList[i].courseClassSchdList[0].end_time);
                            obj_1.courseModelAdder.exam_desc = result.coursesList[i].courseClassSchdList[0].class_desc;
                            obj_1.courseModelAdder.room_no = result.coursesList[i].courseClassSchdList[0].room_no;
                            obj_1.courseModelAdder.total_marks = 0;
                            result.coursesList[i].courseClassSchdList.forEach(function (element) {
                                obj_1.courseModelAdder.total_marks += Number(element.total_marks);
                            });
                        } //end if
                        else {
                            obj_1.courseTableList = [];
                        }
                        this_1.viewList.push(obj_1);
                    }
                };
                var this_1 = this;
                for (var i = 0; i < result.coursesList.length; i++) {
                    _loop_1(i);
                }
            }
        }
    };
    /**
     * check negative value
     */
    CourseExamComponent.prototype.checkNgetiveValue = function ($event) {
        // console.log($event);
        if ($event < 0) {
            this.messageNotifier('error', '', 'Negative mark not allowed');
        }
    };
    CourseExamComponent.prototype.topicLinking = function (subjectData, index) {
        var _this = this;
        var subject_id;
        for (var i = 0; i < subjectData.length; i++) {
            if (this.viewList[index].coursetableAdder.batch_id == subjectData[i].batch_id) {
                subject_id = subjectData[i].subject_id;
            }
        }
        if (subject_id == '' || subject_id == null || subject_id == '-1' || subject_id == undefined) {
            this.messageNotifier('error', '', 'Please Select Subject');
            return;
        }
        else {
            this.isRippleLoad = true;
            this.topicService.getAllTopicsSubTopics(subject_id).subscribe(function (res) {
                _this.topicLinkColor = true;
                var temp;
                temp = res;
                if (temp != null && temp.length != 0) {
                    _this.topicBox = false;
                    _this.isRippleLoad = false;
                    _this.topicsData = res;
                    var subjectName_1 = "";
                    subjectData.forEach(function (ele) {
                        if (ele.subject_id == _this.subject_id) {
                            subjectName_1 = ele.subject_name;
                        }
                    });
                    document.getElementById("topicSubName").innerHTML = subjectName_1;
                    document.getElementById("topicCount").innerHTML = _this.topicsData.length;
                    _this.children = function (dataItem) { return Object(__WEBPACK_IMPORTED_MODULE_5_rxjs_observable_of__["a" /* of */])(dataItem.subTopic); };
                    _this.hasChildren = function (item) { return item.subTopic && item.subTopic.length > 0; };
                }
                else {
                    _this.isRippleLoad = false;
                    _this.messageNotifier('info', 'Info', 'No topics available to Link');
                }
            }, function (err) {
                _this.isRippleLoad = false;
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    CourseExamComponent.prototype.topicLinkingForPreSelectedTopics = function (subjectData) {
        var _this = this;
        if (this.row_edit_subject_id == '' || this.row_edit_subject_id == null || this.row_edit_subject_id == '-1' || this.row_edit_subject_id == undefined) {
            this.messageNotifier('error', '', 'Please Select Subject');
            return;
        }
        else {
            this.isRippleLoad = true;
            this.topicService.getAllTopicsSubTopics(this.row_edit_subject_id).subscribe(function (res) {
                _this.checkedKeys = [];
                var temp;
                temp = res;
                if (temp != null && temp.length != 0) {
                    _this.topicBox = false;
                    _this.isRippleLoad = false;
                    _this.topicsData = res;
                    var subjectName_2 = "";
                    var tempCheckedKeys = void 0;
                    var data = _this.row_edit_subject_topicId.toString();
                    if (data != undefined && data.includes("|")) {
                        tempCheckedKeys = data.split("|");
                    }
                    else {
                        tempCheckedKeys = _this.row_edit_subject_topicId;
                    }
                    tempCheckedKeys.forEach(function (value) {
                        if (value != " " || value != "0") {
                            _this.checkedKeys.push(Number(value));
                        }
                    });
                    subjectData.forEach(function (ele) {
                        if (ele.subject_id == _this.row_edit_subject_id) {
                            subjectName_2 = ele.subject_name;
                        }
                    });
                    _this.subject_name = subjectName_2;
                    _this.children = function (dataItem) { return Object(__WEBPACK_IMPORTED_MODULE_5_rxjs_observable_of__["a" /* of */])(dataItem.subTopic); };
                    _this.hasChildren = function (item) { return item.subTopic && item.subTopic.length > 0; };
                }
                else {
                    _this.isRippleLoad = false;
                    _this.messageNotifier('info', 'Info', 'No topics available to Link');
                }
            }, function (err) {
                _this.isRippleLoad = false;
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    CourseExamComponent.prototype.topicListing = function () {
        var _this = this;
        if (this.subject_id == '' || this.subject_id == null || this.subject_id == '-1' || this.subject_id == undefined) {
            this.messageNotifier('error', '', 'Please Select Subject');
            return;
        }
        else {
            this.isRippleLoad = true;
            this.topicService.getAllTopicsSubTopics(this.subject_id).subscribe(function (res) {
                var temp;
                temp = res;
                if (temp != null && temp.length != 0) {
                    _this.topicBox = false;
                    _this.isRippleLoad = false;
                    _this.topicsData = res;
                    var subjectName = "";
                    _this.subjectListData[0].forEach(function (ele) {
                        if (_this.subject_id == ele.subject_id) {
                            _this.subject_name = ele.subject_name;
                        }
                    });
                    _this.children = function (dataItem) { return Object(__WEBPACK_IMPORTED_MODULE_5_rxjs_observable_of__["a" /* of */])(dataItem.subTopic); };
                    _this.hasChildren = function (item) { return item.subTopic && item.subTopic.length > 0; };
                }
                else {
                    _this.isRippleLoad = false;
                    _this.messageNotifier('info', 'Info', 'No topics available to Link');
                }
            }, function (err) {
                _this.isRippleLoad = false;
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    CourseExamComponent.prototype.handleChecking = function (itemLookup) {
        var subTopic = itemLookup.item.dataItem.subTopic;
        var arrayIndex = this.checkedKeys.indexOf(itemLookup.item.dataItem.topicId);
        if (arrayIndex > -1) {
            // this.checkedKeys.splice(arrayIndex, 1);
            var subTopic_1 = itemLookup.item.dataItem.subTopic;
            subTopic_1.length ? this.removeNLevelTopic(subTopic_1) : '';
        }
        else {
            // this.checkedKeys.push(itemLookup.item.dataItem.topicId);
            if (subTopic.length)
                this.AddNLevelTopic(subTopic);
        }
        this.cd.markForCheck();
    };
    CourseExamComponent.prototype.removeNLevelTopic = function (subTopics) {
        var _this = this;
        if (subTopics.length == 0) {
            var arrayIndex = this.checkedKeys.indexOf(subTopics.topicId);
            this.checkedKeys.splice(arrayIndex, 1);
            return;
        }
        else {
            subTopics.forEach(function (object) {
                var arrayIndex = _this.checkedKeys.indexOf(object.topicId);
                if (arrayIndex > -1) {
                    _this.checkedKeys.splice(arrayIndex, 1);
                }
                if (object.subTopic.length) {
                    _this.removeNLevelTopic(object.subTopic);
                }
            });
        }
        this.cd.markForCheck();
    };
    CourseExamComponent.prototype.AddNLevelTopic = function (subTopics) {
        var _this = this;
        if (subTopics.length == 0) {
            this.checkedKeys.push(subTopics.topicId);
            return;
        }
        else {
            subTopics.forEach(function (object) {
                var arrayIndex = _this.checkedKeys.indexOf(object.topicId);
                if (arrayIndex == -1) {
                    _this.checkedKeys.push(object.topicId);
                }
                if (object.subTopic.length) {
                    _this.AddNLevelTopic(object.subTopic);
                }
            });
        }
    };
    CourseExamComponent.prototype.preSelectedTopicListing = function () {
        var _this = this;
        if (this.edit_subject_id == '' || this.edit_subject_id == null || this.edit_subject_id == '-1' || this.edit_subject_id == undefined) {
            this.messageNotifier('error', '', 'Please Select Subject');
            return;
        }
        else {
            this.isRippleLoad = true;
            this.topicService.getAllTopicsSubTopics(this.edit_subject_id).subscribe(function (res) {
                var temp;
                temp = res;
                if (temp != null && temp.length != 0) {
                    _this.topicBox = false;
                    _this.isRippleLoad = false;
                    _this.topicsData = res;
                    _this.checkedKeys = _this.edit_subject_topicId;
                    _this.subjectListDataSource.forEach(function (ele) {
                        if (ele.subject_id == _this.subject_id) {
                            _this.subject_name = ele.subject_name;
                        }
                    });
                    _this.children = function (dataItem) { return Object(__WEBPACK_IMPORTED_MODULE_5_rxjs_observable_of__["a" /* of */])(dataItem.subTopic); };
                    _this.hasChildren = function (item) { return item.subTopic && item.subTopic.length > 0; };
                }
                else {
                    _this.isRippleLoad = false;
                    _this.messageNotifier('info', 'Info', 'No topics available to Link');
                }
            }, function (err) {
                _this.isRippleLoad = false;
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    CourseExamComponent.prototype.saveTopic = function () {
        var _this = this;
        var temp = this.checkedKeys;
        this.topicsName = [];
        var join = temp.join("|");
        var tempTopicData = this.topicsData;
        this.checkedKeys.forEach(function (ele) {
            _this.findNameInJSON(_this.topicsData, ele);
        });
        for (var i = 0; i < this.topicsName.length; i++) {
            if (this.topicsName[i] == undefined) {
                this.topicsName.splice(i, 1);
            }
        }
        if (this.row_edit_subject_id) {
            this.row_edit_subject_topicId = this.checkedKeys;
            var joinedArr = this.row_edit_subject_topicId.join(",").toString();
            var x = joinedArr.replace(/,/g, "|");
            var y = x.split("|");
            this.row_edit_subject_topicId = y;
        }
        console.log(this.topicsName);
        this.topicBox = true;
        if (this.topicLinkColor) {
            this.changeColor = true;
        }
    };
    CourseExamComponent.prototype.findNameInJSON = function (arr, nameVal) {
        for (var i = 0; i < arr.length; i++) {
            var item = arr[i];
            if (item.topicId.toString() == nameVal.toString()) {
                this.topicsName.push(item.topicName);
            }
            if (item.subTopic.length > 0) {
                this.findNameInJSON(item.subTopic, nameVal);
            }
        }
    };
    CourseExamComponent.prototype.closeAlert = function () {
        this.topicBox = true;
        this.topicLinkColor = false;
        this.changeColor = false;
    };
    CourseExamComponent.prototype.addNewExamSubject = function () {
        var _this = this;
        if (this.newExamData.startTimeHrs == this.newExamData.endTimeHrs
            && this.newExamData.startTimeMins == this.newExamData.endTimeMins) {
            this.messageNotifier('error', '', 'Exam  start time and end time cannot be same !');
            return;
        }
        if (this.subject_id == null || this.subject_id == '') {
            this.messageNotifier('error', '', 'No subject(s) added!');
            return;
        }
        if (this.exam_marks == '' || this.exam_marks == null) {
            this.messageNotifier('error', '', 'Please Provide Marks');
            return;
        }
        for (var i = 0; i < this.newExamSubjectData.length; i++) {
            if (this.newExamSubjectData[i].subject_id == this.subject_id) {
                this.messageNotifier('error', '', 'Selected subject already added!');
                return;
            }
        }
        var subjectName = "";
        this.subjectListData[0].forEach(function (ele) {
            if (_this.subject_id == ele.subject_id) {
                subjectName = ele.subject_name;
            }
        });
        var topic_names = this.topicsName.join(", ");
        var obj = {};
        obj.subject_id = this.subject_id;
        obj.subject_name = subjectName;
        obj.exam_marks = this.exam_marks;
        obj.subject_topics = topic_names;
        obj.topicsId = this.checkedKeys;
        obj.exam_desc = this.exam_desc;
        obj.exam_room_no = this.exam_room_no;
        this.newExamSubjectData.push(obj);
        this.calculateTotalMarks();
        this.clearField();
        this.subject_topics = [];
    };
    CourseExamComponent.prototype.calculateTotalMarks = function () {
        this.total_marks_to_show = 0;
        for (var i = 0; i < this.newExamSubjectData.length; i++) {
            this.total_marks_to_show += this.newExamSubjectData[i].exam_marks;
        }
    };
    CourseExamComponent.prototype.clearField = function () {
        this.subject_id = '';
        this.subject_name = '';
        this.exam_marks = '';
        this.subject_topics = [];
        this.exam_desc = '';
        this.exam_room_no = '';
        this.checkedKeys = [];
        this.topicsName = [];
    };
    CourseExamComponent.prototype.addNewExamSubjectCourse = function (index) {
        if (this.viewList[index].coursetableAdder.batch_id == -1) {
            this.messageNotifier('error', '', 'No subject(s) added!');
            return;
        }
        ;
        if (this.viewList[index].selectedCourseList.is_exam_grad_feature == '0') {
            if (this.viewList[index].coursetableAdder.total_marks == 0) {
                this.messageNotifier('error', '', 'Please Provide Marks');
                return;
            }
        }
        var selectedSubjectDemo = this.getSubjectName(this.viewList[index].subjectList, this.viewList[index].coursetableAdder.batch_id);
        for (var i = 0; i < this.viewList[index].courseTableList.length; i++) {
            if (this.viewList[index].courseTableList[i].subject_name == selectedSubjectDemo.subject_name) {
                this.messageNotifier('error', '', 'Selected subject already added!');
                return;
            }
        }
        var topic_names = this.topicsName.join(", ");
        var obj = {};
        obj.total_marks = this.viewList[index].coursetableAdder.total_marks;
        obj.class_schedule_id = '0';
        var selectedSubject = this.getSubjectName(this.viewList[index].subjectList, this.viewList[index].coursetableAdder.batch_id);
        obj.subject_name = selectedSubject.subject_name;
        obj.batch_id = this.viewList[index].coursetableAdder.batch_id;
        obj.otherData = selectedSubject;
        obj.topicName = topic_names;
        obj.topics_covered = this.checkedKeys;
        obj.class_desc = this.viewList[index].coursetableAdder.exam_desc;
        obj.room_no = this.viewList[index].coursetableAdder.room_no;
        this.viewList[index].courseTableList.push(obj);
        this.viewList[index].courseModelAdder.total_marks += this.viewList[index].coursetableAdder.total_marks;
        this.viewList[index].coursetableAdder = {
            batch_id: -1,
            total_marks: 0
        };
        this.topicLinkColor = false;
        this.changeColor = false;
    };
    CourseExamComponent.prototype.getSubjectName = function (data, id) {
        for (var i = 0; i < data.length; i++) {
            if (data[i].batch_id == id) {
                return data[i];
            }
        }
    };
    CourseExamComponent.prototype.deleteSubject = function (subject_id) {
        for (var i = 0; i < this.newExamSubjectData.length; i++) {
            if (this.newExamSubjectData[i].subject_id == subject_id) {
                this.newExamSubjectData.splice(i, 1);
            }
        }
        this.messageNotifier('success', 'Success', 'Scheduled exam deleted successfully');
    };
    CourseExamComponent.prototype.deleteFromCourse = function (data, index, j) {
        if (this.viewList[j].courseTableList.length == 1) {
            this.messageNotifier('error', '', "Subject can't be deleted from the scheduled exam since only one subject is left!");
            return;
        }
        else {
            this.viewList[j].courseTableList.splice(index, 1);
            this.messageNotifier('success', 'Success', 'Scheduled exam deleted successfully');
        }
        var total = 0;
        for (var i = 0; i < this.viewList[j].courseTableList.length; i++) {
            total += this.viewList[j].courseTableList[i].total_marks;
        }
        this.viewList[j].courseModelAdder.total_marks = total;
    };
    CourseExamComponent.prototype.editFromCourse = function (data, index, j) {
        if (this.selectedRow !== "") {
            if (this.edit_subject_id) {
                document.getElementById(("row" + this.selectedRow).toString()).classList.add('displayComp');
                document.getElementById(("row" + this.selectedRow).toString()).classList.remove('editComp');
            }
            else {
                document.getElementById(("row_already" + this.selectedRow).toString()).classList.add('displayComp');
                document.getElementById(("row_already" + this.selectedRow).toString()).classList.remove('editComp');
            }
        }
        this.selectedRow = index + "_" + j;
        document.getElementById(("row_already" + index + "_" + j).toString()).classList.remove('displayComp');
        document.getElementById(("row_already" + index + "_" + j).toString()).classList.add('editComp');
        var subject_id;
        if (data.otherData) {
            subject_id = data.otherData.subject_id;
        }
        else {
            subject_id = data.subject_id;
        }
        this.row_edit_subject_id = subject_id;
        this.row_edit_subject_name = data.subject_name;
        this.row_edit_exam_marks = data.total_marks;
        this.row_edit_subject_topics = data.topicName;
        this.row_edit_subject_topicId = data.topics_covered;
        this.row_edit_exam_desc = data.class_desc;
        this.row_edit_exam_room_no = data.room_no;
        //
        var temp;
        if (data.topics_covered != undefined) {
            if (data.topics_covered.includes("|")) {
                temp = data.topics_covered.replace("|", ",");
            }
            else {
                temp = data.topics_covered;
            }
            this.checkedKeys = temp;
        }
    };
    CourseExamComponent.prototype.updateEditedSubject = function (row, index, j) {
        var _this = this;
        if (this.row_edit_exam_marks == '' || this.row_edit_exam_marks == null) {
            this.messageNotifier('error', '', 'Please Provide Marks');
            return;
        }
        var subjectName = "";
        console.log(this.viewList);
        this.viewList[j].subjectList.forEach(function (ele) {
            if (_this.row_edit_subject_id == ele.subject_id) {
                subjectName = ele.subject_name;
            }
        });
        var topic_names = this.topicsName.join(", ");
        var topicsNames;
        if (this.topicsName.length > 0) {
            var y = this.row_edit_subject_topicId.join(",");
            topicsNames = y.replace(/,/g, "|");
        }
        this.viewList[j].courseTableList[index].subject_id = this.row_edit_subject_id;
        this.viewList[j].courseTableList[index].subject_name = subjectName;
        this.viewList[j].courseTableList[index].total_marks = this.row_edit_exam_marks;
        this.viewList[j].courseTableList[index].topicName = topic_names;
        this.viewList[j].courseTableList[index].topics_covered = topicsNames;
        this.viewList[j].courseTableList[index].class_desc = this.row_edit_exam_desc;
        this.viewList[j].courseTableList[index].room_no = this.row_edit_exam_room_no;
        this.row_edit_subject_id = '';
        this.row_edit_subject_name = '';
        this.row_edit_exam_marks = '';
        this.row_edit_subject_topics = '';
        this.row_edit_subject_topicId = [];
        this.row_edit_exam_desc = '';
        this.row_edit_exam_room_no = '';
        //
        // // this.calculateTotalMarks();
        //
        var total = 0;
        for (var i = 0; i < this.viewList[j].courseTableList.length; i++) {
            total += this.viewList[j].courseTableList[i].total_marks;
        }
        this.viewList[j].courseModelAdder.total_marks = total;
        this.checkedKeys = [];
        this.topicsName = [];
        document.getElementById(("row_already" + index + "_" + j).toString()).classList.remove('editComp');
        document.getElementById(("row_already" + index + "_" + j).toString()).classList.add('displayComp');
        this.selectedRow = "";
    };
    CourseExamComponent.prototype.saveExamScheduleCourse = function () {
        var _this = this;
        this.multiClickDisabled = true;
        this.isRippleLoad = true;
        var dataToSend = this.makeDataJsonToSendServer();
        // console.log(dataToSend);
        // dataToSend = false;
        if (dataToSend == false || dataToSend == undefined) {
            this.isRippleLoad = false;
            this.multiClickDisabled = false;
            return;
        }
        if (dataToSend.coursesList.length > 0) {
            var flag_1 = false;
            dataToSend.coursesList.forEach(function (object, index) {
                if (object) {
                    if (object.courseClassSchdList.length) {
                        flag_1 = true;
                    }
                    else {
                        object.exam_start_time = null;
                        object.exam_end_time = null;
                    }
                }
                else {
                    dataToSend.coursesList.splice(index, 1);
                }
            });
            if (flag_1) {
                this.apiService.updateExamSch(dataToSend).subscribe(function (res) {
                    _this.isRippleLoad = false;
                    if (res.statusCode == 200) {
                        _this.messageNotifier('success', 'Success', 'Exam scheduled successfully');
                        _this.clearAllField();
                        _this.getExamSchedule();
                    }
                    else {
                        _this.messageNotifier('error', '', res.message);
                    }
                }, function (err) {
                    _this.isRippleLoad = false;
                    _this.multiClickDisabled = false;
                    console.log(err);
                    _this.messageNotifier('error', '', err.error.message);
                });
            }
        }
        else {
            this.multiClickDisabled = false;
            this.isRippleLoad = false;
            this.messageNotifier('error', '', 'Required fields not mentioned!');
        }
    };
    CourseExamComponent.prototype.makeDataJsonToSendServer = function () {
        var _this = this;
        var coursesLists = [];
        /// This section makes json for perticular selected course
        var data = {};
        var total = 0;
        data.master_course = this.courseData.master_course;
        data.requested_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.courseData.requested_date).format('YYYY-MM-DD');
        data.coursesList = [];
        // FOR ALREADY PRESENT EXAM
        var validation_flag = false;
        for (var p = 0; p < this.viewList.length; p++) {
            if (this.viewList[p].courseTableList.length > 0) {
                validation_flag = true;
            }
        }
        if (validation_flag) {
            for (var i = 0; i < this.viewList.length; i++) {
                var test = {};
                test.course_id = this.viewList[i].selectedCourseList.course_id;
                test.course_exam_schedule_id = this.viewList[i].selectedCourseList.course_exam_schedule_id;
                var check = this.validateTime(this.viewList[i].courseModelAdder.start_time, this.viewList[i].courseModelAdder.end_time);
                if (check == false) {
                    return;
                }
                var startTime = this.createTimeInFormat(this.viewList[i].courseModelAdder.start_time.hour, this.viewList[i].courseModelAdder.start_time.minute, '');
                var endTime = this.createTimeInFormat(this.viewList[i].courseModelAdder.end_time.hour, this.viewList[i].courseModelAdder.end_time.minute, '');
                test.exam_start_time = startTime;
                test.exam_end_time = endTime;
                test.courseClassSchdList = [];
                for (var j = 0; j < this.viewList[i].courseTableList.length; j++) {
                    var classLi = {};
                    if (this.viewList[i].courseTableList[j].total_marks == undefined) {
                        this.messageNotifier('error', '', 'please enter total marks');
                        return false;
                    }
                    var topics = this.viewList[i].courseTableList[j].topics_covered;
                    classLi.batch_id = this.viewList[i].courseTableList[j].batch_id.toString();
                    classLi.start_time = startTime;
                    classLi.end_time = endTime;
                    classLi.class_desc = this.viewList[i].courseTableList[j].class_desc;
                    classLi.duration = check;
                    classLi.total_marks = this.viewList[i].courseTableList[j].total_marks.toString();
                    if (topics && topics.includes(",")) {
                        classLi.topics_covered = topics.replace(/,/g, "|");
                    }
                    else {
                        if (typeof topics != 'string') {
                            classLi.topics_covered = topics ? (topics.length == 0 ? "" : topics.join("|")) : "";
                        }
                        else {
                            classLi.topics_covered = topics;
                        }
                    }
                    classLi.room_no = this.viewList[i].courseTableList[j].room_no;
                    classLi.class_schedule_id = this.viewList[i].courseTableList[j].class_schedule_id.toString();
                    ;
                    total += Number(this.viewList[i].courseTableList[j].total_marks);
                    test.courseClassSchdList.push(classLi);
                }
                if (total != this.viewList[i].courseModelAdder.total_marks) {
                    this.messageNotifier('error', '', 'Please check total marks provided');
                    return false;
                }
                total = 0;
                coursesLists.push(test);
                if (this.newExamSubjectData.length == 0) {
                    data.coursesList.push(test);
                }
            }
        }
        // FOR NEWLY ADDED EXAM
        if (this.newExamSubjectData.length > 0) {
            // for (let i = 0; i < this.newExamSubjectData.length; i++) {
            var test = { course_id: '', course_exam_schedule_id: '-1' };
            if (this.viewList.length > 0) {
                test.course_id = this.viewList[0].selectedCourseList.course_id;
            }
            var check = this.validateTime2();
            if (check == false) {
                return;
            }
            var startTime = this.createTimeInFormat(this.newExamData.startTimeHrs, this.newExamData.startTimeMins, '');
            var endTime = this.createTimeInFormat(this.newExamData.endTimeHrs, this.newExamData.endTimeMins, '');
            test.exam_start_time = startTime;
            test.exam_end_time = endTime;
            test.courseClassSchdList = [];
            if (this.newExamSubjectData.length > 0) {
                for (var j = 0; j < this.newExamSubjectData.length; j++) {
                    var classLi = {};
                    var bactch_id = "";
                    for (var k = 0; k < this.subjectListData[0].length; k++) {
                        if (this.newExamSubjectData[j].subject_id == this.subjectListData[0][k].subject_id) {
                            bactch_id = this.subjectListData[0][k].batch_id;
                        }
                    }
                    classLi.batch_id = bactch_id.toString();
                    ;
                    classLi.start_time = startTime;
                    classLi.end_time = endTime;
                    classLi.class_desc = this.newExamSubjectData[j].exam_desc;
                    classLi.duration = check;
                    classLi.topics_covered = this.newExamSubjectData[j].topicsId.join("|");
                    classLi.total_marks = this.newExamSubjectData[j].exam_marks.toString();
                    classLi.room_no = this.newExamSubjectData[j].exam_room_no;
                    classLi.class_schedule_id = "0";
                    total += Number(this.newExamSubjectData[j].exam_marks.toString());
                    test.courseClassSchdList.push(classLi);
                }
                // if (total != this.viewList[i].courseModelAdder.total_marks) {
                //   this.messageNotifier('error', '', 'Please check total marks provided');
                //   return false;
                // }
            }
            total = 0;
            data.coursesList.push(test);
            if (validation_flag) {
                var _loop_2 = function (m) {
                    var isPush = false;
                    console.log(coursesLists[m]);
                    this_2.examScheduleData.coursesList.forEach(function (object, index) {
                        if (object.course_exam_schedule_id == coursesLists[m].course_exam_schedule_id) {
                            isPush = true;
                            ;
                        }
                    });
                    if (isPush) {
                        coursesLists[m] && coursesLists[m].courseClassSchdList.length != 0 ? data.coursesList.push(coursesLists[m]) : '';
                    }
                };
                var this_2 = this;
                for (var m = 0; m < coursesLists.length; m++) {
                    _loop_2(m);
                }
            }
            // }
        }
        /// This section makes json for unselected course
        if (this.examScheduleData.coursesList.length > 0) {
            var startIndex = 0;
            var _loop_3 = function (i) {
                if (this_3.examScheduleData.coursesList[i].course_id != this_3.courseData.course_id) {
                    var unselected = {};
                    var timeStart = null;
                    var timeEnd = null;
                    unselected.course_id = this_3.examScheduleData.coursesList[i].course_id.toString();
                    unselected.courseClassSchdList = [];
                    unselected.course_exam_schedule_id = 0;
                    if (this_3.examScheduleData.coursesList[i].courseClassSchdList != null) {
                        var courseSch = this_3.examScheduleData.coursesList[i].courseClassSchdList;
                        if (courseSch.length > 0) {
                            for (var j = 0; j < courseSch.length; j++) {
                                var classLi = {};
                                timeStart = courseSch[j].start_time;
                                timeEnd = courseSch[j].end_time;
                                classLi.batch_id = courseSch[j].batch_id.toString();
                                classLi.start_time = courseSch[j].start_time;
                                classLi.end_time = courseSch[j].end_time;
                                classLi.class_desc = courseSch[j].class_desc;
                                classLi.duration = courseSch[j].duration;
                                classLi.total_marks = courseSch[j].total_marks.toString();
                                classLi.room_no = courseSch[j].room_no;
                                classLi.class_schedule_id = courseSch[j].class_schedule_id.toString();
                                unselected.courseClassSchdList.push(classLi);
                            }
                            unselected.course_exam_schedule_id = this_3.examScheduleData.coursesList[i].course_exam_schedule_id.toString();
                        }
                    }
                    unselected.exam_start_time = timeStart;
                    unselected.exam_end_time = timeEnd;
                    data.coursesList.push(unselected);
                }
                else if (this_3.examScheduleData.coursesList[i].course_id == this_3.courseData.course_id &&
                    this_3.examScheduleData.coursesList[i] && this_3.examScheduleData.coursesList[i].courseClassSchdList == null &&
                    this_3.examScheduleData.coursesList[i].course_exam_schedule_id != 0) {
                    /** this condition used  for cancel exam if user try to create exam
                     * using  same time and type then cancel exam course_exam_schedule_id need to send in new created
                     * exam object  --- added laxmi */
                    if (data.coursesList[i] && this_3.examScheduleData.coursesList[i]) {
                        data.coursesList[startIndex].course_exam_schedule_id = this_3.examScheduleData.coursesList[i].course_exam_schedule_id;
                        startIndex++;
                    }
                    else if (this_3.examScheduleData.coursesList[i]) {
                        var obj = {
                            "course_id": this_3.examScheduleData.coursesList[i].course_id,
                            "courseClassSchdList": [],
                            "exam_start_time": null,
                            "exam_end_time": null,
                            "course_exam_schedule_id": this_3.examScheduleData.coursesList[i].course_exam_schedule_id
                        };
                        data.coursesList.push(obj);
                    }
                }
                else if (this_3.examScheduleData.coursesList[i].course_id == this_3.courseData.course_id &&
                    this_3.examScheduleData.coursesList[i] && this_3.examScheduleData.coursesList[i].courseClassSchdList) {
                    var isNeedToAdd_1 = true;
                    data.coursesList.forEach(function (obj) {
                        if (obj.course_exam_schedule_id == _this.examScheduleData.coursesList[i].course_exam_schedule_id) {
                            isNeedToAdd_1 = false;
                        }
                    });
                    if (isNeedToAdd_1) {
                        if (coursesLists[i]) {
                            data.coursesList.push(coursesLists[i]);
                        }
                    }
                }
            };
            var this_3 = this;
            for (var i = 0; i < this.examScheduleData.coursesList.length; i++) {
                _loop_3(i);
            }
        }
        return data;
    };
    ////cancel Exam popup/////
    CourseExamComponent.prototype.cancelExamCourse = function (data, index, j) {
        this.cancelExamPopUp = true;
        this.cancelExamData = this.viewList[j].courseTableList[index];
    };
    CourseExamComponent.prototype.cancelCourseExam = function () {
        var _this = this;
        if (this.cancelPopUpData.reason.trim() == "" || null) {
            this.messageNotifier('error', '', 'Please Provide Cancellation Reason');
            return;
        }
        var notify = "";
        if (this.cancelPopUpData.notify) {
            notify = "Y";
        }
        else {
            notify = "N";
        }
        if (!this.isRippleLoad) {
            this.isRippleLoad = true;
            var obj = {
                batch_id: this.cancelExamData.batch_id,
                exam_freq: "OTHER",
                cancelSchd: [{
                        schd_id: this.cancelExamData.class_schedule_id,
                        exam_desc: this.cancelPopUpData.reason,
                        is_notified: notify
                    }]
            };
            this.apiService.cancelExamSchedule(obj).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.messageNotifier('success', 'Successfully Cancelled', 'Scheduled exam cancelled successfully');
                _this.closeCancelExamPopUp();
                _this.getExamSchedule();
            }, function (err) {
                //console.log(err);
                _this.isRippleLoad = false;
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    // cancel Button next to Send Reminder
    CourseExamComponent.prototype.cancelExamForFullCourse = function (data, index) {
        this.cancelExamPopUp = true;
        this.cancelExamData = data;
        this.jsonVar.cancelCourseLevel = true;
    };
    CourseExamComponent.prototype.cancelCourseLevelExam = function () {
        var _this = this;
        if (this.cancelPopUpData.reason.trim() == "" || null) {
            this.messageNotifier('error', '', 'Please Provide Cancellation Reason');
            return;
        }
        var notify = "";
        if (this.cancelPopUpData.notify) {
            notify = "Y";
        }
        else {
            notify = "N";
        }
        if (!this.isRippleLoad) {
            this.isRippleLoad = true;
            var obj = {
                cancel_reason: this.cancelPopUpData.reason,
                course_exam_schedule_id: this.cancelExamData.selectedCourseList.course_exam_schedule_id,
                course_id: this.courseData.course_id,
                is_cancel_notify: notify,
                requested_date: __WEBPACK_IMPORTED_MODULE_3_moment__(this.courseData.requested_date).format('YYYY-MM-DD')
            };
            this.apiService.cancelExamScheduleCourse(obj).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.messageNotifier('success', 'Successfully Cancelled', 'Scheduled exam cancelled successfully');
                _this.closeCancelExamPopUp();
                _this.getExamSchedule();
            }, function (err) {
                //console.log(err);
                _this.isRippleLoad = false;
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    //Toggle Buttons////
    CourseExamComponent.prototype.onChanged = function (event) {
        this.selectedType = event.value;
    };
    // Send Reminder
    CourseExamComponent.prototype.sendReminderForCourse = function (data, index) {
        var _this = this;
        if (confirm('Are you sure, You want to notify?')) {
            var obj = {
                course_exam_schedule_id: data.selectedCourseList.course_exam_schedule_id,
                course_id: this.courseData.course_id,
                requested_date: __WEBPACK_IMPORTED_MODULE_3_moment__(this.courseData.requested_date).format('YYYY-MM-DD')
            };
            this.apiService.sendReminder(obj).subscribe(function (res) {
                _this.messageNotifier('success', 'Reminder Sent', 'Notification sent successfully');
            }, function (err) {
                //console.log(err);
                _this.messageNotifier('error', '', "SMS notification can't be sent due to any of the following reasons: SMS setting is not enabled for the institute. SMS quota is not sufficient for the institute. No student(s) assigned in the course to notify");
            });
        }
    };
    CourseExamComponent.prototype.deleteWholeCourse = function (data, index) {
        this.viewList.splice(index, 1);
    };
    // Helper Function
    CourseExamComponent.prototype.validateTime = function (start, end) {
        var start_time = __WEBPACK_IMPORTED_MODULE_3_moment__(this.createTimeInFormat(start.hour, start.minute, 'comp'), 'h:mma');
        var end_time = __WEBPACK_IMPORTED_MODULE_3_moment__(this.createTimeInFormat(end.hour, end.minute, 'comp'), 'h:mma');
        if (!(start_time.isBefore(end_time))) {
            this.messageNotifier('error', '', 'Please enter correct start time and end time');
            return false;
        }
        else {
            var duration = end_time.diff(start_time, 'minutes');
            return duration;
        }
    };
    CourseExamComponent.prototype.validateTime2 = function () {
        var start_time = __WEBPACK_IMPORTED_MODULE_3_moment__(this.createTimeInFormat(this.newExamData.startTimeHrs, this.newExamData.startTimeMins, 'comp'), 'h:mma');
        var end_time = __WEBPACK_IMPORTED_MODULE_3_moment__(this.createTimeInFormat(this.newExamData.endTimeHrs, this.newExamData.endTimeMins, 'comp'), 'h:mma');
        if (!(start_time.isBefore(end_time))) {
            this.messageNotifier('error', '', 'Please enter correct start time and end time');
            return false;
        }
        else {
            var duration = end_time.diff(start_time, 'minutes');
            return duration;
        }
    };
    CourseExamComponent.prototype.breakTimeFormat = function (time) {
        var obj = {};
        obj.hour = time.split(':')[0] + " " + time.split(':')[1].split(' ')[1];
        obj.minute = time.split(':')[1].split(' ')[0];
        return obj;
    };
    CourseExamComponent.prototype.createTimeInFormat = function (hrMeri, minute, format) {
        var time = hrMeri.split(' ');
        if (format == "comp") {
            var t = time[0] + ":" + minute + time[1];
            return t;
        }
        else {
            var t = time[0] + ":" + minute + " " + time[1];
            return t;
        }
    };
    CourseExamComponent.prototype.messageNotifier = function (type, title, msg) {
        var data = {
            type: type,
            title: title,
            body: msg
        };
        this.toastCtrl.popToast(data);
    };
    CourseExamComponent.prototype.checkInstituteType = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isLangInstitute = true;
            }
            else {
                _this.isLangInstitute = false;
            }
        });
    };
    CourseExamComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-course-exam',
            template: __webpack_require__("./src/app/components/course-module/create-course/course-exam/course-exam.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/create-course/course-exam/course-exam.component.scss")],
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_course_services_exam_schedule_service__["a" /* ExamCourseService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_4__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_6__services_course_services_topic_listing_service__["a" /* TopicListingService */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"]])
    ], CourseExamComponent);
    return CourseExamComponent;
}());

var DateMonthFormat = /** @class */ (function () {
    function DateMonthFormat() {
    }
    DateMonthFormat.prototype.transform = function (value) {
        if (value != "" && value != null && value != undefined) {
            return __WEBPACK_IMPORTED_MODULE_3_moment__(value).format('DD-MMM-YYYY');
        }
        else {
            return value;
        }
    };
    DateMonthFormat = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Pipe"])({
            name: 'dateMonthYear'
        })
    ], DateMonthFormat);
    return DateMonthFormat;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/course-exam/course-exam.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseExamModule", function() { return CourseExamModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap_custome_datepicker_bs_datepicker_module__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/bs-datepicker.module.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__course_exam_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-exam/course-exam.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__course_exam_routing_module__ = __webpack_require__("./src/app/components/course-module/create-course/course-exam/course-exam.routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_course_services_exam_schedule_service__ = __webpack_require__("./src/app/services/course-services/exam-schedule.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__progress_kendo_angular_treeview__ = __webpack_require__("./node_modules/@progress/kendo-angular-treeview/dist/fesm5/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__services_course_services_topic_listing_service__ = __webpack_require__("./src/app/services/course-services/topic-listing.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








//import { SplitButtonModule, MenuModule, MenuItem, SelectButtonModule, TabViewModule, ButtonModule } from 'primeng/primeng';


var CourseExamModule = /** @class */ (function () {
    function CourseExamModule() {
    }
    CourseExamModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_8__progress_kendo_angular_treeview__["a" /* TreeViewModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_3__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_4__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap_custome_datepicker_bs_datepicker_module__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_1__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_6__course_exam_routing_module__["a" /* CourseExamRouting */],
            ],
            exports: [],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_5__course_exam_component__["a" /* CourseExamComponent */],
                __WEBPACK_IMPORTED_MODULE_5__course_exam_component__["b" /* DateMonthFormat */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_7__services_course_services_exam_schedule_service__["a" /* ExamCourseService */],
                __WEBPACK_IMPORTED_MODULE_9__services_course_services_topic_listing_service__["a" /* TopicListingService */]
            ]
        })
    ], CourseExamModule);
    return CourseExamModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/course-exam/course-exam.routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CourseExamRouting; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__course_exam_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-exam/course-exam.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var CourseExamRouting = /** @class */ (function () {
    function CourseExamRouting() {
    }
    CourseExamRouting = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__course_exam_component__["a" /* CourseExamComponent */],
                        pathMatch: 'prefix',
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], CourseExamRouting);
    return CourseExamRouting;
}());



/***/ }),

/***/ "./src/app/services/course-services/exam-schedule.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ExamCourseService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ExamCourseService = /** @class */ (function () {
    function ExamCourseService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseURL = "";
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseURL = this.auth.getBaseUrl();
    }
    // Function For Lang Model
    ExamCourseService.prototype.getCombinedList = function (standard, subject_id) {
        var url = this.baseURL + "/api/v1/batches/fetchCombinedBatchData/" + this.institute_id + "?standard_id=" + standard + "&subject_id=" + subject_id + "&assigned=N";
        return this.http.get(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.getExamSchedule = function (id) {
        var url = this.baseURL + "/api/v1/batchExamSched/" + id;
        return this.http.get(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.putRequestExamSchedule = function (data) {
        var url = this.baseURL + "/api/v1/batchExamSched";
        return this.http.put(url, data, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.postRequestExamSchedule = function (data) {
        var url = this.baseURL + "/api/v1/batchExamSched";
        return this.http.post(url, data, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.serverRequestToSaveSchedule = function (data, Type) {
        var url = this.baseURL + "/api/v1/batchExamSched";
        if (Type == "post") {
            return this.http.post(url, data, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
        }
        else {
            return this.http.put(url, data, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
        }
    };
    ExamCourseService.prototype.notifyStudentExam = function (id) {
        var url = this.baseURL + "/api/v1/batchExamSched/notify/" + this.institute_id + "/" + id;
        return this.http.get(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.fetchStudentList = function (data) {
        var url = this.baseURL + "/api/v1/attendance/exam";
        return this.http.post(url, data, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.markAttendance = function (data) {
        var url = this.baseURL + "/api/v1/attendance/exam";
        return this.http.put(url, data, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.cancelExamSchedule = function (obj) {
        var url = this.baseURL + "/api/v1/batchExamSched/cancel";
        return this.http.put(url, obj, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.notifyCancelledClass = function (obj) {
        var url = this.baseURL + "/api/v1/coursePlanner/notify";
        return this.http.post(url, obj, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.uncancelClassSchedule = function (obj) {
        var url = this.baseURL + "/api/v1/batchExamSched/unCancel";
        return this.http.put(url, obj, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ///////////////////////////////////
    /// For Course Model ///
    ExamCourseService.prototype.getMasterCourse = function () {
        var url = this.baseURL + "/api/v1/courseMaster/fetch/" + this.institute_id + "/all";
        return this.http.get(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.getSchedule = function (obj) {
        obj.inst_id = this.institute_id;
        var url = this.baseURL + "/api/v1/courseExamSchedule/fetch";
        return this.http.post(url, obj, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.sendReminder = function (obj) {
        obj.inst_id = this.institute_id;
        var url = this.baseURL + "/api/v1/courseExamSchedule/sendReminder";
        return this.http.post(url, obj, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.cancelExamScheduleCourse = function (obj) {
        obj.inst_id = this.institute_id;
        var url = this.baseURL + "/api/v1/courseExamSchedule/cancel";
        return this.http.post(url, obj, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.fetchCourseListData = function (data) {
        var url = this.baseURL + "/api/v1/courseMaster/fetch/" + this.institute_id + "/" + data;
        return this.http.get(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService.prototype.updateExamSch = function (data) {
        data.inst_id = this.institute_id;
        var url = this.baseURL + "/api/v1/courseExamSchedule/update";
        return this.http.post(url, data, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamCourseService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */],
            __WEBPACK_IMPORTED_MODULE_2__authenticator_service__["a" /* AuthenticatorService */]])
    ], ExamCourseService);
    return ExamCourseService;
}());



/***/ })

});
//# sourceMappingURL=course-exam.module.chunk.js.map