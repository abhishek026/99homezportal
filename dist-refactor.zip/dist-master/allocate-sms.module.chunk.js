webpackJsonp(["allocate-sms.module"],{

/***/ "./src/app/components/allocate-sms/allocate-sms-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AllocateSmsRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__transactional_transactional_component__ = __webpack_require__("./src/app/components/allocate-sms/transactional/transactional.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__allocate_sms_component__ = __webpack_require__("./src/app/components/allocate-sms/allocate-sms.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var AllocateSmsRoutingModule = /** @class */ (function () {
    function AllocateSmsRoutingModule() {
    }
    AllocateSmsRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_3__allocate_sms_component__["a" /* AllocateSmsComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: 'sms-details',
                                component: __WEBPACK_IMPORTED_MODULE_2__transactional_transactional_component__["a" /* TransactionalComponent */],
                                pathMatch: 'prefix'
                            }
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], AllocateSmsRoutingModule);
    return AllocateSmsRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/allocate-sms/allocate-sms.component.html":
/***/ (function(module, exports) {

module.exports = "\r\n  <router-outlet></router-outlet>"

/***/ }),

/***/ "./src/app/components/allocate-sms/allocate-sms.component.scss":
/***/ (function(module, exports) {

module.exports = ".container-sms {\n  padding: 10px; }\n  .container-sms .title {\n    font-size: 14px;\n    font-weight: 600; }\n  .container-sms .allocate-sms {\n    padding-top: 10px;\n    padding-bottom: 10px;\n    border-bottom: 1px solid gray; }\n  .container-sms .allocate-sms .btn {\n      border-radius: .25rem; }\n  .sms-title {\n  font-size: 14px;\n  font-weight: 600;\n  padding-left: 1rem; }\n"

/***/ }),

/***/ "./src/app/components/allocate-sms/allocate-sms.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AllocateSmsComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var AllocateSmsComponent = /** @class */ (function () {
    function AllocateSmsComponent() {
    }
    AllocateSmsComponent.prototype.ngOnInit = function () {
    };
    AllocateSmsComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-allocate-sms',
            template: __webpack_require__("./src/app/components/allocate-sms/allocate-sms.component.html"),
            styles: [__webpack_require__("./src/app/components/allocate-sms/allocate-sms.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], AllocateSmsComponent);
    return AllocateSmsComponent;
}());



/***/ }),

/***/ "./src/app/components/allocate-sms/allocate-sms.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllocateSmsModule", function() { return AllocateSmsModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__transactional_transactional_component__ = __webpack_require__("./src/app/components/allocate-sms/transactional/transactional.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__allocate_sms_component__ = __webpack_require__("./src/app/components/allocate-sms/allocate-sms.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__allocate_sms_routing_module__ = __webpack_require__("./src/app/components/allocate-sms/allocate-sms-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var AllocateSmsModule = /** @class */ (function () {
    function AllocateSmsModule() {
    }
    AllocateSmsModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_5__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_5__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_4__allocate_sms_routing_module__["a" /* AllocateSmsRoutingModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_2__transactional_transactional_component__["a" /* TransactionalComponent */],
                __WEBPACK_IMPORTED_MODULE_3__allocate_sms_component__["a" /* AllocateSmsComponent */]
            ]
        })
    ], AllocateSmsModule);
    return AllocateSmsModule;
}());



/***/ }),

/***/ "./src/app/components/allocate-sms/transactional/transactional.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\" container-fluid\">\r\n  <div class=\"container-sms\">\r\n    <h1 class=\"pull-left\">\r\n      <a routerLink=\"/view/home/admin\">\r\n        Home\r\n      </a>\r\n      <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>Allocate SMS\r\n    </h1>\r\n    <div class=\"allocate-sms\">\r\n      <input type=\"button\" [ngClass]=\"{'fullBlue': type=='Transactional'}\" style=\"margin-left: 0px;\" class=\"btn\" value=\"Transactional\" (click)=\"changeType('Transactional')\">\r\n      <input type=\"button\" class=\"btn\" [ngClass]=\"{'fullBlue': type=='Promotional'}\" (click)=\"changeType('Promotional')\" value=\"Promotional\">\r\n    </div>\r\n  </div>\r\n  <div class=\"sms-title\">SMS Plan</div>\r\n  <div class=\"container-fluid\">\r\n    <table class=\"table table-hover\">\r\n      <thead class=\"border-css\">\r\n        <tr>\r\n          <th class=\"firstTh\"> Total SMS</th>\r\n          <th> Price (Per SMS in Paisa)</th>\r\n          <th>Tax(%)</th>\r\n          <th>Total Price in Rs.</th>\r\n        </tr>\r\n      </thead>\r\n      <tbody>\r\n        <tr *ngFor=\"let smsDetails  of transactionSMS; let i =index\">\r\n          <td>\r\n            <div class=\"c-sm-1 c-md-1 c-lg-1\">\r\n              <div class=\"field-radio-wrapper\">\r\n                <input type=\"radio\" name=\"bothRadio\" [id]=\"'bothRadio-'+i\" class=\"form-radio\" [value]=\"i\" [(ngModel)]=\"radioSelected\">\r\n                <label [for]=\"'bothRadio-'+i\">{{smsDetails.total_sms}}</label>\r\n              </div>\r\n            </div>\r\n          </td>\r\n          <td>{{smsDetails.price}}</td>\r\n          <td>{{smsDetails.tax}}</td>\r\n          <td class=\"total_price\">{{smsDetails.total_price | number}}</td>\r\n        </tr>\r\n      </tbody>\r\n    </table>\r\n\r\n    <div class=\"text-right\">\r\n      <input type=\"button\" class=\"btn\" routerLink=\"/view/home/admin\" value=\"Back\">\r\n      <input type=\"button\" class=\"btn fullBlue btn-buy\" (click)=\"openRazorpayCheckout()\" value=\"Buy Now\">\r\n    </div>\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./src/app/components/allocate-sms/transactional/transactional.component.scss":
/***/ (function(module, exports) {

module.exports = ".container-fluid {\n  color: #797979;\n  padding-top: 10px; }\n  .container-fluid .border-css {\n    border: 1px solid rgba(211, 212, 213, 0.5); }\n  .container-fluid table thead {\n    font-size: 14px;\n    font-weight: 600; }\n  .container-fluid table thead tr th {\n      color: #797979; }\n  .container-fluid table thead tr td {\n      color: #dbdbdb; }\n  .container-fluid table thead tr .total_price {\n      color: #585574; }\n  .container-fluid .btn-buy {\n    border-radius: .25rem; }\n  .container-sms {\n  padding: 10px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column; }\n  .container-sms .allocate-sms {\n    padding-top: 10px;\n    padding-bottom: 10px;\n    border-bottom: 1px solid gray; }\n  .btn {\n  border-radius: .25rem; }\n  .firstTh {\n  text-align: left;\n  padding-left: 18px; }\n  .sms-title {\n  font-size: 14px;\n  font-weight: 600;\n  padding-left: 1rem; }\n  .filter-section {\n  padding: 10px 0px;\n  margin: 5px 0;\n  background: #efefef; }\n  .filter-section .radio-button {\n    margin-top: 10px;\n    display: -webkit-inline-box;\n    display: -ms-inline-flexbox;\n    display: inline-flex; }\n  .filter-section .radio-button .field-radio-wrapper {\n      margin-right: 5px; }\n  .filter-section .field-wrapper {\n    padding-top: 0; }\n  .filter-section .btn {\n    margin-left: 0; }\n"

/***/ }),

/***/ "./src/app/components/allocate-sms/transactional/transactional.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TransactionalComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_http_service__ = __webpack_require__("./src/app/services/http.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var TransactionalComponent = /** @class */ (function () {
    function TransactionalComponent(apiService, auth, _msgService, zone) {
        var _this = this;
        this.apiService = apiService;
        this.auth = auth;
        this._msgService = _msgService;
        this.zone = zone;
        this.type = 'Transactional';
        this.radioSelected = 0;
        this.transactionSMS = [
            { total_sms: 5000, price: 13, tax: 18, total_price: 767 },
            { total_sms: 10000, price: 13, tax: 18, total_price: 1534 },
            { total_sms: 25000, price: 13, tax: 18, total_price: 3835 },
            { total_sms: 50000, price: 13, tax: 18, total_price: 7670 },
            { total_sms: 100000, price: 12, tax: 18, total_price: 14160 }
        ];
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
    }
    TransactionalComponent.prototype.ngOnInit = function () {
    };
    TransactionalComponent.prototype.changeType = function (type) {
        this.type = type;
        ;
    };
    TransactionalComponent.prototype.openRazorpayCheckout = function () {
        var self = this;
        var merchant_acc = [{ key_id: "rzp_live_pQXvkbWD4oVatb" }]; //rzp_test_vuWxy6G3R70M8C
        // console.log(merchant_acc[0]);
        var total_amount = this.transactionSMS[this.radioSelected].total_price * 100;
        var options = {
            key: merchant_acc[0].key_id,
            amount: total_amount,
            name: "Proctur ",
            description: "Eduspace Technologies Pvt. Ltd",
            theme: {
                color: "blue"
            },
            handler: this.paymentResponseHander.bind(this),
            modal: {
                "ondismiss": function () {
                    self.paymentCancelled();
                }
            }
        };
        var rzp = new Razorpay(options);
        rzp.open();
    };
    TransactionalComponent.prototype.paymentCancelled = function () {
        // Transaction Cancelled
        console.log('Payment Cancelled Called');
        // this._msgService.showErrorMessage('error', '', "due to some problem your transaction is cancel ");
    };
    TransactionalComponent.prototype.paymentResponseHander = function (response) {
        var _this = this;
        var data = {
            "sms_quota_allocated": this.transactionSMS[this.radioSelected].total_sms,
            "sms_type": this.type // Promotional
        };
        this.apiService.putData('/api/v1/institute/SMS/transaction/buyOnline/' + this.institute_id, data).subscribe(function (resp) {
            console.log(resp);
            _this.zone.run(function () {
                _this._msgService.showErrorMessage('success', '', "SMS successfully added in your account");
            });
        }, function (err) {
            console.log(err);
            _this.zone.run(function () {
                _this._msgService.showErrorMessage('error', '', "Something went wrong please try again and if your payment deducted from your account it will be added in your account within 5 to 6 days ");
            });
        });
    };
    TransactionalComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-transactional',
            template: __webpack_require__("./src/app/components/allocate-sms/transactional/transactional.component.html"),
            styles: [__webpack_require__("./src/app/components/allocate-sms/transactional/transactional.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_http_service__["a" /* HttpService */],
            __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__["a" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["NgZone"]])
    ], TransactionalComponent);
    return TransactionalComponent;
}());



/***/ })

});
//# sourceMappingURL=allocate-sms.module.chunk.js.map