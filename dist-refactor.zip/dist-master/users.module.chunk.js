webpackJsonp(["users.module"],{

/***/ "./src/app/components/users-management/users/add-edit-user/add-edit-user.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\"\r\n  *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n<section class=\"middle-section clearFix\">\r\n  <div class=\"content-container\">\r\n\r\n    <h3 *ngIf=\"userId == -1\">Add User</h3>\r\n    <h3 *ngIf=\"userId != -1\">Edit User Detail</h3>\r\n\r\n    <div class=\"user-form-section\">\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"nameUser\">Name <span class=\"text-danger\">*</span></label>\r\n            <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"roleDetails.name\" id=\"nameUser\" name=\"nameUser\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"contactNO\">Contact No<span class=\"text-danger\">*</span></label><br>\r\n            <span class=\"countryCallingCode\"style=\"width: 20%\">\r\n                <select id=\"country_id\" class=\"form-ctrl\" [(ngModel)]=\"roleDetails.country_id\" name=\"country_id\"\r\n                [disabled]=\"countryDetails.length<=1\" (change)=\"onChangeObj($event.target.value)\" style=\"height: 29px;padding: 0\">\r\n                <option value=\"\"></option>\r\n                <option [value]=\"data.id\" selected *ngFor='let data of countryDetails'>\r\n                  {{data.country_code}} +{{data.country_calling_code}}\r\n                </option>\r\n              </select>\r\n            </span> \r\n            <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"roleDetails.username\" id=\"contactNO\" name=\"contactNO\"\r\n              onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\"\r\n               style=\"width: 80%\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n          <div class=\"field-wrapper\">\r\n              <label for=\"emailID\">Email ID</label>\r\n              <!-- <label for=\"emailID\" *ngIf=\"userId != '-1'\">Alternate Login Email ID</label> -->\r\n              <input type=\"text\" class=\"form-ctrl\"\r\n              [(ngModel)]=\"roleDetails.alternate_email_id\" id=\"emailID\" name=\"emailID\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n \r\n      <div class=\"row\">\r\n        <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"address\">Address</label>\r\n            <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"roleDetails.address\" id=\"address\" name=\"address\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\" *ngIf=\"userId == '-1' || roleDetails.userType == '0'\">\r\n        <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"\">Role<span class=\"text-danger\">*</span></label>\r\n            <select id=\"\" class=\"form-ctrl\" [(ngModel)]=\"roleDetails.role_id\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let opt of rolesList\" [value]=\"opt.role_id\">\r\n                {{opt.role_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\" *ngIf=\"userId != '-1' && roleDetails.mutlpleRoles != '' && roleDetails.mutlpleRoles != null\">\r\n        <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n          <h4>Multiple Roles:{{roleDetails.mutlpleRoles}}</h4>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\" *ngIf=\"biometricEnable == '1'\">\r\n        <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"attendance_device_id\">Attendance Card ID</label>\r\n            <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"roleDetails.attendance_device_id\"\r\n              id=\"attendance_device_id\" name=\"attendance_device_id\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\" *ngIf=\"userId == '-1'\">\r\n        <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n          <div class=\"field-checkbox-wrapper\">\r\n            <input id=\"is_employee_to_be_create\" name=\"is_employee_to_be_create\" type=\"checkbox\" class=\"form-checkbox\"\r\n              [(ngModel)]=\"roleDetails.is_employee_to_be_create\">\r\n            <label for=\"is_employee_to_be_create\">Allow Employee to create automatically</label>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\" *ngIf=\"userId != '-1'\">\r\n        <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n          <div class=\"field-checkbox-wrapper\">\r\n            <input id=\"is_active\" name=\"is_active\" type=\"checkbox\" class=\"form-checkbox\"\r\n              [(ngModel)]=\"roleDetails.is_active\">\r\n            <label for=\"is_active\">Is Active</label>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-6 c-lg-6 c-md-6\">\r\n          <div class=\"pull-right\">\r\n            <button class=\"btn\" routerLink=\"/view/manage/user\">Cancel</button>\r\n            <button class=\"btn fullBlue\" *ngIf=\"userId == '-1'\" [disabled]=\"isRippleLoad\"\r\n              (click)=\"saveUserDetails()\">Save</button>\r\n            <button class=\"btn fullBlue\" *ngIf=\"userId != '-1'\" [disabled]=\"isRippleLoad\"\r\n              (click)=\"updateUserDetails()\">Update</button>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n\r\n  </div>\r\n</section>"

/***/ }),

/***/ "./src/app/components/users-management/users/add-edit-user/add-edit-user.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.middle-section {\n  padding: 10px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.row {\n  margin-top: 5px;\n  margin-bottom: 5px; }\n.countryCallingCode {\n  float: left; }\n"

/***/ }),

/***/ "./src/app/components/users-management/users/add-edit-user/add-edit-user.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AddEditUserComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_user_management_user_service__ = __webpack_require__("./src/app/services/user-management/user.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var AddEditUserComponent = /** @class */ (function () {
    function AddEditUserComponent(route, activatedRoute, apiService, toastCtrl, commonService) {
        this.route = route;
        this.activatedRoute = activatedRoute;
        this.apiService = apiService;
        this.toastCtrl = toastCtrl;
        this.commonService = commonService;
        this.isRippleLoad = false;
        this.userId = "-1";
        this.rolesList = [];
        this.roleDetails = {
            name: '',
            address: '',
            username: '',
            country_id: '',
            alternate_email_id: '',
            role_id: '-1',
            attendance_device_id: '',
            userType: '',
            is_employee_to_be_create: 'true'
        };
        this.biometricEnable = '0';
        this.instituteCountryDetObj = {};
        this.countryDetails = [];
        this.maxlength = null;
        this.country_id = null;
    }
    AddEditUserComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.roleDetails = {
            name: '',
            address: '',
            username: '',
            country_id: '',
            alternate_email_id: '',
            role_id: '-1',
            attendance_device_id: '',
            userType: '',
            is_employee_to_be_create: 'true'
        };
        this.activatedRoute.params.subscribe(function (res) {
            if (res.hasOwnProperty('id')) {
                _this.userId = res.id;
                _this.fetchUserDetails(res.id);
            }
            else {
                _this.userId = "-1";
            }
        });
        this.getRolesList();
        this.biometricEnable = sessionStorage.getItem('biometric_attendance_feature');
        this.fetchDataForCountryDetails();
    };
    // created by: Nalini Walunj
    // Below three functions are written to fetch country details from the session stored at the time of login of institute
    AddEditUserComponent.prototype.fetchDataForCountryDetails = function () {
        var encryptedData = sessionStorage.getItem('country_data');
        var data = JSON.parse(encryptedData);
        if (data.length > 0) {
            this.countryDetails = data;
            this.instituteCountryDetObj = this.countryDetails[0];
            this.roleDetails.country_id = this.countryDetails[0].id;
            this.maxlength = this.countryDetails[0].country_phone_number_length;
            this.country_id = this.countryDetails[0].id;
        }
    };
    AddEditUserComponent.prototype.onChangeObj = function (event) {
        var _this = this;
        console.log(event);
        this.countryDetails.forEach(function (element) {
            if (element.id == event) {
                _this.instituteCountryDetObj = element;
                // this.phonenumberCheck(this.instituteCountryDetObj.country_phone_number_length);
                _this.maxlength = _this.instituteCountryDetObj.country_phone_number_length;
                _this.country_id = element.id;
            }
            _this.roleDetails.country_id = _this.instituteCountryDetObj.id;
        });
    };
    AddEditUserComponent.prototype.getRolesList = function () {
        var _this = this;
        this.apiService.getRoles().subscribe(function (res) {
            _this.rolesList = res;
        }, function (err) {
            //console.log(err);
        });
    };
    AddEditUserComponent.prototype.fetchUserDetails = function (id) {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.fetchUserDetails(id).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.roleDetails = res;
            _this.countryDetails.forEach(function (element) {
                if (element.id == _this.roleDetails.country_id) {
                    _this.instituteCountryDetObj = element;
                    // this.phonenumberCheck(this.instituteCountryDetObj.country_phone_number_length);
                    _this.maxlength = _this.instituteCountryDetObj.country_phone_number_length;
                    _this.country_id = _this.instituteCountryDetObj.id;
                }
            });
            if (_this.roleDetails.is_active == 'Y') {
                _this.roleDetails.is_active = true;
            }
            else {
                _this.roleDetails.is_active = false;
            }
        }, function (err) {
            _this.isRippleLoad = false;
            console.log(err);
        });
    };
    AddEditUserComponent.prototype.saveUserDetails = function () {
        var _this = this;
        var validate = this.validateUserDetails(this.roleDetails);
        if (validate == false) {
            return;
        }
        if (this.roleDetails.is_employee_to_be_create == true) {
            this.roleDetails.is_employee_to_be_create = 'Y';
        }
        else {
            this.roleDetails.is_employee_to_be_create = 'N';
        }
        var obj = {
            address: this.roleDetails.address,
            attendance_device_id: this.roleDetails.attendance_device_id,
            is_active: this.roleDetails.is_active,
            name: this.roleDetails.name,
            phone: this.roleDetails.username,
            country_id: this.roleDetails.country_id,
            role_id: this.roleDetails.role_id,
            username: this.roleDetails.username,
            alternate_email_id: this.roleDetails.alternate_email_id
        };
        console.log(obj);
        if (!this.isRippleLoad) {
            this.isRippleLoad = true;
            this.apiService.createUser(obj).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.messageNotifier('success', 'Added Successfully', 'User Added Successfully');
                _this.route.navigateByUrl('/view/manage/user');
            }, function (err) {
                _this.isRippleLoad = false;
                console.log(err);
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    AddEditUserComponent.prototype.updateUserDetails = function () {
        var _this = this;
        var validate = this.validateUserDetails(this.roleDetails);
        if (validate == false) {
            return;
        }
        if (this.roleDetails.is_active == true) {
            this.roleDetails.is_active = 'Y';
        }
        else {
            this.roleDetails.is_active = 'N';
        }
        var obj = {
            address: this.roleDetails.address,
            attendance_device_id: this.roleDetails.attendance_device_id,
            is_active: this.roleDetails.is_active,
            name: this.roleDetails.name,
            phone: this.roleDetails.username,
            country_id: this.roleDetails.country_id,
            role_id: this.roleDetails.role_id,
            alternate_email_id: this.roleDetails.alternate_email_id
        };
        console.log(obj);
        if (!this.isRippleLoad) {
            this.isRippleLoad = true;
            this.apiService.updateUserDetails(obj, this.userId).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.messageNotifier('success', 'Updated Successfully', 'Details Updated Successfully');
                _this.route.navigateByUrl('/view/manage/user');
            }, function (err) {
                _this.isRippleLoad = false;
                console.log(err);
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    AddEditUserComponent.prototype.validateUserDetails = function (obj) {
        var check = false;
        if (obj.name.trim() == "") {
            this.messageNotifier('error', '', 'Please enter name');
            return false;
        }
        console.log(this.maxlength);
        check = this.commonService.phonenumberCheck(obj.username, this.maxlength, this.country_id);
        if (check == false) {
            this.messageNotifier('error', '', 'Please check the number you have provided');
            return false;
        }
        if (check == 'noNumber') {
            this.messageNotifier('error', '', 'Please enter valid contact no.');
            return false;
        }
        if (obj.alternate_email_id.trim() != "") {
            check = this.ValidateEmail(obj.alternate_email_id);
            if (check == false) {
                this.messageNotifier('error', '', 'Please check the email you have provided');
                return false;
            }
        }
        if (this.userId == "-1") {
            if (obj.role_id == '-1') {
                this.messageNotifier('error', '', 'Please assign role to user');
                return false;
            }
        }
        return true;
    };
    // phonenumberCheck(inputtxt, maxlength) {
    //   let phoneno = /^\d{10}$/;
    //   // let phoneno = /^\d+$/+(maxlength);
    //   if ((inputtxt.match(phoneno))) {
    //     return true;
    //   }
    //   else {
    //     return false;
    //   }
    // }
    AddEditUserComponent.prototype.phonenumberCheck = function (inputtxt, maxlength) {
        console.log(maxlength);
        console.log(inputtxt);
        if (inputtxt.length == maxlength) {
            return true;
        }
        else {
            return false;
        }
    };
    AddEditUserComponent.prototype.ValidateEmail = function (mail) {
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
            return true;
        }
        return false;
    };
    AddEditUserComponent.prototype.messageNotifier = function (type, title, msg) {
        var data = {
            type: type,
            title: title,
            body: msg
        };
        this.toastCtrl.popToast(data);
    };
    AddEditUserComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-add-edit-user',
            template: __webpack_require__("./src/app/components/users-management/users/add-edit-user/add-edit-user.component.html"),
            styles: [__webpack_require__("./src/app/components/users-management/users/add-edit-user/add-edit-user.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["ActivatedRoute"],
            __WEBPACK_IMPORTED_MODULE_2__services_user_management_user_service__["a" /* UserService */],
            __WEBPACK_IMPORTED_MODULE_3__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_4__services_common_service__["a" /* CommonServiceFactory */]])
    ], AddEditUserComponent);
    return AddEditUserComponent;
}());



/***/ }),

/***/ "./src/app/components/users-management/users/users.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n\r\n<section class=\"middle-section clearFix\">\r\n  <div class=\"content-container\">\r\n\r\n    <div class=\"head\">\r\n      <div class=\"row\">\r\n        <div class=\"pull-left\">\r\n          <div class=\"header-wrapper\">\r\n            <h3 style=\"display: inline-flex\">User List\r\n              <div style=\"margin-top: -8px\">\r\n                <rob-tooltip [textMessage]=\"'?'\" [message]=\"toottip\" [placement]=\"'left'\" [customClass]=\"'left'\">\r\n                </rob-tooltip>\r\n              </div>\r\n            </h3>\r\n          </div>\r\n        </div>\r\n        <div class=\"btnWrapper\">\r\n          <button type=\"button\" class=\"btn pull-right\" name=\"button\" routerLink='./addedit'>\r\n            <i class=\"fa fa-plus\" aria-hidden=\"true\"></i>\r\n            &nbsp; Add User\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n\r\n    <div class=\"filter-section\">\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n          <div class=\"field-wrapper\" style=\"padding-top: 0px;\">\r\n            <label for=\"userType\" style=\"font-weight: bold;\">User Type</label>\r\n            <select id=\"userType\" class=\"form-ctrl\" [(ngModel)]=\"dataFilter.role\" (ngModelChange)=\"clearData()\">\r\n              <option value=\"-1\"></option>\r\n              <option value=\"100\">Admin</option>\r\n              <option value=\"0\">Custom</option>\r\n              <option value=\"3\">Faculty</option>\r\n              <option value=\"1\">Student</option>\r\n              <option value=\"5\">Parent</option>\r\n              <option value=\"99\">Open App User</option>\r\n              <option value=\"1000\">Others</option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n        <div class=\"c-sm-2 c-md-2 c-lg-2\" style=\"margin-top: 25px;\">\r\n          <div class=\"field-checkbox-wrapper\">\r\n            <input type=\"checkbox\" name=\"check\" class=\"form-checkbox\" [(ngModel)]=\"dataFilter.is_active\" id=\"isAct\">\r\n            <label for=\"isAct\">Is Active</label>\r\n          </div>\r\n        </div>\r\n        <div class=\"c-sm-2 c-md-2 c-lg-2\" style=\"margin-top: 15px; margin-left: -8em;\">\r\n          <button class=\"btn fullBlue\" style=\"    height: 32px !important ;padding: 5px 12px;\" (click)=\"getAllUserList()\">Go</button>\r\n        </div>\r\n        <div class=\"\">\r\n          <div class=\"pull-right\" style=\"margin-top: 20px;margin-right: 15px;\">\r\n            <div class=\"search-filter-wrapper\">\r\n              <input type=\"text\" class=\"normal-field pull-right\" placeholder=\"Search\" name=\"searchData\" [(ngModel)]=\"searchText\" (keyup)=\"searchInList()\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"user-table-wrapper\" *ngIf=\"showUserTable\">\r\n      <div class=\"table-responsive\">\r\n        <table>\r\n          <thead>\r\n            <tr>\r\n              <th></th>\r\n              <th class=\"align-txt-lft\">Name</th>\r\n              <th class=\"align-txt-lft\">Contact No</th>\r\n              <th class=\"align-txt-lft\">Email Id</th>\r\n              <th class=\"align-txt-lft\" *ngIf=\"(dataFilter.role==1 || dataFilter.role==3||dataFilter.role==5 )&& dataFilter.is_show_credentials\">Credentials</th>\r\n              <th *ngIf=\"(dataFilter.role==1 || dataFilter.role==3||dataFilter.role==5 ) && dataFilter.is_show_credentials\"></th>\r\n              <th class=\"align-txt-lft\">User Type</th>\r\n              <th class=\"align-txt-lft\"> Inventory</th>\r\n              <th class=\"align-txt-lft\">Action</th>\r\n            </tr>\r\n          </thead>\r\n          <tbody>\r\n            <tr *ngFor=\"let data of usersList; let i = index; trackBy: i\">\r\n              <td>\r\n                <div class=\"field-checkbox-wrapper\">\r\n                  <input type=\"checkbox\" class=\"form-checkbox\" [(ngModel)]=\"data.assigned\" (click)=\"userSelectedEvent($event , data)\">\r\n                  <label></label>\r\n                </div>\r\n              </td>\r\n              <td class=\"align-txt-lft\">{{data.name}}</td>\r\n              <td class=\"align-txt-lft\">{{data.username}}</td>\r\n              <td class=\"align-txt-lft\">{{data.alternate_email_id}}</td>\r\n              <td class=\"align-txt-lft\" *ngIf=\"(dataFilter.role==1 || dataFilter.role==3||dataFilter.role==5 ) && dataFilter.is_show_credentials\">\r\n                <div class=\"credentials-view\">\r\n                  <span>Username :</span>\r\n                  <span>{{data.username}}</span>\r\n                </div>\r\n                <div class=\"credentials-view\">\r\n                  <span>Password :</span>\r\n                  <span *ngIf=\"data.isEncript\">****</span>\r\n                  <span *ngIf=\"!data.isEncript\">{{data.password}}</span>\r\n                </div>\r\n              </td>\r\n              <td *ngIf=\"( dataFilter.role==1 || dataFilter.role==3 || dataFilter.role==5 ) && dataFilter.is_show_credentials\">\r\n                <i class=\"fa fa-eye psw-show\" aria-hidden=\"true\" (click)=\"descriptPassword(data)\" *ngIf=\"!data.isEncript\"></i>\r\n                <i class=\"fa fa-eye-slash psw-show\" aria-hidden=\"true\" (click)=\"descriptPassword(data)\" *ngIf=\"data.isEncript\"></i>\r\n              </td>\r\n\r\n              <td class=\"align-txt-lft\">{{data.userType}}</td>\r\n              <td class=\"align-txt-lft\">\r\n                <a (click)=\"allocateItemToUser(data)\">Allocate</a>\r\n              </td>\r\n              <td class=\"action-menu align-txt-lft\">\r\n                <a [routerLink]='[\"./addedit\" , data.user_id]'>Edit</a>\r\n                <!-- <a (click)=\"deleteUser(data)\">Delete</a> -->\r\n              </td>\r\n            </tr>\r\n            <tr *ngIf=\"usersList.length == 0\">\r\n              <td colspan=\"9\">\r\n                No User Data Found\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n        </table>\r\n      </div>\r\n    </div>\r\n\r\n    <!-- Paginator Here -->\r\n    <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n      <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n        <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n          [page]=\"PageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRow\">\r\n        </pagination>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"btn-group pull-right\" *ngIf=\"usersList.length > 0\">\r\n      <button (click)=\"sendSmsForApp('1')\" class=\"btn fullBlue\">SMS For APP Download</button>\r\n      <button (click)=\"sendSmsForApp('2')\" class=\"btn fullBlue\">SMS For APP Upgradation</button>\r\n      <!-- <button (click)=\"sendSmsForApp('3')\" class=\"btn fullBlue\">SMS For APP Alternate Login Registration</button> -->\r\n    </div>\r\n\r\n  </div>\r\n</section>\r\n\r\n\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n\r\n<section id=\"popup \" class=\"popupWrapper fadeIn \" *ngIf=\"allocateItemPopUp\">\r\n  <div class=\"popup pos-abs popup-body-container\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closePopUp()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n          <g id=\"Group_1228 \" data-name=\"Group 1228\" transform=\"translate(8298 1888) \">\r\n            <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77)rotate(45)\" />\r\n              <line id=\"Line_275 \" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77)rotate(45)\" />\r\n            </g>\r\n            <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n            />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content allocation-popup\">\r\n        <h2>Allocate Inventory Item</h2>\r\n        <div class=\"row filler-section\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n            <div class=\"field-wrapper\">\r\n              <label for=\"\">Item<span class=\"text-danger\">*</span></label>\r\n              <select id=\"\" class=\"form-ctrl\" [(ngModel)]=\"allocateInventory.item_id\" (ngModelChange)=\"onitemSelction()\">\r\n                <option value=\"-1\"></option>\r\n                <option *ngFor=\"let opt of inventoryList\" [value]=\"opt.item_id\">\r\n                  {{opt.item_name}} ({{opt.category_name}})\r\n                </option>\r\n              </select>\r\n              <p *ngIf=\"showUnit\">Available Units:{{availableunit}}</p>\r\n            </div>\r\n          </div>\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n            <div class=\"field-wrapper\">\r\n              <label for=\"unitInv\">Unit<span class=\"text-danger\">*</span></label>\r\n              <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"allocateInventory.alloted_units\" id=\"unitInv\" name=\"unitInv\">\r\n            </div>\r\n          </div>\r\n          <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n            <button class=\"btn fullBlue\" (click)=\"allocateItem()\" style=\"margin-top: 25px\">Allocate</button>\r\n          </div>\r\n        </div>\r\n\r\n        <h3>Item Allocation History</h3>\r\n        <div class=\"table-wrapper-user table-histrory\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>Date</th>\r\n                <th>Item</th>\r\n                <th>Category</th>\r\n                <th>Quantity</th>\r\n                <th>Action</th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr *ngFor=\"let s of inventoryAllocated\">\r\n                <td>{{s.created_date}}</td>\r\n                <td>{{s.item_name}}</td>\r\n                <td>{{s.category_name}}</td>\r\n                <td>{{s.alloted_units}}</td>\r\n                <td>\r\n                  <a (click)=\"deleteInventoryItem(s)\">Delete</a>\r\n                </td>\r\n              </tr>\r\n              <tr *ngIf=\"inventoryAllocated.length == 0\">\r\n                <td colspan=\"5\">\r\n                  No Item Allocated To User\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>"

/***/ }),

/***/ "./src/app/components/users-management/users/users.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.middle-section {\n  padding: 1%;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.align-txt-lft {\n  text-align: left;\n  font-size: 12px; }\n.align-number {\n  text-align: right;\n  font-size: 12px; }\n.psw-show {\n  font-size: 1.4em;\n  color: #0084f6; }\n.credentials-view {\n  text-align: left; }\n.btnWrapper .btn .tooltip {\n  position: relative;\n  top: -30px;\n  right: -30px;\n  min-width: 100px;\n  font-size: 12px;\n  padding: 6px;\n  height: 35px;\n  border-radius: 5px;\n  background: rgba(0, 0, 0, 0.541);\n  color: white;\n  visibility: hidden;\n  opacity: 0; }\n.btnWrapper .btn:hover .tooltip {\n  position: relative;\n  top: -20px;\n  right: 120px;\n  min-width: 100px;\n  padding: 6px;\n  border-radius: 5px;\n  font-size: 12px;\n  height: 30px;\n  background: rgba(0, 0, 0, 0.541);\n  color: white;\n  visibility: visible;\n  opacity: 1;\n  -webkit-transition: all 0.2s;\n  transition: all 0.2s; }\n.btnWrapper .btn:focus {\n  outline: none; }\n.btnWrapper .btn:active {\n  -webkit-box-shadow: none;\n          box-shadow: none; }\n.row {\n  margin: 0px 0px; }\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 65%;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n.spanText {\n  font-size: 12px; }\n.allocation-popup .filler-section {\n  margin-top: 10px;\n  margin-bottom: 10px; }\n.allocation-popup .table-histrory {\n  margin-top: 10px;\n  margin-bottom: 10px;\n  max-height: 280px;\n  overflow-x: hidden;\n  overflow-y: auto; }\n.content-container .user-table-wrapper {\n  margin-top: 10px; }\n.content-container .btn-group {\n  margin-top: 20px; }\n.content-container .btn-group button {\n    margin-right: 5px; }\n.search-filter-wrapper .normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  height: 32px;\n  font-size: 14px; }\n.search-filter-wrapper .field-wrapper {\n  position: relative;\n  padding-top: 0px !important;\n  width: 30%;\n  float: left !important; }\n.search-filter-wrapper .field-wrapper .form-ctrl {\n    height: 32px !important;\n    font: 400 12px 'Open sans',sans-serif;\n    border-top: none !important;\n    border-right: none !important;\n    border-left: none !important; }\n.search-filter-wrapper .field-wrapper label {\n  position: absolute !important;\n  left: 10% !important;\n  top: 1% !important;\n  font-weight: bold; }\n.search-filter-wrapper .field-wrapper label:after {\n    left: 85% !important;\n    top: 10px !important; }\n.action-menu a {\n  margin-right: 5px;\n  cursor: pointer; }\n"

/***/ }),

/***/ "./src/app/components/users-management/users/users.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UsersComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_user_management_user_service__ = __webpack_require__("./src/app/services/user-management/user.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var UsersComponent = /** @class */ (function () {
    function UsersComponent(apiService, toastCtrl, auth) {
        this.apiService = apiService;
        this.toastCtrl = toastCtrl;
        this.auth = auth;
        this.usersList = [];
        this.userListDataSource = [];
        this.isLangInstitute = false;
        this.dataFilter = {
            role: 0,
            is_active: true,
            is_show_credentials: false
        };
        this.allocateItemPopUp = false;
        this.tempdata = "";
        this.inventoryList = [];
        this.inventoryAllocated = [];
        this.allocateInventory = {
            item_id: -1,
            alloted_units: 1
        };
        this.showUnit = false;
        this.availableunit = 0;
        this.showUserTable = false;
        this.PageIndex = 1;
        this.displayBatchSize = 10;
        this.searchDataFlag = false;
        this.searchedData = [];
        this.totalRow = 0;
        this.userSelected = [];
        this.searchText = "";
        this.isRippleLoad = false;
        this.toottip = "We can customize our users via providing or assigning different roles according to their activities.User can login with their credentials and can operate only their defined roles.";
    }
    UsersComponent.prototype.ngOnInit = function () {
        this.checkInstituteType();
        this.getAllUserList();
        if (sessionStorage.getItem('permitted_roles')) {
            var permissions = Object.keys(JSON.parse(sessionStorage.getItem('permitted_roles')));
            if (permissions.includes('720')) {
                this.dataFilter.is_show_credentials = true;
            }
        }
    };
    UsersComponent.prototype.getAllUserList = function () {
        var _this = this;
        if (this.dataFilter.role == "-1") {
            this.messageNotifier('error', '', 'Please Select User Type');
            return;
        }
        this.PageIndex = 1;
        var Active = "";
        if (this.dataFilter.is_active) {
            Active = "Y";
        }
        else {
            Active = "N";
        }
        var obj = {
            is_not_alr_users: 'N',
            user_Type: this.dataFilter.role,
            app_downloaded: -1
        };
        this.searchText = "";
        this.searchDataFlag = false;
        this.isRippleLoad = true;
        this.apiService.getUserList(obj, Active).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.totalRow = res.length;
            _this.showUserTable = true;
            _this.userListDataSource = _this.addKeys(res, false);
            _this.fetchTableDataByPage(_this.PageIndex);
        }, function (err) {
            _this.isRippleLoad = false;
            _this.showUserTable = false;
            console.log(err);
            _this.messageNotifier('error', '', err.error.message);
        });
    };
    UsersComponent.prototype.clearData = function () {
        this.usersList = [];
        this.totalRow = 0;
        this.PageIndex = 1;
        this.userListDataSource = [];
    };
    UsersComponent.prototype.sendSmsForApp = function (type) {
        var _this = this;
        if (confirm('Are you sure you want to send SMS to selected users?')) {
            var data = {
                app_sms_type: type,
                userArray: this.getSelectedUser()
            };
            if (data.userArray.length == 0) {
                this.messageNotifier('error', '', 'Please select user');
                return;
            }
            this.apiService.sendSmS(data).subscribe(function (res) {
                _this.messageNotifier('success', 'Sent successfully', 'SMS Sent Successfully');
            }, function (err) {
                console.log(err);
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    UsersComponent.prototype.allocateItemToUser = function (data) {
        this.tempdata = data;
        this.getInventoryItemList(data);
        this.getAllocatedItemHistrory(data);
        this.allocateItemPopUp = true;
    };
    UsersComponent.prototype.closePopUp = function () {
        this.tempdata = "";
        this.allocateItemPopUp = false;
        this.showUnit = false;
        this.allocateInventory = {
            item_id: -1,
            alloted_units: 1
        };
    };
    UsersComponent.prototype.getInventoryItemList = function (data) {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getItemList(data.user_id).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.inventoryList = res;
        }, function (err) {
            _this.isRippleLoad = false;
            console.log(err);
        });
    };
    UsersComponent.prototype.getAllocatedItemHistrory = function (data) {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getAllotedHistroy(data.user_id).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.inventoryAllocated = res;
        }, function (err) {
            _this.isRippleLoad = false;
            console.log(err);
        });
    };
    UsersComponent.prototype.allocateItem = function () {
        var _this = this;
        if (this.allocateInventory.item_id == -1) {
            this.messageNotifier('error', '', 'Please prvide item details');
            return;
        }
        var unit = Number(this.allocateInventory.alloted_units);
        if (unit < 0) {
            this.messageNotifier('error', '', 'Please give valid unit');
            return;
        }
        if (this.availableunit < unit) {
            this.messageNotifier('error', '', 'Allocatd unit can not be greater than available unit');
            return;
        }
        var obj = {
            alloted_units: this.allocateInventory.alloted_units,
            item_id: this.allocateInventory.item_id,
            user_id: this.tempdata.user_id
        };
        this.isRippleLoad = true;
        this.apiService.allocateItem(obj).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.messageNotifier('success', 'Allocated', 'Inventory Allocate Successfully');
            _this.getAllocatedItemHistrory(_this.tempdata);
            _this.allocateInventory = {
                item_id: -1,
                alloted_units: 1
            };
            _this.showUnit = false;
        }, function (err) {
            _this.isRippleLoad = false;
            console.log(err);
        });
    };
    UsersComponent.prototype.onitemSelction = function () {
        if (this.allocateInventory.item_id != '-1') {
            this.showUnit = true;
            for (var i = 0; i < this.inventoryList.length; i++) {
                if (this.inventoryList[i].item_id == this.allocateInventory.item_id) {
                    this.availableunit = Number(this.inventoryList[i].available_units);
                }
            }
        }
        else {
            this.showUnit = false;
            this.availableunit = 0;
        }
    };
    UsersComponent.prototype.deleteInventoryItem = function (data) {
        var _this = this;
        if (confirm('Are you sure you want to delete?')) {
            this.isRippleLoad = true;
            this.apiService.deleteInventory(data.allocation_id).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.messageNotifier('success', 'Deleted', 'Item Deleted Successfully');
                _this.getAllocatedItemHistrory(_this.tempdata);
            }, function (err) {
                _this.isRippleLoad = false;
                console.log(err);
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    UsersComponent.prototype.descriptPassword = function (object) {
        object.isEncript = (!object.isEncript);
    };
    // pagination functions 
    UsersComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.usersList = this.getDataFromDataSource(startindex);
        this.usersList.forEach(function (element) {
            element.isEncript = true;
        });
    };
    UsersComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    UsersComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    UsersComponent.prototype.getDataFromDataSource = function (startindex) {
        var data = [];
        if (this.searchDataFlag == true) {
            data = this.searchedData.slice(startindex, startindex + this.displayBatchSize);
        }
        else {
            data = this.userListDataSource.slice(startindex, startindex + this.displayBatchSize);
        }
        return data;
    };
    UsersComponent.prototype.searchInList = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            var searchData = this.userListDataSource.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.searchedData = searchData;
            this.totalRow = searchData.length;
            this.searchDataFlag = true;
            this.PageIndex = 1;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchDataFlag = false;
            this.fetchTableDataByPage(this.PageIndex);
            this.totalRow = this.userListDataSource.length;
        }
    };
    UsersComponent.prototype.getSelectedUser = function () {
        var arr = [];
        for (var i = 0; i < this.userSelected.length; i++) {
            if (this.userSelected[i].assigned == true) {
                arr.push(this.userSelected[i].user_id);
            }
        }
        return arr;
    };
    UsersComponent.prototype.userSelectedEvent = function (event, data) {
        if (event.target.checked) {
            this.userSelected.push(data);
        }
        else {
            for (var i = 0; i < this.userSelected.length; i++) {
                if (this.userSelected[i].user_id == data.user_id) {
                    this.userSelected.splice(i, 1);
                }
            }
        }
    };
    UsersComponent.prototype.addKeys = function (data, val) {
        data.forEach(function (element) {
            element.assigned = val;
        });
        return data;
    };
    UsersComponent.prototype.checkInstituteType = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isLangInstitute = true;
            }
            else {
                _this.isLangInstitute = false;
            }
        });
    };
    UsersComponent.prototype.messageNotifier = function (type, title, msg) {
        var data = {
            type: type,
            title: title,
            body: msg
        };
        this.toastCtrl.popToast(data);
    };
    UsersComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-users',
            template: __webpack_require__("./src/app/components/users-management/users/users.component.html"),
            styles: [__webpack_require__("./src/app/components/users-management/users/users.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_user_management_user_service__["a" /* UserService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], UsersComponent);
    return UsersComponent;
}());



/***/ }),

/***/ "./src/app/components/users-management/users/users.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserModule", function() { return UserModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__users_component__ = __webpack_require__("./src/app/components/users-management/users/users.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__users_routing__ = __webpack_require__("./src/app/components/users-management/users/users.routing.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_user_management_user_service__ = __webpack_require__("./src/app/services/user-management/user.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__add_edit_user_add_edit_user_component__ = __webpack_require__("./src/app/components/users-management/users/add-edit-user/add-edit-user.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var UserModule = /** @class */ (function () {
    function UserModule() {
    }
    UserModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            declarations: [
                __WEBPACK_IMPORTED_MODULE_3__users_component__["a" /* UsersComponent */],
                __WEBPACK_IMPORTED_MODULE_8__add_edit_user_add_edit_user_component__["a" /* AddEditUserComponent */],
            ],
            exports: [],
            imports: [
                __WEBPACK_IMPORTED_MODULE_4_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_6__users_routing__["a" /* UserRouting */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_7__services_user_management_user_service__["a" /* UserService */]
            ]
        })
    ], UserModule);
    return UserModule;
}());



/***/ }),

/***/ "./src/app/components/users-management/users/users.routing.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserRouting; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__users_component__ = __webpack_require__("./src/app/components/users-management/users/users.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__add_edit_user_add_edit_user_component__ = __webpack_require__("./src/app/components/users-management/users/add-edit-user/add-edit-user.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var UserRouting = /** @class */ (function () {
    function UserRouting() {
    }
    UserRouting = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__users_component__["a" /* UsersComponent */],
                        pathMatch: 'prefix',
                    },
                    {
                        path: 'addedit',
                        component: __WEBPACK_IMPORTED_MODULE_3__add_edit_user_add_edit_user_component__["a" /* AddEditUserComponent */]
                    },
                    {
                        path: 'addedit/:id',
                        component: __WEBPACK_IMPORTED_MODULE_3__add_edit_user_add_edit_user_component__["a" /* AddEditUserComponent */]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], UserRouting);
    return UserRouting;
}());



/***/ })

});
//# sourceMappingURL=users.module.chunk.js.map