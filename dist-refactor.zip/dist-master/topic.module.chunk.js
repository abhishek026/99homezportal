webpackJsonp(["topic.module"],{

/***/ "./src/app/components/course-module/create-course/topic/topic-list/topic-list.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n  <div class=\"col-md-12 subject-wrapper\">\r\n    <div class=\"subject-item\" *ngFor=\"let topic of dataList;\">\r\n      <div class=\"subject-label row border-radius-0\">\r\n        <div class=\"col-md-4\">\r\n          <i class=\"fa fa-chevron-down \" (click)=\"toggleObject(topic)\" *ngIf=\"topic.subTopic.length && topic.isExpand\"></i>\r\n          <i class=\"fa fa-chevron-up \" (click)=\"toggleObject(topic)\" *ngIf=\"topic.subTopic.length && (!topic.isExpand)\"></i>\r\n          &nbsp; {{topic.topicName}}\r\n        </div>\r\n        <div class=\"col-md-4\">\r\n          <span style=\"font-weight: 600;\">Est. Time :</span> &nbsp; {{topic.estimated_time}}\r\n        </div>\r\n        <div class=\"pull-right\">\r\n          <i class=\"fa fa-plus-circle btn_action pad_icon\" (click)=\"addSubtopic(topic)\" title=\"Add subTopic \" aria-hidden=\"true\"></i>\r\n          <i class=\"fa fa-pencil btn_action pad_icon\" (click)=\"eventAction('Edit',topic)\" title=\"Edit\"></i>\r\n          <i class=\"fa fa-trash-o btn_delete pad_icon\" (click)=\"eventAction('Delete',topic)\" title=\"Delete\"></i>\r\n        </div>\r\n\r\n        <div class=\"row col-md-12 p-0\" *ngIf=\"topic.isExpand\">\r\n          <div class=\"col-md-12 topic-material-data\">\r\n            <ng-container *ngTemplateOutlet=\"recursiveAddNodes; context:{$implicit: topic.addSubtopic,topic:topic, level: 1}\"></ng-container>\r\n            <ng-container *ngTemplateOutlet=\"recursiveNodes; context:{$implicit: topic.subTopic, level: 1}\"></ng-container>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <ng-template #recursiveAddNodes let-addSubtopic  let-topicData=\"topic\" let-level=\"level\">\r\n    <div class=\"row topic-row\" style=\"padding: 1em 0em 0em .6em;\" *ngFor=\"let topic of addSubtopic\">\r\n      <div [class]=\"'subject-label row'\" style=\"border: 1px solid #0080f6; padding: 0.3em 0em;\">\r\n        <div class=\"col-md-4\">\r\n          <div class=\"dropdown-div\">\r\n            <input class=\"dropdown\" [(ngModel)]=\"topic.name\" placeholder=\"enter subtopic name\" type=\"text\">\r\n          </div>\r\n        </div>\r\n        <div class=\"col-md-4\"></div>\r\n        <div class=\"pull-right\" style=\" padding-right: 1em;\">\r\n          <button class=\"btn\" [disabled]=\"disableAddBtn\" (click)=\"addEditSubtopicDetails(topic,'Subtopic')\" style=\"padding: 0px 7px; font-size: 12px; height: 25px;\">\r\n            <i class=\"fa fa-plus\" style=\"padding: 0px 5px\" aria-hidden=\"true\"></i>Add</button>\r\n          <button class=\"btn_delete\">\r\n            <i aria-hidden=\"true\" (click)=\"cancelAdd(topicData)\" class=\"fa fa-times-circle delete_icon\"  title=\"Cancel\"></i>\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </ng-template>\r\n\r\n  <ng-template #recursiveNodes let-subTopics let-level=\"level\">\r\n    <div class=\"row topic-row\" style=\"padding: 1em 0em 0em .6em;\" *ngFor=\"let topic of subTopics\">\r\n      <div [class]=\"'subject-label row border-radius-'+level\" *ngIf=\"!topic.isEdit\">\r\n        <div class=\"col-md-4\">\r\n          <i class=\"fa fa-chevron-down \" (click)=\"toggleObject(topic)\" *ngIf=\"topic.subTopic.length && topic.isExpand\"></i>\r\n          <i class=\"fa fa-chevron-up \" (click)=\"toggleObject(topic)\" *ngIf=\"topic.subTopic.length && (!topic.isExpand)\"></i>\r\n          &nbsp; {{topic.topicName}}\r\n        </div>\r\n        <div class=\"col-md-4\"></div>\r\n        <div class=\"pull-right\">\r\n          <i class=\"fa fa-plus-circle btn_action pad_icon\" (click)=\"addSubtopic(topic)\" title=\"Add subTopic \" aria-hidden=\"true\"></i>\r\n          <i class=\"fa fa-pencil btn_action pad_icon\" (click)=\"EditSubtopic(topic)\" title=\"Update Topic\"></i>\r\n          <i class=\"fa fa-trash-o btn_delete pad_icon\" (click)=\"eventAction('Delete',topic)\" title=\"Delete Topic\"></i>\r\n        </div>\r\n        <div class=\"row col-md-12 p-0\" *ngIf=\"topic.isExpand\">\r\n          <div class=\"col-md-12 topic-material-data\">\r\n            <ng-container *ngTemplateOutlet=\"recursiveAddNodes; context:{$implicit: topic.addSubtopic, topic:topic,level: level+1}\"></ng-container>\r\n            <ng-container *ngTemplateOutlet=\"recursiveNodes; context:{$implicit: topic.subTopic, level: level+1 }\"></ng-container>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"row topic-row\" style=\"padding: 1em 0em 0em .6em;\" *ngIf=\"topic.isEdit\">\r\n        <div [class]=\"'subject-label row'\" style=\"border: 1px solid #0080f6;    padding: 0.3em 0em;\">\r\n          <div class=\"col-md-4\">\r\n            <div class=\"dropdown-div\">\r\n              <input class=\"dropdown\" [(ngModel)]=\"topic.name\" placeholder=\"  Enter Subbtopic Name\" type=\"text\">\r\n            </div>\r\n          </div>\r\n          <div class=\"col-md-4\"></div>\r\n          <div class=\"pull-right\" style=\" padding-right: 1em;\">\r\n            <button class=\"btn\" (click)=\"addEditSubtopicDetails(topic,'EditSubtopic')\" style=\"padding: 0px 7px; font-size: 12px; height: 25px;\">\r\n              Update</button>\r\n            <button class=\"btn\" (click)=\"clearObject(topic)\" style=\"padding: 0px 7px; font-size: 12px; height: 25px;\">\r\n              Cancel</button>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </ng-template>"

/***/ }),

/***/ "./src/app/components/course-module/create-course/topic/topic-list/topic-list.component.scss":
/***/ (function(module, exports) {

module.exports = ".subject-wrapper .subject-item {\n  padding: 0.6em; }\n  .subject-wrapper .subject-item .subject-label {\n    margin: 0px;\n    cursor: pointer;\n    padding: 0.6em 1em;\n    font-weight: bold;\n    border-radius: 6px;\n    font-size: 0.95em;\n    border: 1pt solid #eee;\n    background-color: #fff;\n    border-left: 3pt solid #0084f6;\n    -webkit-box-shadow: 0 1pt 2pt 0 rgba(0, 0, 0, 0.16);\n            box-shadow: 0 1pt 2pt 0 rgba(0, 0, 0, 0.16); }\n  .subject-wrapper .subject-item .border-radius-0 {\n    border-left: 3pt solid #0084f6; }\n  .subject-wrapper .subject-item .border-radius-1 {\n    border-left: 3pt solid #ff9100; }\n  .subject-wrapper .subject-item .border-radius-2 {\n    border-left: 3pt solid  #e75480; }\n  .subject-wrapper .subject-item .border-radius-3 {\n    border-left: 3pt solid #fa3145; }\n  .subject-title {\n  cursor: pointer;\n  font-weight: 900;\n  font-size: 1.4em;\n  margin-bottom: 0.4em; }\n  .pad_icon {\n  padding: 0 10px; }\n  .btn_action {\n  color: #1283f4;\n  font-size: 1.2em; }\n  .btn_delete {\n  color: #fa3145;\n  font-size: 1.2em; }\n  .col-md-12 {\n  padding-right: 0px;\n  padding-left: 0px; }\n  .row {\n  margin-right: 0px;\n  margin-left: 0px; }\n  .dropdown {\n  width: 100%;\n  height: 30px;\n  border: 1px solid #ddd;\n  border-radius: 4px; }\n  .btn_delete {\n  padding: 1px 7px;\n  background: white; }\n  .btn_delete .delete_icon {\n    color: red;\n    font-size: 1.1rem; }\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/topic/topic-list/topic-list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TopicListComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__topic_model__ = __webpack_require__("./src/app/components/course-module/create-course/topic/topic.model.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var TopicListComponent = /** @class */ (function () {
    function TopicListComponent(_toastPopup) {
        this._toastPopup = _toastPopup;
        this.eventHandler = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.editView = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.disableAddBtn = false;
    }
    TopicListComponent.prototype.ngOnInit = function () {
    };
    TopicListComponent.prototype.toggleObject = function (topic) {
        topic.isExpand = (!topic.isExpand);
        if (topic.isExpand) {
            this.expandAllTopic(topic);
        }
    };
    TopicListComponent.prototype.expandAllTopic = function (topic) {
        var _this = this;
        if (topic.subTopic.length == 0) {
            return;
        }
        else {
            topic.subTopic.forEach(function (object) {
                object.isExpand = true;
                if (object.subTopic.length > 0) {
                    _this.expandAllTopic(object);
                }
            });
        }
    };
    TopicListComponent.prototype.addSubtopic = function (topic) {
        topic.addSubtopic = topic.addSubtopic == undefined ? [] : topic.addSubtopic;
        if (!topic.addSubtopic.length) {
            topic.addSubtopic = [];
            topic.isExpand = true;
            var object_topic = new __WEBPACK_IMPORTED_MODULE_1__topic_model__["a" /* Create_Topic */]();
            object_topic.parent_topic_id = topic.topicId;
            object_topic.estimated_time = topic.estimated_time;
            topic.addSubtopic.push(object_topic);
        }
        else {
            topic.addSubtopic = [];
        }
    };
    TopicListComponent.prototype.cancelAdd = function (parentTopic) {
        // console.log(parentTopic);
        parentTopic.addSubtopic = [];
    };
    TopicListComponent.prototype.addEditSubtopicDetails = function (topic, type) {
        this.disableAddBtn = true;
        if (topic.name == "") {
            this._toastPopup.showErrorMessage('error', '', "please add subtopic name");
            this.disableAddBtn = false;
            return;
        }
        this.eventAction(type, topic);
    };
    TopicListComponent.prototype.eventAction = function (type, topic) {
        this.editView.emit({ 'data': topic, option: type });
        this.disableAddBtn = false;
        // console.log(topic);
    };
    TopicListComponent.prototype.clearObject = function (topic) {
        // console.log(topic);
        topic.name = topic.topicName;
        topic.isEdit = (!topic.isEdit);
    };
    TopicListComponent.prototype.EditSubtopic = function (topic) {
        topic.isEdit = !(topic.isEdit);
        topic.name = topic.topicName;
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], TopicListComponent.prototype, "dataList", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], TopicListComponent.prototype, "eventHandler", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], TopicListComponent.prototype, "editView", void 0);
    TopicListComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-topic-list',
            template: __webpack_require__("./src/app/components/course-module/create-course/topic/topic-list/topic-list.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/create-course/topic/topic-list/topic-list.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_message_show_service__["a" /* MessageShowService */]])
    ], TopicListComponent);
    return TopicListComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/topic/topic-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TopicRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__topic_tree_topic_tree_component__ = __webpack_require__("./src/app/components/course-module/create-course/topic/topic-tree/topic-tree.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [{
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__topic_tree_topic_tree_component__["a" /* TopicTreeComponent */],
        pathMatch: 'prefix',
        children: []
    }];
var TopicRoutingModule = /** @class */ (function () {
    function TopicRoutingModule() {
    }
    TopicRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]]
        })
    ], TopicRoutingModule);
    return TopicRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/topic/topic-tree/topic-tree.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"topic_details\">\r\n  <div class=\"topic_filter_div\">\r\n    <div class=\"topic_title\">Topic</div>\r\n  </div>\r\n  <div class=\"filter_div\">\r\n    <div class=\"field-wrapper\">\r\n      <label *ngIf=\"!isProfessional\">Standard<span class=\"text-danger\">*</span></label>\r\n      <label *ngIf=\"isProfessional\">Master Course<span class=\"text-danger\">*</span></label>\r\n      <div class=\"dropdown-div\">\r\n        <select class=\"dropdown\" [(ngModel)]=\"filterData.standard_id\" (change)=\"getAllSubjectListFromServer($event.target.value)\"> \r\n          <option value=\"-1\"></option>\r\n            <option *ngFor=\"let standard of standardData;let i=index; \" [value]=\"standard.standard_id\">{{standard.standard_name}}</option>\r\n        </select>\r\n      </div>\r\n    </div>\r\n    <div class=\"field-wrapper\">\r\n      <label *ngIf=\"!isProfessional\">Subject<span class=\"text-danger\">*</span></label>\r\n      <label *ngIf=\"isProfessional\">Course<span class=\"text-danger\">*</span></label>\r\n      <div class=\"dropdown-div\">\r\n        <select class=\"dropdown\" [(ngModel)]=\"filterData.subject_id\">\r\n            <option value=\"-1\"></option>\r\n          <option *ngFor=\"let subject of subjectData;let i=index; \" [value]=\"subject.subject_id\">{{subject.subject_name}}</option>\r\n        </select>\r\n      </div>\r\n    </div>\r\n    <button class=\"btn fullBlue\" style=\"margin-bottom: 5px;\" [disabled]=\"(filterData.standard_id==-1) || (filterData.subject_id==-1)\" (click)=\"getTopicDetails('view')\" >View</button>  \r\n    <button class=\"btn fullBlue pull-right\" style=\"margin-top: 18px;\" data-backdrop=\"static\" data-toggle=\"modal\" data-target=\"#addTopic\">\r\n      <i class=\"fa fa-plus\" aria-hidden=\"true\" (click)=\"clearObject()\"></i>&nbsp; Add Topic</button>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"topic_details_view\">\r\n    <app-topic-list [dataList]=\"subjectList\" (editView)=\"eventAction($event)\"></app-topic-list>\r\n</div>\r\n\r\n\r\n<!-- Modal -->\r\n<div class=\"modal topic-add-model\" id=\"addTopic\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">\r\n  <div class=\"modal-dialog\" role=\"document\">\r\n    <div class=\"modal-content\">\r\n      <div class=\"modal-header\">\r\n        <h2 class=\"modal-title\" id=\"addTopic\" *ngIf=\"option_type=='Add'\">Create New Topic</h2>\r\n        <h2 class=\"modal-title\" id=\"addTopic\" *ngIf=\"option_type=='Edit'\">Update Topic</h2>\r\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Cancel\" (click)=\"clearObject()\">\r\n          <span aria-hidden=\"true\">&times;</span>\r\n        </button>\r\n      </div>\r\n      <div class=\"modal-body\">\r\n        <div class=\"model_body_div\">\r\n          <div class=\"field-wrapper\">\r\n            <label *ngIf=\"!isProfessional\">Standard Name<span class=\"text-danger\">*</span></label>\r\n            <label *ngIf=\"isProfessional\">Master Course<span class=\"text-danger\">*</span></label>\r\n            <div class=\"dropdown-div\">\r\n              <select class=\"dropdown\" [(ngModel)]=\"addTopic.standard_id\" (change)=\"getAllSubjectList($event.target.value)\">\r\n                <option value=\"-1\">   Select Standard </option>\r\n                <option *ngFor=\"let standard of standardData;let i=index; \" [value]=\"standard.standard_id\">{{standard.standard_name}}</option>\r\n              </select>\r\n            </div>\r\n          </div>\r\n          <div class=\"field-wrapper\">\r\n            <label *ngIf=\"!isProfessional\">Subject Name<span class=\"text-danger\">*</span></label>\r\n            <label *ngIf=\"isProfessional\">Course<span class=\"text-danger\">*</span></label>\r\n            <div class=\"dropdown-div\">\r\n              <select class=\"dropdown\"  [(ngModel)]=\"addTopic.subject_id\">\r\n                <option value=\"-1\"> Select Subject </option>\r\n                <option *ngFor=\"let subject of subjectTempData;let i=index; \" [value]=\"subject.subject_id\">{{subject.subject_name}}</option>\r\n              </select>\r\n            </div>\r\n          </div>\r\n          <div class=\"field-wrapper\">\r\n            <label>Topic Name <span class=\"text-danger\">*</span></label>\r\n            <div class=\"dropdown-div\">\r\n                <input class=\"dropdown\" [(ngModel)]=\"addTopic.name\" type=\"text\" placeholder=\"  Enter Topic Name\" />\r\n            </div>\r\n          </div>\r\n          <div class=\"field-wrapper\">\r\n            <label>Duration (only minutes)</label>\r\n            <div class=\"dropdown-div\">\r\n              <input class=\"dropdown\" maxlength=\"3\" onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" [(ngModel)]=\"addTopic.estimated_time\" type=\"text\" placeholder=\"  Enter Estimated Time\" />\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"modal-footer\">\r\n        <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\" (click)=\"clearObject()\">Cancel</button>\r\n        <button type=\"button\" class=\"btn btn-primary fullBlue\" *ngIf=\"option_type=='Add'\" [disabled]=\"(addTopic.name=='') ||(addTopic.standard_id==-1) || (addTopic.subject_id==-1)\" (click)=\"Add_New_Topic_Details()\">Save </button>\r\n        <button type=\"button\" class=\"btn btn-primary fullBlue\" *ngIf=\"option_type=='Edit'\" [disabled]=\"(addTopic.name=='') ||(addTopic.standard_id==-1) || (addTopic.subject_id==-1)\" (click)=\"Update_Topic_Details('edit',null)\">Update </button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<!-- Delete Modal -->\r\n<div class=\"modal topic-add-model\" style=\"position: fixed; top: 16em;\" id=\"DeleteTopic\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">\r\n  <div class=\"modal-dialog\" role=\"document\">\r\n    <div class=\"modal-content\" style=\"padding: 1em;\">\r\n      <div class=\"modal-body\">\r\n        <div class=\"model_body_div\">\r\n            Are you sure, you want to delete this topic?\r\n         </div>\r\n      </div>\r\n      <div class=\"modal-footer\">\r\n        <button type=\"button\" class=\"btn\" style=\"color: indianred;\" [disabled]=\"disableDeleteBtn\" (click)=\"deleteTopicObject()\">Delete </button>\r\n        <button type=\"button\" class=\"btn\" data-dismiss=\"modal\" (click)=\"clearObject()\">Cancel</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/topic/topic-tree/topic-tree.component.scss":
/***/ (function(module, exports) {

module.exports = ".btn {\n  font-size: 12px;\n  height: 30px;\n  padding: 1px 12px; }\n\n.topic_details {\n  padding: .6em; }\n\n.topic_details .topic_filter_div {\n    padding-bottom: 1rem; }\n\n.topic_details .topic_filter_div .topic_title {\n      font-size: 14px;\n      font-weight: 600; }\n\n.topic_details .filter_div {\n    background: #ddd;\n    padding: 1rem; }\n\n.topic_details .filter_div .field-wrapper {\n      margin-left: 20px;\n      padding-top: 0;\n      display: inline-block; }\n\n.topic_details .filter_div .dropdown-div {\n      width: 160px; }\n\n.topic_details .filter_div .dropdown-div .dropdown {\n        width: 100%;\n        height: 30px;\n        border: 1px solid #ddd;\n        border-radius: 4px; }\n\n.topic_details_view {\n  padding: .6em; }\n\n.topic-add-model .modal-dialog {\n  width: 350px; }\n\n.topic-add-model .modal-dialog .modal-header {\n    padding: 15px 15px 1px;\n    font-size: 14px; }\n\n.topic-add-model .modal-dialog .modal-header .close {\n      margin-bottom: -20px;\n      position: relative;\n      top: -1.0em;\n      font-size: 30px; }\n\n.topic-add-model .modal-dialog .modal-body {\n    padding-top: 0px; }\n\n.topic-add-model .modal-dialog .modal-body .model_body_div .field-wrapper label {\n      color: #3e3d4a;\n      font-weight: 600; }\n\n.topic-add-model .modal-dialog .modal-body .model_body_div .field-wrapper .dropdown-div .dropdown {\n      width: 100%;\n      height: 30px;\n      border: 1px solid #ddd;\n      border-radius: 4px; }\n\n::-webkit-input-placeholder {\n  color: #ddd;\n  opacity: 1;\n  /* Firefox */ }\n\n:-ms-input-placeholder {\n  color: #ddd;\n  opacity: 1;\n  /* Firefox */ }\n\n::-ms-input-placeholder {\n  color: #ddd;\n  opacity: 1;\n  /* Firefox */ }\n\n::placeholder {\n  color: #ddd;\n  opacity: 1;\n  /* Firefox */ }\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/topic/topic-tree/topic-tree.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TopicTreeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__topic_model__ = __webpack_require__("./src/app/components/course-module/create-course/topic/topic.model.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_http_service__ = __webpack_require__("./src/app/services/http.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





/**
 * created by laxmi
 */
var TopicTreeComponent = /** @class */ (function () {
    function TopicTreeComponent(_http, auth, _toastPopup) {
        var _this = this;
        this._http = _http;
        this.auth = auth;
        this._toastPopup = _toastPopup;
        this.isRippleLoad = false;
        this.isProfessional = false;
        this.option_type = 'Add';
        this.subjectData = [];
        this.subjectTempData = [];
        this.standardData = [];
        this.subjectList = [];
        this.teacher_id = -1;
        this.addTopic = new __WEBPACK_IMPORTED_MODULE_1__topic_model__["a" /* Create_Topic */]();
        this.disableDeleteBtn = false;
        this.filterData = {
            standard_id: -1,
            subject_id: -1
        };
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        console.log('model typ:', this.isProfessional);
    }
    TopicTreeComponent.prototype.ngOnInit = function () {
        var userType = sessionStorage.getItem('userType');
        if (userType == 3) {
            this.teacher_id = sessionStorage.getItem('login_teacher_id');
        }
        this.getAllStandards();
    };
    TopicTreeComponent.prototype.getAllSubjectList = function (standards_id) {
        var _this = this;
        this.subjectTempData = [];
        this.isRippleLoad = true;
        var url = "/api/v1/subjects/standards/" + standards_id + '?active=Y';
        this._http.getData(url).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.subjectTempData = data;
            console.log(data);
        }, function (error) {
            _this.isRippleLoad = false;
            console.log(error);
        });
    };
    // get subject
    TopicTreeComponent.prototype.getAllSubjectListFromServer = function (standards_id) {
        var _this = this;
        this.subjectData = [];
        this.subjectList = [];
        this.filterData.subject_id = -1;
        this.isRippleLoad = true;
        var url = "/api/v1/subjects/standards/" + standards_id + '?active=Y';
        this._http.getData(url).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.subjectData = data;
            console.log(data);
        }, function (error) {
            _this.isRippleLoad = false;
            console.log(error);
        });
    };
    //
    TopicTreeComponent.prototype.Update_Topic_Details = function (type, editObejct) {
        var _this = this;
        var object = type == 'edit' ? this.addTopic : editObejct;
        this.isRippleLoad = true;
        var url = "/api/v1/topic_manager/update/" + this.institute_id;
        this._http.putData(url, object).subscribe(function (res) {
            _this.isRippleLoad = false;
            if (res.statusCode == 200) {
                console.log(res);
                _this.addTopic = new __WEBPACK_IMPORTED_MODULE_1__topic_model__["a" /* Create_Topic */]();
                _this.option_type = 'Add';
                $('#addTopic').modal('hide');
                _this._toastPopup.showErrorMessage('success', '', "Topic Updated Successfully");
                _this.getTopicDetails(null);
            }
            else {
                _this._toastPopup.showErrorMessage('error', '', "something went wrong please try again");
            }
        }, function (error) {
            _this.isRippleLoad = false;
            console.log(error);
            _this._toastPopup.showErrorMessage('error', '', "something went wrong please try again");
        });
    };
    // get standard
    TopicTreeComponent.prototype.getAllStandards = function () {
        var _this = this;
        var url = "/api/v1/standards/all/" + this.institute_id + "?active=Y" + '&teacher_id=' + this.teacher_id;
        this.isRippleLoad = true;
        this._http.getData(url).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.standardData = data;
            // console.log(data);
        }, function (error) {
            _this.isRippleLoad = false;
            console.log(error);
        });
    };
    TopicTreeComponent.prototype.clearObject = function () {
        this.addTopic = new __WEBPACK_IMPORTED_MODULE_1__topic_model__["a" /* Create_Topic */]();
        this.option_type = 'Add';
    };
    TopicTreeComponent.prototype.clearFilter = function () {
        this.filterData = {
            standard_id: -1,
            subject_id: -1
        };
    };
    /**
     * eventaction edit and delete option
     * @param $event
     */
    TopicTreeComponent.prototype.eventAction = function ($event) {
        var _this = this;
        console.log($event);
        switch ($event.option) {
            case 'Edit': {
                this.editTopicDetails($event.data);
                break;
            }
            case 'EditSubtopic': {
                var object = {
                    "name": $event.data.name,
                    "parent_topic_id": $event.data.parentTopicId,
                    "institute_topic_id": $event.data.topicId,
                    "description": $event.data.description
                };
                this.Update_Topic_Details('EditSubtopic', object);
                break;
            }
            case 'Delete': {
                this.temp_object = $event.data;
                $('#DeleteTopic').modal('show');
                break;
            }
            case 'Subtopic': {
                this.isRippleLoad = true;
                var object = $event.data;
                object.subject_id = this.filterData.subject_id;
                object.standard_id = this.filterData.standard_id;
                // this.isRippleLoad = true;
                var url = "/api/v1/topic_manager/add/" + this.institute_id;
                this._http.postData(url, object).subscribe(function (data) {
                    _this.isRippleLoad = false;
                    _this._toastPopup.showErrorMessage('success', '', "Subtopic added successfully");
                    if ((_this.filterData.standard_id != -1) && (_this.filterData.subject_id != -1)) {
                        _this.getTopicDetails(null);
                    }
                }, function (error) {
                    _this.isRippleLoad = false;
                    _this._toastPopup.showErrorMessage('error', '', error.error.message);
                    console.log(error);
                });
            }
        }
    };
    //delete object
    TopicTreeComponent.prototype.deleteTopicObject = function () {
        var _this = this;
        this.disableDeleteBtn = true;
        var url = "/api/v1/topic_manager/" + this.institute_id + "/" + this.temp_object.topicId;
        this._http.deleteData(url, null).subscribe(function (res) {
            _this.isRippleLoad = false;
            $('#DeleteTopic').modal('hide');
            _this._toastPopup.showErrorMessage('success', '', "Topic Deleted Successfully");
            _this.getTopicDetails(null);
            _this.disableDeleteBtn = false;
        }, function (err) {
            _this.isRippleLoad = false;
            console.log(err);
            _this._toastPopup.showErrorMessage('error', '', err.error.message);
            _this.disableDeleteBtn = false;
        });
    };
    //edit object
    TopicTreeComponent.prototype.editTopicDetails = function (data) {
        var _this = this;
        this.isRippleLoad = true;
        var url = "/api/v1/topic_manager/getTopic/" + this.institute_id + "/" + data.topicId;
        this._http.getData(url).subscribe(function (data) {
            _this.isRippleLoad = false;
            console.log(data);
            if (data) {
                _this.addTopic = new __WEBPACK_IMPORTED_MODULE_1__topic_model__["a" /* Create_Topic */]();
                _this.addTopic = data;
                _this.getAllSubjectList(data.standard_id);
                _this.option_type = 'Edit';
                $('#addTopic').modal('show');
            }
            else {
                _this._toastPopup.showErrorMessage('error', '', "something went wrong please try again");
            }
        }, function (err) {
            _this.isRippleLoad = false;
            console.log(err);
            _this._toastPopup.showErrorMessage('error', '', err.error.message);
        });
    };
    // add topic
    TopicTreeComponent.prototype.Add_New_Topic_Details = function () {
        var _this = this;
        this.isRippleLoad = true;
        var url = "/api/v1/topic_manager/add/" + this.institute_id;
        this._http.postData(url, this.addTopic).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.addTopic = new __WEBPACK_IMPORTED_MODULE_1__topic_model__["a" /* Create_Topic */]();
            _this._toastPopup.showErrorMessage('success', '', "Topic Added Successfully");
            $('#addTopic').modal('hide');
            if ((_this.filterData.standard_id != -1) && (_this.filterData.subject_id != -1)) {
                _this.getTopicDetails('view');
            }
            console.log(data);
        }, function (error) {
            _this.isRippleLoad = false;
            _this._toastPopup.showErrorMessage('error', '', "Something went wrong try again ");
            console.log(error);
        });
    };
    TopicTreeComponent.prototype.getTopicDetails = function (type) {
        var _this = this;
        if (this.filterData.standard_id == -1) {
            this._toastPopup.showErrorMessage('error', '', "Select the standard");
            return;
        }
        if (this.filterData.subject_id == -1) {
            this._toastPopup.showErrorMessage('error', '', "Select the subject");
            return;
        }
        this.isRippleLoad = true;
        var url = "/api/v1/topic_manager/standards/" + this.filterData.standard_id + "/subjects/" + this.filterData.subject_id + "/topics";
        this._http.getData(url).subscribe(function (data) {
            _this.isRippleLoad = false;
            if (data) {
                if (type == 'view') {
                    _this.subjectList = data;
                    _this.subjectList.forEach(function (object) {
                        object.addSubtopic = [];
                    });
                }
                else {
                    for (var i = 0; i < data.length; i++) {
                        data[i].isExpand = _this.subjectList[i].isExpand;
                        if (_this.subjectList[i].addSubtopic[0]) {
                            var object = _this.subjectList[i].addSubtopic[0];
                            object.name = object && object.name ? '' : '';
                            data[i].addSubtopic = _this.subjectList[i].addSubtopic;
                        }
                        else {
                            data[i].addSubtopic = [];
                        }
                        _this.expandAllTopic(data[i], _this.subjectList[i]);
                    }
                    _this.subjectList = data;
                }
            }
            if (!data.length || data == null) {
                _this._toastPopup.showErrorMessage('info', '', 'No topics linked');
            }
        }, function (error) {
            _this.isRippleLoad = false;
            console.log(error);
        });
    };
    TopicTreeComponent.prototype.expandAllTopic = function (topic, subjectList) {
        if (topic.subTopic.length == 0) {
            return;
        }
        else {
            for (var i = 0; i < topic.subTopic.length; i++) {
                var object = topic.subTopic[i];
                var subject = subjectList != undefined ? subjectList.subTopic[i] : '';
                object.addSubtopic = subject && subject.addSubtopic ? subject.addSubtopic : [];
                if (subject && subject.addSubtopic && subject.addSubtopic[0]) {
                    var add_sub_object = subject.addSubtopic[0];
                    add_sub_object.name = add_sub_object && add_sub_object.name ? '' : '';
                    object.addSubtopic = subject.addSubtopic;
                }
                else {
                    object.addSubtopic = [];
                }
                object.isExpand = subject && subject.isExpand;
                if (object.subTopic.length > 0) {
                    this.expandAllTopic(object, subject);
                }
            }
        }
    };
    TopicTreeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-topic-tree',
            template: __webpack_require__("./src/app/components/course-module/create-course/topic/topic-tree/topic-tree.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/create-course/topic/topic-tree/topic-tree.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_http_service__["a" /* HttpService */],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__services_message_show_service__["a" /* MessageShowService */]])
    ], TopicTreeComponent);
    return TopicTreeComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/topic/topic.model.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export Topic */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Create_Topic; });
var Topic = /** @class */ (function () {
    function Topic() {
        this.isEdit = false;
        this.isExpand = false;
    }
    return Topic;
}());

var Create_Topic = /** @class */ (function () {
    function Create_Topic() {
        this.name = '';
        this.standard_id = '-1';
        this.subject_id = '-1';
        this.parent_topic_id = '-1';
        this.description = '';
        this.estimated_time = 0;
        this.institute_topic_id = '-1';
    }
    return Create_Topic;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/topic/topic.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopicModule", function() { return TopicModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__topic_routing_module__ = __webpack_require__("./src/app/components/course-module/create-course/topic/topic-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__topic_list_topic_list_component__ = __webpack_require__("./src/app/components/course-module/create-course/topic/topic-list/topic-list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__topic_tree_topic_tree_component__ = __webpack_require__("./src/app/components/course-module/create-course/topic/topic-tree/topic-tree.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__node_modules_angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var TopicModule = /** @class */ (function () {
    function TopicModule() {
    }
    TopicModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_2__topic_routing_module__["a" /* TopicRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_6__node_modules_angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__["a" /* SharedModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_3__topic_list_topic_list_component__["a" /* TopicListComponent */],
                __WEBPACK_IMPORTED_MODULE_4__topic_tree_topic_tree_component__["a" /* TopicTreeComponent */]
            ]
        })
    ], TopicModule);
    return TopicModule;
}());



/***/ })

});
//# sourceMappingURL=topic.module.chunk.js.map