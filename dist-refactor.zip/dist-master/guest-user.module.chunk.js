webpackJsonp(["guest-user.module"],{

/***/ "./src/app/components/guest-user/guest-user-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return GuestUserRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__guest_user_component__ = __webpack_require__("./src/app/components/guest-user/guest-user.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__register_register_component__ = __webpack_require__("./src/app/components/guest-user/register/register.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__guest_user_component__["a" /* GuestUserComponent */],
        pathMatch: 'prefix',
        children: [
            {
                path: 'register',
                component: __WEBPACK_IMPORTED_MODULE_3__register_register_component__["a" /* RegisterComponent */],
                pathMatch: 'prefix',
            }
        ]
    }
];
var GuestUserRoutingModule = /** @class */ (function () {
    function GuestUserRoutingModule() {
    }
    GuestUserRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]]
        })
    ], GuestUserRoutingModule);
    return GuestUserRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/guest-user/guest-user.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet>\r\n</router-outlet>\r\n"

/***/ }),

/***/ "./src/app/components/guest-user/guest-user.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/guest-user/guest-user.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return GuestUserComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var GuestUserComponent = /** @class */ (function () {
    function GuestUserComponent() {
    }
    GuestUserComponent.prototype.ngOnInit = function () {
    };
    GuestUserComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-guest-user',
            template: __webpack_require__("./src/app/components/guest-user/guest-user.component.html"),
            styles: [__webpack_require__("./src/app/components/guest-user/guest-user.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], GuestUserComponent);
    return GuestUserComponent;
}());



/***/ }),

/***/ "./src/app/components/guest-user/guest-user.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GuestUserModule", function() { return GuestUserModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__guest_user_routing_module__ = __webpack_require__("./src/app/components/guest-user/guest-user-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__guest_user_component__ = __webpack_require__("./src/app/components/guest-user/guest-user.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__register_register_component__ = __webpack_require__("./src/app/components/guest-user/register/register.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__node_modules_angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var GuestUserModule = /** @class */ (function () {
    function GuestUserModule() {
    }
    GuestUserModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_5__node_modules_angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_6__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_5__node_modules_angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_2__guest_user_routing_module__["a" /* GuestUserRoutingModule */]
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_3__guest_user_component__["a" /* GuestUserComponent */], __WEBPACK_IMPORTED_MODULE_4__register_register_component__["a" /* RegisterComponent */]]
        })
    ], GuestUserModule);
    return GuestUserModule;
}());



/***/ }),

/***/ "./src/app/components/guest-user/register/register.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"login-virtual\">\r\n<div class=\"middle-section clearFix\">\r\n  <!-- Login Box -->\r\n  <div #virtualStyle>\r\n    <div class=\"login-form-wrapper\">\r\n      <div class=\"row text-center\">\r\n        <h2  *ngIf=\" isView == 'register'\">Register</h2>\r\n        <h2  *ngIf=\" isView == 'institute'\">Select Institute</h2>\r\n      </div>\r\n      <div class=\"row\" *ngIf=\" isView == 'register'\">\r\n        <div class=\"field-wrapper has-value\">\r\n          <input class=\"form-ctrl\" type=\"text\" [(ngModel)]=\"loginDataForm.name\" name=\"name\" id=\"name\" placeholder=\"Name\" #name=\"ngModel\"\r\n            required>\r\n          <div *ngIf=\"name.invalid && (name.dirty || name.touched)\" class=\"alert invalid-alert\">\r\n            <div *ngIf=\"name.errors.required\">\r\n              Please enter full name\r\n            </div>\r\n          </div>\r\n          <label for=\"name\"></label>\r\n        </div>\r\n        <div class=\"row\" style=\"margin:0;\">\r\n          <div class=\"field-wrapper has-value password\">\r\n            <input class=\"form-ctrl\" type=\"text\" [(ngModel)]=\"loginDataForm.alternate_email_id\" name=\"emailid\" id=\"emailid\" #emailid=\"ngModel\" placeholder=\"Email\"\r\n              required pattern=\"[a-zA-Z0-9._%+-]+@[a-zA-Z]+\\.[a-zA-Z.]{2,5}$\">\r\n            <div *ngIf=\"emailid.invalid && (emailid.dirty || emailid.touched )\" class=\"alert invalid-alert\">\r\n              <div *ngIf=\"emailid.errors.required\" class=\"fontCss\">\r\n                Please enter valid Email ID\r\n              </div>\r\n            </div>\r\n            <label for=\"emailid\"></label>\r\n          </div>\r\n        </div>\r\n        <div class=\"field-wrapper has-value\">\r\n          <input class=\"form-ctrl\" type=\"text\" [(ngModel)]=\"loginDataForm.mobile_no\"  id=\"mobile_no\"\r\n            placeholder=\"Mobile\" #mobile_no=\"ngModel\" maxlength=\"10\" minlength=\"10\" onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\" required>\r\n          <div *ngIf=\"mobile_no.invalid && (mobile_no.dirty || mobile_no.touched )\" class=\"alert invalid-alert\">\r\n            <div *ngIf=\"mobile_no.errors.required\" class=\"fontCss\">\r\n              Please enter valid Mobile number\r\n            </div>\r\n          </div>\r\n          <label for=\"mobile_no\"></label>\r\n        </div>\r\n        <div class=\"row\" style=\"margin:0;\">\r\n          <div class=\"field-wrapper has-value password\">\r\n            <input class=\"form-ctrl\" type=\"password\" [(ngModel)]=\"loginDataForm.password\" name=\"password\" id=\"password\" #password=\"ngModel\"\r\n              placeholder=\"Password\" required>\r\n            <div *ngIf=\"password.invalid && (password.dirty || password.touched )\" class=\"alert invalid-alert\">\r\n              <div *ngIf=\"password.errors.required\" class=\"fontCss\">\r\n                Please enter password\r\n              </div>\r\n            </div>\r\n            <label for=\"password\"></label>\r\n          </div>\r\n        </div>\r\n        <div class=\"field-wrapper has-value\">\r\n          <input class=\"form-ctrl\" type=\"password\" [(ngModel)]=\"loginDataForm.confirmPassword\" name=\"confirmPassword\" id=\"confirmPassword\" placeholder=\"Confirm Password\"\r\n            #confirmPassword=\"ngModel\" required>\r\n          <div *ngIf=\"confirmPassword.invalid && (confirmPassword.dirty || confirmPassword.touched || no_email_found)\" class=\"alert invalid-alert\">\r\n            <div *ngIf=\"confirmPassword.errors.required\" class=\"fontCss\">\r\n              Please enter same password\r\n            </div>\r\n          </div>\r\n          <label for=\"confirmPassword\"></label>\r\n        </div>\r\n      </div>\r\n      <!-- Show Insititue List -->\r\n      <div class=\"row\" *ngIf=\"isView=='institute'\">\r\n        <div class=\"field-wrapper\" style=\"margin:0;\">\r\n          <p>You are registered with multiple Institutes, Kindly select one to Continue</p>\r\n        </div>\r\n        <div class=\"insititue-field-wrapper\">\r\n          <div class=\"row\" *ngFor=\"let institute of instituteListArr\">\r\n            <div class=\"field-institute-wrapper\" (click)=\"alternateLoginMultiInstituteData(institute.institute_id)\">\r\n              {{institute.institute_name}}\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <!-- Show Insititute List End -->\r\n\r\n      <!-- OTP verification Start -->\r\n      <div class=\"row\" *ngIf=\"isView=='validateOTP'\">\r\n        <div class=\"field-wrapper insititute-field-wrapper\">\r\n          <h2 class=\"insititue-list-header\" style=\"padding-right:20px;\">Enter One Time Password</h2>\r\n        </div>\r\n        <div class=\"field-wrapper\" style=\"margin:0;\">\r\n          <p>One Time Password (OTP) has been sent to your mobile and/or email, please enter the same\r\n            here to login.</p>\r\n        </div>\r\n        <div class=\"form-type1\">\r\n          <div class=\"field-wrapper has-value\">\r\n            <label>OTP</label>\r\n            <input type=\"text\" value=\"\" class=\"form-ctrl\" [(ngModel)]=\"otpVerificationInfo.otp_code\" maxlength=\"4\" name=\"otpData\" id=\"otpData\"\r\n              #otpData=\"ngModel\" enquiryInput required style=\"margin-top: 18px;\">\r\n            <div *ngIf=\"otpData.invalid && (otpData.dirty || otpData.touched)\" class=\"alert invalid-alert\">\r\n              <div *ngIf=\"otpData.errors.required\" class=\"fontCss\">\r\n                Please enter OTP.\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\" *ngIf=\"counter != 0\">\r\n          <div class=\"forgot-password\" style=\"margin-right:18%;\">\r\n            <a style=\"cursor:pointer\">Resend in 00:{{countDown | async}}</a>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\" *ngIf=\"counter == 0\">\r\n          <div class=\"forgot-password\" style=\"margin-right:18%;\">\r\n            <a style=\"cursor:pointer\" (click)=\"alternateLoginOTPRegenerate()\">Resend?</a>\r\n          </div>\r\n        </div>\r\n        <div class=\"row\" style=\"text-align:center; margin-top:2%; margin-bottom: 15px;\">\r\n          <div class=\"login-field-btn\">\r\n            <input type=\"button\" value=\"VERIFY\" (click)=\"alternateLoginOTPVerification()\" class=\"fullBlue btn\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <!-- OTP verification End -->\r\n\r\n      <div class=\"row text-center\" style=\"margin: 10px;margin-top: 20px;\"  *ngIf=\" isView == 'register'\">\r\n        <div class=\"login-field-btn\">\r\n          <input type=\"button\" value=\"Submit\" id=\"btnSecureLogin\" class=\"fullBlue btn \" (click)=\"registerGuestUser()\">\r\n          <input type=\"button\" value=\"Cancel\" id=\"btnSecureLogin\" class=\"btn\" (click)=\"gotoLogin()\">\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./src/app/components/guest-user/register/register.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/* Login Page Background */\n.bg-img {\n  top: 0px;\n  left: 0px;\n  bottom: 0px;\n  right: 0px;\n  width: 100%;\n  height: 100%;\n  position: fixed;\n  background-color: #004a7e;\n  background-size: cover;\n  /* background-color: #004a7e;\r\n    position: absolute;\r\n    overflow: auto;\r\n    top: 0;\r\n    left: 0;\r\n    width: 100%;\r\n    background: linear-gradient(to right bottom, rgba(0, 72, 126, .97), rgba(0, 74, 126, .97) 50%, rgba(114, 183, 227, .97)); */ }\n.bg-img:before {\n    content: '';\n    background-color: #004a7e;\n    position: absolute;\n    top: 0;\n    right: 0;\n    bottom: 0;\n    left: 0;\n    background-image: -webkit-gradient(linear, left top, right bottom, from(rgba(0, 72, 126, 0.97)), color-stop(50%, rgba(0, 74, 126, 0.97)), to(rgba(114, 183, 227, 0.97)));\n    background-image: linear-gradient(to right bottom, rgba(0, 72, 126, 0.97), rgba(0, 74, 126, 0.97) 50%, rgba(114, 183, 227, 0.97));\n    opacity: .6; }\n.user-ex {\n  margin-top: 15px;\n  /* margin-bottom: 30%; */\n  width: 75%;\n  margin-left: 15%;\n  text-align: left;\n  font-size: 11px; }\n.bg-img-virtual {\n  top: 0px;\n  left: 0px;\n  bottom: 0px;\n  right: 0px;\n  width: 100%;\n  height: 100%;\n  position: fixed;\n  background-size: cover; }\n.bg-img-virtual:before {\n    content: '';\n    position: absolute;\n    top: 0;\n    right: 0;\n    bottom: 0;\n    left: 0;\n    opacity: .6; }\n.detailslog {\n  padding: 10px 30px 10px 30px;\n  min-height: 300px; }\n.box {\n  position: relative;\n  margin: auto;\n  top: 25px;\n  left: 0;\n  right: 0;\n  width: 80%;\n  border-radius: 4px;\n  background: #eaeaea;\n  margin-bottom: 100px;\n  -webkit-box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2);\n          box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2);\n  overflow: hidden;\n  z-index: 1; }\n.login-box {\n  position: absolute;\n  margin: auto;\n  top: 75px;\n  right: 14%;\n  width: 320px;\n  border-radius: 4px;\n  background: white;\n  margin-bottom: 100px;\n  -webkit-box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.15), 0 0 2px 0 rgba(0, 0, 0, 0.2);\n          box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.15), 0 0 2px 0 rgba(0, 0, 0, 0.2);\n  overflow: hidden;\n  z-index: 2;\n  -webkit-transition: left 0.1s cubic-bezier(0.175, 0.885, 0.26, 1.055);\n  transition: left 0.1s cubic-bezier(0.175, 0.885, 0.26, 1.055); }\n#header {\n  background: #009688;\n  position: relative;\n  text-align: center;\n  height: 100px;\n  width: 100%;\n  margin-bottom: 30px; }\n#cont-lock {\n  width: 100%;\n  height: 65px;\n  position: relative;\n  padding: 10px;\n  font-size: 36px;\n  font-weight: normal;\n  color: white; }\n.lock {\n  text-align: center;\n  color: white;\n  position: absolute;\n  left: 0;\n  right: 0;\n  margin: 0;\n  top: 0;\n  bottom: 0;\n  line-height: 65px;\n  font-size: 28px; }\n#bottom-head {\n  position: relative;\n  background: #00796b;\n  height: 35px; }\n#bottom-head::after {\n  content: '';\n  width: 0px;\n  height: 0px;\n  display: block;\n  position: absolute;\n  margin: auto;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  border-bottom: 7px solid white;\n  border-right: 7px solid rgba(0, 0, 0, 0);\n  border-left: 7px solid rgba(0, 0, 0, 0);\n  border-top: 7px solid rgba(0, 0, 0, 0); }\n.box h1 {\n  margin: 0;\n  font-size: 24px;\n  font-weight: 300;\n  color: #cfd8dc;\n  line-height: 35px; }\n.box button {\n  background: #cfd8dc;\n  border: 0;\n  color: #009688;\n  padding: 10px;\n  font-size: 16px;\n  font-weight: 300;\n  width: 330px;\n  margin: 20px auto;\n  display: block;\n  cursor: pointer;\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s;\n  border-radius: 2px; }\n.box button:active {\n  background: #009688;\n  color: #263238; }\n.box button:hover {\n  background: #009688;\n  color: #FFF;\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s; }\n.box p {\n  font-size: 14px;\n  text-align: center; }\n.group {\n  position: relative;\n  margin-bottom: 35px;\n  margin-left: 40px; }\n.inputMaterial {\n  font-size: 18px;\n  padding: 10px 10px 10px 5px;\n  display: block;\n  width: 300px;\n  border: none;\n  border-bottom: 1px solid #757575; }\n.inputMaterial:focus {\n  outline: none; }\n/* LABEL ======================================= */\nlabel {\n  color: #999;\n  font-size: 14px;\n  font-weight: normal;\n  position: absolute;\n  pointer-events: none;\n  left: 5px;\n  top: 10px;\n  transition: 0.1s ease all;\n  -moz-transition: 0.1s ease all;\n  -webkit-transition: 0.1s ease all; }\n/* active state */\n.inputMaterial:focus ~ label,\n.inputMaterial:valid ~ label {\n  top: -20px;\n  font-size: 14px;\n  color: #009688; }\n/* BOTTOM BARS ================================= */\n.bar {\n  position: relative;\n  display: block;\n  width: 315px; }\n.bar:before,\n.bar:after {\n  content: '';\n  height: 2px;\n  width: 0;\n  bottom: 1px;\n  position: absolute;\n  background: #009688;\n  transition: 0.1s ease all;\n  -moz-transition: 0.1s ease all;\n  -webkit-transition: 0.1s ease all; }\n.bar:before {\n  left: 50%; }\n.bar:after {\n  right: 50%; }\n/* active state */\n.inputMaterial:focus ~ .bar:before,\n.inputMaterial:focus ~ .bar:after {\n  width: 50%; }\n.boxNew {\n  position: relative;\n  margin: auto;\n  top: 14vh;\n  left: 0;\n  right: 0;\n  width: 80%;\n  border-radius: 4px;\n  background: #eaeaea;\n  margin-bottom: 100px;\n  -webkit-box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2);\n          box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2);\n  overflow: hidden;\n  z-index: 1; }\n/* active state */\n.inputMaterial:focus ~ .highlight {\n  -webkit-animation: inputHighlighter 0.3s ease;\n  animation: inputHighlighter 0.3s ease; }\n/* ANIMATIONS ================ */\n@-webkit-keyframes inputHighlighter {\n  from {\n    background: #5264AE; }\n  to {\n    width: 0;\n    background: transparent; } }\n@keyframes inputHighlighter {\n  from {\n    background: #5264AE; }\n  to {\n    width: 0;\n    background: transparent; } }\n#footer-box {\n  width: 100%;\n  height: 50px;\n  background: #00695c;\n  position: absolute;\n  bottom: 0; }\n.footer-text {\n  color: #cfd8dc; }\n.sign-up {\n  color: white;\n  cursor: pointer; }\n.sign-up:hover {\n  color: #b2dfdb; }\n.field-radio-wrapper {\n  margin: 30px 10px; }\n.field-radio-wrapper .form-radio {\n    margin: 6px 0px;\n    padding: 0px; }\n.field-radio-wrapper label {\n    padding: 1px 20px; }\n.auth-page-header {\n  position: relative;\n  top: 0;\n  left: 0;\n  width: 100%; }\n.auth-page-header .row {\n    margin-left: 15%;\n    padding-top: 10px; }\n.auth-page-header h5 {\n    color: white; }\n.login-wrapper .row {\n  width: 100%;\n  margin: 0px;\n  padding: 5px;\n  color: #58666e; }\n.login-wrapper .row h2 {\n    color: #58666e;\n    font-weight: 600; }\n.login-wrapper .row hr {\n    border: 0.5px ridge #c1bfbf; }\n.login-wrapper .row .left-div-wrapper {\n    left: 5%;\n    top: 60px; }\n.login-wrapper .row .footer-wrapper {\n    margin-top: 25%;\n    width: 100%; }\n.login-wrapper .row .second-left-div-wrapper {\n    left: 5%;\n    top: 60px;\n    margin-top: 40px; }\n.login-wrapper .row .left-p-div {\n    margin-top: 12px; }\n.login-wrapper .row p {\n    text-align: left; }\n.login-wrapper .row .call-icon {\n    font-family: FontAwesome;\n    border: 1px solid;\n    width: 40px;\n    height: 40px;\n    padding-left: 8px;\n    vertical-align: middle;\n    border-radius: 10px;\n    font-size: 30px;\n    color: #17384b;\n    padding-top: 2px;\n    margin-top: 4px; }\n.login-wrapper .row .footer-contact-wrapper {\n    padding: 10px 40px 0px 10px; }\n.login-wrapper .row .footer-contact-wrapper .c-xs-6 {\n      padding-left: 30px;\n      color: #17384b; }\n.login-wrapper .row .footer-contact-wrapper span {\n      font-size: 22px; }\n.login-wrapper ul.social-icons {\n  padding: 5px 15px; }\n.login-wrapper ul.social-icons li {\n    display: inline; }\n.login-wrapper ul.social-icons li .icons {\n      font-family: FontAwesome;\n      margin: 0px 5px;\n      font-size: 20px; }\n.login-virtual {\n  height: auto;\n  padding-bottom: 4vh;\n  position: absolute;\n  left: 0px;\n  right: 0px;\n  margin: auto;\n  top: 157px;\n  /* right: 32%; */\n  width: 320px;\n  border-radius: 4px;\n  background: white;\n  margin-bottom: 100px;\n  -webkit-box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.15), 0 0 2px 0 rgba(0, 0, 0, 0.2);\n  box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.15), 0 0 2px 0 rgba(0, 0, 0, 0.2);\n  overflow: hidden;\n  z-index: 2;\n  -webkit-transition: left 0.1s cubic-bezier(0.175, 0.885, 0.26, 1.055);\n  transition: left 0.1s cubic-bezier(0.175, 0.885, 0.26, 1.055); }\n.auth-page-virtual {\n  position: relative;\n  top: 4vh;\n  left: 37%;\n  width: 100%; }\n.auth-page-virtual .row {\n    margin: 0 5%;\n    padding-top: 10px; }\n.login-form-wrapper .row {\n  margin: 0px; }\n.login-form-wrapper h2 {\n  padding: 40px 80px 10px 52px;\n  color: #58666e; }\n.login-form-wrapper .field-wrapper {\n  width: 70%;\n  left: 15%;\n  font-size: 12px; }\n.login-form-wrapper .forgot-password {\n  float: right;\n  margin-right: 12%;\n  padding-top: 5px; }\n.login-form-wrapper .login-field-btn .login-btn {\n  margin-top: 5%;\n  width: 70%; }\n.login-form-wrapper .agreement-row {\n  margin-top: 20%;\n  margin-bottom: 30%;\n  width: 75%;\n  margin-left: 15%; }\n.login-form-wrapper .insititute-field-wrapper {\n  width: 90%;\n  left: 0%;\n  margin: 0; }\n.login-form-wrapper .insititute-field-wrapper .insititue-list-header {\n    padding: 10px 80px 0px 52px; }\n.login-form-wrapper .insititue-field-wrapper {\n  height: 250px;\n  overflow-y: auto; }\n.login-form-wrapper .insititue-field-wrapper .row {\n    margin: 0px; }\n.login-form-wrapper .insititue-field-wrapper .field-institute-wrapper {\n    margin: 10px 40px;\n    margin-bottom: 0;\n    cursor: pointer;\n    padding: 15px;\n    -webkit-box-shadow: 1px 1px 10px 0 rgba(0, 0, 0, 0.15), 0 0 2px 0 rgba(0, 0, 0, 0.2);\n            box-shadow: 1px 1px 10px 0 rgba(0, 0, 0, 0.15), 0 0 2px 0 rgba(0, 0, 0, 0.2); }\n.field-wrapper .invalid-alert {\n  color: red;\n  background: rgba(255, 255, 255, 0);\n  -webkit-box-shadow: none;\n          box-shadow: none; }\n.field-radio-wrapper .form-radio + label:after {\n  left: 2px !important;\n  top: 2px !important; }\n.cursor-point {\n  cursor: pointer; }\n.fontCss {\n  font-size: 12px; }\n"

/***/ }),

/***/ "./src/app/components/guest-user/register/register.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RegisterComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__ = __webpack_require__("./src/app/services/login-services/login.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__node_modules_rxjs__ = __webpack_require__("./node_modules/rxjs/Rx.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__node_modules_rxjs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__node_modules_rxjs__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var RegisterComponent = /** @class */ (function () {
    function RegisterComponent(login, router, msgService) {
        this.login = login;
        this.router = router;
        this.msgService = msgService;
        /* Variable Declaration */
        this.loginDataForm = {
            alternate_email_id: "",
            password: "",
            confirmPassword: "",
            mobile_no: "",
            institution_id: "",
            name: ""
        };
        this.otpVerificationInfo = {
            otp_code: ""
        };
        this.instituteListArr = [];
        this.counter = 30;
        this.isRippleLoad = false;
        this.isView = 'register';
        this.messages = msgService.getMessages();
    }
    RegisterComponent.prototype.ngOnInit = function () {
    };
    RegisterComponent.prototype.gotoLogin = function () {
        this.router.navigate(['/authPage']);
    };
    RegisterComponent.prototype.alternateLoginOTPVerification = function () {
        var _this = this;
        if (this.otpVerificationInfo.otp_code.trim() == "") {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, "", "Please enter OTP ");
            return;
        }
        this.otpVerificationInfo.otp_validate_mode = 2;
        this.isRippleLoad = true;
        this.login.validateOTPCode(this.otpVerificationInfo).subscribe(function (res) {
            if (res) {
                // institute
                _this.isRippleLoad = false;
                switch (res.otp_status) {
                    case 1: {
                        _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, "", "Your OTP expired ");
                        break;
                    }
                    case 2: {
                        _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, "", "Your OTP is wrong ");
                        break;
                    }
                    default: {
                        _this.gotoLogin();
                        _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, "", "Your account verified successfully");
                        break;
                    }
                }
            }
        }, function (err) {
            console.log(err);
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    RegisterComponent.prototype.registerGuestUser = function () {
        var _this = this;
        var email = /^[a-zA-Z0-9._%+-]+@[a-zA-Z]+\.[a-zA-Z.]{2,5}$/;
        this.loginDataForm.institution_id = sessionStorage.getItem('institution_id');
        if (this.loginDataForm.alternate_email_id.trim() != ""
            && this.loginDataForm.password.trim() != ""
            && this.loginDataForm.confirmPassword.trim() != ""
            && this.loginDataForm.mobile_no.trim() != ""
            && this.loginDataForm.name.trim() != "") {
            if (this.loginDataForm.name.trim() != "") {
                if (email.test(this.loginDataForm.alternate_email_id)) {
                    if (this.loginDataForm.mobile_no.length == 10) {
                        if (this.loginDataForm.password.length >= 5 && this.loginDataForm.confirmPassword.length >= 5) {
                            if (this.loginDataForm.password == this.loginDataForm.confirmPassword) {
                                this.isRippleLoad = true;
                                this.login.guestUserRegistration(this.loginDataForm).subscribe(function (res) {
                                    _this.otpVerificationInfo = res;
                                    _this.isRippleLoad = false;
                                    if (res.institutesList != null) {
                                        // institute
                                        _this.instituteListArr = res.institutesList;
                                        _this.isView = 'institute';
                                    }
                                    else {
                                        _this.isView = 'validateOTP';
                                        _this.counter = 30;
                                        _this.otpVerificationInfo.otp_code = "";
                                        _this.countDown = __WEBPACK_IMPORTED_MODULE_4__node_modules_rxjs__["Observable"].timer(0, 1000)
                                            .take(_this.counter)
                                            .map(function () { return --_this.counter; });
                                    }
                                }, function (err) {
                                    console.log(err);
                                    _this.isView = 'register';
                                    _this.isRippleLoad = false;
                                    _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
                                });
                            }
                            else {
                                this.msgService.showErrorMessage(this.msgService.toastTypes.error, "", "Password should be same  ");
                            }
                        }
                        else {
                            this.msgService.showErrorMessage(this.msgService.toastTypes.error, "", "Password must be atleast 5 characters long");
                        }
                    }
                    else {
                        this.msgService.showErrorMessage(this.msgService.toastTypes.error, "", "Please enter 10 digit mobile number");
                    }
                }
                else {
                    this.msgService.showErrorMessage(this.msgService.toastTypes.error, "", "Please enter valid email id");
                }
            }
            else {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, "", "Please enter name");
            }
        }
        else {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, "", "Please fill the details");
        }
    };
    RegisterComponent.prototype.alternateLoginOTPRegenerate = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.login.regenerateOTP(this.otpVerificationInfo).subscribe(function (res) {
            if (res) {
                // institute
                _this.isRippleLoad = false;
                _this.otpVerificationInfo = res;
                _this.otpVerificationInfo.otp_code = "";
                _this.isView = 'validateOTP';
                _this.counter = 30;
                _this.countDown = __WEBPACK_IMPORTED_MODULE_4__node_modules_rxjs__["Observable"].timer(0, 1000)
                    .take(_this.counter)
                    .map(function () { return --_this.counter; });
            }
        }, function (err) {
            console.log(err);
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    RegisterComponent.prototype.alternateLoginMultiInstituteData = function (institution_id) {
        var _this = this;
        this.isRippleLoad = true;
        if (this.loginDataForm.institution_id == institution_id) {
            this.loginDataForm.is_main_branch = "Y";
        }
        else {
            this.loginDataForm.is_main_branch = "N";
        }
        this.loginDataForm.institution_id = institution_id;
        this.login.guestUserRegistration(this.loginDataForm).subscribe(function (res) {
            _this.isRippleLoad = false;
            if (res) {
                // institute
                _this.otpVerificationInfo = res;
                _this.otpVerificationInfo.otp_code = "";
                _this.isView = 'validateOTP';
                _this.counter = 30;
                _this.countDown = __WEBPACK_IMPORTED_MODULE_4__node_modules_rxjs__["Observable"].timer(0, 1000)
                    .take(_this.counter)
                    .map(function () { return --_this.counter; });
            }
        }, function (err) {
            _this.isRippleLoad = false;
            console.log(err);
        });
    };
    RegisterComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-register',
            template: __webpack_require__("./src/app/components/guest-user/register/register.component.html"),
            styles: [__webpack_require__("./src/app/components/guest-user/register/register.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_login_services_login_service__["a" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_2__node_modules_angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__["a" /* MessageShowService */]])
    ], RegisterComponent);
    return RegisterComponent;
}());



/***/ })

});
//# sourceMappingURL=guest-user.module.chunk.js.map