webpackJsonp(["monitoring-dashboard.module"],{

/***/ "./src/app/components/fee-module/monitoring-dashboard/dashboard-home/dashboard-home.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"monitor-wrapper\">\r\n\r\n    <section class=\"c-lg-12 header\">\r\n        <h2 class=\"pull-left\">\r\n            <a routerLink=\"/view/fee\">\r\n                Fees\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i> Monitoring Dashboard\r\n        </h2>\r\n        <aside class=\"pull-right\">\r\n        </aside>\r\n    </section>\r\n\r\n    <div style=\"margin-top: 5px;\" class=\"c-lg-12\">\r\n        <div class=\"c-lg-4\">\r\n            <fee-stackbar></fee-stackbar>\r\n        </div>\r\n        <div class=\"c-lg-2\"></div>\r\n        <div class=\"c-lg-6\">\r\n            <fee-pie></fee-pie>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"c-lg-12\">\r\n        <fee-line></fee-line>\r\n    </div>\r\n\r\n</section>"

/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/dashboard-home/dashboard-home.component.scss":
/***/ (function(module, exports) {

module.exports = ".monitor-wrapper {\n  width: 100%;\n  background: #efefef;\n  overflow: auto; }\n  .monitor-wrapper ::-webkit-scrollbar {\n    display: block; }\n  .monitor-wrapper .header {\n    margin: 10px 12px;\n    width: 98%;\n    padding: 15px 15px;\n    border-bottom: 1px solid rgba(10, 10, 10, 0.5); }\n"

/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/dashboard-home/dashboard-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DashboardHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var DashboardHomeComponent = /** @class */ (function () {
    function DashboardHomeComponent() {
    }
    DashboardHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'dashboard-home',
            template: __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/dashboard-home/dashboard-home.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/monitoring-dashboard/dashboard-home/dashboard-home.component.scss")]
        })
    ], DashboardHomeComponent);
    return DashboardHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/fee-line-widget/fee-line.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"line-wrapper\">\r\n\r\n    <section class=\"row pie-filter\" [ngClass]=\"{'hide': !isDataLoaded}\">\r\n        <div class=\"field-wrapper\">\r\n            <!-- <label for=\"duration\">Duration</label> -->\r\n            <select name=\"\" id=\"duration\" [(ngModel)]=\"rangelineSelected\" (ngModelChange)=\"datelineRangeUpdated($event)\" class=\"form-ctrl\">\r\n                <option value=\"1\" selected=\"\">Last 7 days</option>\r\n                <option value=\"2\">This Month</option>\r\n                <option value=\"3\">Last 30 Days</option>\r\n                <option value=\"4\">Last Month</option>\r\n                <option value=\"5\">Last 3 Months</option>\r\n            </select>\r\n        </div>\r\n    </section>\r\n    <section class=\"row\" [ngClass]=\"{'hide': !isDataLoaded}\">\r\n        <div id=\"lineContainer\">\r\n        </div>\r\n    </section>\r\n\r\n    <div style=\"padding: 5px;\" [ngClass]=\"{'hide': isDataLoaded}\">\r\n        Loading Data...\r\n    </div>\r\n\r\n</section>"

/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/fee-line-widget/fee-line.component.scss":
/***/ (function(module, exports) {

module.exports = ".line-wrapper {\n  margin: 20px 14px 10px;\n  -webkit-box-shadow: 0px 0px 2px 1px;\n          box-shadow: 0px 0px 2px 1px;\n  background: #fff; }\n  .line-wrapper .row {\n    margin: 0px; }\n  .line-wrapper .field-wrapper {\n    width: 200px;\n    float: right;\n    margin-right: 10px; }\n"

/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/fee-line-widget/fee-line.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FeeLineComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_monitoring_service__ = __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/services/monitoring.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_highcharts__ = __webpack_require__("./node_modules/highcharts/highcharts.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_highcharts___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_highcharts__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var FeeLineComponent = /** @class */ (function () {
    function FeeLineComponent(getService, _commService) {
        this.getService = getService;
        this._commService = _commService;
        this.datelineRange = [];
        this.rangelineSelected = '2';
        this.rangeType = 'This Month';
        this.isDataLoaded = false;
        this.datelineRange[0] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).startOf('month').format('DD-MMM-YYYY');
        this.datelineRange[1] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).endOf('month').format('DD-MMM-YYYY');
    }
    FeeLineComponent.prototype.ngOnInit = function () {
        this.fetchFeeStackMonitor();
    };
    FeeLineComponent.prototype.datelineRangeUpdated = function (e) {
        /* last 7 days */
        if (e == 1) {
            this.datelineRange[1] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).format('DD-MMM-YYYY');
            this.datelineRange[0] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).subtract(7, 'days').format('DD-MMM-YYYY');
            this.rangeType = "Last 7 days";
        }
        else if (e == 2) {
            this.datelineRange[0] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).startOf('month').format('DD-MMM-YYYY');
            this.datelineRange[1] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).endOf('month').format('DD-MMM-YYYY');
            this.rangeType = "This Month";
        }
        else if (e == 3) {
            this.datelineRange[1] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).format('DD-MMM-YYYY');
            this.datelineRange[0] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).subtract(30, 'days').format('DD-MMM-YYYY');
            this.rangeType = "Last 30 Days";
        }
        else if (e == 4) {
            this.datelineRange[0] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).startOf('month').subtract(1, 'months').format('DD-MMM-YYYY');
            this.datelineRange[1] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).startOf('month').subtract(1, 'months').endOf('month').format('DD-MMM-YYYY');
            this.rangeType = "Last Month";
        }
        else if (e == 5) {
            this.datelineRange[0] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).startOf('month').subtract(3, 'months').format('DD-MMM-YYYY');
            this.datelineRange[1] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).format('DD-MMM-YYYY');
            this.rangeType = "Last 3 Months";
        }
        this.fetchFeeStackMonitor();
    };
    FeeLineComponent.prototype.fetchFeeStackMonitor = function () {
        var _this = this;
        var obj = {
            from_date: __WEBPACK_IMPORTED_MODULE_1_moment__(this.datelineRange[0]).format('YYYY-MM-DD'),
            high_charts_name: "",
            institute_id: sessionStorage.getItem('institute_id'),
            to_date: __WEBPACK_IMPORTED_MODULE_1_moment__(this.datelineRange[1]).format('YYYY-MM-DD')
        };
        this.getService.fetchFeeMonitor(obj).subscribe(function (res) {
            _this.isDataLoaded = true;
            _this.generateChartData(res);
        }, function (err) {
            _this.isDataLoaded = true;
        });
    };
    FeeLineComponent.prototype.generateChartData = function (res) {
        var dateMap = [];
        var feeMap = [];
        res.map(function (e) {
            dateMap.push(e.paid_date);
            feeMap.push(e.total_fees);
        });
        this.createChart(dateMap, feeMap);
    };
    FeeLineComponent.prototype.createChart = function (d, f) {
        __WEBPACK_IMPORTED_MODULE_3_highcharts__["chart"]('lineContainer', {
            chart: {
                zoomType: 'x'
                //type: 'line'
            },
            title: {
                text: 'Fee Collection'
            },
            subtitle: {
                text: this.rangeType
            },
            xAxis: {
                categories: d
            },
            yAxis: {
                title: {
                    text: 'Amount(Rs)'
                }
            },
            tooltip: {
                pointFormat: '<span style="color:{series.color}">●</span> {series.name}: <b> ' + this._commService.currency_default_symbol + ' {point.y} </b>'
            },
            plotOptions: {
                area: {
                    fillColor: {
                        linearGradient: {
                            x1: 0,
                            y1: 0,
                            x2: 0,
                            y2: 1
                        },
                        stops: [
                            [0, __WEBPACK_IMPORTED_MODULE_3_highcharts__["getOptions"]().colors[0]],
                            [1, __WEBPACK_IMPORTED_MODULE_3_highcharts__["Color"](__WEBPACK_IMPORTED_MODULE_3_highcharts__["getOptions"]().colors[1])]
                        ]
                    },
                    marker: {
                        radius: 2
                    },
                    lineWidth: 1,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                    threshold: null
                },
                line: {
                    dataLabels: {
                        enabled: true,
                        format: this._commService.currency_default_symbol + ' {y}'
                    },
                    enableMouseTracking: true
                }
            },
            series: [{
                    name: 'Dates',
                    data: f
                }]
        });
    };
    FeeLineComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'fee-line',
            template: __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/fee-line-widget/fee-line.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/monitoring-dashboard/fee-line-widget/fee-line.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_monitoring_service__["a" /* monitoringService */],
            __WEBPACK_IMPORTED_MODULE_4__services_common_service__["a" /* CommonServiceFactory */]])
    ], FeeLineComponent);
    return FeeLineComponent;
}());



/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/fee-pie-widget/fee-pie.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"pie-wrapper\">\r\n\r\n    <section class=\"row pie-filter\" [ngClass]=\"{'hide': !isDataLoaded}\">\r\n        <div class=\"field-wrapper\">\r\n            <!-- <label for=\"duration\">Duration</label> -->\r\n            <select name=\"\" id=\"duration\" [(ngModel)]=\"rangeSelected\" (ngModelChange)=\"dateRangeUpdated($event)\" class=\"form-ctrl\">\r\n                <option value=\"1\" selected=\"\">Last 7 days</option>\r\n                <option value=\"2\">This month</option>\r\n                <option value=\"3\">Last 30 days</option>\r\n                <option value=\"4\">Last month</option>\r\n                <option value=\"5\">Last 3 months</option>\r\n            </select>\r\n        </div>\r\n    </section>\r\n    <section class=\"row\" [ngClass]=\"{'hide': !isDataLoaded}\">\r\n        <div id=\"pieContainer\">\r\n        </div>\r\n    </section>\r\n\r\n    <div style=\"padding: 5px;\" [ngClass]=\"{'hide': isDataLoaded}\">\r\n        Loading Data...\r\n    </div>\r\n\r\n</section>"

/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/fee-pie-widget/fee-pie.component.scss":
/***/ (function(module, exports) {

module.exports = ".pie-wrapper {\n  -webkit-box-shadow: 0px 0px 2px 1px;\n          box-shadow: 0px 0px 2px 1px;\n  background: #fff; }\n  .pie-wrapper .row {\n    margin: 0px; }\n  .pie-wrapper .field-wrapper {\n    width: 200px;\n    float: right;\n    margin-right: 10px; }\n"

/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/fee-pie-widget/fee-pie.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FeePieComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_monitoring_service__ = __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/services/monitoring.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_highcharts_highcharts__ = __webpack_require__("./node_modules/highcharts/highcharts.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_highcharts_highcharts___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_highcharts_highcharts__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var FeePieComponent = /** @class */ (function () {
    function FeePieComponent(getService, _commService) {
        this.getService = getService;
        this._commService = _commService;
        this.FeeDataData = [0, 0, 0, 0];
        this.isDataLoaded = false;
        this.dateRange = [];
        this.rangeSelected = '2';
        this.dateRange[0] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).startOf('month').format('DD-MMM-YYYY');
        this.dateRange[1] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).endOf('month').format('DD-MMM-YYYY');
    }
    FeePieComponent.prototype.ngOnInit = function () {
        this.fetchFeeStackMonitor();
    };
    FeePieComponent.prototype.dateRangeUpdated = function (e) {
        /* last 7 days */
        if (e == 1) {
            this.dateRange[1] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).format('DD-MMM-YYYY');
            this.dateRange[0] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).subtract(7, 'days').format('DD-MMM-YYYY');
        }
        else if (e == 2) {
            this.dateRange[0] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).startOf('month').format('DD-MMM-YYYY');
            this.dateRange[1] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).endOf('month').format('DD-MMM-YYYY');
        }
        else if (e == 3) {
            this.dateRange[1] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).format('DD-MMM-YYYY');
            this.dateRange[0] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).subtract(30, 'days').format('DD-MMM-YYYY');
        }
        else if (e == 4) {
            this.dateRange[0] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).startOf('month').subtract(1, 'months').format('DD-MMM-YYYY');
            this.dateRange[1] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).startOf('month').subtract(1, 'months').endOf('month').format('DD-MMM-YYYY');
        }
        else if (e == 5) {
            this.dateRange[0] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).startOf('month').subtract(3, 'months').format('DD-MMM-YYYY');
            this.dateRange[1] = __WEBPACK_IMPORTED_MODULE_1_moment__(new Date()).format('DD-MMM-YYYY');
        }
        this.fetchFeeStackMonitor();
    };
    FeePieComponent.prototype.fetchFeeStackMonitor = function () {
        var _this = this;
        var obj = {
            from_date: __WEBPACK_IMPORTED_MODULE_1_moment__(this.dateRange[0]).format('YYYY-MM-DD'),
            high_charts_name: "pieCharts",
            institute_id: sessionStorage.getItem('institute_id'),
            to_date: __WEBPACK_IMPORTED_MODULE_1_moment__(this.dateRange[1]).format('YYYY-MM-DD')
        };
        this.getService.fetchFeeMonitor(obj).subscribe(function (res) {
            _this.isDataLoaded = true;
            _this.generateChartData(res);
        }, function (err) {
            _this.isDataLoaded = false;
        });
    };
    FeePieComponent.prototype.generateChartData = function (res) {
        var temp = res;
        var obj = {
            cash: 0,
            caution: 0,
            credit: 0,
            other: 0,
            cheque: 0,
            neft: 0
        };
        temp.forEach(function (e) {
            if (e.paymentMode == "Cash") {
                obj.cash = e.total_fees;
            }
            else if (e.paymentMode == "Caution Deposit(Refundable)") {
                obj.caution = e.total_fees;
            }
            else if (e.paymentMode == "Credit/Debit Card") {
                obj.credit = e.total_fees;
            }
            else if (e.paymentMode == "Other") {
                obj.other = e.total_fees;
            }
            else if (e.paymentMode == "Cheque") {
                obj.cheque = e.total_fees;
            }
            else if (e.paymentMode == "NEFT/RTGS") {
                obj.neft = e.total_fees;
            }
        });
        this.createChart(obj);
    };
    FeePieComponent.prototype.createChart = function (obj) {
        __WEBPACK_IMPORTED_MODULE_3_highcharts_highcharts__["chart"]('pieContainer', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie',
                options3d: {
                    enabled: true,
                    alpha: 45,
                    beta: 0
                }
            },
            title: {
                text: 'Payment Mode'
            },
            tooltip: {
                pointFormat: '<span style="color:{series.color}">●</span> {series.name}: <b> ' + this._commService.currency_default_symbol + ' {point.y} </b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: this._commService.currency_default_symbol + '{y}'
                    },
                    showInLegend: true
                }
            },
            series: [{
                    name: 'Payment Mode',
                    colorByPoint: true,
                    data: [{
                            name: 'Cash',
                            y: obj.cash,
                            sliced: true,
                            selected: true
                        }, {
                            name: 'Caution Deposit(Refundable)',
                            y: obj.caution
                        }, {
                            name: 'Credit/Debit Card',
                            y: obj.credit
                        }, {
                            name: 'Other',
                            y: obj.other
                        }, {
                            name: 'Cheque',
                            y: obj.cheque
                        }, {
                            name: 'NEFT/RTGS',
                            y: obj.neft
                        }]
                }]
        });
    };
    FeePieComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'fee-pie',
            template: __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/fee-pie-widget/fee-pie.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/monitoring-dashboard/fee-pie-widget/fee-pie.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_monitoring_service__["a" /* monitoringService */],
            __WEBPACK_IMPORTED_MODULE_4__services_common_service__["a" /* CommonServiceFactory */]])
    ], FeePieComponent);
    return FeePieComponent;
}());



/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/fee-stackbar-widget/fee-stackbar.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"stackwrapper\">\r\n\r\n    <div [ngClass]=\"{'hide': !isDataLoaded}\" id=\"feestackbar\">\r\n    </div>\r\n\r\n    <div style=\"padding: 5px;\" [ngClass]=\"{'hide': isDataLoaded}\">\r\n        Loading Data...\r\n    </div>\r\n\r\n</section>"

/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/fee-stackbar-widget/fee-stackbar.component.scss":
/***/ (function(module, exports) {

module.exports = ".stackwrapper {\n  padding-top: 44px;\n  -webkit-box-shadow: 0px 0px 2px 1px;\n          box-shadow: 0px 0px 2px 1px;\n  background: #fff; }\n"

/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/fee-stackbar-widget/fee-stackbar.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FeeStackbarComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_monitoring_service__ = __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/services/monitoring.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_highcharts__ = __webpack_require__("./node_modules/highcharts/highcharts.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_highcharts___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_highcharts__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var FeeStackbarComponent = /** @class */ (function () {
    function FeeStackbarComponent(getService, _commService) {
        this.getService = getService;
        this._commService = _commService;
        this.isDataLoaded = false;
        this.FeeDataData = [0, 0, 0, 0];
    }
    FeeStackbarComponent.prototype.ngOnInit = function () {
        this.fetchFeeStackMonitor();
    };
    FeeStackbarComponent.prototype.fetchFeeStackMonitor = function () {
        var _this = this;
        this.getService.fetchFeeStackMonitor().subscribe(function (res) {
            _this.isDataLoaded = true;
            if (_this.isDataLoaded) {
                _this.generateChartData(res);
            }
        }, function (err) {
            _this.isDataLoaded = false;
        });
    };
    FeeStackbarComponent.prototype.generateChartData = function (res) {
        var fd = parseInt(res.total_future_dues);
        var n = parseInt(res.total_dues_amount_in_next_thirty_days);
        var pd = parseInt(res.total_dues_pending);
        var p = parseInt(res.total_paid_amount_in_last_thirty_days);
        this.createChart(fd, n, pd, p);
    };
    FeeStackbarComponent.prototype.createChart = function (fd, n, pd, p) {
        __WEBPACK_IMPORTED_MODULE_2_highcharts__["chart"]('feestackbar', {
            chart: {
                type: 'column',
                options3d: {
                    enabled: true,
                    alpha: 15,
                    beta: 15,
                    viewDistance: 25,
                    depth: 40
                },
                backgroundColor: '#FFF',
            },
            title: {
                text: ''
            },
            xAxis: {
                categories: ['Future dues', "Dues in next 30 days", "Past dues", "Paid in last 30 days"],
                labels: {
                    skew3d: true,
                    style: {
                        fontSize: '16px'
                    }
                }
            },
            yAxis: {
                visible: false,
                allowDecimals: false,
                min: 0,
                title: {
                    text: 'Amount in Rs',
                    skew3d: true
                }
            },
            tooltip: {
                headerFormat: '<b>{point.key}</b><br>',
                pointFormat: '{series.name}: ' + this._commService.currency_default_symbol + ' {point.y}'
            },
            plotOptions: {
                column: {
                    dataLabels: {
                        enabled: true,
                        color: '#FFF',
                        format: this._commService.currency_default_symbol + ' {y}',
                        x: 0
                    },
                    stacking: 'normal',
                    depth: 40
                }
            },
            series: [
                {
                    data: [
                        { y: fd, name: 'Future dues', color: '#80cbc4' },
                        { y: n, name: 'Dues in next 30 days', color: '#37474f' },
                        { y: pd, name: 'Past dues', color: '#536DFE' },
                        { y: p, name: 'Paid in last 30 days', color: '#2e7d32' }
                    ]
                }
                // { name: 'Future Dues', data: [fd], crisp: false },
                // { name: 'Dues in Next 30 Days', data: [n], crisp: false },
                // { name: 'Past Dues', data: [pd], crisp: false },
                // { name: 'Paid in Last 30 Days', data: [p], crisp: false },
            ]
        });
    };
    FeeStackbarComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'fee-stackbar',
            template: __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/fee-stackbar-widget/fee-stackbar.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/monitoring-dashboard/fee-stackbar-widget/fee-stackbar.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_monitoring_service__["a" /* monitoringService */],
            __WEBPACK_IMPORTED_MODULE_3__services_common_service__["a" /* CommonServiceFactory */]])
    ], FeeStackbarComponent);
    return FeeStackbarComponent;
}());



/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/monitoring-dashboard-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return MonitoringRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__dashboard_home_dashboard_home_component__ = __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/dashboard-home/dashboard-home.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var MonitoringRoutingModule = /** @class */ (function () {
    function MonitoringRoutingModule() {
    }
    MonitoringRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__dashboard_home_dashboard_home_component__["a" /* DashboardHomeComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                redirectTo: 'home'
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_2__dashboard_home_dashboard_home_component__["a" /* DashboardHomeComponent */]
                            }
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], MonitoringRoutingModule);
    return MonitoringRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/monitoring-dashboard.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>"

/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/monitoring-dashboard.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/monitoring-dashboard.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return MonitoringDashboardComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var MonitoringDashboardComponent = /** @class */ (function () {
    function MonitoringDashboardComponent() {
    }
    MonitoringDashboardComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'monitoring-dashboard',
            template: __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/monitoring-dashboard.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/monitoring-dashboard/monitoring-dashboard.component.scss")]
        })
    ], MonitoringDashboardComponent);
    return MonitoringDashboardComponent;
}());



/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/monitoring-dashboard.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MonitoringDashboardModule", function() { return MonitoringDashboardModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_hammerjs__ = __webpack_require__("./node_modules/hammerjs/hammer.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_hammerjs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_hammerjs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_monitoring_service__ = __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/services/monitoring.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__monitoring_dashboard_routing_module__ = __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/monitoring-dashboard-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__monitoring_dashboard_component__ = __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/monitoring-dashboard.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__dashboard_home_dashboard_home_component__ = __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/dashboard-home/dashboard-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__fee_line_widget_fee_line_component__ = __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/fee-line-widget/fee-line.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__fee_pie_widget_fee_pie_component__ = __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/fee-pie-widget/fee-pie.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__fee_stackbar_widget_fee_stackbar_component__ = __webpack_require__("./src/app/components/fee-module/monitoring-dashboard/fee-stackbar-widget/fee-stackbar.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












var MonitoringDashboardModule = /** @class */ (function () {
    function MonitoringDashboardModule() {
    }
    MonitoringDashboardModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_6__monitoring_dashboard_routing_module__["a" /* MonitoringRoutingModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_7__monitoring_dashboard_component__["a" /* MonitoringDashboardComponent */],
                __WEBPACK_IMPORTED_MODULE_8__dashboard_home_dashboard_home_component__["a" /* DashboardHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_9__fee_line_widget_fee_line_component__["a" /* FeeLineComponent */],
                __WEBPACK_IMPORTED_MODULE_10__fee_pie_widget_fee_pie_component__["a" /* FeePieComponent */],
                __WEBPACK_IMPORTED_MODULE_11__fee_stackbar_widget_fee_stackbar_component__["a" /* FeeStackbarComponent */]
            ],
            entryComponents: [
                __WEBPACK_IMPORTED_MODULE_9__fee_line_widget_fee_line_component__["a" /* FeeLineComponent */],
                __WEBPACK_IMPORTED_MODULE_10__fee_pie_widget_fee_pie_component__["a" /* FeePieComponent */],
                __WEBPACK_IMPORTED_MODULE_11__fee_stackbar_widget_fee_stackbar_component__["a" /* FeeStackbarComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_5__services_monitoring_service__["a" /* monitoringService */]
            ]
        })
    ], MonitoringDashboardModule);
    return MonitoringDashboardModule;
}());



/***/ }),

/***/ "./src/app/components/fee-module/monitoring-dashboard/services/monitoring.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return monitoringService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var monitoringService = /** @class */ (function () {
    /* set default value for each url, header and autherization on service creation */
    function monitoringService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.institute_id = sessionStorage.getItem('institute_id');
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    monitoringService.prototype.fetchFeeStackMonitor = function () {
        var url = this.baseUrl + "/api/v1/studentWise/fee/students/highCharts/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (res) {
            return res;
        }, function (err) {
            return err;
        });
    };
    monitoringService.prototype.fetchFeeMonitor = function (obj) {
        var url = this.baseUrl + "/api/v1/studentWise/fee/students/highChartsRender";
        return this.http.post(url, obj, { headers: this.headers }).map(function (res) {
            return res;
        }, function (err) {
            return err;
        });
    };
    monitoringService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */], __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], monitoringService);
    return monitoringService;
}());



/***/ })

});
//# sourceMappingURL=monitoring-dashboard.module.chunk.js.map