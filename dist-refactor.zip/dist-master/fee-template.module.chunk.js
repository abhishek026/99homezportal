webpackJsonp(["fee-template.module"],{

/***/ "./src/app/components/fee-module/data-setup/fee-template/fee-template-add/fee-template-add.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n  </loaders-css>\r\n<div class=\"middle-section clearFix code-wrapper\">\r\n  <section class=\"middle-top mb0 clearFix\">\r\n    <h1 class=\"pull-left\" style=\"padding-left:7px;\">\r\n      <a routerLink=\"/view/fee/data-setup/fee-template/home\">\r\n        {{moduleState}} wise fees\r\n      </a>\r\n      <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n      Add Fee Template\r\n      <div class=\"questionInfo inline-relative\">\r\n        <span class=\"qInfoIcon i-class\">i</span>\r\n        <div class=\"tooltip-box-field md\">\r\n          Define Fee structure\r\n          <br>for a {{moduleState}} Fee.\r\n          <br>For e.g Single Installment\r\n          <br>or 2 installments or multiples\r\n        </div>\r\n      </div>\r\n    </h1>\r\n  </section>\r\n\r\n  <section class=\"middle-main clearFix\">\r\n\r\n    <section class=\"filler-setcion\">\r\n\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n          <div class=\"form-wrapper has-value\" *ngIf=\"isLangInstitute\">\r\n            <label for=\"masterCourse\">Master Course\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <select id=\"masterCourseDdn\" class=\"side-form-ctrl\" [(ngModel)]=\"addNewTemplate.master_course_name\" name=\"masterCourse\" (ngModelChange)=\"onMasterCourseSelection()\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let opt of masterCourseList\" [value]=\"opt.standard_id\">\r\n                {{opt.standard_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"form-wrapper has-value\" *ngIf=\"isLangInstitute\">\r\n            <label for=\"CourseDdn\">Course\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <select id=\"CourseDdn\" class=\"side-form-ctrl\" name=\"CourseDdn\" [(ngModel)]=\"addNewTemplate.course_id\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let opt of CourseList\" [value]=\"opt.subject_id\">\r\n                {{opt.subject_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"form-wrapper has-value\" *ngIf=\"!isLangInstitute\">\r\n            <label for=\"masterCourse\">Master Course\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <select id=\"masterCourseDdn\" class=\"side-form-ctrl\" [(ngModel)]=\"addNewTemplate.master_course_name\" name=\"masterCourse\" (ngModelChange)=\"onMasterCourseSelection()\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let opt of masterCourseList\" [value]=\"opt.master_course\">\r\n                {{opt.master_course}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"form-wrapper has-value\" *ngIf=\"!isLangInstitute\">\r\n            <label for=\"CourseDdn\">Course\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <select id=\"CourseDdn\" class=\"side-form-ctrl\" name=\"CourseDdn\" [(ngModel)]=\"addNewTemplate.course_id\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let opt of CourseList.coursesList\" [value]=\"opt.course_id\">\r\n                {{opt.course_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"form-wrapper has-value\">\r\n            <label for=\"CourseDdn\">Country\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <select id=\"CourseDdn\" class=\"side-form-ctrl\" name=\"CourseCountry\" [(ngModel)]=\"addNewTemplate.country_id\" (ngModelChange)=\"selectedCountryCode($event)\">\r\n              <option value=\"-1\"></option>\r\n              <option [value]=\"data.id\" selected *ngFor='let data of countryDetails'>\r\n                 {{data.country_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"field-checkbox-wrapper checkBoxAllignment\">\r\n            <input type=\"checkbox\" id=\"defTemplate\" name=\"checkbx\" [(ngModel)]=\"addNewTemplate.is_default_template\" class=\"form-checkbox\">\r\n            <label for=\"defTemplate\">Is Default Template\r\n              <div class=\"questionInfo inline-relative\">\r\n                <span class=\"qInfoIcon i-class\">i</span>\r\n                <div class=\"tooltip-box-field md\">\r\n                  Make this a default template\r\n                  <br>for the course\r\n                </div>\r\n              </div>\r\n            </label>\r\n          </div>\r\n\r\n          <div class=\"form-wrapper  has-value\">\r\n            <label for=\"templateName\">Template Name\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <input type=\"text\" class=\"side-form-ctrl\" [(ngModel)]=\"addNewTemplate.template_name\" name=\"templateName\">\r\n          </div>\r\n\r\n          <div class=\"form-wrapper has-value\">\r\n            <label for=\"feeAmount\">Fee Amount\r\n              <span class=\"text-danger\">*</span>\r\n              <div class=\"questionInfo inline-relative\">\r\n                <span class=\"qInfoIcon i-class\">i</span>\r\n                <div class=\"tooltip-box-field md\">\r\n                  Total fee amount defined\r\n                  <br> for the course\r\n                </div>\r\n              </div>\r\n            </label>\r\n            <input type=\"number\" min=\"0\" class=\"side-form-ctrl\" [(ngModel)]=\"addNewTemplate.fee_amount\" (keyup)=\"onAmountKeyUp()\" name=\"feeAmount\">\r\n          </div>\r\n\r\n          <div class=\"question-wrapper\" *ngIf=\"enableTaxOptions == '1' && addNewTemplate.country_id=='1' \">\r\n            <fieldset>\r\n              <legend>\r\n                <div class=\"question\">\r\n                  <h3>Is Fee Amount</h3>\r\n                </div>\r\n              </legend>\r\n              <div class=\"field-radio-wrapper\">\r\n                <input type=\"radio\" name=\"inclusive\" class=\"form-radio\" [(ngModel)]=\"addNewTemplate.tax_type\" (ngModelChange)=\"onTaxTypeChanges($event)\"\r\n                  value=\"inclusive\" id=\"idInclusive\">\r\n                <label for=\"idInclusive\">Inclusive Of Tax</label>\r\n              </div>\r\n              <div class=\"field-radio-wrapper\">\r\n                <input type=\"radio\" name=\"exclusive\" class=\"form-radio\" [(ngModel)]=\"addNewTemplate.tax_type\" (ngModelChange)=\"onTaxTypeChanges($event)\"\r\n                  value=\"exclusive\" id=\"idExclusive\">\r\n                <label for=\"idExclusive\">Exclusive Of Tax</label>\r\n              </div>\r\n            </fieldset>\r\n          </div>\r\n\r\n          <!-- <div class=\"form-wrapper has-value\">\r\n            <label for=\"taxType\">Tax Type</label>\r\n            <select id=\"\" class=\"side-form-ctrl\" name=\"taxType\" [(ngModel)]=\"addNewTemplate.tax_type\" (click)=\"onTaxTypeChanges()\">\r\n              <option *ngIf=\"enableTaxOptions != '1'\" value=\"1\">Tax Out Of Scope</option>\r\n              <option *ngIf=\"enableTaxOptions == '1'\" value=\"2\">Total Fee Including Tax</option>\r\n              <option *ngIf=\"enableTaxOptions == '1'\" value=\"3\">Total Fee Excluding Tax</option>\r\n            </select>\r\n          </div> -->\r\n\r\n          <!-- <div class=\"field-checkbox-wrapper checkBoxAllignment\">\r\n            <input type=\"checkbox\" id=\"\" name=\"checkbx\" [disabled]=\"addNewTemplate.apply_tax == true && addNewTemplate.tax_type != 1\"\r\n              [(ngModel)]=\"addNewTemplate.apply_tax\" class=\"form-checkbox\">\r\n            <label for=\"checkbx\">Apply Tax ({{feeStructure.registeredServiceTax}}%)</label>\r\n          </div> -->\r\n\r\n          <div class=\"spanSection\">\r\n            <span *ngIf=\"enableTaxOptions == '1'&& addNewTemplate.country_id=='1'\" class=\"\">Tax Amount :\r\n              <span *ngIf=\"selectedCountry\">\r\n                <img src=\"{{selectedCountry?.currency_symbol}}\" style=\"max-height: 12px\" />\r\n              </span> {{addNewTemplate.tax_amount}}</span>\r\n            <br>\r\n            <span class=\"\">Total Fees :\r\n              <span *ngIf=\"selectedCountry\">\r\n                <img style=\"\" src=\"{{selectedCountry?.currency_symbol}}\" style=\"max-height: 12px\" />\r\n              </span>{{addNewTemplate.total_fee}}</span>\r\n          </div>\r\n\r\n          <div class=\"form-wrapper has-value\">\r\n            <label for=\"installment\">Total Number of Installment\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <input type=\"number\" min=\"0\" class=\"side-form-ctrl\" name=\"installment\" [(ngModel)]=\"addNewTemplate.installmentCount\">\r\n          </div>\r\n\r\n          <button class=\"btn\" routerLink=\"/view/fee/data-setup/fee-template/home\">Cancel</button>\r\n          <button class=\"btn fullBlue\" (click)=\"createInstallment()\">Create Installment</button>\r\n\r\n        </div>\r\n      </div>\r\n\r\n    </section>\r\n\r\n    <hr>\r\n\r\n    <section class=\"installment-section\" *ngIf=\"showDetails\">\r\n\r\n      <section class=\"installmentSection\">\r\n        <h3 style=\"margin-bottom:10px;\">Manage Installments</h3>\r\n        <div class=\"table-scroll-wrapper\">\r\n          <div class=\"table table-responsive\">\r\n            <table>\r\n              <thead>\r\n                <tr>\r\n                  <th> # </th>\r\n                  <th>Trigger Date</th>\r\n                  <th>No.(Days/Months)</th>\r\n                  <th>Country </th>\r\n                  <th  *ngIf=\"addNewTemplate.country_id=='1'\">Fees Amount\r\n                    <span *ngIf=\"selectedCountry\">(\r\n                      <img src=\"{{selectedCountry?.currency_symbol}}\" style=\"max-height: 9px\" />)</span>\r\n                  </th>\r\n                  <th *ngIf=\"addNewTemplate.country_id=='1'\">Tax\r\n                    <span *ngIf=\"selectedCountry\">\r\n                      (\r\n                      <img src=\"{{selectedCountry?.currency_symbol}}\" style=\"max-height: 9px\" />)</span>\r\n                  </th>\r\n                  <th>Fees Amount\r\n                    <span *ngIf=\"addNewTemplate.country_id=='1'\"> (Incl Tax)</span>\r\n                    <span *ngIf=\"selectedCountry\">\r\n                      (\r\n                      <img src=\"{{selectedCountry?.currency_symbol}}\" style=\"max-height: 9px\" />)</span>\r\n                  </th>\r\n                </tr>\r\n              </thead>\r\n              <tbody>\r\n                <tr *ngFor=\"let row of installMentTable; let i= index ; trackBy : index\">\r\n                  <td>\r\n                    {{i + 1}} </td>\r\n                  <td>\r\n                    <div class=\"form-wrapper\">\r\n                      <select [(ngModel)]=\"row.day_type\" (ngModelChange)=\"changesValuesAsPerType(row)\" style=\"background: transparent\" class=\"side-form-ctrl\">\r\n                        <option value=\"1\">Course Assign Date (CAD)</option>\r\n                        <option value=\"2\">No of days after CAD</option>\r\n                        <option value=\"3\">No of Month after CAD</option>\r\n                      </select>\r\n                    </div>\r\n                  </td>\r\n                  <td>\r\n                    <div class=\"form-wrapper\" style=\"background: transparent;\">\r\n                      <input type=\"number\" min=\"0\" style=\"background: transparent;\" [disabled]=\"row.day_type=='1'\" [ngClass]=\"{'disable_input': row.day_type=='1'}\"  class=\"editCellInput\" [(ngModel)]=\"row.days\" name=\"label\" class=\"side-form-ctrl\">\r\n                    </div>\r\n                  </td>\r\n                  <td>\r\n                    <div class=\"form-wrapper\">\r\n                      <select id=\"CourseDdn\" style=\"background: transparent;margin: 5px 0px; \r\n                        width: 100%;\" disabled class=\"side-form-ctrl disable_input\" name=\"CourseCountry\" [(ngModel)]=\"row.country_id\">\r\n                        <option value=\"-1\"></option>\r\n                        <option [value]=\"data.id\"  selected *ngFor='let data of countryDetails'>\r\n                           {{data.country_name}}\r\n                        </option>\r\n                      </select>\r\n                    </div>\r\n                  </td>\r\n                  <td  *ngIf=\"addNewTemplate.country_id=='1'\">\r\n                    <div class=\"form-wrapper\">\r\n                      <input type=\"number\" style=\"background: transparent\" min=\"0\" [readonly]=\"addNewTemplate.tax_type == 'inclusive'\" class=\"editCellInput side-form-ctrl\"\r\n                        [(ngModel)]=\"row.initial_fee_amount\" (ngModelChange)=\"userChangedInitialAmount(row ,$event)\" name=\"label\">\r\n                    </div>\r\n                  </td>\r\n                  <td *ngIf=\"addNewTemplate.country_id=='1'\"x>\r\n                    <div class=\"form-wrapper\">\r\n                      <input type=\"number\" min=\"0\" readonly=\"true\" class=\"editCellInput side-form-ctrl\" style=\"background: transparent\" [ngModel]='row.tax'\r\n                        name=\"label\">\r\n                    </div>\r\n                  </td>\r\n                  <td>\r\n                    <div class=\"form-wrapper\" style=\"background: transparent;\">\r\n                      <input type=\"number\" min=\"0\" style=\"background: transparent;\" [readonly]=\"addNewTemplate.tax_type == 'exclusive'\" class=\"editCellInput\" (keyup)=\"userChangedAmountTotalAmount(row ,$event)\"\r\n                        [(ngModel)]=\"row.totalAmount\" name=\"label\" class=\"side-form-ctrl\">\r\n                    </div>\r\n                  </td>\r\n                </tr>\r\n              </tbody>\r\n            </table>\r\n          </div>\r\n        </div>\r\n        <span style=\"margin-top:20px;\">* Sum of final amount should match with defined fee amount.</span>\r\n      </section>\r\n      <hr>\r\n      <section class=\"additionalFeeSection\">\r\n        <h3>Manage Additional Fees</h3>\r\n\r\n        <div class=\"row\">\r\n          <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n            <div class=\"form-wrapper has-value\">\r\n              <label for=\"row.category_id\">Select Fee Type</label>\r\n              <select id=\"\" class=\"side-form-ctrl\" style=\"background: transparent\" [(ngModel)]=\"additionalInstallment.fee_type\" (ngModelChange)=\"onAdditionalFeeSelection($event)\"\r\n                name=\"row.category_id\">\r\n                <option *ngFor=\"let opt of otherFeetype; let i= index ; trackBy : index\" [value]=\"opt.id\">\r\n                  {{opt.value}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n            <div class=\"form-wrapper has-value\">\r\n              <label for=\"row.category_id\">Trigger Date</label>\r\n              <select id=\"\" class=\"side-form-ctrl\" style=\"background: transparent\" [(ngModel)]=\"additionalInstallment.day_type\" (ngModelChange)=\"changesValuesAsPerType(additionalInstallment)\" name=\"row.category_id\">\r\n                <option value=\"1\">Course Assign Date (CAD)</option>\r\n                <option value=\"2\">No of days after CAD</option>\r\n                <option value=\"3\">No of Month after CAD</option>\r\n              </select>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n            <div class=\"form-wrapper has-value\">\r\n              <label for=\"slotNew\"> No. (Days/Months)\r\n              </label>\r\n              <input type=\"number\" min=\"0\" style=\"background: transparent;\" class=\"side-form-ctrl\" [disabled]=\"additionalInstallment.day_type=='1'\" [ngClass]=\"{'disable_input': additionalInstallment.day_type=='1'}\" [(ngModel)]=\"additionalInstallment.days\"\r\n                name=\"slotNew\">\r\n            </div>\r\n          </div>\r\n          <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n            <div class=\"form-wrapper has-value\">\r\n              <label for=\"row.country_id\">Country</label>\r\n              <select disabled class=\"side-form-ctrl disable_input\"  [(ngModel)]=\"additionalInstallment.country_id\" \r\n                name=\"row.country_id\">\r\n                <option value=\"-1\"></option>\r\n                <option [value]=\"data.id\" selected *ngFor='let data of countryDetails'>\r\n                   {{data.country_name}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n          </div>\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3\" *ngIf=\"addNewTemplate.country_id!='1'\">\r\n            <div class=\"c-sm-5 c-md-5 c-lg-5 form-wrapper has-value\">\r\n              <label for=\"slotNew\">Fee Amount\r\n              </label>\r\n              <input type=\"number\" style=\"background: transparent;\" min=\"0\" class=\"side-form-ctrl\" [(ngModel)]=\"additionalInstallment.initial_fee_amount\"\r\n                name=\"slotNew\">  \r\n            </div>\r\n          </div>\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3\" *ngIf=\"addNewTemplate.country_id=='1'\">\r\n            <div class=\"row\">\r\n              <div class=\"c-sm-5 c-md-5 c-lg-5 form-wrapper has-value\" style=\" width: 40%;\">\r\n                <label for=\"slotNew\">Fee Amount\r\n                </label>\r\n                <input type=\"number\" style=\"background: transparent;\" min=\"0\" class=\"side-form-ctrl\" [(ngModel)]=\"additionalInstallment.initial_fee_amount\"\r\n                  name=\"slotNew\">  \r\n              </div>\r\n              <div class=\"c-sm-7 c-md-7 c-lg-7  form-wrapper has-value\"  style=\" width: 60%;\" >\r\n                <label for=\"slotNew\">Tax Applicable (%)\r\n                </label>\r\n                <input type=\"number\" min=\"0\"  disabled class=\"side-form-ctrl disable_input\" [(ngModel)]=\"additionalInstallment.service_tax\"\r\n                  name=\"slotNew\">\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"c-sm-1 c-md-1 c-lg-1\" style=\"margin-top:20px;cursor: pointer;\">\r\n            <img src=\"assets/images/plus.png\" (click)=\"addAdditionalInst()\" alt=\"Add\" style=\"vertical-align: -webkit-baseline-middle;\">\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"table-scroll-wrapper\">\r\n          <div class=\"table table-responsive\">\r\n            <table>\r\n              <thead>\r\n                <tr>\r\n                  <th>Fee Type </th>\r\n                  <th>Trigger Date</th>\r\n                  <th>No.(Days/Months)Due Date</th>\r\n                  <th>Country </th>\r\n                  <th *ngIf=\"addNewTemplate.country_id=='1'\">Amount</th>\r\n                  <th *ngIf=\"addNewTemplate.country_id=='1'\">Tax</th>\r\n                  <th *ngIf=\"addNewTemplate.country_id!='1'\">Fee Amount</th>\r\n                  <th *ngIf=\"addNewTemplate.country_id=='1'\">Fee Amount Incl Tax</th>\r\n                  <th>Action</th>\r\n                </tr>\r\n              </thead>\r\n              <tbody>\r\n                <tr *ngFor=\"let row of otherInstList; let i= index ; trackBy : index\">\r\n                  <td>\r\n                    {{row.fee_type_name}}\r\n                  </td>\r\n                  <td>\r\n                    <div class=\"form-wrapper\">\r\n                      <select [(ngModel)]=\"row.day_type\" style=\"background: transparent\" (ngModelChange)=\"changesValuesAsPerType(row)\" class=\"side-form-ctrl\">\r\n                        <option value=\"1\">Course Assign Date (CAD)</option>\r\n                        <option value=\"2\">No of days after CAD</option>\r\n                        <option value=\"3\">No of Month after CAD</option>\r\n                      </select>\r\n                    </div>\r\n                  </td>\r\n                  <td>\r\n                    <div class=\"form-wrapper\">\r\n                      <input type=\"number\" style=\"background: transparent\" min=\"0\" [disabled]=\"row.day_type=='1'\" [ngClass]=\"{'disable_input': row.day_type=='1'}\" class=\"editCellInput\" [(ngModel)]=\"row.days\" name=\"label\" class=\"side-form-ctrl\">\r\n                    </div>\r\n                  </td>\r\n                  <td>\r\n                    <div class=\"form-wrapper\">\r\n                      <select disabled style=\"width:100%;\" id=\"CourseDdn\" class=\"side-form-ctrl disable_input\" name=\"CourseCountry\" [(ngModel)]=\"row.country_id\">\r\n                        <option value=\"-1\"></option>\r\n                        <option [value]=\"data.id\" selected *ngFor='let data of countryDetails'>\r\n                           {{data.country_name}}\r\n                        </option>\r\n                      </select>\r\n                    </div>\r\n                  </td>\r\n                  <td *ngIf=\"addNewTemplate.country_id=='1'\">\r\n                    <div class=\"form-wrapper\">\r\n                      <input type=\"number\" min=\"0\" style=\"background: transparent\" readonly=\"true\" class=\"editCellInput side-form-ctrl\" [(ngModel)]=\"row.initial_fee_amount\"\r\n                        name=\"label\">\r\n                    </div>\r\n                  </td>\r\n                  <td *ngIf=\"addNewTemplate.country_id=='1'\">\r\n                    <div class=\"form-wrapper\">\r\n                      <input type=\"number\" min=\"0\" style=\"background: transparent\" readonly=\"true\" class=\"editCellInput side-form-ctrl\" [ngModel]='row.fees_amount - row.initial_fee_amount'\r\n                        name=\"label\">\r\n                    </div>\r\n                  </td>\r\n                  <td>\r\n                    <div class=\"form-wrapper\">\r\n                      <input type=\"number\" min=\"0\" style=\"background: transparent\" class=\"editCellInput\" (keyup)=\"userChangeAdditionalFeeAmount(row , $event)\"\r\n                        [(ngModel)]=\"row.fees_amount\" name=\"label\" class=\"side-form-ctrl\">\r\n                    </div>\r\n                  </td>\r\n                  <td>\r\n                    <a style=\"cursor: pointer\" (click)=\"deleteAdditionalRow(row , i)\">\r\n                      <i class=\"fa fa-trash\" style=\"font-size: 17px;  color:red;margin-right: 10px;cursor: pointer;\" title=\"Delete\"></i>\r\n                    </a>\r\n                  </td>\r\n                </tr>\r\n                <tr *ngIf=\"otherInstList.length == 0\">\r\n                  <td colspan=\"8\">\r\n                    No Additional Installment\r\n                  </td>\r\n                </tr>\r\n              </tbody>\r\n            </table>\r\n          </div>\r\n        </div>\r\n\r\n      </section>\r\n\r\n      <section class=\"btnGroup pull-right\">\r\n        <button routerLink=\"/view/fee/data-setup/fee-template/home\" class=\"btn\">Back</button>\r\n        <button (click)=\"createFeeTemplate()\" class=\"btn fullBlue\">Create</button>\r\n      </section>\r\n\r\n    </section>\r\n\r\n  </section>\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/fee-template-add/fee-template-add.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  border-radius: 5px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.middle-section ::-webkit-scrollbar {\n    display: block; }\n.middle-main .row {\n  margin: 5px -15px; }\n.middle-main .editCellInput {\n  background: transparent; }\n.middle-main .filler-setcion .checkBoxAllignment {\n  margin-left: 10px; }\n.middle-main .filler-setcion .question-wrapper {\n  margin-left: 10px; }\n.middle-main .filler-setcion .spanSection span {\n  font-weight: 600;\n  margin-left: 5px;\n  padding-left: 8px;\n  margin: 10px 0px; }\n.middle-main .installment-section {\n  margin-top: 10px;\n  border-top: 2px solid #efefef; }\n.middle-main .installment-section .installmentSection {\n    margin-bottom: 10px; }\n.middle-main .installment-section .installmentSection h3 {\n      margin-top: 10px; }\n.middle-main .installment-section .additionalFeeSection {\n    border-top: 2px solid #efefef; }\n.middle-main .installment-section .additionalFeeSection h3 {\n      margin-top: 10px; }\n.middle-main .installment-section .btnGroup {\n    margin-top: 10px !important; }\n.row .btn {\n  float: right;\n  margin-right: 20px; }\n.code-wrapper {\n  background-color: #efefef;\n  border-radius: 6px;\n  max-height: 900px;\n  overflow: scroll; }\n.field-wrapper .form-ctrl {\n  background: transparent; }\ninput[type=number]::-webkit-inner-spin-button,\ninput[type=number]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0; }\n.table-scroll-wrapper table thead tr th {\n  padding: 10px 10px;\n  margin: 0px 0px; }\n.table-scroll-wrapper table tbody tr td {\n  margin: 0px 0px;\n  text-align: center;\n  padding: 10px 10px; }\n.form-wrapper {\n  background: transparent;\n  margin: 5px 0px;\n  width: 100%; }\n.form-wrapper.datepicker {\n    padding-top: 3px; }\n.form-wrapper.datepicker span {\n      position: relative;\n      right: 25px;\n      font-weight: 600;\n      font-size: 16px;\n      color: red;\n      cursor: pointer;\n      width: 20px;\n      text-align: center;\n      /* &::before {\r\n                content: '';\r\n                background: url('/assets/images/calendar.svg') no-repeat;\r\n                position: absolute;\r\n                right: 25px;\r\n                top: 0px;\r\n                width: 21px;\r\n                height: 21px;\r\n                z-index: 0;\r\n            } */ }\n.form-wrapper label {\n    padding-left: 10px;\n    font-size: 12px;\n    font-weight: 400;\n    color: 0084f6;\n    text-decoration: none;\n    -webkit-font-smoothing: antialiased;\n    width: 100%; }\n.form-wrapper .side-form-ctrl {\n    background: white;\n    border: 1px solid rgba(119, 119, 119, 0.419608);\n    width: 60%;\n    padding-left: 10px;\n    margin-left: 10px;\n    height: 30px;\n    padding: 0px 5px;\n    font-weight: 600;\n    font-size: 14px;\n    color: black; }\n.form-wrapper .side-form-ctrl.bsDatepicker {\n      width: 60%; }\n.form-wrapper.timepick {\n    width: 100%;\n    padding-top: 0px; }\n.form-wrapper.timepick .tbox {\n      width: 100%; }\n.form-wrapper.timepick .tbox .times {\n        display: inline-block; }\n.form-wrapper.timepick .tbox .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        padding: 0px 5px;\n        font-weight: 600;\n        font-size: 14px;\n        color: black; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mins {\n          width: 100%; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mers {\n          width: 100%; }\nhr {\n  display: block;\n  margin-top: 0.5em;\n  margin-bottom: 0.5em;\n  margin-left: auto;\n  margin-right: auto;\n  border-style: inset;\n  border-width: 1px; }\n.question-wrapper .field-radio-wrapper .form-radio:checked + label:before {\n  left: 3px;\n  top: 3px; }\n.disable_input {\n  background: lightgrey !important;\n  cursor: not-allowed; }\n.qInfoIcon {\n  width: 20px;\n  margin-left: 5px;\n  height: 20px;\n  border: 1px solid #ccc;\n  border-radius: 50%;\n  display: block;\n  text-align: center;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  line-height: 20px;\n  font-weight: 600;\n  font-size: 12px;\n  cursor: pointer;\n  -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n          box-shadow: 0px 0px 1px 0px #ccc inset;\n  color: #888;\n  -webkit-transition: all 0.2s linear;\n  transition: all 0.2s linear; }\n.qInfoIcon:hover {\n    border-color: #0060A3;\n    -webkit-box-shadow: 0px 0px 1px 0px #0060A3 inset;\n            box-shadow: 0px 0px 1px 0px #0060A3 inset;\n    color: #0060A3; }\n.tooltip-box-field {\n  width: 170px;\n  white-space: nowrap;\n  min-height: 41px;\n  line-height: 18px;\n  padding: 5px 5px;\n  overflow: visible;\n  color: black;\n  font-weight: bold; }\n.tooltip-box-field.lg {\n    width: 200px;\n    white-space: nowrap;\n    min-height: 50px;\n    line-height: 20px;\n    padding: 5px 5px; }\n.tooltip-box-field.sm {\n    width: 100px;\n    white-space: nowrap;\n    min-height: 40px;\n    padding: 5px 5px; }\n"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/fee-template-add/fee-template-add.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FeeTemplateAddComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_feeStruc_service__ = __webpack_require__("./src/app/services/feeStruc.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var FeeTemplateAddComponent = /** @class */ (function () {
    function FeeTemplateAddComponent(apiService, route, auth, commonService) {
        this.apiService = apiService;
        this.route = route;
        this.auth = auth;
        this.commonService = commonService;
        this.isRippleLoad = false;
        this.masterCourseList = [];
        this.CourseList = [];
        this.countryAdditioalFeeTypes = {};
        this.addNewTemplate = {
            template_name: '',
            fee_amount: "",
            master_course_name: '',
            course_id: -1,
            tax_type: "inclusive",
            apply_tax: false,
            tax_amount: 0,
            total_fee: 0,
            installmentCount: '',
            is_default_template: false,
            country_id: -1
        };
        this.additionalInstallment = {
            days: 0,
            day_type: 1,
            fee_type: -1,
            fees_amount: 0,
            initial_fee_amount: 0,
            is_referenced: 'N',
            schedule_id: 0,
            service_tax: 0,
            service_tax_applicable: 'N',
            fee_type_name: '',
            country_id: -1
        };
        this.feeStructure = [];
        this.installMentTable = [];
        this.otherInstList = [];
        this.otherFeetype = [];
        this.countryDetails = [];
        this.totalAmount = 0;
        this.discountAmount = 0;
        this.showDetails = false;
        this.enableTaxOptions = 0;
        this.isLangInstitute = false;
    }
    FeeTemplateAddComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isLangInstitute = true;
                _this.moduleState = 'Batch';
            }
            else {
                _this.isLangInstitute = false;
                _this.moduleState = 'Course';
            }
        });
        this.enableTaxOptions = sessionStorage.getItem('enable_tax_applicable_fee_installments');
        this.getAllMasterCourseList();
        this.getDetailOfFeeStructur();
        this.fetchDataForCountryDetails();
    };
    FeeTemplateAddComponent.prototype.changesValuesAsPerType = function (row) {
        if (row.day_type == 1) {
            row.days = 0;
        }
    };
    FeeTemplateAddComponent.prototype.fetchDataForCountryDetails = function () {
        var _this = this;
        this.countryAdditioalFeeTypes = {};
        var encryptedData = sessionStorage.getItem('country_data');
        var data = JSON.parse(encryptedData);
        if (data.length > 0) {
            this.countryDetails = data;
            var country_ids_1 = [];
            this.countryDetails.forEach(function (item) {
                _this.countryAdditioalFeeTypes[item.id] = [];
                country_ids_1.push(item.id);
            });
            this.apiService.additionalFeeTypeDetail(country_ids_1.join()).subscribe(function (res) {
                res && res.forEach(function (fee) {
                    var country_id = fee.countryId.country_id;
                    var fee_details = {};
                    fee_details[fee.fee_type_id] = fee.fee_type;
                    _this.countryAdditioalFeeTypes[country_id].push(fee_details);
                });
            }, function (err) {
                _this.commonService.showErrorMessage('error', '', err.error.message);
            });
        }
        // console.log(data);
    };
    FeeTemplateAddComponent.prototype.getDetailOfFeeStructur = function () {
        var _this = this;
        this.apiService.fetchFeeDetail(0).subscribe(function (res) {
            _this.feeStructure = res;
        }, function (err) {
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    FeeTemplateAddComponent.prototype.getAllMasterCourseList = function () {
        var _this = this;
        if (this.isLangInstitute) {
            this.apiService.getAllStandard().subscribe(function (res) {
                _this.masterCourseList = res;
            }, function (err) {
                //console.log(err);
            });
        }
        else {
            this.apiService.getMasterCourse().subscribe(function (res) {
                _this.masterCourseList = res;
            }, function (err) {
                _this.commonService.showErrorMessage('error', '', err.error.message);
            });
        }
    };
    FeeTemplateAddComponent.prototype.onMasterCourseSelection = function () {
        var _this = this;
        this.CourseList = [];
        if (this.addNewTemplate.master_course_name != "-1") {
            if (this.isLangInstitute) {
                this.apiService.getCoursesOfStandard(this.addNewTemplate.master_course_name).subscribe(function (res) {
                    _this.CourseList = res;
                }, function (err) {
                    //console.log(err);
                });
            }
            else {
                this.apiService.getCourse(this.addNewTemplate.master_course_name).subscribe(function (res) {
                    _this.CourseList = res;
                }, function (err) {
                    _this.commonService.showErrorMessage('error', '', err.error.message);
                });
            }
        }
    };
    FeeTemplateAddComponent.prototype.onAmountKeyUp = function () {
        switch (this.addNewTemplate.tax_type) {
            case 'inclusive': {
                this.calculateAmount(true);
                break;
            }
            case 'exclusive': {
                this.calculateAmount(false);
                break;
            }
        }
    };
    FeeTemplateAddComponent.prototype.onTaxTypeChanges = function () {
        switch (this.addNewTemplate.tax_type) {
            case 'inclusive': {
                this.addNewTemplate.apply_tax = true;
                this.calculateAmount(true);
                break;
            }
            case 'exclusive': {
                this.addNewTemplate.apply_tax = true;
                this.calculateAmount(false);
                break;
            }
        }
    };
    FeeTemplateAddComponent.prototype.calculateAmount = function (taxInclusive) {
        if (taxInclusive == true) {
            this.addNewTemplate.tax_amount = Math.floor(Number(this.addNewTemplate.fee_amount)) - Math.floor(Number(this.addNewTemplate.fee_amount) * 100 / (100 + this.feeStructure.registeredServiceTax));
            this.addNewTemplate.total_fee = Number(this.addNewTemplate.fee_amount);
        }
        else {
            this.addNewTemplate.tax_amount = Math.floor(Number(this.addNewTemplate.fee_amount) * (this.feeStructure.registeredServiceTax) * .01);
            this.addNewTemplate.total_fee = Number(this.addNewTemplate.fee_amount + this.addNewTemplate.tax_amount);
        }
    };
    FeeTemplateAddComponent.prototype.createInstallment = function () {
        this.onTaxTypeChanges();
        var check = this.validateAllFields();
        if (!check) {
            this.showDetails = false;
            return;
        }
        this.showDetails = true;
        this.createInstallmentTable();
    };
    // set editional fee as per country --laxmi 
    FeeTemplateAddComponent.prototype.selectedCountryCode = function (country_id) {
        var _this = this;
        this.selectedCountry = null;
        this.otherInstList = [];
        this.showDetails = false;
        this.countryDetails.forEach(function (country) {
            if (country.id == Number(country_id)) {
                _this.selectedCountry = country;
            }
        });
        console.log(this.selectedCountry);
        this.fillFeeType(this.countryAdditioalFeeTypes[country_id]);
        this.clearManageFee();
        this.additionalInstallment.country_id = this.addNewTemplate.country_id = country_id;
        this.addNewTemplate.tax_type = 'inclusive';
        this.calculateAmount(true);
        this.installMentTable && this.installMentTable.length && this.installMentTable.forEach(function (installement) {
            installement.country_id = country_id;
        });
        if (this.otherFeetype[0]) {
            this.onAdditionalFeeSelection(this.otherFeetype[0].id);
        }
    };
    FeeTemplateAddComponent.prototype.createInstallmentTable = function () {
        this.installMentTable = [];
        var amount = Math.floor(Number(this.addNewTemplate.fee_amount) / Number(this.addNewTemplate.installmentCount));
        var tax_amount = Math.floor(this.addNewTemplate.tax_amount / Number(this.addNewTemplate.installmentCount));
        var totalAmount = 0;
        var taxAmount = 0;
        var obj = [];
        this.additionalInstallment.country_id = this.addNewTemplate.country_id;
        for (var i = 0; i < Number(this.addNewTemplate.installmentCount); i++) {
            var test = {};
            test.day_type = 1;
            test.days = 0;
            if (this.enableTaxOptions == "1" && this.addNewTemplate.country_id == 1) {
                if (this.addNewTemplate.tax_type == "inclusive") {
                    test.initial_fee_amount = amount - tax_amount;
                    test.tax = tax_amount;
                }
                else {
                    test.initial_fee_amount = amount;
                    test.tax = tax_amount;
                }
                test.service_tax_applicable = "Y";
            }
            else {
                test.initial_fee_amount = amount;
                test.tax = 0;
            }
            test.totalAmount = test.tax + test.initial_fee_amount;
            taxAmount = taxAmount + test.tax;
            totalAmount = totalAmount + test.totalAmount;
            test.country_id = Number(this.addNewTemplate.country_id);
            obj.push(test);
        }
        if (Number(this.addNewTemplate.total_fee) != totalAmount) {
            var lastInstallment = obj[obj.length - 1];
            lastInstallment.totalAmount = lastInstallment.totalAmount + Number(this.addNewTemplate.total_fee) - totalAmount;
            if (this.enableTaxOptions == '1' && this.addNewTemplate.country_id == 1) {
                lastInstallment.initial_fee_amount = Math.floor(Number(lastInstallment.totalAmount * 100 / (100 + this.feeStructure.registeredServiceTax)));
                lastInstallment.tax = lastInstallment.totalAmount - lastInstallment.initial_fee_amount;
            }
            else {
                lastInstallment.tax = 0;
                lastInstallment.initial_fee_amount = lastInstallment.totalAmount;
            }
            obj[obj.length - 1] = lastInstallment;
        }
        // if (Number(this.addNewTemplate.tax_amount) != taxAmount) {
        //   let length = obj.length;
        //   obj[length - 1].tax = obj[length - 1].tax + Number(this.addNewTemplate.tax_amount) - taxAmount;
        // }
        this.installMentTable = obj;
    };
    FeeTemplateAddComponent.prototype.onAdditionalFeeSelection = function (event) {
        var _this = this;
        var id = event;
        this.apiService.getAdditionalFeeDeatails(event).subscribe(function (res) {
            _this.additionalInstallment.initial_fee_amount = res.fee_amount;
            _this.additionalInstallment.service_tax = res.fee_type_tax;
            _this.additionalInstallment.fee_type = res.fee_type_id;
            _this.additionalInstallment.country_id = _this.addNewTemplate.country_id;
            if (res.fee_type_tax > 0) {
                _this.additionalInstallment.service_tax_applicable = "Y";
            }
            _this.additionalInstallment.fee_type = id;
            _this.additionalInstallment.fees_amount = res.fee_amount + (res.fee_amount * res.fee_type_tax * 0.01);
            _this.additionalInstallment.fee_type_name = res.fee_type;
        }, function (err) {
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    FeeTemplateAddComponent.prototype.validateAllFields = function () {
        if (this.addNewTemplate.template_name == "" || null) {
            this.commonService.showErrorMessage('error', '', 'Template name can not be null');
            return false;
        }
        if (this.addNewTemplate.fee_amount == "" || 0) {
            this.commonService.showErrorMessage('error', '', 'Please enter valid amount');
            return false;
        }
        if (this.addNewTemplate.installmentCount == "" || 0) {
            this.commonService.showErrorMessage('error', '', 'Installment Count can not be zero');
            return false;
        }
        if (this.addNewTemplate.is_default_template) {
            if (this.addNewTemplate.master_course_name == "" || this.addNewTemplate.course_id == -1) {
                this.commonService.showErrorMessage('error', '', 'Please enter Master Course and Course to use is default template.');
                return false;
            }
        }
        return true;
    };
    FeeTemplateAddComponent.prototype.addAdditionalInst = function () {
        if (this.additionalInstallment.fee_type == -1) {
            this.commonService.showErrorMessage('error', '', 'Please Select Fee Type');
            return;
        }
        if (Number(this.additionalInstallment.initial_fee_amount) > 0) {
            if (this.additionalInstallment.fees_amount == 0) {
                if (this.additionalInstallment.service_tax == 0) {
                    this.additionalInstallment.fees_amount = this.additionalInstallment.initial_fee_amount;
                }
            }
            else {
                if (this.additionalInstallment.service_tax == 0) {
                    this.additionalInstallment.fees_amount = this.additionalInstallment.initial_fee_amount;
                }
                else {
                    this.additionalInstallment.fees_amount = Math.round(Number(this.additionalInstallment.initial_fee_amount) + Number((this.additionalInstallment.initial_fee_amount * this.additionalInstallment.service_tax) / 100));
                }
            }
            this.otherInstList.push(this.additionalInstallment);
            this.clearManageFee();
        }
    };
    FeeTemplateAddComponent.prototype.clearManageFee = function () {
        this.additionalInstallment = {
            days: 0,
            day_type: 1,
            fee_type: -1,
            fees_amount: 0,
            initial_fee_amount: 0,
            is_referenced: 'N',
            schedule_id: 0,
            service_tax: 0,
            service_tax_applicable: 'N',
            fee_type_name: '',
            country_id: this.additionalInstallment.country_id
        };
    };
    FeeTemplateAddComponent.prototype.fillFeeType = function (data) {
        var _this = this;
        this.otherFeetype = [];
        data.forEach(function (object) {
            var keys = Object.keys(object);
            var test = {};
            test.id = keys[0];
            test.value = object[keys[0]];
            _this.otherFeetype.push(test);
        });
    };
    FeeTemplateAddComponent.prototype.createFeeTemplate = function () {
        var _this = this;
        var tax;
        var defaultValue;
        if (this.addNewTemplate.is_default_template) {
            defaultValue = '1';
        }
        else {
            defaultValue = '0';
        }
        if (this.addNewTemplate.apply_tax && this.addNewTemplate.country_id == 1) {
            tax = "Y";
        }
        else {
            tax = "N";
        }
        var feeSch = this.makeJSONForCustomFee();
        if (feeSch == false) {
            return;
        }
        var data = {
            is_default: defaultValue,
            country_id: this.addNewTemplate.country_id,
            customFeeSchedules: feeSch,
            studentwise_total_fees_amount: this.totalAmount.toString(),
            studentwise_total_fees_discount: 0,
            studentwise_fees_tax_applicable: tax,
            template_id: 0,
            template_name: this.addNewTemplate.template_name
        };
        if (this.isLangInstitute) {
            data.course_id = '-1';
            data.subject_id = this.addNewTemplate.course_id;
        }
        else {
            data.course_id = this.addNewTemplate.course_id;
        }
        if (!this.isRippleLoad) {
            this.isRippleLoad = true;
            this.apiService.updateFeeTemplate(data).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.commonService.showErrorMessage('success', 'Updated', 'Fee Structure created Successfully');
                _this.route.navigateByUrl('/view/fee/data-setup/fee-template/home');
            }, function (err) {
                _this.isRippleLoad = false;
                _this.commonService.showErrorMessage('error', '', err.error.message);
            });
        }
    };
    FeeTemplateAddComponent.prototype.makeJSONForCustomFee = function () {
        this.totalAmount = 0;
        var data = [];
        var registeredServiceTax = 0;
        if (this.addNewTemplate.apply_tax && this.addNewTemplate.country_id == 1) {
            registeredServiceTax = this.feeStructure.registeredServiceTax;
        }
        for (var t = 0; t < this.installMentTable.length; t++) {
            var test = {};
            test.fee_type = 0;
            test.initial_fee_amount = this.installMentTable[t].initial_fee_amount.toString();
            test.service_tax = registeredServiceTax;
            test.fees_amount = this.installMentTable[t].totalAmount;
            test.service_tax_applicable = this.installMentTable[t].service_tax_applicable;
            test.day_type = this.installMentTable[t].day_type.toString();
            test.days = Number(this.installMentTable[t].days).toString();
            this.totalAmount = this.totalAmount + Number(test.fees_amount);
            data.push(test);
        }
        if (this.totalAmount != this.addNewTemplate.total_fee) {
            this.commonService.showErrorMessage('error', '', 'Amount provided in installments doesnot match with total Amount');
            return false;
        }
        for (var t = 0; t < this.otherInstList.length; t++) {
            var test = {};
            test.fee_type = this.otherInstList[t].fee_type;
            test.initial_fee_amount = this.otherInstList[t].initial_fee_amount.toString();
            test.service_tax = this.otherInstList[t].service_tax.toString();
            test.fees_amount = this.otherInstList[t].fees_amount.toString();
            test.service_tax_applicable = 0;
            if (this.addNewTemplate.apply_tax && this.addNewTemplate.country_id == 1) {
                test.service_tax_applicable = this.otherInstList[t].service_tax_applicable;
            }
            test.schedule_id = this.otherInstList[t].schedule_id.toString();
            test.is_referenced = this.otherInstList[t].is_referenced;
            test.day_type = this.otherInstList[t].day_type.toString();
            test.days = Number(this.otherInstList[t].days).toString();
            this.totalAmount = this.totalAmount + this.otherInstList[t].fees_amount;
            data.push(test);
        }
        return data;
    };
    FeeTemplateAddComponent.prototype.userChangedInitialAmount = function (data, event) {
        if (data.service_tax_applicable == "Y") {
            data.tax = Math.floor(data.initial_fee_amount * 0.01 * this.feeStructure.registeredServiceTax);
            data.totalAmount = Math.floor(data.initial_fee_amount + data.tax);
        }
        else {
            data.tax = 0;
        }
    };
    FeeTemplateAddComponent.prototype.userChangedAmountTotalAmount = function (data, event) {
        if (data.service_tax_applicable == "Y") {
            data.tax = Math.floor(data.totalAmount - Math.floor(Number(data.totalAmount) * 100 / (100 + this.feeStructure.registeredServiceTax)));
            data.initial_fee_amount = Math.floor(Number(data.totalAmount - data.tax));
        }
        else {
            data.initial_fee_amount = Math.floor(Number(data.totalAmount));
            data.tax = 0;
        }
    };
    FeeTemplateAddComponent.prototype.userChangeAdditionalFeeAmount = function (data, event) {
        var input = Math.floor(Number(event.currentTarget.value));
        if (data.service_tax > 0) {
            var tax = Math.floor(input - Math.floor(Number(input) * 100 / (100 + data.service_tax)));
            data.initial_fee_amount = Math.floor(input - tax);
            if (Number(data.initial_fee_amount + tax) != input) {
                data.initial_fee_amount = Math.floor(data.initial_fee_amount + input - Number(data.initial_fee_amount + tax));
            }
        }
        else {
            data.initial_fee_amount = input;
            data.tax = 0;
        }
    };
    FeeTemplateAddComponent.prototype.deleteAdditionalRow = function (row, index) {
        this.otherInstList.splice(index, 1);
    };
    FeeTemplateAddComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-fee-template-add',
            template: __webpack_require__("./src/app/components/fee-module/data-setup/fee-template/fee-template-add/fee-template-add.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/data-setup/fee-template/fee-template-add/fee-template-add.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_feeStruc_service__["a" /* FeeStrucService */],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__services_common_service__["a" /* CommonServiceFactory */]])
    ], FeeTemplateAddComponent);
    return FeeTemplateAddComponent;
}());



/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/fee-template-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FeeTemplateRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__fee_template_component__ = __webpack_require__("./src/app/components/fee-module/data-setup/fee-template/fee-template.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__template_home_template_home_component__ = __webpack_require__("./src/app/components/fee-module/data-setup/fee-template/template-home/template-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__fee_template_add_fee_template_add_component__ = __webpack_require__("./src/app/components/fee-module/data-setup/fee-template/fee-template-add/fee-template-add.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var FeeTemplateRoutingModule = /** @class */ (function () {
    function FeeTemplateRoutingModule() {
    }
    FeeTemplateRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__fee_template_component__["a" /* FeeTemplateHomeComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                redirectTo: 'home'
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_3__template_home_template_home_component__["a" /* TemplateHomeComponent */]
                            },
                            {
                                path: 'add',
                                component: __WEBPACK_IMPORTED_MODULE_4__fee_template_add_fee_template_add_component__["a" /* FeeTemplateAddComponent */]
                            }
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], FeeTemplateRoutingModule);
    return FeeTemplateRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/fee-template.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/fee-template.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/fee-template.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FeeTemplateHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var FeeTemplateHomeComponent = /** @class */ (function () {
    function FeeTemplateHomeComponent(commonService) {
        this.commonService = commonService;
    }
    FeeTemplateHomeComponent.prototype.ngOnInit = function () {
        this.commonService.removeSelectionFromSideNav();
    };
    FeeTemplateHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-fee-template',
            template: __webpack_require__("./src/app/components/fee-module/data-setup/fee-template/fee-template.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/data-setup/fee-template/fee-template.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_common_service__["a" /* CommonServiceFactory */]])
    ], FeeTemplateHomeComponent);
    return FeeTemplateHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/fee-template.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FeeTemplateModule", function() { return FeeTemplateModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_hammerjs__ = __webpack_require__("./node_modules/hammerjs/hammer.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_hammerjs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_hammerjs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__fee_template_routing_module__ = __webpack_require__("./src/app/components/fee-module/data-setup/fee-template/fee-template-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_primeng_primeng__ = __webpack_require__("./node_modules/primeng/primeng.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_primeng_primeng___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_primeng_primeng__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__fee_template_component__ = __webpack_require__("./src/app/components/fee-module/data-setup/fee-template/fee-template.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__template_popup_template_popup_component__ = __webpack_require__("./src/app/components/fee-module/data-setup/fee-template/template-popup/template-popup.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__template_home_template_home_component__ = __webpack_require__("./src/app/components/fee-module/data-setup/fee-template/template-home/template-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__fee_template_add_fee_template_add_component__ = __webpack_require__("./src/app/components/fee-module/data-setup/fee-template/fee-template-add/fee-template-add.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__services_feeStruc_service__ = __webpack_require__("./src/app/services/feeStruc.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};














var FeeTemplateModule = /** @class */ (function () {
    function FeeTemplateModule() {
    }
    FeeTemplateModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_5__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_5__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_4__fee_template_routing_module__["a" /* FeeTemplateRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_6_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_7_primeng_primeng__["FileUploadModule"],
                __WEBPACK_IMPORTED_MODULE_7_primeng_primeng__["SplitButtonModule"],
                __WEBPACK_IMPORTED_MODULE_7_primeng_primeng__["MenuModule"],
                __WEBPACK_IMPORTED_MODULE_12__shared_shared_module__["a" /* SharedModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_8__fee_template_component__["a" /* FeeTemplateHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_10__template_home_template_home_component__["a" /* TemplateHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_9__template_popup_template_popup_component__["a" /* TemplatePopUpComponent */],
                __WEBPACK_IMPORTED_MODULE_11__fee_template_add_fee_template_add_component__["a" /* FeeTemplateAddComponent */]
            ],
            entryComponents: [],
            providers: [
                __WEBPACK_IMPORTED_MODULE_13__services_feeStruc_service__["a" /* FeeStrucService */]
            ]
        })
    ], FeeTemplateModule);
    return FeeTemplateModule;
}());



/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/template-home/template-home.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"middle-section clearFix\" id=\"enquiryList\" #enquiryManager>\r\n  <!-- Main View -->\r\n  <aside class=\"middle-full\">\r\n    <section class=\"middle-top clearFix\">\r\n      <h1 class=\"pull-left\">\r\n          <a routerLink=\"/view/fee\">\r\n            Fees \r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n        <a routerLink=\"/view/fee/data-setup\">\r\n           Data-setup\r\n      </a>\r\n      <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n      {{moduleState}} wise fees\r\n      </h1>\r\n\r\n      <aside class=\"pull-right\">\r\n        <div class=\"btn-container\">\r\n          <div class=\"search-filter-wrapper\">\r\n            <input type=\"text\" class=\"normal-field pull-right\" placeholder=\"Search\" name=\"searchData\" [(ngModel)]=\"searchText\" (keyup)=\"searchInList()\">\r\n          </div>\r\n          <button class=\"btn\" routerLink='/view/fee/data-setup/fee-template/add'>\r\n            New Structure\r\n          </button>\r\n        </div>\r\n      </aside>\r\n    </section>\r\n\r\n\r\n    <!-- Fee Table Container -->\r\n    <section class=\"table-content clearFix\" id=\"\">\r\n      <!-- Data Table and Pagination -->\r\n      <div class=\"table-scroll-wrapper\">\r\n        <div class=\"table table-responsive\">\r\n          <table class=\"structure-table\">\r\n            <thead>\r\n              <tr>\r\n                <th>Fee Structure</th>\r\n                <th>Master Course</th>\r\n                <th>Course</th>\r\n                <th>Country</th>\r\n                <th>Students assigned</th>\r\n                <th>Action</th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr *ngFor=\"let fee of tabkeList\">\r\n                <td>\r\n                  <label>\r\n                    {{fee.template_name}}\r\n                  </label>\r\n                </td>\r\n                <td>\r\n                  {{fee.master_course_standard_name}}\r\n                </td>\r\n                <td>\r\n                  {{fee.course_subject_name}}\r\n                </td>\r\n                <td>\r\n                  {{fee.country_name}}\r\n                </td>\r\n                <td>\r\n                  <a (click)=\"studentsAssigned(fee)\">\r\n                    {{fee.totalAssignedStudent}}\r\n                  </a>\r\n                </td>\r\n                <td class=\"feeactions\">\r\n                  <ul>\r\n                    <li (click)=\"editFee(fee)\">\r\n                      <i class=\"fa fa-pencil\" style=\"color:#1283f4;cursor: pointer;\" title=\"Edit\" aria-hidden=\"true\" ></i>\r\n                      &nbsp;\r\n                    </li>\r\n                    <li (click)=\"deleteFeeStructure(fee)\" style=\"margin-right: 7px;\">\r\n                      <i class=\"fa fa-trash\" style=\"color:#fa3145;cursor: pointer;\" title=\"Delete\" aria-hidden=\"true\" ></i>\r\n                    </li>\r\n                  </ul>\r\n                </td>\r\n              </tr>\r\n              <tr *ngIf=\"tabkeList.length == 0\">\r\n                <td colspan=\"6\">\r\n                  No Fee Structure Available\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n        <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n          <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n            [page]=\"PageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRow\">\r\n          </pagination>\r\n        </div>\r\n      </div>\r\n\r\n    </section>\r\n\r\n\r\n    <template-popup *ngIf=\"isEditFee\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closeFeeEditor()\" close-button>\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n          <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n            <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n              <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n            </g>\r\n            <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n            />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n\r\n      <div class=\"Pheader\" popup-header>\r\n        <h2 *ngIf=\"!isHeaderEdit\">Edit Template ::\r\n          <i>{{selectedTemplate.template_name}}</i>\r\n        </h2>\r\n        <a *ngIf=\"!isHeaderEdit\" (click)=\"editTemplateName()\">\r\n          <img src=\"./assets/images/edit_details.svg\" alt=\"\">\r\n        </a>\r\n        <h2 *ngIf=\"isHeaderEdit\">Edit Template</h2>\r\n        <div *ngIf=\"isHeaderEdit\" class=\"headitor field-wrapper\">\r\n          <input type=\"text\" class=\"form-ctrl\" autofocus [(ngModel)]=\"selectedTemplate.template_name\">\r\n        </div>\r\n        <a *ngIf=\"isHeaderEdit\">\r\n          <i class=\"fas fa-check\" (click)=\"updateTemplateName()\" style=\"font-family: FontAwesome ;font-size: 19px;\" title=\"feeName\"></i>\r\n          <i class=\"fas fa fa-times\" (click)=\"cancelTemplateName()\" style=\"font-family: FontAwesome ;font-size: 19px;\" title=\"Cancel\"></i>\r\n        </a>\r\n\r\n\r\n        <div class=\"field-checkbox-wrapper pull-right checkBoxAllignMent\">\r\n          <input type=\"checkbox\" id=\"defChkBX\" name=\"defChkBX\" [(ngModel)]=\"feeStructure.is_default\" class=\"form-checkbox\">\r\n          <label for=\"defChkBX\">Is Default Template</label>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"feeManager\" popup-content>\r\n        <div class=\"fee-content\">\r\n          <fieldset class=\"installment\">\r\n            <h1>MANAGE FEE INSTALLMENTS</h1>\r\n            <div class=\"row data-adder\">\r\n              <div class=\"outer\">\r\n                <div class=\"c-lg-3 c-md-3 pull-left\"></div>\r\n                <div class=\"c-lg-9 c-md-9 pull-right\">\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"row\" style=\"margin-top: 10px;margin-bottom: 10px\">\r\n              <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                <div class=\"field-wrapper has-value\">\r\n                  <label for=\"slotNew\">Total Amount (<img src=\"{{selectedCountry?.currency_symbol}}\" style=\"max-height: 10px\" />) <span class=\"text-danger\">*</span>\r\n                  </label>\r\n                  <input type=\"number\" min=\"0\" readonly=\"true\" class=\"form-ctrl\" [(ngModel)]=\"totalAmountCal\" name=\"slotNew\">\r\n\r\n                </div>\r\n              </div>\r\n              <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n                <div class=\"field-wrapper has-value\">\r\n                  <label for=\"slotNew\">Total No of Installments <span class=\"text-danger\">*</span>\r\n                  </label>\r\n                  <input type=\"number\" min=\"0\" readonly=\"true\" #idSlot [value]=\"installmentList.length\" class=\"form-ctrl\" name=\"slotNew\">\r\n\r\n                </div>\r\n              </div>\r\n              <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                <div class=\"field-wrapper has-value\">\r\n                  <label for=\"CourseDdn\">Country\r\n                    <span class=\"text-danger\">*</span>\r\n                  </label>\r\n                  <select id=\"\" [disabled]=\"true\" class=\"form-ctrl disable_input \" style=\"background: transparent\" name=\"country_id\" [(ngModel)]=\"selectedTemplate.country_id\">\r\n                    <option value=\"-1\"></option>\r\n                    <option [value]=\"data.id\" selected *ngFor='let data of countryDetails'>\r\n                       {{data.country_name}}\r\n                    </option>\r\n                  </select>\r\n\r\n                </div>\r\n              </div>\r\n              <div class=\"c-sm-3 c-md-3 c-lg-3 hide\">\r\n                <div class=\"field-checkbox-wrapper\">\r\n                  <input type=\"checkbox\" id=\"checkBoxtaxes\" name=\"checkbx\" class=\"form-checkbox\" (click)=\"onApplyTaxChechbox($event)\">\r\n                  <label for=\"checkbx\">Apply Tax({{feeStructure.registeredServiceTax}}%)</label>\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n\r\n            <div class=\"row\" style=\"display: flex;\">\r\n\r\n              <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                <div class=\"field-wrapper has-value\">\r\n                  <label for=\"row.category_id\">Trigger Date</label>\r\n                  <select id=\"\" class=\"form-ctrl\" style=\"background: transparent\" name=\"AddInstallment.day_type\" (ngModelChange)=\"changesValuesAsPerType(AddInstallment)\" [(ngModel)]=\"AddInstallment.day_type\">\r\n                    <option value=\"1\">Course Assign Date (CAD)</option>\r\n                    <option value=\"2\">No of days after CAD</option>\r\n                    <option value=\"3\">No of Month after CAD</option>\r\n                  </select>\r\n\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                <div class=\"field-wrapper has-value\">\r\n                  <label for=\"slotNew\"> No.\r\n                  </label>\r\n                  <input type=\"number\" min=\"0\" class=\"form-ctrl\" [disabled]=\"AddInstallment.day_type=='1'\" [ngClass]=\"{'disable_input': AddInstallment.day_type=='1'}\"\r\n                   [(ngModel)]=\"AddInstallment.days\" name=\"slotNew\">\r\n\r\n                  <p>(Days/Months)</p>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                <div class=\"field-wrapper has-value\">\r\n                  <label for=\"slotNew\">Fee Amount\r\n                  </label>\r\n                  <input type=\"number\" min=\"0\" class=\"form-ctrl\" [(ngModel)]=\"AddInstallment.initial_fee_amount\" name=\"slotNew\">\r\n\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-sm-2 c-md-2 c-lg-2\" style=\"margin: auto;cursor: pointer\">\r\n                <img src=\"assets/images/plus.png\" (click)=\"addInstallmentInTable()\" alt=\"Add\" style=\"vertical-align: -webkit-baseline-middle;\">\r\n              </div>\r\n            </div>\r\n\r\n\r\n            <div class=\"row\">\r\n              <div class=\"\">\r\n                <div class=\"table table-responsive\">\r\n                  <table>\r\n                    <thead>\r\n                      <tr>\r\n                        <th>Installment # </th>\r\n                        <th>Due Date</th>\r\n                        <th *ngIf=\"selectedTemplate.country_id=='1'\">Amount</th>\r\n                        <th *ngIf=\"selectedTemplate.country_id=='1'\">Tax</th>\r\n                        <th *ngIf=\"selectedTemplate.country_id!='1'\">Fee Amount</th>\r\n                        <th *ngIf=\"selectedTemplate.country_id=='1'\">Fee Amount Incl Tax</th>\r\n                        <th>Action</th>\r\n                      </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                      <tr *ngFor=\"let row of installmentList; let i= index ; trackBy : index\">\r\n                        <td>\r\n                          <select [(ngModel)]=\"row.day_type\" (ngModelChange)=\"changesValuesAsPerType(row)\" style=\"background: transparent\">\r\n                            <option value=\"1\">Course Assign Date (CAD)</option>\r\n                            <option value=\"2\">No of days after CAD</option>\r\n                            <option value=\"3\">No of Month after CAD</option>\r\n                          </select>\r\n                        </td>\r\n                        <td>\r\n                          <div class=\"field-wrapper\">\r\n                            <input type=\"number\" min=\"0\" class=\"editCellInput\" [disabled]=\"row.day_type=='1'\" [ngClass]=\"{'disable_input': row.day_type=='1'}\" [(ngModel)]=\"row.days\" name=\"label\">\r\n                          </div>\r\n                        </td>\r\n                        <td *ngIf=\"selectedTemplate.country_id=='1'\">\r\n                          <div class=\"field-wrapper\">\r\n                            <input type=\"number\" min=\"0\" readonly=\"true\" class=\"editCellInput\" [(ngModel)]=\"row.initial_fee_amount\" name=\"label\">\r\n                          </div>\r\n                        </td>\r\n                        <td *ngIf=\"selectedTemplate.country_id=='1'\">\r\n                          <div class=\"field-wrapper\">\r\n                            <input type=\"number\" min=\"0\" readonly=\"true\" class=\"editCellInput\" [ngModel]='row.tax' name=\"label\">\r\n                          </div>\r\n                        </td>\r\n                        <td>\r\n                          <div class=\"field-wrapper\">\r\n                            <input type=\"number\" min=\"0\" class=\"editCellInput\" [(ngModel)]=\"row.fees_amount\" (keyup)=\"feeInstallmentChnge(row)\" name=\"label\">\r\n                          </div>\r\n                        </td>\r\n                        <td>\r\n                          <i class=\"fa fa-trash\" (click)=\"deleteRow(row , i)\" style=\"color:#fa3145;cursor: pointer;\" title=\"Delete\" aria-hidden=\"true\" ></i>\r\n                        </td>\r\n                      </tr>\r\n                    </tbody>\r\n                  </table>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </fieldset>\r\n\r\n          <fieldset class=\"additional\">\r\n            <h1>Manage Additional Fees</h1>\r\n\r\n            <div class=\"row\" style=\"display: flex;\">\r\n              <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n                <div class=\"field-wrapper has-value\">\r\n                  <label for=\"row.category_id\">Select Fee Type</label>\r\n                  <select id=\"\" class=\"form-ctrl\" style=\"background: transparent\" [(ngModel)]=\"additionalInstallment.fee_type\" (ngModelChange)=\"onAdditionalFeeSelection($event)\"\r\n                    name=\"row.category_id\">\r\n                    <option *ngFor=\"let opt of otherFeetype; let i= index ; trackBy : index\" [value]=\"opt.id\">\r\n                      {{opt.value}}\r\n                    </option>\r\n                  </select>\r\n\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n                <div class=\"field-wrapper has-value\">\r\n                  <label for=\"row.category_id\">Trigger Date</label>\r\n                  <select id=\"\" class=\"form-ctrl\" style=\"background: transparent\" [(ngModel)]=\"additionalInstallment.day_type\" (ngModelChange)=\"changesValuesAsPerType(additionalInstallment)\" name=\"row.category_id\">\r\n                    <option value=\"1\">Course Assign Date (CAD)</option>\r\n                    <option value=\"2\">No of days after CAD</option>\r\n                    <option value=\"3\">No of Month after CAD</option>\r\n                  </select>\r\n\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n                <div class=\"field-wrapper has-value\">\r\n                  <label for=\"slotNew\"> No.\r\n                  </label>\r\n                  <input type=\"number\" min=\"0\" class=\"form-ctrl\" [disabled]=\"additionalInstallment.day_type=='1'\" [ngClass]=\"{'disable_input': additionalInstallment.day_type=='1'}\" [(ngModel)]=\"additionalInstallment.days\" name=\"slotNew\">\r\n\r\n                  <p>(Days/Months)</p>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n                <div class=\"field-wrapper has-value\">\r\n                  <label for=\"slotNew\">Fee Amount\r\n                  </label>\r\n                  <input type=\"number\" min=\"0\" class=\"form-ctrl\" [(ngModel)]=\"additionalInstallment.initial_fee_amount\" name=\"slotNew\">\r\n\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-sm-2 c-md-2 c-lg-2\" *ngIf=\"selectedTemplate.country_id=='1'\">\r\n                <div class=\"field-wrapper has-value\">\r\n                  <label for=\"slotNew\">Tax Applicable (%)\r\n                  </label>\r\n                  <input type=\"number\" min=\"0\" class=\"form-ctrl\" [(ngModel)]=\"additionalInstallment.service_tax\" disabled name=\"slotNew\">\r\n\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-sm-2 c-md-2 c-lg-2\" style=\"margin: auto;cursor: pointer\">\r\n                <img src=\"assets/images/plus.png\" (click)=\"addAdditionalInst()\" alt=\"Add\" style=\"vertical-align: -webkit-baseline-middle;\">\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"row\">\r\n              <div class=\"\">\r\n                <div class=\"table table-responsive\">\r\n                  <table>\r\n                    <thead>\r\n                      <tr>\r\n                        <th>Fee Type </th>\r\n                        <th>Trigger Date</th>\r\n                        <th>No.(Days/Months)Due Date</th>\r\n                        <th *ngIf=\"selectedTemplate.country_id=='1'\">Amount</th>\r\n                        <th *ngIf=\"selectedTemplate.country_id=='1'\">Tax</th>\r\n                        <th *ngIf=\"selectedTemplate.country_id!='1'\">Fee Amount</th>\r\n                        <th *ngIf=\"selectedTemplate.country_id=='1'\">Fee Amount Incl Tax</th>\r\n                        <th>Action</th>\r\n                      </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                      <tr *ngFor=\"let row of otherInstList; let i= index ; trackBy : index\">\r\n                        <td>\r\n                          {{row.fee_type_name}}\r\n                        </td>\r\n                        <td>\r\n                          <select [(ngModel)]=\"row.day_type\" (ngModelChange)=\"changesValuesAsPerType(row)\" style=\"background: transparent\">\r\n                            <option value=\"1\">Course Assign Date (CAD)</option>\r\n                            <option value=\"2\">No of days after CAD</option>\r\n                            <option value=\"3\">No of Month after CAD</option>\r\n                          </select>\r\n                        </td>\r\n                        <td>\r\n                          <div class=\"field-wrapper\">\r\n                            <input type=\"number\" min=\"0\" class=\"editCellInput\" [disabled]=\"row.day_type=='1'\" [ngClass]=\"{'disable_input': row.day_type=='1'}\" [(ngModel)]=\"row.days\" name=\"label\">\r\n                          </div>\r\n                        </td>\r\n                        <td *ngIf=\"selectedTemplate.country_id=='1'\">\r\n                          <div class=\"field-wrapper\">\r\n                            <input type=\"number\" min=\"0\" readonly=\"true\" class=\"editCellInput\" [(ngModel)]=\"row.initial_fee_amount\" name=\"label\">\r\n                          </div>\r\n                        </td>\r\n                        <td *ngIf=\"selectedTemplate.country_id=='1'\">\r\n                          <div class=\"field-wrapper\">\r\n                            <input type=\"number\" min=\"0\" readonly=\"true\" class=\"editCellInput\" [ngModel]='row.fees_amount - row.initial_fee_amount' name=\"label\">\r\n                          </div>\r\n                        </td>\r\n                        <td>\r\n                          <div class=\"field-wrapper\">\r\n                            <input type=\"number\" min=\"0\" class=\"editCellInput\" [(ngModel)]=\"row.fees_amount\" (keyup)=\"feeTypesAmountChnge(row)\" name=\"label\">\r\n                          </div>\r\n                        </td>\r\n                        <td>\r\n                          <i class=\"fa fa-trash\" (click)=\"deleteAdditionalRow(row , i)\" style=\"color:#fa3145;cursor: pointer;\" title=\"Delete\" aria-hidden=\"true\"></i>\r\n                        </td>\r\n                      </tr>\r\n                      <tr *ngIf=\"otherInstList.length == 0\">\r\n                        <td colspan=\"7\">\r\n                          No Additional Fee\r\n                        </td>\r\n                      </tr>\r\n                    </tbody>\r\n                  </table>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </fieldset>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"\" popup-footer>\r\n        <div class=\"clearfix\">\r\n          <aside class=\"pull-right\">\r\n            <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closeFeeEditor()\">\r\n            <input type=\"button\" value=\"Apply\" (click)=\"updateFeeTemplate()\" class=\"fullBlue btn\">\r\n          </aside>\r\n        </div>\r\n      </div>\r\n\r\n    </template-popup>\r\n\r\n    <proctur-popup [sizeWidth]=\"'small'\" *ngIf=\"addTemplatePopUp\">\r\n\r\n      <span class=\"closePopup pos-abs fbold show\" (click)=\"closeTemplatePopup()\" close-button>\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n          <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n            <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n              <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n            </g>\r\n            <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n            />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n\r\n      <div popup-header class=\"popup-header-content\">\r\n        <h2>Students Assigned</h2>\r\n      </div>\r\n\r\n      <div class=\"popup-content\" popup-content>\r\n        <div class=\"table table-responsive\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  Student Id\r\n                </th>\r\n                <th>\r\n                  Student Name\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n\r\n            <tbody *ngIf=\"studentList!=null\">\r\n              <tr *ngFor=\"let i of studentList\">\r\n                <td>\r\n                  {{i.student_disp_id}}\r\n                </td>\r\n                <td>\r\n                  {{i.student_name}}\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n\r\n    </proctur-popup>\r\n\r\n  </aside>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/template-home/template-home.component.scss":
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.feeManager {\n  width: 100%; }\n.feeManager .fee-content {\n    max-height: 400px;\n    overflow-x: hidden;\n    overflow-y: auto; }\n.feeManager .row {\n    margin: 0px; }\n.feeManager .header {\n    border-bottom: 1px solid rgba(119, 119, 119, 0.733);\n    margin: 5px 0px; }\n.feeManager table thead tr {\n    height: 40px; }\n.feeManager table thead tr th {\n      padding: 0px !important;\n      font-weight: bold;\n      color: #777;\n      border-bottom: 2px solid #ccc;\n      background: white; }\n.feeManager table .field-wrapper {\n    background: transparent;\n    width: 100%; }\n.feeManager table .field-wrapper .form-ctrl {\n      background: transparent !important;\n      border-bottom: solid 1px #0084f6 !important;\n      text-align: center !important;\n      width: 180px !important; }\n.feeManager table .field-wrapper {\n    position: relative; }\n.feeManager table .field-wrapper.datePickerBox .bsDatepicker {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent; }\n.feeManager table .field-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 30px;\n      top: 0px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n.feeManager table .field-wrapper .date-clear {\n      position: absolute;\n      right: 60%;\n      top: 50px;\n      cursor: pointer;\n      color: #0084f6; }\n.feeManager table tr {\n    line-height: 20px; }\n.feeManager table tr i {\n      font-size: 18px;\n      cursor: pointer; }\n.feeManager table tr td {\n      padding: 3px 20px; }\n.feeManager .installment {\n    padding: 5px;\n    background: #efefef;\n    border-radius: 5px;\n    padding: 10px 10px 10px 10px; }\n.feeManager .installment .field-wrapper {\n      background: transparent; }\n.feeManager .installment .field-wrapper .form-ctrl {\n        background: transparent;\n        border-bottom: 1px solid #ccc; }\n.feeManager .installment .data-adder {\n      margin: 0px 0px 5px 0px; }\n.feeManager .installment .data-adder .outer .inner {\n        width: 30%;\n        display: -webkit-inline-box;\n        display: -ms-inline-flexbox;\n        display: inline-flex; }\n.feeManager .installment .data-adder .outer .inner .btn {\n          padding: 2px 0px 0px 7px;\n          border: none;\n          height: 35px;\n          width: 35px;\n          border-radius: 50%; }\n.feeManager .installment .data-adder .outer .inner .btn .tooltip {\n            position: relative;\n            top: -30px;\n            right: 50px;\n            min-width: 100px;\n            font-size: 12px;\n            padding: 6px;\n            height: 35px;\n            border-radius: 5px;\n            background: rgba(0, 0, 0, 0.774);\n            color: white;\n            visibility: hidden;\n            opacity: 0; }\n.feeManager .installment .data-adder .outer .inner .btn:hover {\n            background: #d8d6d6; }\n.feeManager .installment .data-adder .outer .inner .btn:hover .tooltip {\n              position: relative;\n              top: -65px;\n              right: 100px;\n              min-width: 160px;\n              padding: 6px;\n              border-radius: 5px;\n              font-size: 12px;\n              height: 35px;\n              background: rgba(0, 0, 0, 0.541);\n              color: white;\n              visibility: visible;\n              opacity: 1;\n              -webkit-transition: all 0.2s;\n              transition: all 0.2s; }\n.feeManager .installment .data-adder .outer .inner .btn:focus {\n            outline: none; }\n.feeManager .installment .data-adder .outer .inner .btn:active {\n            -webkit-box-shadow: none;\n                    box-shadow: none; }\n.feeManager .additional {\n    margin-top: 40px;\n    padding: 5px;\n    background: #efefef;\n    border-radius: 5px;\n    padding: 10px 10px 10px 10px; }\n.feeManager .additional .field-wrapper {\n      background: transparent; }\n.feeManager .additional .field-wrapper .form-ctrl {\n        background: transparent;\n        border-bottom: 1px solid #ccc; }\n.feeManager .additional legend {\n      padding: 0.2em 0.5em;\n      border: 1px solid #004a7e;\n      color: #ffffff;\n      font-size: 14px;\n      font-weight: 600;\n      text-align: left;\n      width: 200px;\n      background: #004a7e; }\n.feeManager .additional .data-adder {\n      margin: 0px 0px 5px 0px; }\n.feeManager .additional .data-adder .outer .inner {\n        width: 30%;\n        display: -webkit-inline-box;\n        display: -ms-inline-flexbox;\n        display: inline-flex; }\n.feeManager .additional .data-adder .outer .inner .btn {\n          padding: 2px 0px 0px 7px;\n          border: none;\n          height: 35px;\n          width: 35px;\n          border-radius: 50%; }\n.feeManager .additional .data-adder .outer .inner .btn .tooltip {\n            position: relative;\n            top: -30px;\n            right: 50px;\n            min-width: 100px;\n            font-size: 12px;\n            padding: 6px;\n            height: 35px;\n            border-radius: 5px;\n            background: rgba(0, 0, 0, 0.774);\n            color: white;\n            visibility: hidden;\n            opacity: 0; }\n.feeManager .additional .data-adder .outer .inner .btn:hover {\n            background: #d8d6d6; }\n.feeManager .additional .data-adder .outer .inner .btn:hover .tooltip {\n              position: relative;\n              top: -65px;\n              right: 100px;\n              min-width: 160px;\n              padding: 6px;\n              border-radius: 5px;\n              font-size: 12px;\n              height: 35px;\n              background: rgba(0, 0, 0, 0.541);\n              color: white;\n              visibility: visible;\n              opacity: 1;\n              -webkit-transition: all 0.2s;\n              transition: all 0.2s; }\n.feeManager .additional .data-adder .outer .inner .btn:focus {\n            outline: none; }\n.feeManager .additional .data-adder .outer .inner .btn:active {\n            -webkit-box-shadow: none;\n                    box-shadow: none; }\n.feeManager .additional .data-adder .outer .innermost {\n        display: -webkit-inline-box;\n        display: -ms-inline-flexbox;\n        display: inline-flex; }\n.feeManager .additional .data-adder .outer .innermost .field-wrapper {\n          width: 200px; }\n.feeManager .additional .data-adder .outer .innermost .btn {\n          padding: 2px 0px 0px 7px;\n          border: none;\n          height: 35px;\n          width: 35px;\n          border-radius: 50%; }\n.feeManager .additional .data-adder .outer .innermost .btn .tooltip {\n            position: relative;\n            top: -30px;\n            right: 50px;\n            min-width: 100px;\n            font-size: 12px;\n            padding: 6px;\n            height: 35px;\n            border-radius: 5px;\n            background: rgba(0, 0, 0, 0.774);\n            color: white;\n            visibility: hidden;\n            opacity: 0; }\n.feeManager .additional .data-adder .outer .innermost .btn:hover {\n            background: #d8d6d6; }\n.feeManager .additional .data-adder .outer .innermost .btn:hover .tooltip {\n              position: relative;\n              top: -65px;\n              right: 100px;\n              min-width: 160px;\n              padding: 6px;\n              border-radius: 5px;\n              font-size: 12px;\n              height: 35px;\n              background: rgba(0, 0, 0, 0.541);\n              color: white;\n              visibility: visible;\n              opacity: 1;\n              -webkit-transition: all 0.2s;\n              transition: all 0.2s; }\n.feeManager .additional .data-adder .outer .innermost .btn:focus {\n            outline: none; }\n.feeManager .additional .data-adder .outer .innermost .btn:active {\n            -webkit-box-shadow: none;\n                    box-shadow: none; }\n.Pheader h2 {\n  display: inline-block; }\n.Pheader .headitor {\n  display: inline-block; }\n.Pheader .headitor.field-wrapper {\n    padding-top: 0px; }\n.Pheader .headitor.field-wrapper .form-ctrl {\n      margin: 0px 0px 0px 15px;\n      display: block;\n      width: 100%;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      padding: 5px 0px 0px 0px;\n      outline: none;\n      border: 0;\n      border-bottom: solid 1px #e2ebee;\n      height: 30px;\n      font: 400 12px 'Open sans',sans-serif;\n      -webkit-box-shadow: none;\n              box-shadow: none;\n      border-radius: 0;\n      line-height: 24px; }\n.Pheader a {\n  display: inline-block;\n  line-height: 1.2;\n  position: relative;\n  cursor: S;\n  bottom: -5px;\n  margin-left: 15px; }\n.Pheader a img {\n    width: 25px;\n    height: 25px; }\ninput[type='number'] {\n  -moz-appearance: textfield; }\n/* Webkit browsers like Safari and Chrome */\ninput[type=number]::-webkit-inner-spin-button,\ninput[type=number]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0; }\n/* =================================================================================== */\n.feeactions ul li {\n  display: inline-block;\n  cursor: pointer; }\n/* =================================================================================== */\n.headEnq .option-wrap {\n  width: 20px;\n  height: 20px; }\n.headEnq .btn {\n  padding: 2px 0px 0px 7px;\n  border: none;\n  height: 35px;\n  width: 35px;\n  border-radius: 50%; }\n.headEnq .btn .tooltip {\n    position: relative;\n    top: -30px;\n    right: -30px;\n    min-width: 100px;\n    font-size: 12px;\n    padding: 6px;\n    height: 35px;\n    border-radius: 5px;\n    background: rgba(0, 0, 0, 0.541);\n    color: white;\n    visibility: hidden;\n    opacity: 0; }\n.headEnq .btn:hover {\n    background: #d8d6d6; }\n.headEnq .btn:hover .tooltip {\n      position: relative;\n      top: -30px;\n      right: 120px;\n      min-width: 100px;\n      padding: 6px;\n      border-radius: 5px;\n      font-size: 12px;\n      height: 35px;\n      background: rgba(0, 0, 0, 0.541);\n      color: white;\n      visibility: visible;\n      opacity: 1;\n      -webkit-transition: all 0.2s;\n      transition: all 0.2s; }\n.headEnq .btn:focus {\n    outline: none; }\n.headEnq .btn:active {\n    -webkit-box-shadow: none;\n            box-shadow: none; }\n.headEnq .enq-dropdown-content {\n  position: absolute;\n  background: white;\n  z-index: 10;\n  width: 150px;\n  padding: 0px 5px;\n  height: 80px;\n  -webkit-box-shadow: 1px 1px 3px 1px black;\n          box-shadow: 1px 1px 3px 1px black; }\n.headEnq .enq-dropdown-content ul {\n    list-style: none; }\n.headEnq .enq-dropdown-content ul .export-icon {\n      background: url(\"/assets/images/expand.svg\") no-repeat;\n      margin: 10px 0px 0px 2px;\n      background-size: 20px auto;\n      padding: 0px 0px 0px 25px;\n      cursor: pointer;\n      font-size: 14px;\n      color: #888; }\n.headEnq .enq-dropdown-content ul .export-icon:hover {\n        color: #0084f6; }\n.headEnq .enq-dropdown-content ul .upload-icon {\n      background: url(\"/assets/images/pdf_download.svg\") no-repeat;\n      margin: 10px 0px 0px 2px;\n      background-size: 20px auto;\n      padding: 0px 0px 0px 25px;\n      cursor: pointer;\n      font-size: 14px;\n      color: #888; }\n.headEnq .enq-dropdown-content ul .upload-icon:hover {\n        color: #0084f6; }\n.headEnq .enq-dropdown-content ul li {\n      height: 25px;\n      padding: 7px;\n      border-bottom: 1px solid rgba(119, 119, 119, 0.705); }\n/* =================================================================================== */\n.table-head-menu {\n  position: relative; }\n.table-head-menu span {\n  cursor: pointer;\n  padding: 9px 0px;\n  display: block;\n  height: 100%;\n  background: #0084f6;\n  width: 40px;\n  height: 50px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  float: right;\n  position: relative; }\n.table-head-menu span img {\n    width: 28px;\n    height: 30px;\n    position: absolute;\n    top: 0;\n    bottom: 0;\n    right: 0;\n    left: 0;\n    margin: auto;\n    -webkit-transition: all 0.5s ease;\n    transition: all 0.5s ease;\n    opacity: 1;\n    visibility: visible;\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg); }\n.table-head-menu span img + img {\n    opacity: 0;\n    visibility: hidden;\n    -webkit-transform: rotate(90deg);\n            transform: rotate(90deg);\n    width: 24px; }\n.table-head-menu:hover span img {\n  -webkit-transform: rotate(90deg);\n          transform: rotate(90deg);\n  opacity: 0;\n  visibility: hidden; }\n.table-head-menu:hover span img + img {\n  opacity: 1;\n  visibility: visible;\n  -webkit-transform: rotate(0deg);\n          transform: rotate(0deg); }\n.table-heading-menu {\n  position: absolute;\n  top: 50%;\n  right: 0;\n  background: #fff;\n  width: 200px;\n  text-align: left;\n  padding: 0px;\n  -webkit-box-shadow: 0px 1px 2px 1px #dcdcdc;\n          box-shadow: 0px 1px 2px 1px #dcdcdc;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.1s;\n  transition: all 0.1s; }\n.table-head-menu:hover .table-heading-menu {\n  visibility: visible;\n  opacity: 1;\n  top: 100%; }\n.table-heading-menu ul li {\n  border-bottom: 1px solid #ccc;\n  padding: 5px 5px; }\n.table-heading-menu ul li .field-checkbox-wrapper {\n  margin-bottom: 0;\n  cursor: pointer; }\n.table-heading-menu ul li .field-checkbox-wrapper label {\n  font-weight: normal;\n  cursor: pointer; }\n/* =================================================================================== */\n/* =================================================================================== */\n/* =================================================================================== */\n/* =================================================================================== */\n.tooltip-table:hover .tooltip-box-right {\n  visibility: visible;\n  opacity: 1;\n  left: 100px; }\n.tooltip-table .tooltip-box-right {\n  position: absolute;\n  min-width: 700px;\n  max-width: 750px;\n  min-height: 150px;\n  max-height: 200px;\n  background: #f5f5ed;\n  border: 1px solid #ccc;\n  left: 100px;\n  z-index: 1;\n  top: -65px;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.1s linear 0.1s;\n  transition: all 0.1s linear 0.1s;\n  font-size: 11px;\n  border-radius: 4px;\n  padding: 10px;\n  -webkit-box-shadow: 0px 0px 10px #161515;\n          box-shadow: 0px 0px 10px #161515;\n  overflow-y: scroll;\n  overflow-x: hidden; }\n/* =================================================================================== */\n/* =================================================================================== */\n/* =================================================================================== */\n#table-main {\n  margin-left: 0px !important;\n  margin-top: 15px;\n  margin-right: 15px !important;\n  max-height: 400px;\n  overflow: hidden;\n  width: 100%; }\n#table-main ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n@media screen and (max-width: 995px), screen and (max-height: 768px) {\n  #table-main {\n    margin-left: 0px !important;\n    margin-top: 15px;\n    margin-right: 15px !important;\n    max-height: 400px;\n    overflow: hidden;\n    width: 100%; }\n    #table-main .table-scroll-wrapper {\n      max-height: 400px; }\n    #table-main ::-webkit-scrollbar {\n      display: block;\n      width: 7px;\n      height: 7px; } }\n/* =================================================================================== */\n/* =================================================================================== */\n/* =================================================================================== */\n.time-picker .field-wrapper {\n  display: inline-block;\n  margin: 5px 10px 0px 0px; }\n.time-picker .field-wrapper .form-ctrl {\n    width: 70px; }\n/* =================================================================================== */\n/* =================================================================================== */\n/* =================================================================================== */\n.registration-table {\n  padding: 30px 0px; }\n.registration-table table thead tr {\n    line-height: 25px; }\n.registration-table table tbody tr {\n    line-height: 20px; }\n.registration-table table tbody tr td {\n      text-overflow: ellipsis; }\n.registration-table table tbody tr td .download-icon {\n        cursor: pointer; }\n.registration-table table tbody tr td .download-icon::after {\n          content: \"\\f0ed\";\n          font-family: FontAwesome; }\n::ng-deep .ui-splitbutton {\n  position: relative;\n  display: inline-block;\n  zoom: 1;\n  background: #fff;\n  border: none;\n  font-size: 14px !important;\n  font-weight: 500;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 32px;\n  min-width: 205px;\n  cursor: pointer;\n  color: #0084f6;\n  padding: 0px;\n  font-size: 14px; }\n::ng-deep .ui-splitbutton .ui-button {\n    background: #fff;\n    color: #0084f6 !important;\n    font-size: 14px;\n    height: 30px !important;\n    font-weight: 600;\n    border: 1px solid #eaeaeb !important;\n    -webkit-transition: background-color 0s !important;\n    transition: background-color 0s !important; }\n::ng-deep .ui-splitbutton .ui-button:hover {\n      color: white !important; }\n::ng-deep .ui-splitbutton .ui-button:active {\n      color: white !important; }\n::ng-deep .ui-splitbutton .ui-button:focus {\n      color: white !important; }\n::ng-deep .ui-splitbutton .ui-corner-left {\n    min-width: 175px; }\n::ng-deep .ui-splitbutton .ui-menu {\n    border: none;\n    color: #1b1d1f;\n    background: #f6f7f9 0 0 repeat-x;\n    background: none;\n    top: 35px !important;\n    left: 0px !important;\n    outline: none;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    font-size: 14px;\n    text-align: left; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list {\n      font-size: 14px; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem {\n        font-size: 14px;\n        width: 100%;\n        min-width: 200px;\n        min-height: 39px;\n        clear: both;\n        margin: .125em 0;\n        padding: 0px 5px 0px 5px;\n        color: #0084f6;\n        margin: 0px 0px -1px 0px;\n        border: none !important;\n        -webkit-box-shadow: none;\n                box-shadow: none;\n        background: white; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem:hover {\n          background: #0084f6 !important;\n          color: white !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem:hover a {\n            color: white !important;\n            font-size: 14px !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem:active {\n          background: #0084f6 !important;\n          color: white !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem:active a {\n            color: white !important;\n            font-size: 14px !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem:focus {\n          background: #0084f6 !important;\n          color: white !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem:focus a {\n            color: white !important;\n            font-size: 14px !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem .ui-menuitem-link {\n          padding: 0 !important; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem a {\n          color: #0084f6 !important;\n          font-size: 14px !important;\n          height: 35px; }\n::ng-deep .ui-splitbutton .ui-menu .ui-menu-list .ui-menuitem a:hover {\n            background: #0084f6 !important; }\n.middle-main {\n  position: relative; }\n.middle-main:before {\n    content: '';\n    position: absolute;\n    width: 100%;\n    height: 100%;\n    left: 0;\n    top: 80px;\n    z-index: 1;\n    background: rgba(255, 255, 255, 0.74);\n    -webkit-transition: all 0.1s;\n    transition: all 0.1s;\n    opacity: 0;\n    visibility: hidden; }\n.middle-main.hasFilter:before {\n    opacity: 1;\n    visibility: visible; }\n.middle-main.hasFilter .filter-fields {\n    opacity: 1;\n    visibility: visible;\n    top: 100%; }\n.middle-main.hasFilter .closeFilter {\n    display: block; }\n.normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  border-right: 0;\n  height: 35px;\n  font-size: 14px; }\n.normal-btn {\n  padding: 8px 10px;\n  width: 25%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  float: left;\n  background: #9c9b9b;\n  color: #fff;\n  cursor: pointer; }\n.filter-box {\n  padding: 20px 0px;\n  background: #efefef; }\n.filter-right .btn {\n  min-width: 100px; }\n.filter-search {\n  position: relative; }\n.filter-fields {\n  padding: 0 15px 20px;\n  background: #fff;\n  border: 1px solid #ccc;\n  position: absolute;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  z-index: 1;\n  left: 0;\n  top: 70%;\n  -webkit-transition: all 0.3s;\n  transition: all 0.3s;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-box-shadow: 0px 2px 1px #e2e0e0;\n          box-shadow: 0px 2px 1px #e2e0e0; }\n.filter-fields .field-wrapper {\n    margin: 15px 0; }\n.filter-fields .form-ctrl {\n  background: transparent;\n  font: 400 12px 'Open sans',sans-serif;\n  border-bottom: solid 1px #d2d2d2; }\n.filter-fields .btn {\n  margin: 0;\n  width: 100%;\n  margin-top: 20px;\n  padding: 10px 12px;\n  height: auto; }\n.common-nav {\n  display: none; }\n.middle-section {\n  padding: 1%;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.middle-left {\n  width: 100%;\n  padding: 0; }\n.middle-top h1 {\n  margin-top: 8px;\n  margin-bottom: 10px;\n  float: none; }\n.middle-top aside {\n  float: left; }\n/*=======================filter type==============*/\n.search-enquiry-type-filter {\n  margin: 35px 0 10px; }\n.filter-label {\n  font-weight: 600; }\n.filter-label label {\n  font-weight: 600; }\n.type-filter li {\n  display: inline-block;\n  margin: 0 10px; }\n.pagination li,\n.export-print li {\n  display: inline-block;\n  margin-left: 10px;\n  font-size: 12px; }\n.export-print {\n  margin-bottom: 10px; }\n.export-print .print-icon {\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%229177 266 26 22%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %23999%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1224%22 data-name%3D%22Group 1224%22 transform%3D%22translate(8100 -6)%22%3E%0D    %3Cg id%3D%22Group_1222%22 data-name%3D%22Group 1222%22%3E%0D      %3Cg id%3D%22Group_1212%22 data-name%3D%22Group 1212%22%3E%0D        %3Cpath id%3D%22Path_163%22 data-name%3D%22Path 163%22 class%3D%22cls-1%22 d%3D%22M37%2C22.478h4.174a1.047%2C1.047%2C0%2C0%2C0%2C1.043-1.043V12.043A1.047%2C1.047%2C0%2C0%2C0%2C41.174%2C11H39.087%22 transform%3D%22translate(1059.782 267.47)%22%2F%3E%0D        %3Cpath id%3D%22Path_164%22 data-name%3D%22Path 164%22 class%3D%22cls-1%22 d%3D%22M4.13%2C11H2.043A1.047%2C1.047%2C0%2C0%2C0%2C1%2C12.043v9.391a1.047%2C1.047%2C0%2C0%2C0%2C1.043%2C1.043H6.217%22 transform%3D%22translate(1077 267.47)%22%2F%3E%0D        %3Crect id%3D%22Rectangle_269%22 data-name%3D%22Rectangle 269%22 class%3D%22cls-1%22 width%3D%2213.565%22 height%3D%2210.435%22 transform%3D%22translate(1083.217 273)%22%2F%3E%0D        %3Crect id%3D%22Rectangle_270%22 data-name%3D%22Rectangle 270%22 class%3D%22cls-1%22 width%3D%2213.565%22 height%3D%225.217%22 transform%3D%22translate(1083.217 287.77)%22%2F%3E%0D        %3Cline id%3D%22Line_125%22 data-name%3D%22Line 125%22 class%3D%22cls-1%22 x2%3D%2219.826%22 transform%3D%22translate(1080.087 283.94)%22%2F%3E%0D        %3Cline id%3D%22Line_126%22 data-name%3D%22Line 126%22 class%3D%22cls-1%22 y2%3D%221.094%22 transform%3D%22translate(1080.609 286.128)%22%2F%3E%0D        %3Cline id%3D%22Line_127%22 data-name%3D%22Line 127%22 class%3D%22cls-1%22 y1%3D%226.564%22 transform%3D%22translate(1081.13 275.735)%22%2F%3E%0D        %3Cline id%3D%22Line_128%22 data-name%3D%22Line 128%22 class%3D%22cls-1%22 y1%3D%226.564%22 transform%3D%22translate(1098.87 275.735)%22%2F%3E%0D      %3C%2Fg%3E%0D      %3Crect id%3D%22Rectangle_690%22 data-name%3D%22Rectangle 690%22 class%3D%22cls-2%22 width%3D%2226%22 height%3D%2222%22 transform%3D%22translate(1077 272)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    color: #888; }\n.export-print .export-icon {\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%229268 266 26 22%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %23999%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1223%22 data-name%3D%22Group 1223%22 transform%3D%22translate(8100 -6)%22%3E%0D    %3Cg id%3D%22Group_1211%22 data-name%3D%22Group 1211%22 transform%3D%22translate(0 -1)%22%3E%0D      %3Cpath id%3D%22Path_178%22 data-name%3D%22Path 178%22 class%3D%22cls-1%22 d%3D%22M11.588%2C3H3.353A2.36%2C2.36%2C0%2C0%2C0%2C1%2C5.353V19.47a2.36%2C2.36%2C0%2C0%2C0%2C2.353%2C2.353H17.47a2.36%2C2.36%2C0%2C0%2C0%2C2.353-2.353V11.235%22 transform%3D%22translate(1170 272.176)%22%2F%3E%0D      %3Cline id%3D%22Line_140%22 data-name%3D%22Line 140%22 class%3D%22cls-1%22 y1%3D%2210%22 x2%3D%2210%22 transform%3D%22translate(1180.412 274.588)%22%2F%3E%0D      %3Cpath id%3D%22Path_179%22 data-name%3D%22Path 179%22 class%3D%22cls-1%22 d%3D%22M30.059%2C8.059V1.588A.556.556%2C0%2C0%2C0%2C29.47%2C1H23%22 transform%3D%22translate(1160.941 273)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Crect id%3D%22Rectangle_691%22 data-name%3D%22Rectangle 691%22 class%3D%22cls-2%22 width%3D%2226%22 height%3D%2222%22 transform%3D%22translate(1168 272)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    margin-left: 25px; }\n.export-print .print-icon,\n  .export-print .export-icon {\n    background-size: 20px auto;\n    padding: 0px 0px 0px 22px;\n    cursor: pointer;\n    font-size: 14px;\n    color: #888; }\n.export-print .print-icon:hover,\n    .export-print .export-icon:hover {\n      color: #0084f6; }\n.filter-res label {\n  font-size: 14px;\n  font-weight: 600; }\n.pagination .first:before {\n  content: \"« \";\n  font-size: 16px;\n  font-weight: 800; }\n.pagination .last:after {\n  content: \" »\";\n  font-size: 16px;\n  font-weight: 800; }\n.pagination .batch-size {\n  font-size: 16px;\n  font-weight: 800;\n  border-bottom: 1px solid black; }\n.pagination li {\n  border-right: 1px solid #ccc;\n  padding: 0px 7px;\n  margin: 0;\n  line-height: 10px;\n  font-weight: 800;\n  cursor: pointer; }\n.pagination li a {\n    line-height: 10px;\n    font-size: 16px;\n    font-weight: 800;\n    border: none;\n    padding: 0px 14px; }\n.pagination li:last-child {\n  border-right: 0;\n  padding-right: 0; }\n.AdFilter-field {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  z-index: 1;\n  -webkit-box-shadow: #e2e0e0 0px 2px 1px;\n          box-shadow: #e2e0e0 0px 2px 1px;\n  padding: 0px 15px 20px;\n  background: white;\n  border-width: 1px;\n  border-style: solid;\n  border-color: #cccccc;\n  -o-border-image: initial;\n     border-image: initial;\n  position: absolute; }\n.AdFilter-field .field-wrapper {\n    margin: 15px 0; }\n.AdFilter-field .field-wrapper .date-clear {\n      position: absolute;\n      right: 15px;\n      top: 50px;\n      cursor: pointer;\n      color: #0084f6; }\n.openAdFilter {\n  float: right;\n  margin-top: 8px;\n  font-size: 14px;\n  font-weight: 600;\n  color: #0084f6; }\n.closeAdFilter {\n  float: right;\n  margin-top: 8px;\n  font-size: 14px;\n  font-weight: 600;\n  color: #f44336; }\n.closeAdFilter svg {\n    width: 15px;\n    height: 16px;\n    display: inline-block;\n    vertical-align: bottom;\n    margin-right: 4px; }\n.closeAdFilter svg .cls-1 {\n      stroke: #f44336;\n      stroke-miterlimit: 10;\n      stroke-width: 2; }\n.closeAdFilter svg .cls-2 {\n      stroke: none; }\n/*===========================================action tooltip of table===================*/\n.enquiry-action {\n  position: relative;\n  cursor: pointer; }\n.enquiry-action .cls-1,\n  .enquiry-action .cls-2 {\n    fill: none;\n    stroke: transparent; }\n.enquiry-action svg {\n    width: 18px; }\n.enquiry-action .cls-2 {\n    stroke: #7d7f80;\n    stroke-miterlimit: 10; }\n.enquiry-action:hover .action-icon svg .cls-2 {\n    stroke: #0084f6;\n    stroke-miterlimit: 10; }\n.action-menu {\n  position: absolute;\n  background: #fff;\n  width: 350px;\n  border-radius: 0;\n  border: 1px solid #ccc;\n  bottom: 10px;\n  -webkit-box-shadow: 0px 2px 4px 1px #ccc;\n          box-shadow: 0px 2px 4px 1px #ccc;\n  -webkit-transform: translateX(-50%);\n          transform: translateX(-50%);\n  left: 200px;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.6s;\n  transition: all 0.6s; }\n.enquiry-action:hover .action-menu {\n  visibility: visible;\n  opacity: 1;\n  bottom: 8px; }\n.action-menu-inner ul {\n  font-size: 0;\n  position: relative;\n  padding: 5px 5px; }\n.action-menu-inner ul:after {\n  content: '';\n  position: absolute;\n  right: 0;\n  left: 0;\n  bottom: -15px;\n  margin: auto;\n  border-top: 8px solid #fff;\n  border-bottom: 8px solid transparent;\n  border-right: 8px solid transparent;\n  border-left: 8px solid transparent;\n  width: 0;\n  height: 0; }\n.action-menu-inner ul li {\n  display: inline-block;\n  text-align: center;\n  vertical-align: top;\n  font-size: 12px;\n  padding: 0 8px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  cursor: pointer;\n  width: 18%; }\n.action-menu-inner ul li:last-child {\n    width: 28%; }\n.action-menu-inner ul li:last-child svg {\n      width: 33px; }\n.action-menu-inner ul li.edit-detail-icon svg * {\n    fill: none;\n    stroke: #8b8b8b; }\n.action-menu-inner ul li.edit-detail-icon svg .cls-1 {\n    stroke: none;\n    /* stroke: #8b8b8b; */ }\n.action-menu-inner ul li:hover {\n    color: #0084f6; }\n.action-menu-inner ul li:hover .cls-2,\n    .action-menu-inner ul li:hover .cls-3 {\n      fill: none;\n      stroke: #0084f6; }\n.action-menu-inner ul li span {\n  display: block;\n  font-size: 9px;\n  text-align: center;\n  line-height: 10px; }\n.action-menu-inner .close {\n  position: absolute;\n  right: 4px;\n  top: 2px; }\n.action-menu-inner i {\n  display: block;\n  height: 32px; }\n.enquiry-action li svg {\n  width: 28px; }\n/**===============================search data=========================*/\n.search-data {\n  margin: 10px 0px; }\n.search-data th {\n    font-weight: 500; }\n.search-data td {\n    font-size: 14px;\n    line-height: normal;\n    padding: 6px 5px; }\n.search-data tr th:first-child,\n  .search-data tr td:first-child {\n    padding: 15px 2px; }\n.search-data tr th:first-child .field-checkbox-wrapper,\n    .search-data tr td:first-child .field-checkbox-wrapper {\n      background: transparent; }\n.search-data tr th:last-child {\n    padding: 0; }\n/*=====================================mobile head menu css===========================*/\nul.customDropdown {\n  position: absolute;\n  top: 20%;\n  width: 100%;\n  height: auto;\n  background: #fff;\n  left: 0;\n  z-index: 11;\n  -webkit-box-shadow: 0px 1px 2px 1px #e2e2e2;\n          box-shadow: 0px 1px 2px 1px #e2e2e2; }\nul.customDropdown li {\n  padding: 10px 15px;\n  border-bottom: 1px solid #f5f5f5;\n  -webkit-transition: all 0.5s;\n  transition: all 0.5s;\n  cursor: pointer; }\nul.customDropdown li:hover {\n    background: #f5f5f5; }\nul.customDropdown li:first-child {\n  border: 0;\n  padding: 0; }\nul.customDropdown li:last-child {\n  border-bottom: 0; }\nul.customDropdown {\n  -webkit-transition: all 0.3s cubic-bezier(0.55, 0, 0.55, 0.2);\n  transition: all 0.3s cubic-bezier(0.55, 0, 0.55, 0.2);\n  -webkit-transition-duration: .15s;\n  transition-duration: .15s;\n  -webkit-transition-delay: .1s;\n  transition-delay: .1s;\n  opacity: 0;\n  visibility: hidden; }\nul.customDropdown.visibleDropdown {\n  visibility: visible;\n  opacity: 1;\n  top: 20%; }\nul.customDropdown li:hover {\n  background: #f5f5f5; }\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 850px;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n/*=========================================registration popup form css==================*/\n.registration-fee-form {\n  overflow: hidden; }\n.print-output-section {\n  margin: 35px 0 25px;\n  border-top: 1px solid #deeaee;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  border-bottom: 1px solid #deeaee;\n  text-align: center;\n  font-size: 0; }\n.print-output-section li {\n    display: inline-block;\n    padding: 0 15px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    width: 25%;\n    border-right: 1px solid #deeaee;\n    font-size: 15px;\n    cursor: pointer;\n    color: #929292; }\n.print-output-section li:last-child {\n      border-right: 0; }\n.print-output-section li:hover {\n      color: #0084f6; }\n.print-output-section li svg {\n      width: 30px;\n      display: inline-block;\n      vertical-align: middle;\n      margin-right: 8px; }\n.print-output-section li svg .cls-1 {\n        stroke: none;\n        stroke: #929292; }\n.print-output-section li.svg-icon .cls-1 {\n      stroke: none; }\n.print-output-section li.svg-icon .cls-2 {\n      stroke: #929292; }\n.print-output-section li.svg-icon:hover .cls-2 {\n      stroke: #0084f6; }\n.print-output-section li:first-child:hover svg .cls-1 {\n      stroke: #0084f6; }\n/*=======================================confirmation =========================*/\n.confirmation-popup-content {\n  line-height: normal; }\n.confirmation-popup-content > div {\n    margin-bottom: 10px; }\n.confirmation-popup-content > div:first-child {\n      margin-bottom: 20px; }\n.confirmation-popup-content > div a,\n    .confirmation-popup-content > div p {\n      font-size: 16px;\n      line-height: 22px; }\n.confirmation-popup-content > div a {\n      font-weight: 600; }\n.confirmation-popup-content > div a:hover {\n      text-decoration: underline; }\n.confirmation-popup-content strong {\n    font-weight: 600; }\n.confirmation-popup-content .add-form-btns a {\n    margin-left: 20px;\n    font-size: 14px; }\n.popup-btn {\n  margin-top: 20px; }\n.popup-btn .btn {\n    font-size: 16px;\n    height: 40px;\n    color: #333; }\n.popup-btn .btn.redBtn {\n      color: #fff;\n      min-width: 160px; }\n.update-enquiry-form {\n  width: 100%;\n  max-height: 400px; }\n.update-enquiry-form .form-wrapper {\n    width: 40%;\n    min-height: 370px;\n    max-height: 400px; }\n.update-enquiry-form .form-wrapper .row {\n      margin: 10px 5px 20px; }\n.update-enquiry-form .form-wrapper .submitter {\n      position: absolute;\n      right: 41px;\n      bottom: 41px; }\n.update-enquiry-form .table-wrapper {\n    width: 60%; }\n.update-enquiry-form .table-wrapper h4 {\n      margin: 0px 0 15px;\n      font-weight: 600; }\n.update-enquiry-form .table-wrapper .enquiry-update-history {\n      min-height: 370px;\n      max-height: 400px;\n      overflow: auto; }\n.update-enquiry-form .table-wrapper table th {\n      text-align: left;\n      padding: 10px;\n      font-size: 14px; }\n.update-enquiry-form .table-wrapper table td {\n      text-align: left;\n      padding: 10px;\n      font-size: 14px; }\n.confirmation-popup-content:after {\n  content: '';\n  height: 8px;\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  width: 100%;\n  background: #8bc34a; }\n.row.extraMargin {\n  margin: 10px -15px 20px; }\n.sms-form .row {\n  margin: 0px -15px; }\n.sms-table-head {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex; }\n.sms-table-head .sms-tab {\n    display: inline-block;\n    padding: 10px;\n    background: #ffffff;\n    cursor: pointer; }\n.sms-table-head .sms-tab label {\n      font-weight: 700;\n      color: #0084f6; }\n.sms-table-head .sms-tab.active {\n      background: #0084f6;\n      -webkit-box-shadow: 0px 0px 0px 1px #0084f6;\n              box-shadow: 0px 0px 0px 1px #0084f6;\n      border-bottom: 1px solid #0084f6;\n      color: #ffffff; }\n.sms-table-head .sms-tab.active label {\n        color: #ffffff; }\n.popup-body-container {\n  max-width: 85% !important;\n  top: 2% !important;\n  left: 5% !important; }\n.sms-popup-content {\n  max-height: 80% !important;\n  display: -webkit-box !important;\n  display: -ms-flexbox !important;\n  display: flex !important;\n  overflow: hidden !important; }\n.sms-middle-section {\n  padding: 5px 5px; }\n.sms-middle-section .table-container {\n    max-width: 100%;\n    min-height: 200px;\n    overflow: auto;\n    max-height: 300px; }\n.sms-update {\n  min-height: 100%;\n  width: 100%; }\n.sms-update .sms-table {\n    min-height: 300px;\n    max-height: 450px;\n    border-top: 1px solid #eaeaeb;\n    border-right: 1px solid #eaeaeb;\n    width: 70%;\n    padding-left: 2px;\n    overflow-y: hidden;\n    overflow-x: hidden; }\n.sms-update .sms-table .sms-search-field {\n      padding: 5px 10px;\n      border: 1px solid #eaeaeb;\n      width: 65%;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      margin: 0px 5px 0px 0px;\n      float: left;\n      border-right: 0;\n      height: 35px;\n      font-size: 14px;\n      outline: none; }\n.sms-update .sms-table .field-checkbox-wrapper,\n    .sms-update .sms-table .field-radio-wrapper {\n      position: relative;\n      padding-left: 25px;\n      margin-bottom: 10px; }\n.sms-update .sms-table .field-radio-wrapper .form-radio {\n      opacity: 0;\n      position: absolute;\n      left: 0;\n      top: 0;\n      width: 20px;\n      height: 20px;\n      z-index: 1; }\n.sms-update .sms-table .field-radio-wrapper .form-radio + label {\n      vertical-align: middle;\n      -webkit-transition: all 0.1s;\n      transition: all 0.1s; }\n.sms-update .sms-table .field-radio-wrapper .form-radio + label:after {\n      content: '';\n      width: 16px;\n      height: 16px;\n      border: 2px solid #ccc;\n      border-radius: 50%;\n      position: absolute;\n      left: 0;\n      top: 0;\n      -webkit-transition: all 0.1s;\n      transition: all 0.1s; }\n.sms-update .sms-table .field-radio-wrapper .form-radio:checked + label:after {\n      border: 2px solid #0084f6; }\n.sms-update .sms-table .field-radio-wrapper .form-radio + label:before {\n      -webkit-transition: all 0.1s;\n      transition: all 0.1s;\n      width: 1px;\n      height: 1px;\n      left: 9px;\n      top: 9px;\n      position: absolute;\n      content: ''; }\n.sms-update .sms-table .field-radio-wrapper .form-radio:checked + label:before {\n      content: '';\n      width: 10px;\n      height: 10px;\n      background: #0084f6;\n      border-radius: 50%;\n      left: 3px !important;\n      top: 3px !important; }\n.sms-update .sms-table .field-radio-wrapper .form-radio:checked + label {\n      color: #0084f6; }\n.sms-update .sms-preview {\n    min-height: 450px;\n    border-top: 1px solid #eaeaeb;\n    width: 30%;\n    padding: 0px 5px; }\n.sms-update .sms-preview .sms-preview-header {\n      margin-bottom: 25px; }\n.field-sms-wrapper {\n  position: relative;\n  padding-top: 10px;\n  border: 1px solid #eaeaeb;\n  overflow: hidden; }\n.field-sms-wrapper textarea {\n    width: 100%;\n    max-height: 200px;\n    color: #555555;\n    -webkit-transition: background-color 0.2s ease 0s;\n    transition: background-color 0.2s ease 0s; }\n.field-sms-wrapper textarea::focus {\n      background: none repeat scroll 0 0 #FFFFFF;\n      outline-width: 0; }\n.new-sms-form {\n  padding: 0px;\n  width: 100%; }\n.new-sms-form .row {\n    margin: 0px; }\n.new-sms-form .new-sms-wrapper .new-sms-textarea {\n    width: 100%;\n    border: 1px solid #eaeaeb;\n    padding: 5px; }\n.add-edit {\n  cursor: pointer; }\n.add-edit .add-sms {\n    line-height: 8px;\n    padding: 4px 0px 0px 0px;\n    font-size: 24px;\n    border: 1px solid #0084f6;\n    display: inline-block;\n    width: 20px;\n    height: 20px;\n    border-radius: 50%;\n    margin-right: 7px;\n    vertical-align: middle;\n    text-align: center; }\n/* ======================== DropDown Menu ================================= */\n/* Dropdown Button */\n.bulk-dropbtn {\n  padding: 0px 0px 3px 0px;\n  background: #fff;\n  border: none;\n  margin-left: 10px;\n  display: inline-block;\n  font-size: 14px;\n  font-weight: 600;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 35px;\n  cursor: pointer; }\n/* The container <div> - needed to position the dropdown content */\n.bulk-dropdown {\n  position: relative;\n  display: inline-block;\n  /* Dropdown Content (Hidden by Default) */\n  /* Links inside the dropdown */\n  /* Change color of dropdown links on hover */ }\n.bulk-dropdown .bulk-dropbtn {\n    padding: 0px 0px 3px 0px;\n    background: #fff;\n    border: none;\n    margin-left: 10px;\n    display: inline-block;\n    font-size: 14px;\n    font-weight: 600;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    height: 35px;\n    cursor: pointer; }\n.bulk-dropdown .bulk-dropbtn .caret {\n      margin-left: 5px;\n      display: inline-block;\n      width: 0;\n      height: 0;\n      vertical-align: middle;\n      border-top: 4px dashed;\n      border-right: 4px solid transparent;\n      border-left: 4px solid transparent;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      font-size: 14px;\n      font-weight: 400;\n      line-height: 1.42857143;\n      text-align: center;\n      white-space: nowrap;\n      cursor: pointer;\n      -webkit-user-select: none;\n         -moz-user-select: none;\n          -ms-user-select: none;\n              user-select: none;\n      font-family: inherit;\n      text-transform: none;\n      text-indent: 0px;\n      text-shadow: none; }\n.bulk-dropdown .bulk-dropbtn-border {\n    padding: 7px 12px;\n    background: #fff;\n    border-bottom: 1px solid #ccc;\n    border-top: none;\n    border-right: none;\n    border-left: none;\n    margin-left: 10px;\n    display: inline-block;\n    font-size: 14px;\n    font-weight: 600;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    height: 35px;\n    cursor: pointer;\n    color: #0084f6; }\n.bulk-dropdown .bulk-dropbtn-border:active {\n      -webkit-box-shadow: none;\n              box-shadow: none; }\n.bulk-dropdown .bulk-dropbtn-border::focus {\n      outline: none; }\n.bulk-dropdown .bulk-dropdown-content {\n    display: block;\n    position: absolute;\n    background-color: #f9f9f9;\n    min-width: 70px;\n    left: 75%;\n    -webkit-box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);\n            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);\n    z-index: 1;\n    text-align: left;\n    cursor: pointer; }\n.bulk-dropdown .bulk-dropdown-content a {\n    color: black;\n    padding: 12px 16px;\n    text-decoration: none;\n    display: block; }\n.bulk-dropdown .bulk-dropdown-content a:hover {\n    background-color: #f1f1f1; }\n.sidenav {\n  max-height: 480px;\n  width: 0;\n  position: absolute;\n  z-index: 1;\n  top: 100px;\n  right: 0;\n  overflow-y: scroll;\n  overflow-x: hidden;\n  -webkit-transition: 0.1s;\n  transition: 0.1s; }\n.sidenav ::-webkit-scrollbar {\n    display: none;\n    width: 7px;\n    height: 7px; }\n.sidenav a {\n  padding: 8px 8px 8px 32px;\n  text-decoration: none;\n  font-size: 25px;\n  color: #d60909;\n  display: block; }\n.sidenav a:hover {\n  color: #d60909; }\n.sidenav .closebtn {\n  position: absolute;\n  left: 80%;\n  top: 10px;\n  font-size: 16px;\n  font-weight: 900;\n  position: absolute;\n  top: 20px;\n  margin-right: 50px; }\n#main {\n  -webkit-transition: margin-right .5s;\n  transition: margin-right .5s;\n  padding: 16px; }\n.checkBoxAllignMent {\n  margin-right: 20px;\n  margin-top: 5px; }\n.checkBoxAllignMent.field-checkbox-wrapper {\n    margin-bottom: 0px; }\n@media screen and (max-height: 450px) {\n  .sidenav {\n    padding-top: 15px; }\n  .sidenav a {\n    font-size: 18px; } }\n.skeleton:empty {\n  margin: 30px 0px 0px -100px;\n  width: 500px;\n  height: 400px;\n  background-image: linear-gradient(90deg, rgba(255, 255, 255, 0) 10%, rgba(255, 255, 255, 0.5) 20%, rgba(255, 255, 255, 0.5) 50%, rgba(255, 255, 255, 0.5) 20%, rgba(255, 255, 255, 0) 80%), linear-gradient(lightgray 10px, transparent 0), linear-gradient(lightgray 10px, transparent 0), linear-gradient(lightgray 10px, transparent 0), linear-gradient(lightgray 10px, transparent 0), linear-gradient(lightgray 10px, transparent 0), linear-gradient(lightgray 10px, transparent 0);\n  background-repeat: repeat-y;\n  background-size: 350px 200px, 350px 200px, 350px 200px, 350px 200px, 350px 200px, 350px 200px, 150px 200px, 150px 200px;\n  background-position: 80px 0px, 80px 0px, 80px 0px, 80px 40px, 80px 80px, 80px 120px;\n  -webkit-animation: shine 1s infinite;\n  animation: shine 1s infinite; }\n@-webkit-keyframes shine {\n  to {\n    background-position: 0 0, 100% 0, 100px 0, 100px 40px, 100px 80px, 100px 120px; } }\n@keyframes shine {\n  to {\n    background-position: 0 0, 100% 0, 100px 0, 100px 40px, 100px 80px, 100px 120px; } }\n.editCellInput {\n  width: 50px !important;\n  border: 1px solid rgba(119, 119, 119, 0.34);\n  border-radius: 5px;\n  text-align: center; }\n.btn-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  width: auto; }\n.search-filter-wrapper .normal-field {\n  margin-right: 10px;\n  padding: 4px 10px;\n  border: 1px solid #ccc;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  height: 35px;\n  font-size: 14px; }\n.table-content {\n  margin-top: 20px; }\n.structure-table tr th {\n  padding: 10px 10px !important; }\n.disable_input {\n  background: lightgrey !important;\n  cursor: not-allowed; }\n"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/template-home/template-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TemplateHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_rxjs_Rx__ = __webpack_require__("./node_modules/rxjs/_esm5/Rx.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_utils_facade_browser__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/utils/facade/browser.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_feeStruc_service__ = __webpack_require__("./src/app/services/feeStruc.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var TemplateHomeComponent = /** @class */ (function () {
    function TemplateHomeComponent(router, fetchService, auth, commonService) {
        this.router = router;
        this.fetchService = fetchService;
        this.auth = auth;
        this.commonService = commonService;
        this.isProfessional = false;
        this.countryAdditioalFeeTypes = {};
        this.source = [];
        this.isHeaderEdit = false;
        this.isEditFee = false;
        this.installmentList = [];
        this.otherInstList = [];
        this.otherFeetype = [];
        this.countryDetails = [];
        this.AddInstallment = {
            days: 0,
            day_type: 1,
            fee_type: 0,
            fees_amount: 0,
            initial_fee_amount: 0,
            is_referenced: 'N',
            schedule_id: 0,
            service_tax: 0,
            service_tax_applicable: "N",
            tax: 0,
            taxAmount: 0,
        };
        this.additionalInstallment = {
            days: 0,
            day_type: 1,
            fee_type: -1,
            fees_amount: 0,
            initial_fee_amount: 0,
            is_referenced: 'N',
            schedule_id: 0,
            service_tax: 0,
            service_tax_applicable: 'N',
            fee_type_name: ''
        };
        this.customJson = [];
        this.totalAmount = '';
        this.discountAmount = '';
        this.isRippleLoad = false;
        this.feeTyeDetails = [];
        this.tabkeList = [];
        this.searchedData = [];
        this.studentList = [];
        this.totalAmountCal = 0;
        this.templateName = "";
        this.PageIndex = 0;
        this.displayBatchSize = 20;
        this.totalRow = 0;
        this.searchText = '';
        this.addTemplatePopUp = false;
        this.searchDataFlag = false;
        if (sessionStorage.getItem('userid') == null) {
            this.router.navigate(['/authPage']);
        }
    }
    TemplateHomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.enableTax = sessionStorage.getItem('enable_tax_applicable_fee_installments');
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.isProfessional = true;
                _this.moduleState = 'Batch';
            }
            else {
                _this.isProfessional = false;
                _this.moduleState = 'Course';
            }
        });
        this.fetchPrefill();
    };
    TemplateHomeComponent.prototype.fetchPrefill = function () {
        this.getFeeStructures();
        this.fetchDataForCountryDetails();
    };
    TemplateHomeComponent.prototype.fetchDataForCountryDetails = function () {
        var _this = this;
        this.countryAdditioalFeeTypes = {};
        var encryptedData = sessionStorage.getItem('country_data');
        var data = JSON.parse(encryptedData);
        if (data.length > 0) {
            this.countryDetails = data;
            var country_ids_1 = [];
            this.countryDetails.forEach(function (item) {
                _this.countryAdditioalFeeTypes[item.id] = [];
                country_ids_1.push(item.id);
            });
            this.fetchService.additionalFeeTypeDetail(country_ids_1.join()).subscribe(function (res) {
                res && res.forEach(function (fee) {
                    var country_id = fee.countryId.country_id;
                    var fee_details = {};
                    fee_details[fee.fee_type_id] = fee.fee_type;
                    _this.countryAdditioalFeeTypes[country_id].push(fee_details);
                });
            }, function (err) {
                _this.commonService.showErrorMessage('error', '', err.error.message);
            });
        }
        // console.log(data);
    };
    TemplateHomeComponent.prototype.getFeeStructures = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.PageIndex = 1;
        this.fetchService.fetchFeeStruc().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.totalRow = res.length;
            _this.source = res;
            _this.fetchTableDataByPage(_this.PageIndex);
        }, function (err) {
            _this.isRippleLoad = false;
        });
    };
    TemplateHomeComponent.prototype.changesValuesAsPerType = function (row) {
        if (row.day_type == 1) {
            row.days = 0;
        }
    };
    TemplateHomeComponent.prototype.editFee = function (fee) {
        var _this = this;
        this.templateName = fee.template_name;
        this.selectedTemplate = fee;
        this.feeStructure = [];
        this.isEditFee = true;
        this.isRippleLoad = true;
        this.fetchService.fetchFeeDetail(fee.template_id).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.feeStructure = res;
            if (res.is_default == "1") {
                _this.feeStructure.is_default = true;
            }
            else {
                _this.feeStructure.is_default = false;
            }
            _this.fillFeeType(_this.countryAdditioalFeeTypes[_this.selectedTemplate.country_id]);
            var encryptedData = sessionStorage.getItem('country_data');
            var data = JSON.parse(encryptedData);
            if (data.length > 0) {
                data.forEach(function (country) {
                    if (_this.selectedTemplate.country_id == country.id) {
                        _this.selectedCountry = country;
                    }
                });
            }
            _this.fillDataInYTable(res.customFeeSchedules);
            if (res.studentwise_fees_tax_applicable == "Y") {
                if (_this.enableTax == "1" &&
                    __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('checkBoxtaxes')) {
                    __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('checkBoxtaxes').checked = true;
                    _this.showTaxFields();
                }
            }
            _this.totalAmountCal = res.studentwise_total_fees_amount;
        }, function (err) {
            _this.isRippleLoad = false;
        });
    };
    TemplateHomeComponent.prototype.showTaxFields = function () {
        this.installmentList.forEach(function (element) {
            if (element.service_tax_applicable == "Y") {
                element.taxAmount = element.fees_amount - element.initial_fee_amount;
                element.tax = element.taxAmount;
            }
        });
    };
    TemplateHomeComponent.prototype.fillFeeType = function (data) {
        var _this = this;
        this.otherFeetype = [];
        data.forEach(function (object) {
            var keys = Object.keys(object);
            var test = {};
            test.id = keys[0];
            test.value = object[keys[0]];
            _this.otherFeetype.push(test);
        });
    };
    TemplateHomeComponent.prototype.fillDataInYTable = function (data) {
        this.installmentList = [];
        this.otherInstList = [];
        for (var t = 0; t < data.length; t++) {
            if (data[t].fee_type_name == "INSTALLMENT") {
                this.installmentList.push(data[t]);
            }
            else {
                this.otherInstList.push(data[t]);
            }
        }
    };
    TemplateHomeComponent.prototype.closeFeeEditor = function () {
        this.getFeeStructures();
        this.isHeaderEdit = false;
        this.isEditFee = false;
        this.templateName = "";
    };
    TemplateHomeComponent.prototype.updateFeeTemplate = function () {
        var _this = this;
        var taxApplicable = __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('checkBoxtaxes').checked;
        if (taxApplicable == true) {
            taxApplicable = "Y";
        }
        else {
            taxApplicable = "N";
        }
        var set_is_default = '0';
        if (this.feeStructure.is_default == '1' || this.feeStructure.is_default == true) {
            set_is_default = '1';
        }
        var data = {
            is_default: set_is_default,
            country_id: this.selectedTemplate.country_id,
            customFeeSchedules: this.makeJSONForCustomFee(),
            studentwise_total_fees_amount: this.totalAmount.toString(),
            studentwise_total_fees_discount: this.discountAmount,
            studentwise_fees_tax_applicable: taxApplicable,
            template_id: this.selectedTemplate.template_id.toString(),
            template_name: this.selectedTemplate.template_name
        };
        this.isRippleLoad = true;
        this.fetchService.updateFeeTemplate(data).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.commonService.showErrorMessage('success', 'Update Successfully', 'Fee Structure Updated Successfully');
            _this.closeFeeEditor();
        }, function (err) {
            _this.isRippleLoad = false;
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    TemplateHomeComponent.prototype.makeJSONForCustomFee = function () {
        this.customJson = [];
        this.totalAmount = 0;
        this.discountAmount = 0;
        var data = [];
        for (var t = 0; t < this.installmentList.length; t++) {
            var test = {};
            test.fee_type = 0;
            test.initial_fee_amount = this.installmentList[t].initial_fee_amount.toString();
            test.service_tax = this.installmentList[t].service_tax.toString();
            test.fees_amount = this.installmentList[t].fees_amount.toString();
            test.service_tax_applicable = this.installmentList[t].service_tax_applicable;
            test.schedule_id = this.installmentList[t].schedule_id.toString();
            test.is_referenced = this.installmentList[t].is_referenced;
            test.day_type = this.installmentList[t].day_type.toString();
            test.days = Number(this.installmentList[t].days).toString();
            this.totalAmount = this.totalAmount + this.installmentList[t].fees_amount;
            this.discountAmount = this.discountAmount + this.installmentList[t].fees_amount - this.installmentList[t].initial_fee_amount;
            data.push(test);
        }
        for (var t = 0; t < this.otherInstList.length; t++) {
            var test = {};
            test.fee_type = this.otherInstList[t].fee_type;
            test.initial_fee_amount = this.otherInstList[t].initial_fee_amount.toString();
            test.service_tax = this.otherInstList[t].service_tax.toString();
            test.fees_amount = this.otherInstList[t].fees_amount.toString();
            test.service_tax_applicable = this.otherInstList[t].service_tax_applicable;
            test.schedule_id = this.otherInstList[t].schedule_id.toString();
            test.is_referenced = this.otherInstList[t].is_referenced;
            test.day_type = this.otherInstList[t].day_type.toString();
            test.days = Number(this.otherInstList[t].days).toString();
            this.totalAmount = this.totalAmount + this.otherInstList[t].fees_amount;
            this.discountAmount = this.discountAmount + this.otherInstList[t].fees_amount - this.otherInstList[t].initial_fee_amount;
            data.push(test);
        }
        this.customJson = data;
        return data;
    };
    TemplateHomeComponent.prototype.updateTemplateName = function () {
        if (this.selectedTemplate.template_name.trim() != '') {
            this.isHeaderEdit = false;
        }
        else {
            this.commonService.showErrorMessage('error', 'Fee Template Name is Mandatory', 'Please enter a valid fee template name');
        }
    };
    TemplateHomeComponent.prototype.onApplyTaxChechbox = function (event) {
        if (this.enableTax == "0") {
            this.commonService.showErrorMessage('error', '', 'Please define Tax (%age) in Institute Settings');
            event.target.checked = false;
            return;
        }
        if (event.target.checked) {
            this.installmentList.forEach(function (element) {
                if (element.service_tax_applicable == "Y" && element.hasOwnProperty('taxAmount')) {
                    element.fees_amount = Number(element.fees_amount) + Number(element.taxAmount);
                    element.tax = element.taxAmount;
                }
                else {
                    element.tax = Number(element.service_tax) * 0.01 * Number(element.initial_fee_amount);
                    element.taxAmount = element.tax;
                    element.fees_amount = element.initial_fee_amount + element.taxAmount;
                }
                element.service_tax_applicable = "Y";
            });
        }
        else {
            this.installmentList.forEach(function (element) {
                element.fees_amount = Number(element.fees_amount) - Number(element.taxAmount);
                element.tax = 0;
                element.service_tax_applicable = "N";
            });
        }
        this.calculateTotalAmount();
    };
    TemplateHomeComponent.prototype.calculateTotalAmount = function () {
        var totalAmount = 0;
        this.installmentList.forEach(function (element) {
            totalAmount += Number(element.fees_amount);
        });
        this.otherInstList.forEach(function (element) {
            totalAmount += Number(element.fees_amount);
        });
        this.totalAmountCal = totalAmount;
    };
    // calculateTotalAmount() {
    //   if (document.getElementById('checkBoxtaxes').checked == true) {
    //     let otherAmount = 0;
    //     if (this.otherInstList.length > 0) {
    //       otherAmount = this.otherInstList.map(fee => fee.fees_amount).reduce((acc, val) => val + acc)
    //     } else {
    //       otherAmount = 0;
    //     }
    //     return Math.floor(this.onApplyTaxChechbox() + otherAmount);
    //   } else {
    //     let installAmount = 0;
    //     let otherAmount = 0;
    //     if (this.installmentList.length > 0) {
    //       installAmount = this.installmentList.map(fee => fee.initial_fee_amount).reduce((acc, val) => val + acc);
    //     }
    //     if (this.otherInstList.length > 0) {
    //       otherAmount = this.otherInstList.map(fee => fee.fees_amount).reduce((acc, val) => val + acc);
    //     }
    //     return Math.floor(installAmount + otherAmount);
    //   }
    // }
    // onApplyTaxChechbox() {
    //   let taxPercent = this.feeStructure.registeredServiceTax;
    //   if (sessionStorage.getItem('enable_tax_applicable_fee_installments') == '1') {
    //     if (this.installmentList.length > 0) {
    //       this.addTaxInInstallmentTable();
    //       return (this.totalAmountCal);
    //     } else {
    //       return 0;
    //     }
    //   } else {
    //     let msg = {
    //       type: 'error',
    //       title: '',
    //       body: "Please define Tax (%age) in Institute Settings"
    //     }
    //     this.appC.popToast(msg);
    //     document.getElementById('checkBoxtaxes').checked == false;
    //     this.calculateTotalAmount();
    //   }
    // }
    // addTaxInInstallmentTable() {
    //   this.totalAmountCal = 0;
    //   if (sessionStorage.getItem('enable_tax_applicable_fee_installments') == '1') {
    //     let taxPercent = this.feeStructure.registeredServiceTax;
    //     if (document.getElementById('checkBoxtaxes').checked == true) {
    //       if (taxPercent > 0) {
    //         this.installmentList.map(
    //           fee => {
    //             if (fee.service_tax_applicable == "Y") {
    //               fee.tax = Math.floor(fee.fees_amount - fee.initial_fee_amount)
    //               this.totalAmountCal = this.totalAmountCal + fee.fee_amount;
    //             } else {
    //               fee.tax = Math.floor(fee.fees_amount * 0.01 * taxPercent);
    //               fee.initial_fee_amount = fee.fees_amount - fee.tax;
    //               fee.service_tax_applicable = "Y";
    //               this.totalAmountCal = this.totalAmountCal + fee.fees_amount;
    //             }
    //           }
    //         )
    //       }
    //     } else {
    //       this.installmentList.map(
    //         fee => {
    //           if (fee.service_tax_applicable == "Y") {
    //             fee.initial_fee_amount = fee.fee_amount - fee.tax;
    //             fee.tax = 0;
    //             fee.fees_amount = fee.tax + fee.initial_fee_amount;
    //             fee.service_tax_applicable = "N";
    //           } else {
    //             fee.tax = 0;
    //             fee.fees_amount = fee.initial_fee_amount;
    //           }
    //           this.totalAmountCal = this.totalAmountCal + fee.fees_amount;
    //         }
    //       )
    //     }
    //     if (this.otherInstList.length > 0) {
    //       this.totalAmountCal = this.totalAmountCal + this.otherInstList.map(fee => fee.fees_amount).reduce((acc, val) => val + acc);
    //     }
    //   }
    // }  
    TemplateHomeComponent.prototype.deleteRow = function (row, i) {
        this.installmentList.splice(i, 1);
        this.calculateTotalAmount();
    };
    TemplateHomeComponent.prototype.deleteAdditionalRow = function (row, i) {
        this.otherInstList.splice(i, 1);
        this.calculateTotalAmount();
    };
    TemplateHomeComponent.prototype.addInstallmentInTable = function () {
        if (Number(this.AddInstallment.initial_fee_amount) > 0 && this.AddInstallment.days != null) {
            if (sessionStorage.getItem('enable_tax_applicable_fee_installments') == '1') {
                this.AddInstallment.service_tax = Number(this.feeStructure.registeredServiceTax);
                if (__WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_utils_facade_browser__["a" /* document */].getElementById('checkBoxtaxes').checked) {
                    this.AddInstallment.service_tax_applicable = "Y";
                    this.AddInstallment.tax = Math.floor(this.AddInstallment.initial_fee_amount * Number(this.feeStructure.registeredServiceTax) * 0.01);
                    this.AddInstallment.taxAmount = Number(this.AddInstallment.tax);
                    this.AddInstallment.fees_amount = Number(this.AddInstallment.initial_fee_amount + this.AddInstallment.tax);
                }
                else {
                    this.AddInstallment.service_tax_applicable = "N";
                    this.AddInstallment.fees_amount = this.AddInstallment.initial_fee_amount;
                    this.AddInstallment.tax = 0;
                }
            }
            else {
                this.AddInstallment.tax = 0;
                this.AddInstallment.fees_amount = this.AddInstallment.initial_fee_amount;
            }
            this.installmentList.push(this.AddInstallment);
            this.AddInstallment = {
                days: 0,
                day_type: 1,
                fee_type: 0,
                fees_amount: 0,
                initial_fee_amount: 0,
                is_referenced: 'N',
                schedule_id: 0,
                service_tax: 0,
                service_tax_applicable: 'N',
                tax: 0,
                taxAmount: 0,
            };
        }
        else {
            if (this.AddInstallment.initial_fee_amount == null || this.AddInstallment.initial_fee_amount == 0) {
                this.commonService.showErrorMessage('error', '', 'Please enter Amount');
                return;
            }
            if (this.AddInstallment.days == null) {
                this.commonService.showErrorMessage('error', '', 'Please enter days/month');
                return;
            }
        }
        this.calculateTotalAmount();
    };
    TemplateHomeComponent.prototype.addAdditionalInst = function () {
        if (this.additionalInstallment.fee_type == -1) {
            this.commonService.showErrorMessage('error', '', 'Please enter fee type');
            return;
        }
        if (Number(this.additionalInstallment.initial_fee_amount) > 0 && this.additionalInstallment.days != null) {
            // this.additionalInstallment.fees_amount = this.additionalInstallment.initial_fee_amount;
            if (this.additionalInstallment.fees_amount == 0) {
                if (this.additionalInstallment.service_tax == 0) {
                    this.additionalInstallment.fees_amount = this.additionalInstallment.initial_fee_amount;
                }
            }
            else {
                if (this.additionalInstallment.service_tax == 0) {
                    this.additionalInstallment.fees_amount = this.additionalInstallment.initial_fee_amount;
                }
                else {
                    this.additionalInstallment.fees_amount = Math.round(Number(this.additionalInstallment.initial_fee_amount) + Number((this.additionalInstallment.initial_fee_amount * this.additionalInstallment.service_tax) / 100));
                }
            }
            this.otherInstList.push(this.additionalInstallment);
            this.additionalInstallment = {
                days: 0,
                day_type: 1,
                fee_type: -1,
                fees_amount: 0,
                initial_fee_amount: 0,
                is_referenced: 'N',
                schedule_id: 0,
                service_tax: 0,
                service_tax_applicable: 'N',
                fee_type_name: ''
            };
        }
        else {
            if (this.additionalInstallment.initial_fee_amount == 0 || this.additionalInstallment.initial_fee_amount == null) {
                this.commonService.showErrorMessage('error', '', 'Please enter Amount');
                return;
            }
            if (this.additionalInstallment.days == null) {
                this.commonService.showErrorMessage('error', '', 'Please enter days');
                return;
            }
        }
        this.calculateTotalAmount();
    };
    TemplateHomeComponent.prototype.onAdditionalFeeSelection = function (event) {
        var _this = this;
        var id = event;
        this.feeTyeDetails = [];
        this.fetchService.getAdditionalFeeDeatails(event).subscribe(function (res) {
            _this.feeTyeDetails = res;
            _this.additionalInstallment.initial_fee_amount = res.fee_amount;
            _this.additionalInstallment.service_tax = res.fee_type_tax;
            _this.additionalInstallment.fee_type = res.fee_type_id;
            if (res.fee_type_tax > 0) {
                _this.additionalInstallment.service_tax_applicable = "Y";
            }
            _this.additionalInstallment.fee_type = id;
            _this.additionalInstallment.fees_amount = res.fee_amount + (res.fee_amount * res.fee_type_tax * 0.01);
            _this.additionalInstallment.fee_type_name = res.fee_type;
        }, function (err) {
            _this.commonService.showErrorMessage('error', '', err.error.message);
        });
    };
    TemplateHomeComponent.prototype.editTemplateName = function () {
        this.isHeaderEdit = true;
    };
    TemplateHomeComponent.prototype.cancelTemplateName = function () {
        this.isHeaderEdit = false;
        this.selectedTemplate.template_name = this.templateName;
    };
    TemplateHomeComponent.prototype.feeTypesAmountChnge = function (data) {
        if (data.service_tax == 0) {
            data.initial_fee_amount = Math.floor(Number(data.fees_amount));
        }
        else {
            data.initial_fee_amount = Math.floor(Number(data.fees_amount)) - Math.floor(Number(data.fees_amount) - Number((data.fees_amount * 100) / (100 + data.service_tax)));
            data.initial_fee_amount = Math.floor(data.initial_fee_amount);
        }
        this.calculateTotalAmount();
    };
    TemplateHomeComponent.prototype.feeInstallmentChnge = function (data) {
        if (data.service_tax_applicable == "N") {
            data.initial_fee_amount = data.fees_amount;
        }
        else {
            data.tax = data.fees_amount - Math.floor(Number(data.fees_amount) * 100 / (100 + data.service_tax));
            data.taxAmount = data.tax;
            data.initial_fee_amount = data.fees_amount - data.tax;
        }
        this.calculateTotalAmount();
    };
    // pagination functions
    TemplateHomeComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.tabkeList = this.getDataFromDataSource(startindex);
    };
    TemplateHomeComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    TemplateHomeComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    TemplateHomeComponent.prototype.getDataFromDataSource = function (startindex) {
        var data = [];
        if (this.searchDataFlag == true) {
            data = this.searchedData.slice(startindex, startindex + this.displayBatchSize);
        }
        else {
            data = this.source.slice(startindex, startindex + this.displayBatchSize);
        }
        return data;
    };
    TemplateHomeComponent.prototype.searchInList = function () {
        var _this = this;
        if (this.searchText.trim() != "" && this.searchText.trim() != null) {
            var searchData = this.source.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.searchedData = searchData;
            this.totalRow = searchData.length;
            this.searchDataFlag = true;
            this.PageIndex = 1;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchDataFlag = false;
            this.fetchTableDataByPage(this.PageIndex);
            this.totalRow = this.source.length;
        }
    };
    ////Delete Fee Structure
    TemplateHomeComponent.prototype.deleteFeeStructure = function (fee) {
        var _this = this;
        var is_archived = "N";
        if (confirm('Are you sure, you want to delete Fee Structure?')) {
            this.isRippleLoad = true;
            this.fetchService.deleteFeeStructure(fee.template_id, is_archived).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.commonService.showErrorMessage('success', 'Deleted', 'Fee Structure Deleted Successfully');
                _this.getFeeStructures();
                _this.searchText = "";
                _this.searchDataFlag = false;
            }, function (err) {
                _this.isRippleLoad = false;
                if (err.error.message.includes("Fee template(s) are assigned to student(s).")) {
                    if (confirm('Fee template(s) are assigned to student(s). Do you wish to delete it ?')) {
                        is_archived = "Y";
                        _this.isRippleLoad = true;
                        _this.fetchService.deleteFeeStructure(fee.template_id, is_archived).subscribe(function (res) {
                            _this.isRippleLoad = false;
                            _this.commonService.showErrorMessage('success', 'Deleted', 'Fee Structure Deleted Successfully');
                            _this.getFeeStructures();
                        }, function (err) {
                            _this.isRippleLoad = false;
                            _this.commonService.showErrorMessage('error', '', err.error.message);
                        });
                    }
                }
                else {
                    _this.commonService.showErrorMessage('error', '', err.error.message);
                }
            });
        }
    };
    // for showing students assigned to the particular fee template
    TemplateHomeComponent.prototype.studentsAssigned = function (fee) {
        if (fee.studentList != null) {
            this.addTemplatePopUp = true;
            this.studentList = fee.studentList;
        }
        else {
            this.commonService.showErrorMessage("info", "", "No data found");
            this.addTemplatePopUp = false;
        }
    };
    TemplateHomeComponent.prototype.closeTemplatePopup = function () {
        this.addTemplatePopUp = false;
    };
    TemplateHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-template-home',
            template: __webpack_require__("./src/app/components/fee-module/data-setup/fee-template/template-home/template-home.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/data-setup/fee-template/template-home/template-home.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_4__services_feeStruc_service__["a" /* FeeStrucService */],
            __WEBPACK_IMPORTED_MODULE_5__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_6__services_common_service__["a" /* CommonServiceFactory */]])
    ], TemplateHomeComponent);
    return TemplateHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/template-popup/template-popup.component.html":
/***/ (function(module, exports) {

module.exports = "<section id=\"popup\" class=\"popupWrapper fadeIn\">\r\n    <div class=\"popup pos-abs\">\r\n      <div class=\"popup-wrapper pos-rel\">\r\n        <!-- Project content for close button here -->\r\n        <ng-content select=\"[close-button]\"></ng-content>\r\n        <div class=\"popup-content\">\r\n          <!-- project content for header here -->\r\n          <ng-content select=\"[popup-header]\"></ng-content>\r\n          \r\n          <div class=\"update-enquiry-form overflowHidden\">\r\n            \r\n            <!-- project content for popup here -->\r\n            <ng-content select=\"[popup-content]\"></ng-content>\r\n  \r\n            <!-- project footer for popup here -->\r\n            <ng-content select=\"[popup-footer]\"></ng-content>\r\n            \r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/template-popup/template-popup.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.table-data-overflow table tbody td {\n  max-width: 100px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap; }\n.middle-section {\n  padding: 15px; }\n.boxPadding15, .middle-left, .middle-right {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 0 15px; }\n.middle-left {\n  width: 70%; }\n.middle-right {\n  width: 30%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding: 0 15px; }\n.accordian-section {\n  padding: 15px 10px 0; }\n.accordian-section .accordian-heading h4 {\n    font-size: 14px;\n    font-weight: 600;\n    color: #ddd; }\n.accordian-section .accordian-heading h4 .open-accor {\n      display: none;\n      float: right;\n      width: 24px;\n      font-size: 24px;\n      height: 24px;\n      text-align: center;\n      border: none;\n      border-radius: 50%;\n      line-height: 24px;\n      margin-right: 4px;\n      margin-top: 3px;\n      cursor: pointer;\n      color: #0084f6; }\n.accordian-section .accordian-heading h4 .close-accor {\n      float: right;\n      width: 24px;\n      font-size: 31px;\n      height: 24px;\n      text-align: center;\n      border: none;\n      border-radius: 50%;\n      line-height: 16px;\n      margin-right: 4px;\n      margin-top: 5px;\n      cursor: pointer;\n      color: #0084f6;\n      font-weight: 400; }\n.accordian-section .accordian-content {\n    padding-left: 50px; }\n.accordian-section .accordian > li {\n    position: relative;\n    padding-bottom: 25px; }\n.accordian-section .accordian > li:before {\n      content: '';\n      width: 1px;\n      height: 90.5%;\n      position: absolute;\n      background: #cccccc;\n      z-index: 0;\n      left: 15px;\n      top: 34px;\n      display: block; }\n.accordian-section .accordian > li:last-child:before {\n      display: none; }\n.accordian-section .accordian > li.active .circle-accor, .accordian-section .accordian > li.data-filled .circle-accor {\n      background: #0084f6;\n      color: #fff;\n      border-color: #0084f6; }\n.accordian-section .accordian > li.active .accordian-heading h4, .accordian-section .accordian > li.data-filled .accordian-heading h4 {\n      color: #333; }\n.accordian-section .accordian > li.data-filled .accordian-content {\n      display: none; }\n.accordian-section .accordian > li.data-filled .accordian-heading h4 {\n      color: #444;\n      border: 1px solid #eaecee;\n      padding: 1px;\n      border-radius: 20px;\n      background: #e6f2fe; }\n.accordian-section .accordian > li.data-filled .accordian-heading h4 .open-accor {\n        display: block; }\n.accordian-section .accordian > li.data-filled .accordian-heading h4 .close-accor {\n        display: none; }\n.accordian-section .accordian > li.data-filled.active .accordian-content {\n      display: block; }\n.accordian-section .accordian > li.data-filled.active .accordian-heading h4 .open-accor {\n      display: none; }\n.accordian-section .accordian > li.data-filled.active .accordian-heading h4 .close-accor {\n      display: block; }\n.more-detail {\n  margin-top: 10px;\n  font-size: 12px; }\n.circle-accor {\n  display: inline-block;\n  width: 32px;\n  border-radius: 50%;\n  text-align: center;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  padding-top: 4px;\n  font-size: 14px;\n  background: #f0f0f0;\n  height: 32px;\n  border: 1px solid #bbb;\n  margin-right: 5px;\n  color: #ceced1;\n  padding: 0;\n  line-height: 30px; }\n.form-type2,\n.form-type1 {\n  max-width: 360px; }\n.paddingR30 {\n  padding-right: 30px; }\n.form-type2 .field-wrapper {\n  padding-right: 35px; }\n.form-type2 .customSelectWrapper:after {\n  right: 35px; }\n.questionInfo {\n  position: absolute;\n  right: 0px;\n  bottom: 5px;\n  height: 20px;\n  width: 20px;\n  z-index: 2; }\n.questionInfo .qInfoIcon {\n    width: 20px;\n    height: 20px;\n    border: 1px solid #ccc;\n    border-radius: 50%;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    line-height: 20px;\n    font-weight: 600;\n    font-size: 12px;\n    cursor: pointer;\n    -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n            box-shadow: 0px 0px 1px 0px #ccc inset;\n    color: #888;\n    -webkit-transition: all 0.6s linear;\n    transition: all 0.6s linear; }\n.questionInfo .qInfoIcon:hover {\n      border-color: #0060A3;\n      -webkit-box-shadow: 0px 0px 1px 0px #0060A3 inset;\n              box-shadow: 0px 0px 1px 0px #0060A3 inset;\n      color: #0060A3; }\n.create-institution {\n  position: absolute;\n  right: -98px;\n  white-space: nowrap;\n  bottom: 6px;\n  font-size: 12px;\n  font-weight: 600; }\n.shadow-box {\n  -webkit-box-shadow: 0px 2px 2px #7d7d7d;\n          box-shadow: 0px 2px 2px #7d7d7d;\n  padding: 7px;\n  border-radius: 2px;\n  background: #eff7ff; }\n.last-added-info {\n  font-size: 12px; }\n.last-added-info ul li {\n    line-height: normal;\n    padding: 2px 0;\n    display: inline-block;\n    width: 100%;\n    vertical-align: top; }\n.last-added-info strong {\n    font-weight: 600;\n    color: #28384a; }\n.last-added-info .view-details {\n    float: right;\n    font-size: 11px; }\n.last-added-info .view-details a:hover {\n      text-decoration: underline; }\n.last-added-info .enquiry-time {\n    float: right;\n    font-size: 10px;\n    color: #28384a;\n    margin-top: 4px; }\n/*=======================Right bottom lite shadow box======================*/\n.box-shadow-lite {\n  -webkit-box-shadow: 0px 1px 2px 0px #ccc;\n          box-shadow: 0px 1px 2px 0px #ccc;\n  padding: 10px 0 10px 10px;\n  border-top: 1px solid #e8e8e8; }\n.box-shadow-lite .field-wrapper {\n    padding-right: 40px; }\n.box-shadow-lite .field-wrapper .open-accor {\n      width: 17px;\n      font-size: 17px;\n      height: 17px;\n      line-height: 18px;\n      position: absolute;\n      right: 4px;\n      top: 19px;\n      z-index: 2; }\n.box-shadow-lite .field-wrapper:first-child {\n      margin-top: -10px; }\n.common-right-section {\n  margin-top: 30px; }\n.common-right-section h4 {\n    margin-bottom: 7px;\n    color: #28383A;\n    font-size: 16px; }\n.common-right-section h4 strong {\n      font-weight: 600; }\n.common-right-section .clear-detail {\n    margin-top: 10px;\n    font-size: 12px;\n    margin-bottom: 10px; }\n.follow-up-date-icon {\n  position: absolute;\n  position: absolute;\n  right: 7px;\n  top: 20px;\n  cursor: pointer; }\n.follow-up-date-icon img {\n    width: 21px; }\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 890px;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n/*=========================================registration popup form css==================*/\n.registration-fee-form {\n  overflow: hidden; }\n.print-output-section {\n  margin: 35px 0 25px;\n  border-top: 1px solid #deeaee;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  border-bottom: 1px solid #deeaee;\n  text-align: center;\n  font-size: 0; }\n.print-output-section li {\n    display: inline-block;\n    padding: 0 15px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    width: 25%;\n    border-right: 1px solid #deeaee;\n    font-size: 15px;\n    cursor: pointer;\n    color: #929292; }\n.print-output-section li:last-child {\n      border-right: 0; }\n.print-output-section li:hover {\n      color: #0084f6; }\n.print-output-section li svg {\n      width: 30px;\n      display: inline-block;\n      vertical-align: middle;\n      margin-right: 8px; }\n.print-output-section li svg .cls-1 {\n        stroke: none;\n        stroke: #929292; }\n.print-output-section li.svg-icon .cls-1 {\n      stroke: none; }\n.print-output-section li.svg-icon .cls-2 {\n      stroke: #929292; }\n.print-output-section li.svg-icon:hover .cls-2 {\n      stroke: #0084f6; }\n.print-output-section li:first-child:hover svg .cls-1 {\n      stroke: #0084f6; }\n/*=======================================confirmation =========================*/\n.confirmation-popup-content {\n  line-height: normal; }\n.confirmation-popup-content > div {\n    margin-bottom: 10px; }\n.confirmation-popup-content > div:first-child {\n      margin-bottom: 20px; }\n.confirmation-popup-content > div a,\n    .confirmation-popup-content > div p {\n      font-size: 16px;\n      line-height: 22px; }\n.confirmation-popup-content > div a {\n      font-weight: 600; }\n.confirmation-popup-content > div a:hover {\n      text-decoration: underline; }\n.confirmation-popup-content strong {\n    font-weight: 600; }\n.confirmation-popup-content .add-form-btns a {\n    margin-left: 20px;\n    font-size: 14px; }\n.popup-btn {\n  margin-top: 20px; }\n.popup-btn .btn {\n    font-size: 16px;\n    height: 40px;\n    color: #333; }\n.popup-btn .btn.redBtn {\n      color: #fff;\n      min-width: 160px; }\n.update-enquiry-form table th {\n  text-align: left;\n  padding: 10px;\n  font-size: 14px; }\n.update-enquiry-form table td {\n  text-align: left;\n  padding: 10px;\n  font-size: 14px; }\n.enquiry-update-history {\n  max-height: 110px;\n  overflow: auto; }\n.update-enquiry-form .row {\n  margin: 10px -15px 20px; }\n.confirmation-popup-content:after {\n  content: '';\n  height: 8px;\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  width: 100%;\n  background: #8bc34a; }\n.row.extraMargin {\n  margin: 10px -15px 20px; }\n"

/***/ }),

/***/ "./src/app/components/fee-module/data-setup/fee-template/template-popup/template-popup.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TemplatePopUpComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var TemplatePopUpComponent = /** @class */ (function () {
    function TemplatePopUpComponent() {
    }
    TemplatePopUpComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'template-popup',
            template: __webpack_require__("./src/app/components/fee-module/data-setup/fee-template/template-popup/template-popup.component.html"),
            styles: [__webpack_require__("./src/app/components/fee-module/data-setup/fee-template/template-popup/template-popup.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], TemplatePopUpComponent);
    return TemplatePopUpComponent;
}());



/***/ })

});
//# sourceMappingURL=fee-template.module.chunk.js.map