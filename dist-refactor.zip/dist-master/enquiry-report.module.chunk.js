webpackJsonp(["enquiry-report.module"],{

/***/ "./src/app/components/leads/enquiry-report/counsellor-report/counsellor-report.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"clear-fix background\">\r\n  <aside class=\"middle-full\">\r\n    <section class=\"middle-main clearFix attendance-container\">\r\n\r\n      <section class=\"middle-top mb0 clearFix \">\r\n\r\n        <h2 style=\"padding: 5px;\" class=\"pull-left\">\r\n          <a routerLink=\"/view/leads\">\r\n            Lead\r\n\r\n          </a>\r\n          <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n          <a routerLink=\"/view/leads/enquiryReport\">\r\n             Reports\r\n\r\n          </a>\r\n          <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>Counsellor Report\r\n        </h2>\r\n      </section>\r\n\r\n      <section class=\"filter-form\">\r\n\r\n        <div class=\"row\">\r\n\r\n          <div class=\"c-lg-3 field-wrapper\">\r\n            <label>Counsellor</label>\r\n            <select class=\"form-ctrl\" [(ngModel)]=\"counsellorInfoDetails.assigned_to\">\r\n              <option value=\"-1\">\r\n              </option>\r\n              <option *ngFor=\"let i of getCounsellorData\" [value]=\"i.userid\">\r\n                {{i.name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"c-lg-3 field-wrapper datePickerBox\">\r\n            <label>Enquiry From Date</label>\r\n            <input type=\"text\" readonly=\"true\" class=\"form-ctrl\" bsDatepicker [(ngModel)]=\"counsellorInfoDetails.updateDateFrom\" >\r\n          </div>\r\n\r\n          <div class=\"c-lg-3 field-wrapper datePickerBox\">\r\n            <label>Enquiry To Date</label>\r\n            <input type=\"text\" readonly=\"true\" class=\"form-ctrl\" bsDatepicker [(ngModel)]=\"counsellorInfoDetails.updateDateTo\" >\r\n          </div>\r\n\r\n          <div class=\"c-lg-3 \" style=\"margin-top:2%;\">\r\n            <button class=\"btn fullBlue\" (click)=\"fetchAllCounsellorDataDetails()\">Go</button>\r\n          </div>\r\n        </div>\r\n\r\n        <div id=\"basic-search\" style=\"margin:5px; float:right;\">\r\n          <input #search type=\"text\" class=\"search-field searchName\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\"\r\n            (keyup)=\"searchDatabase()\" style=\"padding:7px 10px; width:200px; height:35px;\">\r\n        </div>\r\n\r\n        <rob-table [isMulti]=\"false\" [records]=\"getCounsellorDetails\" [dataStatus]=\"dataStatus\" (userRowSelect)=\"reportHandler($event)\"\r\n          [tableName]=\"'feereport'\" [settings]=\"feeSettings1\">\r\n        </rob-table>\r\n\r\n        <proctur-popup [sizeWidth]=\"'small'\" *ngIf=\"showPopup\">\r\n          <span class=\"closePopup pos-abs fbold show\" (click)=\"popupToggler()\" close-button>\r\n            <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n              <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n                <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n                  <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n                  <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n                </g>\r\n                <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n                />\r\n              </g>\r\n            </svg>\r\n          </span>\r\n\r\n          <h2 popup-header>Enquiries</h2>\r\n\r\n          <div popup-content class=\"main-student-table\">\r\n            <div class=\"table table-responsive\">\r\n              <table>\r\n                <thead>\r\n                  <tr>\r\n                    <th>\r\n                      Enquiry No\r\n                    </th>\r\n                    <th>\r\n                      Enquiry Date\r\n                    </th>\r\n                    <th>\r\n                      Name\r\n                    </th>\r\n                    <th>\r\n                      Mobile No.\r\n                    </th>\r\n                    <th>\r\n                      Last Updated\r\n                    </th>\r\n                  </tr>\r\n                </thead>\r\n                <tbody>\r\n                  <tr *ngFor=\"let i of popupDataEnquiries\">\r\n                    <td>\r\n                        {{i.enquiry_no}}\r\n                    </td>\r\n                    <td>\r\n                      {{i.enquiry_date}}\r\n                    </td>\r\n                    <td>\r\n                      {{i.name}}\r\n                    </td>\r\n                    <td>\r\n                      {{i.phone}}\r\n                    </td>\r\n                    <td>\r\n                      {{i.updateDate}}\r\n                    </td>\r\n                  </tr>\r\n                </tbody>\r\n              </table>\r\n            </div>\r\n          </div>\r\n        </proctur-popup>\r\n\r\n      </section>\r\n    </section>\r\n  </aside>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry-report/counsellor-report/counsellor-report.component.scss":
/***/ (function(module, exports) {

module.exports = ".attendance-container {\n  background: #efefef;\n  padding: 5px;\n  overflow: auto; }\n\n.skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 100%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n\n.skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n\n.filter-form {\n  background: #fff;\n  -webkit-box-shadow: 0px 0px 2px 2px #dadada;\n          box-shadow: 0px 0px 2px 2px #dadada;\n  border-radius: 10px;\n  overflow-x: hidden; }\n\n.filter-form .row {\n    margin: 5px 15px; }\n\n.filter-form .field-wrapper {\n    position: relative; }\n\n.filter-form .field-wrapper.datePickerBox .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent; }\n\n.filter-form .field-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 19px;\n      top: 31px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry-report/counsellor-report/counsellor-report.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CounsellorReportComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_login_services_login_service__ = __webpack_require__("./src/app/services/login-services/login.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_counsellor_service_service__ = __webpack_require__("./src/app/components/leads/services/counsellor-service.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var CounsellorReportComponent = /** @class */ (function () {
    function CounsellorReportComponent(counsellor, appc, auth, login) {
        this.counsellor = counsellor;
        this.appc = appc;
        this.auth = auth;
        this.login = login;
        this.counsellorInfo = {
            user_Type: 0
        };
        this.counsellorInfoDetails = {
            institution_id: this.counsellor.institute_id,
            reportType: "assigned",
            assigned_to: -1,
            updateDateFrom: __WEBPACK_IMPORTED_MODULE_2_moment__().startOf('month').format('YYYY-MM-DD'),
            updateDateTo: __WEBPACK_IMPORTED_MODULE_2_moment__().format('YYYY-MM-DD'),
        };
        this.getCounsellorDetails = {};
        this.getCounsellorData = [];
        this.mappedCounsellor = [];
        this.dataStatus = 0;
        this.searchText = "";
        this.feeSettings1 = [
            { primaryKey: 'source', header: 'Counsellor' },
            // { primaryKey: 'newEnqCount', header: 'New Enquiries' },
            { primaryKey: 'open', header: 'Open' },
            { primaryKey: 'inProgress', header: 'In Progress' },
            { primaryKey: 'Converted', header: 'Converted' },
            { primaryKey: 'studentAdmitted', header: 'Student Admitted' },
            { primaryKey: 'Closed', header: 'Closed' },
            { primaryKey: 'totalcount', header: 'Total Assigned' },
        ];
        this.showPopup = false;
        this.statusKeys = {
            // 'newEnqcount': '-1',
            'open': '0',
            'inProgress': '3',
            'Converted': '2',
            'studentAdmitted': '12',
            'Closed': '1',
            'totalcount': '-1'
        };
        this.newObject = {
            key: "",
            data: ""
        };
        this.newArray = [];
    }
    CounsellorReportComponent.prototype.ngOnInit = function () {
        this.fetchAllCounsellorData();
        this.fetchAllCounsellorDataDetails();
    };
    CounsellorReportComponent.prototype.fetchAllCounsellorData = function () {
        var _this = this;
        this.dataStatus = 1;
        this.counsellor.counsellorInformation(this.counsellorInfo).subscribe(function (data) {
            if (data.length) {
                _this.dataStatus = 2;
            }
            else {
                _this.dataStatus = 0;
            }
            _this.getCounsellorData = data;
        }, function (error) {
            _this.dataStatus = 2;
            var msg = {
                type: "error",
                body: error.error.message
            };
            _this.appc.popToast(msg);
        });
    };
    CounsellorReportComponent.prototype.fetchAllCounsellorDataDetails = function () {
        var _this = this;
        this.getCounsellorDetails = [];
        this.newArray = [];
        this.dataStatus = 1;
        if (this.counsellorInfoDetails.updateDateFrom > this.counsellorInfoDetails.updateDateTo) {
            this.appc.popToast({ type: "error", title: "", body: "From date cannot be greater than to date" });
            this.dataStatus = 2;
        }
        else {
            this.counsellorInfoDetails.updateDateFrom = __WEBPACK_IMPORTED_MODULE_2_moment__(this.counsellorInfoDetails.updateDateFrom).format('YYYY-MM-DD');
            this.counsellorInfoDetails.updateDateTo = __WEBPACK_IMPORTED_MODULE_2_moment__(this.counsellorInfoDetails.updateDateTo).format('YYYY-MM-DD');
            this.counsellor.counsellorDetails(this.counsellorInfoDetails).subscribe(function (data) {
                for (var prop in data) {
                    if (data.hasOwnProperty(prop)) {
                        var innerObj = {};
                        innerObj[prop] = data[prop];
                        _this.getCounsellorDetails.push(innerObj);
                    }
                }
                for (var _i = 0, _a = _this.getCounsellorDetails; _i < _a.length; _i++) {
                    var a = _a[_i];
                    for (var prop_1 in a) {
                        _this.newObject = {
                            key: prop_1,
                            data: a[prop_1]
                        };
                    }
                    _this.newArray.push(_this.newObject);
                }
                _this.getCounsellorDetails = _this.newArray;
                _this.getCounsellorDetails.map(function (ele) {
                    // ele.newEnqCount = ele.data.newEnqcount;
                    ele.totalcount = ele.data.totalcount;
                    ele.source_id = ele.key;
                    ele.source = ele.data.uniqueCatName;
                    ele.Closed = ele.data.statusMap.Closed;
                    ele.open = ele.data.statusMap.Open;
                    ele.inProgress = ele.data.statusMap["In Progress"];
                    ele.Converted = ele.data.statusMap.Converted;
                    ele.studentAdmitted = ele.data.statusMap["Student Admitted"];
                });
                if (_this.getCounsellorDetails.length == 0) {
                    _this.dataStatus = 2;
                }
                else {
                    _this.dataStatus = 0;
                }
                _this.searchMyRecords = _this.getCounsellorDetails;
            }, function (error) {
                _this.dataStatus = 2;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
    };
    CounsellorReportComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            // let searchData: any;
            this.getCounsellorDetails = this.getCounsellorDetails.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            // this.searchData = searchData;
            this.searchflag = true;
        }
        else {
            this.getCounsellorDetails = this.searchMyRecords;
            this.searchflag = false;
        }
    };
    CounsellorReportComponent.prototype.reportHandler = function (dataObj) {
        var _this = this;
        if (dataObj.data > 0) {
            if (dataObj.key == "newEnqCount") {
                var payload = {
                    assigned_to: dataObj.source,
                    institution_id: "",
                    isRport: "Y",
                    status: this.statusKeys[dataObj.key],
                    enquireDateFrom: this.counsellorInfoDetails.updateDateFrom,
                    enquireDateTo: this.counsellorInfoDetails.updateDateTo
                };
                this.popupDataEnquiries = [];
                this.counsellor.enquiryCategorySearch(payload).subscribe(function (data) {
                    _this.popupDataEnquiries = data;
                }, function (error) {
                });
            }
            else {
                var payload = {
                    assigned_to: dataObj.source,
                    institution_id: "",
                    isRport: "Y",
                    status: this.statusKeys[dataObj.key],
                    enquireDateFrom: __WEBPACK_IMPORTED_MODULE_2_moment__(this.counsellorInfoDetails.updateDateFrom).format('YYYY-MM-DD'),
                    enquireDateTo: __WEBPACK_IMPORTED_MODULE_2_moment__(this.counsellorInfoDetails.updateDateTo).format('YYYY-MM-DD')
                };
                this.popupDataEnquiries = [];
                this.counsellor.enquiryCategorySearch(payload).subscribe(function (data) {
                    _this.popupDataEnquiries = data;
                }, function (error) {
                });
            }
            this.showPopup = true;
        }
    };
    CounsellorReportComponent.prototype.popupToggler = function () {
        this.showPopup = false;
    };
    CounsellorReportComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-counsellor-report',
            template: __webpack_require__("./src/app/components/leads/enquiry-report/counsellor-report/counsellor-report.component.html"),
            styles: [__webpack_require__("./src/app/components/leads/enquiry-report/counsellor-report/counsellor-report.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_5__services_counsellor_service_service__["a" /* EnquiryReportService */],
            __WEBPACK_IMPORTED_MODULE_4__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_3__services_login_services_login_service__["a" /* LoginService */]])
    ], CounsellorReportComponent);
    return CounsellorReportComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry-report/enquiry-home/enquiry-home.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"middle-section clearFix\">\r\n    <aside class=\"middle-full\">\r\n        <h2 style=\"padding: 5px;\" class=\"pull-left\">\r\n            <a routerLink=\"/view/leads\">\r\n              Lead\r\n  \r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n             Reports\r\n            </h2>\r\n        <div class=\"leads-menu-section-container\">\r\n            <div class=\"leads-menu-item\" routerLink=\"./counsellor\">\r\n              <div class=\"menu-title\">\r\n                <img src=\"./assets/images/leads/counselor_report.svg\" alt=\"data setup\">\r\n                <span>Counsellor</span>\r\n              </div>\r\n              <div class=\"menu-description\">\r\n                <span>This Report depicts the counsellor reports by date range</span>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"leads-menu-item\" routerLink=\"./source\">\r\n              <div class=\"menu-title\">\r\n                <img src=\"./assets/images/leads/source_wise_report.svg\" alt=\"data setup\">\r\n                <span>Source</span>\r\n              </div>\r\n              <div class=\"menu-description\">\r\n                <span> This Report depicts the source reports by date range</span>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"leads-menu-item\" routerLink=\"./referredBy\">\r\n              <div class=\"menu-title\">\r\n                <img src=\"./assets/images/leads/referred_by_reports.svg\" alt=\"data setup\">\r\n                <span> Referred By</span>\r\n              </div>\r\n              <div class=\"menu-description\">\r\n                <span> This Report depicts the referred by reports by date range\r\n                  </span>\r\n              </div>\r\n            </div>\r\n            </div>\r\n    </aside>\r\n  </div>"

/***/ }),

/***/ "./src/app/components/leads/enquiry-report/enquiry-home/enquiry-home.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/** these css for gear icon download options\r\n* created by laxmi\r\n*/\nsvg:hover #gearIcon {\n  fill: #0084f6; }\n.asHover:hover {\n  color: #0084f6 !important; }\n.download:hover {\n  cursor: pointer; }\n.made-in {\n  font-size: 17px;\n  font-weight: bold;\n  text-align: left; }\n.dropdown > ul {\n  background: #fff;\n  padding: 10px 20px;\n  border: 1px solid #eaeaeb;\n  border-top: 0;\n  margin-top: 3px;\n  -webkit-box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 6px 10px 0 rgba(0, 0, 0, 0.12);\n          box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0 4px 5px 0 rgba(0, 0, 0, 0.14), 0 6px 10px 0 rgba(0, 0, 0, 0.12); }\n.dropdown > ul li {\n    color: #333; }\n.dropdown > ul li strong {\n      font-weight: 600;\n      display: block; }\n.dropdown > ul li a {\n      display: block;\n      color: #333; }\n.login-tube nav > ul > li {\n  display: inline-block;\n  position: relative; }\n.login-tube nav > ul > li > a {\n  color: #333;\n  text-decoration: none;\n  padding: 5px 10px;\n  display: block;\n  -webkit-transition: all .4s;\n  transition: all .4s; }\n.login-tube nav > ul > li > a:hover,\n.login-tube nav > ul > li:hover > a {\n  text-decoration: none;\n  background: #ccc; }\n.login-tube nav > ul > li .dropdown {\n  position: absolute;\n  visibility: hidden;\n  right: 0;\n  top: 100%;\n  min-width: 200px;\n  border-top: 0;\n  opacity: 0;\n  -webkit-transition: all 0.1s cubic-bezier(0.55, 0, 0.55, 0.2);\n  transition: all 0.1s cubic-bezier(0.55, 0, 0.55, 0.2);\n  -webkit-transition-duration: .25s;\n  transition-duration: .2s;\n  -webkit-transform: scale(0.5);\n          transform: scale(0.5); }\n.login-tube nav > ul > li .dropdown > ul li {\n    line-height: normal; }\n.login-tube nav > ul > li .dropdown > ul li a {\n      display: block;\n      margin: 5px 0; }\n.login-tube nav > ul > li .dropdown > ul li a:hover {\n        color: #0084f6; }\n.login-tube nav > ul > li .dropdown > ul ul {\n    padding-left: 15px;\n    padding-top: 10px; }\n.login-tube nav > ul > li .dropdown > ul ul ul {\n      padding-top: 0; }\n.login-tube nav > ul > li:hover .dropdown {\n  visibility: visible;\n  position: absolute;\n  opacity: 1;\n  right: 0;\n  top: 100%;\n  -webkit-transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);\n  transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);\n  -webkit-transition-duration: .5s;\n  transition-duration: .5s;\n  -webkit-transform: scale(1);\n          transform: scale(1); }\n.span-button {\n  border: 1px solid #0084f6;\n  padding: 4px 8px;\n  color: #0084f6;\n  font-size: .9em;\n  border-radius: 2px;\n  font-weight: 600;\n  cursor: pointer; }\n.span-button svg {\n    margin: -3px 0;\n    height: 14px; }\nlogin-nav > li {\n  display: inline-block;\n  padding: 0 7px;\n  cursor: pointer;\n  vertical-align: text-bottom; }\nlogin-nav > li .dropdown {\n    position: absolute;\n    right: 0;\n    top: 100%;\n    padding-top: 10px; }\nlogin-nav > li .icons {\n    width: 35px;\n    height: 35px;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    border-radius: 50%;\n    padding-top: 3px;\n    -webkit-transition: all 0.1s;\n    transition: all 0.1s;\n    border: 1px solid transparent; }\nlogin-nav > li .icons svg {\n      width: 25px;\n      color: #034979; }\nlogin-nav > li .icons svg .cls-1 {\n        stroke: #034979;\n        stroke-linejoin: unset;\n        border: none; }\nlogin-nav > li .user-info {\n    white-space: nowrap;\n    margin-right: 40px;\n    width: auto;\n    display: block;\n    position: relative; }\nlogin-nav > li .user-info > .icons {\n      display: inline-block;\n      vertical-align: middle; }\nlogin-nav > li .user-info > span {\n      vertical-align: middle;\n      display: inline-block; }\nlogin-nav > li .user-info:after {\n      display: inline-block;\n      font: normal normal normal 14px/1 FontAwesome;\n      font-size: inherit;\n      text-rendering: auto;\n      -webkit-font-smoothing: antialiased;\n      content: \"\\f107\";\n      font-size: 17px;\n      position: absolute;\n      right: -20px;\n      top: 10px; }\n/**\r\n  this css is for report section css for cards\r\n  added by laxmi\r\n*/\n.report-box {\n  width: 100%;\n  height: 100%;\n  padding: 10px; }\n.report-box ul.card-box li.card-row {\n    margin: 10px 0px; }\n.report-box ul.card {\n    padding: 15px 10px;\n    border: 1px solid #efefef;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 10px 0px;\n    -webkit-box-shadow: 0px 0px 2px 0px;\n            box-shadow: 0px 0px 2px 0px; }\n.report-box ul.card li {\n      padding: 5px; }\n.report-box ul.card li:first-child {\n        font-size: 14px;\n        font-weight: 600;\n        padding: 10px 5px; }\n.report-box ul.card li:nth-child(2n) {\n        font-size: 12px; }\n.disabled {\n  cursor: not-allowed;\n  background: lightgrey; }\n.middle-section {\n  padding: 1%; }\n.leads-menu-section-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  padding-top: 20px;\n  margin-top: 20px;\n  border-top: 1px solid rgba(10, 10, 10, 0.5);\n  width: 100%; }\n.leads-menu-section-container .leads-menu-item {\n    padding: 15px 10px;\n    width: 31%;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 1%;\n    -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24);\n    box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24); }\n.leads-menu-section-container .leads-menu-item .menu-title {\n      width: 100%;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start;\n      font-size: 14px;\n      font-weight: 600;\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row; }\n.leads-menu-section-container .leads-menu-item .menu-title img {\n        width: 25px;\n        height: 25px; }\n.leads-menu-section-container .leads-menu-item .menu-title span {\n        margin-left: 10px;\n        margin-top: 5px; }\n.leads-menu-section-container .leads-menu-item .menu-description {\n      padding: 10px;\n      font-size: 12px; }\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry-report/enquiry-home/enquiry-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EnquiryHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var EnquiryHomeComponent = /** @class */ (function () {
    function EnquiryHomeComponent() {
    }
    EnquiryHomeComponent.prototype.ngOnInit = function () {
    };
    EnquiryHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-enquiry-home',
            template: __webpack_require__("./src/app/components/leads/enquiry-report/enquiry-home/enquiry-home.component.html"),
            styles: [__webpack_require__("./src/app/components/leads/enquiry-report/enquiry-home/enquiry-home.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], EnquiryHomeComponent);
    return EnquiryHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry-report/enquiry-report-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EnquiryReportRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__counsellor_report_counsellor_report_component__ = __webpack_require__("./src/app/components/leads/enquiry-report/counsellor-report/counsellor-report.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__source_source_component__ = __webpack_require__("./src/app/components/leads/enquiry-report/source/source.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__referred_by_referred_by_component__ = __webpack_require__("./src/app/components/leads/enquiry-report/referred-by/referred-by.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__enquiry_report_component__ = __webpack_require__("./src/app/components/leads/enquiry-report/enquiry-report.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__enquiry_home_enquiry_home_component__ = __webpack_require__("./src/app/components/leads/enquiry-report/enquiry-home/enquiry-home.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// import { ReportComponent } from "../report.component";


// import { ReportHomeComponent } from "../report-home/report-home.component";





var EnquiryReportRoutingModule = /** @class */ (function () {
    function EnquiryReportRoutingModule() {
    }
    EnquiryReportRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_1__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_0__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_5__enquiry_report_component__["a" /* EnquiryReportComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                component: __WEBPACK_IMPORTED_MODULE_6__enquiry_home_enquiry_home_component__["a" /* EnquiryHomeComponent */]
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_6__enquiry_home_enquiry_home_component__["a" /* EnquiryHomeComponent */]
                            },
                            {
                                path: 'counsellor',
                                component: __WEBPACK_IMPORTED_MODULE_2__counsellor_report_counsellor_report_component__["a" /* CounsellorReportComponent */]
                            },
                            {
                                path: 'source',
                                component: __WEBPACK_IMPORTED_MODULE_3__source_source_component__["a" /* SourceComponent */]
                            },
                            {
                                path: 'referredBy',
                                component: __WEBPACK_IMPORTED_MODULE_4__referred_by_referred_by_component__["a" /* ReferredByComponent */]
                            }
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_0__angular_router__["RouterModule"]
            ]
        })
    ], EnquiryReportRoutingModule);
    return EnquiryReportRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry-report/enquiry-report.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>"

/***/ }),

/***/ "./src/app/components/leads/enquiry-report/enquiry-report.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/leads/enquiry-report/enquiry-report.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EnquiryReportComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var EnquiryReportComponent = /** @class */ (function () {
    function EnquiryReportComponent() {
    }
    EnquiryReportComponent.prototype.ngOnInit = function () {
    };
    EnquiryReportComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-enquiry-report',
            template: __webpack_require__("./src/app/components/leads/enquiry-report/enquiry-report.component.html"),
            styles: [__webpack_require__("./src/app/components/leads/enquiry-report/enquiry-report.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], EnquiryReportComponent);
    return EnquiryReportComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry-report/enquiry-report.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EnquiryReportModule", function() { return EnquiryReportModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__referred_by_referred_by_component__ = __webpack_require__("./src/app/components/leads/enquiry-report/referred-by/referred-by.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__source_source_component__ = __webpack_require__("./src/app/components/leads/enquiry-report/source/source.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__counsellor_report_counsellor_report_component__ = __webpack_require__("./src/app/components/leads/enquiry-report/counsellor-report/counsellor-report.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__enquiry_home_enquiry_home_component__ = __webpack_require__("./src/app/components/leads/enquiry-report/enquiry-home/enquiry-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__enquiry_report_routing_module__ = __webpack_require__("./src/app/components/leads/enquiry-report/enquiry-report-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__enquiry_report_component__ = __webpack_require__("./src/app/components/leads/enquiry-report/enquiry-report.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__services_counsellor_service_service__ = __webpack_require__("./src/app/components/leads/services/counsellor-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11_ngx_bootstrap_custome__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/index.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












var EnquiryReportModule = /** @class */ (function () {
    function EnquiryReportModule() {
    }
    EnquiryReportModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_1__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_0__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_0__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_2__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_7__enquiry_report_routing_module__["a" /* EnquiryReportRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_10__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_11_ngx_bootstrap_custome__["a" /* BsDatepickerModule */],
            ],
            exports: [],
            entryComponents: [
                __WEBPACK_IMPORTED_MODULE_6__enquiry_home_enquiry_home_component__["a" /* EnquiryHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_3__referred_by_referred_by_component__["a" /* ReferredByComponent */],
                __WEBPACK_IMPORTED_MODULE_4__source_source_component__["a" /* SourceComponent */],
                __WEBPACK_IMPORTED_MODULE_5__counsellor_report_counsellor_report_component__["a" /* CounsellorReportComponent */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_3__referred_by_referred_by_component__["a" /* ReferredByComponent */],
                __WEBPACK_IMPORTED_MODULE_4__source_source_component__["a" /* SourceComponent */],
                __WEBPACK_IMPORTED_MODULE_5__counsellor_report_counsellor_report_component__["a" /* CounsellorReportComponent */],
                __WEBPACK_IMPORTED_MODULE_6__enquiry_home_enquiry_home_component__["a" /* EnquiryHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_8__enquiry_report_component__["a" /* EnquiryReportComponent */],
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_9__services_counsellor_service_service__["a" /* EnquiryReportService */]
            ]
        })
    ], EnquiryReportModule);
    return EnquiryReportModule;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry-report/referred-by/referred-by.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"clear-fix background\">\r\n  <aside class=\"middle-full\">\r\n    <section class=\"middle-main clearFix attendance-container\">\r\n\r\n      <section class=\"middle-top mb0 clearFix \">\r\n        <h2 style=\"padding: 5px;\" class=\"pull-left\">\r\n          <a routerLink=\"/view/leads\">\r\n            Lead\r\n\r\n          </a>\r\n          <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n          <a routerLink=\"/view/leads/enquiryReport\">\r\n             Reports\r\n\r\n          </a>\r\n          <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>Referred By Report\r\n        </h2>\r\n      </section>\r\n\r\n      <section class=\"filter-form\">\r\n\r\n        <div class=\"row\">\r\n          <div class=\"c-lg-3 field-wrapper\">\r\n            <label>Referred By</label>\r\n            <select class=\"form-ctrl\" [(ngModel)]=\"referredByInfoDetails.referred_by\">\r\n              <option value=\"-1\">\r\n              </option>\r\n              <option *ngFor=\"let i of getreferredByData\" [value]=\"i.id\">\r\n                {{i.name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"c-lg-3 field-wrapper datePickerBox\">\r\n            <label>From Date</label>\r\n            <input type=\"text\" readonly=\"true\" class=\"form-ctrl\" bsDatepicker [(ngModel)]=\"referredByInfoDetails.updateDateFrom\">\r\n          </div>\r\n\r\n          <div class=\"c-lg-3 field-wrapper datePickerBox\">\r\n            <label>To Date</label>\r\n            <input type=\"text\" readonly=\"true\" class=\"form-ctrl\" bsDatepicker [(ngModel)]=\"referredByInfoDetails.updateDateTo\">\r\n          </div>\r\n\r\n          <div class=\"c-lg-3 \" style=\"margin-top:2%;\">\r\n            <button class=\"btn fullBlue\" (click)=\"referredByDetails()\">Go</button>\r\n          </div>\r\n        </div>\r\n\r\n        <div id=\"basic-search\" style=\"margin:5px; float:right;\">\r\n          <input #search type=\"text\" class=\"search-field searchName\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\"\r\n            (keyup)=\"searchDatabase()\" style=\"padding:7px 10px; width:200px; height:35px;\">\r\n        </div>\r\n\r\n        <rob-table [isMulti]=\"false\" [records]=\"getreferredByDetails\" [dataStatus]=\"dataStatus\" (userRowSelect)=\"reportHandler($event)\"\r\n          [tableName]=\"'feereport'\" [settings]=\"feeSettings1\">\r\n        </rob-table>\r\n\r\n        <proctur-popup [sizeWidth]=\"'small'\" *ngIf=\"showPopup\">\r\n          <span class=\"closePopup pos-abs fbold show\" (click)=\"popupToggler()\" close-button>\r\n            <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n              <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n                <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n                  <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n                  <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n                </g>\r\n                <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n                />\r\n              </g>\r\n            </svg>\r\n          </span>\r\n\r\n          <h2 popup-header>Enquiries</h2>\r\n\r\n          <div popup-content class=\"main-student-table\">\r\n            <div class=\"table table-responsive\">\r\n              <table>\r\n                <thead>\r\n                  <tr>\r\n                    <th>\r\n                      Enquiry No\r\n                    </th>\r\n                    <th>\r\n                      Enquiry Date\r\n                    </th>\r\n                    <th>\r\n                      Name\r\n                    </th>\r\n                    <th>\r\n                      Mobile No.\r\n                    </th>\r\n                    <th>\r\n                      Last Updated\r\n                    </th>\r\n                  </tr>\r\n                </thead>\r\n                <tbody>\r\n                  <tr *ngFor=\"let i of popupDataEnquiries\">\r\n                    <td>\r\n                      {{i.enquiry_no}}\r\n                    </td>\r\n                    <td>\r\n                      {{i.enquiry_date}}\r\n                    </td>\r\n                    <td>\r\n                      {{i.name}}\r\n                    </td>\r\n                    <td>\r\n                      {{i.phone}}\r\n                    </td>\r\n                    <td>\r\n                      {{i.updateDate}}\r\n                    </td>\r\n                  </tr>\r\n                </tbody>\r\n              </table>\r\n            </div>\r\n          </div>\r\n\r\n        </proctur-popup>\r\n      </section>\r\n    </section>\r\n  </aside>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry-report/referred-by/referred-by.component.scss":
/***/ (function(module, exports) {

module.exports = ".attendance-container {\n  background: #efefef;\n  padding: 5px;\n  overflow: auto; }\n\n.filter-form {\n  background: #fff;\n  -webkit-box-shadow: 0px 0px 2px 2px #dadada;\n          box-shadow: 0px 0px 2px 2px #dadada;\n  border-radius: 10px;\n  overflow-x: hidden; }\n\n.filter-form .row {\n    margin: 5px 15px; }\n\n.filter-form .field-wrapper {\n    position: relative; }\n\n.filter-form .field-wrapper.datePickerBox .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent; }\n\n.filter-form .field-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 19px;\n      top: 31px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry-report/referred-by/referred-by.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReferredByComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_counsellor_service_service__ = __webpack_require__("./src/app/components/leads/services/counsellor-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ReferredByComponent = /** @class */ (function () {
    function ReferredByComponent(service, appc) {
        this.service = service;
        this.appc = appc;
        this.referredByInfoDetails = {
            institution_id: this.service.institute_id,
            reportType: "Referred",
            referred_by: -1,
            updateDateFrom: __WEBPACK_IMPORTED_MODULE_3_moment__().startOf('month').format('YYYY-MM-DD'),
            updateDateTo: __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD')
        };
        this.getreferredByData = [];
        this.getreferredByDetails = {};
        this.mappedreferredBy = [];
        this.searchMyRecords = [];
        this.searchText = "";
        this.feeSettings1 = [
            { primaryKey: 'source', header: 'Referred By' },
            { primaryKey: 'newEnqCount', header: 'New Enquiries' },
            { primaryKey: 'open', header: 'Open' },
            { primaryKey: 'inProgress', header: 'In Progress' },
            { primaryKey: 'Converted', header: 'Converted' },
            { primaryKey: 'studentAdmitted', header: 'Student Admitted' },
            { primaryKey: 'Closed', header: 'Closed' },
            { primaryKey: 'totalcount', header: 'Total Assigned' },
        ];
        this.showPopup = false;
        this.newObject = {
            key: "",
            data: ""
        };
        this.newArray = [];
        this.statusKeys = {
            'status': '-1',
            'open': '0',
            'inProgress': '3',
            'Converted': '2',
            'studentAdmitted': '12',
            'Closed': '1',
            'totalcount': '-1'
        };
        this.popupDataEnquiries = [];
    }
    ReferredByComponent.prototype.ngOnInit = function () {
        this.referredByData();
        this.referredByDetails();
    };
    ReferredByComponent.prototype.referredByData = function () {
        var _this = this;
        this.dataStatus = 1;
        this.service.referredByDetails().subscribe(function (data) {
            if (data.length == 0) {
                _this.dataStatus = 2;
            }
            else {
                if (data.length == 0) {
                    _this.dataStatus = 2;
                }
                else {
                    _this.dataStatus = 0;
                }
                _this.getreferredByData = data;
            }
        }, function (error) {
            var msg = {
                type: "error",
                body: error.error.message
            };
            _this.appc.popToast(msg);
        });
    };
    ReferredByComponent.prototype.referredByDetails = function () {
        var _this = this;
        this.getreferredByDetails = [];
        this.newArray = [];
        this.dataStatus = 1;
        if (this.referredByInfoDetails.updateDateFrom > this.referredByInfoDetails.updateDateTo) {
            this.appc.popToast({ type: "error", title: "", body: "From date cannot be greater than to date" });
            this.dataStatus = 2;
        }
        else {
            this.service.counsellorDetails(this.referredByInfoDetails).subscribe(function (data) {
                for (var prop in data) {
                    if (data.hasOwnProperty(prop)) {
                        var innerObj = {};
                        innerObj[prop] = data[prop];
                        _this.getreferredByDetails.push(innerObj);
                    }
                }
                for (var _i = 0, _a = _this.getreferredByDetails; _i < _a.length; _i++) {
                    var a = _a[_i];
                    for (var prop_1 in a) {
                        _this.newObject = {
                            key: prop_1,
                            data: a[prop_1]
                        };
                    }
                    _this.newArray.push(_this.newObject);
                }
                _this.getreferredByDetails = _this.newArray;
                _this.getreferredByDetails.map(function (ele) {
                    ele.newEnqCount = ele.data.newEnqcount;
                    ele.totalcount = ele.data.totalcount;
                    ele.source_id = ele.key;
                    ele.source = ele.data.uniqueCatName;
                    ele.Closed = ele.data.statusMap.Closed;
                    ele.open = ele.data.statusMap.Open;
                    ele.inProgress = ele.data.statusMap["In Progress"];
                    ele.Converted = ele.data.statusMap.Converted;
                    ele.studentAdmitted = ele.data.statusMap["Student Admitted"];
                });
                if (_this.getreferredByDetails.length == 0) {
                    _this.dataStatus = 2;
                }
                else {
                    _this.dataStatus = 0;
                }
                _this.searchMyRecords = _this.getreferredByDetails;
            }, function (error) {
                _this.dataStatus = 2;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
    };
    ReferredByComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            // let searchData: any;
            this.getreferredByDetails = this.getreferredByDetails.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            // this.searchData = searchData;
            this.searchflag = true;
        }
        else {
            this.getreferredByDetails = this.searchMyRecords;
            this.searchflag = false;
        }
    };
    ReferredByComponent.prototype.reportHandler = function (dataObj) {
        var _this = this;
        console.log(dataObj);
        if (dataObj.data > 0) {
            if (dataObj.key == "newEnqcount") {
                var payload = {
                    referred_by: dataObj.source,
                    institution_id: this.service.institute_id,
                    isRport: "Y",
                    status: this.statusKeys[dataObj.key],
                    enquireDateFrom: this.referredByInfoDetails.updateDateFrom,
                    enquireDateTo: this.referredByInfoDetails.updateDateTo
                };
                this.popupDataEnquiries = [];
                this.service.enquiryCategorySearch(payload).subscribe(function (data) {
                    _this.popupDataEnquiries = data;
                }, function (error) {
                });
            }
            else {
                var payload = {
                    referred_by: dataObj.source,
                    institution_id: this.service.institute_id,
                    isRport: "Y",
                    status: this.statusKeys[dataObj.key],
                    updateDateFrom: this.referredByInfoDetails.updateDateFrom,
                    updateDateTo: this.referredByInfoDetails.updateDateTo
                };
                this.popupDataEnquiries = [];
                this.service.enquiryCategorySearch(payload).subscribe(function (data) {
                    _this.popupDataEnquiries = data;
                }, function (error) {
                });
            }
            this.showPopup = true;
        }
    };
    ReferredByComponent.prototype.popupToggler = function () {
        this.showPopup = false;
    };
    ReferredByComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-referred-by',
            template: __webpack_require__("./src/app/components/leads/enquiry-report/referred-by/referred-by.component.html"),
            styles: [__webpack_require__("./src/app/components/leads/enquiry-report/referred-by/referred-by.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_counsellor_service_service__["a" /* EnquiryReportService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */]])
    ], ReferredByComponent);
    return ReferredByComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/enquiry-report/source/source.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"clear-fix background\">\r\n  <aside class=\"middle-full\">\r\n    <section class=\"middle-main clearFix attendance-container\">\r\n\r\n      <section class=\"middle-top mb0 clearFix \">\r\n        <h2 style=\"padding: 5px;\" class=\"pull-left\">\r\n          <a routerLink=\"/view/leads\">\r\n            Lead\r\n\r\n          </a>\r\n          <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n          <a routerLink=\"/view/leads/enquiryReport\">\r\n            Reports\r\n\r\n          </a>\r\n          <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>Source Report\r\n        </h2>\r\n      </section>\r\n\r\n      <section class=\"filter-form\">\r\n\r\n        <div class=\"row\">\r\n\r\n          <div class=\"c-lg-3 field-wrapper\">\r\n            <label>Source By</label>\r\n            <select class=\"form-ctrl\" [(ngModel)]=\"sourceInfoDetails.source_id\">\r\n              <option value=\"-1\">\r\n              </option>\r\n              <option *ngFor=\"let i of getSourceData\" [value]=\"i.id\">\r\n                {{i.name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"c-lg-3 field-wrapper datePickerBox\">\r\n            <label>From Date</label>\r\n            <input type=\"text\" readonly=\"true\" class=\"form-ctrl\" bsDatepicker [(ngModel)]=\"sourceInfoDetails.updateDateFrom\">\r\n          </div>\r\n\r\n          <div class=\"c-lg-3 field-wrapper datePickerBox\">\r\n            <label>To Date</label>\r\n            <input type=\"text\" readonly=\"true\" class=\"form-ctrl\" bsDatepicker [(ngModel)]=\"sourceInfoDetails.updateDateTo\">\r\n          </div>\r\n          <div class=\"c-lg-3 \" style=\"margin-top:2%;\">\r\n            <button class=\"btn fullBlue\" (click)=\"sourceDataDetails()\">Go</button>\r\n          </div>\r\n        </div>\r\n\r\n        <div id=\"basic-search\" style=\"margin:5px; float:right;\">\r\n          <input #search type=\"text\" class=\"search-field searchName\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\"\r\n            (keyup)=\"searchDatabase()\" style=\"padding:7px 10px; width:200px; height:35px;\">\r\n        </div>\r\n        <rob-table [isMulti]=\"false\" [records]=\"getSourceDetails\" [dataStatus]=\"dataStatus\" (userRowSelect)=\"reportHandler($event)\"\r\n          [tableName]=\"'feereport'\" [settings]=\"feeSettings1\">\r\n        </rob-table>\r\n\r\n        <proctur-popup [sizeWidth]=\"'small'\" *ngIf=\"showPopup\">\r\n          <span class=\"closePopup pos-abs fbold show\" (click)=\"popupToggler()\" close-button>\r\n            <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n              <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n                <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n                  <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n                  <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n                </g>\r\n                <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n                />\r\n              </g>\r\n            </svg>\r\n          </span>\r\n\r\n          <h2 popup-header>Enquiries</h2>\r\n\r\n          <div popup-content class=\"main-student-table\">\r\n            <div class=\"table table-responsive\">\r\n              <table>\r\n                <thead>\r\n                  <tr>\r\n                    <th>\r\n                      Enquiry No\r\n                    </th>\r\n                    <th>\r\n                      Enquiry Date\r\n                    </th>\r\n                    <th>\r\n                      Name\r\n                    </th>\r\n                    <th>\r\n                      Mobile No.\r\n                    </th>\r\n                    <th>\r\n                      Last Updated\r\n                    </th>\r\n                  </tr>\r\n                </thead>\r\n                <tbody>\r\n                  <tr *ngFor=\"let i of popupDataEnquiries\">\r\n                    <td>\r\n                      {{i.enquiry_no}}\r\n                    </td>\r\n                    <td>\r\n                      {{i.enquiry_date}}\r\n                    </td>\r\n                    <td>\r\n                      {{i.name}}\r\n                    </td>\r\n                    <td>\r\n                      {{i.phone}}\r\n                    </td>\r\n                    <td>\r\n                      {{i.updateDate}}\r\n                    </td>\r\n                  </tr>\r\n                </tbody>\r\n              </table>\r\n            </div>\r\n          </div>\r\n\r\n        </proctur-popup>\r\n      </section>\r\n    </section>\r\n  </aside>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry-report/source/source.component.scss":
/***/ (function(module, exports) {

module.exports = ".attendance-container {\n  background: #efefef;\n  padding: 5px;\n  overflow: auto; }\n\n.filter-form {\n  background: #fff;\n  -webkit-box-shadow: 0px 0px 2px 2px #dadada;\n          box-shadow: 0px 0px 2px 2px #dadada;\n  border-radius: 10px;\n  overflow-x: hidden; }\n\n.filter-form .row {\n    margin: 5px 15px; }\n\n.filter-form .field-wrapper {\n    position: relative; }\n\n.filter-form .field-wrapper.datePickerBox .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent; }\n\n.filter-form .field-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 19px;\n      top: 31px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n"

/***/ }),

/***/ "./src/app/components/leads/enquiry-report/source/source.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SourceComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_counsellor_service_service__ = __webpack_require__("./src/app/components/leads/services/counsellor-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var SourceComponent = /** @class */ (function () {
    function SourceComponent(service, appc) {
        this.service = service;
        this.appc = appc;
        this.sourceInfoDetails = {
            institution_id: this.service.institute_id,
            reportType: "source",
            source_id: -1,
            updateDateFrom: __WEBPACK_IMPORTED_MODULE_3_moment__().startOf('month').format('YYYY-MM-DD'),
            updateDateTo: __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD')
        };
        this.getSourceData = [];
        this.getSourceDetails = {};
        this.mappedSource = [];
        this.searchMyRecords = [];
        this.searchText = "";
        this.feeSettings1 = [
            { primaryKey: 'source', header: 'Source' },
            { primaryKey: 'newEnqCount', header: 'New Enquiries' },
            { primaryKey: 'open', header: 'Open' },
            { primaryKey: 'inProgress', header: 'In Progress' },
            { primaryKey: 'Converted', header: 'Converted' },
            { primaryKey: 'studentAdmitted', header: 'Student Admitted' },
            { primaryKey: 'Closed', header: 'Closed' },
            { primaryKey: 'totalcount', header: 'Total Assigned' },
        ];
        this.statusKeys = {
            'newEnqcount': '-1',
            'open': '0',
            'inProgress': '3',
            'Converted': '2',
            'studentAdmitted': '12',
            'Closed': '1',
            'totalcount': '-1'
        };
        this.showPopup = false;
        this.newObject = {
            key: "",
            data: ""
        };
        this.newArray = [];
    }
    SourceComponent.prototype.ngOnInit = function () {
        this.sourceData();
        this.sourceDataDetails();
    };
    SourceComponent.prototype.sourceData = function () {
        var _this = this;
        this.dataStatus = 1;
        this.service.sourceData().subscribe(function (data) {
            if (data.length == 0) {
                _this.dataStatus = 2;
            }
            else {
                _this.dataStatus = 0;
            }
            _this.getSourceData = data;
        }, function (error) {
            var msg = {
                type: "error",
                body: error.error.message
            };
            _this.appc.popToast(msg);
        });
    };
    SourceComponent.prototype.sourceDataDetails = function () {
        var _this = this;
        this.getSourceDetails = [];
        this.newArray = [];
        this.dataStatus = 1;
        if (this.sourceInfoDetails.updateDateFrom > this.sourceInfoDetails.updateDateTo) {
            this.appc.popToast({ type: "error", title: "", body: "From date cannot be greater than to date" });
            this.dataStatus = 2;
        }
        else {
            this.service.counsellorDetails(this.sourceInfoDetails).subscribe(function (data) {
                for (var prop in data) {
                    if (data.hasOwnProperty(prop)) {
                        var innerObj = {};
                        innerObj[prop] = data[prop];
                        _this.getSourceDetails.push(innerObj);
                    }
                }
                for (var _i = 0, _a = _this.getSourceDetails; _i < _a.length; _i++) {
                    var a = _a[_i];
                    for (var prop_1 in a) {
                        _this.newObject = {
                            key: prop_1,
                            data: a[prop_1]
                        };
                    }
                    _this.newArray.push(_this.newObject);
                }
                _this.getSourceDetails = _this.newArray;
                _this.getSourceDetails.map(function (ele) {
                    ele.newEnqCount = ele.data.newEnqcount;
                    ele.totalcount = ele.data.totalcount;
                    ele.source_id = ele.key;
                    ele.source = ele.data.uniqueCatName;
                    ele.Closed = ele.data.statusMap.Closed;
                    ele.open = ele.data.statusMap.Open;
                    ele.inProgress = ele.data.statusMap["In Progress"];
                    ele.Converted = ele.data.statusMap.Converted;
                    ele.studentAdmitted = ele.data.statusMap["Student Admitted"];
                });
                if (_this.getSourceDetails.length == 0) {
                    _this.dataStatus = 2;
                }
                else {
                    _this.dataStatus = 0;
                }
                _this.searchMyRecords = _this.getSourceDetails;
            }, function (error) {
                _this.dataStatus = 2;
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appc.popToast(msg);
            });
        }
    };
    SourceComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            // let searchData: any;
            this.getSourceDetails = this.getSourceDetails.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            // this.searchData = searchData;
            this.searchflag = true;
        }
        else {
            this.getSourceDetails = this.searchMyRecords;
            this.searchflag = false;
        }
    };
    SourceComponent.prototype.reportHandler = function (dataObj) {
        var _this = this;
        console.log(dataObj);
        if (dataObj.key == "newEnqCount") {
            var payload = {
                source_id: dataObj.source,
                institution_id: this.service.institute_id,
                isRport: "Y",
                status: this.statusKeys[dataObj.key],
                enquireDateFrom: this.sourceInfoDetails.updateDateFrom,
                enquireDateTo: this.sourceInfoDetails.updateDateTo
            };
            console.log(payload);
            this.popupDataEnquiries = [];
            this.service.enquiryCategorySearch(payload).subscribe(function (data) {
                _this.popupDataEnquiries = data;
            }, function (error) {
            });
        }
        else {
            var payload = {
                source_id: dataObj.source,
                institution_id: this.service.institute_id,
                isRport: "Y",
                status: this.statusKeys[dataObj.key],
                updateDateFrom: this.sourceInfoDetails.updateDateFrom,
                updateDateTo: this.sourceInfoDetails.updateDateTo
            };
            this.popupDataEnquiries = [];
            this.service.enquiryCategorySearch(payload).subscribe(function (data) {
                _this.popupDataEnquiries = data;
            }, function (error) {
            });
            console.log(payload);
        }
        this.showPopup = true;
    };
    SourceComponent.prototype.popupToggler = function () {
        this.showPopup = false;
    };
    SourceComponent.prototype.userRowClicked = function ($event, ev, row, key) {
        console.log(row);
    };
    SourceComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-source',
            template: __webpack_require__("./src/app/components/leads/enquiry-report/source/source.component.html"),
            styles: [__webpack_require__("./src/app/components/leads/enquiry-report/source/source.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_counsellor_service_service__["a" /* EnquiryReportService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */]])
    ], SourceComponent);
    return SourceComponent;
}());



/***/ }),

/***/ "./src/app/components/leads/services/counsellor-service.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EnquiryReportService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var EnquiryReportService = /** @class */ (function () {
    function EnquiryReportService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        // this.institute_id = this.auth.getInstituteId();
        // this.Authorization = this.auth.getAuthToken();
        this.baseUrl = this.auth.getBaseUrl();
    }
    EnquiryReportService.prototype.counsellorInformation = function (obj) {
        var url = this.baseUrl + "/api/v1/profiles/" + this.institute_id;
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    EnquiryReportService.prototype.counsellorDetails = function (obj) {
        var url = this.baseUrl + "/api/v1/enquiry/report/" + this.institute_id;
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    EnquiryReportService.prototype.sourceData = function () {
        var url = this.baseUrl + "/api/v1/enquiry_campaign/master/lead_source/" + this.institute_id + "/all";
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    EnquiryReportService.prototype.referredByDetails = function () {
        var url = this.baseUrl + "/api/v1/enquiry_campaign/master/lead_referred_by/" + this.institute_id + "/all";
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    EnquiryReportService.prototype.enquiryCategorySearch = function (payload) {
        var url = this.baseUrl + "/api/v1/enquiry_manager/search/" + this.institute_id;
        return this.http.post(url, payload, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    EnquiryReportService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */],
            __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], EnquiryReportService);
    return EnquiryReportService;
}());



/***/ })

});
//# sourceMappingURL=enquiry-report.module.chunk.js.map