webpackJsonp(["course-subject.module"],{

/***/ "./src/app/components/course-module/create-course/course-subject/course-subject.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<section class=\"marginExtra\">\r\n\r\n  <div class=\"row\" style=\"margin-top:10px;\">\r\n    <div class=\"c-lg-6 c-md-6 c-sm-6\">\r\n      <div class=\"clearFix add-edit\">\r\n        <a (click)=\"toggleCreateNewSubject()\">\r\n          <i id=\"showAddBtnSubject\" class=\"addBtnClass\">+</i>\r\n          <i id=\"showCloseBtnSubject\" style=\"display:none\" class=\"closeBtnClass\">-</i>\r\n          <span *ngIf=\"(isLangInstitue != true )\">Add Subject</span>\r\n          <span *ngIf=\"(isLangInstitue == true )\">Add Course</span>\r\n        </a>\r\n      </div>\r\n    </div>\r\n    <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n\r\n    </div>\r\n\r\n    <div class=\"pull-right\">\r\n      <div class=\"search-filter-wrapper\">\r\n        <input #searchVal type=\"text\" class=\"normal-field pull-right\" style=\"margin-right: 15px\" placeholder=\"Search\" id=\"search\"\r\n          name=\"searchData \" (keyup)=\"searchInList(searchVal)\">\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <section class=\"clearFix create-standard-form\" *ngIf=\"createNewSubject\">\r\n    <div class=\"c-lg-8 c-sm-8 c-md-8\">\r\n      <div class=\"row create-standard-field\">\r\n\r\n        <div class=\"field-wrapper c-lg-4 c-sm-4 c-md-4\">\r\n          <label *ngIf=\"(isLangInstitue != true )\" for=\"masterCourse\">Standard Name\r\n            <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <label *ngIf=\"(isLangInstitue == true )\" for=\"masterCourse\">Master Course Name\r\n            <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <select id=\"masterCourse\" class=\"form-ctrl\" [(ngModel)]=\"newSubjectDetails.standard_id\">\r\n            <option value=\"-1\"> </option>\r\n            <option *ngFor=\"let opt of standardList\" [value]=\"opt.standard_id\">\r\n              {{opt.standard_name}}\r\n            </option>\r\n          </select>\r\n\r\n          <p>* Example English, Science</p>\r\n        </div>\r\n\r\n        <div class=\"field-wrapper c-lg-4 c-sm-4 c-md-4\">\r\n          <label *ngIf=\"(isLangInstitue != true )\" for=\"subname\">\r\n            Subject Name\r\n          </label>\r\n          <label *ngIf=\"(isLangInstitue == true )\" for=\"subname\">\r\n            Course Name\r\n            <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"newSubjectDetails.subject_name\" id=\"subname\" name=\"label\">\r\n\r\n          <p>(Eg. Maths or Science or Accounts)</p>\r\n        </div>\r\n\r\n        <div class=\"c-lg-2 c-sm-2 c-md-2\" style=\"padding-top: 10px\">\r\n          <div class=\"field-checkbox-wrapper\">\r\n            <input type=\"checkbox\" value=\"\" name=\"check\" class=\"form-checkbox\" [(ngModel)]=\"newSubjectDetails.is_active\" id=\"isAct\">\r\n            <label for=\"isAct\">Is Active</label>\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n    <div class=\"c-lg-4 c-sm-4 c-md-4\" style=\"padding-top: 20px\">\r\n      <aside class=\"\">\r\n        <input type=\"button\" value=\"Cancel\" class=\"btn cancel-btn\" style=\"\" (click)=\"toggleCreateNewSubject()\">\r\n        <input type=\"button\" value=\"Add\" class=\"btn fullBlue\" (click)=\"addNewSubject()\">\r\n      </aside>\r\n    </div>\r\n  </section>\r\n\r\n  <div class=\"fee-install-table courses-list-table\">\r\n    <div class=\"table-responsive table-change\" >\r\n      <table>\r\n        <thead>\r\n          <tr>\r\n            <th>\r\n              <label style=\"cursor:pointer;\" (click)=\"sortTable('subject_id')\">ID</label>\r\n            </th>\r\n            <th>\r\n              <label *ngIf=\"isLangInstitue\" style=\"cursor:pointer;\" (click)=\"sortTable('standard_name')\">Master Course</label>\r\n              <label *ngIf=\"!isLangInstitue\" style=\"cursor:pointer;\" (click)=\"sortTable('standard_name')\">Standard</label>\r\n            </th>\r\n            <th>\r\n              <label *ngIf=\"(isLangInstitue != true )\" style=\"cursor:pointer;\" (click)=\"sortTable('subject_name')\">Subject</label>\r\n              <label *ngIf=\"(isLangInstitue == true )\" style=\"cursor:pointer;\" (click)=\"sortTable('subject_name')\">Course</label>\r\n            </th>\r\n            <th>\r\n              <label style=\"cursor:pointer;\" (click)=\"sortTable('is_active')\">Is Active</label>\r\n            </th>\r\n            <th>\r\n              <i *ngIf=\"sortingDir == 'asc'\" (click)=\"sortTable('created_date')\" class=\"fas fa-caret-up\" style=\"font-family: FontAwesome;\"></i>\r\n              <i *ngIf=\"sortingDir != 'asc'\" (click)=\"sortTable('created_date')\" class=\"fas fa-caret-down\" style=\"font-family: FontAwesome;\"></i>\r\n              <label style=\"cursor:pointer;\" (click)=\"sortTable('created_date')\">Added Date</label>\r\n            </th>\r\n            <th>\r\n              <label>Edit</label>\r\n            </th>\r\n          </tr>\r\n        </thead>\r\n        <tbody *ngIf=\"(subjectList.length != 0)\">\r\n          <tr (click)=\"rowSelectEvent(i)\" [class.selected]=\"i == selectedRow\" class=\"displayComp\" id=\"row{{i}}\" *ngFor=\"let row of subjectList; let i = index; trackBy: i;\">\r\n            <td>\r\n              {{row.subject_id}}\r\n            </td>\r\n\r\n            <td>\r\n              {{row.standard_name}}\r\n            </td>\r\n\r\n            <td class=\"view-comp\">\r\n              {{row.subject_name}}\r\n            </td>\r\n            <td class=\"edit-comp\">\r\n              <div class=\"field-wrapper\">\r\n                <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"row.subject_name\" name=\"label\" style=\"margin:auto\">\r\n              </div>\r\n            </td>\r\n\r\n            <td class=\"view-comp\">\r\n              {{row.is_active}}\r\n            </td>\r\n            <td class=\"edit-comp\">\r\n              <div class=\"field-wrapper has-value\">\r\n                <select id=\"issearchable\" class=\"form-ctrl\" name=\"issearchable\" style=\"margin:auto\" [(ngModel)]=\"row.is_active\">\r\n                  <option value=\"Y\">Yes</option>\r\n                  <option value=\"N\">No</option>\r\n                </select>\r\n              </div>\r\n            </td>\r\n\r\n            <td>\r\n              {{row.created_date}}\r\n            </td>\r\n\r\n            <td class=\"view-comp\">\r\n              <a style=\"cursor: pointer;\" (click)=\"editRow(i)\" style=\"margin-right: 10px;\">\r\n                <i class=\"edit-icon\" aria-hidden=\"true\" style=\"margin-right: 5px;\" title=\"Edit\"></i>Edit\r\n              </a>\r\n              <a style=\"cursor: pointer;\" (click)=\"deleteRow(row)\">\r\n                <i aria-hidden=\"true\" title=\"Delete\"></i>Delete\r\n              </a>\r\n            </td>\r\n            <td class=\"edit-comp\">\r\n              <a style=\"cursor: pointer; margin-right: 10px;\" (click)=\"updateRow(row,i)\">\r\n                <i class=\"fas fa-check\" style=\"font-family: FontAwesome ;font-size: 15px;\" title=\"Update\"></i>\r\n                Update\r\n              </a>\r\n              <a style=\"cursor: pointer; margin-right: 10px;\" (click)=\"cancelRow(i)\">\r\n                <i class=\"fas fa fa-times\" style=\"font-family: FontAwesome ;font-size: 15px;\" title=\"Cancel\"></i>\r\n                Cancel\r\n              </a>\r\n            </td>\r\n          </tr>\r\n        </tbody>\r\n        <tbody *ngIf=\"subjectList.length == 0 && dataStatus === 1\">\r\n          <tr *ngFor=\"let dummy of dummyArr\">\r\n            <td *ngFor=\"let c of columnMaps\">\r\n              <div class=\"skeleton\">\r\n              </div>\r\n            </td>\r\n          </tr>\r\n        </tbody>\r\n        <tbody *ngIf=\"(subjectList.length == 0 && dataStatus === 2)\">\r\n          <tr>\r\n            <td colspan=\"6\">\r\n              No data found\r\n            </td>\r\n          </tr>\r\n        </tbody>\r\n      </table>\r\n    </div>\r\n  </div>\r\n  <!-- Paginator Here -->\r\n  <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n      <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n        [page]=\"PageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRow\">\r\n      </pagination>\r\n    </div>\r\n  </div>\r\n\r\n</section>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-subject/course-subject.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.courses-list-table {\n  max-height: 72vh;\n  min-height: 72vh;\n  overflow: auto; }\n.courses-list-table ::-webkit-scrollbar {\n    display: block; }\ntable thead tr th {\n  padding: 15px;\n  background: #f7f7f7; }\ntable tbody tr td {\n  padding: 10px; }\ntable tbody tr td .editOptions li {\n    display: inline-block; }\ntable tbody tr td th {\n    padding: 15px; }\ntable tbody tr .field-wrapper {\n  padding: 0px !important; }\ntable tbody tr .field-wrapper .form-ctrl {\n    display: block;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 0px 0px 0px 5px;\n    outline: none;\n    border: 0;\n    height: 26px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 25px;\n    background: transparent;\n    width: 80px;\n    text-align: center;\n    border-bottom: 1px solid #ccc; }\ntable tbody .displayComp {\n  height: 0%; }\ntable tbody .displayComp .edit-comp {\n    display: none; }\ntable tbody .editComp .view-comp {\n  display: none; }\n.marginExtra {\n  margin-left: 15px;\n  margin-right: 15px; }\n.table-change table thead tr th {\n  padding: 10px 5px;\n  font-weight: 600; }\n.table-change table tbody tr td {\n  padding: 5px 5px;\n  font-size: 12px; }\n.pagination {\n  padding: 0px; }\n.create-standard-form {\n  margin: 10px 0;\n  padding: 5px;\n  border-bottom: 1px solid #d8d8d8; }\n.create-standard-form .field-checkbox-wrapper {\n    margin-top: 15px; }\n.create-standard-form .field-checkbox-wrapper .form-checkbox + label {\n      font-size: 12px;\n      font-weight: 600;\n      margin-left: 10px;\n      color: #777; }\n.create-standard-form .field-checkbox-wrapper .form-checkbox:checked + label {\n      color: #0084f6; }\n.create-standard-form .field-checkbox-wrapper .form-checkbox + label:after {\n      content: '';\n      width: 24px;\n      height: 24px;\n      border: 2px solid #ccc;\n      border-radius: 2px;\n      position: absolute;\n      left: 0;\n      top: 0;\n      -webkit-transform: scale(0.7);\n              transform: scale(0.7); }\n.create-standard-form .field-checkbox-wrapper .form-checkbox + label:before {\n      width: 13px;\n      height: 5px;\n      left: 6px;\n      top: 9px;\n      -webkit-transform: rotate(-45deg) scale(0.7);\n              transform: rotate(-45deg) scale(0.7); }\n.create-standard-form .field-wrapper {\n    margin-top: -10px; }\n.create-standard-form .field-wrapper label {\n      left: 20px;\n      top: 25px;\n      font-size: 13px;\n      font-weight: 600; }\n.create-standard-form .field-wrapper.has-value .form-ctrl + label,\n  .create-standard-form .field-wrapper .form-ctrl:focus + label {\n    top: 6px;\n    left: 20px; }\n.create-standard-form .form-ctrl {\n    background: white; }\n.create-standard-form p {\n    margin-top: 5px;\n    font-size: 10px;\n    color: #979797; }\n.cancel-btn {\n  border-radius: 4px;\n  height: 30px;\n  padding: 4px 10px; }\n.add-edit {\n  margin-bottom: 0;\n  margin-top: 10px; }\n.add-edit i {\n    display: inline-block;\n    width: 17px;\n    height: 17px;\n    line-height: 1rem;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle;\n    margin-right: 4px; }\n.add-edit span {\n    display: inline-block; }\n.add-edit .expend-box i {\n    line-height: 12px;\n    font-size: 22px; }\n.add-edit a {\n    cursor: pointer; }\n.closeBtnClass {\n  line-height: 0.6rem !important; }\n.search-filter-wrapper .normal-field {\n  padding: 4px 10px;\n  border: 1px solid #ccc;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  font-size: 14px;\n  border-radius: 4px; }\n.search-filter-wrapper .field-wrapper {\n  position: relative;\n  padding-top: 0px !important;\n  width: 30%;\n  float: left !important; }\n.search-filter-wrapper .field-wrapper .form-ctrl {\n    font: 400 12px 'Open sans',sans-serif;\n    border-top: none !important;\n    border-right: none !important;\n    border-left: none !important; }\n.search-filter-wrapper .field-wrapper label {\n  position: absolute !important;\n  left: 10% !important;\n  top: 1% !important; }\n.search-filter-wrapper .field-wrapper label:after {\n    left: 85% !important;\n    top: 10px !important; }\n.skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 80%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n.skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n@-webkit-keyframes progress {\n  0% {\n    -webkit-transform: translate3d(-100%, 0, 0);\n            transform: translate3d(-100%, 0, 0); }\n  100% {\n    -webkit-transform: translate3d(100%, 0, 0);\n            transform: translate3d(100%, 0, 0); } }\n@keyframes progress {\n  0% {\n    -webkit-transform: translate3d(-100%, 0, 0);\n            transform: translate3d(-100%, 0, 0); }\n  100% {\n    -webkit-transform: translate3d(100%, 0, 0);\n            transform: translate3d(100%, 0, 0); } }\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-subject/course-subject.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CourseSubjectComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_course_services_subject_service__ = __webpack_require__("./src/app/services/course-services/subject.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var CourseSubjectComponent = /** @class */ (function () {
    function CourseSubjectComponent(apiService, toastCtrl, auth) {
        this.apiService = apiService;
        this.toastCtrl = toastCtrl;
        this.auth = auth;
        this.isRippleLoad = false;
        this.createNewSubject = false;
        this.no_subject_name = false;
        this.PageIndex = 1;
        this.displayBatchSize = 15;
        this.subjectList = [];
        this.standardList = [];
        this.newSubjectDetails = {
            is_active: "Y",
            standard_id: "-1",
            subject_name: ''
        };
        this.searchedData = [];
        this.searchDataFlag = false;
        this.dataStatus = 1;
        this.dummyArr = [0, 1, 2, 3, 4, 0, 1, 2, 3, 4];
        this.columnMaps = [0, 1, 2, 3, 4, 5];
        this.isLangInstitue = false;
        this.sortingDir = "asc";
    }
    CourseSubjectComponent.prototype.ngOnInit = function () {
        this.checkInstituteType();
        this.getAllSubjectList();
        this.getAllStandardSubjectList();
    };
    CourseSubjectComponent.prototype.getAllSubjectList = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getAllSubjectListFromServer().subscribe(function (data) {
            _this.totalRow = data.length;
            data.sort(function (a, b) {
                return __WEBPACK_IMPORTED_MODULE_3_moment__(b.created_date).unix() - __WEBPACK_IMPORTED_MODULE_3_moment__(a.created_date).unix();
            });
            _this.subjectListDataSource = data;
            _this.fetchTableDataByPage(_this.PageIndex);
            _this.isRippleLoad = false;
            _this.dataStatus = 2;
        }, function (error) {
        });
    };
    CourseSubjectComponent.prototype.editRow = function (id) {
        document.getElementById(("row" + id).toString()).classList.remove('displayComp');
        document.getElementById(("row" + id).toString()).classList.add('editComp');
    };
    CourseSubjectComponent.prototype.cancelRow = function (id) {
        document.getElementById(("row" + id).toString()).classList.remove('editComp');
        document.getElementById(("row" + id).toString()).classList.add('displayComp');
        this.getAllSubjectList();
    };
    CourseSubjectComponent.prototype.updateRow = function (row, id) {
        var _this = this;
        var data = {};
        data.is_active = row.is_active;
        data.subject_name = row.subject_name;
        data.institution_id = row.institution_id;
        if (data.subject_name == "" && data.data.subject_name == null) {
            var msg = {
                type: "error",
                title: "",
                body: "Please enter Subject Name"
            };
            this.toastCtrl.popToast(msg);
            return;
        }
        this.apiService.updateSubjectRowData(data, row.subject_id).subscribe(function (data) {
            var msg = {
                type: "success",
                title: "Standard Updated",
                body: "Standard Updated Successfully!"
            };
            _this.toastCtrl.popToast(msg);
            _this.cancelRow(id);
        }, function (error) {
            var data = {
                type: "error",
                title: "",
                body: error.error.message
            };
            _this.toastCtrl.popToast(data);
        });
    };
    CourseSubjectComponent.prototype.getAllStandardSubjectList = function () {
        var _this = this;
        this.apiService.getAllStandardName().subscribe(function (res) {
            _this.standardList = res;
        }, function (error) {
        });
    };
    CourseSubjectComponent.prototype.addNewSubject = function () {
        var _this = this;
        if (this.newSubjectDetails.standard_id == "" || this.newSubjectDetails.subject_name == "" || this.newSubjectDetails.standard_id == '-1') {
            var data = {
                type: "error",
                title: "",
                body: "Please enter value of mandatory fields."
            };
            this.toastCtrl.popToast(data);
            return false;
        }
        else {
            if (this.newSubjectDetails.is_active == true || this.newSubjectDetails.is_active == "Y") {
                this.newSubjectDetails.is_active = "Y";
            }
            else {
                this.newSubjectDetails.is_active = "N";
            }
            this.apiService.createNewSubject(this.newSubjectDetails).subscribe(function (res) {
                var msg = "";
                if (_this.isLangInstitue) {
                    msg = "Course added Successfull!!";
                }
                else {
                    msg = "New Subject added Successfull!";
                }
                var data = {
                    type: "success",
                    title: "Subject Added",
                    body: msg
                };
                _this.toastCtrl.popToast(data);
                _this.getAllSubjectList();
                _this.newSubjectDetails = {
                    is_active: "Y",
                    standard_id: "",
                    subject_name: ''
                };
            }, function (err) {
                var data = {
                    type: "error",
                    title: "",
                    body: err.error.message
                };
                _this.toastCtrl.popToast(data);
            });
        }
    };
    CourseSubjectComponent.prototype.searchInList = function (element) {
        if (element.value != "" && element.value != null) {
            var searchData = this.subjectListDataSource.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(element.value.toLowerCase()); });
            });
            this.searchedData = searchData;
            this.searchDataFlag = true;
            this.totalRow = searchData.length;
            this.PageIndex = 1;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchDataFlag = false;
            this.fetchTableDataByPage(this.PageIndex);
            this.totalRow = this.subjectListDataSource.length;
        }
    };
    /* Function to set the createNewStandard View On/Off */
    CourseSubjectComponent.prototype.toggleCreateNewSubject = function () {
        if (this.createNewSubject == false) {
            this.createNewSubject = true;
            document.getElementById('showCloseBtnSubject').style.display = '';
            document.getElementById('showAddBtnSubject').style.display = 'none';
        }
        else {
            this.no_subject_name = false;
            this.createNewSubject = false;
            document.getElementById('showCloseBtnSubject').style.display = 'none';
            document.getElementById('showAddBtnSubject').style.display = '';
            this.newSubjectDetails = {
                is_active: "Y",
                standard_id: "",
                subject_name: ''
            };
        }
    };
    CourseSubjectComponent.prototype.deleteRow = function (row) {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.deleteSubject(row.subject_id).subscribe(function (res) {
            _this.isRippleLoad = false;
            var data = {
                type: "success",
                title: '',
                body: "Deleted Successfully"
            };
            _this.toastCtrl.popToast(data);
            _this.getAllSubjectList();
        }, function (err) {
            _this.isRippleLoad = false;
            var data = {
                type: "error",
                title: "",
                body: err.error.message
            };
            _this.toastCtrl.popToast(data);
        });
    };
    // pagination functions
    CourseSubjectComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.subjectList = this.getDataFromDataSource(startindex);
    };
    CourseSubjectComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    CourseSubjectComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    CourseSubjectComponent.prototype.getDataFromDataSource = function (startindex) {
        var data = [];
        if (this.searchDataFlag) {
            data = this.searchedData.slice(startindex, startindex + this.displayBatchSize);
        }
        else {
            data = this.subjectListDataSource.slice(startindex, startindex + this.displayBatchSize);
        }
        return data;
    };
    CourseSubjectComponent.prototype.sortTable = function (str) {
        if (str == "standard_name" || str == "subject_name" || str == "is_active") {
            this.subjectListDataSource.sort(function (a, b) {
                var nameA = a[str].toUpperCase(); // ignore upper and lowercase
                var nameB = b[str].toUpperCase(); // ignore upper and lowercase
                if (nameA < nameB) {
                    return -1;
                }
                if (nameA > nameB) {
                    return 1;
                }
                // names must be equal
                return 0;
            });
        }
        else if (str == "subject_id") {
            this.subjectListDataSource.sort(function (a, b) {
                return a[str] - b[str];
            });
        }
        else if (str == "created_date") {
            this.subjectListDataSource.sort(function (a, b) {
                return __WEBPACK_IMPORTED_MODULE_3_moment__(a[str]).unix() - __WEBPACK_IMPORTED_MODULE_3_moment__(b[str]).unix();
            });
        }
        if (this.sortingDir == "asc") {
            this.sortingDir = "dec";
        }
        else {
            this.sortingDir = "asc";
            this.subjectListDataSource = this.subjectListDataSource.reverse();
        }
        this.fetchTableDataByPage(this.PageIndex);
    };
    CourseSubjectComponent.prototype.rowSelectEvent = function (i) {
        this.selectedRow = i;
    };
    CourseSubjectComponent.prototype.checkInstituteType = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isLangInstitue = true;
            }
            else {
                _this.isLangInstitue = false;
            }
        });
    };
    CourseSubjectComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-course-subject',
            template: __webpack_require__("./src/app/components/course-module/create-course/course-subject/course-subject.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/create-course/course-subject/course-subject.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_course_services_subject_service__["a" /* SubjectApiService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_4__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], CourseSubjectComponent);
    return CourseSubjectComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/course-subject/course-subject.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseSubjectModule", function() { return CourseSubjectModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__course_subject_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-subject/course-subject.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_datepicker_bs_datepicker_module__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/bs-datepicker.module.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_course_services_subject_service__ = __webpack_require__("./src/app/services/course-services/subject.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__course_subject_routing_module__ = __webpack_require__("./src/app/components/course-module/create-course/course-subject/course-subject.routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








var CourseSubjectModule = /** @class */ (function () {
    function CourseSubjectModule() {
    }
    CourseSubjectModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_6__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_6__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_7__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_datepicker_bs_datepicker_module__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_2__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_5__course_subject_routing_module__["a" /* CourseSubjectRouting */]
            ],
            exports: [],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_1__course_subject_component__["a" /* CourseSubjectComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_4__services_course_services_subject_service__["a" /* SubjectApiService */]
            ]
        })
    ], CourseSubjectModule);
    return CourseSubjectModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/course-subject/course-subject.routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CourseSubjectRouting; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__course_subject_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-subject/course-subject.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var CourseSubjectRouting = /** @class */ (function () {
    function CourseSubjectRouting() {
    }
    CourseSubjectRouting = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__course_subject_component__["a" /* CourseSubjectComponent */],
                        pathMatch: 'prefix',
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], CourseSubjectRouting);
    return CourseSubjectRouting;
}());



/***/ }),

/***/ "./src/app/services/course-services/subject.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SubjectApiService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var SubjectApiService = /** @class */ (function () {
    function SubjectApiService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseURL = "";
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseURL = this.auth.getBaseUrl();
    }
    SubjectApiService.prototype.getAllSubjectListFromServer = function () {
        var url = this.baseURL + "/api/v1/subjects/all/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    SubjectApiService.prototype.updateSubjectRowData = function (data, id) {
        var url = this.baseURL + "/api/v1/subjects/" + id;
        return this.http.put(url, data, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    SubjectApiService.prototype.getAllStandardName = function () {
        var url = this.baseURL + '/api/v1/standards/all/' + this.institute_id + "?active=Y";
        return this.http.get(url, { headers: this.headers }).map(function (res) {
            return res;
        }, function (error) {
            return error;
        });
    };
    SubjectApiService.prototype.createNewSubject = function (data) {
        var url = this.baseURL + '/api/v1/subjects';
        return this.http.post(url, data, { headers: this.headers }).map(function (res) {
            return res;
        }, function (error) {
            return error;
        });
    };
    SubjectApiService.prototype.deleteSubject = function (data) {
        var url = this.baseURL + '/api/v1/subjects/' + data;
        return this.http.delete(url, { headers: this.headers }).map(function (res) {
            return res;
        }, function (error) {
            return error;
        });
    };
    SubjectApiService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */],
            __WEBPACK_IMPORTED_MODULE_2__authenticator_service__["a" /* AuthenticatorService */]])
    ], SubjectApiService);
    return SubjectApiService;
}());



/***/ })

});
//# sourceMappingURL=course-subject.module.chunk.js.map