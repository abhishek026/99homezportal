webpackJsonp(["library-management.module"],{

/***/ "./src/app/components/library-management/activity/activity.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"coming_soon\">\r\n  <span>Coming soon</span>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/library-management/activity/activity.component.scss":
/***/ (function(module, exports) {

module.exports = ".coming_soon {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  margin-top: 50px;\n  font-size: 16px;\n  font-weight: 600;\n  color: #9b9b9b; }\n"

/***/ }),

/***/ "./src/app/components/library-management/activity/activity.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ActivityComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ActivityComponent = /** @class */ (function () {
    function ActivityComponent() {
    }
    ActivityComponent.prototype.ngOnInit = function () {
    };
    ActivityComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-activity',
            template: __webpack_require__("./src/app/components/library-management/activity/activity.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/activity/activity.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], ActivityComponent);
    return ActivityComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/add-book/add-book.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n<section>\r\n  <div class=\"add_book_container\">\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Title<span class=\"text-danger\">*</span></span>\r\n      <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Book Name\" class=\"add_input\" [(ngModel)]=\"title\">\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Category<span class=\"text-danger\">*</span></span>\r\n      <div class=\"select_with_add\">\r\n        <select class=\"add_input1\" name=\"\" (ngModelChange)=\"getSubCategory($event)\" [(ngModel)]=\"categoryName\">\r\n          <option value=\"-1\">Select Category Name</option>\r\n          <option [value]=\"category.category_id\" *ngFor=\"let category of categoryList let i = index\">{{category.category_name}}</option>\r\n        </select>\r\n        <!-- <div class=\"add\" *ngIf=\"!addCategory\">\r\n          <button type=\"button\" name=\"button\" class=\"add_new\" (click)=\"addNewCategory()\">\r\n            <i class=\"fa fa-plus\" aria-hidden=\"true\"></i>\r\n          </button>\r\n        </div> -->\r\n        <!-- <div class=\"\" *ngIf=\"addCategory\">\r\n          <input type=\"number\" name=\"\" value=\"\" placeholder=\"Enter Category Name\" class=\"add_input1\">\r\n        </div>\r\n        <div class=\"save_and_cancel\" *ngIf=\"addCategory\">\r\n          <span class=\"save\">Save</span>\r\n          <span class=\"cancel\">Cancel</span>\r\n        </div> -->\r\n      </div>\r\n    </div>\r\n\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Sub-Category</span>\r\n      <select class=\"add_input1\" name=\"\" [(ngModel)]=\"subcategoryName\">\r\n        <option value=\"-1\">Select Sub-Category Name</option>\r\n        <option [value]=\"subCategory.category_id\" *ngFor=\"let subCategory of subcategoryList let i = index\">{{subCategory.category_name}}</option>\r\n      </select>\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Subject<span class=\"text-danger\">*</span></span>\r\n      <select class=\"add_input1\" name=\"\" [(ngModel)]=\"subjectName\">\r\n        <option value=\"-1\">Select Subject Name</option>\r\n        <option [value]=\"subject.subject_id\" *ngFor=\"let subject of subjectList let i = index\">{{subject.subject_name}}</option>\r\n      </select>\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Publication<span class=\"text-danger\">*</span></span>\r\n      <select class=\"add_input1\" name=\"\" [(ngModel)]=\"publicationName\">\r\n        <option value=\"-1\">Select Publication Name</option>\r\n        <option [value]=\"publication.publication_id\" *ngFor=\"let publication of publicationList let i = index\">{{publication.publication_name}}</option>\r\n      </select>\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Author<span class=\"text-danger\">*</span></span>\r\n      <!-- <select class=\"add_input1\" name=\"\" [(ngModel)]=\"authorName\">\r\n        <option value=\"-1\">Select Author Name</option>\r\n        <option [value]=\"author.author_id\" *ngFor=\"let author of authorList let i = index\">{{author.author_name}}</option>\r\n      </select> -->\r\n      <ng-multiselect-dropdown\r\n        [placeholder]=\"'Select Author Name'\"\r\n        [data]=\"authorList\"\r\n        [settings]=\"authorSettings\"\r\n        [(ngModel)]=\"selectedAuthorList\" >\r\n      </ng-multiselect-dropdown>\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Quantity<span class=\"text-danger\">*</span></span>\r\n      <input type=\"number\" name=\"\" value=\"\" placeholder=\"No of Books\" class=\"add_input2\" [(ngModel)]=\"bookQty\">\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Amount in Rs.<span class=\"text-danger\">*</span></span>\r\n      <input type=\"number\" name=\"\" value=\"\" placeholder=\"Price per book\" class=\"add_input2\" [(ngModel)]=\"bookAmt\">\r\n    </div>\r\n\r\n    <!-- <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Book Add Date*</span>\r\n      <input type=\"text\" name=\"\" value=\"\" placeholder=\"\" disabled class=\"add_input2\" [(ngModel)]=\"today\">\r\n      <i class=\"fa fa-calendar\" style=\"cursor: pointer;color: #1283f4;\" (click)=\"openCalendar('addDate')\"></i>\r\n\r\n      <input  type=\"text\" value=\"\" id=\"addDate\" class=\"widgetDatepicker bsDatepicker\" name=\"addDate\"\r\n       [(ngModel)]=\"bookAddDate\" (ngModelChange)=\"addNewDate($event)\" readonly=\"true\" bsDatepicker  style=\"width:0px;margin-right: 10px;\"/>\r\n    </div> -->\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Language<span class=\"text-danger\">*</span></span>\r\n      <select class=\"add_input1\" name=\"\" [(ngModel)]=\"bookLang\">\r\n        <option value=\"-1\">Select Language</option>\r\n        <option [value]=\"language.language_id\" *ngFor=\"let language of languageList let i = index\">{{language.language_name}}</option>\r\n      </select>\r\n    </div>\r\n\r\n  </div>\r\n</section>\r\n\r\n<section>\r\n  <div class=\"add_details_btn_container\">\r\n    <button type=\"button\" name=\"button\" class=\"add_details\" (click)=\"showAdditionalDetails()\">\r\n      <i class=\"fa fa-plus\" aria-hidden=\"true\" *ngIf=\"!additiobnalDetailsDisplay\"></i>\r\n      <i class=\"fa fa-minus\" aria-hidden=\"true\" *ngIf=\"additiobnalDetailsDisplay\"></i> &nbsp;&nbsp;\r\n       Additional Details\r\n    </button>\r\n  </div>\r\n</section>\r\n\r\n<section class=\"addtional_details_section\" *ngIf=\"additiobnalDetailsDisplay\">\r\n  <div class=\"add_book_more_details\">\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Barcode Number</span>\r\n      <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Barcode Number\" class=\"add_input2\" [(ngModel)]=\"bookBarCodeNumber\">\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">ISBN Number</span>\r\n      <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter ISBN Number\" class=\"add_input2\" [(ngModel)]=\"bookISBN\">\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Number of pages</span>\r\n      <input type=\"number\" name=\"\" value=\"\" placeholder=\"Enter No. of pages\" class=\"add_input2\" [(ngModel)]=\"bookPagesCount\">\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Volume</span>\r\n      <input type=\"number\" name=\"\" value=\"\" placeholder=\"Enter Volume of books\" class=\"add_input2\" [(ngModel)]=\"bookVolume\">\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Edition</span>\r\n      <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Edition\" class=\"add_input2\" [(ngModel)]=\"bookEdition\">\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Reference</span>\r\n      <select class=\"add_input2\" name=\"\" [(ngModel)]=\"bookReference\">\r\n        <option value=\"-1\">Select Reference</option>\r\n        <option [value]=\"reference.reference_id\" *ngFor=\"let reference of referenceList let i = index\">{{reference.reference_name}}</option>\r\n      </select>\r\n    </div>\r\n\r\n    <!-- <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Language</span>\r\n      <select class=\"add_input2\" name=\"\" [(ngModel)]=\"bookLang\">\r\n        <option value=\"-1\">Select Language</option>\r\n        <option [value]=\"language.language_id\" *ngFor=\"let language of languageList let i = index\">{{language.language_name}}</option>\r\n      </select>\r\n    </div> -->\r\n\r\n  </div>\r\n\r\n  <hr>\r\n\r\n  <div class=\"book_detail_name_container\">\r\n    <span>Book Bill Details</span>\r\n  </div>\r\n\r\n  <div class=\"books_details_container\">\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Bill Number</span>\r\n      <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Bill Number\" class=\"add_input2\" [(ngModel)]=\"bookBillNumber\">\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Book Lost Amount in Rs.</span>\r\n      <input type=\"number\" name=\"\" value=\"\" placeholder=\"Enter Book Lost Amount\" class=\"add_input2\" [(ngModel)]=\"bookLostAmt\">\r\n    </div>\r\n\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Bill Date</span>\r\n      <input type=\"text\" name=\"\" value=\"\" placeholder=\"\" class=\"add_input2\" readonly [(ngModel)]=\"tempBillDate\" (click)=\"openCalendar('billDate')\">\r\n      <i class=\"fa fa-calendar\" style=\"cursor: pointer;color: #1283f4;\" (click)=\"openCalendar('billDate')\"></i>\r\n\r\n      <input  type=\"text\" value=\"\" id=\"billDate\" class=\"widgetDatepicker bsDatepicker\" name=\"billDate\"\r\n       [(ngModel)]=\"bookBillDate\" (ngModelChange)=\"addBookDate($event)\" readonly=\"true\" bsDatepicker  style=\"width:0px;margin-right: 10px;\"/>\r\n    </div>\r\n\r\n  </div>\r\n\r\n  <div class=\"books_details_remark_container\">\r\n    <div class=\"add_book_item\">\r\n      <span style=\"margin-bottom:3px;\">Remark</span>\r\n      <textarea name=\"name\" rows=\"3\" class=\"add_input3\" placeholder=\"Enter Remarks...\" [(ngModel)]=\"bookRemarks\"></textarea>\r\n    </div>\r\n  </div>\r\n\r\n</section>\r\n\r\n\r\n<section style=\"background: #fdfdfd;\">\r\n  <div class=\"action_button_container\">\r\n    <button type=\"button\" name=\"button\" class=\"cancel_btn\" (click)=\"clearAllFields()\">Cancel</button>\r\n    <button type=\"button\" name=\"button\" class=\"save_btn\" (click)=\"addNewBook()\" [disabled]=\"multiClickDisabled\">Save</button>\r\n  </div>\r\n</section>\r\n"

/***/ }),

/***/ "./src/app/components/library-management/add-book/add-book.component.scss":
/***/ (function(module, exports) {

module.exports = ".add_book_container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  -ms-flex-pack: distribute;\n      justify-content: space-around; }\n  .add_book_container .add_book_item {\n    width: 30%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    color: #3e3d4a;\n    margin-bottom: 20px;\n    position: relative; }\n  .add_book_container .add_book_item .select_with_add {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row; }\n  .add_book_container .add_book_item .select_with_add .save_and_cancel {\n        margin-left: 10px;\n        margin-top: 5px; }\n  .add_book_container .add_book_item .select_with_add .save_and_cancel .save {\n          color: #1984f6;\n          cursor: pointer;\n          margin-right: 10px; }\n  .add_book_container .add_book_item .select_with_add .save_and_cancel .cancel {\n          color: #dcdcdc;\n          cursor: pointer; }\n  .add_book_container .add_book_item .select_with_add .add {\n        margin-left: 5px; }\n  .add_book_container .add_book_item .select_with_add .add .add_new {\n          border: 1px solid #9b9b9b;\n          border-radius: 4px;\n          color: #9b9b9b;\n          padding: 6px 8px;\n          background: white;\n          height: 28px;\n          font-size: 12px; }\n  .add_book_container .add_book_item span {\n      font-size: 12px; }\n  .add_book_container .add_book_item .add_input {\n      background: white;\n      border-radius: 4px;\n      padding: 5px 10px;\n      border: 1px solid #bdbdbd;\n      width: 80%; }\n  .add_book_container .add_book_item .add_input1 {\n      background: white;\n      border-radius: 4px;\n      border: 1px solid #bdbdbd;\n      width: 70%; }\n  .add_book_container .add_book_item .add_input2 {\n      background: white;\n      border-radius: 4px;\n      padding: 5px 10px;\n      border: 1px solid #bdbdbd;\n      width: 35%; }\n  .add_book_container .add_book_item .fa-calendar {\n      position: absolute;\n      top: 24px;\n      right: 68%; }\n  .add_book_container .add_book_item ::-webkit-input-placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .add_book_container .add_book_item :-ms-input-placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .add_book_container .add_book_item ::-ms-input-placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .add_book_container .add_book_item ::placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .add_book_container .add_book_item .widgetDatepicker {\n      position: absolute;\n      margin-left: 10%;\n      width: 1px;\n      visibility: hidden;\n      opacity: 0; }\n  .add_book_container .add_book_item .bsDatepicker {\n      padding: 5px;\n      width: 100%;\n      position: absolute;\n      left: 80px; }\n  .add_book_container .add_book_item select {\n      height: 28px;\n      padding: 0px 10px; }\n  .addtional_details_section {\n  background: #fdfdfd; }\n  .add_book_more_details {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  -ms-flex-pack: distribute;\n      justify-content: space-around; }\n  .add_book_more_details .add_book_item {\n    width: 30%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    color: #3e3d4a;\n    margin-bottom: 20px;\n    position: relative; }\n  .add_book_more_details .add_book_item span {\n      font-size: 12px; }\n  .add_book_more_details .add_book_item .add_input2 {\n      background: white;\n      border-radius: 4px;\n      padding: 5px 10px;\n      border: 1px solid #bdbdbd;\n      width: 47%; }\n  .add_book_more_details .add_book_item ::-webkit-input-placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .add_book_more_details .add_book_item :-ms-input-placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .add_book_more_details .add_book_item ::-ms-input-placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .add_book_more_details .add_book_item ::placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  hr {\n  margin-top: 0px;\n  margin-bottom: 20px;\n  border: 0;\n  border-top: 1px solid #eee; }\n  .book_detail_name_container {\n  margin-top: 10px;\n  text-align: left;\n  margin-left: 2%; }\n  .book_detail_name_container span {\n    font-weight: 600; }\n  .books_details_container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  -ms-flex-pack: distribute;\n      justify-content: space-around;\n  margin-top: 20px; }\n  .books_details_container .add_book_item {\n    width: 30%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    color: #3e3d4a;\n    margin-bottom: 20px;\n    position: relative; }\n  .books_details_container .add_book_item span {\n      font-size: 12px; }\n  .books_details_container .add_book_item i {\n      position: absolute;\n      top: 24px;\n      right: 56%; }\n  .books_details_container .add_book_item .add_input2 {\n      background: white;\n      border-radius: 4px;\n      padding: 5px 10px;\n      border: 1px solid #bdbdbd;\n      width: 47%; }\n  .books_details_container .add_book_item ::-webkit-input-placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .books_details_container .add_book_item :-ms-input-placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .books_details_container .add_book_item ::-ms-input-placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .books_details_container .add_book_item ::placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .books_details_remark_container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  margin-left: 2%; }\n  .books_details_remark_container .add_book_item {\n    width: 30%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    color: #3e3d4a;\n    margin-bottom: 20px;\n    position: relative; }\n  .books_details_remark_container .add_book_item span {\n      font-size: 12px; }\n  .books_details_remark_container .add_book_item .add_input3 {\n      background: white;\n      border-radius: 4px;\n      padding: 5px 10px;\n      border: 1px solid #bdbdbd;\n      width: 70%; }\n  .books_details_remark_container .add_book_item ::-webkit-input-placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .books_details_remark_container .add_book_item :-ms-input-placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .books_details_remark_container .add_book_item ::-ms-input-placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .books_details_remark_container .add_book_item ::placeholder {\n      /* Chrome, Firefox, Opera, Safari 10.1+ */\n      color: #bdbdbd; }\n  .add_details_btn_container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  margin-left: 2%;\n  margin-top: 10px;\n  margin-bottom: 20px; }\n  .add_details_btn_container .add_details {\n    color: #1984f6;\n    border-radius: 4px;\n    border: 1px solid #1984f6;\n    padding: 10px;\n    background: white;\n    font-weight: 600; }\n  .action_button_container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n  margin-right: 2%;\n  padding-top: 20px;\n  padding-bottom: 20px;\n  font-weight: 600; }\n  .action_button_container .cancel_btn {\n    background: white;\n    width: 100px;\n    text-align: center;\n    padding: 10px;\n    color: #1984f6;\n    border-radius: 4px;\n    border: 1px solid #1984f6;\n    cursor: pointer;\n    margin-right: 10px; }\n  .action_button_container .save_btn {\n    background: #1984f6;\n    width: 100px;\n    text-align: center;\n    padding: 10px;\n    color: white;\n    border-radius: 4px;\n    border: 1px solid #1984f6;\n    cursor: pointer; }\n  input[type=number]::-webkit-inner-spin-button,\ninput[type=number]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0; }\n  .multiselect-dropdown {\n  font-size: 14px !important;\n  width: 70% !important;\n  font-size: 14px !important;\n  background: white; }\n  .multiselect-dropdown .add_book_container .add_book_item span {\n    font-size: 12px;\n    color: #1984f6;\n    font-weight: 600; }\n  .multiselect-dropdown .dropdown-down {\n    border-top: 5px solid black !important;\n    border-left: 5px solid transparent !important;\n    border-right: 5px solid transparent !important; }\n  .multiselect-dropdown .dropdown-up {\n    border-bottom: 5px solid black !important;\n    border-left: 5px solid transparent !important;\n    border-right: 5px solid transparent !important; }\n  .multiselect-dropdown .dropdown-btn {\n    display: inline-block;\n    border: 1px solid #adadad;\n    width: 100%;\n    padding: 4px 8px;\n    margin-bottom: 0;\n    font-weight: 400;\n    line-height: 1.52857143;\n    text-align: left;\n    vertical-align: middle;\n    cursor: pointer;\n    background-image: none;\n    border-radius: 4px;\n    font-size: 12px; }\n  .dropdown-btn {\n  padding: 4px 12px !important; }\n  input {\n  background: #fdfdfd; }\n  select {\n  font-size: 12px; }\n"

/***/ }),

/***/ "./src/app/components/library-management/add-book/add-book.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AddBookComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_library_add_add_book_service__ = __webpack_require__("./src/app/services/library/add/add-book.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var AddBookComponent = /** @class */ (function () {
    function AddBookComponent(router, auth, commonService, appC, addBookService) {
        this.router = router;
        this.auth = auth;
        this.commonService = commonService;
        this.appC = appC;
        this.addBookService = addBookService;
        this.additiobnalDetailsDisplay = false;
        this.addCategory = false;
        this.isRippleLoad = false;
        this.authorSettings = {};
        this.selectedAuthorList = [];
        this.multiClickDisabled = false;
        // Master add book data
        this.title = '';
        this.categoryName = '-1';
        this.subcategoryName = '-1';
        this.subjectName = '-1';
        this.publicationName = '-1';
        this.authorName = '-1';
        this.bookAddDate = '';
        this.bookQty = '';
        this.bookAmt = '';
        this.bookISBN = '';
        this.bookPagesCount = '';
        this.bookVolume = '';
        this.bookEdition = '';
        this.bookReference = '-1';
        this.bookLang = '-1';
        this.bookBillNumber = '';
        this.bookLostAmt = '';
        this.bookBillDate = '';
        this.bookRemarks = '';
    }
    AddBookComponent.prototype.ngOnInit = function () {
        this.today = __WEBPACK_IMPORTED_MODULE_6_moment__(new Date()).format("DD MMM YYYY");
        this.tempBillDate = __WEBPACK_IMPORTED_MODULE_6_moment__(new Date()).format("DD MMM YYYY");
        this.getAllMasterData();
        this.authorSettings = {
            singleSelection: false,
            idField: 'author_id',
            textField: 'author_name',
            itemsShowLimit: 1,
            enableCheckAll: false
        };
    };
    AddBookComponent.prototype.getAllMasterData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.addBookService.getAllMasterData().subscribe(function (response) {
            _this.isRippleLoad = false;
            var res;
            res = response;
            console.log(response);
            _this.categoryList = res.response.categories;
            _this.subjectList = res.response.subjects;
            _this.publicationList = res.response.publications;
            _this.authorList = res.response.authors;
            _this.languageList = res.response.languages;
            _this.referenceList = res.response.references;
        }, function (errorResponse) {
            _this.isRippleLoad = false;
            console.log(errorResponse);
        });
    };
    AddBookComponent.prototype.getSubCategory = function (ev) {
        var _this = this;
        this.isRippleLoad = true;
        this.addBookService.getSubCategories(ev).subscribe(function (response) {
            _this.isRippleLoad = false;
            var res;
            res = response;
            console.log(response);
            _this.subcategoryList = res.response;
        }, function (errorResponse) {
            _this.isRippleLoad = false;
            console.log(errorResponse);
        });
    };
    AddBookComponent.prototype.showAdditionalDetails = function () {
        if (this.additiobnalDetailsDisplay) {
            this.additiobnalDetailsDisplay = false;
            return;
        }
        if (!this.additiobnalDetailsDisplay) {
            this.additiobnalDetailsDisplay = true;
            return;
        }
    };
    AddBookComponent.prototype.addNewCategory = function () {
        this.addCategory = true;
    };
    AddBookComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    AddBookComponent.prototype.addNewDate = function () {
        var check = this.dateGreaterThanCheck(this.bookAddDate);
        if (check) {
            this.today = __WEBPACK_IMPORTED_MODULE_6_moment__(this.bookAddDate).format("DD MMM YYYY");
        }
        else {
            this.messageHandler('error', 'Bill date cannot be future date', '');
        }
    };
    AddBookComponent.prototype.addBookDate = function () {
        var check = this.dateGreaterThanCheck(this.bookBillDate);
        if (check) {
            this.tempBillDate = __WEBPACK_IMPORTED_MODULE_6_moment__(this.bookBillDate).format("DD MMM YYYY");
        }
        else {
            this.messageHandler('error', 'Bill date cannot be future date', '');
        }
    };
    AddBookComponent.prototype.dateGreaterThanCheck = function (givenDate) {
        var currentDate = new Date();
        givenDate = new Date(givenDate);
        if (givenDate > currentDate) {
            return false;
        }
        else {
            return true;
        }
    };
    AddBookComponent.prototype.addNewBook = function () {
        var _this = this;
        var custAuthorIds = [];
        this.selectedAuthorList.map(function (ele) {
            var x = ele.author_id.toString();
            custAuthorIds.push(x);
        });
        if (this.title == null || this.title == '' ||
            this.categoryName == '-1' || this.categoryName == null || this.categoryName == '' ||
            this.subjectName == '-1' || this.subjectName == null || this.subjectName == '' ||
            this.publicationName == '-1' || this.publicationName == null || this.publicationName == '' ||
            this.bookLang == '-1' || this.bookLang == null || this.bookLang == '' ||
            custAuthorIds.length == 0 ||
            this.bookQty == null || this.bookQty == '' ||
            this.bookAmt == null || this.bookAmt == '') {
            this.messageHandler('error', 'Mandatory field(s) are required', '');
        }
        else if (this.bookQty == 0) {
            this.messageHandler('error', 'Book quantity should not be zero', '');
        }
        else if (this.bookAmt == 0) {
            this.messageHandler('error', 'Book amount should not be zero', '');
        }
        else {
            var d = void 0;
            if (this.bookBillDate == "") {
                d = "";
            }
            else {
                d = __WEBPACK_IMPORTED_MODULE_6_moment__(this.bookBillDate).unix();
            }
            var obj = {
                "category_id": this.categoryName,
                "sub_category_id": this.subcategoryName,
                "subject_id": this.subjectName,
                "publication_id": this.publicationName,
                "language_id": this.bookLang,
                "reference_id": this.bookReference,
                "authors": custAuthorIds,
                "title": this.title,
                // "location": ,
                "volume": this.bookVolume,
                // "due_fine_per_day": ,
                "edition": this.bookEdition,
                "book_lost_fine": this.bookLostAmt,
                // "issue_for_days": ,
                "bar_code_number": this.bookBarCodeNumber,
                "isbn_number": this.bookISBN,
                "quantity": this.bookQty,
                "price_per_book": this.bookAmt,
                "no_of_pages": this.bookPagesCount,
                "bill_number": this.bookBillNumber,
                "bill_date": d,
                "bill_remark": this.bookRemarks
            };
            this.isRippleLoad = true;
            this.multiClickDisabled = true;
            console.log(obj);
            this.addBookService.addNewBook(obj).subscribe(function (response) {
                var res;
                res = response;
                if (res.response != null) {
                    _this.isRippleLoad = false;
                    _this.messageHandler('success', 'Book(s) added successfully', '');
                    var res_1;
                    res_1 = response;
                    console.log(response);
                    _this.multiClickDisabled = false;
                    _this.clearAllFields();
                }
                else {
                    _this.multiClickDisabled = false;
                    _this.isRippleLoad = false;
                    if (res.errorResponse[0].errorCode == 700) {
                        _this.messageHandler('error', 'Book alredy exists', '');
                    }
                    _this.messageHandler('error', 'Internal Server Error', '');
                }
            }, function (errorResponse) {
                _this.isRippleLoad = false;
                _this.messageHandler('error', 'Internal Server Error', '');
                console.log(errorResponse);
            });
        }
    };
    AddBookComponent.prototype.clearAllFields = function () {
        this.today = __WEBPACK_IMPORTED_MODULE_6_moment__(new Date()).format("DD MMM YYYY");
        this.tempBillDate = __WEBPACK_IMPORTED_MODULE_6_moment__(new Date()).format("DD MMM YYYY");
        this.bookBillDate = __WEBPACK_IMPORTED_MODULE_6_moment__(new Date()).format("DD MMM YYYY");
        this.title = "";
        this.categoryName = "-1";
        this.subcategoryName = "-1";
        this.subjectName = "-1";
        this.publicationName = "-1";
        this.authorName = "-1";
        this.bookAddDate = "";
        this.bookQty = "";
        this.bookAmt = "";
        this.bookBarCodeNumber = "";
        this.bookISBN = "";
        this.bookPagesCount = "";
        this.bookVolume = "";
        this.bookEdition = "";
        this.bookReference = "-1";
        this.bookLang = "-1";
        this.bookBillNumber = "";
        this.bookLostAmt = "";
        this.bookRemarks = "";
        this.selectedAuthorList = [];
    };
    AddBookComponent.prototype.messageHandler = function (type, title, body) {
        var obj = {
            type: type,
            title: title,
            body: body
        };
        this.appC.popToast(obj);
    };
    AddBookComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-add-book',
            template: __webpack_require__("./src/app/components/library-management/add-book/add-book.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/add-book/add-book.component.scss")],
            encapsulation: __WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewEncapsulation"].None
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__services_common_service__["a" /* CommonServiceFactory */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_5__services_library_add_add_book_service__["a" /* AddBookService */]])
    ], AddBookComponent);
    return AddBookComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/dashboard/dashboard.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"row\" [ngClass]=\"{'hide': !isDataLoaded}\">\r\n    <div id=\"pieContainer\">\r\n    </div>\r\n</section>\r\n"

/***/ }),

/***/ "./src/app/components/library-management/dashboard/dashboard.component.scss":
/***/ (function(module, exports) {

module.exports = ".pie-wrapper {\n  -webkit-box-shadow: 0px 0px 2px 1px;\n          box-shadow: 0px 0px 2px 1px;\n  background: #fff; }\n  .pie-wrapper .row {\n    margin: 0px; }\n  .pie-wrapper .field-wrapper {\n    width: 200px;\n    float: right;\n    margin-right: 10px; }\n"

/***/ }),

/***/ "./src/app/components/library-management/dashboard/dashboard.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DashboardComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_library_master_masters_service__ = __webpack_require__("./src/app/services/library/master/masters.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_highcharts_highcharts__ = __webpack_require__("./node_modules/highcharts/highcharts.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_highcharts_highcharts___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_highcharts_highcharts__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var DashboardComponent = /** @class */ (function () {
    function DashboardComponent(masterService) {
        this.masterService = masterService;
        this.isDataLoaded = false;
    }
    DashboardComponent.prototype.ngOnInit = function () {
        this.fetchDashboard();
    };
    DashboardComponent.prototype.fetchDashboard = function () {
        var _this = this;
        this.masterService.fetchDashboardMonitor().subscribe(function (res) {
            _this.isDataLoaded = true;
            var result;
            result = res;
            _this.generateChartData(result.response);
        }, function (err) {
            _this.isDataLoaded = false;
        });
    };
    DashboardComponent.prototype.generateChartData = function (res) {
        var obj = {
            total_added_books: res.total_added_books,
            total_available_books: res.total_available_books,
            total_issued_books: res.total_issued_books,
            total_lost_books: res.total_lost_books,
            total_overdued_books: res.total_overdued_books,
            total_scrapped_books: res.total_scrapped_books
        };
        this.createChart(obj);
    };
    DashboardComponent.prototype.createChart = function (obj) {
        __WEBPACK_IMPORTED_MODULE_2_highcharts_highcharts__["chart"]('pieContainer', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie',
                options3d: {
                    enabled: true,
                    alpha: 45,
                    beta: 0
                }
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: '<span style="color:{series.color}">●</span> Books: <b>  {point.y} </b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '{y}'
                    },
                    showInLegend: true
                }
            },
            series: [{
                    // name: 'Payment Mode',
                    colorByPoint: true,
                    data: [
                        // {
                        // name: 'total',
                        // y: obj.total_added_books,
                        // sliced: true,
                        // selected: true
                        // },
                        {
                            name: 'Available',
                            y: obj.total_available_books,
                            sliced: true,
                            selected: true
                        },
                        {
                            name: 'Issued',
                            y: obj.total_issued_books,
                            sliced: true
                        },
                        {
                            name: 'Lost',
                            y: obj.total_lost_books,
                            sliced: true
                        },
                        {
                            name: 'Overdue',
                            y: obj.total_overdued_books,
                            sliced: true
                        },
                        {
                            name: 'Scrapped',
                            y: obj.total_scrapped_books,
                            sliced: true
                        }
                    ]
                }]
        });
    };
    DashboardComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-dashboard',
            template: __webpack_require__("./src/app/components/library-management/dashboard/dashboard.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/dashboard/dashboard.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_library_master_masters_service__["a" /* MastersService */]])
    ], DashboardComponent);
    return DashboardComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/issue-book/issue-book.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n<section class=\"main_container\">\r\n  <section *ngIf=\"!bookSuggestion\">\r\n    <div class=\"search_bar_container\">\r\n      <input type=\"text\" name=\"\" value=\"\" placeholder=\"Search Book\" class=\"search_box\"  (keyup)=\"searchInList($event)\" [(ngModel)]=\"searchInput\">\r\n      <i class=\"fa fa-search\" aria-hidden=\"true\"></i>\r\n      <i class=\"fa fa-sort-desc\" aria-hidden=\"true\" (click)=\"showFilter()\"></i>\r\n\r\n      <!-- <span *ngIf=\"!searchResult\">&#8701; Search here! </span> -->\r\n    </div>\r\n\r\n    <!-- FILTER -->\r\n    <div class=\"search_box_filter_container\" *ngIf=\"filter\" (click)=\"closeBookTitleSuggestion()\">\r\n\r\n      <div class=\"filter_item\">\r\n        <div class=\"label_container\">\r\n          <span style=\"top: 10px;\">Book Title</span>\r\n        </div>\r\n        <div class=\"input_container\">\r\n          <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Book Name\" [(ngModel)]=\"searchTitle\" (keyup)=\"searchInBookList($event)\">\r\n          <div class=\"book_suggestion_container\" *ngIf=\"bookSuggestionForTitle\">\r\n            <div class=\"book_suggestion_item\" *ngFor=\"let book of bookSuggestionListForTitle let i = index\">\r\n              <div class=\"name_container\" (click)=\"selectBookForAdvanceSearch(book.title)\">\r\n                <span>{{book.title}}</span>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"filter_item\">\r\n        <div class=\"label_container\">\r\n          <span>Author</span>\r\n        </div>\r\n        <div class=\"input_container\">\r\n          <select class=\"add_input1\" name=\"\" [(ngModel)]=\"searchAuthorId\">\r\n            <option value=\"-1\" style=\"color: #cfcfcf;\">Select Author Name</option>\r\n            <option [value]=\"author.author_id\" *ngFor=\"let author of authorList let i = index\">{{author.author_name}}</option>\r\n          </select>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"filter_item\">\r\n        <div class=\"label_container\">\r\n          <span>Category</span>\r\n        </div>\r\n        <div class=\"input_container\">\r\n          <select class=\"add_input1\" name=\"\" (ngModelChange)=\"getSubCategory($event)\" [(ngModel)]=\"searchCategoryId\">\r\n            <option value=\"-1\" style=\"color: #cfcfcf;\">Select Category Name</option>\r\n            <option [value]=\"category.category_id\" [attr.id]=\"category.category_id\" *ngFor=\"let category of categoryList let i = index\">{{category.category_name}}</option>\r\n          </select>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"filter_item\">\r\n        <div class=\"label_container\">\r\n          <span>Sub-Category</span>\r\n        </div>\r\n        <div class=\"input_container\">\r\n          <select class=\"add_input1\" name=\"\" [(ngModel)]=\"searchSubcategoryId\">\r\n            <option value=\"-1\" style=\"color: #cfcfcf;\">Select Sub-Category Name</option>\r\n            <option [value]=\"subCategory.category_id\" *ngFor=\"let subCategory of subcategoryList let i = index\">{{subCategory.category_name}}</option>\r\n          </select>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"filter_item\">\r\n        <div class=\"label_container\">\r\n          <span>Subject</span>\r\n        </div>\r\n        <div class=\"input_container\">\r\n          <select class=\"add_input1\" name=\"\" [(ngModel)]=\"searchSubjectId\">\r\n            <option value=\"-1\" style=\"color: #cfcfcf;\">Select Subject Name</option>\r\n            <option [value]=\"subject.subject_id\" *ngFor=\"let subject of subjectList let i = index\">{{subject.subject_name}}</option>\r\n          </select>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"filter_item\">\r\n        <div class=\"label_container\">\r\n          <span>Publication</span>\r\n        </div>\r\n        <div class=\"input_container\">\r\n          <select class=\"add_input1\" name=\"\" [(ngModel)]=\"searchPublicationId\">\r\n            <option value=\"-1\" style=\"color: #cfcfcf;\">Select Publication Name</option>\r\n            <option [value]=\"publication.publication_id\" *ngFor=\"let publication of publicationList let i = index\">{{publication.publication_name}}</option>\r\n          </select>\r\n        </div>\r\n      </div>\r\n\r\n\r\n      <div class=\"filter_item\">\r\n        <div class=\"label_container\">\r\n          <span>Language</span>\r\n        </div>\r\n        <div class=\"input_container\">\r\n          <select class=\"add_input2\" name=\"\" [(ngModel)]=\"searchLangId\">\r\n            <option value=\"-1\" style=\"color: #cfcfcf;\">Select Language</option>\r\n            <option [value]=\"language.language_id\" *ngFor=\"let language of languageList let i = index\">{{language.language_name}}</option>\r\n          </select>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"action_btn_container pull-right\">\r\n        <button type=\"button\" name=\"button\" class=\"reset_btn\" (click)=\"resetFilter()\">Reset</button>\r\n        <button type=\"button\" name=\"button\" class=\"search_btn\" (click)=\"advanceSearch()\">Search</button>\r\n      </div>\r\n\r\n    </div>\r\n\r\n    <!-- Suggestion -->\r\n    <div class=\"suggestions_container\" *ngIf=\"suggestion\" (click)=\"closeSuggestionAndFilter()\">\r\n      <div class=\"suggestion\">\r\n        <div class=\"suggestion_item\" *ngFor=\"let suggestion of suggestionList let i = index\" (click)=\"selectBookForIssue(suggestion.book_id)\">\r\n          <div class=\"img_container\">\r\n            <img src=\"./assets/images/library/gray_book.svg\" alt=\"\">\r\n          </div>\r\n          <div class=\"book_details\">\r\n            <div class=\"name_container\">\r\n              <span>{{suggestion.title}}</span>\r\n            </div>\r\n            <div class=\"book_more_info\">\r\n              <span>Publication - {{ suggestion.publications.publication_name | slice:0:12 }}</span>\r\n              <span>&nbsp;&nbsp;|&nbsp;&nbsp;</span>\r\n              <span>Author(s) - <span *ngFor=\"let author of suggestion.authorObjects | slice:0:1;\">{{author.author_name | slice:0:12}} <span *ngIf=\"suggestion?.authorObjects?.length > 1\">...</span></span></span>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <!-- <div style=\"text-align: center; font-weight: 600;\" *ngIf=\"suggestionList.length == 0\">\r\n          <span>No result found!</span>\r\n        </div> -->\r\n      </div>\r\n    </div>\r\n\r\n  </section>\r\n\r\n  <section *ngIf=\"!searchResult && !bookSuggestion\">\r\n    <div class=\"illustartion_container\" (click)=\"closeSuggestionAndFilter()\">\r\n      <img src=\"./assets/images/library/search_book.svg\" alt=\"\">\r\n    </div>\r\n  </section>\r\n\r\n  <hr *ngIf=\"searchResult\">\r\n\r\n  <section *ngIf=\"searchResult\" (click)=\"closeSuggestionAndFilter()\">\r\n    <div class=\"search_result_container\">\r\n      <div class=\"header_container\">\r\n        <div class=\"header_item1\">\r\n          <span>Book Title</span>\r\n        </div>\r\n        <div class=\"header_item\">\r\n          <span>ISBN No.</span>\r\n        </div>\r\n        <div class=\"header_item1\">\r\n          <span>Publication</span>\r\n        </div>\r\n        <div class=\"header_item1\">\r\n          <span>Author</span>\r\n        </div>\r\n        <div class=\"header_item\">\r\n          <span>Available</span>\r\n        </div>\r\n        <div class=\"header_item\">\r\n          <span>Issued</span>\r\n        </div>\r\n        <div class=\"header_item\">\r\n          <span>Lost/Scrap</span>\r\n        </div>\r\n        <div class=\"header_item\" style=\"text-align: right;\">\r\n          <span>Actions</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"value_container\" *ngFor=\"let book of bookSearchData\" [ngClass]=\"book.totalBooksAvailable != 0 ? 'border_div' : 'non_border_div'\">\r\n        <div class=\"value_item1\">\r\n          <span>{{book.title}}</span>\r\n        </div>\r\n        <div class=\"value_item\">\r\n          <span>{{book.isbn_number}}</span>\r\n        </div>\r\n        <div class=\"value_item1\">\r\n          <span>{{book.publications.publication_name | slice:0:25}}</span>\r\n        </div>\r\n        <div class=\"value_item1\">\r\n          <span title=\"{{concatString(book.authorObjects)}}\">\r\n            <span *ngFor=\"let author of book.authorObjects | slice:start:end let i = index\">\r\n              <span *ngIf=\"i < 2\">{{author.author_name | slice:0:10}}<span *ngIf=\"book.authorObjects?.length > 1 && i < 2\">,&nbsp;</span>\r\n                <span *ngIf=\"i < 3 && i == 1\">...</span>\r\n              </span>\r\n            </span>\r\n          </span>\r\n          <!-- <span *ngFor=\"let author of book.authorObjects | slice:0:book.authorObjects.length >= 1 ? 2 : 1\">{{author.author_name | slice:0:10}},&nbsp; </span> -->\r\n        </div>\r\n        <div class=\"value_item\">\r\n          <span>{{book.totalBooksAvailable}} of {{book.totalBooksAdded}}</span>\r\n        </div>\r\n        <div class=\"value_item\">\r\n          <span>{{book.totalBooksIssued}}</span>\r\n        </div>\r\n        <div class=\"value_item\">\r\n          <span>{{book.totalBooksLost}}</span>\r\n        </div>\r\n        <div class=\"value_item\" style=\"text-align: right;display: block;\">\r\n          <img src=\"./assets/images/library/issue_gray.svg\" alt=\"non issue\" class=\"action_img\" title=\"Issue Book\" (click)=\"showIssueBookPopup(book)\" *ngIf=\"book.totalBooksAvailable != 0\">\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <section class=\"for_book_details\" *ngIf=\"bookSuggestion\" (click)=\"closeSuggestionAndFilter()\">\r\n    <div class=\"book_details_container\" (click)=\"closeSuggestionAndFilter()\">\r\n\r\n      <div class=\"book_details_item_1\">\r\n        <img src=\"./assets/images/library/color_book.svg\" alt=\"\" class=\"book_icon\">\r\n        <div class=\"book_name_container\">\r\n          <span class=\"title\">Book Title</span>\r\n          <span class=\"book_name\">{{bookDataForIssue.title}}</span>\r\n        </div>\r\n        <div class=\"book_isbn\">\r\n          <span class=\"title\">ISBN No.</span>\r\n          <span class=\"isbn_number\">{{bookDataForIssue.isbn_number}}</span>\r\n        </div>\r\n        <button type=\"button\" name=\"button\" class=\"available_btn\" *ngIf=\"bookDataForIssue.totalBooksAvailable != 0\">Available : {{bookDataForIssue.totalBooksAvailable}}</button>\r\n        <button type=\"button\" name=\"button\" class=\"not_available_btn\" *ngIf=\"bookDataForIssue.totalBooksAvailable == 0\">Not Available</button>\r\n      </div>\r\n\r\n      <div class=\"book_details_item_2\">\r\n        <div class=\"book_more_info_item_1\">\r\n          <span class=\"title\">Author</span>\r\n          <span title=\"{{concatAuthorList(bookDataForIssue.authorObjects)}}\">\r\n            <span class=\"more_info_value\" *ngFor=\"let author of bookDataForIssue.authorObjects | slice:start:end let p = index;\">\r\n              <span *ngIf=\"p < 2\">{{author.author_name | slice:0:10}}<span *ngIf=\"bookDataForIssue?.authorObjects?.length > 1\">,&nbsp;</span><span *ngIf=\"p < 3 && p == 1\">...</span>\r\n\r\n              </span>\r\n             </span>\r\n          </span>\r\n        </div>\r\n        <div class=\"book_more_info_item_1\">\r\n          <span class=\"title\">Publication</span>\r\n          <span class=\"more_info_value\">{{bookDataForIssue.publications.publication_name | slice:0:25}}</span>\r\n        </div>\r\n        <div class=\"book_more_info_item_2\">\r\n          <span class=\"title\">Category</span>\r\n          <span class=\"more_info_value\">{{bookDataForIssue.category.category_name}}</span>\r\n        </div>\r\n        <div class=\"book_more_info_item_2\">\r\n          <span class=\"title\">Sub-Category</span>\r\n          <span class=\"more_info_value\" *ngIf=\"bookDataForIssue.sub_category != null\">{{bookDataForIssue.sub_category.category_name}}</span>\r\n        </div>\r\n        <div class=\"book_more_info_item_2\">\r\n          <span class=\"title\">Subject</span>\r\n          <span class=\"more_info_value\">{{bookDataForIssue.subject.subject_name}}</span>\r\n        </div>\r\n        <div class=\"book_more_info_item_2\">\r\n          <span class=\"title\">Language</span>\r\n          <span class=\"more_info_value\">{{bookDataForIssue.language.language_name}}</span>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"book_details_item_3\">\r\n        <div class=\"search_box_container\">\r\n          <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Borrower Name/Mobile Number \" class=\"search_box\"  (keyup)=\"searchBorrower($event)\" [(ngModel)]=\"borrower\">\r\n          <div class=\"bor_suggestions_container\" *ngIf=\"borSuggestions\">\r\n            <div class=\"suggestion\">\r\n              <div class=\"suggestion_item\" *ngFor=\"let borrower of borrowerSearchData\" (click)=\"selectStudent(borrower)\">\r\n                <div class=\"img_container\">\r\n                  <img src=\"./assets/images/library/profile.svg\" alt=\"\">\r\n                </div>\r\n                <div class=\"book_details\">\r\n                  <div class=\"name_container\">\r\n                    <span>{{borrower.student_name}}</span>\r\n                  </div>\r\n                  <div class=\"book_more_info\">\r\n                    <span>Mobile No. - {{borrower.student_phone}}</span>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"book_in_hand_container\" *ngIf=\"booksInHandStatus\">\r\n          <span *ngIf=\"bookInHand != 0\">Books in hand : <span style=\"font-weight: 600;\">{{bookInHand}}</span></span>\r\n          <span *ngIf=\"bookInHand == 0\">No books in hand!</span>\r\n        </div>\r\n\r\n        <div class=\"books_in_hand_details_container\" *ngIf=\"booksInHandStatus\">\r\n          <div class=\"books_in_hand_details_item\" *ngFor=\"let book of booksInHandDetails\">\r\n            <div class=\"item_container\">\r\n              <img src=\"./assets/images/library/color_book.svg\" alt=\"\" class=\"book_icon\">\r\n              <div class=\"book_name_container\">\r\n                <span class=\"title\">Book Title</span>\r\n                <span class=\"book_name\">{{book.book_complete_details.title}}</span>\r\n              </div>\r\n              <div class=\"issue_date\">\r\n                <span class=\"title\">Issued Date</span>\r\n                <span class=\"book_name\">{{book.issued_book.issued_on | date: 'dd MMM yyyy'}}</span>\r\n              </div>\r\n              <div class=\"return_date\">\r\n                <span class=\"title\">Return Date</span>\r\n                <span class=\"book_name\">{{book.issued_book.to_return_on_date | date: 'dd MMM yyyy'}}</span>\r\n              </div>\r\n              <div class=\"book_status_container\">\r\n                <button type=\"button\" name=\"button\" class=\"issued_btn\" *ngIf=\"book.issued_book.no_of_late_days == 0\">Issued</button>\r\n                <button type=\"button\" name=\"button\" class=\"overdue_btn\" *ngIf=\"book.issued_book.no_of_late_days != 0\">Overdue</button>\r\n              </div>\r\n            </div>\r\n            <!-- <div class=\"action_container\">\r\n              <img src=\"./assets/images/library/issue_btn.svg\" alt=\"\" class=\"book_icon\" (click)=\"returnBook(book)\">\r\n            </div> -->\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n\r\n      <div class=\"book_details_item_4\">\r\n        <div class=\"date_container\">\r\n          <div class=\"from_date\">\r\n            <span>From</span>\r\n            <input type=\"text\" name=\"\" value=\"\" placeholder=\"\" readonly [(ngModel)]=\"tempFromDate\" (click)=\"openCalendar('bookFromDate')\">\r\n            <i class=\"fa fa-calendar\" style=\"cursor: pointer;color: #1283f4;\" (click)=\"openCalendar('bookFromDate')\"></i>\r\n\r\n            <input  type=\"text\" value=\"\" id=\"bookFromDate\" class=\"widgetDatepicker bsDatepicker\" name=\"bookFromDate\"\r\n             [(ngModel)]=\"bookFromDate\" (ngModelChange)=\"selectBookFromDate($event)\" readonly=\"true\" bsDatepicker  style=\"width:0px;margin-right: 10px;\"/>\r\n          </div>\r\n          <div class=\"to_date\">\r\n            <span>To</span>\r\n            <input type=\"text\" name=\"\" value=\"\" placeholder=\"\" readonly [(ngModel)]=\"tempToDate\">\r\n            <!-- <div class=\"questionInfo inline-relative\">\r\n              <span class=\"qInfoIcon i-class\">i</span>\r\n              <div class=\"tooltip-box-field\">\r\n                Enable this to\r\n                <br> start sending SMS\r\n              </div>\r\n            </div> -->\r\n            <!-- <i class=\"fa fa-calendar\" style=\"cursor: pointer;color: #1283f4;\" (click)=\"openCalendar('bookToDate')\"></i> -->\r\n\r\n            <!-- <input  type=\"text\" value=\"\" id=\"bookToDate\" class=\"widgetDatepicker bsDatepicker\" name=\"bookToDate\" -->\r\n             <!-- [(ngModel)]=\"bookToDate\" (ngModelChange)=\"selectBookToDate($event)\" readonly=\"true\" bsDatepicker  style=\"width:0px;margin-right: 10px;\"/> -->\r\n          </div>\r\n        </div>\r\n        <!-- <div class=\"notify_container\">\r\n          <div class=\"field-checkbox-wrapper checkbox_container\">\r\n            <input type=\"checkbox\" value=\"\" name=\"notify\" class=\"form-checkbox\">\r\n            <label for=\"notify\">Notify to Student</label>\r\n          </div>\r\n          <div class=\"field-checkbox-wrapper checkbox_container\">\r\n            <input type=\"checkbox\" value=\"\" name=\"download\" class=\"form-checkbox\">\r\n            <label for=\"download\">Download Receipt</label>\r\n          </div>\r\n        </div> -->\r\n      </div>\r\n\r\n      <div class=\"book_details_item_5\">\r\n        <div class=\"left_side\">\r\n          <button type=\"button\" name=\"button\" class=\"back_btn\" (click)=\"showSearchResult()\">Back</button>\r\n        </div>\r\n        <div class=\"right_side\">\r\n          <button type=\"button\" name=\"button\" class=\"cancel_btn\" (click)=\"clearResult()\">Clear</button>\r\n          <button type=\"button\" name=\"button\" class=\"issue_btn\" (click)=\"issueBook()\" [disabled]=\"multiClickDisabled\">Issue</button>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </section>\r\n\r\n</section>\r\n\r\n<div class=\"row filter-res pagination\" #pager id=\"pager\" style=\"width: 100%;\" *ngIf=\"!bookSuggestion\">\r\n  <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n    <pagination (goPage)=\"fectchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\"\r\n      [pagesToShow]=\"10\" [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [sizeArr]=\"sizeArr\"\r\n      (sizeChange)=\"updateTableBatchSize($event)\" [count]=\"totalCount\">\r\n    </pagination>\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./src/app/components/library-management/issue-book/issue-book.component.scss":
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n.main_container {\n  height: 100%;\n  min-height: -webkit-fill-available;\n  min-height: -moz-available;\n  min-height: stretch; }\n.search_bar_container {\n  position: relative;\n  margin-left: 2%; }\n.search_bar_container .search_box {\n    height: 35px;\n    width: 420px;\n    border: 1px solid #dcdcdc;\n    background: white;\n    border-radius: 4px;\n    padding-left: 32px;\n    padding-right: 18px; }\n.search_bar_container .fa-search {\n    position: absolute;\n    left: 1px;\n    top: 1px;\n    padding: 9px;\n    color: #9b9b9b;\n    background: white;\n    border-radius: 4px; }\n.search_bar_container .fa-search:hover {\n    color: black; }\n.search_bar_container .fa-sort-desc {\n    position: absolute;\n    left: 385px;\n    top: 8px;\n    background: white;\n    cursor: pointer;\n    padding-left: 10px; }\n.search_bar_container span {\n    font-family: 'Nanum Pen Script';\n    font-size: 18px;\n    margin-left: 10px; }\n::ng-deep bs-datepicker-container, bs-daterangepicker-container {\n  left: 160px !important; }\n.search_box_filter_container {\n  margin-left: 2%;\n  width: 420px;\n  border-radius: 4px;\n  background: white;\n  -webkit-box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.27);\n          box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.27);\n  margin-top: 4px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  padding: 16px 26px;\n  position: fixed;\n  z-index: 1000; }\n.search_box_filter_container .filter_item {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    width: 100%;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between;\n    margin-bottom: 10px; }\n.search_box_filter_container .filter_item .label_container {\n      width: 25%;\n      color: #3a3a3a;\n      text-align: left;\n      position: relative; }\n.search_box_filter_container .filter_item .label_container span {\n        position: absolute;\n        top: 5px;\n        font-size: 12px; }\n.search_box_filter_container .filter_item .input_container {\n      width: 70%; }\n.search_box_filter_container .filter_item .input_container input {\n        border-bottom: 1px solid #9b9b9b;\n        padding: 10px;\n        padding-bottom: 3px;\n        padding-left: 0px;\n        width: 100%;\n        color: #3a3a3a;\n        font-size: 12px;\n        line-height: 1.36;\n        letter-spacing: normal;\n        font-weight: normal; }\n.search_box_filter_container .filter_item .input_container ::-webkit-input-placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: #cfcfcf; }\n.search_box_filter_container .filter_item .input_container :-ms-input-placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: #cfcfcf; }\n.search_box_filter_container .filter_item .input_container ::-ms-input-placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: #cfcfcf; }\n.search_box_filter_container .filter_item .input_container ::placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: #cfcfcf; }\n.search_box_filter_container .filter_item .input_container select {\n        border-bottom: 1px solid #9b9b9b;\n        padding-bottom: 3px;\n        padding-left: 0px;\n        width: 100%;\n        color: #3a3a3a;\n        font-size: 12px;\n        line-height: 1.36;\n        letter-spacing: normal;\n        font-weight: normal; }\n.search_box_filter_container .filter_item .input_container select option {\n        color: #3a3a3a; }\n.search_box_filter_container .filter_item .input_container option:first-child {\n        color: #cfcfcf !important; }\n.search_box_filter_container .filter_item .input_container input:focus {\n        border-bottom: 1px solid #1283f4; }\n.search_box_filter_container .filter_item .input_container select:focus {\n        border-bottom: 1px solid #1283f4; }\n.search_box_filter_container .filter_item .input_container .book_suggestion_container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        width: 19%;\n        margin-top: 5px;\n        border-radius: 4px;\n        position: fixed;\n        background: white;\n        -webkit-box-shadow: 0px 3px 15px rgba(0, 0, 0, 0.16);\n                box-shadow: 0px 3px 15px rgba(0, 0, 0, 0.16);\n        height: 200px;\n        overflow-y: scroll; }\n.search_box_filter_container .filter_item .input_container .book_suggestion_container .book_suggestion_item {\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: horizontal;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: row;\n                  flex-direction: row;\n          width: 100%;\n          padding: 8px;\n          color: #585574; }\n.search_box_filter_container .filter_item .input_container .book_suggestion_container .book_suggestion_item .name_container {\n            font-size: 13px;\n            width: 100%;\n            cursor: pointer; }\n.search_box_filter_container .filter_item .input_container .book_suggestion_container .book_suggestion_item:hover {\n          color: #ffffff;\n          background: #1283f4; }\n.search_box_filter_container .action_btn_container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: end;\n        -ms-flex-pack: end;\n            justify-content: flex-end;\n    margin-top: 10px; }\n.search_box_filter_container .action_btn_container .reset_btn {\n      margin-right: 10px;\n      padding: 6px 15px;\n      border-radius: 4px;\n      border: 1px solid #585574;\n      color: #585574;\n      text-align: center;\n      background: white; }\n.search_box_filter_container .action_btn_container .search_btn {\n      padding: 6px 15px;\n      border-radius: 4px;\n      border: 1px solid #1283f4;\n      color: white;\n      background: #1283f4;\n      text-align: center; }\n.suggestions_container {\n  background: white;\n  border-radius: 4px;\n  height: 200px;\n  max-height: 200px;\n  min-height: 200px;\n  overflow-y: auto;\n  -webkit-box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.27);\n          box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.27);\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  margin-left: 2%;\n  width: 420px;\n  margin-top: 4px;\n  position: fixed; }\n.suggestions_container .suggestion {\n    padding: 10px; }\n.suggestions_container .suggestion .suggestion_item {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      margin-bottom: 10px;\n      cursor: pointer; }\n.suggestions_container .suggestion .suggestion_item .img_container {\n        width: 10%;\n        padding: 6px; }\n.suggestions_container .suggestion .suggestion_item .book_details {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column; }\n.suggestions_container .suggestion .suggestion_item .book_details .name_container {\n          color: #585574;\n          font-size: 12px; }\n.suggestions_container .suggestion .suggestion_item .book_details .book_more_info {\n          color: #9b9b9b;\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: horizontal;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: row;\n                  flex-direction: row;\n          font-size: 12px;\n          margin-top: 5px; }\nhr {\n  margin-top: 10px;\n  margin-bottom: 10px;\n  border: 0;\n  border-top: 1px solid #eee;\n  width: 96%;\n  margin-left: 2%; }\n.widgetDatepicker {\n  position: absolute;\n  margin-left: 10%;\n  width: 1px;\n  visibility: hidden;\n  opacity: 0; }\n.bsDatepicker {\n  padding: 5px;\n  width: 100%;\n  position: absolute;\n  left: 80px; }\n.illustartion_container {\n  width: 100%; }\n.illustartion_container img {\n    max-height: 70%;\n    max-width: 27%;\n    margin-left: 30%; }\n.search_result_container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 96%;\n  margin-left: 2%;\n  margin-right: 2%; }\n.search_result_container .header_container {\n    width: 100%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    padding: 10px 0px;\n    padding-top: 0px;\n    padding-left: 16px;\n    padding-right: 10px;\n    font-size: 13px; }\n.search_result_container .header_container .header_item, .search_result_container .header_container .header_item1 {\n      color: #9898a3;\n      font-weight: 600;\n      text-align: left;\n      width: 10%; }\n.search_result_container .header_container .header_item1 {\n      width: 16%; }\n.search_result_container .value_container {\n    width: 100%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    padding: 5px 10px;\n    -webkit-box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.16);\n            box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.16);\n    border-radius: 6px;\n    background: white;\n    font-size: 13px;\n    border-left: 6px solid #9b9b9b;\n    margin-bottom: 10px; }\n.search_result_container .value_container .value_item, .search_result_container .value_container .value_item1 {\n      color: #585574;\n      text-align: left;\n      width: 10%;\n      /* Firefox */\n      display: -moz-box;\n      -moz-box-align: center;\n      /* Safari, Opera, and Chrome */\n      display: -webkit-box;\n      -webkit-box-align: center;\n      /* W3C */ }\n.search_result_container .value_container .value_item1 {\n      width: 16%; }\n.search_result_container .value_container .action_img {\n      cursor: pointer;\n      width: 25px;\n      height: 25px; }\n.search_result_container .border_div {\n    border-left: 6px solid #04bb11; }\n.search_result_container .non_border_div {\n    height: 38px;\n    border-left: 6px solid #9b9b9b; }\n.for_book_details {\n  background: white;\n  border-radius: 6px;\n  -webkit-box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.16);\n          box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.16); }\n.for_book_details .book_details_container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    width: 100%; }\n.for_book_details .book_details_container .book_details_item_1 {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      border-bottom: 1px solid #DDDDDD;\n      padding: 10px 15px; }\n.for_book_details .book_details_container .book_details_item_1 .book_icon {\n        width: 25px;\n        height: 25px; }\n.for_book_details .book_details_container .book_details_item_1 .book_name_container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        margin-left: 5px;\n        width: auto;\n        min-width: 20%; }\n.for_book_details .book_details_container .book_details_item_1 .book_name_container .title {\n          font-size: 12px;\n          font-weight: normal;\n          font-style: normal;\n          text-align: left;\n          color: #9b9b9b; }\n.for_book_details .book_details_container .book_details_item_1 .book_name_container .book_name {\n          font-size: 14px;\n          font-weight: 600;\n          font-style: normal;\n          text-align: left;\n          color: #585574; }\n.for_book_details .book_details_container .book_details_item_1 .book_isbn {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        width: 20%;\n        margin-left: 15px; }\n.for_book_details .book_details_container .book_details_item_1 .book_isbn .title {\n          font-size: 12px;\n          font-weight: normal;\n          font-style: normal;\n          text-align: left;\n          color: #9b9b9b; }\n.for_book_details .book_details_container .book_details_item_1 .book_isbn .isbn_number {\n          font-size: 12px;\n          font-weight: 600;\n          font-style: normal;\n          text-align: left;\n          color: #585574; }\n.for_book_details .book_details_container .book_details_item_1 .available_btn {\n        background: #cdffd1;\n        border: 1px solid #04bb11;\n        border-radius: 4px;\n        color: #434343;\n        padding: 1px 10px;\n        height: 20px;\n        font-size: 12px;\n        cursor: normal; }\n.for_book_details .book_details_container .book_details_item_1 .not_available_btn {\n        background: #f9f9f9;\n        border: 1px solid #b0b0b0;\n        border-radius: 4px;\n        color: #b0b0b0;\n        padding: 1px 10px;\n        height: 20px;\n        font-size: 12px;\n        cursor: normal; }\n.for_book_details .book_details_container .book_details_item_2 {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      border-bottom: 1px solid #DDDDDD;\n      padding: 10px 15px; }\n.for_book_details .book_details_container .book_details_item_2 .title {\n        font-size: 12px;\n        font-weight: normal;\n        font-style: normal;\n        text-align: left;\n        color: #9b9b9b; }\n.for_book_details .book_details_container .book_details_item_2 .book_more_info_item_1 {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        width: 20%; }\n.for_book_details .book_details_container .book_details_item_2 .book_more_info_item_1 .more_info_value {\n          font-size: 12px;\n          font-weight: normal;\n          font-style: normal;\n          text-align: left;\n          color: #585574; }\n.for_book_details .book_details_container .book_details_item_2 .book_more_info_item_2 {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        width: 15%; }\n.for_book_details .book_details_container .book_details_item_2 .book_more_info_item_2 .more_info_value {\n          font-size: 12px;\n          font-weight: normal;\n          font-style: normal;\n          text-align: left;\n          color: #585574; }\n.for_book_details .book_details_container .book_details_item_3 {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      border-bottom: 1px solid #DDDDDD;\n      padding: 10px 15px; }\n.for_book_details .book_details_container .book_details_item_3 .search_box_container .search_box {\n        height: 35px;\n        width: 310px;\n        border: 1px solid #dcdcdc;\n        background: white;\n        border-radius: 4px;\n        padding-left: 10px; }\n.for_book_details .book_details_container .book_details_item_3 .book_in_hand_container {\n        text-align: left;\n        width: 34%;\n        padding-left: 20px;\n        padding-top: 10px;\n        color: #585574; }\n.for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        width: 40%; }\n.for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container .books_in_hand_details_item {\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: horizontal;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: row;\n                  flex-direction: row;\n          background: #f2f9ff;\n          border: 1px solid #d4eaff;\n          border-radius: 4px;\n          margin-bottom: 5px; }\n.for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container .books_in_hand_details_item .item_container {\n            display: -webkit-box;\n            display: -ms-flexbox;\n            display: flex;\n            -webkit-box-orient: horizontal;\n            -webkit-box-direction: normal;\n                -ms-flex-direction: row;\n                    flex-direction: row;\n            padding: 10px;\n            width: 94%;\n            -webkit-box-pack: start;\n                -ms-flex-pack: start;\n                    justify-content: flex-start; }\n.for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container .books_in_hand_details_item .action_container {\n            padding: 10px;\n            border-left: 1px solid #d4eaff; }\n.for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container .books_in_hand_details_item .book_icon {\n            width: 25px;\n            height: 25px; }\n.for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container .books_in_hand_details_item .book_name_container {\n            display: -webkit-box;\n            display: -ms-flexbox;\n            display: flex;\n            -webkit-box-orient: vertical;\n            -webkit-box-direction: normal;\n                -ms-flex-direction: column;\n                    flex-direction: column;\n            margin-left: 5px;\n            width: 35%; }\n.for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container .books_in_hand_details_item .issue_date, .for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container .books_in_hand_details_item .return_date {\n            display: -webkit-box;\n            display: -ms-flexbox;\n            display: flex;\n            -webkit-box-orient: vertical;\n            -webkit-box-direction: normal;\n                -ms-flex-direction: column;\n                    flex-direction: column;\n            margin-left: 5px;\n            width: 20%; }\n.for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container .books_in_hand_details_item .book_status_container {\n            margin-top: 5px; }\n.for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container .books_in_hand_details_item .book_status_container .issued_btn {\n              cursor: default;\n              background: #dfefff;\n              border: 1px solid #1283f4;\n              padding: 3px 8px;\n              font-size: 12px;\n              font-weight: 400;\n              border-radius: 4px; }\n.for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container .books_in_hand_details_item .book_status_container .overdue_btn {\n              cursor: default;\n              background: #ffdfca;\n              border: 1px solid #ff6600;\n              padding: 3px 8px;\n              font-size: 12px;\n              font-weight: 400;\n              border-radius: 4px; }\n.for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container .books_in_hand_details_item .title {\n            font-size: 12px;\n            font-weight: normal;\n            font-style: normal;\n            text-align: left;\n            color: #9b9b9b; }\n.for_book_details .book_details_container .book_details_item_3 .books_in_hand_details_container .books_in_hand_details_item .book_name {\n            font-size: 12px;\n            font-weight: 600;\n            font-style: normal;\n            text-align: left;\n            color: #585574; }\n.for_book_details .book_details_container .book_details_item_3 .bor_suggestions_container {\n        background: white;\n        border-radius: 4px;\n        height: 200px;\n        max-height: 200px;\n        min-height: 200px;\n        overflow-y: auto;\n        -webkit-box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.27);\n                box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.27);\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        width: 310px;\n        margin-top: 4px;\n        position: fixed;\n        z-index: 100; }\n.for_book_details .book_details_container .book_details_item_3 .bor_suggestions_container .suggestion {\n          padding: 10px; }\n.for_book_details .book_details_container .book_details_item_3 .bor_suggestions_container .suggestion .suggestion_item {\n            display: -webkit-box;\n            display: -ms-flexbox;\n            display: flex;\n            -webkit-box-orient: horizontal;\n            -webkit-box-direction: normal;\n                -ms-flex-direction: row;\n                    flex-direction: row;\n            margin-bottom: 10px;\n            cursor: pointer; }\n.for_book_details .book_details_container .book_details_item_3 .bor_suggestions_container .suggestion .suggestion_item .img_container {\n              width: 10%;\n              padding: 6px; }\n.for_book_details .book_details_container .book_details_item_3 .bor_suggestions_container .suggestion .suggestion_item .book_details {\n              display: -webkit-box;\n              display: -ms-flexbox;\n              display: flex;\n              -webkit-box-orient: vertical;\n              -webkit-box-direction: normal;\n                  -ms-flex-direction: column;\n                      flex-direction: column;\n              margin-left: 10px; }\n.for_book_details .book_details_container .book_details_item_3 .bor_suggestions_container .suggestion .suggestion_item .book_details .name_container {\n                color: #585574;\n                font-size: 12px; }\n.for_book_details .book_details_container .book_details_item_3 .bor_suggestions_container .suggestion .suggestion_item .book_details .book_more_info {\n                color: #9b9b9b;\n                display: -webkit-box;\n                display: -ms-flexbox;\n                display: flex;\n                -webkit-box-orient: horizontal;\n                -webkit-box-direction: normal;\n                    -ms-flex-direction: row;\n                        flex-direction: row;\n                font-size: 11px;\n                margin-top: 5px; }\n.for_book_details .book_details_container .book_details_item_4 {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      padding: 10px 15px; }\n.for_book_details .book_details_container .book_details_item_4 .date_container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row; }\n.for_book_details .book_details_container .book_details_item_4 .date_container .from_date, .for_book_details .book_details_container .book_details_item_4 .date_container .to_date {\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: vertical;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: column;\n                  flex-direction: column;\n          width: 20%;\n          position: relative; }\n.for_book_details .book_details_container .book_details_item_4 .date_container .from_date span, .for_book_details .book_details_container .book_details_item_4 .date_container .to_date span {\n            color: #9b9b9b;\n            font-size: 12px; }\n.for_book_details .book_details_container .book_details_item_4 .date_container .from_date input, .for_book_details .book_details_container .book_details_item_4 .date_container .to_date input {\n            border-radius: 4px;\n            border: 1px solid #dddddd;\n            padding: 5px;\n            width: 50%; }\n.for_book_details .book_details_container .book_details_item_4 .date_container .from_date .fa-calendar, .for_book_details .book_details_container .book_details_item_4 .date_container .to_date .fa-calendar {\n            position: absolute;\n            top: 21px;\n            right: 54%; }\n.for_book_details .book_details_container .book_details_item_4 .notify_container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row; }\n.for_book_details .book_details_container .book_details_item_4 .notify_container .checkbox_container {\n          width: 20%;\n          margin-top: 10px; }\n.for_book_details .book_details_container .book_details_item_4 .notify_container .field-checkbox-wrapper .form-checkbox + label {\n          vertical-align: middle;\n          font-size: 12px;\n          display: inline-block; }\n.for_book_details .book_details_container .book_details_item_4 .notify_container .field-checkbox-wrapper .form-checkbox + label:after {\n          content: '';\n          width: 16px;\n          height: 16px;\n          border: 2px solid #ccc;\n          border-radius: 2px;\n          position: absolute;\n          left: 0;\n          top: 0; }\n.for_book_details .book_details_container .book_details_item_4 .notify_container .field-checkbox-wrapper .form-checkbox:checked + label:after {\n          border: 2px solid #0084f6; }\n.for_book_details .book_details_container .book_details_item_4 .notify_container .field-checkbox-wrapper .form-checkbox + label:before {\n          width: 1px;\n          height: 1px;\n          left: 8px;\n          top: 9px;\n          position: absolute;\n          content: '';\n          border-top: 0;\n          border-right: 0;\n          border-left: 2px solid transparent;\n          border-bottom: 2px solid transparent;\n          -webkit-transform: rotate(-45deg);\n                  transform: rotate(-45deg); }\n.for_book_details .book_details_container .book_details_item_4 .notify_container .field-checkbox-wrapper .form-checkbox:checked + label:before {\n          border-left: 2px solid #0084f6;\n          border-bottom: 2px solid #0084f6;\n          width: 12px;\n          height: 5px;\n          left: 2px;\n          top: 5px; }\n.for_book_details .book_details_container .book_details_item_4 .notify_container .field-checkbox-wrapper .form-checkbox:checked + label {\n          color: #0084f6; }\n.for_book_details .book_details_container .book_details_item_5 {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      -webkit-box-pack: justify;\n          -ms-flex-pack: justify;\n              justify-content: space-between;\n      padding: 10px 15px;\n      padding-top: 0px; }\n.for_book_details .book_details_container .book_details_item_5 .left_side .back_btn {\n        background: white;\n        border-radius: 4px;\n        border: 1px solid #1283f4;\n        padding: 8px 15px;\n        text-align: center;\n        color: #1283f4; }\n.for_book_details .book_details_container .book_details_item_5 .right_side {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        width: 15%;\n        -ms-flex-pack: distribute;\n            justify-content: space-around; }\n.for_book_details .book_details_container .book_details_item_5 .right_side .cancel_btn {\n          background: white;\n          border-radius: 4px;\n          border: 1px solid #1283f4;\n          padding: 8px 15px;\n          text-align: center;\n          color: #1283f4; }\n.for_book_details .book_details_container .book_details_item_5 .right_side .issue_btn {\n          background: #1283f4;\n          border-radius: 4px;\n          border: 1px solid #1283f4;\n          padding: 8px 15px;\n          text-align: center;\n          color: white;\n          font-weight: 600; }\ninput {\n  font-size: 12px; }\n.filter-res label {\n  font-size: 14px;\n  font-weight: 600; }\n.pagination .first:before {\n  content: \"« \";\n  font-size: 16px;\n  font-weight: 800; }\n.pagination .last:after {\n  content: \" »\";\n  font-size: 16px;\n  font-weight: 800; }\n.pagination .batch-size {\n  font-size: 16px;\n  font-weight: 800;\n  border-bottom: 1px solid black; }\n.pagination li {\n  border-right: 1px solid #ccc;\n  padding: 0 7px;\n  margin: 0;\n  line-height: 10px;\n  font-weight: 800;\n  cursor: pointer; }\n.pagination li a {\n    line-height: 10px;\n    font-size: 16px;\n    font-weight: 800;\n    border: none;\n    padding: 0 14px; }\n.pagination li:last-child {\n  border-right: 0;\n  padding-right: 0; }\n.pagination\n.batch-size\n.bulk-dropdown\n.bulk-dropbtn {\n  background: transparent !important; }\n"

/***/ }),

/***/ "./src/app/components/library-management/issue-book/issue-book.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return IssueBookComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_library_add_add_book_service__ = __webpack_require__("./src/app/services/library/add/add-book.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_library_issue_issue_book_service__ = __webpack_require__("./src/app/services/library/issue/issue-book.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_rxjs_add_observable_merge__ = __webpack_require__("./node_modules/rxjs/_esm5/add/observable/merge.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var IssueBookComponent = /** @class */ (function () {
    function IssueBookComponent(router, auth, commonService, appC, addBookService, issueBookService) {
        this.router = router;
        this.auth = auth;
        this.commonService = commonService;
        this.appC = appC;
        this.addBookService = addBookService;
        this.issueBookService = issueBookService;
        this.filter = false;
        this.searchResult = false;
        this.suggestion = false;
        this.bookSuggestion = false;
        this.borSuggestions = false;
        this.isRippleLoad = false;
        this.multiClickDisabled = false;
        this.hoverTitle = "";
        this.hoverTitleAuthor = "";
        this.searchTitle = "";
        this.searchCategoryId = '-1';
        this.searchSubcategoryId = '-1';
        this.searchSubjectId = '-1';
        this.searchPublicationId = '-1';
        this.searchAuthorId = '-1';
        this.searchLangId = '-1';
        this.booksInHandStatus = false;
        this.bookInHand = 0;
        this.bookSuggestionForTitle = false;
        // FOR PAGINATION
        this.pageIndex = 1;
        this.displayBatchSize = 20;
        this.totalCount = 0;
        this.sizeArr = [20, 50, 100, 150, 200, 500];
    }
    IssueBookComponent.prototype.ngOnInit = function () {
        this.tempFromDate = __WEBPACK_IMPORTED_MODULE_7_moment__(new Date()).format("DD MMM YYYY");
        this.getAllMasterData();
        this.getInstituteData();
    };
    IssueBookComponent.prototype.getInstituteData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.issueBookService.getInstituteSettingFromServer().subscribe(function (response) {
            _this.isRippleLoad = false;
            var res;
            res = response;
            _this.numberOfLateDaysWithoutFine = res.lib_issue_for_days;
            console.log(_this.numberOfLateDaysWithoutFine);
            _this.tempToDate = __WEBPACK_IMPORTED_MODULE_7_moment__(new Date()).add(_this.numberOfLateDaysWithoutFine, 'days').format("DD MMM YYYY");
        }, function (errorResponse) {
            _this.isRippleLoad = false;
            console.log(errorResponse);
        });
    };
    IssueBookComponent.prototype.getAllMasterData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.addBookService.getAllMasterData().subscribe(function (response) {
            _this.isRippleLoad = false;
            var res;
            res = response;
            console.log(response);
            var tempCatList = res.response.categories;
            _this.categoryList = res.response.categories;
            _this.subjectList = res.response.subjects;
            _this.publicationList = res.response.publications;
            _this.authorList = res.response.authors;
            _this.languageList = res.response.languages;
        }, function (errorResponse) {
            _this.isRippleLoad = false;
            console.log(errorResponse);
        });
    };
    IssueBookComponent.prototype.getSubCategory = function (ev) {
        var _this = this;
        this.isRippleLoad = true;
        this.addBookService.getSubCategories(ev).subscribe(function (response) {
            _this.isRippleLoad = false;
            var res;
            res = response;
            console.log(response);
            _this.subcategoryList = res.response;
        }, function (errorResponse) {
            _this.isRippleLoad = false;
            console.log(errorResponse);
        });
    };
    IssueBookComponent.prototype.searchInBookList = function (search_string) {
        var _this = this;
        this.isRippleLoad = true;
        this.issueBookService.getSearchedBooks(this.searchTitle).subscribe(function (response) {
            var res;
            res = response;
            _this.isRippleLoad = false;
            if (res.response.length > 0) {
                _this.bookSuggestionForTitle = true;
                _this.bookSuggestionListForTitle = res.response;
            }
            else {
                _this.bookSuggestionForTitle = false;
            }
        });
    };
    IssueBookComponent.prototype.closeBookTitleSuggestion = function () {
        this.bookSuggestionForTitle = false;
    };
    IssueBookComponent.prototype.selectBookForAdvanceSearch = function (title) {
        this.searchTitle = title;
        this.bookSuggestionForTitle = false;
    };
    IssueBookComponent.prototype.searchInList = function (search_string) {
        if (search_string.which <= 90 && search_string.which >= 48 || search_string.which == 8 || search_string.which == 13) {
            this.filter = false;
            this.suggestionList = [];
            if (this.searchInput != '') {
                this.getSearchData();
            }
            if (search_string.which == 13) {
                this.showSearchResult();
            }
        }
        if (this.searchInput == '' || this.searchInput == null) {
            this.suggestion = false;
            this.filter = false;
        }
    };
    IssueBookComponent.prototype.showFilter = function () {
        if (this.filter) {
            this.filter = false;
            return;
        }
        else {
            this.filter = true;
            this.suggestion = false;
            return;
        }
    };
    IssueBookComponent.prototype.searchBorrower = function (search_string) {
        if (search_string.which <= 90 && search_string.which >= 48 || search_string.which == 8) {
            this.selectedBorrowerId = "";
            this.getBorrowerData();
        }
        if (this.borrower.length == 0 || this.borrower == '' || this.borrower == null) {
            this.borSuggestions = false;
        }
    };
    IssueBookComponent.prototype.getBorrowerData = function () {
        var _this = this;
        this.issueBookService.getBorrowerData(this.borrower).subscribe(function (response) {
            _this.isRippleLoad = false;
            var res;
            res = response;
            if (res.response != null && res.response.length != 0) {
                console.log(response);
                _this.borSuggestions = true;
                _this.borrowerSearchData = res.response;
            }
            else {
                if (res.errorResponse[0].errorCode == 700) {
                    _this.messageHandler('error', 'Book alredy exists', '');
                }
            }
        });
    };
    IssueBookComponent.prototype.showSearchResult = function () {
        this.bookSuggestion = false;
        this.searchResult = true;
    };
    IssueBookComponent.prototype.getSearchData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.issueBookService.getSearchedBooks(this.searchInput).subscribe(function (response) {
            var res;
            res = response;
            _this.isRippleLoad = false;
            if (res.response.length > 0) {
                _this.suggestion = true;
                _this.suggestionList = res.response;
            }
            else {
                _this.suggestion = false;
            }
            // this.authorSuggestionList = res.response
        });
    };
    IssueBookComponent.prototype.advanceSearch = function () {
        var _this = this;
        this.filter = false;
        this.suggestion = false;
        var obj = {
            "by": [
                {
                    "column": "title",
                    "value": this.searchTitle
                },
                {
                    "column": "category_id",
                    "value": this.searchCategoryId
                },
                {
                    "column": "sub_category_id",
                    "value": this.searchSubcategoryId
                },
                {
                    "column": "subject_id",
                    "value": this.searchSubjectId
                },
                {
                    "column": "publication_id",
                    "value": this.searchPublicationId
                },
                {
                    "column": "language_id",
                    "value": this.searchLangId
                },
                {
                    "column": "author_id",
                    "value": this.searchAuthorId
                }
            ],
            // "sort": [
            //   {
            //     "column": "updated",
            //     "assending" : false
            //   }
            // ],
            "pageNo": this.pageIndex,
            "noOfRecords": this.displayBatchSize
        };
        // console.log(obj);
        this.isRippleLoad = true;
        this.issueBookService.getBookFilterData(obj).subscribe(function (response) {
            _this.isRippleLoad = false;
            var res;
            res = response;
            _this.bookSearchData = [];
            _this.totalCount = 0;
            _this.searchResult = true;
            if (res.response.results.length > 0) {
                console.log(response);
                _this.bookSearchData = res.response.results;
                _this.totalCount = res.response.totalRecords;
                _this.searchResult = true;
            }
            else {
                _this.messageHandler('info', 'No data found', '');
                // if(res.errorResponse[0].errorCode == 700){
                //   this.messageHandler('error', 'No data found', '');
                // }
            }
        });
    };
    IssueBookComponent.prototype.resetFilter = function () {
        this.searchTitle = "";
        this.searchCategoryId = "-1";
        this.searchSubcategoryId = "-1";
        this.searchSubjectId = "-1";
        this.searchPublicationId = "-1";
        this.searchLangId = "-1";
        this.searchAuthorId = "-1";
    };
    IssueBookComponent.prototype.selectBookForIssue = function (book_id) {
        var _this = this;
        this.suggestion = false;
        this.isRippleLoad = true;
        this.issueBookService.getBookDetails(book_id).subscribe(function (response) {
            var res;
            res = response;
            if (res.response != null) {
                console.log(response);
                _this.searchResult = true;
                _this.bookSearchData = res.response.results;
                _this.isRippleLoad = false;
            }
            else {
                if (res.errorResponse[0].errorCode == 700) {
                    _this.messageHandler('error', 'Book alredy exists', '');
                }
                _this.isRippleLoad = false;
            }
        });
    };
    IssueBookComponent.prototype.selectStudent = function (borrower_details) {
        this.borrower = borrower_details.student_name;
        this.selectedBorrowerId = borrower_details.student_id;
        this.borSuggestions = false;
        this.getBooksStatusForStudent();
    };
    IssueBookComponent.prototype.getBooksStatusForStudent = function () {
        var _this = this;
        this.issueBookService.getBooksStatusForStudent(this.selectedBorrowerId).subscribe(function (response) {
            _this.isRippleLoad = false;
            var res;
            res = response;
            if (res.response != null) {
                console.log(response);
                _this.booksInHandStatus = true;
                _this.bookInHand = res.response.length;
                _this.booksInHandDetails = res.response;
            }
            else {
                _this.messageHandler('error', 'Internal server error', '');
            }
        });
    };
    IssueBookComponent.prototype.selectBookFromDate = function () {
        var fromDateNotGreaterThanToday = this.graterThanToday(this.bookFromDate);
        if (fromDateNotGreaterThanToday) {
            this.tempFromDate = __WEBPACK_IMPORTED_MODULE_7_moment__(this.bookFromDate).format("DD MMM YYYY");
            this.tempToDate = __WEBPACK_IMPORTED_MODULE_7_moment__(this.bookFromDate).add(this.numberOfLateDaysWithoutFine, 'days').format("DD MMM YYYY");
        }
        else {
            this.messageHandler('error', 'From date cannot be future date', '');
            return;
        }
        var check = this.dateGreaterThanCheck(this.bookFromDate, this.bookToDate);
        if (check) {
            this.tempFromDate = __WEBPACK_IMPORTED_MODULE_7_moment__(this.bookFromDate).format("DD MMM YYYY");
        }
        else {
            this.messageHandler('error', 'From date can not be greater than To date', '');
            this.bookFromDate = __WEBPACK_IMPORTED_MODULE_7_moment__(this.tempFromDate).format("DD MMM YYYY");
            return;
        }
    };
    IssueBookComponent.prototype.selectBookToDate = function () {
        var check = this.dateGreaterThanCheck(this.bookFromDate, this.bookToDate);
        if (check) {
            this.tempToDate = __WEBPACK_IMPORTED_MODULE_7_moment__(this.bookToDate).format("DD MMM YYYY");
        }
        else {
            this.messageHandler('error', 'To date can not be lesser than From date', '');
            this.bookToDate = __WEBPACK_IMPORTED_MODULE_7_moment__(this.tempToDate).format("DD MMM YYYY");
            return;
        }
    };
    IssueBookComponent.prototype.graterThanToday = function (givenDate) {
        var currentDate = new Date();
        givenDate = new Date(givenDate);
        if (givenDate > currentDate) {
            return false;
        }
        else {
            return true;
        }
    };
    IssueBookComponent.prototype.dateGreaterThanCheck = function (from_date, to_date) {
        from_date = new Date(from_date);
        to_date = new Date(to_date);
        var currentDate = new Date();
        if (from_date > to_date) {
            return false;
        }
        else if (from_date > currentDate) {
            return false;
        }
        else {
            return true;
        }
    };
    IssueBookComponent.prototype.issueBook = function () {
        var _this = this;
        if (this.selectedBorrowerId == "" || this.selectedBorrowerId == null) {
            this.messageHandler('error', 'Please enter borrower name', '');
        }
        else {
            var obj = {
                "book_id": this.bookDataForIssue.book_id,
                "issued_on": __WEBPACK_IMPORTED_MODULE_7_moment__(this.tempFromDate).unix() * 1000,
                "to_return_on_date": __WEBPACK_IMPORTED_MODULE_7_moment__(this.tempToDate).unix() * 1000,
                "issued_to": this.selectedBorrowerId
            };
            console.log(obj);
            this.isRippleLoad = true;
            this.multiClickDisabled = true;
            this.issueBookService.issueBook(obj).subscribe(function (response) {
                _this.isRippleLoad = false;
                _this.multiClickDisabled = false;
                var res;
                res = response;
                if (res.response != null) {
                    console.log(response);
                    _this.messageHandler('success', 'Book issued successfully', '');
                    _this.clearIssueBookRecord();
                    _this.searchResult = false;
                    _this.bookSuggestion = false;
                    _this.filter = false;
                    _this.searchInput = "";
                }
                else if (res.errorResponse[0].errorCode == 2000) {
                    _this.messageHandler('error', 'No book available in stock', '');
                }
                else {
                    _this.messageHandler('error', 'Internal server error', '');
                }
            });
        }
    };
    IssueBookComponent.prototype.clearIssueBookRecord = function () {
        this.selectedBorrowerId = "";
        this.tempFromDate = __WEBPACK_IMPORTED_MODULE_7_moment__(new Date()).format("DD MMM YYYY");
        this.tempToDate = __WEBPACK_IMPORTED_MODULE_7_moment__(new Date()).format("DD MMM YYYY");
        this.bookFromDate = __WEBPACK_IMPORTED_MODULE_7_moment__(new Date()).format("DD MMM YYYY");
        this.bookToDate = __WEBPACK_IMPORTED_MODULE_7_moment__(new Date()).format("DD MMM YYYY");
        this.booksInHandStatus = false;
        this.bookInHand = 0;
        this.booksInHandDetails = [];
    };
    IssueBookComponent.prototype.showIssueBookPopup = function (bookData) {
        this.bookSuggestion = true;
        this.searchResult = false;
        this.borrower = "";
        this.booksInHandDetails = [];
        this.booksInHandStatus = false;
        this.bookInHand = 0;
        this.tempFromDate = __WEBPACK_IMPORTED_MODULE_7_moment__(new Date()).format("DD MMM YYYY");
        // this.tempToDate = moment(new Date()).format("DD MMM YYYY");
        this.bookFromDate = __WEBPACK_IMPORTED_MODULE_7_moment__(new Date()).format("DD MMM YYYY");
        this.bookToDate = this.tempToDate;
        this.bookDataForIssue = bookData;
    };
    IssueBookComponent.prototype.concatString = function (authorArray) {
        this.hoverTitle = "";
        for (var i = 0; i < authorArray.length; i++) {
            this.hoverTitle += authorArray[i].author_name;
            if (i < authorArray.length - 1 && authorArray.length > 1) {
                this.hoverTitle += ", ";
            }
        }
        return this.hoverTitle;
    };
    IssueBookComponent.prototype.concatAuthorList = function (authorArray) {
        this.hoverTitleAuthor = "";
        for (var i = 0; i < authorArray.length; i++) {
            this.hoverTitleAuthor += authorArray[i].author_name;
            if (i >= 0 && i < authorArray.length - 1 && authorArray.length > 1) {
                this.hoverTitleAuthor += ", ";
            }
        }
        return this.hoverTitleAuthor;
    };
    IssueBookComponent.prototype.messageHandler = function (type, title, body) {
        var obj = {
            type: type,
            title: title,
            body: body
        };
        this.appC.popToast(obj);
    };
    IssueBookComponent.prototype.closeSuggestionAndFilter = function () {
        this.suggestion = false;
        this.filter = false;
        this.borSuggestions = false;
    };
    IssueBookComponent.prototype.clearResult = function () {
        this.borrower = "";
        this.booksInHandStatus = false;
        this.booksInHandDetails = [];
    };
    IssueBookComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    /*** pagination functions */
    /* Fetch next set of data from server and update table */
    IssueBookComponent.prototype.fetchNext = function () {
        this.pageIndex++;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch previous set of data from server and update table */
    IssueBookComponent.prototype.fetchPrevious = function () {
        this.pageIndex--;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch table data by page index */
    IssueBookComponent.prototype.fectchTableDataByPage = function (index) {
        this.pageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.advanceSearch();
    };
    /* Fetches Data as per the user selected batch size */
    IssueBookComponent.prototype.updateTableBatchSize = function (num) {
        this.pageIndex = 1;
        this.displayBatchSize = parseInt(num);
        this.advanceSearch();
    };
    IssueBookComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-issue-book',
            template: __webpack_require__("./src/app/components/library-management/issue-book/issue-book.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/issue-book/issue-book.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__services_common_service__["a" /* CommonServiceFactory */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_5__services_library_add_add_book_service__["a" /* AddBookService */],
            __WEBPACK_IMPORTED_MODULE_6__services_library_issue_issue_book_service__["a" /* IssueBookService */]])
    ], IssueBookComponent);
    return IssueBookComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/library-management-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LibraryManagementRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__library_management_component__ = __webpack_require__("./src/app/components/library-management/library-management.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__masters_masters_component__ = __webpack_require__("./src/app/components/library-management/masters/masters.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__add_book_add_book_component__ = __webpack_require__("./src/app/components/library-management/add-book/add-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__return_book_return_book_component__ = __webpack_require__("./src/app/components/library-management/return-book/return-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__dashboard_dashboard_component__ = __webpack_require__("./src/app/components/library-management/dashboard/dashboard.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__issue_book_issue_book_component__ = __webpack_require__("./src/app/components/library-management/issue-book/issue-book.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








var LibraryManagementRoutingModule = /** @class */ (function () {
    function LibraryManagementRoutingModule() {
    }
    LibraryManagementRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__library_management_component__["a" /* LibraryManagementComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                component: __WEBPACK_IMPORTED_MODULE_7__issue_book_issue_book_component__["a" /* IssueBookComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'issue',
                                component: __WEBPACK_IMPORTED_MODULE_7__issue_book_issue_book_component__["a" /* IssueBookComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'master',
                                component: __WEBPACK_IMPORTED_MODULE_3__masters_masters_component__["a" /* MastersComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'add',
                                component: __WEBPACK_IMPORTED_MODULE_4__add_book_add_book_component__["a" /* AddBookComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'return',
                                component: __WEBPACK_IMPORTED_MODULE_5__return_book_return_book_component__["a" /* ReturnBookComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'dashboard',
                                component: __WEBPACK_IMPORTED_MODULE_6__dashboard_dashboard_component__["a" /* DashboardComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'report',
                                loadChildren: "app/components/library-management/report/report.module#ReportModule",
                                pathMatch: 'prefix',
                            }
                        ]
                    }
                ])
            ],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]]
        })
    ], LibraryManagementRoutingModule);
    return LibraryManagementRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/library-management/library-management.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n<section style=\"padding: 10px;padding-bottom: 0;\" class=\"middle-section clearFix\">\r\n  <!-- Library Menu -->\r\n   <section class=\"menu_section\">\r\n    <div class=\"library_menu_container\">\r\n      <div class=\"library_menu_item\" routerLink=\"/view/library/issue\"  >\r\n        <div class=\"lib_menu_img\"  >\r\n          <img src=\"./assets/images/library/gray/issue.svg\" alt=\"issue\" *ngIf=\"activeSession !='issue'\">\r\n          <img src=\"./assets/images/library/color/issue.svg\" alt=\"issue\" *ngIf=\"activeSession =='issue'\">\r\n        </div>\r\n        <div class=\"lib_menu_name\" [ngClass]=\"activeSession =='issue' ? 'activeMenu' : 'nonActive'\" (click)=\"menuChange('issue')\">\r\n          <i class=\"fa fa-circle-o ring\" aria-hidden=\"true\"></i>\r\n          <span>Issue Book</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"library_menu_item\" routerLink=\"/view/library/return\">\r\n        <div class=\"lib_menu_img\"  >\r\n          <img src=\"./assets/images/library/gray/return.svg\" alt=\"return\" *ngIf=\"activeSession !='return'\">\r\n          <img src=\"./assets/images/library/color/return.svg\" alt=\"return\" *ngIf=\"activeSession =='return'\">\r\n        </div>\r\n        <div class=\"lib_menu_name\" [ngClass]=\"activeSession =='return' ? 'activeMenu' : 'nonActive'\" (click)=\"menuChange('return')\">\r\n          <i class=\"fa fa-circle-o ring\" aria-hidden=\"true\"></i>\r\n          <span>Return Book</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"library_menu_item\">\r\n        <div class=\"lib_menu_img\" routerLink=\"/view/library/add\" >\r\n          <img src=\"./assets/images/library/gray/add.svg\" alt=\"add\" *ngIf=\"activeSession !='add'\">\r\n          <img src=\"./assets/images/library/color/add.svg\" alt=\"add\" *ngIf=\"activeSession =='add'\">\r\n        </div>\r\n        <div class=\"lib_menu_name\" [ngClass]=\"activeSession =='add' ? 'activeMenu' : 'nonActive'\" (click)=\"menuChange('add')\">\r\n          <i class=\"fa fa-circle-o ring\" aria-hidden=\"true\"></i>\r\n          <span>Add New Book</span>\r\n        </div>\r\n      </div>\r\n      <!-- <div class=\"library_menu_item\">\r\n        <div class=\"lib_menu_img\" (click)=\"menuChange('activity')\">\r\n          <img src=\"./assets/images/library/gray/activity.svg\" alt=\"activity\" *ngIf=\"!activity\">\r\n          <img src=\"./assets/images/library/color/activity.svg\" alt=\"activity\" *ngIf=\"activity\">\r\n        </div>\r\n        <div class=\"lib_menu_name\" [ngClass]=\"activity ? 'activeMenu' : 'nonActive'\" (click)=\"menuChange('activity')\">\r\n          <i class=\"fa fa-circle-o ring\" aria-hidden=\"true\"></i>\r\n          <span>Activity</span>\r\n        </div>\r\n      </div> -->\r\n      <div class=\"library_menu_item\">\r\n        <div class=\"lib_menu_img\"  routerLink=\"/view/library/report/lost\" >\r\n          <img src=\"./assets/images/library/gray/report.svg\" alt=\"report\" *ngIf=\"activeSession !='report'\">\r\n          <img src=\"./assets/images/library/color/report.svg\" alt=\"report\" *ngIf=\"activeSession =='report'\">\r\n        </div>\r\n        <div class=\"lib_menu_name\" [ngClass]=\"activeSession =='report' ? 'activeMenu' : 'nonActive'\" (click)=\"menuChange('report')\">\r\n          <i class=\"fa fa-circle-o ring\" aria-hidden=\"true\"></i>\r\n          <span>Report</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"library_menu_item\">\r\n        <div class=\"lib_menu_img\" routerLink=\"/view/library/dashboard\">\r\n          <img src=\"./assets/images/library/gray/dashboard.svg\" alt=\"dashboard\" *ngIf=\"activeSession !='dashboard'\">\r\n          <img src=\"./assets/images/library/color/dashboard.svg\" alt=\"dashboard\" *ngIf=\"activeSession =='dashboard'\">\r\n        </div>\r\n        <div class=\"lib_menu_name\" [ngClass]=\"activeSession =='dashboard' ? 'activeMenu' : 'nonActive'\" (click)=\"menuChange('dashboard')\">\r\n          <i class=\"fa fa-circle-o ring\" aria-hidden=\"true\"></i>\r\n          <span>Dashboard</span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <section class=\"middle\">\r\n    <router-outlet></router-outlet>\r\n  </section>\r\n\r\n</section>\r\n"

/***/ }),

/***/ "./src/app/components/library-management/library-management.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  background: #fdfdfd; }\n\n.menu_section {\n  margin: 20px 0px;\n  width: 100%; }\n\n.menu_section .library_menu_container {\n    background: #ffffff;\n    border-radius: 8px;\n    -webkit-box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.16);\n            box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.16);\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    width: 60%;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    margin-left: 20%;\n    margin-right: 20%;\n    height: 55px; }\n\n.menu_section .library_menu_container .library_menu_item {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      width: 20%; }\n\n.menu_section .library_menu_container .library_menu_item .lib_menu_img {\n        height: 100%;\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-pack: center;\n            -ms-flex-pack: center;\n                justify-content: center;\n        margin-top: -30px; }\n\n.menu_section .library_menu_container .library_menu_item .lib_menu_img img {\n          height: 70px;\n          width: 70px;\n          cursor: pointer; }\n\n.menu_section .library_menu_container .library_menu_item .lib_menu_name {\n        text-align: center;\n        font-weight: 600;\n        font-size: 14px;\n        margin-top: 8px;\n        position: relative; }\n\n.menu_section .library_menu_container .library_menu_item .lib_menu_name .ring {\n          color: #1984f6;\n          font-size: 10px;\n          font-weight: 600;\n          position: relative;\n          left: 0px;\n          top: -1px; }\n\n.menu_section .library_menu_container .library_menu_item .lib_menu_name span {\n          cursor: pointer; }\n\n.menu_section .library_menu_container .library_menu_item .activeMenu {\n        color: #1984f6;\n        visibility: visible; }\n\n.menu_section .library_menu_container .library_menu_item .nonActive {\n        color: #9b9b9b; }\n\n.menu_section .library_menu_container .library_menu_item .nonActive .fa-circle-o {\n          visibility: hidden; }\n\n.middle {\n  margin-top: 25px;\n  height: -webkit-fill-available;\n  height: -moz-available;\n  height: stretch;\n  min-height: -webkit-fill-available;\n  min-height: -moz-available;\n  min-height: stretch; }\n"

/***/ }),

/***/ "./src/app/components/library-management/library-management.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LibraryManagementComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var LibraryManagementComponent = /** @class */ (function () {
    function LibraryManagementComponent() {
        this.activeSession = 'issue';
    }
    LibraryManagementComponent.prototype.ngOnInit = function () {
    };
    LibraryManagementComponent.prototype.ngAfterContentChecked = function () {
        this.setActiveClassOnSideNav();
    };
    LibraryManagementComponent.prototype.setActiveClassOnSideNav = function () {
        var pathLastURL;
        var str = window.location.href;
        var pathURL = str.substring(str.lastIndexOf("/") + 1, str.length);
        switch (pathURL) {
            case 'overdue':
            case 'never-issued':
            case 'retrun-book':
            case 'issued':
            case 'lost':
            case 'fine': {
                this.activeSession = 'report';
                break;
            }
            case 'issue': {
                this.activeSession = pathURL;
                break;
            }
            case 'dashboard': {
                this.activeSession = pathURL;
                break;
            }
            case 'issue': {
                this.activeSession = pathURL;
                break;
            }
            case 'return': {
                this.activeSession = pathURL;
                break;
            }
            case 'add': {
                this.activeSession = pathURL;
                break;
            }
        }
    };
    LibraryManagementComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-library-management',
            template: __webpack_require__("./src/app/components/library-management/library-management.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/library-management.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], LibraryManagementComponent);
    return LibraryManagementComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/library-management.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LibraryManagementModule", function() { return LibraryManagementModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_primeng_primeng__ = __webpack_require__("./node_modules/primeng/primeng.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_primeng_primeng___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_primeng_primeng__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__library_management_routing_module__ = __webpack_require__("./src/app/components/library-management/library-management-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__library_management_component__ = __webpack_require__("./src/app/components/library-management/library-management.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__masters_masters_component__ = __webpack_require__("./src/app/components/library-management/masters/masters.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__add_book_add_book_component__ = __webpack_require__("./src/app/components/library-management/add-book/add-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__issue_book_issue_book_component__ = __webpack_require__("./src/app/components/library-management/issue-book/issue-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__return_book_return_book_component__ = __webpack_require__("./src/app/components/library-management/return-book/return-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__activity_activity_component__ = __webpack_require__("./src/app/components/library-management/activity/activity.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__dashboard_dashboard_component__ = __webpack_require__("./src/app/components/library-management/dashboard/dashboard.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15_ng_multiselect_dropdown__ = __webpack_require__("./node_modules/ng-multiselect-dropdown/fesm5/ng-multiselect-dropdown.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__services_library_return_return_book_service__ = __webpack_require__("./src/app/services/library/return/return-book.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__services_library_issue_issue_book_service__ = __webpack_require__("./src/app/services/library/issue/issue-book.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_18__services_library_add_add_book_service__ = __webpack_require__("./src/app/services/library/add/add-book.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_19__services_library_master_masters_service__ = __webpack_require__("./src/app/services/library/master/masters.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




















var LibraryManagementModule = /** @class */ (function () {
    function LibraryManagementModule() {
    }
    LibraryManagementModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_4_primeng_primeng__["FileUploadModule"],
                __WEBPACK_IMPORTED_MODULE_4_primeng_primeng__["SplitButtonModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_6__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_7__library_management_routing_module__["a" /* LibraryManagementRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_15_ng_multiselect_dropdown__["a" /* NgMultiSelectDropDownModule */].forRoot()
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_9__masters_masters_component__["a" /* MastersComponent */],
                __WEBPACK_IMPORTED_MODULE_8__library_management_component__["a" /* LibraryManagementComponent */],
                __WEBPACK_IMPORTED_MODULE_10__add_book_add_book_component__["a" /* AddBookComponent */],
                __WEBPACK_IMPORTED_MODULE_11__issue_book_issue_book_component__["a" /* IssueBookComponent */],
                __WEBPACK_IMPORTED_MODULE_12__return_book_return_book_component__["a" /* ReturnBookComponent */],
                __WEBPACK_IMPORTED_MODULE_13__activity_activity_component__["a" /* ActivityComponent */],
                __WEBPACK_IMPORTED_MODULE_14__dashboard_dashboard_component__["a" /* DashboardComponent */]
            ],
            entryComponents: [
                __WEBPACK_IMPORTED_MODULE_10__add_book_add_book_component__["a" /* AddBookComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_16__services_library_return_return_book_service__["a" /* ReturnBookService */],
                __WEBPACK_IMPORTED_MODULE_17__services_library_issue_issue_book_service__["a" /* IssueBookService */],
                __WEBPACK_IMPORTED_MODULE_18__services_library_add_add_book_service__["a" /* AddBookService */],
                __WEBPACK_IMPORTED_MODULE_19__services_library_master_masters_service__["a" /* MastersService */]
            ]
        })
    ], LibraryManagementModule);
    return LibraryManagementModule;
}());



/***/ }),

/***/ "./src/app/components/library-management/masters/masters.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n\r\n<section style=\"padding: 10px;height: -webkit-fill-available;\" class=\"middle-section clearFix\">\r\n  <section class=\"middle-top mb0 clearFix\">\r\n    <h1 class=\"pull-left\">\r\n        Create Library Master\r\n    </h1>\r\n  </section>\r\n\r\n  <hr style=\"color:#f9f9f9;\">\r\n\r\n  <!-- HEADER LIST -->\r\n\r\n  <section class=\"master_list\">\r\n    <div class=\"master_list_container\">\r\n\r\n      <div class=\"master_menu\">\r\n        <div class=\"master_list_item\">\r\n          <button type=\"button\" name=\"button\" class=\"master_list_btn active\" id=\"item1\" (click)=\"changeMasterCategory('item1', 'for_category')\">Category & Sub-categories</button>\r\n        </div>\r\n        <div class=\"master_list_item\">\r\n          <button type=\"button\" name=\"button\" class=\"master_list_btn\" id=\"item2\" (click)=\"changeMasterCategory('item2', 'for_subject')\">Subject</button>\r\n        </div>\r\n        <div class=\"master_list_item\">\r\n          <button type=\"button\" name=\"button\" class=\"master_list_btn\" id=\"item3\" (click)=\"changeMasterCategory('item3', 'for_publication')\">Publication</button>\r\n        </div>\r\n        <div class=\"master_list_item\">\r\n          <button type=\"button\" name=\"button\" class=\"master_list_btn\" id=\"item4\" (click)=\"changeMasterCategory('item4', 'for_author')\">Author</button>\r\n        </div>\r\n        <div class=\"master_list_item\">\r\n          <button type=\"button\" name=\"button\" class=\"master_list_btn\" id=\"item5\" (click)=\"changeMasterCategory('item5', 'for_reference')\">References</button>\r\n        </div>\r\n        <div class=\"master_list_item\">\r\n          <button type=\"button\" name=\"button\" class=\"master_list_btn\" id=\"item6\" (click)=\"changeMasterCategory('item6', 'for_languages')\">Language</button>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"search_container pull-right\">\r\n        <div class=\"pull-right\" style=\"margin-right: 15px;\">\r\n            <div class=\"search-filter-wrapper \">\r\n                <input type=\"text\" class=\"normal-field pull-right\" placeholder=\"Search\" name=\"searchData\" (keyup)=\"searchInList($event)\" [(ngModel)]=\"searchInput\">\r\n            </div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </section>\r\n\r\n\r\n  <!-- FOR Category and Sub-Category -->\r\n\r\n  <section id=\"for_category\" class=\"middle_section\">\r\n    <div class=\"add_container\">\r\n      <div class=\"main_name_container\">\r\n        <div class=\"name_container\">\r\n          <span style=\"margin-bottom:5px;font-size: 12px;\">Category<span class=\"text-danger\">*</span></span>\r\n          <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Category Name\" class=\"add_input\" style=\"width: 100%;\" [(ngModel)]=\"categoryName\" > <!--  (keyup)=\"showCategorySuggestions($event)\" -->\r\n          <i class=\"fa fa-sort-desc\" aria-hidden=\"true\" (click)=\"showSuggestions()\"></i>\r\n        </div>\r\n        <div class=\"name_container\" style=\"margin-left: 10px;\">\r\n          <span style=\"margin-bottom:5px;font-size: 12px;\">Sub-Category</span>\r\n          <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Sub-Category Name\" class=\"add_input\" style=\"width: 100%;\" [(ngModel)]=\"subcategoryName\">\r\n        </div>\r\n      </div>\r\n      <div class=\"add_btn\">\r\n        <button type=\"button\" name=\"button\" (click)=\"addCatAndSubCat()\" [disabled]=\"multiClickDisabled\">Add <i class=\"fa fa-plus-circle\" style=\"color:#1984f6\" aria-hidden=\"true\"></i></button>\r\n      </div>\r\n\r\n      <div class=\"category_suggestions_container\" *ngIf=\"categorySuggestions\">\r\n        <div class=\"category_suggestions_item\" *ngFor=\"let category of categoryList let i = index\" (click)=\"chooseCategory(category.category_name)\">\r\n          <span>{{category.category_name}}</span>\r\n        </div>\r\n      </div>\r\n\r\n\r\n    </div>\r\n\r\n\r\n    <div class=\"added_list_container\">\r\n\r\n      <div class=\"added_list_item\" *ngFor=\"let category of categorySubCatList let i = index\">\r\n        <div class=\"display_com\" id=\"cat_row_dis{{i}}\">\r\n          <div class=\"value_container\">\r\n            <div class=\"value_item1 display_com\" id=\"\">\r\n              <span>{{category.category_name}}</span>\r\n            </div>\r\n            <div class=\"value_item2\" style=\"margin-left: 10px;\">\r\n              <span>{{category.sub_category_name}}</span>\r\n            </div>\r\n          </div>\r\n          <div class=\"action_container\">\r\n            <i class=\"fa fa-pencil\" style=\"color:#1283f4;\" aria-hidden=\"true\" (click)=\"editCat(category, i)\"></i>\r\n            <i class=\"fa fa-trash\" style=\"color:#fa3145;\" aria-hidden=\"true\"  (click)=\"deleteCat(category)\"></i>\r\n          </div>\r\n        </div>\r\n        <div class=\"edit_com\" id=\"cat_row_edit{{i}}\">\r\n          <div class=\"value_container\">\r\n            <div class=\"value_item1\">\r\n              <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Category Name\" class=\"edit_input\" [(ngModel)]=\"editCategoryName\">\r\n            </div>\r\n            <div class=\"value_item2\" style=\"margin-left: 10px;\" *ngIf=\"subcatEdit\">\r\n              <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Sub-Category Name\" class=\"edit_input\" [(ngModel)]=\"editSubCategoryName\">\r\n            </div>\r\n          </div>\r\n          <div class=\"action_container\">\r\n            <span (click)=\"saveCat(category.category_id, category.sub_category_id)\">Save</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <!-- <div class=\"new_sub_cat\" *ngIf=\"newSubCat\">\r\n        <div class=\"new_sub_cat_item\">\r\n          <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Sub-Category Name\" class=\"edit_input\" >\r\n        </div>\r\n        <div class=\"new_sub_cat_action_item\">\r\n          <button type=\"button\" name=\"button\" class=\"new_cat_save_btn\">Save</button>\r\n          <button type=\"button\" name=\"button\" class=\"new_cat_cancel_btn\">Cancel</button>\r\n        </div>\r\n      </div> -->\r\n\r\n    </div>\r\n\r\n    <div class=\"noResult\" *ngIf=\"categorySubCatList.length == 0\">\r\n      <span *ngIf=\"searchInput == ''\">No category added!</span>\r\n      <span *ngIf=\"searchInput != ''\">No search result found!</span>\r\n    </div>\r\n\r\n  </section>\r\n\r\n  <!-- FOR SUBJECT  -->\r\n\r\n  <section id=\"for_subject\" class=\"middle_section\">\r\n    <div class=\"add_container\">\r\n      <div class=\"name_container\">\r\n        <span style=\"margin-bottom:5px;font-size: 12px;\">Subject<span class=\"text-danger\">*</span></span>\r\n        <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Subject Name\" class=\"add_input\" [(ngModel)]=\"subjectName\">\r\n      </div>\r\n      <div class=\"add_btn\">\r\n        <button type=\"button\" name=\"button\" (click)=\"addSubject()\" [disabled]=\"multiClickDisabled\">Add <i class=\"fa fa-plus-circle\" style=\"color:#1984f6\" aria-hidden=\"true\"></i></button>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"added_list_container\">\r\n      <div class=\"added_list_item\" *ngFor=\"let subject of subjectList let i = index\">\r\n        <div class=\"display_com\" id=\"subject_row_dis{{i}}\">\r\n          <div class=\"value_container\">\r\n            <span>{{subject.subject_name}}</span>\r\n          </div>\r\n          <div class=\"action_container\">\r\n            <i class=\"fa fa-pencil\" style=\"color:#1283f4;\" aria-hidden=\"true\" (click)=\"editSubject(subject, i)\"></i>\r\n            <i class=\"fa fa-trash\" style=\"color:#fa3145;\" aria-hidden=\"true\" (click)=\"delete(subject.subject_id, 'subject')\"></i>\r\n          </div>\r\n        </div>\r\n        <div class=\"edit_com\" id=\"subject_row_edit{{i}}\">\r\n          <div class=\"value_container\">\r\n            <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Subject Name\" class=\"edit_input\" [(ngModel)]=\"editSubjectName\">\r\n          </div>\r\n          <div class=\"action_container\">\r\n            <span (click)=\"saveSubject(subject.subject_id)\">Save</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"noResult\" *ngIf=\"subjectList.length == 0\">\r\n      <span *ngIf=\"searchInput == ''\">No subject added!</span>\r\n      <span *ngIf=\"searchInput != ''\">No search result found!</span>\r\n    </div>\r\n  </section>\r\n\r\n  <!-- FOR PUBLICATION -->\r\n\r\n  <section id=\"for_publication\" class=\"middle_section\">\r\n    <div class=\"add_container\">\r\n      <div class=\"name_container\">\r\n        <span style=\"margin-bottom:5px;font-size: 12px;\">Publication<span class=\"text-danger\">*</span></span>\r\n        <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Publication Name\" class=\"add_input\" [(ngModel)]=\"publicationName\">\r\n      </div>\r\n      <div class=\"add_btn\">\r\n        <button type=\"button\" name=\"button\" (click)=\"addPublication()\" [disabled]=\"multiClickDisabled\">Add <i class=\"fa fa-plus-circle\" style=\"color:#1984f6\" aria-hidden=\"true\"></i></button>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"added_list_container\">\r\n      <div class=\"added_list_item\" *ngFor=\"let publication of publicationList let i = index\">\r\n        <div class=\"display_com\" id=\"publication_row_dis{{i}}\">\r\n          <div class=\"value_container\">\r\n            <span>{{publication.publication_name}}</span>\r\n          </div>\r\n          <div class=\"action_container\">\r\n            <i class=\"fa fa-pencil\" style=\"color:#1283f4;\" aria-hidden=\"true\" (click)=\"editPublication(publication, i)\"></i>\r\n            <i class=\"fa fa-trash\" style=\"color:#fa3145;\" aria-hidden=\"true\" (click)=\"delete(publication.publication_id, 'publication')\"></i>\r\n          </div>\r\n        </div>\r\n        <div class=\"edit_com\" id=\"publication_row_edit{{i}}\">\r\n          <div class=\"value_container\">\r\n            <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Publication Name\" class=\"edit_input\" [(ngModel)]=\"editPublicationName\">\r\n          </div>\r\n          <div class=\"action_container\">\r\n            <span (click)=\"savePublication(publication.publication_id)\">Save</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"noResult\" *ngIf=\"publicationList.length == 0\">\r\n      <span *ngIf=\"searchInput == ''\">No publication added!</span>\r\n      <span *ngIf=\"searchInput != ''\">No search result found!</span>\r\n    </div>\r\n  </section>\r\n\r\n\r\n  <!-- FOR AUTHOR -->\r\n\r\n  <section id=\"for_author\" class=\"middle_section\">\r\n    <div class=\"add_container\">\r\n      <div class=\"name_container\">\r\n        <span style=\"margin-bottom:5px;font-size: 12px;\">Author<span class=\"text-danger\">*</span></span>\r\n        <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Author Name\" class=\"add_input\" [(ngModel)]=\"authorName\">\r\n      </div>\r\n      <div class=\"add_btn\">\r\n        <button type=\"button\" name=\"button\" (click)=\"addAuthor()\" [disabled]=\"multiClickDisabled\">Add <i class=\"fa fa-plus-circle\" style=\"color:#1984f6\" aria-hidden=\"true\"></i></button>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"added_list_container\">\r\n      <div class=\"added_list_item\" *ngFor=\"let author of authorList let i = index\">\r\n        <div class=\"display_com\" id=\"author_row_dis{{i}}\">\r\n          <div class=\"value_container\">\r\n            <span>{{author.author_name}}</span>\r\n          </div>\r\n          <div class=\"action_container\">\r\n            <i class=\"fa fa-pencil\" style=\"color:#1283f4;\" aria-hidden=\"true\" (click)=\"editAuthor(author, i)\"></i>\r\n            <i class=\"fa fa-trash\" style=\"color:#fa3145;\" aria-hidden=\"true\" (click)=\"delete(author.author_id, 'author')\"></i>\r\n          </div>\r\n        </div>\r\n        <div class=\"edit_com\" id=\"author_row_edit{{i}}\">\r\n          <div class=\"value_container\">\r\n            <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Author Name\" class=\"edit_input\" [(ngModel)]=\"editAuthorName\">\r\n          </div>\r\n          <div class=\"action_container\">\r\n            <span (click)=\"saveAuthor(author.author_id)\">Save</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"noResult\" *ngIf=\"authorList.length == 0\">\r\n      <span *ngIf=\"searchInput == ''\">No author added!</span>\r\n      <span *ngIf=\"searchInput != ''\">No search result found!</span>\r\n    </div>\r\n  </section>\r\n\r\n  <!-- FOR REFERENCES -->\r\n\r\n  <section id=\"for_reference\" class=\"middle_section\">\r\n    <div class=\"add_container\">\r\n      <div class=\"name_container\">\r\n        <span style=\"margin-bottom:5px;font-size: 12px;\">References<span class=\"text-danger\">*</span></span>\r\n        <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter References Name\" class=\"add_input\" [(ngModel)]=\"referenceName\">\r\n      </div>\r\n      <div class=\"add_btn\">\r\n        <button type=\"button\" name=\"button\" (click)=\"addReference()\" [disabled]=\"multiClickDisabled\">Add <i class=\"fa fa-plus-circle\" style=\"color:#1984f6\" aria-hidden=\"true\"></i></button>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"added_list_container\">\r\n      <div class=\"added_list_item\" *ngFor=\"let reference of referenceList let i = index\">\r\n        <div class=\"display_com\" id=\"reference_row_dis{{i}}\">\r\n          <div class=\"value_container\">\r\n            <span>{{reference.reference_name}}</span>\r\n          </div>\r\n          <div class=\"action_container\">\r\n            <i class=\"fa fa-pencil\" style=\"color:#1283f4;\" aria-hidden=\"true\" (click)=\"editReference(reference, i)\"></i>\r\n            <i class=\"fa fa-trash\" style=\"color:#fa3145;\" aria-hidden=\"true\" (click)=\"delete(reference.reference_id, 'reference')\"></i>\r\n          </div>\r\n        </div>\r\n        <div class=\"edit_com\" id=\"reference_row_edit{{i}}\">\r\n          <div class=\"value_container\">\r\n            <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Reference Name\" class=\"edit_input\" [(ngModel)]=\"editReferenceName\">\r\n          </div>\r\n          <div class=\"action_container\">\r\n            <span (click)=\"saveReference(reference.reference_id)\">Save</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"noResult\" *ngIf=\"referenceList.length == 0\">\r\n      <span *ngIf=\"searchInput == ''\">No reference added!</span>\r\n      <span *ngIf=\"searchInput != ''\">No search result found!</span>\r\n    </div>\r\n  </section>\r\n\r\n\r\n  <!-- FOR LANGUAGES -->\r\n\r\n  <section id=\"for_languages\" class=\"middle_section\">\r\n    <div class=\"add_container\">\r\n      <div class=\"name_container\">\r\n        <span style=\"margin-bottom:5px;font-size: 12px;\">Language<span class=\"text-danger\">*</span></span>\r\n        <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Language Name\" class=\"add_input\" [(ngModel)]=\"languageName\">\r\n      </div>\r\n      <div class=\"add_btn\">\r\n        <button type=\"button\" name=\"button\" (click)=\"addLanguage()\" [disabled]=\"multiClickDisabled\">Add <i class=\"fa fa-plus-circle\" style=\"color:#1984f6\" aria-hidden=\"true\"></i></button>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"added_list_container\">\r\n      <div class=\"added_list_item\" *ngFor=\"let language of languageList let i = index\">\r\n        <div class=\"display_com\" id=\"language_row_dis{{i}}\">\r\n          <div class=\"value_container\">\r\n            <span>{{language.language_name}}</span>\r\n          </div>\r\n          <div class=\"action_container\">\r\n            <i class=\"fa fa-pencil\" style=\"color:#1283f4;\" aria-hidden=\"true\" (click)=\"editLanguage(language, i)\"></i>\r\n            <i class=\"fa fa-trash\" style=\"color:#fa3145;\" aria-hidden=\"true\" (click)=\"delete(language.language_id, 'language')\"></i>\r\n          </div>\r\n        </div>\r\n        <div class=\"edit_com\" id=\"language_row_edit{{i}}\">\r\n          <div class=\"value_container\">\r\n            <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Language Name\" class=\"edit_input\" [(ngModel)]=\"editLanguageName\">\r\n          </div>\r\n          <div class=\"action_container\">\r\n            <span (click)=\"saveLanguage(language.language_id)\">Save</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"noResult\" *ngIf=\"languageList.length == 0\">\r\n      <span *ngIf=\"searchInput == ''\">No language added!</span>\r\n      <span *ngIf=\"searchInput != ''\">No search result found!</span>\r\n    </div>\r\n  </section>\r\n\r\n\r\n\r\n</section>"

/***/ }),

/***/ "./src/app/components/library-management/masters/masters.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  background: #f9f9f9; }\n\nhr {\n  margin-top: 10px;\n  margin-bottom: 10px;\n  border: 0;\n  border-top: 1px solid #eee; }\n\n.master_list .master_list_container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  width: 100%;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between; }\n\n.master_list .master_list_container .master_menu {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    -webkit-box-pack: start;\n        -ms-flex-pack: start;\n            justify-content: flex-start; }\n\n.master_list .master_list_container .master_list_item {\n    width: auto; }\n\n.master_list .master_list_container .master_list_item .master_list_btn {\n      background: white;\n      color: #9b9b9b;\n      padding: 10px;\n      text-align: center;\n      border: 1px solid #d1d1d1; }\n\n.master_list .master_list_container .master_list_item .active {\n      background: #1984f6;\n      color: white;\n      border: 1px solid #1984f6; }\n\n.master_list .master_list_container .search-filter-wrapper .normal-field {\n    padding: 7px 10px;\n    border: 1px solid #ccc;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    margin: 0;\n    float: left;\n    height: 35px;\n    font-size: 14px;\n    border-radius: 4px; }\n\n.master_list .master_list_container #item1 {\n    border-top-left-radius: 4px;\n    border-bottom-left-radius: 4px; }\n\n.master_list .master_list_container #item6 {\n    border-top-right-radius: 4px;\n    border-bottom-right-radius: 4px; }\n\n.middle_section {\n  margin-top: 10px;\n  width: 100%;\n  margin-bottom: 20px; }\n\n.middle_section .add_container {\n    background: #eeeeee;\n    border-top-left-radius: 4px;\n    border-top-right-radius: 4px;\n    padding: 5px 10px;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    position: relative; }\n\n.middle_section .add_container .main_name_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 35%; }\n\n.middle_section .add_container .name_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      color: #3e3d4a;\n      width: 45%;\n      position: relative; }\n\n.middle_section .add_container .name_container .fa-sort-desc {\n        position: absolute;\n        left: 175px;\n        top: 25px;\n        background: white;\n        cursor: pointer;\n        padding-left: 10px;\n        padding-bottom: 5px; }\n\n.middle_section .add_container .name_container .add_input {\n        background: white;\n        border-radius: 4px;\n        padding: 5px 10px;\n        border: 1px solid #bdbdbd;\n        width: 35%; }\n\n.middle_section .add_container .name_container ::-webkit-input-placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: #bdbdbd; }\n\n.middle_section .add_container .name_container :-ms-input-placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: #bdbdbd; }\n\n.middle_section .add_container .name_container ::-ms-input-placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: #bdbdbd; }\n\n.middle_section .add_container .name_container ::placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: #bdbdbd; }\n\n.middle_section .add_container .add_btn button {\n      border: 1px solid #1283f4;\n      color: #1283f4;\n      border-radius: 4px;\n      padding: 5px 10px;\n      font-weight: 600;\n      background: white;\n      margin-top: 20px; }\n\n.middle_section .add_container .category_suggestions_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n      flex-direction: column;\n      position: absolute;\n      top: 57px;\n      left: 10px;\n      background: white;\n      width: 15.5%;\n      border-radius: 4px;\n      overflow-y: auto;\n      height: 200px;\n      -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n              box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16); }\n\n.middle_section .add_container .category_suggestions_container .category_suggestions_item {\n        width: 100%;\n        text-align: left;\n        font-size: 14px;\n        color: black;\n        padding: 5px;\n        cursor: pointer; }\n\n.middle_section .add_container .category_suggestions_container .category_suggestions_item span {\n          width: 100%; }\n\n.middle_section .add_container .category_suggestions_container .category_suggestions_item:hover {\n        background: #1283f4;\n        color: white; }\n\n.middle_section .added_list_container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    border-bottom-left-radius: 4px;\n    border-bottom-right-radius: 4px;\n    -webkit-box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.16);\n            box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.16);\n    background-color: #ffffff; }\n\n.middle_section .added_list_container .added_list_item {\n      padding: 10px;\n      border-bottom: 1px solid #f9f9f9;\n      width: 100%; }\n\n.middle_section .added_list_container .added_list_item .value_container {\n        width: 50%;\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row; }\n\n.middle_section .added_list_container .added_list_item .value_container .edit_input {\n          background: white;\n          border-radius: 4px;\n          padding: 5px 10px;\n          border: 1px solid #bdbdbd; }\n\n.middle_section .added_list_container .added_list_item .value_container ::-webkit-input-placeholder {\n          /* Chrome, Firefox, Opera, Safari 10.1+ */\n          color: #bdbdbd; }\n\n.middle_section .added_list_container .added_list_item .value_container :-ms-input-placeholder {\n          /* Chrome, Firefox, Opera, Safari 10.1+ */\n          color: #bdbdbd; }\n\n.middle_section .added_list_container .added_list_item .value_container ::-ms-input-placeholder {\n          /* Chrome, Firefox, Opera, Safari 10.1+ */\n          color: #bdbdbd; }\n\n.middle_section .added_list_container .added_list_item .value_container ::placeholder {\n          /* Chrome, Firefox, Opera, Safari 10.1+ */\n          color: #bdbdbd; }\n\n.middle_section .added_list_container .added_list_item .value_item1, .middle_section .added_list_container .added_list_item .value_item2 {\n        width: 32%;\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        -webkit-box-pack: justify;\n            -ms-flex-pack: justify;\n                justify-content: space-between; }\n\n.middle_section .added_list_container .added_list_item .value_item1 i, .middle_section .added_list_container .added_list_item .value_item2 i {\n          cursor: pointer;\n          margin: 0px 5px; }\n\n.middle_section .added_list_container .added_list_item .action_container .add_sub_cat {\n        border: none;\n        background: white;\n        color: #9b9b9b;\n        font-size: 12px; }\n\n.middle_section .added_list_container .added_list_item .action_container .add_sub_cat i {\n          color: #1283f4; }\n\n.middle_section .added_list_container .added_list_item .action_container i {\n        cursor: pointer;\n        margin: 0px 5px; }\n\n.middle_section .added_list_container .added_list_item .action_container span {\n        color: #1283f4;\n        cursor: pointer;\n        margin: 0px 5px; }\n\n.middle_section .added_list_container .new_sub_cat {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      -webkit-box-pack: justify;\n          -ms-flex-pack: justify;\n              justify-content: space-between;\n      padding: 10px;\n      padding-left: 0px;\n      width: 97%;\n      margin-left: 17%; }\n\n.middle_section .added_list_container .new_sub_cat .new_sub_cat_item {\n        width: 20%; }\n\n.middle_section .added_list_container .new_sub_cat .new_sub_cat_item .edit_input {\n          background: white;\n          border-radius: 4px;\n          padding: 5px 10px;\n          border: 1px solid #bdbdbd;\n          width: 80%; }\n\n.middle_section .added_list_container .new_sub_cat .new_sub_cat_action_item {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        width: 25.5%; }\n\n.middle_section .added_list_container .new_sub_cat .new_sub_cat_action_item .new_cat_save_btn {\n          color: #1283f4;\n          border: 1px solid #1283f4;\n          text-align: center;\n          padding: 5px 10px;\n          background: white;\n          margin-right: 10px; }\n\n.middle_section .added_list_container .new_sub_cat .new_sub_cat_action_item .new_cat_cancel_btn {\n          color: #9b9b9b;\n          border: 1px solid #9b9b9b;\n          text-align: center;\n          padding: 5px 10px;\n          background: white; }\n\n.middle_section .noResult {\n    width: 100%;\n    text-align: center;\n    font-weight: 600;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    margin-top: 20px;\n    color: #9b9b9b;\n    font-size: 16px; }\n\n.middle_section .edit_com {\n    display: none;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between; }\n\n.middle_section .display_com {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between; }\n\n::ng-deep bs-datepicker-container, bs-daterangepicker-container {\n  left: 850 !important; }\n"

/***/ }),

/***/ "./src/app/components/library-management/masters/masters.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return MastersComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_library_master_masters_service__ = __webpack_require__("./src/app/services/library/master/masters.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var MastersComponent = /** @class */ (function () {
    function MastersComponent(router, auth, commonService, appC, masterService) {
        this.router = router;
        this.auth = auth;
        this.commonService = commonService;
        this.appC = appC;
        this.masterService = masterService;
        this.currentSectionName = '';
        this.searchInput = '';
        this.isRippleLoad = false;
        this.multiClickDisabled = false;
        // FOR Category and Subcategory
        this.categorySuggestions = false;
        this.newSubCat = false;
        this.categoryName = '';
        this.subcategoryName = '';
        this.categorySubCatList = [];
        this.editCategoryName = '';
        this.editSubCategoryName = '';
        this.selectedRowForCat = '';
        this.subcatEdit = false;
        // For Subject
        this.subjectList = [];
        this.subjectName = '';
        this.editSubjectName = '';
        this.selectedRowForSubject = '';
        // For Publication
        this.publicationName = '';
        this.publicationList = [];
        this.editPublicationName = '';
        this.selectedRowForPublication = '';
        // For Author
        this.authorName = '';
        this.authorList = [];
        this.editAuthorName = '';
        this.selectedRowForAuthor = '';
        // For Reference
        this.referenceName = '';
        this.referenceList = [];
        this.editReferenceName = '';
        this.selectedRowForReference = '';
        // For Language
        this.languageName = '';
        this.languageList = [];
        this.editLanguageName = '';
        this.selectedRowForLanguage = '';
    }
    MastersComponent.prototype.ngOnInit = function () {
        this.changeMasterCategory('item1', 'for_category');
    };
    MastersComponent.prototype.changeMasterCategory = function (itemId, section_name) {
        for (var i = 1; i <= 6; i++) {
            document.getElementById("item" + i).classList.remove("active");
        }
        document.getElementById(itemId).classList.add("active");
        for (var i = 0; i < 6; i++) {
            document.getElementsByClassName("middle_section")[i].classList.add("hide");
        }
        document.getElementById(section_name).classList.remove("hide");
        this.searchInput = '';
        this.getCategory(section_name);
    };
    MastersComponent.prototype.searchInList = function (search_string) {
        var _this = this;
        if (this.searchInput != '' && this.searchInput != null) {
            if (search_string.which <= 90 && search_string.which >= 48 || search_string.which == 8) {
                this.isRippleLoad = true;
                this.masterService.searchData(this.currentSectionName, this.searchInput).subscribe(function (response) {
                    var res;
                    res = response;
                    _this.isRippleLoad = false;
                    if (res.response != null) {
                        if (_this.currentSectionName.includes('category')) {
                            _this.categorySubCatList = res.response;
                        }
                        if (_this.currentSectionName.includes('subject')) {
                            _this.subjectList = res.response;
                        }
                        if (_this.currentSectionName.includes('publication')) {
                            _this.publicationList = res.response;
                        }
                        if (_this.currentSectionName.includes('author')) {
                            _this.authorList = res.response;
                        }
                        if (_this.currentSectionName.includes('reference')) {
                            _this.referenceList = res.response;
                        }
                        if (_this.currentSectionName.includes('language')) {
                            _this.languageList = res.response;
                        }
                    }
                    else {
                        console.log(res.errorResponse);
                    }
                });
            }
        }
        else {
            this.getCategory(this.currentSectionName);
        }
    };
    MastersComponent.prototype.getCategory = function (section_name) {
        if (section_name.includes('category')) {
            this.categoryName = "";
            this.subcategoryName = "";
            this.currentSectionName = 'category';
            this.getAllCategory();
            this.getAllParentCategory();
        }
        if (section_name.includes('subject')) {
            this.subjectName = "";
            this.currentSectionName = 'subject';
            this.getAllSubjects();
        }
        if (section_name.includes('publication')) {
            this.publicationName = "";
            this.currentSectionName = 'publication';
            this.getAllPublications();
        }
        if (section_name.includes('author')) {
            this.authorName = "";
            this.currentSectionName = 'author';
            this.getAllAuthors();
        }
        if (section_name.includes('reference')) {
            this.referenceName = "";
            this.currentSectionName = 'reference';
            this.getAllReferences();
        }
        if (section_name.includes('language')) {
            this.languageName = "";
            this.currentSectionName = 'language';
            this.getAllLanguages();
        }
    };
    MastersComponent.prototype.showCategorySuggestions = function (search_string) {
        this.categoryList = this.tempCatSubList;
        for (var i = 0; i < this.categoryList.length; i++) {
            if (this.categoryList[i].category_name.includes(search_string.key)) {
                i++;
            }
            else {
                this.categoryList.splice(i, 1);
            }
        }
        if (this.categoryList.length > 0) {
            this.categorySuggestions = true;
        }
        else {
            this.categorySuggestions = false;
        }
        if (this.categoryName == "" || this.categoryName == null) {
            this.categoryList = this.tempCatSubList;
            this.categorySuggestions = false;
        }
    };
    MastersComponent.prototype.showSuggestions = function () {
        if (this.categorySuggestions) {
            this.categorySuggestions = false;
        }
        else {
            this.categorySuggestions = true;
        }
    };
    MastersComponent.prototype.chooseCategory = function (cat_name) {
        this.categoryName = cat_name;
        this.categorySuggestions = false;
    };
    MastersComponent.prototype.addCatAndSubCat = function () {
        var _this = this;
        if (this.categoryName != '' && this.categoryName != null) {
            var obj = {
                "category_name": this.categoryName
            };
            if (this.subcategoryName != '' && this.subcategoryName != null) {
                this.addBulkCatAndSubCat();
            }
            else {
                this.isRippleLoad = true;
                this.multiClickDisabled = true;
                this.masterService.addCategory(obj).subscribe(function (response) {
                    var res;
                    res = response;
                    _this.multiClickDisabled = false;
                    _this.isRippleLoad = false;
                    if (res.response != null) {
                        _this.messageHandler('success', 'Category added successfully', '');
                        _this.categoryName = "";
                        _this.subcategoryName = "";
                        _this.categorySuggestions = false;
                        _this.getAllCategory();
                        _this.getAllParentCategory();
                    }
                    else {
                        if (res.errorResponse[0].errorCode == 700) {
                            _this.messageHandler('error', 'Category already exists', '');
                        }
                        _this.categorySuggestions = false;
                        console.log(res.errorResponse);
                    }
                });
            }
        }
        else {
            this.messageHandler('error', 'Enter category name', '');
        }
    };
    MastersComponent.prototype.addBulkCatAndSubCat = function () {
        var _this = this;
        var obj = {
            "category_name": this.categoryName,
            "sub_category_name": this.subcategoryName
        };
        this.isRippleLoad = true;
        this.multiClickDisabled = true;
        this.masterService.addCatAndSubCat(obj).subscribe(function (response) {
            var res;
            res = response;
            _this.multiClickDisabled = false;
            _this.isRippleLoad = false;
            if (res.response != null) {
                _this.messageHandler('success', 'Category added successfully', '');
                _this.categoryName = "";
                _this.subcategoryName = "";
                _this.categorySuggestions = false;
                _this.getAllCategory();
                _this.getAllParentCategory();
            }
            else {
                if (res.errorResponse[0].errorCode == 700) {
                    _this.messageHandler('error', 'Category already exists', '');
                }
                _this.categorySuggestions = false;
                console.log(res.errorResponse[0].errorCode == 700);
            }
        });
    };
    MastersComponent.prototype.getAllCategory = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.masterService.getAllCategory().subscribe(function (response) {
            var res;
            res = response;
            _this.isRippleLoad = false;
            if (res.response != null) {
                _this.categorySubCatList = res.response;
                _this.tempCatSubList = res.response;
                console.log(_this.categorySubCatList);
            }
            else {
                console.log(res.errorResponse);
            }
        });
    };
    MastersComponent.prototype.getAllParentCategory = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.masterService.getAllParentCategory().subscribe(function (response) {
            var res;
            res = response;
            _this.isRippleLoad = false;
            if (res.response != null) {
                _this.categoryList = res.response;
                _this.tempCatSubList = res.response;
            }
            else {
                console.log(res.errorResponse);
            }
        });
    };
    MastersComponent.prototype.editCat = function (category, row_no) {
        if (category.sub_category_id != null && category.sub_category_name != null) {
            this.subcatEdit = true;
            this.editSubCategoryName = category.sub_category_name;
        }
        else {
            this.subcatEdit = false;
        }
        this.categorySuggestions = false;
        if (this.selectedRowForCat !== "") {
            //console.log(this.selectedRow);
            document.getElementById(("cat_row_dis" + this.selectedRowForCat).toString()).style.display = "flex";
            document.getElementById(("cat_row_edit" + this.selectedRowForCat).toString()).style.display = "none";
        }
        this.selectedRowForCat = row_no;
        document.getElementById(("cat_row_dis" + row_no).toString()).style.display = "none";
        document.getElementById(("cat_row_edit" + row_no).toString()).style.display = "flex";
        this.editCategoryName = category.category_name;
    };
    MastersComponent.prototype.saveCat = function (cat_id, subcat_id) {
        var _this = this;
        if (subcat_id != null) {
            if (this.editCategoryName != '' && this.editCategoryName != null) {
                var obj = {
                    "category_name": this.editCategoryName,
                    "category_id": cat_id,
                    "sub_category_name": this.editSubCategoryName,
                    "sub_category_id": subcat_id
                };
                this.isRippleLoad = true;
                this.masterService.updateCatSubCat(obj).subscribe(function (response) {
                    var res;
                    res = response;
                    _this.categorySuggestions = false;
                    _this.isRippleLoad = false;
                    if (res.response != null) {
                        _this.messageHandler('success', 'Category updated successfully', '');
                        _this.editCategoryName = "";
                        _this.editSubCategoryName = "";
                        _this.getAllCategory();
                    }
                    else {
                        if (res.errorResponse[0].errorCode == 700) {
                            _this.messageHandler('error', 'Category already exists', '');
                        }
                        console.log(res.errorResponse);
                    }
                });
            }
            else {
                this.messageHandler('error', 'Enter category name', '');
            }
        }
        else {
            if (this.editCategoryName != '' && this.editCategoryName != null) {
                var obj = {
                    "category_name": this.editCategoryName,
                    "category_id": cat_id
                };
                this.isRippleLoad = true;
                this.masterService.updateCat(obj).subscribe(function (response) {
                    var res;
                    res = response;
                    _this.categorySuggestions = false;
                    _this.isRippleLoad = false;
                    if (res.response != null) {
                        _this.messageHandler('success', 'Category updated successfully', '');
                        _this.editCategoryName = "";
                        _this.editSubCategoryName = "";
                        _this.getAllCategory();
                    }
                    else {
                        if (res.errorResponse[0].errorCode == 700) {
                            _this.messageHandler('error', 'Category already exists', '');
                        }
                        console.log(res.errorResponse);
                    }
                });
            }
            else {
                this.messageHandler('error', 'Enter category name', '');
            }
        }
    };
    MastersComponent.prototype.deleteCat = function (category) {
        console.log(category);
        if (category.sub_category_id != null) {
            this.delete(category.sub_category_id, 'category');
        }
        else {
            this.delete(category.category_id, 'category');
        }
    };
    // For Subject
    MastersComponent.prototype.getAllSubjects = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.masterService.getAllSubjects().subscribe(function (response) {
            var res;
            res = response;
            _this.isRippleLoad = false;
            if (res.response != null) {
                _this.subjectList = res.response;
                console.log(_this.subjectList);
            }
            else {
                console.log(res.errorResponse);
            }
        });
    };
    MastersComponent.prototype.addSubject = function () {
        var _this = this;
        if (this.subjectName != '' && this.subjectName != null) {
            var obj = {
                "subject_name": this.subjectName
            };
            this.isRippleLoad = true;
            this.multiClickDisabled = true;
            this.masterService.addSubject(obj).subscribe(function (response) {
                var res;
                res = response;
                _this.multiClickDisabled = false;
                _this.isRippleLoad = false;
                if (res.response != null) {
                    _this.messageHandler('success', 'Subject added successfully', '');
                    _this.subjectName = "";
                    _this.getAllSubjects();
                }
                else {
                    if (res.errorResponse[0].errorCode == 700) {
                        _this.messageHandler('error', 'Subject already exists', '');
                    }
                    console.log(res.errorResponse);
                }
            });
        }
        else {
            this.messageHandler('error', 'Enter subject Name', '');
        }
    };
    MastersComponent.prototype.editSubject = function (subject, row_no) {
        if (this.selectedRowForSubject !== "") {
            //console.log(this.selectedRow);
            document.getElementById(("subject_row_dis" + this.selectedRowForSubject).toString()).style.display = "flex";
            document.getElementById(("subject_row_edit" + this.selectedRowForSubject).toString()).style.display = "none";
        }
        this.selectedRowForSubject = row_no;
        document.getElementById(("subject_row_dis" + row_no).toString()).style.display = "none";
        document.getElementById(("subject_row_edit" + row_no).toString()).style.display = "flex";
        this.editSubjectName = subject.subject_name;
    };
    MastersComponent.prototype.saveSubject = function (subject_id) {
        var _this = this;
        if (this.editSubjectName != '' && this.editSubjectName != null) {
            var obj = {
                "subject_name": this.editSubjectName,
                "subject_id": subject_id
            };
            this.isRippleLoad = true;
            this.masterService.updateSubject(obj).subscribe(function (response) {
                var res;
                res = response;
                _this.isRippleLoad = false;
                if (res.response != null) {
                    _this.messageHandler('success', 'Subject updated successfully', '');
                    _this.editSubjectName = "";
                    _this.getAllSubjects();
                }
                else {
                    console.log(res.errorResponse);
                }
            });
        }
        else {
            this.messageHandler('error', 'Enter subject name', '');
        }
    };
    // FOR PUBLICATION
    MastersComponent.prototype.getAllPublications = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.masterService.getAllPublications().subscribe(function (response) {
            var res;
            res = response;
            _this.isRippleLoad = false;
            if (res.response != null) {
                _this.publicationList = res.response;
            }
            else {
                console.log(res.errorResponse);
            }
        });
    };
    MastersComponent.prototype.addPublication = function () {
        var _this = this;
        if (this.publicationName != '' && this.publicationName != null) {
            var obj = {
                "publication_name": this.publicationName
            };
            this.isRippleLoad = true;
            this.multiClickDisabled = true;
            this.masterService.addPublication(obj).subscribe(function (response) {
                var res;
                res = response;
                _this.multiClickDisabled = false;
                _this.isRippleLoad = false;
                if (res.response != null) {
                    _this.messageHandler('success', 'Publication added successfully', '');
                    _this.publicationName = "";
                    _this.getAllPublications();
                }
                else {
                    if (res.errorResponse[0].errorCode == 700) {
                        _this.messageHandler('error', 'Publication already exists', '');
                    }
                    console.log(res.errorResponse);
                }
            });
        }
        else {
            this.messageHandler('error', 'Enter publication name', '');
        }
    };
    MastersComponent.prototype.editPublication = function (publication, row_no) {
        if (this.selectedRowForPublication !== "") {
            //console.log(this.selectedRow);
            document.getElementById(("publication_row_dis" + this.selectedRowForPublication).toString()).style.display = "flex";
            document.getElementById(("publication_row_edit" + this.selectedRowForPublication).toString()).style.display = "none";
        }
        this.selectedRowForPublication = row_no;
        document.getElementById(("publication_row_dis" + row_no).toString()).style.display = "none";
        document.getElementById(("publication_row_edit" + row_no).toString()).style.display = "flex";
        this.editPublicationName = publication.publication_name;
    };
    MastersComponent.prototype.savePublication = function (publication_id) {
        var _this = this;
        if (this.editPublicationName != '' && this.editPublicationName != null) {
            var obj = {
                "publication_name": this.editPublicationName,
                "publication_id": publication_id
            };
            this.isRippleLoad = true;
            this.masterService.updatePublication(obj).subscribe(function (response) {
                var res;
                res = response;
                _this.isRippleLoad = false;
                if (res.response != null) {
                    _this.messageHandler('success', 'Publication updated successfully', '');
                    _this.editPublicationName = "";
                    _this.getAllPublications();
                }
                else {
                    console.log(res.errorResponse);
                }
            });
        }
        else {
            this.messageHandler('error', 'Enter publication name', '');
        }
    };
    // FOR AUTHOR
    MastersComponent.prototype.getAllAuthors = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.masterService.getAllAuthors().subscribe(function (response) {
            var res;
            res = response;
            _this.isRippleLoad = false;
            if (res.response != null) {
                _this.authorList = res.response;
            }
            else {
                console.log(res.errorResponse);
            }
        });
    };
    MastersComponent.prototype.addAuthor = function () {
        var _this = this;
        if (this.authorName != '' && this.authorName != null) {
            var obj = {
                "author_name": this.authorName
            };
            this.isRippleLoad = true;
            this.multiClickDisabled = true;
            this.masterService.addAuthor(obj).subscribe(function (response) {
                var res;
                res = response;
                _this.isRippleLoad = false;
                _this.multiClickDisabled = false;
                if (res.response != null) {
                    _this.messageHandler('success', 'Author added successfully', '');
                    _this.authorName = "";
                    _this.getAllAuthors();
                }
                else {
                    if (res.errorResponse[0].errorCode == 700) {
                        _this.messageHandler('error', 'Author already exists', '');
                    }
                    console.log(res.errorResponse);
                }
            });
        }
        else {
            this.messageHandler('error', 'Enter author name', '');
        }
    };
    MastersComponent.prototype.editAuthor = function (author, row_no) {
        if (this.selectedRowForAuthor !== "") {
            //console.log(this.selectedRow);
            document.getElementById(("author_row_dis" + this.selectedRowForAuthor).toString()).style.display = "flex";
            document.getElementById(("author_row_edit" + this.selectedRowForAuthor).toString()).style.display = "none";
        }
        this.selectedRowForAuthor = row_no;
        document.getElementById(("author_row_dis" + row_no).toString()).style.display = "none";
        document.getElementById(("author_row_edit" + row_no).toString()).style.display = "flex";
        this.editAuthorName = author.author_name;
    };
    MastersComponent.prototype.saveAuthor = function (author_id) {
        var _this = this;
        if (this.editAuthorName != '' && this.editAuthorName != null) {
            var obj = {
                "author_name": this.editAuthorName,
                "author_id": author_id
            };
            this.isRippleLoad = true;
            this.masterService.updateAuthor(obj).subscribe(function (response) {
                var res;
                res = response;
                _this.isRippleLoad = false;
                if (res.response != null) {
                    _this.messageHandler('success', 'Author updated successfully', '');
                    _this.editAuthorName = "";
                    _this.getAllAuthors();
                }
                else {
                    console.log(res.errorResponse);
                }
            });
        }
        else {
            this.messageHandler('error', 'Enter author name', '');
        }
    };
    // FOR REFERENCES
    MastersComponent.prototype.getAllReferences = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.masterService.getAllReferences().subscribe(function (response) {
            var res;
            res = response;
            _this.isRippleLoad = false;
            if (res.response != null) {
                _this.referenceList = res.response;
            }
            else {
                console.log(res.errorResponse);
            }
        });
    };
    MastersComponent.prototype.addReference = function () {
        var _this = this;
        if (this.referenceName != '' && this.referenceName != null) {
            var obj = {
                "reference_name": this.referenceName
            };
            this.isRippleLoad = true;
            this.multiClickDisabled = true;
            this.masterService.addReference(obj).subscribe(function (response) {
                var res;
                res = response;
                _this.isRippleLoad = false;
                _this.multiClickDisabled = false;
                if (res.response != null) {
                    _this.messageHandler('success', 'Reference added successfully', '');
                    _this.referenceName = "";
                    _this.getAllReferences();
                }
                else {
                    if (res.errorResponse[0].errorCode == 700) {
                        _this.messageHandler('error', 'Reference already exists', '');
                    }
                    console.log(res.errorResponse);
                }
            });
        }
        else {
            this.messageHandler('error', 'Enter reference name', '');
        }
    };
    MastersComponent.prototype.editReference = function (reference, row_no) {
        if (this.selectedRowForReference !== "") {
            //console.log(this.selectedRow);
            document.getElementById(("reference_row_dis" + this.selectedRowForReference).toString()).style.display = "flex";
            document.getElementById(("reference_row_edit" + this.selectedRowForReference).toString()).style.display = "none";
        }
        this.selectedRowForReference = row_no;
        document.getElementById(("reference_row_dis" + row_no).toString()).style.display = "none";
        document.getElementById(("reference_row_edit" + row_no).toString()).style.display = "flex";
        this.editReferenceName = reference.reference_name;
    };
    MastersComponent.prototype.saveReference = function (reference_id) {
        var _this = this;
        if (this.editReferenceName != '' && this.editReferenceName != null) {
            var obj = {
                "reference_name": this.editReferenceName,
                "reference_id": reference_id
            };
            this.isRippleLoad = true;
            this.masterService.updateReference(obj).subscribe(function (response) {
                var res;
                res = response;
                _this.isRippleLoad = false;
                if (res.response != null) {
                    _this.messageHandler('success', 'Reference updated successfully', '');
                    _this.editReferenceName = "";
                    _this.getAllReferences();
                }
                else {
                    console.log(res.errorResponse);
                }
            });
        }
        else {
            this.messageHandler('error', 'Enter reference name', '');
        }
    };
    // For Language
    MastersComponent.prototype.getAllLanguages = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.masterService.getAllLanguages().subscribe(function (response) {
            var res;
            res = response;
            if (res.response != null) {
                _this.isRippleLoad = false;
                _this.languageList = res.response;
            }
            else {
                _this.isRippleLoad = false;
                console.log(res.errorResponse);
            }
        });
    };
    MastersComponent.prototype.addLanguage = function () {
        var _this = this;
        if (this.languageName != '' && this.languageName != null) {
            var obj = {
                "language_name": this.languageName
            };
            this.isRippleLoad = true;
            this.multiClickDisabled = true;
            this.masterService.addLanguage(obj).subscribe(function (response) {
                var res;
                res = response;
                _this.multiClickDisabled = false;
                if (res.response != null) {
                    _this.isRippleLoad = false;
                    _this.messageHandler('success', 'Language added successfully', '');
                    _this.languageName = "";
                    _this.getAllLanguages();
                }
                else {
                    _this.isRippleLoad = false;
                    if (res.errorResponse[0].errorCode == 700) {
                        _this.messageHandler('error', 'Language already exists', '');
                    }
                    console.log(res.errorResponse);
                }
            });
        }
        else {
            this.messageHandler('error', 'Enter language name', '');
        }
    };
    MastersComponent.prototype.editLanguage = function (language, row_no) {
        if (this.selectedRowForLanguage !== "") {
            //console.log(this.selectedRow);
            document.getElementById(("language_row_dis" + this.selectedRowForLanguage).toString()).style.display = "flex";
            document.getElementById(("language_row_edit" + this.selectedRowForLanguage).toString()).style.display = "none";
        }
        this.selectedRowForLanguage = row_no;
        document.getElementById(("language_row_dis" + row_no).toString()).style.display = "none";
        document.getElementById(("language_row_edit" + row_no).toString()).style.display = "flex";
        this.editLanguageName = language.language_name;
    };
    MastersComponent.prototype.saveLanguage = function (language_id) {
        var _this = this;
        if (this.editLanguageName != '' && this.editLanguageName != null) {
            var obj = {
                "language_name": this.editLanguageName,
                "language_id": language_id
            };
            this.isRippleLoad = true;
            this.masterService.updateLanguage(obj).subscribe(function (response) {
                var res;
                res = response;
                if (res.response != null) {
                    _this.isRippleLoad = false;
                    _this.messageHandler('success', 'Language updated successfully', '');
                    _this.editLanguageName = "";
                    _this.getAllLanguages();
                }
                else {
                    _this.isRippleLoad = false;
                    console.log(res.errorResponse);
                }
            });
        }
        else {
            this.messageHandler('error', 'Enter language name', '');
        }
    };
    MastersComponent.prototype.delete = function (id, key_name) {
        var _this = this;
        var name = key_name.charAt(0).toUpperCase() + key_name.slice(1);
        this.isRippleLoad = true;
        this.masterService.delete(id, key_name).subscribe(function (response) {
            var res;
            res = response;
            if (res.response != null) {
                _this.isRippleLoad = false;
                _this.messageHandler('success', name + ' deleted successfully', '');
                if (key_name.includes('category')) {
                    _this.categoryName = "";
                    _this.subcategoryName = "";
                    _this.getAllCategory();
                }
                if (key_name.includes('subject')) {
                    _this.subjectName = "";
                    _this.getAllSubjects();
                }
                if (key_name.includes('publication')) {
                    _this.publicationName = "";
                    _this.getAllPublications();
                }
                if (key_name.includes('author')) {
                    _this.authorName = "";
                    _this.getAllAuthors();
                }
                if (key_name.includes('reference')) {
                    _this.referenceName = "";
                    _this.getAllReferences();
                }
                if (key_name.includes('language')) {
                    _this.languageName = "";
                    _this.getAllLanguages();
                }
            }
            else if (res.errorResponse[0].errorCode == 3000) {
                _this.messageHandler('error', name + ' is linked with data and cannot be deleted', '');
                _this.isRippleLoad = false;
            }
            else {
                _this.isRippleLoad = false;
                console.log(res.errorResponse);
            }
        });
    };
    MastersComponent.prototype.messageHandler = function (type, title, body) {
        var obj = {
            type: type,
            title: title,
            body: body
        };
        this.appC.popToast(obj);
    };
    MastersComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-masters',
            template: __webpack_require__("./src/app/components/library-management/masters/masters.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/masters/masters.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__services_common_service__["a" /* CommonServiceFactory */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_5__services_library_master_masters_service__["a" /* MastersService */]])
    ], MastersComponent);
    return MastersComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/return-book/return-book.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n\r\n<section *ngIf=\"!bookSuggestion\">\r\n  <div class=\"search_bar_container\">\r\n    <input type=\"text\" name=\"\" value=\"\" placeholder=\"Search by Borrower/Book issued\" class=\"search_box\"  (keyup)=\"searchInList($event)\" [(ngModel)]=\"searchInput\">\r\n    <i class=\"fa fa-search\" aria-hidden=\"true\"></i>\r\n    <!-- <i class=\"fa fa-times\" aria-hidden=\"true\" (click)=\"clearFilter()\" ></i> -->\r\n    <!-- <i class=\"fa fa-sort-desc\" aria-hidden=\"true\" (click)=\"showFilter()\"></i> -->\r\n    <!-- <span *ngIf=\"!searchResult\">&#8701; Search here! </span> -->\r\n  </div>\r\n\r\n  <!-- FILTER -->\r\n  <!-- <div class=\"search_box_filter_container\" *ngIf=\"filter\">\r\n\r\n    <div class=\"filter_item\">\r\n      <div class=\"label_container\">\r\n        <span style=\"top: 10px;\">Book Title</span>\r\n      </div>\r\n      <div class=\"input_container\">\r\n        <input type=\"text\" name=\"\" value=\"\" placeholder=\"Enter Book Name\" [(ngModel)]=\"searchTitle\">\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"filter_item\">\r\n      <div class=\"label_container\">\r\n        <span>Author</span>\r\n      </div>\r\n      <div class=\"input_container\">\r\n        <select class=\"add_input1\" name=\"\" [(ngModel)]=\"searchAuthorId\">\r\n          <option value=\"-1\" style=\"color: #cfcfcf;\">Select Author Name</option>\r\n          <option [value]=\"author.author_id\" *ngFor=\"let author of authorList let i = index\">{{author.author_name}}</option>\r\n        </select>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"filter_item\">\r\n      <div class=\"label_container\">\r\n        <span>Category</span>\r\n      </div>\r\n      <div class=\"input_container\">\r\n        <select class=\"add_input1\" name=\"\" (ngModelChange)=\"getSubCategory($event)\" [(ngModel)]=\"searchCategoryId\">\r\n          <option value=\"-1\" style=\"color: #cfcfcf;\">Select Category Name</option>\r\n          <option [value]=\"category.category_id\" [attr.id]=\"category.category_id\" *ngFor=\"let category of categoryList let i = index\">{{category.category_name}}</option>\r\n        </select>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"filter_item\">\r\n      <div class=\"label_container\">\r\n        <span>Sub-Category</span>\r\n      </div>\r\n      <div class=\"input_container\">\r\n        <select class=\"add_input1\" name=\"\" [(ngModel)]=\"searchSubcategoryId\">\r\n          <option value=\"-1\" style=\"color: #cfcfcf;\">Select Sub-Category Name</option>\r\n          <option [value]=\"subCategory.category_id\" *ngFor=\"let subCategory of subcategoryList let i = index\">{{subCategory.category_name}}</option>\r\n        </select>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"filter_item\">\r\n      <div class=\"label_container\">\r\n        <span>Subject</span>\r\n      </div>\r\n      <div class=\"input_container\">\r\n        <select class=\"add_input1\" name=\"\" [(ngModel)]=\"searchSubjectId\">\r\n          <option value=\"-1\" style=\"color: #cfcfcf;\">Select Subject Name</option>\r\n          <option [value]=\"subject.subject_id\" *ngFor=\"let subject of subjectList let i = index\">{{subject.subject_name}}</option>\r\n        </select>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"filter_item\">\r\n      <div class=\"label_container\">\r\n        <span>Publication</span>\r\n      </div>\r\n      <div class=\"input_container\">\r\n        <select class=\"add_input1\" name=\"\" [(ngModel)]=\"searchPublicationId\">\r\n          <option value=\"-1\" style=\"color: #cfcfcf;\">Select Publication Name</option>\r\n          <option [value]=\"publication.publication_id\" *ngFor=\"let publication of publicationList let i = index\">{{publication.publication_name}}</option>\r\n        </select>\r\n      </div>\r\n    </div>\r\n\r\n\r\n    <div class=\"filter_item\">\r\n      <div class=\"label_container\">\r\n        <span>Language</span>\r\n      </div>\r\n      <div class=\"input_container\">\r\n        <select class=\"add_input2\" name=\"\" [(ngModel)]=\"searchLangId\">\r\n          <option value=\"-1\" style=\"color: #cfcfcf;\">Select Language</option>\r\n          <option [value]=\"language.language_id\" *ngFor=\"let language of languageList let i = index\">{{language.language_name}}</option>\r\n        </select>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"action_btn_container pull-right\">\r\n      <button type=\"button\" name=\"button\" class=\"reset_btn\" (click)=\"resetFilter()\">Reset</button>\r\n      <button type=\"button\" name=\"button\" class=\"search_btn\" (click)=\"advanceSearch()\">Search</button>\r\n    </div>\r\n\r\n  </div> -->\r\n\r\n  <!-- Suggestion -->\r\n  <div class=\"suggestions_container\" *ngIf=\"suggestion\">\r\n    <div class=\"suggestion\">\r\n\r\n      <div class=\"suggestion_item\" *ngFor=\"let suggestion of suggestionList.libraryBookDTOs let i = index\" (click)=\"getIssuedBooksByBook(suggestion.book_id, suggestion.title)\">\r\n        <div class=\"img_container\">\r\n          <img src=\"./assets/images/library/gray_book.svg\" alt=\"\">\r\n        </div>\r\n        <div class=\"book_details\">\r\n          <div class=\"name_container\">\r\n            <span>{{suggestion.title}}</span>\r\n          </div>\r\n          <div class=\"book_more_info\">\r\n            <span>Publication - {{ suggestion.publications.publication_name | slice:0:12 }}</span>\r\n            <span>&nbsp;&nbsp;|&nbsp;&nbsp;</span>\r\n            <span>Author(s) - <span *ngFor=\"let author of suggestion.authorObjects | slice:0:1;\">{{author.author_name | slice:0:12}} &nbsp; </span></span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"suggestion_item\" *ngFor=\"let suggestion of suggestionList.students let i = index\" (click)=\"getIssuedBooksByStudent(suggestion.student_id, suggestion.student_name)\">\r\n        <div class=\"img_container\">\r\n          <img src=\"./assets/images/library/profile.svg\" alt=\"\">\r\n        </div>\r\n        <div class=\"book_details\">\r\n          <div class=\"name_container\">\r\n            <span>{{suggestion.student_name}}</span>\r\n          </div>\r\n          <div class=\"book_more_info\">\r\n            <span>Mobile No. - {{suggestion.student_phone}}</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n  </div>\r\n\r\n</section>\r\n\r\n<section *ngIf=\"!searchResult\">\r\n  <div class=\"illustartion_container\" (close)=\"closeSuggestions()\">\r\n    <img src=\"./assets/images/library/search_book.svg\" alt=\"\">\r\n  </div>\r\n</section>\r\n\r\n<hr *ngIf=\"searchResult\">\r\n\r\n\r\n<section *ngIf=\"searchResult\">\r\n  <div class=\"search_result_container\">\r\n    <div class=\"search_result_item\" *ngFor=\"let returnBook of returnBookData let p = index\">\r\n      <div class=\"sub_item_1_container\">\r\n        <div class=\"sub_item1\">\r\n          <img src=\"./assets/images/library/color_book.svg\" alt=\"\" class=\"book_icon\">\r\n          <div class=\"book_name_container\">\r\n            <span class=\"title\">Book Title</span>\r\n            <span class=\"book_name\">{{returnBook.book_complete_details.title}}</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"sub_item2\">\r\n          <img src=\"./assets/images/library/profile_color.svg\" alt=\"\" class=\"book_icon\">\r\n          <div class=\"book_name_container\">\r\n            <span class=\"title\">Borrower</span>\r\n            <span class=\"book_name\">{{returnBook.issued_book.student.student_name}}</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"sub_item3\">\r\n          <div class=\"book_name_container\">\r\n            <span class=\"title\">Mobile Number</span>\r\n            <span class=\"more_info\" style=\"font-weight: 600;\">{{returnBook.issued_book.student.student_phone}}</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"sub_item3\">\r\n          <div class=\"book_name_container\">\r\n            <span class=\"title\">ISBN No.</span>\r\n            <span class=\"more_info\" style=\"font-weight: 600;\">{{returnBook.book_complete_details.isbn_number}}</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"sub_item3\">\r\n          <div class=\"book_name_container\">\r\n            <span class=\"title\">Issued Date</span>\r\n            <span class=\"more_info\" style=\"font-weight: 600;\">{{returnBook.issued_book.issued_on | date: 'dd MMM yyyy'}}</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"sub_item3\">\r\n          <div class=\"book_name_container\">\r\n            <span class=\"title\">Return Date</span>\r\n            <span class=\"more_info\" style=\"font-weight: 600;\">{{returnBook.issued_book.to_return_on_date | date: 'dd MMM yyyy'}}</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"sub_item3\" style=\"text-align: right;\">\r\n          <span class=\"issue_span\" *ngIf=\"returnBook.issued_book.no_of_late_days == 0\">Issued</span>\r\n          <span class=\"overdue_span\" *ngIf=\"returnBook.issued_book.no_of_late_days != 0\">Overdue</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"sub_item_2_container\">\r\n        <div class=\"item\">\r\n          <div class=\"sub_item3\">\r\n            <div class=\"book_name_container\">\r\n              <span class=\"title\">Author</span>\r\n              <div class=\"\">\r\n                <span title=\"{{concatString(returnBook.book_complete_details.authorObjects)}}\">\r\n                  <span class=\"more_info\" *ngFor=\"let author of returnBook.book_complete_details.authorObjects | slice:start:end let i = index\">\r\n                    <span *ngIf=\"i < 2\">{{author.author_name | slice:0:10}}<span *ngIf=\"i == 0\">,&nbsp;</span>\r\n                      <span *ngIf=\"i < 3 && i == 1\">...</span>\r\n                    </span>\r\n                  </span>\r\n                </span>\r\n              </div>\r\n              <!-- <span class=\"more_info\">{{returnBook.book_complete_details.authorObjects}}</span> -->\r\n            </div>\r\n          </div>\r\n          <div class=\"sub_item3\">\r\n            <div class=\"book_name_container\">\r\n              <span class=\"title\">Publication</span>\r\n              <span class=\"more_info\">{{returnBook.book_complete_details.publications.publication_name}}</span>\r\n            </div>\r\n          </div>\r\n          <div class=\"sub_item3\">\r\n            <div class=\"book_name_container\">\r\n              <span class=\"title\">Subject</span>\r\n              <span class=\"more_info\">{{returnBook.book_complete_details.subject.subject_name}}</span>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"item_2\">\r\n          <button type=\"button\" name=\"button\" class=\"return_btn\" (click)=\"showReturnBook(returnBook)\">Return</button>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n\r\n<!-- POP UP -->\r\n\r\n<section *ngIf=\"returnBookPopup\">\r\n  <div class=\"return_book_pop_up_container\">\r\n    <div class=\"header_container\">\r\n      <span>Return Book</span>\r\n      <i class=\"fa fa-times\" aria-hidden=\"true\" (click)=\"closePopup()\"></i>\r\n    </div>\r\n    <div class=\"details_container\">\r\n      <div class=\"book_info_container\">\r\n        <div class=\"book_info_item1\">\r\n          <img src=\"./assets/images/library/color_book.svg\" alt=\"\" class=\"book_icon\">\r\n          <div class=\"book_name_container\">\r\n            <span class=\"title\">Book Title</span>\r\n            <span class=\"book_name\">{{returnBookTitle}}</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"book_info_item2\">\r\n          <div class=\"book_name_container\">\r\n            <span class=\"title\">Issued Date</span>\r\n            <span class=\"more_info\">{{returnBookIssuedDate}}</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"book_info_item2\">\r\n          <div class=\"book_name_container\">\r\n            <span class=\"title\">Return Date</span>\r\n            <span class=\"more_info\">{{returnBookReturnDate}}</span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"book_status_container\">\r\n        <span>Status of Book : </span>\r\n        <div class=\"field-checkbox-wrapper checkbox_container\">\r\n          <input type=\"checkbox\" value=\"lostBook\" name=\"lost\" class=\"form-checkbox\" [(ngModel)]=\"lostBook\">\r\n          <label for=\"lost\">Lost/Scrap</label>\r\n        </div>\r\n      </div>\r\n      <div class=\"return_info_container\" *ngIf=\"!lostBook\">\r\n        <div class=\"return_info_item\">\r\n          <span>Returned Date</span>\r\n          <input type=\"text\" name=\"\" value=\"\" readonly [(ngModel)]=\"tempReturnDate\" (click)=\"openCalendar('returnDate')\">\r\n          <i class=\"fa fa-calendar\" style=\"cursor: pointer;color: #1283f4;\" (click)=\"openCalendar('returnDate')\"></i>\r\n\r\n          <input  type=\"text\" value=\"\" id=\"returnDate\" class=\"widgetDatepicker bsDatepicker\" name=\"returnDate\"\r\n           [(ngModel)]=\"returnDate\" (ngModelChange)=\"selectReturnDate($event)\" readonly=\"true\" bsDatepicker  style=\"width:0px;margin-right: 10px;\"/>\r\n        </div>\r\n        <div class=\"return_info_item\">\r\n          <span>Number of late days<span class=\"text-danger\">*</span></span>\r\n          <div class=\"input_container_for_days\">\r\n            <input type=\"number\" name=\"\" value=\"\" placeholder=\"\" style=\"width: 30%;\" [(ngModel)]=\"noOfLateDays\" (ngModelChange)=\"calculateLateFine()\" [disabled]=\"true\">\r\n            <span>X</span>\r\n            <span>{{perDayFine}}/- per day</span>\r\n          </div>\r\n        </div>\r\n        <div class=\"return_info_item\">\r\n          <span>Total Fine in Rs.</span>\r\n          <input type=\"number\" name=\"\" value=\"\" placeholder=\"\" style=\"font-weight: 600;\" [(ngModel)]=\"totalLateFine\" [disabled]=\"disableReturnAmt\" readonly>\r\n        </div>\r\n      </div>\r\n      <div class=\"lost_book_container\" *ngIf=\"lostBook\">\r\n        <div class=\"lost_book_item\">\r\n          <span>Lost/Scrap Date</span>\r\n          <input type=\"text\" name=\"\" value=\"\" readonly [(ngModel)]=\"tempLostDate\" (click)=\"openCalendar('lostDate')\">\r\n          <i class=\"fa fa-calendar\" style=\"cursor: pointer;color: #1283f4;\" (click)=\"openCalendar('lostDate')\"></i>\r\n\r\n          <input  type=\"text\" value=\"\" id=\"lostDate\" class=\"widgetDatepicker bsDatepicker\" name=\"lostDate\"\r\n           [(ngModel)]=\"lostDate\" (ngModelChange)=\"selectBookLostDate($event)\" readonly=\"true\" bsDatepicker  style=\"width:0px;margin-right: 10px;\"/>\r\n        </div>\r\n        <div class=\"lost_book_item\">\r\n          <span>Lost/Scrap Amount in Rs.</span>\r\n          <input type=\"number\" name=\"\" value=\"\" placeholder=\"\" style=\"font-weight: 600;\" [(ngModel)]=\"lostBookAmt\">\r\n        </div>\r\n      </div>\r\n      <div class=\"remarks_container\">\r\n        <span>Remarks</span>\r\n        <textarea name=\"name\" class=\"remarks_textarea\" placeholder=\"Write Remarks...\" [(ngModel)]=\"returnBookRemarks\"></textarea>\r\n      </div>\r\n      <!-- <div class=\"notify_container\">\r\n        <div class=\"field-checkbox-wrapper checkbox_container\">\r\n          <input type=\"checkbox\" value=\"\" name=\"notify\" class=\"form-checkbox\">\r\n          <label for=\"notify\">Notify to Student</label>\r\n        </div>\r\n        <div class=\"field-checkbox-wrapper checkbox_container\">\r\n          <input type=\"checkbox\" value=\"\" name=\"download\" class=\"form-checkbox\">\r\n          <label for=\"download\">Download Receipt</label>\r\n        </div>\r\n      </div> -->\r\n      <div class=\"action_btn_container pull-right\">\r\n        <button type=\"button\" name=\"button\" class=\"cancel_btn\" (click)=\"cancelReturnBook()\">Cancel</button>\r\n        <button type=\"button\" name=\"button\" class=\"return_btn\" [disabled]=\"multiClickDisabled\" (click)=\"returnBook()\">Return</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n<a id=\"feeReceipt_download\" href=\"\" class=\"hide\"></a>\r\n\r\n<div class=\"black-bg\" id=\"black-bg\" *ngIf=\"returnBookPopup\" (click)=\"closePopup()\">\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/components/library-management/return-book/return-book.component.scss":
/***/ (function(module, exports) {

module.exports = ".search_bar_container {\n  position: relative;\n  margin-left: 3%; }\n  .search_bar_container .search_box {\n    height: 35px;\n    width: 420px;\n    border: 1px solid #dcdcdc;\n    background: white;\n    border-radius: 4px;\n    padding-right: 18px;\n    padding-left: 32px; }\n  .search_bar_container .fa-search {\n    position: absolute;\n    left: 1px;\n    top: 1px;\n    padding: 9px;\n    color: #9b9b9b;\n    background: white;\n    border-radius: 4px; }\n  .search_bar_container .fa-times {\n    position: absolute;\n    left: 364px;\n    top: 8px;\n    background: white;\n    cursor: pointer;\n    padding-left: 10px;\n    color: #757575;\n    padding-top: 2px;\n    padding-bottom: 4px; }\n  .search_bar_container .fa-sort-desc {\n    position: absolute;\n    left: 385px;\n    top: 8px;\n    background: white;\n    cursor: pointer;\n    padding-left: 10px;\n    padding-bottom: 5px; }\n  .search_bar_container span {\n    font-family: 'Nanum Pen Script';\n    font-size: 18px;\n    margin-left: 10px; }\n  .search_box_filter_container {\n  margin-left: 3%;\n  width: 420px;\n  border-radius: 4px;\n  background: white;\n  -webkit-box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.27);\n          box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.27);\n  margin-top: 4px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  padding: 16px 26px;\n  position: fixed; }\n  .search_box_filter_container .filter_item {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    width: 100%;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between;\n    margin-bottom: 10px; }\n  .search_box_filter_container .filter_item .label_container {\n      width: 25%;\n      color: #3a3a3a;\n      text-align: left;\n      position: relative; }\n  .search_box_filter_container .filter_item .label_container span {\n        position: absolute;\n        top: 5px;\n        font-size: 12px; }\n  .search_box_filter_container .filter_item .input_container {\n      width: 70%; }\n  .search_box_filter_container .filter_item .input_container input {\n        border-bottom: 1px solid #9b9b9b;\n        padding: 10px;\n        padding-bottom: 3px;\n        padding-left: 0px;\n        width: 100%;\n        color: #3a3a3a;\n        font-size: 12px;\n        line-height: 1.36;\n        letter-spacing: normal;\n        font-weight: normal; }\n  .search_box_filter_container .filter_item .input_container ::-webkit-input-placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: #cfcfcf; }\n  .search_box_filter_container .filter_item .input_container :-ms-input-placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: #cfcfcf; }\n  .search_box_filter_container .filter_item .input_container ::-ms-input-placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: #cfcfcf; }\n  .search_box_filter_container .filter_item .input_container ::placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: #cfcfcf; }\n  .search_box_filter_container .filter_item .input_container select {\n        border-bottom: 1px solid #9b9b9b;\n        padding-bottom: 3px;\n        padding-left: 0px;\n        width: 100%;\n        color: #3a3a3a;\n        font-size: 12px;\n        line-height: 1.36;\n        letter-spacing: normal;\n        font-weight: normal; }\n  .search_box_filter_container .filter_item .input_container select option {\n        color: #3a3a3a; }\n  .search_box_filter_container .filter_item .input_container select option:first-child {\n        color: #cfcfcf !important; }\n  .search_box_filter_container .filter_item .input_container input:focus {\n        border-bottom: 1px solid #1283f4; }\n  .search_box_filter_container .filter_item .input_container select:focus {\n        border-bottom: 1px solid #1283f4; }\n  .search_box_filter_container .action_btn_container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: end;\n        -ms-flex-pack: end;\n            justify-content: flex-end;\n    margin-top: 10px; }\n  .search_box_filter_container .action_btn_container .reset_btn {\n      margin-right: 10px;\n      padding: 6px 15px;\n      border-radius: 4px;\n      border: 1px solid #585574;\n      color: #585574;\n      text-align: center;\n      background: white; }\n  .search_box_filter_container .action_btn_container .search_btn {\n      padding: 6px 15px;\n      border-radius: 4px;\n      border: 1px solid #1283f4;\n      color: white;\n      background: #1283f4;\n      text-align: center; }\n  .suggestions_container {\n  background: white;\n  border-radius: 4px;\n  height: 200px;\n  max-height: 200px;\n  min-height: 200px;\n  overflow-y: auto;\n  -webkit-box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.27);\n          box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.27);\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  margin-left: 3%;\n  width: 420px;\n  margin-top: 0px;\n  position: fixed; }\n  .suggestions_container .suggestion {\n    padding: 10px; }\n  .suggestions_container .suggestion .suggestion_item {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      margin-bottom: 10px;\n      cursor: pointer; }\n  .suggestions_container .suggestion .suggestion_item .img_container {\n        width: 10%;\n        padding: 6px; }\n  .suggestions_container .suggestion .suggestion_item .book_details {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column; }\n  .suggestions_container .suggestion .suggestion_item .book_details .name_container {\n          color: #585574;\n          font-size: 12px; }\n  .suggestions_container .suggestion .suggestion_item .book_details .book_more_info {\n          color: #9b9b9b;\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: horizontal;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: row;\n                  flex-direction: row;\n          font-size: 12px;\n          margin-top: 5px; }\n  hr {\n  margin-top: 10px;\n  margin-bottom: 10px;\n  border: 0;\n  border-top: 1px solid #eee;\n  width: 94%;\n  margin-left: 3%; }\n  .widgetDatepicker {\n  position: absolute;\n  margin-left: 10%;\n  width: 1px;\n  visibility: hidden;\n  opacity: 0; }\n  .bsDatepicker {\n  padding: 5px;\n  width: 100%;\n  position: absolute;\n  left: 80px; }\n  .illustartion_container {\n  width: 100%; }\n  .illustartion_container img {\n    max-height: 70%;\n    max-width: 27%;\n    margin-left: 30%; }\n  .search_result_container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 94%;\n  margin-left: 3%; }\n  .search_result_container .search_result_item {\n    width: 100%;\n    margin-bottom: 10px;\n    border-radius: 6px;\n    -webkit-box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.16);\n            box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.16);\n    background: white; }\n  .search_result_container .search_result_item .sub_item_1_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      padding: 10px;\n      border-bottom: 1px solid #DDDDDD; }\n  .search_result_container .search_result_item .sub_item_1_container .sub_item1 {\n        width: 32%;\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row; }\n  .search_result_container .search_result_item .sub_item_1_container .sub_item2 {\n        width: 18%;\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row; }\n  .search_result_container .search_result_item .sub_item_1_container .sub_item3 {\n        width: 10%;\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        -webkit-box-pack: end;\n            -ms-flex-pack: end;\n                justify-content: flex-end; }\n  .search_result_container .search_result_item .sub_item_1_container .more_info {\n        font-size: 12px;\n        font-style: normal;\n        text-align: left;\n        color: #585574; }\n  .search_result_container .search_result_item .sub_item_1_container .issue_span {\n        background: #dfefff;\n        padding: 5px 10px;\n        border-radius: 4px;\n        border: 1px solid #1984f6;\n        height: 27px; }\n  .search_result_container .search_result_item .sub_item_1_container .overdue_span {\n        background: #ffdfca;\n        padding: 5px 10px;\n        border-radius: 4px;\n        border: 1px solid #ff6600;\n        height: 27px; }\n  .search_result_container .search_result_item .sub_item_1_container .book_icon {\n        width: 30px;\n        height: 30px; }\n  .search_result_container .search_result_item .sub_item_1_container .book_name_container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        margin-left: 5px; }\n  .search_result_container .search_result_item .sub_item_1_container .book_name_container .title {\n          font-size: 12px;\n          font-weight: normal;\n          font-style: normal;\n          text-align: left;\n          color: #9b9b9b; }\n  .search_result_container .search_result_item .sub_item_1_container .book_name_container .book_name {\n          font-size: 14px;\n          font-weight: 600;\n          font-style: normal;\n          text-align: left;\n          color: #585574; }\n  .search_result_container .search_result_item .sub_item_2_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      -webkit-box-pack: justify;\n          -ms-flex-pack: justify;\n              justify-content: space-between; }\n  .search_result_container .search_result_item .sub_item_2_container .item, .search_result_container .search_result_item .sub_item_2_container .item_2 {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        padding: 10px;\n        width: 80%; }\n  .search_result_container .search_result_item .sub_item_2_container .item_2 {\n        width: 20%;\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-pack: end;\n            -ms-flex-pack: end;\n                justify-content: flex-end; }\n  .search_result_container .search_result_item .sub_item_2_container .sub_item3 {\n        width: 20%;\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        -webkit-box-pack: start;\n            -ms-flex-pack: start;\n                justify-content: flex-start; }\n  .search_result_container .search_result_item .sub_item_2_container .return_btn {\n        background: #1984f6;\n        border-radius: 4px;\n        color: white;\n        padding: 10px 25px;\n        font-weight: 600; }\n  .search_result_container .search_result_item .sub_item_2_container .more_info {\n        font-size: 12px;\n        font-style: normal;\n        text-align: left;\n        color: #585574; }\n  .search_result_container .search_result_item .sub_item_2_container .book_name_container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        margin-left: 5px; }\n  .search_result_container .search_result_item .sub_item_2_container .book_name_container .title {\n          font-size: 12px;\n          font-weight: normal;\n          font-style: normal;\n          text-align: left;\n          color: #9b9b9b; }\n  .search_result_container .search_result_item .sub_item_2_container .book_name_container .book_name {\n          font-size: 14px;\n          font-weight: 600;\n          font-style: normal;\n          text-align: left;\n          color: #585574; }\n  .return_book_pop_up_container {\n  position: fixed;\n  top: 20%;\n  left: 25%;\n  right: 25%;\n  width: 50%;\n  background: white;\n  border-radius: 4px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  z-index: 100; }\n  .return_book_pop_up_container .header_container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between;\n    padding: 15px 20px;\n    background: #f8f8f8;\n    border-bottom: 1px solid #dddddd;\n    border-top-left-radius: 4px;\n    border-top-right-radius: 4px; }\n  .return_book_pop_up_container .header_container span {\n      font-weight: 600;\n      color: #585574;\n      font-size: 14px; }\n  .return_book_pop_up_container .header_container .fa-times {\n      color: #707070;\n      cursor: pointer; }\n  .return_book_pop_up_container .details_container {\n    padding: 20px;\n    padding-top: 10px;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column; }\n  .return_book_pop_up_container .details_container .book_info_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      padding: 10px 0px;\n      border-bottom: 1px solid #dddddd;\n      width: 100%;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start; }\n  .return_book_pop_up_container .details_container .book_info_container .book_info_item1 {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        -webkit-box-pack: start;\n            -ms-flex-pack: start;\n                justify-content: flex-start;\n        width: 40%; }\n  .return_book_pop_up_container .details_container .book_info_container .book_info_item2 {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row;\n        -webkit-box-pack: start;\n            -ms-flex-pack: start;\n                justify-content: flex-start;\n        width: 25%; }\n  .return_book_pop_up_container .details_container .book_info_container .book_icon {\n        width: 30px;\n        height: 30px; }\n  .return_book_pop_up_container .details_container .book_info_container .book_name_container {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        margin-left: 5px; }\n  .return_book_pop_up_container .details_container .book_info_container .book_name_container .title {\n          font-size: 12px;\n          font-weight: normal;\n          font-style: normal;\n          text-align: left;\n          color: #9b9b9b; }\n  .return_book_pop_up_container .details_container .book_info_container .book_name_container .book_name {\n          font-size: 14px;\n          font-weight: 600;\n          font-style: normal;\n          text-align: left;\n          color: #585574; }\n  .return_book_pop_up_container .details_container .book_info_container .book_name_container .more_info {\n          font-size: 12px;\n          font-style: normal;\n          text-align: left;\n          color: #585574;\n          font-weight: 600; }\n  .return_book_pop_up_container .details_container .book_status_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      padding: 10px 0px;\n      border-bottom: 1px solid #dddddd;\n      width: 100%;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start;\n      color: #9b9b9b;\n      font-size: 12px; }\n  .return_book_pop_up_container .details_container .book_status_container .checkbox_container {\n        width: 25%;\n        margin-left: 10px;\n        margin-bottom: 0px; }\n  .return_book_pop_up_container .details_container .book_status_container .field-checkbox-wrapper .form-checkbox + label {\n        vertical-align: middle;\n        font-size: 12px;\n        display: inline-block; }\n  .return_book_pop_up_container .details_container .book_status_container .field-checkbox-wrapper .form-checkbox + label:after {\n        content: '';\n        width: 16px;\n        height: 16px;\n        border: 2px solid #ccc;\n        border-radius: 2px;\n        position: absolute;\n        left: 0;\n        top: 0; }\n  .return_book_pop_up_container .details_container .book_status_container .field-checkbox-wrapper .form-checkbox:checked + label:after {\n        border: 2px solid #0084f6; }\n  .return_book_pop_up_container .details_container .book_status_container .field-checkbox-wrapper .form-checkbox + label:before {\n        width: 1px;\n        height: 1px;\n        left: 8px;\n        top: 9px;\n        position: absolute;\n        content: '';\n        border-top: 0;\n        border-right: 0;\n        border-left: 2px solid transparent;\n        border-bottom: 2px solid transparent;\n        -webkit-transform: rotate(-45deg);\n                transform: rotate(-45deg); }\n  .return_book_pop_up_container .details_container .book_status_container .field-checkbox-wrapper .form-checkbox:checked + label:before {\n        border-left: 2px solid #0084f6;\n        border-bottom: 2px solid #0084f6;\n        width: 12px;\n        height: 5px;\n        left: 2px;\n        top: 5px; }\n  .return_book_pop_up_container .details_container .book_status_container .field-checkbox-wrapper .form-checkbox:checked + label {\n        color: #0084f6; }\n  .return_book_pop_up_container .details_container .return_info_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 100%;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start;\n      padding: 10px 0px;\n      border-bottom: 1px solid #dddddd;\n      color: #9b9b9b; }\n  .return_book_pop_up_container .details_container .return_info_container .return_info_item {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        width: 30%;\n        position: relative; }\n  .return_book_pop_up_container .details_container .return_info_container .return_info_item .input_container_for_days {\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: horizontal;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: row;\n                  flex-direction: row; }\n  .return_book_pop_up_container .details_container .return_info_container .return_info_item .input_container_for_days span {\n            color: #585574;\n            margin-left: 5px;\n            margin-top: 10px; }\n  .return_book_pop_up_container .details_container .return_info_container .return_info_item span {\n          color: #9b9b9b;\n          font-size: 12px; }\n  .return_book_pop_up_container .details_container .return_info_container .return_info_item input {\n          border-radius: 4px;\n          border: 1px solid rgba(0, 0, 0, 0.3);\n          padding: 5px;\n          width: 60%;\n          margin-top: 5px;\n          color: #585574; }\n  .return_book_pop_up_container .details_container .return_info_container .return_info_item .fa-calendar {\n          position: absolute;\n          top: 26px;\n          right: 45%; }\n  .return_book_pop_up_container .details_container .lost_book_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 100%;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start;\n      padding: 10px 0px;\n      border-bottom: 1px solid #dddddd;\n      color: #9b9b9b; }\n  .return_book_pop_up_container .details_container .lost_book_container .lost_book_item {\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: vertical;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: column;\n                flex-direction: column;\n        width: 30%;\n        position: relative; }\n  .return_book_pop_up_container .details_container .lost_book_container .lost_book_item .input_container_for_days {\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          -webkit-box-orient: horizontal;\n          -webkit-box-direction: normal;\n              -ms-flex-direction: row;\n                  flex-direction: row; }\n  .return_book_pop_up_container .details_container .lost_book_container .lost_book_item .input_container_for_days span {\n            color: #585574;\n            margin-left: 5px;\n            margin-top: 10px; }\n  .return_book_pop_up_container .details_container .lost_book_container .lost_book_item span {\n          color: #9b9b9b;\n          font-size: 12px; }\n  .return_book_pop_up_container .details_container .lost_book_container .lost_book_item input {\n          border-radius: 4px;\n          border: 1px solid rgba(0, 0, 0, 0.3);\n          padding: 5px;\n          width: 60%;\n          margin-top: 5px;\n          color: #585574; }\n  .return_book_pop_up_container .details_container .lost_book_container .lost_book_item .fa-calendar {\n          position: absolute;\n          top: 26px;\n          right: 45%; }\n  .return_book_pop_up_container .details_container .remarks_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start;\n      width: 100%;\n      padding: 10px 0px;\n      color: #9b9b9b; }\n  .return_book_pop_up_container .details_container .remarks_container span {\n        font-size: 12px; }\n  .return_book_pop_up_container .details_container .remarks_container .remarks_textarea {\n        width: 100%;\n        height: 60px;\n        border-radius: 4px;\n        border: solid 1px rgba(0, 0, 0, 0.3);\n        margin-top: 5px;\n        padding: 5px;\n        color: black; }\n  .return_book_pop_up_container .details_container .remarks_container ::-webkit-input-placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: rgba(0, 0, 0, 0.3); }\n  .return_book_pop_up_container .details_container .remarks_container :-ms-input-placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: rgba(0, 0, 0, 0.3); }\n  .return_book_pop_up_container .details_container .remarks_container ::-ms-input-placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: rgba(0, 0, 0, 0.3); }\n  .return_book_pop_up_container .details_container .remarks_container ::placeholder {\n        /* Chrome, Firefox, Opera, Safari 10.1+ */\n        color: rgba(0, 0, 0, 0.3); }\n  .return_book_pop_up_container .details_container .notify_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      padding: 10px 0px; }\n  .return_book_pop_up_container .details_container .notify_container .checkbox_container {\n        width: 30%;\n        margin-top: 10px;\n        color: #9b9b9b;\n        font-size: 12px; }\n  .return_book_pop_up_container .details_container .notify_container .field-checkbox-wrapper .form-checkbox + label {\n        vertical-align: middle;\n        font-size: 12px;\n        display: inline-block; }\n  .return_book_pop_up_container .details_container .notify_container .field-checkbox-wrapper .form-checkbox + label:after {\n        content: '';\n        width: 16px;\n        height: 16px;\n        border: 2px solid #ccc;\n        border-radius: 2px;\n        position: absolute;\n        left: 0;\n        top: 0; }\n  .return_book_pop_up_container .details_container .notify_container .field-checkbox-wrapper .form-checkbox:checked + label:after {\n        border: 2px solid #0084f6; }\n  .return_book_pop_up_container .details_container .notify_container .field-checkbox-wrapper .form-checkbox + label:before {\n        width: 1px;\n        height: 1px;\n        left: 8px;\n        top: 9px;\n        position: absolute;\n        content: '';\n        border-top: 0;\n        border-right: 0;\n        border-left: 2px solid transparent;\n        border-bottom: 2px solid transparent;\n        -webkit-transform: rotate(-45deg);\n                transform: rotate(-45deg); }\n  .return_book_pop_up_container .details_container .notify_container .field-checkbox-wrapper .form-checkbox:checked + label:before {\n        border-left: 2px solid #0084f6;\n        border-bottom: 2px solid #0084f6;\n        width: 12px;\n        height: 5px;\n        left: 2px;\n        top: 5px; }\n  .return_book_pop_up_container .details_container .notify_container .field-checkbox-wrapper .form-checkbox:checked + label {\n        color: #0084f6; }\n  .return_book_pop_up_container .details_container .action_btn_container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: end;\n          -ms-flex-pack: end;\n              justify-content: flex-end;\n      padding: 10px; }\n  .return_book_pop_up_container .details_container .action_btn_container .cancel_btn {\n        margin-right: 10px;\n        padding: 6px 15px;\n        border-radius: 4px;\n        border: solid 1px #1283f4;\n        color: #1984f6;\n        text-align: center;\n        background: white; }\n  .return_book_pop_up_container .details_container .action_btn_container .return_btn {\n        padding: 6px 15px;\n        border-radius: 4px;\n        border: 1px solid #1283f4;\n        color: white;\n        background: #1283f4;\n        text-align: center; }\n  input[type=number]::-webkit-inner-spin-button,\ninput[type=number]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0; }\n  input, textarea {\n  font-size: 12px; }\n  .black-bg {\n  background: rgba(10, 10, 10, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 1;\n  width: 100%; }\n"

/***/ }),

/***/ "./src/app/components/library-management/return-book/return-book.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReturnBookComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_library_add_add_book_service__ = __webpack_require__("./src/app/services/library/add/add-book.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_library_issue_issue_book_service__ = __webpack_require__("./src/app/services/library/issue/issue-book.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_library_return_return_book_service__ = __webpack_require__("./src/app/services/library/return/return-book.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var ReturnBookComponent = /** @class */ (function () {
    function ReturnBookComponent(router, auth, _commService, appC, addBookService, issueBookService, returnBookService) {
        this.router = router;
        this.auth = auth;
        this._commService = _commService;
        this.appC = appC;
        this.addBookService = addBookService;
        this.issueBookService = issueBookService;
        this.returnBookService = returnBookService;
        this.filter = false;
        this.searchResult = false;
        this.suggestion = false;
        this.returnBookPopup = false;
        this.lostBook = false;
        this.isRippleLoad = false;
        this.bookSuggestion = false;
        this.hoverTitle = "";
        this.multiClickDisabled = false;
        this.searchCategoryId = '-1';
        this.searchSubcategoryId = '-1';
        this.searchSubjectId = '-1';
        this.searchPublicationId = '-1';
        this.searchAuthorId = '-1';
        this.searchLangId = '-1';
        this.disableReturnAmt = false;
    }
    ReturnBookComponent.prototype.ngOnInit = function () {
        this.tempReturnDate = __WEBPACK_IMPORTED_MODULE_8_moment__(new Date()).format("DD MMM YYYY");
        this.tempLostDate = __WEBPACK_IMPORTED_MODULE_8_moment__(new Date()).format("DD MMM YYYY");
        this.getAllMasterData();
        this.getInstituteData();
    };
    ReturnBookComponent.prototype.getInstituteData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.issueBookService.getInstituteSettingFromServer().subscribe(function (response) {
            _this.isRippleLoad = false;
            var res;
            res = response;
            _this.perDayFine = res.lib_due_date_fine_per_day;
            console.log(_this.perDayFine);
        }, function (errorResponse) {
            _this.isRippleLoad = false;
            console.log(errorResponse);
        });
    };
    ReturnBookComponent.prototype.getAllMasterData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.addBookService.getAllMasterData().subscribe(function (response) {
            _this.isRippleLoad = false;
            var res;
            res = response;
            console.log(response);
            var tempCatList = res.response.categories;
            _this.categoryList = res.response.categories;
            _this.subjectList = res.response.subjects;
            _this.publicationList = res.response.publications;
            _this.authorList = res.response.authors;
            _this.languageList = res.response.languages;
        }, function (errorResponse) {
            _this.isRippleLoad = false;
            console.log(errorResponse);
        });
    };
    ReturnBookComponent.prototype.getSubCategory = function (ev) {
        var _this = this;
        this.isRippleLoad = true;
        this.addBookService.getSubCategories(ev).subscribe(function (response) {
            _this.isRippleLoad = false;
            var res;
            res = response;
            console.log(response);
            _this.subcategoryList = res.response;
        }, function (errorResponse) {
            _this.isRippleLoad = false;
            console.log(errorResponse);
        });
    };
    ReturnBookComponent.prototype.searchInList = function (search_string) {
        if (search_string.which <= 90 && search_string.which >= 48 || search_string.which == 8) {
            this.filter = false;
            this.searchResult = false;
            if (this.searchInput != '') {
                this.suggestionList = "";
                this.getSearchData();
            }
            if (search_string.which === 13) {
                this.showSearchResult();
            }
        }
        if (this.searchInput == '' || this.searchInput == null) {
            this.suggestion = false;
            this.filter = false;
        }
    };
    ReturnBookComponent.prototype.showSearchResult = function () {
        this.bookSuggestion = false;
        this.searchResult = true;
    };
    ReturnBookComponent.prototype.showFilter = function () {
        if (this.filter) {
            this.filter = false;
            return;
        }
        else {
            this.filter = true;
            this.suggestion = false;
            return;
        }
    };
    ReturnBookComponent.prototype.getSearchData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.returnBookService.getSearchedBooksOrStudents(this.searchInput).subscribe(function (response) {
            var res;
            res = response;
            if (res.response.libraryBookDTOs.length > 0 || res.response.students.length > 0) {
                if (_this.searchInput == '' || _this.searchInput == null) {
                    _this.suggestion = false;
                    _this.filter = false;
                }
                else {
                    _this.suggestion = true;
                }
                _this.suggestionList = res.response;
                _this.isRippleLoad = false;
            }
        });
    };
    ReturnBookComponent.prototype.advanceSearch = function () {
        var _this = this;
        this.filter = false;
        this.suggestion = false;
        var obj = {
            "by": [
                {
                    "column": "title",
                    "value": this.searchTitle
                },
                {
                    "column": "category_id",
                    "value": this.searchCategoryId
                },
                {
                    "column": "sub_category_id",
                    "value": this.searchSubcategoryId
                },
                {
                    "column": "subject_id",
                    "value": this.searchSubjectId
                },
                {
                    "column": "publication_id",
                    "value": this.searchPublicationId
                },
                {
                    "column": "language_id",
                    "value": this.searchLangId
                },
                {
                    "column": "author_id",
                    "value": this.searchAuthorId
                }
            ],
            "sort": [
                {
                    "column": "publication_name",
                    "assending": false
                }
            ],
            "pageNo": 1,
            "noOfRecords": 10
        };
        console.log(obj);
        this.isRippleLoad = true;
        this.issueBookService.getBookFilterData(obj).subscribe(function (response) {
            _this.isRippleLoad = false;
            var res;
            res = response;
            if (res.response.results.length > 0) {
                console.log(response);
                // this.returnBookData = res.response.results;
                _this.searchResult = true;
            }
            else {
                _this.messageHandler('error', 'No data found', '');
                // if(res.errorResponse[0].errorCode == 700){
                //   this.messageHandler('error', 'No data found', '');
                // }
            }
        });
    };
    ReturnBookComponent.prototype.resetFilter = function () {
        this.searchTitle = "";
        this.searchCategoryId = "-1";
        this.searchSubcategoryId = "-1";
        this.searchSubjectId = "-1";
        this.searchPublicationId = "-1";
        this.searchLangId = "-1";
        this.searchAuthorId = "-1";
    };
    ReturnBookComponent.prototype.getIssuedBooksByBook = function (book_id, book_title) {
        var _this = this;
        this.isRippleLoad = true;
        this.returnBookService.getIssuedBooksByBook(book_id).subscribe(function (response) {
            var res;
            res = response;
            _this.isRippleLoad = false;
            _this.suggestion = false;
            if (res.response.length > 0) {
                _this.searchResult = true;
                _this.returnBookData = res.response;
            }
            else {
                _this.messageHandler('error', book_title + ' has not been issued by any borrower', '');
            }
        });
    };
    ReturnBookComponent.prototype.getIssuedBooksByStudent = function (student_id, student_name) {
        var _this = this;
        this.returnBookService.getIssuedBooksByStudent(student_id).subscribe(function (response) {
            var res;
            res = response;
            _this.isRippleLoad = false;
            _this.suggestion = false;
            if (res.response.length > 0) {
                _this.searchResult = true;
                _this.returnBookData = res.response;
            }
            else {
                _this.messageHandler('error', 'No book to be returned by ' + student_name, '');
            }
        });
    };
    ReturnBookComponent.prototype.downloadReceipt = function (issueBookId) {
        var _this = this;
        this.isRippleLoad = true;
        this.returnBookService.downloadReceipt(issueBookId).subscribe(function (response) {
            var res;
            res = response;
            _this.isRippleLoad = false;
            var byteArr = _this._commService.convertBase64ToArray(res.document);
            var fileName = res.docTitle;
            var file = new Blob([byteArr], { type: 'text/csv;charset=utf-8;' });
            var url = URL.createObjectURL(file);
            var dwldLink = document.getElementById('feeReceipt_download');
            dwldLink.setAttribute("href", url);
            dwldLink.setAttribute("download", fileName);
            document.body.appendChild(dwldLink);
            dwldLink.click();
        });
    };
    ReturnBookComponent.prototype.showReturnBook = function (returnBookData) {
        this.lostBookAmt = returnBookData.book_complete_details.book_lost_fine;
        this.noOfLateDays = 0;
        this.totalLateFine = 0;
        this.returnBookRemarks = "";
        this.returnBookPopup = true;
        this.returnBookTitle = returnBookData.book_complete_details.title;
        this.returnBookIssuedDate = __WEBPACK_IMPORTED_MODULE_8_moment__(returnBookData.issued_book.issued_on).format("DD MMM YYYY");
        this.returnBookReturnDate = __WEBPACK_IMPORTED_MODULE_8_moment__(returnBookData.issued_book.to_return_on_date).format("DD MMM YYYY");
        this.returnBookRemarks = "";
        this.returnIssueBookId = returnBookData.issued_book.issue_book_id;
        this.bookId = returnBookData.book_complete_details.book_id;
        this.checkForReturnDate(__WEBPACK_IMPORTED_MODULE_8_moment__(returnBookData.issued_book.to_return_on_date).format("DD MMM YYYY"));
        var timeDiff = "";
        var givenDate = new Date(this.returnBookReturnDate);
        var tempDate = new Date(this.tempReturnDate);
        if (givenDate > tempDate) {
            this.noOfLateDays = 0;
        }
        else {
            timeDiff = Math.abs(__WEBPACK_IMPORTED_MODULE_8_moment__(this.returnBookReturnDate).diff(__WEBPACK_IMPORTED_MODULE_8_moment__(this.tempReturnDate), 'days'));
            if (timeDiff > 0) {
                this.noOfLateDays = timeDiff;
                this.totalLateFine = this.perDayFine * this.noOfLateDays;
            }
        }
        // this.checkForReturnDate(moment(returnBookData.issued_book.to_return_on_date).format("DD MMM YYYY"));
    };
    ReturnBookComponent.prototype.returnBook = function () {
        var _this = this;
        console.log(this.lostBook);
        var obj;
        if (this.lostBook) {
            obj = {
                "issue_book_id": this.returnIssueBookId,
                "book_id": this.bookId,
                "returned_date": __WEBPACK_IMPORTED_MODULE_8_moment__(this.tempReturnDate).unix() * 1000,
                "lost_on_date": __WEBPACK_IMPORTED_MODULE_8_moment__(this.tempLostDate).unix() * 1000,
                "scrapped_on_date": __WEBPACK_IMPORTED_MODULE_8_moment__(this.tempLostDate).unix() * 1000,
                "paid_fine": this.lostBookAmt,
                "remark": this.returnBookRemarks,
                "no_of_late_days": ""
            };
        }
        else {
            if (this.noOfLateDays == null && !this.disableReturnAmt) {
                this.messageHandler('error', 'Enter number of late days', '');
                return;
            }
            else {
                obj = {
                    "issue_book_id": this.returnIssueBookId,
                    "book_id": this.bookId,
                    "returned_date": __WEBPACK_IMPORTED_MODULE_8_moment__(this.tempReturnDate).unix() * 1000,
                    "lost_on_date": "",
                    "scrapped_on_date": "",
                    "paid_fine": this.totalLateFine,
                    "remark": this.returnBookRemarks,
                    "no_of_late_days": this.noOfLateDays
                };
            }
        }
        console.log(obj);
        this.isRippleLoad = true;
        this.multiClickDisabled = true;
        this.returnBookService.returnBook(obj).subscribe(function (response) {
            var res;
            res = response;
            _this.isRippleLoad = false;
            _this.returnBookPopup = false;
            _this.multiClickDisabled = false;
            console.log(res.response);
            if (res.statusCode == 200) {
                _this.downloadReceipt(_this.returnIssueBookId);
                _this.bookSuggestion = false;
                _this.searchResult = false;
                _this.searchInput = "";
                _this.lostBookAmt = 0;
                _this.noOfLateDays = 0;
                _this.totalLateFine = 0;
                _this.returnBookRemarks = "";
                _this.messageHandler('success', 'Book returned successfully', '');
            }
            else {
                _this.messageHandler('error', 'Internal server error', '');
            }
        });
    };
    ReturnBookComponent.prototype.cancelReturnBook = function () {
        this.returnBookPopup = false;
    };
    ReturnBookComponent.prototype.calculateLateFine = function () {
        this.totalLateFine = this.perDayFine * this.noOfLateDays;
        this.totalLateFine = Math.round(this.totalLateFine);
    };
    ReturnBookComponent.prototype.selectReturnDate = function () {
        var fromDateNotGreaterThanToday = this.lessThanReturnDate(this.returnDate);
        if (fromDateNotGreaterThanToday == 'true') {
            this.tempReturnDate = __WEBPACK_IMPORTED_MODULE_8_moment__(this.returnDate).format("DD MMM YYYY");
            var timeDiff = "";
            timeDiff = Math.abs(__WEBPACK_IMPORTED_MODULE_8_moment__(this.returnBookReturnDate).diff(__WEBPACK_IMPORTED_MODULE_8_moment__(this.returnDate), 'days'));
            this.noOfLateDays = timeDiff;
            this.totalLateFine = this.perDayFine * this.noOfLateDays;
        }
        else if (fromDateNotGreaterThanToday == 'greaterthan') {
            this.messageHandler('error', 'Return date cannot be future date', '');
            return;
        }
        else if (fromDateNotGreaterThanToday == 'lessthan') {
            this.messageHandler('error', 'It cannot be less than return date', '');
            return;
        }
    };
    ReturnBookComponent.prototype.selectBookLostDate = function () {
        var fromDateNotGreaterThanToday = this.graterThanToday(this.lostDate);
        if (fromDateNotGreaterThanToday) {
            this.tempLostDate = __WEBPACK_IMPORTED_MODULE_8_moment__(this.lostDate).format("DD MMM YYYY");
        }
        else {
            this.messageHandler('error', 'Book lost/scrap date cannot be future date', '');
            return;
        }
    };
    ReturnBookComponent.prototype.graterThanToday = function (givenDate) {
        var currentDate = new Date();
        givenDate = new Date(givenDate);
        if (givenDate > currentDate) {
            return false;
        }
        else {
            return true;
        }
    };
    ReturnBookComponent.prototype.lessThanReturnDate = function (givenDate) {
        var currentDate = new Date();
        givenDate = new Date(givenDate);
        var tempDate = this.returnBookReturnDate;
        tempDate = new Date(tempDate);
        if (givenDate < tempDate) {
            return 'lessthan';
        }
        else if (givenDate > currentDate) {
            return 'greaterthan';
        }
        else {
            return 'true';
        }
    };
    ReturnBookComponent.prototype.checkForReturnDate = function (givenDate) {
        var currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);
        givenDate = new Date(givenDate);
        if (givenDate >= currentDate) {
            this.disableReturnAmt = true;
        }
        else {
            this.disableReturnAmt = false;
        }
        var timeDiff = "";
        var days = "";
        timeDiff = Math.floor(currentDate - givenDate);
        days = timeDiff / (1000 * 60 * 60 * 24);
        if (days > 0) {
            this.noOfLateDays = days;
            this.totalLateFine = this.perDayFine * this.noOfLateDays;
        }
    };
    ReturnBookComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    ReturnBookComponent.prototype.clearFilter = function () {
        this.searchInput = "";
        this.suggestion = false;
    };
    ReturnBookComponent.prototype.closePopup = function () {
        this.returnBookPopup = false;
    };
    ReturnBookComponent.prototype.closeSuggestions = function () {
        this.suggestion = false;
    };
    ReturnBookComponent.prototype.concatString = function (authorArray) {
        this.hoverTitle = "";
        for (var i = 0; i < authorArray.length; i++) {
            this.hoverTitle += authorArray[i].author_name;
            if (i >= 0 && i < authorArray.length) {
                this.hoverTitle += ", ";
            }
        }
        return this.hoverTitle;
    };
    ReturnBookComponent.prototype.messageHandler = function (type, title, body) {
        var obj = {
            type: type,
            title: title,
            body: body
        };
        this.appC.popToast(obj);
    };
    ReturnBookComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-return-book',
            template: __webpack_require__("./src/app/components/library-management/return-book/return-book.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/return-book/return-book.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__services_common_service__["a" /* CommonServiceFactory */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_5__services_library_add_add_book_service__["a" /* AddBookService */],
            __WEBPACK_IMPORTED_MODULE_6__services_library_issue_issue_book_service__["a" /* IssueBookService */],
            __WEBPACK_IMPORTED_MODULE_7__services_library_return_return_book_service__["a" /* ReturnBookService */]])
    ], ReturnBookComponent);
    return ReturnBookComponent;
}());



/***/ })

});
//# sourceMappingURL=library-management.module.chunk.js.map