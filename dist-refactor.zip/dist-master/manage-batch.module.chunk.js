webpackJsonp(["manage-batch.module"],{

/***/ "./src/app/components/course-module/create-course/manage-batch/manage-batch.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"middle-section clearFix\">\r\n\r\n  <section class=\"middle-main clearFix\" style=\"padding-left: 15px;\">\r\n    <div class=\"row\">\r\n      <div class=\"clearFix add-edit pull-left\" [ngClass]=\"{'hide' : checkIfUserHadAccess()}\">\r\n        <a (click)=\"togglecreateNewBatch()\">\r\n          <i id=\"showAddBtn\" class=\"addBtnClass\">+</i>\r\n          <i id=\"showCloseBtn\" style=\"display:none\" class=\"closeBtnClass\">-</i>\r\n          <span>Create Batch</span>\r\n        </a>\r\n      </div>\r\n      <div class=\"pull-right\">\r\n        <div class=\"search-filter-wrapper \">\r\n          <input #search type=\"text\" class=\"normal-field pull-right\" placeholder=\"Search\" style=\"font-size:12px;margin-right: 15px;\"\r\n            id=\"search\" name=\"searchData \" (keyup)=\"searchDatabase(search) \">\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <section class=\"clearFix add-batch-section\" *ngIf=\"createNewBatch\">\r\n\r\n      <div class=\"row\">\r\n        <div class=\"c-lg-4 c-sm-4 c-md-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label>Master Course\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <select id=\"\" class=\"form-ctrl halfwidth\" name=\"row.standard_id\" [(ngModel)]=\"addNewBatch.standard_id\" (change)=\"onMasterCourseSelection(addNewBatch.standard_id)\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let opt of courseList\" [value]=\"opt.standard_id\">\r\n                {{opt.standard_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n        <div class=\"c-lg-4 c-sm-4 c-md-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label>Course\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <select id=\"\" class=\"form-ctrl halfwidth\" name=\"row.subject_id\" [(ngModel)]=\"addNewBatch.subject_id\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let opt of subjectList\" [value]=\"opt.subject_id\">\r\n                {{opt.subject_name}}\r\n              </option>\r\n            </select>\r\n\r\n          </div>\r\n        </div>\r\n        <div class=\"c-lg-4 c-sm-4 c-md-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label>Faculty Name\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <select id=\"\" class=\"form-ctrl halfwidth\" name=\"row.teacher_id\" [(ngModel)]=\"addNewBatch.teacher_id\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let opt of teacherList\" [value]=\"opt.teacher_id\">\r\n                {{opt.teacher_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\">\r\n\r\n        <div class=\"c-lg-4 c-sm-4 c-md-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"slotNew \">Batch Name\r\n              <span style=\"color:red\">* </span>(Eg - IX-Math-TTS-5-6)\r\n            </label>\r\n            <input type=\"text\" #idSlot class=\"form-ctrl halfwidth\" name=\"slotNew\" [(ngModel)]=\"addNewBatch.batch_name\">\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-lg-4 c-sm-4 c-md-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"slotNew \">Batch Code (For Student Bulk uplaod)\r\n            </label>\r\n            <input type=\"text\" #idSlot class=\"form-ctrl halfwidth\" name=\"slotNew\" [(ngModel)]=\"addNewBatch.batch_code\">\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-lg-4 c-sm-4 c-md-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label>Class Room\r\n            </label>\r\n            <select id=\"\" class=\"form-ctrl halfwidth\" name=\"row.class_room_id\" [(ngModel)]=\"addNewBatch.class_room_id\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let opt of classRoomList\" [value]=\"opt.class_room_id\">\r\n                {{opt.class_room_name}}\r\n              </option>\r\n            </select>\r\n\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n\r\n      <div class=\"row\">\r\n\r\n        <div class=\"c-lg-4 c-sm-4 c-md-4\">\r\n          <div class=\"field-wrapper datePickerBox\">\r\n            <label for=\"endDate\">Start Date\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <input type=\"text\" value=\"\" readonly=\"true\" class=\"form-ctrl bsDatepicker halfwidth\" [(ngModel)]=\"addNewBatch.start_date\"\r\n              name=\"endDate\" bsDatepicker>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-lg-4 c-sm-4 c-md-4\">\r\n          <div class=\"field-wrapper datePickerBox\">\r\n            <label for=\"endDate\">End Date\r\n              <span class=\"text-danger\">*</span>\r\n            </label>\r\n            <input type=\"text\" value=\"\" readonly=\"true\" class=\"form-ctrl bsDatepicker halfwidth\" [(ngModel)]=\"addNewBatch.end_date\" name=\"endDate\"\r\n              bsDatepicker>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-lg-4 c-sm-4 c-md-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label>Academic Year </label>\r\n            <select id=\"\" class=\"form-ctrl halfwidth\" name=\"row.class_room_id\" [(ngModel)]=\"addNewBatch.academic_year_id\">\r\n              <option value=\"-1\">Select</option>\r\n              <option *ngFor=\"let opt of academicList\" [value]=\"opt.inst_acad_year_id\">\r\n                {{opt.inst_acad_year}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n\r\n      <div class=\"row\" style=\"margin-top: 15px;\">\r\n\r\n        <div class=\"c-lg-4 c-sm-4 c-md-4\">\r\n          <div class=\"field-checkbox-wrapper\">\r\n            <input type=\"checkbox\" id=\"isActiveCH\" name=\"isActiveCH\" class=\"form-checkbox\" [(ngModel)]=\"addNewBatch.is_active\">\r\n            <label for=\"isActiveCH\">Is Active</label>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-lg-4 c-sm-4 c-md-4\" *ngIf=\"examGradeFeature == '1'\">\r\n          <div class=\"field-checkbox-wrapper\">\r\n            <input id=\"enableChkBX\" name=\"enableChkBX\" type=\"checkbox\" class=\"form-checkbox\" [(ngModel)]=\"addNewBatch.is_exam_grad_feature\">\r\n            <label for=\"enableChkBX\">Enable Exam Grading System</label>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-lg-4 c-sm-4 c-md-4\">\r\n          <aside class=\"pull-left\">\r\n            <button class=\"btn fullBlue\" (click)=\"addNewBatchToList()\">Add</button>\r\n          </aside>\r\n        </div>\r\n\r\n      </div>\r\n\r\n    </section>\r\n\r\n\r\n    <div id=\"\" class=\"courses-list-table\" style=\"margin-left: -15px\">\r\n      <div class=\"table-scroll-wrapper tableBatchClass\">\r\n        <div class=\"table table-responsive \" style=\"max-height: 460px\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('batch_name')\">Batch</label>\r\n                </th>\r\n                <th>\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('batch_code')\">Batch Code</label>\r\n                </th>\r\n                <th>\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('standard_name')\">Master Course</label>\r\n                </th>\r\n                <th>\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('subject_name')\">Course</label>\r\n                </th>\r\n                <th>\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('teacher_name')\">Faculty</label>\r\n                </th>\r\n                <th>\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('start_date')\">Start Date</label>\r\n                </th>\r\n                <th>\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('end_date')\">End Date</label>\r\n                </th>\r\n                <th>\r\n                  <label style=\"cursor:pointer;\">Academic Year</label>\r\n                </th>\r\n                <th>\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('class_room_name')\">Class Room No.</label>\r\n                </th>\r\n                <th>\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('is_active')\">Is Active</label>\r\n                </th>\r\n                <th>\r\n                  <label style=\"cursor:pointer;\" (click)=\"sortTable('total_students')\">Total Students</label>\r\n                </th>\r\n                <th>\r\n                  Edit\r\n                </th>\r\n                <th>\r\n                  Add Students\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody *ngIf=\"(tableData.length != 0)\">\r\n              <tr id=\"row{{i}}\" (click)=\"rowSelectEvent(i)\" [class.selected]=\"i == selectedRow\" class=\"displayComp\" *ngFor=\"let row of tableData; let i=index; trackBy: i; \">\r\n                <td class=\"view-comp\">\r\n                  <span title=\"{{row.batch_name}}\">{{row.batch_name.length>20?(row.batch_name | slice:0:20):row.batch_name}}</span>\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper editCellAllignment\">\r\n                    <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"row.batch_name\">\r\n                  </div>\r\n                </td>\r\n\r\n                <td class=\"view-comp\">\r\n                  {{row.batch_code}}\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper\">\r\n                    <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"row.batch_code\">\r\n                  </div>\r\n                </td>\r\n\r\n                <td class=\"view-comp\">\r\n                  {{row.standard_name}}\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper editCellAllignment\">\r\n                    <select id=\"\" class=\"form-ctrl\" name=\"row.category_id\" (change)=\"onMasterCourseSelection(editRowDetails.standard_id)\" [(ngModel)]=\"editRowDetails.standard_id\">\r\n                      <option *ngFor=\"let opt of courseList\" [value]=\"opt.standard_id\">\r\n                        {{opt.standard_name}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </td>\r\n\r\n                <td class=\"view-comp\">\r\n                  {{row.subject_name}}\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper editCellAllignment\">\r\n                    <select id=\"\" class=\"form-ctrl\" name=\"row.category_id\" [(ngModel)]=\"editRowDetails.subject_id\">\r\n                      <option *ngFor=\"let opt of subjectList\" [value]=\"opt.subject_id\">\r\n                        {{opt.subject_name}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </td>\r\n\r\n\r\n                <td class=\"view-comp\">\r\n                  {{row.teacher_name}}\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper editCellAllignment\">\r\n                    <select id=\"\" class=\"form-ctrl\" name=\"row.category_id\" [(ngModel)]=\"row.teacher_id\">\r\n                      <option value=\"0\"></option>\r\n                      <option *ngFor=\"let opt of teacherList\" [value]=\"opt.teacher_id\">\r\n                        {{opt.teacher_name}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </td>\r\n\r\n                <td>\r\n                  {{row.start_date}}\r\n                </td>\r\n\r\n                <td class=\"view-comp\">\r\n                  {{changeDateFormat(row.end_date)}}\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper\">\r\n                    <label for=\"endDate\">\r\n                    </label>\r\n                    <input type=\"text\" value=\"\" readonly=\"true\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"row.end_date\" name=\"endDate\" bsDatepicker\r\n                      id=\"endDate\">\r\n\r\n                  </div>\r\n                </td>\r\n                <td class=\"view-comp\">\r\n                  <select class=\"form-ctrl\" [disabled]=\"true\" [ngStyle]=\"{'background':row.academic_year_id? 'lightgrey':'','cursor':row.academic_year_id ? 'not-allowed':''}\"\r\n                    [(ngModel)]=\"row.academic_year_id\" style=\"background: transparent\">\r\n                    <option value=\"-1\">Select</option>\r\n                    <option *ngFor=\"let opt of academicList\" [value]=\"opt.inst_acad_year_id\">\r\n                      {{opt.inst_acad_year}}\r\n                    </option>\r\n                  </select>\r\n                </td>\r\n\r\n                <td class=\"view-comp\">\r\n                  {{row.class_room_name}}\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper\">\r\n                    <select id=\"\" class=\"form-ctrl \" name=\"row.academic_year_id\" [(ngModel)]=\"editRowDetails.academic_year_id\">\r\n                      <option value=\"-1\">Select</option>\r\n                      <option *ngFor=\"let opt of academicList\" [value]=\"opt.inst_acad_year_id\">\r\n                        {{opt.inst_acad_year}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper\">\r\n                    <select id=\"\" class=\"form-ctrl\" name=\"row.category_id\" [(ngModel)]=\"editRowDetails.class_room_id\">\r\n                      <option *ngFor=\"let opt of classRoomList\" [value]=\"opt.class_room_id\">\r\n                        {{opt.class_room_name}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </td>\r\n\r\n                <td class=\"view-comp\">\r\n                  {{row.is_active}}\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <select [(ngModel)]=\"row.is_active\">\r\n                    <option value=\"Y\">Yes</option>\r\n                    <option value=\"N\">No</option>\r\n                  </select>\r\n                </td>\r\n\r\n                <td>\r\n                  <span *ngIf=\"row.is_active == 'Y'\">{{row.total_students}}</span>\r\n                </td>\r\n\r\n                <td class=\"view-comp\">\r\n                  <a style=\"cursor:pointer\" (click)=\"editTableRow(row , i)\">\r\n                    <i class=\"edit-icon\" aria-hidden=\"true\" style=\"margin-right: 5px;\" title=\"Edit\"></i>Edit\r\n                  </a>\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <a style=\"cursor:pointer ; margin-right:10px\" (click)=\"updateTableRow(row , i)\">\r\n                    <i class=\"far fa fa-save\" style=\"font-family: FontAwesome ;font-size: 19px;\" title=\"Update\"></i>\r\n                  </a>\r\n                  <a style=\"cursor:pointer\" (click)=\"cancelTableRow(row , i)\">\r\n                    <i class=\"fas fa fa-times\" style=\"font-family: FontAwesome ;font-size: 19px;\" title=\"Cancel\"></i>\r\n                  </a>\r\n                </td>\r\n\r\n                <td>\r\n                  <a style=\"cursor:pointer\" (click)=\"addStudentToBatch(row)\">\r\n                    <i class=\"far fa fa-plus-square\" style=\"font-size: 14px\" alt=\"Add Student\" title=\"Add Student\"></i>\r\n                  </a>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n            <tbody *ngIf=\"tableData.length == 0 && dataStatus === 1\">\r\n              <tr *ngFor=\"let dummy of dummyArr\">\r\n                <td *ngFor=\"let c of columnMaps\">\r\n                  <div class=\"skeleton\">\r\n                  </div>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n            <tbody *ngIf=\"(tableData.length == 0 && dataStatus === 2)\">\r\n              <tr>\r\n                <td colspan=\"13\">\r\n                  No Batch List Found\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <section>\r\n    <!-- Paginator Here -->\r\n    <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n      <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n        <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n          [page]=\"PageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRow\">\r\n        </pagination>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n</div>\r\n\r\n\r\n\r\n<!-- Allocation Item History -->\r\n<!-- =============================================================================== -->\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"addStudentPopUp\">\r\n  <div class=\"popup pos-abs popup-body-container\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closeStudentPopup()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n          <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n            <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n              <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n            </g>\r\n            <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n            />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content student-assign-popup\">\r\n        <div>\r\n          <h3>Batch Name : {{batchDetails.batch_name}}</h3>\r\n        </div>\r\n\r\n        <div class=\"row filter-section\">\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6 radio-button\">\r\n            <div class=\"field-radio-wrapper\">\r\n              <input type=\"radio\" name=\"bothRadio\" id=\"bothRadio\" class=\"form-radio\" value=\"0\" [(ngModel)]=\"radioOption\" (ngModelChange)=\"onRadioButtonChange()\">\r\n              <label for=\"bothRadio\">Both</label>\r\n            </div>\r\n            <div class=\"field-radio-wrapper\">\r\n              <input type=\"radio\" name=\"assignRadio\" id=\"assignRadio\" value=\"1\" class=\"form-radio\" [(ngModel)]=\"radioOption\" (ngModelChange)=\"onRadioButtonChange()\">\r\n              <label for=\"assignRadio\">Assigned</label>\r\n            </div>\r\n            <div class=\"field-radio-wrapper\">\r\n              <input type=\"radio\" name=\"unassignStudent\" id=\"unassignStudent\" value=\"2\" class=\"form-radio\" [(ngModel)]=\"radioOption\" (ngModelChange)=\"onRadioButtonChange()\">\r\n              <label for=\"unassignStudent\">UnAssigned</label>\r\n            </div>\r\n          </div>\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"search-filter-wrapper\">\r\n              <input #searchVal type=\"text\" class=\"normal-field\" placeholder=\"Search\" id=\"searchStudent\" name=\"searchData\" [(ngModel)]=\"searchData\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"table-wrapper\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  <div class=\"field-checkbox-wrapper\">\r\n                    <input #idSelectAll type=\"checkbox\" class=\"form-checkbox\" [(ngModel)]=\"allChecked\" (click)=\"selectAllCheckBox(idSelectAll)\">\r\n                    <label></label>\r\n                  </div>\r\n                </th>\r\n                <th>\r\n                  ID\r\n                </th>\r\n                <th>\r\n                  Name\r\n                </th>\r\n                <th>\r\n                  Country\r\n                </th>\r\n                <th>\r\n                  Contact No.\r\n                </th>\r\n                <!-- <th>\r\n                  Institution Name\r\n                </th> -->\r\n                <th>\r\n                  Standard Class\r\n                </th>\r\n                <th>\r\n                  Academic Year\r\n                </th>\r\n                <th>\r\n                  Fee Template\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr id=\"row{{i}}\" *ngFor=\"let row of (dataTable | searchPipe:searchData); let i = index; trackBy: i;\">\r\n                <td>\r\n                  <div class=\"field-checkbox-wrapper\">\r\n                    <input type=\"checkbox\" id=\"studentcheck{{row.student_id}}\" class=\"form-checkbox\" [(ngModel)]=\"row.assigned\">\r\n                    <!--  [disabled]=\"row.immutableKey\"  -->\r\n                    <label></label>\r\n                  </div>\r\n                </td>\r\n                <td>\r\n                  {{row.student_disp_id}}\r\n                </td>\r\n                <td>\r\n                  {{row.student_name}}\r\n                </td>\r\n                <td [title]=\"row.country_name\">\r\n                  {{row.country_code}}\r\n                </td>\r\n                <td>\r\n                  {{row.student_phone}}\r\n                </td>\r\n                <!-- <td>\r\n                  {{row.school}}\r\n                </td> -->\r\n                <td>\r\n                  {{row.student_class}}\r\n                </td>\r\n                <td>\r\n                  <div class=\"field-wrapper\">\r\n                    <select class=\"form-ctrl\" [disabled]=\"true\" [ngStyle]=\"{'background':row.academic_year_id? 'lightgrey':'','cursor':row.academic_year_id ? 'not-allowed':''}\"\r\n                      [(ngModel)]=\"batchDetails.academic_year_id\" style=\"background: transparent\">\r\n                      <option value=\"-1\">Select</option>\r\n                      <option *ngFor=\"let opt of academicList\" [value]=\"opt.inst_acad_year_id\">\r\n                        {{opt.inst_acad_year}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </td>\r\n                <td>\r\n                  <div class=\"field-wrapper\">\r\n                    <select class=\"form-ctrl\" [disabled]=\"row.immutableKey\" [(ngModel)]=\"row.assigned_fee_template_id\" style=\"background: transparent\">\r\n                      <option value=\"-1\">Select</option>\r\n                      <option *ngFor=\"let opt of setDefaultTemplate(row.country_id,feeTemplateDataSource,row) \" [value]=\"opt.template_id\">\r\n                        {{opt.template_name}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </td>\r\n              </tr>\r\n              <tr *ngIf=\"(dataTable.length == 0)\">\r\n                <td colspan=\"8\">\r\n                  No Student Found\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n\r\n        <div class=\"pull-right\" style=\"padding: 5px 10px 0 0;\">\r\n          <button class=\"btn fullBlue\" (click)=\"saveChanges()\">Save</button>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n<section [hidden]=\"alertBox\">\r\n  <div class=\"confirmation_popup\">\r\n    <div class=\"confirm_title\">\r\n      <i class=\"fa fa-exclamation-triangle\" aria-hidden=\"true\" style=\"color: rgba(255,0,0,0.7);\"></i> &nbsp;\r\n      <span>Alert</span>\r\n    </div>\r\n    <div class=\"confirmation_msg_box\">\r\n      <span id=\"confirm_msg\">Do you wish to unassign student from the batch?</span>\r\n    </div>\r\n    <br>\r\n    <div class=\"field-checkbox-wrapper\">\r\n      <input type=\"checkbox\" id=\"delete_unpaid_fee\" name=\"batch\" [(ngModel)]=\"delete_unpaid_fee\" class=\"form-checkbox\">\r\n      <label> Delete unpaid fees installments</label>\r\n    </div>\r\n    <div class=\"confirmation_button_container\">\r\n      <input type=\"button\" value=\"Yes\" class=\"btn\" (click)=\"unassign_course()\">\r\n      <input type=\"button\" value=\"No\" class=\"btn\" (click)=\"closeAlert()\">\r\n      <!-- <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closeAlert()\"> -->\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n<div class=\"black-bg\" id=\"black-bg\" [hidden]=\"alertBox\" (click)=\"closeAlert()\">\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/components/course-module/create-course/manage-batch/manage-batch.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.add-edit {\n  margin-bottom: 15px;\n  margin-top: 15px; }\n.add-edit i {\n    display: inline-block;\n    width: 17px;\n    height: 17px;\n    border-radius: 50%;\n    line-height: 16px;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle;\n    margin-right: 4px; }\n.add-edit span {\n    display: inline-block; }\n.add-edit .expend-box i {\n    line-height: 12px;\n    font-size: 22px; }\n.add-edit a {\n    cursor: pointer; }\n.closeBtnClass {\n  line-height: 11px !important; }\n.create-standard-form {\n  margin: 0px 0;\n  position: absolute;\n  width: 92%;\n  top: 25%;\n  left: 6.5%;\n  padding: 10px 20px 20px;\n  background: #ffffff;\n  border: 1px solid #d8d8d8; }\n.create-standard-form .form-ctrl {\n    background: transparent;\n    border-bottom: solid 1px #cccccc; }\n.search-filter-wrapper .normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  height: 35px;\n  font-size: 14px; }\n.search-filter-wrapper .field-wrapper {\n  position: relative;\n  padding-top: 0px !important;\n  width: 30%;\n  float: left !important; }\n.search-filter-wrapper .field-wrapper .form-ctrl {\n    font: 400 12px 'Open sans',sans-serif;\n    border-top: none !important;\n    border-right: none !important;\n    border-left: none !important; }\n.search-filter-wrapper .field-wrapper label {\n  position: absolute !important;\n  left: 10% !important;\n  top: 1% !important; }\n.search-filter-wrapper .field-wrapper label:after {\n    left: 85% !important;\n    top: 10px !important; }\n.normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  border-right: 0;\n  height: 35px;\n  font-size: 14px; }\n#divBatchTable .tableBatchClass {\n  max-height: 385px;\n  overflow-x: hidden;\n  overflow-y: scroll; }\n#divBatchTable ::-webkit-scrollbar {\n  display: block;\n  width: 7px;\n  height: 7px; }\ntable thead tr th {\n  width: 8%;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  font-size: 12px;\n  font-weight: 500; }\ntable tbody tr td {\n  padding: 10px 5px;\n  width: 8%; }\ntable tbody tr td .editOptions li {\n    display: inline-block; }\ntable tbody tr .field-wrapper {\n  padding: 0px !important; }\ntable tbody tr .field-wrapper .form-ctrl {\n    display: block;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 0px 0px 0px 5px;\n    outline: none;\n    border: 0;\n    height: 26px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 25px;\n    background: transparent;\n    width: 80px;\n    text-align: center;\n    border-bottom: 1px solid #ccc; }\ntable tbody .displayComp .edit-comp {\n  display: none; }\ntable tbody .editComp .view-comp {\n  display: none; }\n.editCellAllignment {\n  margin-left: 30px; }\n/*=====================================mobile head menu css===========================*/\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 850px;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n.skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 80%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n.skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n@-webkit-keyframes progress {\n  0% {\n    -webkit-transform: translate3d(-100%, 0, 0);\n            transform: translate3d(-100%, 0, 0); }\n  100% {\n    -webkit-transform: translate3d(100%, 0, 0);\n            transform: translate3d(100%, 0, 0); } }\n@keyframes progress {\n  0% {\n    -webkit-transform: translate3d(-100%, 0, 0);\n            transform: translate3d(-100%, 0, 0); }\n  100% {\n    -webkit-transform: translate3d(100%, 0, 0);\n            transform: translate3d(100%, 0, 0); } }\n.add-batch-section {\n  margin: 0px 0px 10px -15px;\n  padding: 0px 15px 5px 15px;\n  background: #efefef;\n  border-top: 1px solid #d8d8d8;\n  margin-bottom: 10px; }\n.add-batch-section .halfwidth {\n    width: 200px; }\n.add-batch-section .halfwidth.bsDatepicker {\n      background: white; }\n.add-batch-section .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(/./assets/images/calendar.svg) no-repeat;\n    position: absolute;\n    left: 175px;\n    top: 35px;\n    width: 21px;\n    height: 21px;\n    z-index: 999999; }\n.search-filter-wrapper .normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  height: 35px;\n  font-size: 14px; }\n.student-assign-popup .filter-section {\n  padding: 10px 0px;\n  margin: 5px 0;\n  background: #efefef; }\n.student-assign-popup .filter-section .radio-button {\n    margin-top: 10px;\n    display: -webkit-inline-box;\n    display: -ms-inline-flexbox;\n    display: inline-flex; }\n.student-assign-popup .filter-section .radio-button .field-radio-wrapper {\n      margin-right: 5px; }\n.student-assign-popup .filter-section .field-wrapper {\n    padding-top: 0; }\n.student-assign-popup .filter-section .btn {\n    margin-left: 0; }\n.student-assign-popup .table-wrapper {\n  margin-top: 15px;\n  max-height: 350px;\n  overflow-x: hidden;\n  overflow-y: scroll; }\n.student-assign-popup .table-wrapper th {\n    text-align: left; }\n.student-assign-popup .table-wrapper td {\n    text-align: left;\n    padding: 5px; }\n.student-assign-popup .table-wrapper td .field-wrapper .form-ctrl {\n      padding: 5px;\n      width: 90px; }\n.black-bg {\n  background: rgba(10, 10, 10, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 1;\n  width: 100%; }\n::ng-deep bs-datepicker-container, bs-daterangepicker-container {\n  margin-left: 3%; }\n.confirmation_popup {\n  position: fixed;\n  top: 35%;\n  left: 40%;\n  width: 300px;\n  background: white;\n  height: auto;\n  padding: 20px;\n  z-index: 100;\n  border-radius: 6px;\n  border-top: 4px solid rgba(255, 0, 0, 0.7);\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c; }\n.confirm_title {\n  font-size: 20px; }\n.confirmation_msg_box {\n  margin-top: 15px; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox {\n  opacity: 0;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px;\n  z-index: 1;\n  border: 2px solid #0084f6; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox + label {\n  vertical-align: middle;\n  font-size: 14px;\n  display: inline-block; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 2px;\n  position: absolute;\n  left: 0;\n  top: 0; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox:checked + label:after {\n  border: 2px solid #0084f6; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox + label:before {\n  width: 1px;\n  height: 1px;\n  left: 8px;\n  top: 9px;\n  position: absolute;\n  content: '';\n  border-top: 0;\n  border-right: 0;\n  border-left: 2px solid transparent;\n  border-bottom: 2px solid transparent;\n  -webkit-transform: rotate(-45deg);\n          transform: rotate(-45deg); }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox:checked + label:before {\n  border-left: 2px solid #0084f6;\n  border-bottom: 2px solid #0084f6;\n  width: 12px;\n  height: 5px;\n  left: 2px;\n  top: 5px; }\n.confirmation_popup .field-checkbox-wrapper .form-checkbox:checked + label {\n  color: #0084f6; }\n.confirmation_button_container {\n  margin-top: 20px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center; }\n.confirmation_button_container input {\n    width: 80px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/manage-batch/manage-batch.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ManageBatchComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_course_services_manage_batch_service__ = __webpack_require__("./src/app/services/course-services/manage-batch.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ManageBatchComponent = /** @class */ (function () {
    function ManageBatchComponent(apiService, toastCtrl) {
        this.apiService = apiService;
        this.toastCtrl = toastCtrl;
        this.batchesListDataSource = [];
        this.tableData = [];
        this.courseList = [];
        this.studentListDataSource = [];
        this.studentList = [];
        this.searchedData = [];
        this.dummyArr = [0, 1, 2, 3, 4, 0, 1, 2, 3, 4];
        this.columnMaps = [0, 1, 2, 3, 4, 5, 0, 1, 2, 3, 4, 5, 0];
        this.academicList = [];
        this.feeTemplateDataSource = [];
        this.dataTable = [];
        this.PageIndex = 1;
        this.displayBatchSize = 10;
        this.dataStatus = 1;
        this.examGradeFeature = "";
        this.searchData = "";
        this.radioOption = '0';
        this.searchDataFlag = false;
        this.alertBox = true;
        this.delete_unpaid_fee = false;
        this.addStudentPopUp = false;
        this.createNewBatch = false;
        this.allChecked = false;
        this.isRippleLoad = false;
        this.editRowDetails = {
            standard_id: '',
            subject_id: '',
            teacher_id: '',
            class_room_id: ''
        };
        this.addNewBatch = {
            standard_id: '-1',
            subject_id: '-1',
            class_room_id: '-1',
            teacher_id: '-1',
            batch_name: '',
            batch_code: '',
            start_date: '',
            end_date: '',
            is_active: true,
            academic_year_id: '-1',
            is_exam_grad_feature: false
        };
    }
    ManageBatchComponent.prototype.ngOnInit = function () {
        this.checkTabSelection();
        this.examGradeFeature = sessionStorage.getItem('is_exam_grad_feature');
        this.getAllBatchesList();
        this.getMasterCourseList();
        this.getAllClassRoom();
        this.getAllTeacherList();
        this.getAcademicYearDetails();
    };
    ManageBatchComponent.prototype.getAllBatchesList = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.batchesListDataSource = [];
        this.tableData = [];
        this.apiService.getBatchListFromServer().subscribe(function (res) {
            _this.batchesListDataSource = res;
            _this.totalRow = res.length;
            _this.fetchTableDataByPage(_this.PageIndex);
            _this.isRippleLoad = false;
            _this.dataStatus = 2;
        }, function (error) {
            _this.isRippleLoad = false;
            //console.log(error);
            _this.messageToast('error', '', error.error.message);
        });
    };
    ManageBatchComponent.prototype.editTableRow = function (rowDetails, index) {
        var _this = this;
        this.isRippleLoad = true;
        document.getElementById(("row" + index).toString()).classList.remove('displayComp');
        document.getElementById(("row" + index).toString()).classList.add('editComp');
        this.apiService.getBatchDetailsForEdit(rowDetails.batch_id).subscribe(function (data) {
            //console.log(data);
            _this.editRowDetails = data;
            _this.onMasterCourseSelection(data.standard_id);
            _this.isRippleLoad = false;
        }, function (error) {
            _this.isRippleLoad = false;
            //console.log(error);
            _this.messageToast('error', '', error.error.message);
        });
    };
    ManageBatchComponent.prototype.searchDatabase = function (element) {
        if (element.value != '' && element.value != null) {
            var searchData = this.batchesListDataSource.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(element.value.toLowerCase()); });
            });
            this.searchedData = searchData;
            this.searchDataFlag = true;
            this.totalRow = searchData.length;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchDataFlag = false;
            this.fetchTableDataByPage(this.PageIndex);
            this.totalRow = this.batchesListDataSource.length;
        }
    };
    ManageBatchComponent.prototype.togglecreateNewBatch = function () {
        this.selectedRow = null;
        if (this.createNewBatch == false) {
            this.createNewBatch = true;
            document.getElementById('showCloseBtn').style.display = '';
            document.getElementById('showAddBtn').style.display = 'none';
        }
        else {
            this.createNewBatch = false;
            document.getElementById('showCloseBtn').style.display = 'none';
            document.getElementById('showAddBtn').style.display = '';
        }
    };
    // set default template and set 
    ManageBatchComponent.prototype.setDefaultTemplate = function (country_id, templates, data) {
        templates[country_id] && templates[country_id].forEach(function (object) {
            if (object.is_default == 'Y' && data.assigned_fee_template_id == -1) {
                data.assigned_fee_template_id = object.template_id;
            }
        });
        return templates[country_id];
    };
    ManageBatchComponent.prototype.getAllClassRoom = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getBatchClassRoomListFromServer().subscribe(function (data) {
            _this.classRoomList = data;
            _this.isRippleLoad = false;
        }, function (error) {
            _this.isRippleLoad = false;
            //console.log(error);
            _this.messageToast('error', '', error.error.message);
        });
    };
    ManageBatchComponent.prototype.getAllTeacherList = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getTeachersListFromServer().subscribe(function (res) {
            _this.teacherList = res;
            _this.isRippleLoad = false;
        }, function (error) {
            _this.isRippleLoad = false;
            //console.log(error);
            _this.messageToast('error', '', error.error.message);
        });
    };
    ManageBatchComponent.prototype.getMasterCourseList = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getMasterCourseListFromServer().subscribe(function (res) {
            _this.courseList = res;
            _this.isRippleLoad = false;
        }, function (error) {
            _this.isRippleLoad = false;
            //console.log(error);
            _this.messageToast('error', '', error.error.message);
        });
    };
    ManageBatchComponent.prototype.onMasterCourseSelection = function (data) {
        var _this = this;
        this.isRippleLoad = true;
        this.addNewBatch.subject_id = '-1';
        if (data != '-1') {
            this.apiService.getPerticularCourseList(data).subscribe(function (res) {
                //console.log('Subject List', res);
                _this.subjectList = res;
                _this.isRippleLoad = false;
            }, function (error) {
                _this.isRippleLoad = false;
                //console.log(error);
                _this.messageToast('error', '', error.error.message);
            });
        }
        else {
            this.isRippleLoad = false;
            this.messageToast('error', '', 'You Can not select empty value');
            return;
        }
    };
    ManageBatchComponent.prototype.addNewBatchToList = function () {
        var _this = this;
        if (this.addNewBatch.standard_id != '-1') {
            if (this.addNewBatch.subject_id != "-1") {
                if (this.addNewBatch.teacher_id != "-1") {
                    if (this.addNewBatch.batch_name.trim() != '') {
                        if (this.addNewBatch.batch_code.length < 5) {
                            if (this.addNewBatch.start_date != "" && this.addNewBatch.start_date != null) {
                                this.addNewBatch.start_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.addNewBatch.start_date).format("YYYY-MM-DD");
                                if (this.addNewBatch.end_date != "" && this.addNewBatch.end_date != null) {
                                    this.addNewBatch.end_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.addNewBatch.end_date).format("YYYY-MM-DD");
                                    if (this.addNewBatch.start_date < this.addNewBatch.end_date) {
                                        if (this.addNewBatch.is_active == true) {
                                            this.addNewBatch.is_active = 'Y';
                                        }
                                        else {
                                            this.addNewBatch.is_active = 'N';
                                        }
                                        if (this.addNewBatch.is_exam_grad_feature == true) {
                                            this.addNewBatch.is_exam_grad_feature = 1;
                                        }
                                        else {
                                            this.addNewBatch.is_exam_grad_feature = 0;
                                        }
                                        this.apiService.addNewBatch(this.addNewBatch).subscribe(function (res) {
                                            _this.messageToast('success', 'Added Batch', "Batch created successfully!");
                                            _this.clearFormData();
                                            _this.getAllBatchesList();
                                            _this.togglecreateNewBatch();
                                        }, function (error) {
                                            //console.log(error);
                                            _this.messageToast('error', '', error.error.message);
                                        });
                                    }
                                    else {
                                        this.messageToast('error', '', 'Provide valid details of Start Date');
                                        return;
                                    }
                                }
                                else {
                                    this.messageToast('error', '', 'Please Provide End Date');
                                    return;
                                }
                            }
                            else {
                                this.messageToast('error', '', 'Please Provide Start Date');
                                return;
                            }
                        }
                        else {
                            this.messageToast('error', '', 'Batch Code can not be greater than 4 alphabet');
                            return;
                        }
                    }
                    else {
                        this.messageToast('error', '', 'Provide batch name');
                        return;
                    }
                }
                else {
                    this.messageToast('error', '', 'Provide  faculty name');
                    return;
                }
            }
            else {
                this.messageToast('error', '', 'select course');
                return;
            }
        }
        else {
            this.messageToast('error', '', 'Select master course');
        }
    };
    ManageBatchComponent.prototype.updateTableRow = function (rowDetails, index) {
        var _this = this;
        var dataToSend = {
            batch_code: rowDetails.batch_code,
            batch_name: rowDetails.batch_name,
            start_date: __WEBPACK_IMPORTED_MODULE_3_moment__(rowDetails.start_date).format("YYYY-MM-DD"),
            end_date: __WEBPACK_IMPORTED_MODULE_3_moment__(rowDetails.end_date).format("YYYY-MM-DD"),
            subject_id: this.editRowDetails.subject_id,
            teacher_id: Number(rowDetails.teacher_id),
            is_active: rowDetails.is_active,
            isStudentToBeInactivated: this.editRowDetails.isStudentToBeInactivated,
            class_room_id: this.editRowDetails.class_room_id,
            academic_year_id: this.editRowDetails.academic_year_id
        };
        if (dataToSend.start_date > dataToSend.end_date) {
            this.messageToast('error', '', 'Provide valid dates.');
            return;
        }
        var endDate = __WEBPACK_IMPORTED_MODULE_3_moment__(this.editRowDetails.end_date).format("YYYY-MM-DD");
        if (!(dataToSend.end_date >= endDate)) {
            this.messageToast('error', '', 'Batch end date can only be extended.');
            return;
        }
        if (rowDetails.batch_code.length > 4) {
            this.messageToast('error', '', 'Batch Code can not be greater than 4 digits.');
            return;
        }
        if (rowDetails.teacher_id == 0 || rowDetails.teacher_id == null || rowDetails.teacher_id == "") {
            this.messageToast('error', '', 'Please enter the faculty for the batch.');
            return;
        }
        this.isRippleLoad = true;
        this.apiService.updateDataToServer(dataToSend, rowDetails.batch_id).subscribe(function (data) {
            _this.isRippleLoad = false;
            document.getElementById(("row" + index).toString()).classList.remove('editComp');
            document.getElementById(("row" + index).toString()).classList.add('displayComp');
            _this.messageToast('success', 'Updated', 'Details Updated Successfully.');
            _this.getAllBatchesList();
        }, function (error) {
            _this.isRippleLoad = false;
            _this.messageToast('error', '', error.error.message);
        });
    };
    ManageBatchComponent.prototype.cancelTableRow = function (rowDetails, index) {
        document.getElementById(("row" + index).toString()).classList.remove('editComp');
        document.getElementById(("row" + index).toString()).classList.add('displayComp');
        this.getAllBatchesList();
    };
    ManageBatchComponent.prototype.clearFormData = function () {
        this.addNewBatch = {
            standard_id: '-1',
            subject_id: '-1',
            class_room_id: '-1',
            teacher_id: '-1',
            batch_name: '',
            batch_code: '',
            start_date: '',
            end_date: '',
            is_active: true,
            academic_year_id: '-1',
            is_exam_grad_feature: false
        };
    };
    ManageBatchComponent.prototype.addStudentToBatch = function (rowDetails) {
        this.addStudentPopUp = true;
        this.batchDetails = rowDetails;
        this.getAllFeeTemplate();
        this.getAllStudentList(rowDetails);
    };
    ManageBatchComponent.prototype.getAcademicYearDetails = function () {
        var _this = this;
        this.academicList = [];
        this.apiService.getAcadYear().subscribe(function (res) {
            _this.academicList = res;
        }, function (err) {
        });
    };
    ManageBatchComponent.prototype.getAllFeeTemplate = function () {
        var _this = this;
        this.apiService.getFeeTemplate(this.batchDetails.subject_id).subscribe(function (res) {
            _this.feeTemplateDataSource = res;
        }, function (err) {
            //console.log(err);
        });
    };
    ManageBatchComponent.prototype.getAllStudentList = function (rowDetails) {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getStudentListFromServer(rowDetails.batch_id).subscribe(function (res) {
            _this.radioOption = '0';
            res.map(function (element) {
                element.immutableKey = element.assigned;
            });
            _this.studentListDataSource = res;
            _this.studentList = _this.keepCloning(res);
            _this.dataTable = _this.studentList;
            _this.getHeaderCheckBoxValue(_this.dataTable);
            _this.isRippleLoad = false;
        }, function (error) {
            _this.isRippleLoad = false;
            _this.messageToast('error', '', error.error.message);
        });
    };
    ManageBatchComponent.prototype.onRadioButtonChange = function () {
        this.searchData = "";
        if (this.studentList.length > 0) {
            if (this.radioOption == '0') {
                this.dataTable = this.studentList;
            }
            else if (this.radioOption == '1') {
                this.dataTable = this.studentList.filter(function (el) { return el.assigned == true; });
            }
            else {
                this.dataTable = this.studentList.filter(function (el) { return el.assigned == false; });
            }
            this.getHeaderCheckBoxValue(this.dataTable);
        }
        else {
            this.dataTable = [];
        }
    };
    ManageBatchComponent.prototype.checkIfStudentUnassigned = function () {
        var check = false;
        for (var i = 0; i < this.studentListDataSource.length; i++) {
            for (var j = 0; j < this.studentList.length; j++) {
                if (this.studentListDataSource[i].assigned) {
                    if (this.studentList[j].assigned == false && this.studentListDataSource[i].student_id == this.studentList[j].student_id) {
                        check = true;
                        break;
                    }
                }
            }
        }
        return check;
    };
    ManageBatchComponent.prototype.saveChanges = function () {
        var studentUnAssigned = this.checkIfStudentUnassigned();
        if (studentUnAssigned) {
            this.alertBox = false;
            // if (confirm("If you unassign the student from batch then corresponding unpaid fee instalments might be deleted.")) {
            //   this.saveStudentListToServer();
            // }
        }
        else {
            this.saveStudentListToServer();
        }
    };
    ManageBatchComponent.prototype.closeAlert = function () {
        this.alertBox = true;
        this.delete_unpaid_fee = false;
        var data = this.getCheckedRows();
        for (var i = 0; i < Object.keys(data).length; i++) {
            document.getElementById("studentcheck" + Object.keys(data)[i]).checked = true;
        }
    };
    ManageBatchComponent.prototype.unassign_course = function () {
        this.alertBox = true;
        this.saveStudentListToServer();
    };
    ManageBatchComponent.prototype.saveStudentListToServer = function () {
        var _this = this;
        var data = this.getCheckedRows();
        var dataToSend = {
            batch_id: this.batchDetails.batch_id,
            studentAssignedUnassigned_and_AcademicYearMapping: data,
            deleteCourse_SubjectUnPaidFeeSchedules: this.delete_unpaid_fee
        };
        this.isRippleLoad = true;
        // console.log(dataToSend)
        this.apiService.saveUpdatedList(dataToSend, this.batchDetails.batch_id).subscribe(function (res) {
            _this.messageToast('success', 'Saved', 'Changes saved successfully.');
            _this.studentList = [];
            _this.addStudentPopUp = false;
            _this.isRippleLoad = false;
            _this.getAllBatchesList();
            _this.searchData = "";
        }, function (err) {
            _this.isRippleLoad = false;
            //console.log(err);
            _this.messageToast('error', '', err.error.message);
        });
    };
    ManageBatchComponent.prototype.getCheckedRows = function () {
        var test = {};
        for (var i = 0; i < this.studentListDataSource.length; i++) {
            for (var t = 0; t < this.studentList.length; t++) {
                if (this.studentList[t].student_id == this.studentListDataSource[i].student_id) {
                    if (this.studentList[t].assigned != this.studentListDataSource[i].assigned) {
                        test[this.studentList[t].student_id] = [this.studentList[t].assigned.toString(), this.studentList[t].academic_year.toString(), this.studentList[i].assigned_fee_template_id.toString()];
                    }
                }
            }
        }
        return test;
    };
    ManageBatchComponent.prototype.selectAllCheckBox = function (element) {
        var val = element.checked;
        for (var i = 0; i < this.studentList.length; i++) {
            this.studentList[i].assigned = val;
        }
    };
    ManageBatchComponent.prototype.closeStudentPopup = function () {
        this.addStudentPopUp = false;
        this.searchData = "";
        this.alertBox = true;
    };
    ManageBatchComponent.prototype.changeDateFormat = function (date) {
        if (date != "" && date != null) {
            return __WEBPACK_IMPORTED_MODULE_3_moment__(date).format("D-MMM-YYYY");
        }
    };
    ManageBatchComponent.prototype.getHeaderCheckBoxValue = function (res) {
        for (var i = 0; i < res.length; i++) {
            if (res[i].assigned == false) {
                this.allChecked = false;
                break;
            }
            else {
                this.allChecked = true;
            }
        }
    };
    ManageBatchComponent.prototype.keepCloning = function (objectpassed) {
        if (objectpassed === null || typeof objectpassed !== 'object') {
            return objectpassed;
        }
        var temporaryStorage = objectpassed.constructor();
        for (var key in objectpassed) {
            temporaryStorage[key] = this.keepCloning(objectpassed[key]);
        }
        return temporaryStorage;
    };
    ManageBatchComponent.prototype.messageToast = function (errorType, errorTitle, errorMeassage) {
        var data = {
            type: errorType,
            title: errorTitle,
            body: errorMeassage
        };
        this.toastCtrl.popToast(data);
    };
    ManageBatchComponent.prototype.sortTable = function (str) {
        if (str == "batch_name" || str == "standard_name" || str == "subject_name" || str == "teacher_name" || str == "is_active") {
            this.tableData.sort(function (a, b) {
                var nameA = a[str].toUpperCase(); // ignore upper and lowercase
                var nameB = b[str].toUpperCase(); // ignore upper and lowercase
                if (nameA < nameB) {
                    return -1;
                }
                if (nameA > nameB) {
                    return 1;
                }
                // names must be equal
                return 0;
            });
        }
        else if (str == "batch_code" || str == "class_room_name" || str == "total_students") {
            this.tableData.sort(function (a, b) {
                return a[str] - b[str];
            });
        }
        else if (str == "end_date" || str == "start_date") {
            this.tableData.sort(function (a, b) {
                return __WEBPACK_IMPORTED_MODULE_3_moment__(a[str]).unix() - __WEBPACK_IMPORTED_MODULE_3_moment__(b[str]).unix();
            });
        }
    };
    // pagination functions
    ManageBatchComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.tableData = this.getDataFromDataSource(startindex);
    };
    ManageBatchComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    ManageBatchComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    ManageBatchComponent.prototype.getDataFromDataSource = function (startindex) {
        var data = [];
        if (this.searchDataFlag == true) {
            data = this.searchedData.slice(startindex, startindex + this.displayBatchSize);
        }
        else {
            data = this.batchesListDataSource.slice(startindex, startindex + this.displayBatchSize);
        }
        return data;
    };
    ManageBatchComponent.prototype.rowSelectEvent = function (i) {
        if (this.createNewBatch == true) {
            this.selectedRow = null;
        }
        else {
            this.selectedRow = i;
        }
    };
    ManageBatchComponent.prototype.checkTabSelection = function () {
        var _this = this;
        setTimeout(function () {
            _this.hideAllTabs();
            document.getElementById('liManageBatch').classList.add('active');
        }, 200);
    };
    ManageBatchComponent.prototype.hideAllTabs = function () {
        document.getElementById('liStandard').classList.remove('active');
        document.getElementById('liSubject').classList.remove('active');
        document.getElementById('liManageBatch').classList.remove('active');
        document.getElementById('liClass').classList.remove('active');
    };
    //  Role Based Access
    ManageBatchComponent.prototype.checkIfUserHadAccess = function () {
        var permissionArray = sessionStorage.getItem('permissions');
        var userType = Number(sessionStorage.getItem('userType'));
        if (userType != 3) {
            if (permissionArray == "" || permissionArray == null) {
                return false;
            }
            else if (permissionArray.indexOf('401') != -1) {
                return false;
            }
            else {
                return true;
            }
        }
        else if (userType == 3) {
            return true;
        }
    };
    ManageBatchComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-manage-batch',
            template: __webpack_require__("./src/app/components/course-module/create-course/manage-batch/manage-batch.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/create-course/manage-batch/manage-batch.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_course_services_manage_batch_service__["a" /* ManageBatchService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */]])
    ], ManageBatchComponent);
    return ManageBatchComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/manage-batch/manage-batch.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageBatchModule", function() { return ManageBatchModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_datepicker_bs_datepicker_module__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/bs-datepicker.module.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__manage_batch_component__ = __webpack_require__("./src/app/components/course-module/create-course/manage-batch/manage-batch.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_course_services_manage_batch_service__ = __webpack_require__("./src/app/services/course-services/manage-batch.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








var ManageBatchModule = /** @class */ (function () {
    function ManageBatchModule() {
    }
    ManageBatchModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_4__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_4__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_5__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_datepicker_bs_datepicker_module__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_2__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_6__manage_batch_component__["a" /* ManageBatchComponent */]
                    }
                ])
            ],
            exports: [],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_6__manage_batch_component__["a" /* ManageBatchComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_7__services_course_services_manage_batch_service__["a" /* ManageBatchService */]
            ]
        })
    ], ManageBatchModule);
    return ManageBatchModule;
}());



/***/ }),

/***/ "./src/app/services/course-services/manage-batch.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ManageBatchService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ManageBatchService = /** @class */ (function () {
    function ManageBatchService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseURL = "";
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseURL = this.auth.getBaseUrl();
    }
    ManageBatchService.prototype.successCallback = function (res) {
        return res;
    };
    ManageBatchService.prototype.errorCallBack = function (error) {
        return error;
    };
    ManageBatchService.prototype.getBatchListFromServer = function () {
        var url = this.baseURL + "/api/v1/batches/all/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    ManageBatchService.prototype.getBatchClassRoomListFromServer = function () {
        var url = this.baseURL + "/api/v1/batchClassRoom/all/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    ManageBatchService.prototype.getMasterCourseListFromServer = function () {
        var url = this.baseURL + "/api/v1/standards/all/" + this.institute_id + "?active=Y";
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    ManageBatchService.prototype.getTeachersListFromServer = function () {
        var url = this.baseURL + "/api/v1/teachers/all/" + this.institute_id + "?active=Y";
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    ManageBatchService.prototype.getPerticularCourseList = function (data) {
        var url = this.baseURL + "/api/v1/subjects/standards/" + data + "?active=Y";
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    ManageBatchService.prototype.addNewBatch = function (data) {
        delete data['standard_id'];
        var url = this.baseURL + "/api/v1/batches";
        return this.http.post(url, data, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    ManageBatchService.prototype.getBatchDetailsForEdit = function (id) {
        var url = this.baseURL + "/api/v1/batches/" + id;
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    ManageBatchService.prototype.updateDataToServer = function (data, batch_Id) {
        var url = this.baseURL + '/api/v1/batches/' + batch_Id;
        return this.http.put(url, data, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    ManageBatchService.prototype.getStudentListFromServer = function (batch_id) {
        var url = this.baseURL + "/api/v1/allStdAsgnment/all/" + this.institute_id + "/" + batch_id + "?active=Y";
        return this.http.get(url, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    ManageBatchService.prototype.saveUpdatedList = function (data, batch_id) {
        data.institute_id = this.institute_id;
        var url = this.baseURL + "/api/v1/allStdAsgnment/" + batch_id;
        return this.http.post(url, data, { headers: this.headers }).map(this.successCallback, this.errorCallBack);
    };
    //  Get acadmeic Year Details
    ManageBatchService.prototype.getAcadYear = function () {
        var url = this.baseURL + "/api/v1/academicYear/all/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (err) {
            return err;
        });
    };
    ManageBatchService.prototype.getFeeTemplate = function (batch_id) {
        // https://test999.proctur.com/StdMgmtWebAPI/api/v1/studentWise/fee/fee_template_country_wise/100135?course_id=-1&subject_id=1372
        var url = this.baseURL + "/api/v1/studentWise/fee/fee_template_country_wise/" + this.institute_id + "?course_id=-1&subject_id=" + batch_id;
        return this.http.get(url, { headers: this.headers }).map(function (res) {
            return res;
        }, function (error) {
            return error;
        });
    };
    ManageBatchService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */],
            __WEBPACK_IMPORTED_MODULE_2__authenticator_service__["a" /* AuthenticatorService */]])
    ], ManageBatchService);
    return ManageBatchService;
}());



/***/ })

});
//# sourceMappingURL=manage-batch.module.chunk.js.map