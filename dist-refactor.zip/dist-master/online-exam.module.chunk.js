webpackJsonp(["online-exam.module"],{

/***/ "./src/app/components/online-exam-module/examdesk-course-assignment/examdesk-course-assignment.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n<section class=\"clearfix middle-section\">\r\n\r\n\r\n  <div class=\"row head-section\">\r\n    <h2 class=\"pull-left\">\r\n        <a routerLink=\"/view/online-exam/\">\r\n          Online Exam\r\n      </a>\r\n      <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>ExamDesk Course Assignment</h2>\r\n    <div class=\"pull-right\">\r\n      <div class=\"search-filter-wrapper\">\r\n        <input type=\"text\" class=\"normal-field\" [(ngModel)]=\"searchValue\" placeholder=\"Search\" (keyup)=\"searchInList()\">\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"table-wrapper\">\r\n\r\n    <table>\r\n      <thead>\r\n        <tr>\r\n          <th>Course Name</th>\r\n          <th>Total Assigned Student</th>\r\n          <th></th>\r\n        </tr>\r\n      </thead>\r\n      <tbody *ngIf=\"coursesList.length > 0\">\r\n        <tr *ngFor=\"let data of coursesList\">\r\n          <td>{{data.course_type}}</td>\r\n          <td>{{data.total_assigned_student_count}}</td>\r\n          <td>\r\n            <a style=\"cursor: pointer;\" (click)=\"assignStudent(data)\">Assign Student</a>\r\n          </td>\r\n        </tr>\r\n      </tbody>\r\n      <tbody *ngIf=\"coursesList.length == 0 && dataStatus === 1\">\r\n        <tr *ngFor=\"let dummy of dummyArr\">\r\n          <td *ngFor=\"let c of columnMaps\">\r\n            <div class=\"skeleton\">\r\n            </div>\r\n          </td>\r\n        </tr>\r\n      </tbody>\r\n      <tbody *ngIf=\"(coursesList.length == 0 && dataStatus === 2)\">\r\n        <tr>\r\n          <td colspan=\"6\">\r\n            No data found\r\n          </td>\r\n        </tr>\r\n      </tbody>\r\n    </table>\r\n\r\n    <!-- Paginator Here -->\r\n    <!-- <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n      <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n        <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n          [page]=\"PageIndex\" [perPage]=\"studentdisplaysize\" [count]=\"totalRow\">\r\n        </pagination>\r\n      </div>\r\n    </div> -->\r\n\r\n  </div>\r\n\r\n</section>\r\n\r\n\r\n<proctur-popup  [sizeWidth]=\"'medium'\" *ngIf=\"assignPopUp\">\r\n\r\n  <span class=\"closePopup pos-abs fbold show\" (click)=\"closePopup()\" close-button>\r\n    <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n      <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" style=\"fill: currentColor\"></path>\r\n    </svg>\r\n  </span>\r\n\r\n  <h2 popup-header>Course Name : {{tempData.course_type}}</h2>\r\n\r\n  <div popup-content class=\"student-assign-popup\">\r\n    <div class=\" filter-section\">\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-5 c-md-5 c-lg-5 radio-button\">\r\n          <div class=\"field-radio-wrapper\">\r\n            <input type=\"radio\" name=\"bothRadio\" id=\"bothRadio\" class=\"form-radio\" value=\"0\" [(ngModel)]=\"radioOption\" (ngModelChange)=\"onRadioButtonChange()\">\r\n            <label for=\"bothRadio\">Both</label>\r\n          </div>\r\n          <div class=\"field-radio-wrapper\">\r\n            <input type=\"radio\" name=\"assignRadio\" id=\"assignRadio\" value=\"1\" class=\"form-radio\" [(ngModel)]=\"radioOption\" (ngModelChange)=\"onRadioButtonChange()\">\r\n            <label for=\"assignRadio\">Assigned</label>\r\n          </div>\r\n          <div class=\"field-radio-wrapper\">\r\n            <input type=\"radio\" name=\"unassignStudent\" id=\"unassignStudent\" value=\"2\" class=\"form-radio\" [(ngModel)]=\"radioOption\" (ngModelChange)=\"onRadioButtonChange()\">\r\n            <label for=\"unassignStudent\">UnAssigned</label>\r\n          </div>\r\n        </div>\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3 radio-button\" >\r\n\r\n          <div class=\"field-radio-wrapper\"  *ngIf=\"isCourseModule\">\r\n            <input type=\"radio\" name=\"standardRadio\" id=\"standardRadio\" value=\"0\" class=\"form-radio\" [(ngModel)]=\"filterOption\" (ngModelChange)=\"onfilterOptionChange()\">\r\n            <label for=\"standardRadio\">Standard</label>\r\n          </div>\r\n          <div class=\"field-radio-wrapper\" *ngIf=\"isCourseModule\">\r\n            <input type=\"radio\" name=\"courseStudent\" id=\"courseStudent\" value=\"1\" class=\"form-radio\" [(ngModel)]=\"filterOption\" (ngModelChange)=\"onfilterOptionChange()\">\r\n            <label for=\"courseStudent\">Course</label>\r\n          </div>\r\n        </div>\r\n        <div class=\"c-sm-4 c-md-4 c-lg-4 \">\r\n          <div class=\"c-sm-12 c-md-12 c-lg-12\">\r\n            <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n              <div class=\"search-filter-wrapper\">\r\n                <input #searchVal type=\"text\" class=\"normal-field\" placeholder=\"Search\" id=\"searchStudent\" name=\"searchData\" [(ngModel)]=\"searchData\">\r\n              </div>\r\n            </div>\r\n\r\n          </div>\r\n\r\n        </div>\r\n      </div>\r\n      <div class=\"row extraMargin\" *ngIf=\"(!isCourse)&&isCourseModule\">\r\n        <div class=\"c-lg-4 c-md-4 c-sm-4 c-xs-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"master\">Standard\r\n            </label>\r\n            <select class=\"form-ctrl\" [(ngModel)]=\"standard_id\" (change)=\"onfilterOptionChange()\">\r\n              <option value=\"-1\">Standard</option>\r\n              <option *ngFor=\"let i of standardList\" [value]=\"i.standard_id\">\r\n                {{i.standard_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"row extraMargin\" *ngIf=\"isCourse&&isCourseModule\">\r\n        <div class=\"c-lg-4 c-md-4 c-sm-4 c-xs-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"master\">Master Course\r\n            </label>\r\n            <select class=\"form-ctrl\" [(ngModel)]=\"examAssignmentData.master_course_name\" (change)=\"getCourses($event.target.value)\">\r\n              <option value=\"\">Master Course</option>\r\n              <option *ngFor=\"let i of masterCourse\" [value]=\"i.master_course\">\r\n                {{i.master_course}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-lg-4 c-md-4 c-sm-4 c-xs-4\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"course\">Course\r\n            </label>\r\n            <select class=\"form-ctrl\" [(ngModel)]=\"examAssignmentData.course_id\">\r\n              <option value=\"-1\">Course</option>\r\n              <option *ngFor=\"let i of courses\" [value]=\"i.course_id\">\r\n                {{i.course_name}}\r\n              </option>>\r\n            </select>\r\n\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-lg-2 c-md-2 c-sm-2 c-xs-2 text-center\">\r\n          <button id=\"btnSave\" class=\"btn fullBlue\" style=\"margin-top: 1rem;\" type=\"submit\" (click)=\"getExamAssignmentData()\"> Go </button>\r\n\r\n        </div>\r\n      </div>\r\n      <div class=\"row extraMargin\" *ngIf=\"(!isCourseModule)\">\r\n          <div class=\"c-lg-3 c-md-3 c-sm-3 c-xs-3\">\r\n            <div class=\"field-wrapper\">\r\n              <label for=\"master\">Master Course\r\n              </label>\r\n              <select class=\"form-ctrl\" [(ngModel)]=\"examAssignmentData.standard_id\" (change)=\"clearData(1);getData($event.target.value)\">\r\n                <option value=\"-1\">Master Course</option>\r\n                <option *ngFor=\"let i of standardList\" [value]=\"i.standard_id\">\r\n                  {{i.standard_name}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"c-lg-3 c-md-3 c-sm-3 c-xs-3\">\r\n            <div class=\"field-wrapper\">\r\n              <label for=\"course\">Course\r\n              </label>\r\n              <select class=\"form-ctrl\" [(ngModel)]=\"examAssignmentData.subject_id\"  (change)=\"clearData(2);getData($event.target.value)\">\r\n                <option value=\"-1\">Course</option>\r\n                <option *ngFor=\"let i of subjectList\" [value]=\"i.subject_id\">\r\n                  {{i.subject_name}}\r\n                </option>>\r\n              </select>\r\n\r\n            </div>\r\n          </div>\r\n          <div class=\"c-lg-3 c-md-3 c-sm-3 c-xs-3\">\r\n              <div class=\"field-wrapper\">\r\n                <label for=\"course\">Batch\r\n                </label>\r\n                <select class=\"form-ctrl\" [(ngModel)]=\"examAssignmentData.batch_id\">\r\n                  <option value=\"-1\">Batch</option>\r\n                  <option *ngFor=\"let i of batchList\" [value]=\"i.batch_id\">\r\n                    {{i.batch_name}}\r\n                  </option>>\r\n                </select>\r\n\r\n              </div>\r\n            </div>\r\n          <div class=\"c-lg-2 c-md-2 c-sm-2 c-xs-2 text-center\">\r\n            <button id=\"btnSave\" class=\"btn fullBlue\" style=\"margin-top: 1rem;\" type=\"submit\" (click)=\"getExamAssignmentData()\"> Go </button>\r\n\r\n          </div>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"table-wrapper\">\r\n      <table>\r\n        <thead>\r\n          <tr>\r\n            <th>\r\n              <div class=\"field-checkbox-wrapper\">\r\n                <input type=\"checkbox\" class=\"form-checkbox\" [(ngModel)]=\"headerChecked\" (ngModelChange)=\"onHeaderCheckBox($event)\">\r\n                <label></label>\r\n              </div>\r\n            </th>\r\n            <th>Student ID</th>\r\n            <th>Name</th>\r\n            <th>Contact No</th>\r\n            <th>Joining Date</th>\r\n            <th>Type</th>\r\n          </tr>\r\n        </thead>\r\n        <tbody *ngIf=\"tableData.length > 0 && dataStatus === 2\">\r\n          <tr *ngFor=\"let data of (tableData | searchPipe:searchData)\">\r\n            <td style=\"text-align: left\">\r\n              <div class=\"field-checkbox-wrapper\">\r\n                <input [disabled]=\"data.user_type == '99'\" type=\"checkbox\" class=\"form-checkbox\" [(ngModel)]=\"data.assigned\" (ngModelChange)=\"checkIfHeaderChecked()\">\r\n                <label></label>\r\n              </div>\r\n            </td>\r\n            <td>\r\n              {{data.student_disp_id}}\r\n            </td>\r\n            <td>\r\n              {{data.student_name}}\r\n            </td>\r\n            <td>\r\n              {{data.student_phone}}\r\n            </td>\r\n            <td>\r\n              {{data.doj}}\r\n            </td>\r\n            <td>\r\n              <span *ngIf=\"data.user_type == '99'\">Guest User</span>\r\n              <span *ngIf=\"data.user_type == '1'\">Enrolled Student</span>\r\n            </td>\r\n          </tr>\r\n        </tbody>\r\n        <tbody *ngIf=\"tableData.length == 0 && dataStatus === 1\">\r\n          <tr *ngFor=\"let dummy of dummyArr\">\r\n            <td *ngFor=\"let c of columnMapsTr\">\r\n              <div class=\"skeleton\">\r\n              </div>\r\n            </td>\r\n          </tr>\r\n        </tbody>\r\n        <tbody *ngIf=\"tableData.length == 0 && dataStatus === 2\">\r\n          <tr>\r\n            <td colspan=\"6\">\r\n              <h3>No Student Record Found</h3>\r\n            </td>\r\n          </tr>\r\n        </tbody>\r\n      </table>\r\n    </div>\r\n\r\n  </div>\r\n\r\n  <div class=\"\" popup-footer>\r\n    <div class=\"clearfix\" style=\"margin-top :10px\">\r\n      <aside class=\"pull-right popup-btn\">\r\n        <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closePopup()\">\r\n        <input type=\"button\" value=\"Add Student\" class=\"fullBlue btn\" (click)=\"addStudentToCourse()\">\r\n      </aside>\r\n    </div>\r\n  </div>\r\n\r\n</proctur-popup>\r\n"

/***/ }),

/***/ "./src/app/components/online-exam-module/examdesk-course-assignment/examdesk-course-assignment.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  padding: 15px; }\n\n.head-section {\n  margin: 0 0 10px 0; }\n\n.head-section .normal-field {\n    padding: 7px 10px;\n    border: 1px solid #ccc;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    margin: 0;\n    float: left;\n    height: 35px;\n    font-size: 14px; }\n\n.skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 80%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n\n.skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n\n.search-filter-wrapper .normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  height: 35px;\n  font-size: 14px; }\n\n.student-assign-popup .popup-title {\n  margin-left: 0px; }\n\n.student-assign-popup .filter-section {\n  padding: 10px 0px;\n  margin: 5px 0;\n  background: #efefef; }\n\n.student-assign-popup .filter-section .radio-button {\n    margin-top: 10px;\n    display: -webkit-inline-box;\n    display: -ms-inline-flexbox;\n    display: inline-flex; }\n\n.student-assign-popup .filter-section .radio-button .field-radio-wrapper {\n      margin-right: 5px; }\n\n.student-assign-popup .filter-section .field-wrapper {\n    padding-top: 0; }\n\n.student-assign-popup .filter-section .btn {\n    margin-left: 0; }\n\n.student-assign-popup .table-wrapper {\n  margin-top: 15px;\n  max-height: 265px;\n  overflow-x: hidden;\n  overflow-y: auto; }\n\n.student-assign-popup .table-wrapper th {\n    padding: 10px; }\n\n.student-assign-popup .table-wrapper td {\n    padding: 5px 10px; }\n"

/***/ }),

/***/ "./src/app/components/online-exam-module/examdesk-course-assignment/examdesk-course-assignment.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ExamdeskCourseAssignmentComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_examdesk_service_examdeskcourseassignment_service__ = __webpack_require__("./src/app/services/examdesk-service/examdeskcourseassignment.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ExamdeskCourseAssignmentComponent = /** @class */ (function () {
    function ExamdeskCourseAssignmentComponent(apiService, toastCtrl) {
        this.apiService = apiService;
        this.toastCtrl = toastCtrl;
        this.coursesList = [];
        this.dummyArr = [0, 1, 2, 3, 4, 0, 1, 2, 3, 4];
        this.columnMaps = [0, 1, 2];
        this.columnMapsTr = [0, 1, 2, 3, 4, 5];
        this.searchValue = "";
        this.coursesListDataSource = [];
        this.standardList = [];
        this.studentDataSourceList = [];
        this.studentList = [];
        this.tableData = [];
        this.masterCourse = [];
        this.courses = [];
        this.subjectList = [];
        this.batchList = [];
        this.tempBatchList = [];
        this.tempData = "";
        this.radioOption = '0';
        this.filterOption = '0';
        this.standard_id = -1;
        this.dataStatus = 1;
        this.assignPopUp = false;
        this.headerChecked = false;
        this.isCourse = false;
        this.isRippleLoad = false;
        this.isCourseModule = false;
        this.examAssignmentData = {
            "institute_id": 0,
            "master_course_name": "",
            "course_id": -1,
            "subject_id": -1,
            "standard_id": -1,
            "batch_id": -1
        };
    }
    ExamdeskCourseAssignmentComponent.prototype.ngOnInit = function () {
        this.fetchCoursesList();
        this.getAllStandardList();
        this.getMasterCourse();
        this.getData('first');
        if (sessionStorage.getItem('course_structure_flag') == '1') {
            this.isCourseModule = true;
        }
        else {
            this.isCourseModule = false;
        }
    };
    ExamdeskCourseAssignmentComponent.prototype.clearData = function (type) {
        if (type == 1) {
            this.examAssignmentData.subject_id = -1;
            this.batchList = this.tempBatchList;
        }
        else {
            this.examAssignmentData.batch_id = -1;
        }
    };
    ExamdeskCourseAssignmentComponent.prototype.fetchCoursesList = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.dataStatus = 1;
        this.apiService.getCoursesList().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.dataStatus = 2;
            _this.coursesList = res;
            _this.coursesListDataSource = res;
        }, function (err) {
            _this.dataStatus = 2;
            _this.isRippleLoad = false;
            _this.messageNotifier('error', '', err.error.message);
        });
    };
    ExamdeskCourseAssignmentComponent.prototype.getAllStandardList = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getStandard().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.standardList = res;
        }, function (err) {
            _this.isRippleLoad = false;
            _this.messageNotifier('error', '', err.error.message);
        });
    };
    ExamdeskCourseAssignmentComponent.prototype.searchInList = function () {
        var _this = this;
        if (this.searchValue != "" && this.searchValue != null) {
            var searchData = this.coursesListDataSource.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchValue.toLowerCase()); });
            });
            this.coursesList = searchData;
        }
        else {
            this.coursesList = this.coursesListDataSource;
        }
    };
    //Pop up Function
    ExamdeskCourseAssignmentComponent.prototype.assignStudent = function (data) {
        this.tempData = data;
        this.assignPopUp = true;
        this.getAllStudentList();
    };
    ExamdeskCourseAssignmentComponent.prototype.getExamAssignmentData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getStudentList2(this.examAssignmentData).subscribe(function (res) {
            _this.dataStatus = 2;
            _this.isRippleLoad = false;
            _this.studentDataSourceList = res;
            _this.studentList = _this.keepCloning(res);
            _this.onRadioButtonChange();
        }, function (err) {
            _this.dataStatus = 2;
            _this.isRippleLoad = false;
            _this.messageNotifier('error', '', err.error.message);
        });
    };
    ExamdeskCourseAssignmentComponent.prototype.getAllStudentList = function () {
        var _this = this;
        this.studentList = [];
        this.studentDataSourceList = [];
        this.isRippleLoad = true;
        var obj = {
            standard_id: this.standard_id,
            course_type_id: this.tempData.course_type_id
        };
        this.dataStatus = 1;
        this.apiService.getStudentList(obj).subscribe(function (res) {
            _this.dataStatus = 2;
            _this.isRippleLoad = false;
            _this.studentDataSourceList = res;
            _this.studentList = _this.keepCloning(res);
            _this.onRadioButtonChange();
        }, function (err) {
            _this.dataStatus = 2;
            _this.isRippleLoad = false;
            _this.messageNotifier('error', '', err.error.message);
        });
    };
    ExamdeskCourseAssignmentComponent.prototype.onfilterOptionChange = function () {
        this.isCourse = false;
        switch (this.filterOption) {
            case '0': {
                this.isCourse = false;
                this.tableData = [];
                this.studentList = [];
                this.examAssignmentData = {
                    "institute_id": 0,
                    "master_course_name": "",
                    "course_id": -1,
                    "subject_id": -1,
                    "standard_id": this.standard_id,
                    "batch_id": -1
                };
                this.getExamAssignmentData();
                break;
            }
            case '1': {
                this.isCourse = true;
                this.tableData = [];
                this.studentList = [];
                this.examAssignmentData = {
                    "institute_id": 0,
                    "master_course_name": "",
                    "course_id": -1,
                    "subject_id": -1,
                    "standard_id": -1,
                    "batch_id": -1
                };
                break;
            }
        }
        this.onRadioButtonChange();
    };
    ExamdeskCourseAssignmentComponent.prototype.onRadioButtonChange = function () {
        if (this.studentList.length > 0) {
            if (this.radioOption == '0') {
                this.tableData = this.studentList;
                this.checkIfHeaderChecked();
            }
            else if (this.radioOption == "1") {
                this.headerChecked = false;
                this.tableData = this.studentList.filter(function (el) { return el.assigned == true; });
                if (this.tableData.length > 0) {
                    this.headerChecked = true;
                }
            }
            else {
                this.headerChecked = false;
                this.tableData = this.studentList.filter(function (el) { return el.assigned == false; });
            }
        }
        else {
            this.tableData = [];
        }
    };
    ExamdeskCourseAssignmentComponent.prototype.onHeaderCheckBox = function (event) {
        if (event) {
            this.headerChecked = true;
            this.tableData.forEach(function (element) {
                element.assigned = true;
            });
        }
        else {
            this.headerChecked = true;
            this.tableData.forEach(function (element) {
                element.assigned = false;
            });
        }
    };
    ExamdeskCourseAssignmentComponent.prototype.checkIfHeaderChecked = function () {
        for (var i = 0; i < this.tableData.length; i++) {
            if (this.tableData[i].assigned == false) {
                this.headerChecked = false;
                break;
            }
            else {
                this.headerChecked = true;
            }
        }
    };
    ExamdeskCourseAssignmentComponent.prototype.closePopup = function () {
        this.assignPopUp = false;
        this.isCourse = false;
        this.radioOption = '0';
        this.studentDataSourceList = [];
        this.studentList = [];
        this.standard_id = -1;
        this.filterOption = '0';
        this.examAssignmentData = {
            "institute_id": 0,
            "master_course_name": "",
            "course_id": -1,
            "subject_id": -1,
            "standard_id": -1,
            "batch_id": -1
        };
    };
    ExamdeskCourseAssignmentComponent.prototype.addStudentToCourse = function () {
        var _this = this;
        var data = this.getSelectedStudent();
        if (data.length == 0) {
            this.messageNotifier('error', '', 'Please select student to assign in course');
            return;
        }
        var obj = {
            studentArray: data,
        };
        this.isRippleLoad = true;
        this.apiService.assignStudentToCourse(obj, this.tempData.course_type_id).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.messageNotifier('success', 'Student assigned successfully', '');
            _this.fetchCoursesList();
            _this.closePopup();
        }, function (err) {
            _this.isRippleLoad = false;
            _this.messageNotifier('error', '', err.error.message);
        });
    };
    ExamdeskCourseAssignmentComponent.prototype.getMasterCourse = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getAllMasterCourse().subscribe(function (data) {
            _this.examAssignmentData.master_course_name = "";
            _this.examAssignmentData.course_id = -1;
            _this.masterCourse = data;
            _this.isRippleLoad = false;
        }, function (error) {
            _this.isRippleLoad = false;
            return error;
        });
    };
    ExamdeskCourseAssignmentComponent.prototype.getCourses = function (name) {
        var _this = this;
        this.isRippleLoad = true;
        this.apiService.getAllCourse(name).subscribe(function (data) {
            _this.courses = data.coursesList;
            _this.isRippleLoad = false;
        }, function (error) {
            _this.isRippleLoad = false;
            return error;
        });
    };
    ExamdeskCourseAssignmentComponent.prototype.getData = function (name) {
        var _this = this;
        this.dataStatus = 2;
        this.apiService.batchData(this.examAssignmentData).subscribe(function (res) {
            console.log(res);
            if (name == 'first') {
                _this.tempBatchList = res.batchLi;
                _this.batchList = _this.tempBatchList;
                return;
            }
            if (_this.examAssignmentData.subject_id == -1) {
                _this.examAssignmentData.batch_id = -1;
                _this.subjectList = res.subjectLi;
                return;
            }
            if (_this.examAssignmentData.batch_id == -1) {
                _this.batchList = res.batchLi;
                if (_this.batchList.length == 0) {
                    _this.batchList = _this.tempBatchList;
                }
            }
        }, function (err) {
            _this.messageNotifier('error', '', err.error.message);
        });
    };
    ExamdeskCourseAssignmentComponent.prototype.getSelectedStudent = function () {
        var temp = {};
        for (var i = 0; i < this.studentDataSourceList.length; i++) {
            for (var j = 0; j < this.studentList.length; j++) {
                if (this.studentDataSourceList[i].user_type == 1 && this.studentList[j].user_type == 1) {
                    if (this.studentDataSourceList[i].student_id == this.studentList[j].student_id) {
                        if (this.studentDataSourceList[i].assigned != this.studentList[j].assigned) {
                            temp[this.studentList[i].student_id] = this.studentList[j].assigned;
                        }
                    }
                }
            }
        }
        return temp;
    };
    // pagination functions 
    // fetchTableDataByPage(index) {
    //   this.PageIndex = index;
    //   let startindex = this.studentdisplaysize * (index - 1);
    //   this.slotTableList = this.getDataFromDataSource(startindex);
    // }
    // fetchNext() {
    //   this.PageIndex++;
    //   this.fetchTableDataByPage(this.PageIndex);
    // }
    // fetchPrevious() {
    //   if (this.PageIndex != 1) {
    //     this.PageIndex--;
    //     this.fetchTableDataByPage(this.PageIndex);
    //   }
    // }
    // getDataFromDataSource(startindex) {
    //   let t = this.slotsDataSource.slice(startindex, startindex + this.studentdisplaysize);
    //   return t;
    // }
    // helper Function
    ExamdeskCourseAssignmentComponent.prototype.messageNotifier = function (type, title, msg) {
        var data = {
            type: type,
            title: title,
            body: msg
        };
        this.toastCtrl.popToast(data);
    };
    ExamdeskCourseAssignmentComponent.prototype.keepCloning = function (objectpassed) {
        if (objectpassed === null || typeof objectpassed !== 'object') {
            return objectpassed;
        }
        var temporaryStorage = objectpassed.constructor();
        for (var key in objectpassed) {
            temporaryStorage[key] = this.keepCloning(objectpassed[key]);
        }
        return temporaryStorage;
    };
    ExamdeskCourseAssignmentComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-examdesk-course-assignment',
            template: __webpack_require__("./src/app/components/online-exam-module/examdesk-course-assignment/examdesk-course-assignment.component.html"),
            styles: [__webpack_require__("./src/app/components/online-exam-module/examdesk-course-assignment/examdesk-course-assignment.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_examdesk_service_examdeskcourseassignment_service__["a" /* ExamDeskCourseAssignmentService */],
            __WEBPACK_IMPORTED_MODULE_1__app_component__["a" /* AppComponent */]])
    ], ExamdeskCourseAssignmentComponent);
    return ExamdeskCourseAssignmentComponent;
}());



/***/ }),

/***/ "./src/app/components/online-exam-module/index.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__online_exam_module_component__ = __webpack_require__("./src/app/components/online-exam-module/online-exam-module.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "c", function() { return __WEBPACK_IMPORTED_MODULE_0__online_exam_module_component__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__online_exam_home_online_exam_home_component__ = __webpack_require__("./src/app/components/online-exam-module/online-exam-home/online-exam-home.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "b", function() { return __WEBPACK_IMPORTED_MODULE_1__online_exam_home_online_exam_home_component__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__examdesk_course_assignment_examdesk_course_assignment_component__ = __webpack_require__("./src/app/components/online-exam-module/examdesk-course-assignment/examdesk-course-assignment.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_2__examdesk_course_assignment_examdesk_course_assignment_component__["a"]; });





/***/ }),

/***/ "./src/app/components/online-exam-module/online-exam-home/online-exam-home.component.html":
/***/ (function(module, exports) {

module.exports = "\r\n<section class=\"middle-section\">\r\n  <!-- course module -->\r\n  <section class=\"header-section\"> \r\n      <div>\r\n          <div class=\"header-title\">\r\n              <span >Online Exam</span>\r\n            </div>\r\n      </div>  \r\n    </section>\r\n  <div class=\"course-menu-section-container\" >\r\n    <div class=\"course-menu-item\" *ngIf=\"jsonFlag.showExamDesk\" routerLink=\"/view/online-exam/examcourse\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/online-exam/exam_desk.svg\" alt=\"examDesk course assignment\">\r\n        <span>ExamDesk Course Assignment</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span> Data setup your academic year, faculties, classrooms, etc</span>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"course-menu-item\"*ngIf=\"jsonFlag.isShowEcourseMapping\" routerLink=\"/view/online-exam/ecoursemapping\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/activity/ecourse.svg\" alt=\"\">\r\n        <span>E-course Mapping</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span *ngIf=\"!jsonFlag.isProfessional\">Create E-courses and assign multiple standards to the E-courses.</span>\r\n        <span *ngIf=\"jsonFlag.isProfessional\">Create E-courses and assign multiple batches to the E-courses</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>"

/***/ }),

/***/ "./src/app/components/online-exam-module/online-exam-home/online-exam-home.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  padding: 1%; }\n\n.header-section .header-title {\n  text-align: left;\n  font-size: 14px;\n  font-weight: 600;\n  color: #0084f6; }\n\n.course-menu-section-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  padding-top: 10px;\n  margin-top: 10px;\n  border-top: 1px solid rgba(10, 10, 10, 0.5);\n  width: 100%; }\n\n.course-menu-section-container .course-menu-item {\n    padding: 15px 10px;\n    width: 31%;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 1%;\n    -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24);\n    box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24); }\n\n.course-menu-section-container .course-menu-item .menu-title {\n      width: 100%;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start;\n      font-size: 14px;\n      font-weight: 600;\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row; }\n\n.course-menu-section-container .course-menu-item .menu-title img {\n        width: 25px;\n        height: 25px; }\n\n.course-menu-section-container .course-menu-item .menu-title span {\n        margin-left: 10px;\n        margin-top: 5px; }\n\n.course-menu-section-container .course-menu-item .menu-description {\n      padding: 10px;\n      font-size: 12px; }\n"

/***/ }),

/***/ "./src/app/components/online-exam-module/online-exam-home/online-exam-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return OnlineExamHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var OnlineExamHomeComponent = /** @class */ (function () {
    function OnlineExamHomeComponent(router, auth) {
        this.router = router;
        this.auth = auth;
        this.jsonFlag = {
            isProfessional: false,
            isAdmin: false,
            showExamDesk: false,
            institute_id: '',
            isShowEcourseMapping: false
        };
        if (sessionStorage.getItem('userid') == null) {
            this.router.navigateByUrl('/authPage');
        }
    }
    OnlineExamHomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == 'LANG') {
                _this.jsonFlag.isProfessional = true;
            }
            else {
                _this.jsonFlag.isProfessional = false;
            }
        });
        this.jsonFlag.institute_id = sessionStorage.getItem('institute_id');
        this.checkUserAccess();
        if (this.jsonFlag.isAdmin) {
            var type = Number(sessionStorage.getItem('institute_setup_type'));
            this.jsonFlag.showExamDesk = this.checkInstSetupType(type, 4);
        }
    };
    OnlineExamHomeComponent.prototype.checkUserAccess = function () {
        var permissionArray = sessionStorage.getItem('permissions');
        var permittedRoles = sessionStorage.getItem('permitted_roles');
        var userType = sessionStorage.getItem('userType');
        if (userType == '3') {
            this.jsonFlag.isAdmin = false;
        }
        else if (userType == '0') {
            if (permissionArray == "" || permissionArray == null) {
                this.jsonFlag.isAdmin = true;
                this.jsonFlag.isShowEcourseMapping = true;
            }
        }
        if (sessionStorage.getItem('enable_elearn_course_mapping_feature') == '1') {
            this.jsonFlag.isShowEcourseMapping = true;
        }
    };
    OnlineExamHomeComponent.prototype.checkInstSetupType = function (value, role) {
        if (value != 0) {
            var start = 2;
            var count = 1;
            while (start != value) {
                count++;
                start = start + 2;
            }
            var arr = [0, 0, 0, 0, 0, 0, 0, 0];
            var s = count.toString(2);
            var k = 0;
            for (var i = s.length - 1; i >= 0; i--) {
                arr[k] = parseInt(s.charAt(i));
                k++;
            }
            switch (role) {
                case 2:
                    if (arr[0] == 1)
                        return true;
                    break;
                case 4:
                    if (arr[1] == 1)
                        return true;
                    break;
                case 8:
                    if (arr[2] == 1)
                        return true;
                    break;
                case 16:
                    if (arr[3] == 1)
                        return true;
                    break;
                case 32:
                    if (arr[4] == 1)
                        return true;
                    break;
                case 64:
                    if (arr[5] == 1)
                        return true;
                    break;
                case 128:
                    if (arr[6] == 1)
                        return true;
                    break;
                case 256:
                    if (arr[7] == 1)
                        return true;
                    break;
                default: return false;
            }
            return false;
        }
        else {
            return false;
        }
    };
    OnlineExamHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-online-exam-home',
            template: __webpack_require__("./src/app/components/online-exam-module/online-exam-home/online-exam-home.component.html"),
            styles: [__webpack_require__("./src/app/components/online-exam-module/online-exam-home/online-exam-home.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], OnlineExamHomeComponent);
    return OnlineExamHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/online-exam-module/online-exam-module-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return OnlineExamModuleRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2____ = __webpack_require__("./src/app/components/online-exam-module/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__eStore_module__ = __webpack_require__("./src/app/components/eStore-module/index.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2____["c" /* OnlineExamModuleComponent */],
        pathMatch: 'prefix',
        children: [
            {
                path: '',
                component: __WEBPACK_IMPORTED_MODULE_2____["b" /* OnlineExamHomeComponent */]
            },
            {
                path: 'ecoursemapping',
                component: __WEBPACK_IMPORTED_MODULE_3__eStore_module__["c" /* EcourseMappingComponent */],
                pathMatch: 'prefix'
            }
        ]
    },
    {
        path: 'examcourse',
        component: __WEBPACK_IMPORTED_MODULE_2____["a" /* ExamdeskCourseAssignmentComponent */],
        pathMatch: 'prefix'
    }
];
var OnlineExamModuleRoutingModule = /** @class */ (function () {
    function OnlineExamModuleRoutingModule() {
    }
    OnlineExamModuleRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]]
        })
    ], OnlineExamModuleRoutingModule);
    return OnlineExamModuleRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/online-exam-module/online-exam-module.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/components/online-exam-module/online-exam-module.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/online-exam-module/online-exam-module.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return OnlineExamModuleComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var OnlineExamModuleComponent = /** @class */ (function () {
    function OnlineExamModuleComponent() {
    }
    OnlineExamModuleComponent.prototype.ngOnInit = function () {
    };
    OnlineExamModuleComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-online-exam-module',
            template: __webpack_require__("./src/app/components/online-exam-module/online-exam-module.component.html"),
            styles: [__webpack_require__("./src/app/components/online-exam-module/online-exam-module.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], OnlineExamModuleComponent);
    return OnlineExamModuleComponent;
}());



/***/ }),

/***/ "./src/app/components/online-exam-module/online-exam.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OnlineExamModule", function() { return OnlineExamModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__online_exam_module_routing_module__ = __webpack_require__("./src/app/components/online-exam-module/online-exam-module-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3____ = __webpack_require__("./src/app/components/online-exam-module/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_examdesk_service_examdeskcourseassignment_service__ = __webpack_require__("./src/app/services/examdesk-service/examdeskcourseassignment.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__eStore_module_estore_module__ = __webpack_require__("./src/app/components/eStore-module/estore.module.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var OnlineExamModule = /** @class */ (function () {
    function OnlineExamModule() {
    }
    OnlineExamModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_4__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_6__eStore_module_estore_module__["EstoreModule"],
                __WEBPACK_IMPORTED_MODULE_2__online_exam_module_routing_module__["a" /* OnlineExamModuleRoutingModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_3____["c" /* OnlineExamModuleComponent */],
                __WEBPACK_IMPORTED_MODULE_3____["b" /* OnlineExamHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_3____["a" /* ExamdeskCourseAssignmentComponent */]
            ],
            providers: [__WEBPACK_IMPORTED_MODULE_5__services_examdesk_service_examdeskcourseassignment_service__["a" /* ExamDeskCourseAssignmentService */]]
        })
    ], OnlineExamModule);
    return OnlineExamModule;
}());



/***/ }),

/***/ "./src/app/services/examdesk-service/examdeskcourseassignment.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ExamDeskCourseAssignmentService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ExamDeskCourseAssignmentService = /** @class */ (function () {
    function ExamDeskCourseAssignmentService(auth, http) {
        var _this = this;
        this.auth = auth;
        this.http = http;
        this.baseUrl = '';
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_2__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    ExamDeskCourseAssignmentService.prototype.getCoursesList = function () {
        var url = this.baseUrl + "/api/v1/institute/courseMapping/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamDeskCourseAssignmentService.prototype.getStandard = function () {
        var url = this.baseUrl + "/api/v1/standards/all/" + this.institute_id + "/?active=Y";
        return this.http.get(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamDeskCourseAssignmentService.prototype.getStudentList = function (obj) {
        obj.institute_id = this.institute_id;
        var url = this.baseUrl + "/api/v1/institute/studentCourseMapping/getStudAndUsers";
        return this.http.post(url, obj, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamDeskCourseAssignmentService.prototype.batchData = function (obj) {
        var url = this.baseUrl + "/api/v1/batches/fetchCombinedBatchData/" + this.institute_id + "?standard_id=" + obj.standard_id + "&subject_id=" + obj.subject_id;
        return this.http.get(url, { headers: this.headers }).map(function (res) {
            return res;
        }, function (err) {
            return err;
        });
    };
    ExamDeskCourseAssignmentService.prototype.getStudentList2 = function (obj) {
        obj.institute_id = this.institute_id;
        var url = this.baseUrl + "/api/v1/institute/studentCourseMapping/v2/fetchStudentsFilterWise";
        return this.http.post(url, obj, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamDeskCourseAssignmentService.prototype.assignStudentToCourse = function (obj, id) {
        obj.institute_id = this.institute_id;
        var url = this.baseUrl + "/api/v1/institute/studentCourseMapping/" + id + "/assignStudents";
        return this.http.post(url, obj, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ExamDeskCourseAssignmentService.prototype.getAllMasterCourse = function () {
        var url = this.baseUrl + "/api/v1/courseMaster/fetch/" + this.institute_id + "/all";
        return this.http.get(url, { headers: this.headers }).map(function (res) {
            return res;
        }, function (err) {
            return err;
        });
    };
    ExamDeskCourseAssignmentService.prototype.getAllCourse = function (name) {
        var url = this.baseUrl + "/api/v1/courseMaster/fetch/" + this.institute_id + "/" + name;
        return this.http.get(url, { headers: this.headers }).map(function (res) {
            return res;
        }, function (err) {
            return err;
        });
    };
    ExamDeskCourseAssignmentService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_2__angular_common_http__["a" /* HttpClient */]])
    ], ExamDeskCourseAssignmentService);
    return ExamDeskCourseAssignmentService;
}());



/***/ })

});
//# sourceMappingURL=online-exam.module.chunk.js.map