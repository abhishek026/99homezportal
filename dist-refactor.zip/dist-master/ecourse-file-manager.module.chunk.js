webpackJsonp(["ecourse-file-manager.module"],{

/***/ "./src/app/components/eStore-module/ecourse-file-manager/core/upload-file/upload-file.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper black-bg\" [loaderClass]=\"'blueRipple'\"\r\n  *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<!-- <div class=\"ga-modal-wrapper\" *ngIf=\"showModal\">\r\n  <div class=\"ga-modal-container\">\r\n    <div class=\"ga-modal\">\r\n      <div class=\"ga-modal-head\">\r\n        <span>Upload Files {{varJson.topic_id}}</span>\r\n        <span class=\"close\" (click)=\"clearuploadObject()\"></span>\r\n      </div>\r\n      <div class=\"ga-modal-body\">\r\n        <div class=\"row upload-box\">\r\n          <div class=\"col-md-4 file-form\">\r\n            <div class=\"form-group\">\r\n              <select class=\"form-ctrl ga-form-input\" [disabled]=\"material_dataShow\" [(ngModel)]=\"varJson.course_types\"\r\n                (change)=\"getSubjectsList($event.target.value)\">\r\n                <option value=\"\"> Select course</option>\r\n                <option *ngFor=\"let exam of categiesList; \" [value]=\"exam.course_type_id\">{{exam.course_type}}</option>\r\n              </select>\r\n            </div>\r\n            <div class=\"form-group\">\r\n              <select [(ngModel)]=\"varJson.subject_id\" [disabled]=\"material_dataShow\" class=\"form-ctrl ga-form-input\"\r\n                (change)=\"getTopicsList($event.target.value)\">\r\n                <option value=\"0\">Select subject</option>\r\n                <option *ngFor=\"let subject of subjectList;\" [value]=\"subject.subject_id\">{{subject.subject_name}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n            <div class=\"form-group\">\r\n              <select class=\"form-ctrl ga-form-input\" [(ngModel)]=\"varJson.topic_id\"\r\n                (change)=\"getSubtopicList($event.target.value)\">\r\n                <option value=\"0\">Select topic</option>\r\n                <option *ngFor=\"let topic of topicList; \" [value]=\"topic.institute_topic_id\">{{topic.name}}</option>\r\n              </select>\r\n            </div>\r\n            <div class=\"form-group\">\r\n              <select class=\"form-ctrl ga-form-input\" [(ngModel)]=\"varJson.sub_topic_id\">\r\n                <option value=\"0\">Select subtopic</option>\r\n                <option *ngFor=\"let subtopic of subtopicList; \" [value]=\"subtopic.institute_topic_id\">{{subtopic.name}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n          </div>\r\n          <div class=\"file-drop-wrapper\"\r\n            [ngClass]=\"{'col-md-10': varJson.category_id==330,'col-md-8': varJson.category_id!=330}\">\r\n            <div class=\"drop-box\">\r\n              <select [(ngModel)]=\"varJson.category_id\" (change)=\"setCategoryType($event.target.value)\"\r\n                class=\"form-ctrl ga-form-input\" style=\"margin-bottom: 0.8em\">\r\n                <option value=\"0\">Select file type</option>\r\n                <option *ngFor=\"let category of categiesTypeList; \" [value]=\"category.category_id\">\r\n                  {{category.category_name}}</option>\r\n              </select>\r\n              <div class=\"row\" *ngIf=\"varJson.category_id==235\">\r\n                <div class=\"col-md-7\">\r\n                  <div class=\"field-wrapper\">\r\n                    <label>Privacy Settings<div class=\"questionInfo inline-relative\">\r\n                        <span class=\"qInfoIcon i-class\">i</span>\r\n                        <div class=\"tooltip-box-field\">\r\n                          Set the video visibility mode to private or public.\r\n                          In private mode, video will be visible to the enrolled students.\r\n                          In public mode, video will be visible to guest users & enrolled students\r\n                        </div>\r\n                      </div></label>\r\n                    <div class=\"row\" style=\"padding: 15px 30px;\">\r\n                      <label class=\"toggle\">\r\n                        <span class=\"toggle-label\" id=\"unassigned\"\r\n                          [ngClass]=\"(varJson.is_private)?'inactive_toggle_button':'active_toggle_button'\">Private</span>\r\n                        <input class=\"toggle-checkbox\" type=\"checkbox\" [(ngModel)]=\"varJson.is_private\">\r\n                        <div class=\"toggle-switch\"></div>\r\n                        <span class=\"toggle-label\" id=\"assigned\"\r\n                          [ngClass]=\"(varJson.is_private)?'active_toggle_button':'inactive_toggle_button'\">Public\r\n                        </span>\r\n                      </label>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"col-md-5\">\r\n                  <div class=\"field-wrapper\" style=\"margin-left: -50px;\">\r\n                    <div class=\"dropdown-div\">\r\n                      <label>Enable Watermark <div class=\"questionInfo inline-relative\">\r\n                          <span class=\"qInfoIcon i-class\">i</span>\r\n                          <div class=\"tooltip-box-field\">\r\n                            Enable or disable the watermark visibility in the video with this setting\r\n                          </div>\r\n                        </div>&nbsp;&nbsp;\r\n                        <div class=\"row\" style=\"padding: 15px 30px;\">\r\n                          <label class=\"toggle\">\r\n                            <span class=\"toggle-label\" id=\"unassigned\"\r\n                              [ngClass]=\"(varJson.enable_watermark)?'inactive_toggle_button':'active_toggle_button'\">Disable\r\n                            </span>\r\n                            <input class=\"toggle-checkbox\" type=\"checkbox\" [(ngModel)]=\"varJson.enable_watermark\">\r\n                            <div class=\"toggle-switch\"></div>\r\n                            <span class=\"toggle-label\" id=\"assigned\"\r\n                              [ngClass]=\"(varJson.enable_watermark)?'active_toggle_button':'inactive_toggle_button'\">Enable\r\n                            </span>\r\n                          </label>\r\n                        </div>\r\n                      </label>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <input type=\"text\" style=\"margin-bottom: 0.8em;\" *ngIf=\"varJson.category_id==235\"\r\n                class=\"form-ctrl video-input\" placeholder=\"Video Title\" [(ngModel)]=\"varJson.title\">\r\n            \r\n                <input type=\"text\" style=\"margin-bottom: 0.8em;\" class=\"form-ctrl video-input\"\r\n                *ngIf=\"varJson.category_id==230\" placeholder=\"Video URL\" [(ngModel)]=\"varJson.video_url\">\r\n         \r\n                <div class=\"btn-div\" *ngIf=\"varJson.category_id==230\">\r\n                <input class=\"btn fullBlue\" type=\"button\" value=\"Upload\" [disabled]=\"varJson.video_url==''\"\r\n                  (click)=\"uploadYoutubeURL($event)\">\r\n                <input class=\"btn\" (click)=\" clearuploadObject()\" type=\"button\" value=\"Cancel\">\r\n              </div>\r\n              <div style=\"height: 22rem; overflow:hidden;   overflow-y: scroll;\"\r\n                class=\"table table-responsive table-made\" *ngIf=\"varJson.category_id==330\">\r\n                <table>\r\n                  <thead>\r\n                    <tr style=\"background:#005cbf;\">\r\n                      <td>#</td>\r\n                      <td>Title</td>\r\n                      <td>Size</td>\r\n                      <td>Date</td>\r\n                      <td>Source</td>\r\n                      <td>Links</td>\r\n                    </tr>\r\n                  </thead>\r\n                  <tbody>\r\n                    <tr *ngFor=\"let video of existVideos; let i= index\" >\r\n                      <td>\r\n                        <div class=\"field-radio-wrapper\">\r\n                          <input type=\"radio\" name=\"bothRadio\" id=\"bothRadio\" class=\"form-radio\"\r\n                            [(ngModel)]=\"jsonData.selectedVideo\" [value]=\"video.video_id\"\r\n                            (ngModelChange)=\"onRadioButtonChange($event,video)\">\r\n                          <label for=\"bothRadio\"></label>\r\n                        </div>\r\n                      </td>\r\n                      <td>\r\n                        <span class=\"txt-title text-left\"\r\n                          title=\"{{video.video_title}}\">{{video.video_title.length>20?(video.video_title | slice:0:20):video.video_title}}</span>\r\n                      </td>\r\n                      <td>{{video.video_size}} MB {{i}}</td>\r\n                      <td>{{video.video_upload_date | date: 'dd-MMM-yyyy'}}</td>\r\n                      <td>\r\n                        <span class=\"txt-title\"\r\n                          title=\"{{getSourceName(video)}}\">{{(getSourceName(video)?.length>30)?(getSourceName(video) | slice:0:30) + '...':(getSourceName(video))}}</span>\r\n                      </td>\r\n                      <td>\r\n                        <div class=\"questionInfo inline-relative\" *ngIf=\"video.link_video_list.length\">\r\n                          <span class=\"qInfoIcon i-class\"><b>{{video.link_video_list.length}}</b></span>\r\n                          <div class=\"tooltip-box-field text-left\" >\r\n                            <span *ngFor=\"let data of video.link_video_list;let i=index\"  style=\"padding: 5px;\">\r\n                              {{videoGetDetails(data,i+1)}} <br>\r\n                            </span>\r\n                          </div>\r\n                        </div>\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                </table>\r\n              </div>\r\n              <div class=\"btn-div\" *ngIf=\"varJson.category_id==330\"\r\n                style=\" position: absolute; right: 1rem; bottom: 0;\">\r\n                <input class=\"btn fullBlue\" type=\"button\" value=\"Link Video\" [disabled]=\"varJson.title==''\"\r\n                  (click)=\"linkAlreadyUploadedVideo($event)\">\r\n                <input class=\"btn\" (click)=\" clearuploadObject()\" type=\"button\" value=\"Cancel\">\r\n              </div>\r\n              <p-fileUpload customUpload=\"true\" type=\"submit\" (uploadHandler)=\"uploadHandler2($event,values)\"\r\n                [showCancelButton]=\"false\"\r\n                *ngIf=\"varJson.category_id==235 && varJson.category_id!=0 && varJson.category_id!=330\">\r\n              </p-fileUpload>\r\n              \r\n              <p-fileUpload customUpload=\"true\" multiple=\"multiple\" type=\"submit\"\r\n                (uploadHandler)=\"uploadHandler($event,values)\" [showCancelButton]=\"false\"\r\n                *ngIf=\"varJson.category_id!=230 && varJson.category_id!=235 && varJson.category_id!=330\">\r\n              </p-fileUpload>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div> -->\r\n\r\n<div class=\"ga-modal-wrapper\" *ngIf=\"showParentTopicModel\">\r\n  <div class=\"ga-modal-container\">\r\n    <div class=\"ga-modal\">\r\n      <div class=\"ga-modal-head\">\r\n        <span>Upload Files</span>\r\n        <span class=\"close\" (click)=\"clearuploadObject()\"></span>\r\n      </div>\r\n      <div class=\"ga-modal-body\">\r\n        <div class=\"row upload-box\">\r\n          <div class=\"col-md-12 file-form\">\r\n            <div class=\"form-group\">\r\n              <label class=\"title\">Course</label>\r\n              <select class=\"form-ctrl ga-form-input\" [disabled]=\"material_dataShow\" [(ngModel)]=\"varJson.course_types\"\r\n                (change)=\"getSubjectsList($event.target.value)\">\r\n                <option value=\"\"> Select course</option>\r\n                <option *ngFor=\"let exam of categiesList; \" title=\"{{exam.course_type}}\" [value]=\"exam.course_type_id\">\r\n                 {{(exam.course_type?.length>30)?(exam.course_type | slice:0:30) + '...':(exam.course_type)}}     \r\n                </option>\r\n              </select>\r\n            </div>\r\n          </div>\r\n          <div class=\"col-md-12 file-form\">\r\n            <div class=\"form-group\">\r\n              <label class=\"title\">Subject</label>\r\n              <select [(ngModel)]=\"varJson.subject_id\" [disabled]=\"material_dataShow\" class=\"form-ctrl ga-form-input\"\r\n                (change)=\"getTopicsList($event.target.value)\">\r\n                <option value=\"0\">Select subject</option>\r\n                <option *ngFor=\"let subject of subjectList;\" title=\"{{subject.subject_name}}\" [value]=\"subject.subject_id\">\r\n                    {{(subject.subject_name?.length>30)?(subject.subject_name| slice:0:30) + '...':(subject.subject_name)}}\r\n  \r\n                </option>\r\n              </select>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row upload-box\" *ngIf=\"showModal\">\r\n            <div class=\"col-md-12 file-form\">\r\n              <div class=\"form-group\">\r\n                <label class=\"title\">Topic</label>\r\n                <select class=\"form-ctrl ga-form-input\" [(ngModel)]=\"varJson.topic_id\"\r\n                (change)=\"getSubtopicList($event.target.value)\">\r\n                <option value=\"0\">Select topic</option>\r\n                <option *ngFor=\"let topic of topicList; \"  title=\"{{topic.name}}\" [value]=\"topic.institute_topic_id\">\r\n                   {{(topic.name?.length>30)?(topic.name| slice:0:30) + '...':(topic.name)}}\r\n                </option>\r\n              </select>\r\n              </div>\r\n            </div>\r\n            <div class=\"col-md-12 file-form\">\r\n              <div class=\"form-group\">\r\n                <label class=\"title\">Subtopic</label>\r\n                <select class=\"form-ctrl ga-form-input\" [(ngModel)]=\"varJson.sub_topic_id\">\r\n                    <option value=\"0\">Select subtopic</option>\r\n                    <option *ngFor=\"let subtopic of subtopicList; \"  title=\"{{subtopic.name}}\" [value]=\"subtopic.institute_topic_id\">\r\n                        {{(subtopic.name?.length>30)?(subtopic.name| slice:0:30) + '...':(subtopic.name)}}\r\n                                </option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        <div class=\"row upload-box\" *ngIf=\"!showModal\">\r\n          <div class=\"col-md-12 file-form\">\r\n            <div class=\"form-group\">\r\n              <label class=\"title\">Topic &nbsp;:&nbsp;</label>\r\n              <label\r\n                title=\"{{jsonData.parentTopic}}\">{{(jsonData.parentTopic?.length>30)?(jsonData.parentTopic | slice:0:30) + '...':(jsonData.parentTopic)}}\r\n              </label>\r\n\r\n            </div>\r\n          </div>\r\n          <div class=\"col-md-12 file-form\">\r\n            <div class=\"form-group\">\r\n              <label class=\"title\">Subtopic &nbsp;:&nbsp;</label>\r\n              <label\r\n                title=\"{{jsonData.parentTopic}}\">{{(jsonData.mainTopic?.length>30)?(jsonData.mainTopic | slice:0:30) + '...':(jsonData.mainTopic)}}</label>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n\r\n\r\n        <div class=\"row upload-box\">\r\n          <div class=\"col-md-12 file-drop-wrapper\">\r\n            <div class=\"drop-box\">\r\n              <select [(ngModel)]=\"varJson.category_id\" (change)=\"setCategoryType($event.target.value)\"\r\n                class=\"form-ctrl ga-form-input\" style=\"margin-bottom: 0.8em\">\r\n                <option value=\"0\">Select file type</option>\r\n                <option *ngFor=\"let category of categiesTypeList; \" [value]=\"category.category_id\">\r\n                  {{category.category_name}}</option>\r\n              </select>\r\n              <div class=\"row\" *ngIf=\"varJson.category_id==235\">\r\n                  <div class=\"col-md-7\">\r\n                    <div class=\"field-wrapper\">\r\n                      <label>Privacy Settings<div class=\"questionInfo inline-relative\">\r\n                          <span class=\"qInfoIcon i-class\">i</span>\r\n                          <div class=\"tooltip-box-field\">\r\n                            Set the video visibility mode to private or public.\r\n                            In private mode, video will be visible to the enrolled students.\r\n                            In public mode, video will be visible to guest users & enrolled students\r\n                          </div>\r\n                        </div></label>\r\n                      <div class=\"row\" style=\"padding: 15px 30px;\">\r\n                        <label class=\"toggle\">\r\n                          <span class=\"toggle-label\" id=\"unassigned\"\r\n                            [ngClass]=\"(varJson.is_private)?'inactive_toggle_button':'active_toggle_button'\">Private</span>\r\n                          <input class=\"toggle-checkbox\" type=\"checkbox\" [(ngModel)]=\"varJson.is_private\">\r\n                          <div class=\"toggle-switch\"></div>\r\n                          <span class=\"toggle-label\" id=\"assigned\"\r\n                            [ngClass]=\"(varJson.is_private)?'active_toggle_button':'inactive_toggle_button'\">Public\r\n                          </span>\r\n                        </label>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"col-md-5\">\r\n                    <div class=\"field-wrapper\" style=\"margin-left: -50px;\">\r\n                      <div class=\"dropdown-div\">\r\n                        <label>Enable Watermark <div class=\"questionInfo inline-relative\">\r\n                            <span class=\"qInfoIcon i-class\">i</span>\r\n                            <div class=\"tooltip-box-field\">\r\n                              Enable or disable the watermark visibility in the video with this setting\r\n                            </div>\r\n                          </div>&nbsp;&nbsp;\r\n                          <div class=\"row\" style=\"padding: 15px 30px;\">\r\n                            <label class=\"toggle\">\r\n                              <span class=\"toggle-label\" id=\"unassigned\"\r\n                                [ngClass]=\"(varJson.enable_watermark)?'inactive_toggle_button':'active_toggle_button'\">Disable\r\n                              </span>\r\n                              <input class=\"toggle-checkbox\" type=\"checkbox\" [(ngModel)]=\"varJson.enable_watermark\">\r\n                              <div class=\"toggle-switch\"></div>\r\n                              <span class=\"toggle-label\" id=\"assigned\"\r\n                                [ngClass]=\"(varJson.enable_watermark)?'active_toggle_button':'inactive_toggle_button'\">Enable\r\n                              </span>\r\n                            </label>\r\n                          </div>\r\n                        </label>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              <input type=\"text\" style=\"margin-bottom: 0.8em;\"\r\n                *ngIf=\"varJson.category_id==235\" class=\"form-ctrl video-input\"\r\n                placeholder=\"Video Title\" [(ngModel)]=\"varJson.title\">\r\n\r\n              <input type=\"text\" style=\"margin-bottom: 0.8em;\" class=\"form-ctrl video-input\"\r\n                *ngIf=\"varJson.category_id==230\" placeholder=\"Video URL\" [(ngModel)]=\"varJson.video_url\">\r\n\r\n              <div class=\"btn-div\" *ngIf=\"varJson.category_id==230\">\r\n                <input class=\"btn fullBlue\" type=\"button\" value=\"Upload\" [disabled]=\"varJson.video_url==''\"\r\n                  (click)=\"uploadYoutubeURL($event)\">\r\n                <input class=\"btn\" (click)=\" clearuploadObject()\" type=\"button\" value=\"Cancel\">\r\n              </div>\r\n              <div style=\" height: 22rem;overflow:hidden; overflow-y: scroll;\" class=\"table table-responsive table-made\"\r\n                *ngIf=\"varJson.category_id==330\">\r\n                <table>\r\n                  <thead>\r\n                    <tr style=\"background:#005cbf;\">\r\n                      <td>#</td>\r\n                      <td>Title</td>\r\n                      <td>Size</td>\r\n                      <td>Date</td>\r\n                      <td>Source</td>\r\n                      <td>Links</td>\r\n                    </tr>\r\n                  </thead>\r\n                  <tbody>\r\n                    <tr *ngFor=\"let video of existVideos;\">\r\n                      <td>\r\n                        <div class=\"field-radio-wrapper\">\r\n                          <input type=\"radio\" name=\"bothRadio\" id=\"bothRadio\" class=\"form-radio\"\r\n                            [(ngModel)]=\"jsonData.selectedVideo\" [value]=\"video.video_id\"\r\n                            (ngModelChange)=\"onRadioButtonChange($event,video)\">\r\n                          <label for=\"bothRadio\"></label>\r\n                        </div>\r\n                      </td>\r\n                      <td>\r\n                        <span class=\"txt-title text-left\"\r\n                          title=\"{{video.video_title}}\">{{video.video_title.length>20?(video.video_title | slice:0:20):video.video_title}}</span>\r\n                      </td>\r\n                      <td>{{video.video_size}} MB</td>\r\n                      <td>{{video.video_upload_date | date: 'dd-MMM-yyyy'}}</td>\r\n                      <td><span class=\"txt-title\"\r\n                          title=\"{{getSourceName(video)}}\">{{(getSourceName(video)?.length>30)?(getSourceName(video) | slice:0:30) + '...':(getSourceName(video))}}</span>\r\n                      </td>\r\n                      <td>\r\n                          <span *ngIf=\"video.link_video_list.length==0\">-</span>\r\n                        <div class=\"questionInfo inline-relative\" *ngIf=\"video.link_video_list.length\">\r\n                          <span class=\"qInfoIcon i-class\"><b>{{video.link_video_list.length}}</b></span>\r\n                          <div class=\"tooltip-box-field text-left\">\r\n                            <span *ngFor=\"let data of video.link_video_list;let i=index\" style=\"padding: 5px;\">\r\n                              {{videoGetDetails(data,i+1)}} <br>\r\n                            </span>\r\n                          </div>\r\n                        </div>\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                </table>\r\n              </div>\r\n              <div class=\"btn-div\" *ngIf=\"varJson.category_id==330\"\r\n                style=\" position: absolute; right: 1rem; bottom: -10px;\">\r\n                <input class=\"btn fullBlue\" type=\"button\" value=\"Link Video\" (click)=\"linkAlreadyUploadedVideo($event)\">\r\n                <input class=\"btn\" (click)=\" clearuploadObject()\" type=\"button\" value=\"Cancel\">\r\n              </div>\r\n              <p-fileUpload customUpload=\"true\" type=\"submit\" (uploadHandler)=\"uploadHandler2($event,values)\"\r\n                [showCancelButton]=\"false\"\r\n                *ngIf=\"varJson.category_id==235 && varJson.category_id!=0 && varJson.category_id!=330\">\r\n              </p-fileUpload>\r\n\r\n              <p-fileUpload customUpload=\"true\" multiple=\"multiple\" type=\"submit\"\r\n                (uploadHandler)=\"uploadHandler($event,values)\" [showCancelButton]=\"false\"\r\n                *ngIf=\"varJson.category_id!=230 && varJson.category_id!=235 && varJson.category_id!=330\">\r\n              </p-fileUpload>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/core/upload-file/upload-file.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.ga-modal-wrapper {\n  right: 0;\n  position: fixed;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  background: rgba(136, 136, 136, 0.6);\n  z-index: 999; }\n.ga-modal-wrapper .ga-modal-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    overflow-y: auto;\n    height: 100%; }\n.ga-modal-wrapper .ga-modal-container .ga-modal {\n      margin: auto;\n      background: #fff;\n      border: 2pt solid #fff;\n      border-radius: .2em;\n      -webkit-box-shadow: 0 2pt 3pt #999;\n              box-shadow: 0 2pt 3pt #999;\n      min-width: 50%; }\n.ga-modal-wrapper .ga-modal-container .ga-modal .ga-modal-head {\n        padding: .5em 1em;\n        border-bottom: 1pt solid #ddd;\n        font-weight: bold; }\n.ga-modal-wrapper .ga-modal-container .ga-modal .ga-modal-head .close {\n          font-weight: bold;\n          font-size: 1.2em;\n          position: relative;\n          right: -0.6em;\n          top: -0.4em;\n          background: #fff;\n          border-radius: 100%;\n          width: 24px;\n          height: 24px;\n          display: -webkit-box;\n          display: -ms-flexbox;\n          display: flex;\n          opacity: 1;\n          cursor: pointer; }\n.ga-modal-wrapper .ga-modal-container .ga-modal .ga-modal-head .close:after {\n            content: 'X';\n            margin: auto;\n            font-size: .85em; }\n.ga-modal-wrapper .ga-modal-container .ga-modal .ga-modal-body {\n        padding: 1em; }\n.ga-form-input {\n  border: 1pt solid #ddd;\n  width: 100%;\n  border-radius: 3px;\n  padding: .2em;\n  color: #334e4c;\n  -webkit-box-shadow: inset 0 0 2pt #f1f1f1;\n          box-shadow: inset 0 0 2pt #f1f1f1; }\n.field-checkbox-wrapper, .field-radio-wrapper {\n  position: relative;\n  padding-left: 0px;\n  margin-bottom: 0px; }\n.upload-box {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex; }\n.upload-box .file-drop-wrapper {\n    padding: 0 1em; }\n.upload-box .file-drop-wrapper .drop-box {\n      background: #ecf7ff;\n      height: 100%;\n      border: 1pt solid #9E9E9E;\n      border-style: dashed;\n      margin-bottom: 30px; }\n::ng-deep .ui-fileupload {\n  width: 100%;\n  cursor: pointer; }\n::ng-deep .ui-fileupload-buttonbar {\n  background: #0060A3;\n  width: auto; }\n::ng-deep .ui-fileupload-content {\n  min-height: 200px;\n  width: auto;\n  padding: 5px;\n  border-top: none;\n  border-right: 3px dashed #eaeaeb;\n  border-bottom: 3px dashed #eaeaeb;\n  border-left: 3px dashed #eaeaeb;\n  cursor: pointer; }\n::ng-deep .ui-fileupload-content::after {\n    content: \"Drag & Drop Files Here\";\n    color: rgba(0, 0, 0, 0.09);\n    position: absolute;\n    top: 35%;\n    left: 5%;\n    font-size: 36px; }\n.video-input {\n  border: 1pt solid #ddd;\n  width: 100%;\n  border-radius: 3px;\n  padding: 1em;\n  color: #334e4c;\n  -webkit-box-shadow: inset 0 0 2pt #f1f1f1; }\n.btn-div {\n  float: right;\n  margin-top: 3em;\n  margin-right: 1em;\n  margin-bottom: 1em; }\n.title {\n  font-weight: 600; }\n.qInfoIcon {\n  width: 20px;\n  margin-left: 5px;\n  height: 20px;\n  border: 1px solid #ccc;\n  border-radius: 50%;\n  display: block;\n  text-align: center;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  line-height: 20px;\n  font-weight: 600;\n  font-size: 12px;\n  cursor: pointer;\n  -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n          box-shadow: 0px 0px 1px 0px #ccc inset;\n  color: #888;\n  -webkit-transition: all 0.2s linear;\n  transition: all 0.2s linear; }\n.qInfoIcon:hover {\n    border-color: #0060A3;\n    -webkit-box-shadow: 0px 0px 1px 0px #0060A3 inset;\n            box-shadow: 0px 0px 1px 0px #0060A3 inset;\n    color: #0060A3; }\n.tooltip-box-field {\n  color: white;\n  min-height: 22px;\n  width: 300px !important;\n  left: -300px !important;\n  background: grey; }\n.active_toggle_button {\n  color: #00a2ff; }\n.inactive_toggle_button {\n  color: lightgray; }\n.qInfoIcon {\n  width: 20px;\n  margin-left: 5px;\n  height: 20px;\n  border: 1px solid #ccc;\n  border-radius: 50%;\n  display: block;\n  text-align: center;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  line-height: 20px;\n  font-weight: 600;\n  font-size: 12px;\n  cursor: pointer;\n  -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n          box-shadow: 0px 0px 1px 0px #ccc inset;\n  color: #888;\n  -webkit-transition: all 0.2s linear;\n  transition: all 0.2s linear; }\n.qInfoIcon:hover {\n    border-color: #0060A3;\n    -webkit-box-shadow: 0px 0px 1px 0px #0060A3 inset;\n            box-shadow: 0px 0px 1px 0px #0060A3 inset;\n    color: #0060A3; }\n.toggle-switch {\n  display: inline-block;\n  background: #0084f6;\n  border-radius: 16px;\n  width: 46px;\n  height: 16px;\n  position: relative;\n  vertical-align: middle;\n  -webkit-transition: background 0.25s;\n  transition: background 0.25s; }\n.toggle-switch:before, .toggle-switch:after {\n    content: \"\"; }\n.toggle-switch:before {\n    display: block;\n    background: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#eee));\n    background: linear-gradient(to bottom, #fff 0%, #eee 100%);\n    border-radius: 50%;\n    -webkit-box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.25);\n            box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.25);\n    width: 16px;\n    height: 16px;\n    position: absolute;\n    -webkit-transition: left 0.25s;\n    transition: left 0.25s; }\n.toggle:hover .toggle-switch:before {\n    background: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#fff));\n    background: linear-gradient(to bottom, #fff 0%, #fff 100%);\n    -webkit-box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.5);\n            box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.5); }\n.toggle-checkbox:checked + .toggle-switch {\n    background: #0084f6; }\n.toggle-checkbox:checked + .toggle-switch:before {\n      left: 30px; }\n.field-wrapper {\n  padding-left: 10px; }\n.black-bg {\n  background: rgba(12, 11, 11, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 1100;\n  width: 100%; }\n"

/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/core/upload-file/upload-file.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UploadFileComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_http_service__ = __webpack_require__("./src/app/services/http.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__file_service__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/file.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




;


var UploadFileComponent = /** @class */ (function () {
    function UploadFileComponent(_http, auth, msgService, router, _fservice, renderer) {
        var _this = this;
        this._http = _http;
        this.auth = auth;
        this.msgService = msgService;
        this.router = router;
        this._fservice = _fservice;
        this.renderer = renderer;
        this.subjectList = [];
        this.topicList = [];
        this.subtopicList = [];
        this.categiesList = [];
        this.categiesTypeList = [];
        this.existVideos = [];
        this.showModal = false;
        this.dragoverflag = false;
        this.isRippleLoad = false;
        this.addCategoryPopup = false;
        this.material_dataShow = false;
        this.showParentTopicModel = false;
        this.material_dataFlag = '';
        this.jsonData = {
            parentTopic: '',
            mainTopic: '',
            selectedVideo: ''
        };
        this.payload = {
            "clientPayload": {
                "policy": "",
                "key": "",
                "x-amz-signature": "",
                "x-amz-algorithm": "",
                "x-amz-date": "",
                "x-amz-credential": "",
                "uploadLink": ""
            },
            "videoId": ""
        };
        this.varJson = {
            category_id: 0,
            name: '',
            topic_id: 0,
            course_types: "",
            video_url: "",
            sub_topic_id: 0,
            subject_id: 0,
            file_id: 0,
            is_readonly: 'N',
            title: '',
            is_private: false,
            enable_watermark: true
        };
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
    }
    UploadFileComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dragoverflag = true;
        this.getcategoriesList();
        this.getCategories();
        this._http.data.subscribe(function (data) {
            if (data == 'material-web') {
                _this.material_dataFlag = 'material';
                _this._http.updatedDataSelection(null);
            }
        });
    };
    UploadFileComponent.prototype.ngAfterViewChecked = function () {
        // if(document.getElementsByClassName('ui-fileupload-row').length){
        //   this.renderer.setStyle(document.getElementsByClassName('ui-fileupload-row')[0].children[2], 'display', 'none');
        // }
    };
    UploadFileComponent.prototype.getVDOCipherLinkedDate = function () {
        var _this = this;
        var url = "/api/v1/instFileSystem/VDOCipher/" + this.institute_id;
        this.existVideos = [];
        this.isRippleLoad = true;
        this._http.getData(url).subscribe(function (res) {
            // console.log(res);
            _this.isRippleLoad = false;
            if (res) {
                _this.existVideos = res;
            }
        }, function (err) {
            _this.isRippleLoad = false;
            _this.existVideos = [];
        });
    };
    UploadFileComponent.prototype.linkAlreadyUploadedVideo = function ($event) {
        var _this = this;
        // console.log($event);
        var url = "/api/v1/instFileSystem/linkVideos";
        var object = {
            "institute_id": this.institute_id,
            "videoID": this.jsonData.selectedVideo,
            "course_types": this.varJson.course_types,
            "subject_id": this.varJson.subject_id,
            "topic_id": this.varJson.topic_id,
            "sub_topic_id": this.varJson.sub_topic_id,
            "title": this.varJson.title,
            "category_id": 235,
        };
        var flag = this.uploadDatavalidation();
        if (!this.isRippleLoad && (flag)) {
            this.isRippleLoad = true;
            this._http.postData(url, object).subscribe(function (res) {
                // console.log(res);
                _this.isRippleLoad = false;
                if (res) {
                    _this.clearuploadObject();
                    _this.refreshList();
                    _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, '', res.message);
                }
            }, function (err) {
                _this.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            });
        }
    };
    UploadFileComponent.prototype.getSourceName = function (video) {
        //{{video.subject_name}}
        var source = video.ecourse_name + ' > ' + video.subject_name;
        if (video.parent_topic_name != null) {
            source += ' > ' + video.parent_topic_name;
            if (video.sub_topic_name != null) {
                source += ' > ' + video.sub_topic_name;
            }
        }
        return source;
    };
    UploadFileComponent.prototype.uploadYoutubeURL = function ($event) {
        var _this = this;
        var flag = this.uploadDatavalidation();
        if (flag) {
            var pattern = /^(http|https|www)?:\/\/[a-zA-Z0-9-\.]+\.[a-z]{2,4}/;
            if (!pattern.test(this.varJson.video_url)) {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "Incorrect url");
                return false;
            }
            // if (this.varJson.title == '') {
            //   this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "please add video title");
            //   return false;
            // }
            var formData = new FormData();
            var fileJson = {
                institute_id: this.institute_id,
                category_id: this.varJson.category_id,
                topic_id: this.varJson.topic_id,
                course_types: this.varJson.course_types,
                video_url: this.varJson.video_url,
                sub_topic_id: this.varJson.sub_topic_id,
                subject_id: this.varJson.subject_id,
                file_id: -1,
                is_readonly: 'N',
                "size": 0
            };
            var base = this.auth.getBaseUrl();
            var urlPostUpload = base + "/api/v1/instFileSystem/uploadFile";
            var newxhr_1 = new XMLHttpRequest();
            formData.append('fileJson', JSON.stringify(fileJson));
            var auths = {
                userid: sessionStorage.getItem('userid'),
                userType: sessionStorage.getItem('userType'),
                password: sessionStorage.getItem('password'),
                institution_id: sessionStorage.getItem('institute_id'),
            };
            var Authorization = btoa(auths.userid + "|" + auths.userType + ":" + auths.password + ":" + auths.institution_id);
            newxhr_1.open("POST", urlPostUpload, true);
            newxhr_1.setRequestHeader("Authorization", Authorization);
            newxhr_1.setRequestHeader("enctype", "multipart/form-data;");
            newxhr_1.setRequestHeader("Accept", "application/json, text/javascript");
            newxhr_1.setRequestHeader("Access-Control-Allow-Origin", "*");
            if (!this.isRippleLoad) {
                this.isRippleLoad = true;
                newxhr_1.onreadystatechange = function () {
                    _this.isRippleLoad = false;
                    if (newxhr_1.readyState == 4) {
                        if (newxhr_1.status >= 200 && newxhr_1.status < 300) {
                            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, '', "File uploaded successfully");
                            _this.clearuploadObject();
                            // this.material_dataShow ? this._http.updatedDataSelection('material') :
                            //   this.material_dataFlag == 'material' ? this._http.updatedDataSelection('material') : this._http.updatedDataSelection('list');
                            _this.refreshList();
                        }
                        else {
                            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', JSON.parse(newxhr_1.response).message);
                        }
                    }
                };
                newxhr_1.send(formData);
            }
        }
    };
    UploadFileComponent.prototype.refreshList = function () {
        if (this.material_dataShow && this.material_dataFlag == 'material') {
            this._http.updatedDataSelection('material');
        }
        else if (this.material_dataShow && this.material_dataFlag == 'subject-list') {
            this._http.updatedDataSelection('subject');
        }
        else {
            this._http.updatedDataSelection('list');
        }
        // console.log(this.material_dataFlag);
    };
    UploadFileComponent.prototype.checkListCall = function () {
        switch (this.material_dataFlag) {
            default:
                this._http.updatedDataSelection('subject');
        }
    };
    UploadFileComponent.prototype.clearuploadObject = function () {
        this.showModal = false;
        this.showParentTopicModel = false;
        this.varJson = {
            category_id: 0,
            name: '',
            topic_id: -0,
            course_types: "",
            video_url: "",
            sub_topic_id: 0,
            subject_id: 0,
            file_id: 0,
            is_readonly: 'N',
            title: '',
            is_private: false,
            enable_watermark: true
        };
        this.varJson.name = '';
    };
    UploadFileComponent.prototype.uploadDatavalidation = function () {
        if (this.varJson.category_id == 0) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "select file type to upload data");
            return false;
        }
        if (this.varJson.course_types == "" || this.varJson.course_types == '0') {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "please select course to upload data");
            return false;
        }
        if (this.varJson.subject_id == 0) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "please select subject to upload data");
            return false;
        }
        // if (this.varJson.topic_id == 0) {
        //   this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "please select topic to upload data");
        //   return false;
        // }
        return true;
    };
    UploadFileComponent.prototype.uploadHandler = function ($event) {
        var _this = this;
        var flag = this.uploadDatavalidation();
        // console.log(this.material_dataFlag);
        if (flag && this.checkCategoriesType($event.files)) {
            var formData_1 = new FormData();
            var fileJson = {
                institute_id: this.institute_id,
                category_id: this.varJson.category_id,
                topic_id: this.varJson.topic_id,
                course_types: this.varJson.course_types,
                video_url: this.varJson.video_url,
                sub_topic_id: this.varJson.sub_topic_id,
                subject_id: this.varJson.subject_id,
                file_id: -1,
                is_readonly: 'N',
                size: 0
            };
            if ($event.files && $event.files.length) {
                $event.files.forEach(function (file) {
                    formData_1.append('files', file);
                });
                // formData.append('files', $event.files);
            }
            var base = this.auth.getBaseUrl();
            var urlPostXlsDocument = base + "/api/v1/instFileSystem/uploadFile";
            var newxhr_2 = new XMLHttpRequest();
            var auths = {
                userid: sessionStorage.getItem('userid'),
                userType: sessionStorage.getItem('userType'),
                password: sessionStorage.getItem('password'),
                institution_id: sessionStorage.getItem('institute_id'),
            };
            var Authorization = btoa(auths.userid + "|" + auths.userType + ":" + auths.password + ":" + auths.institution_id);
            formData_1.append('fileJson', JSON.stringify(fileJson));
            newxhr_2.open("POST", urlPostXlsDocument, true);
            newxhr_2.setRequestHeader("Authorization", Authorization);
            newxhr_2.setRequestHeader("enctype", "multipart/form-data;");
            newxhr_2.setRequestHeader("Accept", "application/json, text/javascript");
            newxhr_2.setRequestHeader("Access-Control-Allow-Origin", "*");
            if (!this.isRippleLoad) {
                this.isRippleLoad = true;
                newxhr_2.onreadystatechange = function () {
                    _this.isRippleLoad = false;
                    if (newxhr_2.readyState == 4) {
                        if (newxhr_2.status >= 200 && newxhr_2.status < 300) {
                            _this.clearuploadObject();
                            _this.refreshList();
                            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, '', "File uploaded successfully");
                            _this.getDataUsedInCourseList();
                        }
                        else {
                            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', JSON.parse(newxhr_2.response).message);
                        }
                    }
                };
                newxhr_2.send(formData_1);
            }
        }
    };
    UploadFileComponent.prototype.setCategoryType = function (value) {
        var _this = this;
        // console.log(value);
        this.categiesTypeList.forEach(function (element) {
            if (element.category_id == value) {
                if (element.category_id == -1) {
                    _this.varJson.name = element.videoCategoryList[0].category_name;
                }
                else {
                    _this.varJson.name = element.category_name;
                }
            }
        });
        if (value == '330') {
            this.jsonData.selectedVideo = '';
            this.getVDOCipherLinkedDate();
        }
    };
    // user data usage get
    UploadFileComponent.prototype.getDataUsedInCourseList = function () {
        var _this = this;
        var url = "/api/v1/instFileSystem/getUsedSpace/" + this.institute_id;
        this._http.getData(url).subscribe(function (res) {
            // console.log(res);
            _this._fservice.storageData.storage_allocated = (Number(res.storage_allocated) * 0.001048576);
            _this._fservice.storageData.uploaded_size = (Number(res.uploaded_size) * 0.001048576);
            var width = 1;
            if (_this._fservice.storageData.uploaded_size != 0 &&
                _this._fservice.storageData.uploaded_size <= _this._fservice.storageData.storage_allocated) {
                width = (100 * _this._fservice.storageData.uploaded_size) / _this._fservice.storageData.storage_allocated;
            }
            _this._fservice.storageData.width = Math.round(width);
        });
    };
    UploadFileComponent.prototype.checkCategoriesType = function (files) {
        var flag = true;
        switch (this.varJson.name) {
            case "Notes":
            case "Assignment":
            case "EBook":
            case "Previous Year Questions Paper": {
                for (var i = 0; i < files.length; i++) {
                    var pattern = /([a-zA-Z0-9\s_\\.\-\(\):])+(.xls|.xlsx|.doc|.docx|.pdf|.gif|.png|.jpg|.jpeg|.ppt|.pptx|.epub|.mp3|.wav|.aac|.wma )$/i;
                    // console.log(pattern.test(files[i].name));
                    if (!pattern.test(files[i].name)) {
                        this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "please select " + this.varJson.name + " in pdf, doc, docx ,gif, png, jpg , xls, xlsx  form");
                        flag = false;
                        break;
                    }
                }
                break;
            }
            case "Images": {
                for (var i = 0; i < files.length; i++) {
                    var pattern = /([a-zA-Z0-9\s_\\.\-\(\):])+(.gif|.png|.jpg|.jpeg)$/i;
                    if (!pattern.test(files[i].name)) {
                        this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "please select " + this.varJson.name + "in gif, png, jpg form");
                        flag = false;
                        break;
                    }
                }
                break;
            }
            case "VDOCipher": {
                if (this.varJson.title == '') {
                    this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "Please add video title");
                    flag = false;
                }
                for (var i = 0; i < files.length; i++) {
                    var pattern = /([a-zA-Z0-9\s_\\.\-\(\):])+(.AVI|.FLV|.WMV|.MP4|.MOV|.FIV|.flv|.mp4|.mov|.webm|.WEBM|.mkv|.MKV|.ogv|.OGV|.vob|.VOB|.gifv|.GIFV|.mng|.MNG|.avi|.gif|.GIF|.drc|.DRC|.ogg|.OGG|.MTS|.mts|.M2TS|.m2ts|.TS|.ts|.qt|.QT|.wmv|.yuv|.YUV|.rm|.RM|.rmvb|.RMVB)/i;
                    if (!pattern.test(files[i].name)) {
                        this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "Please select " + this.varJson.name + " in avi,flv,wmv,mp4 ,webm, mkv ,ogv, vob,gifv, mng, avi,gif, drc, ogg, MTS, M2TS , TS, mov, qt , yuv, rm,rmvb and mov form");
                        flag = false;
                        break;
                    }
                }
                break;
            }
            // case "EBook": {
            //   for (let i = 0; i < files.length; i++) {
            //     let pattern = /([a-zA-Z0-9\s_\\.\-\(\):])+(.pdf|.epub)$/i;
            //     if (!pattern.test(files[i].name)) {
            //       this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "please select " + this.varJson.name + " file in epub, pdf form");
            //       flag = false;
            //       break;
            //     }
            //   }
            //   break;
            // }
            case "Audio Notes": {
                for (var i = 0; i < files.length; i++) {
                    var pattern = /([a-zA-Z0-9\s_\\.\-\(\):])+(.mp3|.wav|.aac|.wma)$/i;
                    if (!pattern.test(files[i].name)) {
                        this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "please select Audio Notes in mp3, wav, aac, wma form");
                        flag = false;
                        break;
                    }
                }
                break;
            }
            case "Slides": {
                for (var i = 0; i < files.length; i++) {
                    var pattern = /([a-zA-Z0-9\s_\\.\-\(\):])+(.ppt|.pptx)$/i;
                    if (!pattern.test(files[i].name)) {
                        this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "please select slides in ppt, pptx form");
                        flag = false;
                        break;
                    }
                }
                break;
            }
            default:
                {
                    this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', "please select type");
                    flag = false;
                    break;
                }
        }
        return flag;
    };
    UploadFileComponent.prototype.videoGetDetails = function (video, index) {
        var url = index + ' ) ' + video.ecourse_name + ' > ' + video.subject_name;
        if (video.parent_topic_name) {
            url = url + ' > ' + video.parent_topic_name;
            if (video.sub_topic_name) {
                url = url + ' > ' + video.sub_topic_name;
            }
        }
        return url;
    };
    UploadFileComponent.prototype.getCategories = function () {
        var _this = this;
        this.categiesTypeList = [];
        // this.isRippleLoad = true;
        var url = "/api/v1/instFileSystem/v2/categories";
        this._http.getData(url).subscribe(function (res) {
            // console.log(res);
            var temp = [{ category_id: 330, category_name: 'Existing video' }];
            res.forEach(function (category) {
                if (category.category_id == -1) {
                    category.videoCategoryList.forEach(function (vdoType) {
                        temp.push(vdoType);
                    });
                }
                else {
                    temp.push(category);
                }
            });
            // this.isRippleLoad = false;
            _this.categiesTypeList = temp;
            if (sessionStorage.getItem('enable_vdoCipher_feature') != '1') {
                temp.forEach(function (object, index) {
                    if (object.category_id == 235 || object.category_id == 330) {
                        temp.splice(index, 1);
                    }
                });
            }
        }, function (err) {
            // this.isRippleLoad = false;
        });
    };
    UploadFileComponent.prototype.getTopicsList = function (subjectId) {
        var _this = this;
        this.topicList = [];
        this.isRippleLoad = true;
        var url = "/api/v1/topic_manager/" + this.institute_id + "/subjects/" + subjectId + "/topics";
        this._http.getData(url).subscribe(function (res) {
            // console.log(res);
            _this.isRippleLoad = false;
            _this.topicList = res;
            _this.varJson.sub_topic_id = 0;
            _this.subtopicList = [];
        }, function (err) {
            _this.isRippleLoad = false;
        });
    };
    //Get Subtopic of a Parent Topic
    UploadFileComponent.prototype.getSubtopicList = function (subjectId) {
        var _this = this;
        this.subtopicList = [];
        this.isRippleLoad = true;
        var url = "/api/v1/topic_manager/subTopicList/" + this.institute_id + "/" + subjectId;
        this._http.getData(url).subscribe(function (res) {
            // console.log(res);
            _this.isRippleLoad = false;
            _this.subtopicList = res;
            _this.varJson.sub_topic_id = 0;
        }, function (err) {
            _this.isRippleLoad = false;
        });
    };
    UploadFileComponent.prototype.getcategoriesList = function () {
        var _this = this;
        this.categiesList = [];
        var url = "/api/v1/instFileSystem/institute/" + this.institute_id + "/ecoursesList";
        this._http.getData(url).subscribe(function (res) {
            // console.log(res);
            _this.categiesList = res;
        }, function (err) {
        });
    };
    //Get subjects of ecourse 
    UploadFileComponent.prototype.getSubjectsList = function (ecourseId) {
        var _this = this;
        this.subjectList = [];
        this.isRippleLoad = true;
        var url = "/api/v1/ecourse/" + this.institute_id + "/" + ecourseId + "/subjects";
        this._http.getData(url).subscribe(function (res) {
            // console.log(res);
            _this.subjectList = res;
            if (_this.material_dataFlag != 'material' && _this.material_dataFlag != 'subject-list') {
                _this.varJson.subject_id = 0;
            }
            _this.varJson.sub_topic_id = 0;
            _this.subtopicList = [];
            _this.isRippleLoad = false;
        }, function (err) {
            _this.isRippleLoad = false;
        });
    };
    UploadFileComponent.prototype.onRadioButtonChange = function ($event, video) {
        // console.log($event, video);
        this.varJson.title = video.video_title;
    };
    UploadFileComponent.prototype.uploadHandler2 = function ($event) {
        var _this = this;
        // console.log(this.material_dataFlag);
        var flag = this.uploadDatavalidation();
        if (flag && this.checkCategoriesType($event.files)) {
            var is_private = this.varJson.is_private == false ? 'Y' : 'N';
            var enable_watermark = this.varJson.enable_watermark == true ? 'Y' : 'N';
            var size = 0;
            size = $event.files && $event.files[0] ? $event.files[0].size : 0;
            var fileJson = {
                "institute_id": this.institute_id,
                "category_id": this.varJson.category_id,
                "topic_id": this.varJson.topic_id,
                "course_types": this.varJson.course_types,
                "video_url": null,
                "sub_topic_id": this.varJson.sub_topic_id,
                "subject_id": this.varJson.subject_id,
                "is_raw_data": "Y",
                "is_url": "N",
                "is_private": is_private,
                "title": this.varJson.title,
                "enable_watermark": enable_watermark,
                "size": (size / (1024 * 1024)).toFixed(3)
            };
            var base = this.auth.getBaseUrl();
            var urlPostXlsDocument = base + "/api/v1/instFileSystem/uploadFile";
            var newxhr_3 = new XMLHttpRequest();
            var auths = {
                userid: sessionStorage.getItem('userid'),
                userType: sessionStorage.getItem('userType'),
                password: sessionStorage.getItem('password'),
                institution_id: sessionStorage.getItem('institute_id'),
            };
            var Authorization = btoa(auths.userid + "|" + auths.userType + ":" + auths.password + ":" + auths.institution_id);
            var formData = new FormData();
            formData.append('fileJson', JSON.stringify(fileJson));
            newxhr_3.open("POST", urlPostXlsDocument, true);
            newxhr_3.setRequestHeader("Authorization", Authorization);
            newxhr_3.setRequestHeader("enctype", "multipart/form-data;");
            newxhr_3.setRequestHeader("Accept", "application/json, text/javascript");
            newxhr_3.setRequestHeader("Access-Control-Allow-Origin", "*");
            this.isRippleLoad = false;
            if (!this.isRippleLoad) {
                this.isRippleLoad = true;
                newxhr_3.onreadystatechange = function () {
                    _this.isRippleLoad = false;
                    if (newxhr_3.readyState == 4) {
                        if (newxhr_3.status >= 200 && newxhr_3.status < 300) {
                            _this.isRippleLoad = false;
                            var files = $event.files;
                            _this.file = files[0];
                            // console.log(this.file);
                            var payloadObject = JSON.parse(newxhr_3.response);
                            _this.payload = payloadObject;
                            _this.upload();
                        }
                        else {
                            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', JSON.parse(newxhr_3.response).message);
                        }
                    }
                };
                newxhr_3.send(formData);
            }
        }
        // var files = $event.files;
        // this.file = files[0];
        // console.log(this.file);
        // this.upload();
    };
    UploadFileComponent.prototype.upload = function () {
        var _this = this;
        var formData = new FormData();
        var xhr = new XMLHttpRequest();
        var self = this;
        //Build AWS S3 Request
        formData.append('key', this.payload.clientPayload.key);
        formData.append('x-amz-credential', this.payload.clientPayload['x-amz-credential']);
        formData.append('x-amz-algorithm', this.payload.clientPayload['x-amz-algorithm']);
        formData.append('x-amz-date', this.payload.clientPayload['x-amz-date']);
        formData.append('policy', this.payload.clientPayload['policy']);
        formData.append('x-amz-signature', this.payload.clientPayload['x-amz-signature']);
        formData.append("success_action_status", "201");
        formData.append("success_action_redirect", "");
        formData.append('file', this.file);
        xhr.open('POST', this.payload.clientPayload['uploadLink'], false);
        xhr.onreadystatechange = function () {
            var parser, xmlDoc;
            if (xhr.readyState == 4 && xhr.status == 201) {
                console.log(xhr.response);
                var text = '' + xhr.response + '';
                parser = new DOMParser();
                xmlDoc = parser.parseFromString(text, "text/xml");
                if (xmlDoc.getElementsByTagName("ETag")) {
                    var videoID = xmlDoc.getElementsByTagName("ETag")[0].childNodes[0].nodeValue;
                    _this.updateVideoStatus(_this.payload['videoId']);
                }
            }
        };
        xhr.send(formData);
    };
    UploadFileComponent.prototype.updateVideoStatus = function (videoID) {
        var _this = this;
        var obj = {
            "videoID": videoID,
            "institute_id": sessionStorage.getItem('institute_id'),
            "video_status": "Queued"
        };
        var url = "/api/v1/instFileSystem/updateVideoStatus";
        this._http.postData(url, obj).subscribe(function (res) {
            // console.log(res);
            _this.clearuploadObject();
            _this.refreshList();
            _this._http.updatedDataSelection('subject');
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, '', "Video uploaded successfully");
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', "some problem arise please check with support ");
        });
    };
    UploadFileComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-upload-file',
            template: __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/core/upload-file/upload-file.component.html"),
            styles: [__webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/core/upload-file/upload-file.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_http_service__["a" /* HttpService */],
            __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__["a" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_4__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_5__file_service__["a" /* FileService */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["Renderer2"]])
    ], UploadFileComponent);
    return UploadFileComponent;
}());



/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/ecourse-file-manager-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EcourseFileManagerRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__ecourse_list_ecourse_list_component__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-list/ecourse-list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__ecourse_file_manager_component__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-file-manager.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__ecourse_subject_list_ecourse_subject_list_component__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-subject-list/ecourse-subject-list.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_3__ecourse_file_manager_component__["a" /* EcourseFileManagerComponent */],
        pathMatch: 'prefix',
        children: [
            {
                path: '',
                redirectTo: 'ecourses'
            },
            {
                path: 'ecourses',
                component: __WEBPACK_IMPORTED_MODULE_2__ecourse_list_ecourse_list_component__["a" /* EcourseListComponent */]
            },
            {
                path: 'ecourses/:ecourse_id/subjects',
                component: __WEBPACK_IMPORTED_MODULE_4__ecourse_subject_list_ecourse_subject_list_component__["a" /* EcourseSubjectListComponent */]
            }
        ]
    }
];
var EcourseFileManagerRoutingModule = /** @class */ (function () {
    function EcourseFileManagerRoutingModule() {
    }
    EcourseFileManagerRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]]
        })
    ], EcourseFileManagerRoutingModule);
    return EcourseFileManagerRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/ecourse-file-manager.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"mainDiv\">\r\n  <div class=\"row\">\r\n    <div class=\"col-md-12 text-headline\">\r\n      <a routerLink=\"/view/e-store/home\">\r\n        eStore\r\n      </a>\r\n      &gt;\r\n      <span> Study Materials</span>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"row\">\r\n    <div class=\"col-md-2 file-mgr-sidebar\" style=\"margin-top: .6em;\">\r\n      <div>\r\n        <button class=\"btn btn-wide-blue\" (click)=\"toggleFileUploadModal()\">Upload File</button>\r\n      </div>\r\n\r\n      <!-- <div class=\"sidecard\">\r\n      <ul>\r\n        <li class=\"btn-wide-blue\">E-Course</li>\r\n      </ul>\r\n    </div> -->\r\n\r\n      <div class=\"sidecard\">\r\n        <div class=\"wrap\">\r\n          <h4>Download Usage<div class=\"questionInfo inline-relative\">\r\n            <span class=\"qInfoIcon i-class\">i</span>\r\n            <div class=\"tooltip-box-field lg\">\r\n              This doesn't include video storage!\r\n            </div>\r\n          </div></h4>\r\n          <p class=\"small usage\">{{_fservice.storageData.uploaded_size | number :'.2-2'}} GB used of\r\n            {{_fservice.storageData.storage_allocated | number:'.2-2'}}\r\n            GB</p>\r\n          <div class=\"progress-bar\">\r\n            <div class=\"progress-stat\" [ngStyle]=\"{'width': _fservice.storageData.width+'%'}\"></div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"col-md-10 file-mgr-wrapper\">\r\n      <div class=\"row\">\r\n        <div class=\"col-md-12 file-mgr-breadcrumb\">\r\n          <h2>\r\n            <ng-container *ngIf=\"_http.routeList.length\">\r\n              <a class=\"breadcrums\" (click)=\"gotoPageData(route)\" *ngFor=\"let route of _http.routeList ;let i = index\">\r\n                {{route.name}}\r\n                <i class=\"fas fa-angle-right\" *ngIf=\" i < (_http.routeList.length-1) \"></i>\r\n              </a>\r\n            </ng-container>\r\n          </h2>\r\n        </div>\r\n\r\n        <div class=\"col-md-12 file-mgr-body\">\r\n          <router-outlet></router-outlet>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<app-upload-file></app-upload-file>"

/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/ecourse-file-manager.component.scss":
/***/ (function(module, exports) {

module.exports = ".row {\n  margin: 0; }\n\na {\n  text-decoration: none; }\n\na i {\n    color: black;\n    font-family: 'FontAwesome'; }\n\n.text-headline {\n  font-size: 12px;\n  font-weight: 600;\n  margin-bottom: .6em;\n  margin-top: 0.6em; }\n\n.btn-wide-blue {\n  background: #2680eb;\n  color: #fff;\n  border-radius: 2px;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n  border: 0;\n  width: 100%;\n  margin: 0; }\n\n.file-mgr-sidebar .sidecard {\n  -webkit-box-shadow: 0 1pt 3pt 0 rgba(0, 0, 0, 0.16);\n          box-shadow: 0 1pt 3pt 0 rgba(0, 0, 0, 0.16);\n  border-radius: 2px;\n  margin: 1em 0;\n  padding: .5em 0;\n  cursor: default;\n  background: white; }\n\n.file-mgr-sidebar .sidecard ul li {\n    padding: .4em .6em;\n    cursor: pointer;\n    font-weight: bold; }\n\n.file-mgr-sidebar .sidecard ul li:hover {\n      background: #cedff3; }\n\n.file-mgr-sidebar .sidecard .wrap {\n    padding: .4em .6em;\n    display: inline-block; }\n\n.file-mgr-sidebar .sidecard .wrap h4 {\n      font-weight: bold;\n      margin-bottom: .5em; }\n\n.file-mgr-sidebar .sidecard .wrap .progress-bar {\n      background: #e8e8e8;\n      height: 4px;\n      width: 100%;\n      margin: .2em 0;\n      border: 0;\n      border-radius: 2px; }\n\n.file-mgr-sidebar .sidecard .wrap .progress-bar .progress-stat {\n        background: #2680eb;\n        width: 79%;\n        height: 4px; }\n\n.file-mgr-wrapper .file-mgr-breadcrumb {\n  border-bottom: 1pt solid #ddd;\n  padding: .5em 0;\n  margin-bottom: .8em;\n  cursor: pointer; }\n\n.file-mgr-wrapper .file-mgr-body {\n  padding: 0; }\n\na.breadcrums {\n  color: black !important;\n  font-size: 12px; }\n\n.usage {\n  color: #bfc2c4 !important; }\n\n.mainDiv {\n  background-color: #f5f5f5;\n  height: 100vw; }\n\n.qInfoIcon {\n  width: 15px !important;\n  height: 15px !important;\n  color: #0084f6 !important;\n  border: 1px solid #0084f6 !important;\n  border-radius: 50% !important;\n  padding: 0px 1px !important;\n  margin-left: 3px !important;\n  font-size: 12px !important;\n  line-height: 14px !important;\n  font-weight: bolder !important;\n  width: 20px;\n  margin-left: 5px;\n  height: 20px;\n  border: 1px solid #ccc;\n  border-radius: 50%;\n  display: block;\n  text-align: center;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  line-height: 20px;\n  font-weight: 600;\n  font-size: 12px;\n  cursor: pointer;\n  -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n          box-shadow: 0px 0px 1px 0px #ccc inset;\n  color: #888;\n  -webkit-transition: all 0.2s linear;\n  transition: all 0.2s linear; }\n\n.tooltip-box-field {\n  width: 150px;\n  white-space: nowrap;\n  min-height: 41px;\n  line-height: 18px;\n  padding: 5px 5px;\n  overflow: visible;\n  color: black;\n  visibility: hidden;\n  font-weight: bold; }\n\n.tooltip-box-field.lg {\n    width: 200px;\n    white-space: nowrap;\n    line-height: 20px;\n    padding: 5px 5px; }\n\n.tooltip-box-field.sm {\n    width: 100px;\n    white-space: nowrap;\n    min-height: 40px;\n    padding: 5px 5px; }\n"

/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/ecourse-file-manager.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EcourseFileManagerComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__core_upload_file_upload_file_component__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/core/upload-file/upload-file.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_http_service__ = __webpack_require__("./src/app/services/http.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__file_service__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/file.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var EcourseFileManagerComponent = /** @class */ (function () {
    function EcourseFileManagerComponent(_http, auth, router, _fservice) {
        this._http = _http;
        this.auth = auth;
        this.router = router;
        this._fservice = _fservice;
        this.showUploadFileModal = false;
    }
    EcourseFileManagerComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
            _this.getDataUsedInCourseList();
        });
    };
    EcourseFileManagerComponent.prototype.toggleFileUploadModal = function () {
        this.uploadFile.showParentTopicModel = (this.uploadFile.showParentTopicModel) ? false : true;
        this.uploadFile.showModal = (this.uploadFile.showModal) ? false : true;
    };
    EcourseFileManagerComponent.prototype.gotoPageData = function (route) {
        // console.log(route)
        this.router.navigate([route.routeLink], { queryParams: route.data });
    };
    // user data usage get
    EcourseFileManagerComponent.prototype.getDataUsedInCourseList = function () {
        var _this = this;
        var url = "/api/v1/instFileSystem/getUsedSpace/" + this.institute_id;
        this._http.getData(url).subscribe(function (res) {
            console.log(res);
            _this._fservice.storageData.storage_allocated = (Number(res.storage_allocated) * 0.001048576);
            _this._fservice.storageData.uploaded_size = (Number(res.uploaded_size) * 0.001048576);
            var width = 1;
            if (_this._fservice.storageData.uploaded_size != 0 &&
                _this._fservice.storageData.uploaded_size <= _this._fservice.storageData.storage_allocated) {
                width = (100 * _this._fservice.storageData.uploaded_size) / _this._fservice.storageData.storage_allocated;
            }
            _this._fservice.storageData.width = Math.round(width);
        });
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])(__WEBPACK_IMPORTED_MODULE_1__core_upload_file_upload_file_component__["a" /* UploadFileComponent */]),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_1__core_upload_file_upload_file_component__["a" /* UploadFileComponent */])
    ], EcourseFileManagerComponent.prototype, "uploadFile", void 0);
    EcourseFileManagerComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-ecourse-file-manager',
            template: __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-file-manager.component.html"),
            styles: [__webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-file-manager.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_http_service__["a" /* HttpService */],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_5__file_service__["a" /* FileService */]])
    ], EcourseFileManagerComponent);
    return EcourseFileManagerComponent;
}());



/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/ecourse-file-manager.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EcourseFileManagerModule", function() { return EcourseFileManagerModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__ecourse_file_manager_component__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-file-manager.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__ecourse_file_manager_routing_module__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-file-manager-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__ecourse_list_ecourse_list_component__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-list/ecourse-list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__core_upload_file_upload_file_component__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/core/upload-file/upload-file.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__ecourse_subject_list_ecourse_subject_list_component__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-subject-list/ecourse-subject-list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_primeng_fileupload__ = __webpack_require__("./node_modules/primeng/fileupload.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_primeng_fileupload___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_primeng_fileupload__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__file_service__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/file.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var EcourseFileManagerModule = /** @class */ (function () {
    function EcourseFileManagerModule() {
    }
    EcourseFileManagerModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_9__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_9__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_3__ecourse_file_manager_routing_module__["a" /* EcourseFileManagerRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_7_primeng_fileupload__["FileUploadModule"],
                __WEBPACK_IMPORTED_MODULE_8__shared_shared_module__["a" /* SharedModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_2__ecourse_file_manager_component__["a" /* EcourseFileManagerComponent */],
                __WEBPACK_IMPORTED_MODULE_4__ecourse_list_ecourse_list_component__["a" /* EcourseListComponent */],
                __WEBPACK_IMPORTED_MODULE_5__core_upload_file_upload_file_component__["a" /* UploadFileComponent */],
                __WEBPACK_IMPORTED_MODULE_6__ecourse_subject_list_ecourse_subject_list_component__["a" /* EcourseSubjectListComponent */],
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_10__file_service__["a" /* FileService */]
            ]
        })
    ], EcourseFileManagerModule);
    return EcourseFileManagerModule;
}());



/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/ecourse-list/ecourse-list.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper black-bg\" [loaderClass]=\"'blueRipple'\"\r\n  *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n<div class=\"row\">\r\n  <div class=\"head\" id=\"addDiv\" style=\"text-align: right\">\r\n    <button class=\"btn_addecourse\" routerLink=\"/view/e-store/ecoursemapping\">\r\n      <i class=\"fa fa-plus\" aria-hidden=\"true\"></i> &nbsp; E-course &nbsp;\r\n    </button>\r\n    <!-- <section class=\"login-tube pull-right\" style=\"margin-top: 14px; position: absolute;  right: -30px; top: -9px;\">\r\n      <nav (click)=\"getSettingDetails();\">\r\n        <ul class=\"login-nav\">\r\n          <li class=\"pos-rel\">\r\n            <i class=\"icons\">\r\n              <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\">\r\n                <path id=\"gearIcon\"\r\n                  d=\"M24 14.187v-4.374c-2.148-.766-2.726-.802-3.027-1.529-.303-.729.083-1.169 1.059-3.223l-3.093-3.093c-2.026.963-2.488 1.364-3.224 1.059-.727-.302-.768-.889-1.527-3.027h-4.375c-.764 2.144-.8 2.725-1.529 3.027-.752.313-1.203-.1-3.223-1.059l-3.093 3.093c.977 2.055 1.362 2.493 1.059 3.224-.302.727-.881.764-3.027 1.528v4.375c2.139.76 2.725.8 3.027 1.528.304.734-.081 1.167-1.059 3.223l3.093 3.093c1.999-.95 2.47-1.373 3.223-1.059.728.302.764.88 1.529 3.027h4.374c.758-2.131.799-2.723 1.537-3.031.745-.308 1.186.099 3.215 1.062l3.093-3.093c-.975-2.05-1.362-2.492-1.059-3.223.3-.726.88-.763 3.027-1.528zm-4.875.764c-.577 1.394-.068 2.458.488 3.578l-1.084 1.084c-1.093-.543-2.161-1.076-3.573-.49-1.396.581-1.79 1.693-2.188 2.877h-1.534c-.398-1.185-.791-2.297-2.183-2.875-1.419-.588-2.507-.045-3.579.488l-1.083-1.084c.557-1.118 1.066-2.18.487-3.58-.579-1.391-1.691-1.784-2.876-2.182v-1.533c1.185-.398 2.297-.791 2.875-2.184.578-1.394.068-2.459-.488-3.579l1.084-1.084c1.082.538 2.162 1.077 3.58.488 1.392-.577 1.785-1.69 2.183-2.875h1.534c.398 1.185.792 2.297 2.184 2.875 1.419.588 2.506.045 3.579-.488l1.084 1.084c-.556 1.121-1.065 2.187-.488 3.58.577 1.391 1.689 1.784 2.875 2.183v1.534c-1.188.398-2.302.791-2.877 2.183zm-7.125-5.951c1.654 0 3 1.346 3 3s-1.346 3-3 3-3-1.346-3-3 1.346-3 3-3zm0-2c-2.762 0-5 2.238-5 5s2.238 5 5 5 5-2.238 5-5-2.238-5-5-5z\" />\r\n              </svg>\r\n            </i>\r\n          </li>\r\n        </ul>\r\n      </nav>\r\n    </section> -->\r\n  </div>\r\n</div>\r\n\r\n<div class=\"row  wrap-data\">\r\n  <div class=\"col-md-3 ecourse-item\" *ngFor=\"let ecourse of categiesList;  \">\r\n    <div class=\"ecourse-card\" (click)=\"getToSubject(ecourse)\">\r\n      <div class=\"head\" title=\"{{ecourse.course_type}}\">\r\n        {{ecourse.course_type}}\r\n      </div>\r\n      <div class=\"body\">\r\n        <span *ngIf=\"ecourse.categoryList.length==0\" style=\"padding-left:2em;padding-top:1em;\">No Data Added</span>\r\n        <ul>\r\n          <li *ngFor=\"let item of ecourse.categoryList\">{{item}}</li>\r\n        </ul>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"col-md-12\" style=\"margin-top:12px;\" *ngIf=\"categiesList.length==0\">\r\n    {{outputMessage}}\r\n  </div>\r\n</div>\r\n\r\n<div class=\"ga-modal-wrapper\" [hidden]=\"showSettings\">\r\n  <div class=\"ga-modal-container\">\r\n    <div class=\"ga-modal\">\r\n      <div class=\"ga-modal-head\" style=\"text-align: left\">\r\n        <span>Video Settings </span>\r\n        <div class=\"btn_cross\"> <button class=\"btn btn-xs btn-ga-white\" (click)=\"showSettings = true\">X</button></div>\r\n      </div>\r\n      <div class=\"ga-modal-body\">\r\n        <div class=\"row upload-box\">\r\n          <div style=\"height: 350px;overflow-x: hidden; padding-bottom: 10px;\" class=\"model_body_div\">\r\n            <div class=\"field-wrapper\">\r\n              <label>Watermark \r\n                <div class=\"questionInfo inline-relative\">\r\n                  <span class=\"qInfoIcon i-class\">i</span>\r\n                  <div class=\"tooltip-box-field\">\r\n                    Set the text to be shown as\r\n                    watermark in the video\r\n                  </div>\r\n                </div>\r\n              </label>\r\n              <div class=\"dropdown-div\">\r\n                <input class=\"dropdown\" [(ngModel)]=\"settingDetails.video_watermark\" type=\"text\"\r\n                  placeholder=\"  enter watermark\" />\r\n              </div>\r\n            </div>\r\n            <br>\r\n            <div class=\"row\">\r\n              <div class=\"col-md-7\">\r\n                <div class=\"field-wrapper\">\r\n                  <label>Privacy Settings<div class=\"questionInfo inline-relative\">\r\n                      <span class=\"qInfoIcon i-class\">i</span>\r\n                      <div class=\"tooltip-box-field\">\r\n                        Set the video visibility mode to private or public.\r\n                        In private mode, video will be visible to the enrolled students.\r\n                        In public mode, video will be visible to guest users & enrolled students\r\n                      </div>\r\n                    </div></label>\r\n                  <div class=\"row\" style=\"padding: 15px 30px;\">\r\n                    <label class=\"toggle\">\r\n                      <span class=\"toggle-label\" id=\"unassigned\"\r\n                        [ngClass]=\"(is_video_public)?'inactive_toggle_button':'active_toggle_button'\">Private</span>\r\n                      <input class=\"toggle-checkbox\" type=\"checkbox\" [(ngModel)]=\"is_video_public\">\r\n                      <div class=\"toggle-switch\"></div>\r\n                      <span class=\"toggle-label\" id=\"assigned\"\r\n                        [ngClass]=\"(is_video_public)?'active_toggle_button':'inactive_toggle_button'\">Public\r\n                      </span>\r\n                    </label>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"col-md-5\">\r\n                <div class=\"field-wrapper\" style=\"margin-left: -50px;\">\r\n                  <div class=\"dropdown-div\">\r\n                    <label>Colour <div class=\"questionInfo inline-relative\">\r\n                        <span class=\"qInfoIcon i-class\">i</span>\r\n                        <div class=\"tooltip-box-field\">\r\n                          Pick the choice of colour\r\n                          for the watermark text.\r\n                        </div>\r\n                      </div>&nbsp;&nbsp;\r\n                      <div class=\"row\" style=\"padding: 15px 30px;\">\r\n                        <input [(ngModel)]=\"settingDetails.watermark_color\" type=\"color\" />\r\n                      </div>\r\n                    </label>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"field-wrapper\">\r\n              <label>Opacity\r\n                <div class=\"questionInfo inline-relative\">\r\n                  <span class=\"qInfoIcon i-class\">i</span>\r\n                  <div class=\"tooltip-box-field\">\r\n                    It is the opacity of the watermark text.\r\n                    It defines how much watermark text\r\n                    will obscure the background image\r\n                  </div>\r\n                </div>\r\n              </label>\r\n              <div class=\"row\" style=\"padding: 15px 30px;\">\r\n                <div class=\"col-md-9\">\r\n                  <input type=\"range\" min=\"0.00\" max=\"1.00\" step=\"0.05\"\r\n                    [(ngModel)]=\"settingDetails.watermark_opacity\" />\r\n                </div>\r\n                <div class=\"col-md-3\">{{settingDetails.watermark_opacity}}</div>\r\n              </div>\r\n            </div>\r\n            <div class=\"field-wrapper\">\r\n              <label>Font Size <div class=\"questionInfo inline-relative\">\r\n                  <span class=\"qInfoIcon i-class\">i</span>\r\n                  <div class=\"tooltip-box-field\">\r\n                    It is the overall size (height) of the\r\n                    watermark text font\r\n                    shown on the screen\r\n                  </div>\r\n                </div></label>\r\n              <div class=\"row\" style=\"padding: 15px 30px;\">\r\n                <div class=\"col-md-9\">\r\n                  <input type=\"range\" min=\"1\" max=\"100\" [(ngModel)]=\"settingDetails.watermark_font_size\" />\r\n                </div>\r\n                <div class=\"col-md-3\">{{settingDetails.watermark_font_size}} px</div>\r\n              </div>\r\n            </div>\r\n            <div class=\"field-wrapper\">\r\n              <label>Bandwidth Threshold Alerts <div class=\"questionInfo inline-relative\">\r\n                  <span class=\"qInfoIcon i-class\">i</span>\r\n                  <div class=\"tooltip-box-field\">\r\n                    Set limits (in percentage) for\r\n                    bandwidth utilization to receive\r\n                    the alerts in SMS & email.\r\n                  </div>\r\n                </div></label>\r\n              <div class=\"row\" style=\"padding: 15px 30px;\">\r\n                <div class=\"col-md-9\">\r\n                  <input type=\"range\" min=\"1\" max=\"100\" [(ngModel)]=\"settingDetails.vdocipher_bandwidth_threshold\" />\r\n                </div>\r\n                <div class=\"col-md-3\">{{settingDetails.vdocipher_bandwidth_threshold}}%</div>\r\n              </div>\r\n            </div>\r\n            <div class=\"field-wrapper\">\r\n              <label>Storage Capacity Threshold Alerts <div class=\"questionInfo inline-relative\">\r\n                  <span class=\"qInfoIcon i-class\">i</span>\r\n                  <div class=\"tooltip-box-field\">\r\n                    Set limits (in percentage) for\r\n                    storage utilization to receive\r\n                    the alerts in SMS & email\r\n                  </div>\r\n                </div></label>\r\n              <div class=\"row\" style=\"padding: 15px 30px;\">\r\n                <div class=\"col-md-9\">\r\n                  <input type=\"range\" min=\"1\" max=\"100\"\r\n                    [(ngModel)]=\"settingDetails.vdocipher_storage_capacity_threshold\" />\r\n                </div>\r\n                <div class=\"col-md-3\">{{settingDetails.vdocipher_storage_capacity_threshold}} %</div>\r\n              </div>\r\n            </div>\r\n            <div class=\"field-wrapper\">\r\n              <label>Interval <div class=\"questionInfo inline-relative\">\r\n                  <span class=\"qInfoIcon i-class\">i</span>\r\n                  <div class=\"tooltip-box-field\">\r\n                    Specify the interval over which\r\n                    watermark changes position.\r\n                    The value is the interval in\r\n                    seconds when the text changes position.\r\n                  </div>\r\n                </div></label>\r\n              <div class=\"row\" style=\"padding: 15px 30px;\">\r\n                <div class=\"col-md-9\">\r\n                  <input type=\"range\" min=\"1\" max=\"100\" [(ngModel)]=\"settingDetails.watermark_text_moving_interval\" />\r\n                </div>\r\n                <div class=\"col-md-3\">{{settingDetails.watermark_text_moving_interval}} Sec</div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"ga-modal-head\" style=\"text-align: right\">\r\n        <div class=\"modal-footer\">\r\n          <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\" (click)=\"clearObject()\">Cancel</button>\r\n          <button type=\"button\" class=\"btn btn-primary fullBlue\" (click)=\"Save_Setting_Details()\">Save </button>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/ecourse-list/ecourse-list.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.wrap-data {\n  height: 88vh;\n  overflow-y: scroll;\n  overflow-x: none; }\n.wrap-data ::-webkit-scrollbar {\n    display: block !important;\n    width: 7px;\n    height: 7px; }\n.btn_cross {\n  text-align: right;\n  margin-bottom: -25px;\n  position: relative;\n  bottom: 1.4rem;\n  right: -.7rem; }\n#addDiv {\n  text-align: right;\n  position: absolute;\n  right: 0px;\n  top: -3rem; }\n#addDiv .btn_addecourse {\n    padding: 8px;\n    border-radius: 13px;\n    color: #fff;\n    background: #2680eb;\n    font-weight: 600;\n    font-size: 12px; }\n.icons:hover {\n  color: #2680eb; }\n.ecourse-item {\n  padding: 1em; }\n.ecourse-item .ecourse-card {\n    border-radius: 4px;\n    -webkit-box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.16);\n            box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.16);\n    border: solid 1px #cedff3;\n    background-color: #ffffff;\n    height: 100%;\n    cursor: pointer; }\n.ecourse-item .ecourse-card:hover .head {\n      background: #b1ccec; }\n.ecourse-item .ecourse-card .head {\n      text-align: center;\n      padding: .8em .6em;\n      background-color: #cedff3;\n      font-weight: bold;\n      color: #3f2e2e;\n      height: 60px;\n      overflow: hidden; }\n.ecourse-item .ecourse-card .body {\n      padding: .6em .8em;\n      height: 15em; }\n.ecourse-item .ecourse-card .body ul {\n        padding-left: 1.4em; }\n.ecourse-item .ecourse-card .body ul li {\n          padding: .2em 0;\n          font-size: .9em;\n          color: #212c34; }\n.ecourse-item .ecourse-card .body ul {\n        list-style: none; }\n.ecourse-item .ecourse-card .body ul li::before {\n        content: \"\\2022\";\n        color: #85bdff;\n        font-weight: bold;\n        display: inline-block;\n        width: 1em;\n        margin-left: -1em; }\n.ga-modal-wrapper {\n  right: 0;\n  position: fixed;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  background: rgba(136, 136, 136, 0.6);\n  z-index: 999; }\n.ga-modal-wrapper .ga-modal-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    overflow-y: auto;\n    height: 100%; }\n.ga-modal-wrapper .ga-modal-container .ga-modal {\n      margin: auto;\n      background: #fff;\n      border: 2pt solid #fff;\n      border-radius: .2em;\n      -webkit-box-shadow: 0 2pt 3pt #999;\n              box-shadow: 0 2pt 3pt #999;\n      min-width: 30%;\n      max-width: 35%; }\n.ga-modal-wrapper .ga-modal-container .ga-modal .ga-modal-head {\n        padding: .5em 1em;\n        border-bottom: 1pt solid #ddd;\n        font-weight: bold;\n        text-align: center; }\n.ga-modal-wrapper .ga-modal-container .ga-modal .ga-modal-body {\n        padding: 1em;\n        text-align: center;\n        padding-top: 0px; }\n.btn-ga-white {\n  padding: .1em .6em;\n  height: auto;\n  -webkit-box-shadow: 1pt 1pt 0 #f1f1f1;\n          box-shadow: 1pt 1pt 0 #f1f1f1;\n  color: #555; }\n.btn-ga-white:hover {\n    color: #07f; }\n.btn-ga-white:focus {\n    outline: none; }\n.btn-ga-white:active {\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    color: #fff;\n    background: #0084f6;\n    border: 1px solid #0084f6; }\n.model_body_div .field-wrapper label {\n  color: #3e3d4a;\n  font-weight: 600; }\n.model_body_div .field-wrapper .dropdown-div .dropdown {\n  width: 100%;\n  height: 30px;\n  border: 1px solid #ddd;\n  border-radius: 4px; }\n.field-wrapper {\n  position: relative;\n  padding-top: 10px;\n  text-align: LEFT;\n  padding: 20px 20px 0px 20px;\n  padding-top: 10px;\n  padding-right: 20px;\n  padding-bottom: 0px;\n  padding-left: 20px; }\n.toggle {\n  cursor: pointer;\n  display: inline-block; }\n.toggle-switch {\n  display: inline-block;\n  background: #0084f6;\n  border-radius: 16px;\n  width: 46px;\n  height: 16px;\n  position: relative;\n  vertical-align: middle;\n  -webkit-transition: background 0.25s;\n  transition: background 0.25s; }\n.toggle-switch:before, .toggle-switch:after {\n    content: \"\"; }\n.toggle-switch:before {\n    display: block;\n    background: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#eee));\n    background: linear-gradient(to bottom, #fff 0%, #eee 100%);\n    border-radius: 50%;\n    -webkit-box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.25);\n            box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.25);\n    width: 16px;\n    height: 16px;\n    position: absolute;\n    -webkit-transition: left 0.25s;\n    transition: left 0.25s; }\n.toggle:hover .toggle-switch:before {\n    background: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#fff));\n    background: linear-gradient(to bottom, #fff 0%, #fff 100%);\n    -webkit-box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.5);\n            box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.5); }\n.toggle-checkbox:checked + .toggle-switch {\n    background: #0084f6; }\n.toggle-checkbox:checked + .toggle-switch:before {\n      left: 30px; }\n.toggle-checkbox {\n  position: absolute;\n  visibility: hidden; }\n.toggle-label {\n  margin-left: 5px;\n  margin-right: 5px;\n  position: relative;\n  top: 2px;\n  font-weight: 600; }\n.active_toggle_button {\n  color: #00a2ff; }\n.inactive_toggle_button {\n  color: lightgray; }\n/*Chrome*/\n@media screen and (-webkit-min-device-pixel-ratio: 0) {\n  input[type='range'] {\n    overflow: hidden;\n    -webkit-appearance: none;\n    background-color: #337ab7; }\n  input[type='range']::-webkit-slider-thumb {\n    width: 0px;\n    -webkit-appearance: none;\n    height: 10px;\n    cursor: ew-resize;\n    -webkit-box-shadow: -8px 0 0 8px orange;\n            box-shadow: -8px 0 0 8px orange; } }\n.qInfoIcon {\n  width: 20px;\n  margin-left: 5px;\n  height: 20px;\n  border: 1px solid #ccc;\n  border-radius: 50%;\n  display: block;\n  text-align: center;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  line-height: 20px;\n  font-weight: 600;\n  font-size: 12px;\n  cursor: pointer;\n  -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n          box-shadow: 0px 0px 1px 0px #ccc inset;\n  color: #888;\n  -webkit-transition: all 0.2s linear;\n  transition: all 0.2s linear; }\n.qInfoIcon:hover {\n    border-color: #0060A3;\n    -webkit-box-shadow: 0px 0px 1px 0px #0060A3 inset;\n            box-shadow: 0px 0px 1px 0px #0060A3 inset;\n    color: #0060A3; }\n.black-bg {\n  background: rgba(12, 11, 11, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 6;\n  width: 100%; }\n"

/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/ecourse-list/ecourse-list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EcourseListComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_http_service__ = __webpack_require__("./src/app/services/http.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var EcourseListComponent = /** @class */ (function () {
    function EcourseListComponent(_http, auth, msgService, router, cd) {
        var _this = this;
        this._http = _http;
        this.auth = auth;
        this.msgService = msgService;
        this.router = router;
        this.cd = cd;
        this.categiesList = [];
        this.isRippleLoad = false;
        this.showSettings = true;
        this.is_video_public = true;
        this.outputMessage = '';
        this.settingDetails = {
            "institute_id": 100058,
            "video_watermark": "Megha",
            "is_video_public": true,
            "watermark_opacity": 1,
            "watermark_color": "#2680eb",
            "watermark_font_size": 10,
            "video_watch_limit_per_video": 1,
            "storage_capacity_threshold_alerts": 1,
            "bandwidth_threshold_alerts": 1,
            "watermark_text_moving_interval": 1
        };
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        console.log("EcourseListComponent");
    }
    EcourseListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.getcategoriesList();
        this._http.routeList = [];
        var obj = { routeLink: '/view/e-store/ecourse-file-manager/ecourses', name: 'E-Course', data: { data: null } };
        this._http.routeList.push(obj);
        sessionStorage.setItem('routeListForEcourse', JSON.stringify(this._http.routeList));
        this.cd.detectChanges();
        this._http.data.subscribe(function (data) {
            // console.log(data);
            if (data == 'list') {
                _this.getcategoriesList();
                _this._http.updatedDataSelection(null);
            }
        });
    };
    EcourseListComponent.prototype.getToSubject = function (ecourse) {
        if (sessionStorage.getItem('routeListForEcourse')) {
            this.router.navigate(['/view/e-store/ecourse-file-manager/ecourses/' + ecourse.course_type_id + "/subjects"], { queryParams: { data: window.btoa(ecourse.course_type) } });
        }
    };
    EcourseListComponent.prototype.getSettingDetails = function () {
        var _this = this;
        // <base_url>/instFileSystem/getStudyMaterialSetting/{institute_id}
        var url = "/api/v1/instFileSystem/getStudyMaterialSetting/" + this.institute_id;
        this.isRippleLoad = true;
        this.showSettings = true;
        this._http.getData(url).subscribe(function (res) {
            console.log("getSettingDetails", res);
            _this.isRippleLoad = false;
            _this.settingDetails = res;
            _this.is_video_public = _this.settingDetails.is_video_public == 'Y' ? true : false;
            _this.showSettings = false;
        }, function (err) {
            _this.isRippleLoad = false;
        });
    };
    EcourseListComponent.prototype.clearObject = function () {
        this.showSettings = !this.showSettings;
    };
    EcourseListComponent.prototype.Save_Setting_Details = function () {
        var _this = this;
        this.isRippleLoad = true;
        //<base_url>/instFileSystem/updateStudyMaterialSetting
        var url = "/api/v1/instFileSystem/updateStudyMaterialSetting";
        this.settingDetails.institute_id = this.institute_id;
        this.settingDetails.is_video_public = this.is_video_public == true ? 'Y' : 'N';
        var object = {
            "institute_id": this.settingDetails.institute_id,
            "video_watermark": this.settingDetails.video_watermark,
            "is_video_public": this.settingDetails.is_video_public,
            "watermark_opacity": this.settingDetails.watermark_opacity,
            "watermark_color": this.settingDetails.watermark_color,
            "watermark_font_size": this.settingDetails.watermark_font_size,
            "watermark_text_moving_interval": this.settingDetails.watermark_text_moving_interval,
            "vdocipher_bandwidth_threshold": this.settingDetails.vdocipher_bandwidth_threshold,
            "vdocipher_storage_capacity_threshold": this.settingDetails.vdocipher_storage_capacity_threshold
        };
        this._http.putData(url, object).subscribe(function (res) {
            console.log(res);
            _this.isRippleLoad = false;
            _this.showSettings = true;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, '', res.message);
        }, function (err) {
            console.log(err);
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.message);
        });
    };
    EcourseListComponent.prototype.getcategoriesList = function () {
        var _this = this;
        this.categiesList = [];
        this.isRippleLoad = true;
        var url = "/api/v1/instFileSystem/institute/" + this.institute_id + "/ecoursesList";
        this._http.getData(url).subscribe(function (res) {
            console.log(res);
            _this.isRippleLoad = false;
            _this.categiesList = res;
            if (_this.categiesList.length == 0) {
                _this.outputMessage = 'No data found';
            }
        }, function (err) {
            _this.isRippleLoad = false;
        });
    };
    EcourseListComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-ecourse-list',
            template: __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-list/ecourse-list.component.html"),
            styles: [__webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-list/ecourse-list.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_http_service__["a" /* HttpService */],
            __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__services_message_show_service__["a" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_3__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"]])
    ], EcourseListComponent);
    return EcourseListComponent;
}());



/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/ecourse-subject-list/ecourse-subject-list.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper black-bg\" [loaderClass]=\"'blueRipple'\"\r\n  *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"row\">\r\n  <div class=\"head\" id=\"addDiv\" routerLink=\"/view/course/create/topic\" style=\"text-align: right\">\r\n    <button class=\"btn_addecourse\">\r\n      <i class=\"fa fa-plus\" aria-hidden=\"true\" style=\"font-size: 14px;\"></i> Topic &nbsp;\r\n    </button>\r\n  </div>\r\n</div>\r\n\r\n<div>\r\n    <div class=\"row\">\r\n        <div class=\"col-md-12 subject-wrapper\">\r\n          <div class=\"subject-title\">\r\n            Subject List \r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"row\">\r\n        <div class=\"col-md-12 subject-wrapper\">\r\n          <div *ngIf=\"subjectList.length==0\">\r\n            {{outputMessage}}\r\n          </div>\r\n        </div>\r\n      </div>\r\n      \r\n      <div class=\"fluid-container data-wrapper\">\r\n        <div class=\"row main-topic-row\" *ngFor=\"let topic of subjectList;\">\r\n          <div class=\"row singleton-row col-md-12 topic-data main-topic-data\">\r\n            <!-- <div class=\"field-checkbox-wrapper\">\r\n              <input type=\"checkbox\" name=\"topicIds[]\" id=\"topic{{topic.topic_id}}\" class=\"topic-selector form-checkbox\">\r\n              <label for=\"topic{{topic.topic_id}}\"></label>\r\n            </div> -->\r\n      \r\n            <div class=\"col-md-4 topic-name\">\r\n              <button class=\"btn-ga-collapse\">\r\n                <i class=\"fa fa-minus\" *ngIf=\"topic.isExpand\" (click)=\"toggleObject(topic)\"></i>\r\n                <i class=\"fa fa-plus\" *ngIf=\"!topic.isExpand\" (click)=\"toggleObject(topic)\"></i>\r\n              </button> {{topic.subject_name}}\r\n            </div>\r\n            <div class=\"col-md-4\">\r\n            </div>\r\n            <div class=\"col-md-4\">\r\n              <div>\r\n                <button class=\"btn btn-xs btn-ga-white\" (click)=\"uploadPopupOpen(topic)\">Upload</button>\r\n                <!-- <button class=\"btn btn-xs btn-ga-white\" (click)=\"getToSubjectMaterials(topic)\">view topic</button> -->\r\n                <!-- <button class=\"btn btn-xs btn-ga-white\">Add Topic</button> -->\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"row col-md-12 p-0\" *ngIf=\"topic.isExpand\">\r\n            <div class=\"col-md-12 topic-material-data\">\r\n              <ng-container *ngTemplateOutlet=\"youtubeData; context:{$implicit: topic.videosList, level: 1}\"></ng-container>\r\n              <ng-container *ngTemplateOutlet=\"assignmentData; context:{$implicit: topic.assignmentList, level: 1}\">\r\n              </ng-container>\r\n              <ng-container *ngTemplateOutlet=\"imagelistData; context:{$implicit: topic.imageList, level: 1}\"></ng-container>\r\n              <ng-container *ngTemplateOutlet=\"audioNotesData; context:{$implicit: topic.audioNotesList, level: 1}\">\r\n              </ng-container>\r\n              <ng-container *ngTemplateOutlet=\"notesData; context:{$implicit: topic.notesList, level: level+1}\">\r\n              </ng-container>\r\n              <ng-container\r\n                *ngTemplateOutlet=\"previousYearQuesListData; context:{$implicit: topic.previousYearQuesList, level: level+1}\">\r\n              </ng-container>\r\n              <ng-container *ngTemplateOutlet=\"slidesListData; context:{$implicit: topic.slidesList, level: level+1}\">\r\n              </ng-container>\r\n              <ng-container\r\n                *ngTemplateOutlet=\"studyMaterialList; context:{$implicit: topic.studyMaterialList, level: level+1}\">\r\n              </ng-container>\r\n            </div>\r\n            <div class=\"row col-md-12 subTopics-data\" *ngIf=\"topic.isExpand\">\r\n              <ng-container *ngTemplateOutlet=\"recursiveNodes; context: { $implicit: topic.subTopics, subLevel: 1 } \">\r\n              </ng-container>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n</div>\r\n\r\n\r\n<ng-template #recursiveNodes let-subTopics let-level=\"subLevel\">\r\n  <div class=\"row topic-row\" *ngFor=\"let topic of subTopics\">\r\n    <div class=\"row singleton-row col-md-12 topic-data\">\r\n      <div class=\"col-md-4 topic-name\" [ngStyle]=\"{'padding-left': level+'em'}\">\r\n        <button class=\"btn-ga-collapse\">\r\n          <i class=\"fa fa-minus\" *ngIf=\"topic.isExpand\" (click)=\"toggleObject(topic)\"></i>\r\n          <i class=\"fa fa-plus\" *ngIf=\"!topic.isExpand\" (click)=\"toggleObject(topic)\"></i>\r\n        </button>\r\n        <span class=\"txt-title\"\r\n          title=\"{{topic.topic_name}}\">{{(topic.topic_name?.length>30)?(topic.topic_name | slice:0:30) + '...':(topic.topic_name)}}</span>\r\n\r\n      </div>\r\n      <div class=\"col-md-4\">\r\n\r\n      </div>\r\n      <div class=\"col-md-4\">\r\n        <div>\r\n          <button class=\"btn btn-xs btn-ga-white\" (click)=\"uploadPopupOpen(topic)\">Upload</button>\r\n          <!-- <button class=\"btn btn-xs btn-ga-white\">Add Topic</button> -->\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"row col-md-12 p-0\" *ngIf=\"topic.isExpand\">\r\n      <div class=\"row col-md-12 topic-material-data\">\r\n        <ng-container *ngTemplateOutlet=\"youtubeData; context:{$implicit: topic.videosList, level: level+1}\">\r\n        </ng-container>\r\n        <ng-container *ngTemplateOutlet=\"assignmentData; context:{$implicit: topic.assignmentList, level: level+1}\">\r\n        </ng-container>\r\n        <ng-container *ngTemplateOutlet=\"imagelistData; context:{$implicit: topic.imageList, level: level+1}\">\r\n        </ng-container>\r\n        <ng-container *ngTemplateOutlet=\"audioNotesData; context:{$implicit: topic.audioNotesList, level: level+1}\">\r\n        </ng-container>\r\n        <ng-container *ngTemplateOutlet=\"notesData; context:{$implicit: topic.notesList, level: level+1}\">\r\n        </ng-container>\r\n        <ng-container\r\n          *ngTemplateOutlet=\"previousYearQuesListData; context:{$implicit: topic.previousYearQuesList, level: level+1}\">\r\n        </ng-container>\r\n        <ng-container *ngTemplateOutlet=\"slidesListData; context:{$implicit: topic.slidesList, level: level+1}\">\r\n        </ng-container>\r\n        <ng-container\r\n          *ngTemplateOutlet=\"studyMaterialList; context:{$implicit: topic.studyMaterialList, level: level+1}\">\r\n        </ng-container>\r\n\r\n      </div>\r\n      <div class=\"row col-md-12 subTopics-data\">\r\n        <ng-container *ngTemplateOutlet=\"recursiveNodes; context: { $implicit: topic.subTopics, subLevel: level+1 } \">\r\n        </ng-container>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n\r\n<ng-template #youtubeData let-youtube let-level=\"level\">\r\n  <div class=\"row singleton-row material-row\" *ngFor=\"let video of youtube\">\r\n    <div class=\"col-md-4 material-title txt-color\" (click)=\"getVdocipherVideoOtp(video)\" [ngStyle]=\"{'padding-left': level+'em'}\">\r\n      <h4 class=\"file__title\" title=\"{{video.title}}\">\r\n        <i class=\"fa fa-youtube-play text-red\"  *ngIf=\"video.category_name!='VDOCipher'\"></i>\r\n        <i class=\"fa fa-play-circle-o\" aria-hidden=\"true\" style=\"color: blue;font-size: 16px;\" *ngIf=\"video.category_name=='VDOCipher'\"></i>\r\n\r\n        <a [href]=\"video.video_url\" *ngIf=\"video.category_name!='VDOCipher'\" target=\"_blank\" class=\"txt-color\">\r\n          <span class=\"txt-title\"\r\n            title=\"{{video.title}}\">{{(video.title?.length>30)?(video.title | slice:0:30) + '...':(video.title)}}</span>\r\n        </a>\r\n        <a *ngIf=\"video.category_name=='VDOCipher'\"  class=\"txt-color\">\r\n          <span class=\"txt-title\"  style=\"cursor: pointer\"\r\n            title=\"{{video.title}}\">{{(video.title?.length>30)?(video.title | slice:0:30) + '...':(video.title)}}</span>\r\n        </a>\r\n      </h4>\r\n    </div>\r\n    <div class=\"col-md-4 txt-font\" *ngIf=\"video.category_name!='VDOCipher'\">\r\n      {{video.category_name}}\r\n    </div>\r\n    <div class=\"col-md-1 txt-font\" *ngIf=\"video.category_name=='VDOCipher'\">\r\n      {{video.size | number:'.2-2'}}&nbsp;MB\r\n    </div>\r\n    <div class=\"col-md-1 txt-font\" *ngIf=\"video.category_name=='VDOCipher'\">\r\n      <span [ngClass]=\"{'hide': video.video_time==null}\">  {{video.video_time }}&nbsp;Hr</span>\r\n    </div>\r\n    <div class=\"col-md-1 txt-font\" *ngIf=\"video.category_name=='VDOCipher'\">\r\n      {{video.watch_count}} &nbsp;<i  class=\"fas fa fa-eye\" style=\"color:#2680eb;font-family: FontAwesome ;font-size: 14px;display: inline-block;vertical-align: middle; margin-right:5px\" title=\"Watched\"></i> \r\n    </div>\r\n    <div class=\"col-md-1 txt-font\" style=\"color:blue;\" *ngIf=\"video.category_name=='VDOCipher'\">\r\n        {{video.video_status |titlecase}} &nbsp;\r\n      </div>\r\n    <div class=\"col-md-4\">\r\n      <div class=\"action-buttons\" *ngIf=\"video.category_name=='VDOCipher'\">\r\n        <button class=\"btn btn-xs btn-ga-white\" *ngIf=\"video.is_video_linked!='N'\" (click)=\"setRemoveDataFile(video,'unlink')\">Unlink</button>\r\n        <button class=\"btn btn-xs btn-ga-white\" *ngIf=\"video.is_video_linked=='N'\" (click)=\"setRemoveDataFile(video,'delete')\">Delete</button>\r\n        <button class=\"btn btn-xs btn-ga-white\" *ngIf=\"video.is_video_linked=='N'\" (click)=\"setRemoveDataFile(video,'unlink all')\">Unlink All</button>\r\n      </div>\r\n      <div class=\"action-buttons\" *ngIf=\"video.category_name!='VDOCipher'\">\r\n        <button class=\"btn btn-xs btn-ga-white\"  (click)=\"setRemoveDataFile(video,'delete')\">Delete</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n<ng-template #imagelistData let-image let-level=\"level\">\r\n  <div class=\"row singleton-row material-row\" *ngFor=\"let file of image\">\r\n    <div class=\"col-md-4 material-title txt-color \" [ngStyle]=\"{'padding-left': level+'em'}\">\r\n      <h4 class=\"file__title\" title=\"{{file.title}}\">\r\n        <i [class]=\"file?.extension\" aria-hidden=\"true\"></i>\r\n        <span class=\"txt-title\"\r\n          title=\"{{file.title}}\">{{(file.title?.length>30)?(file.title | slice:0:30) + '...':(file.title)}}</span>\r\n      </h4>\r\n    </div>\r\n    <div class=\"col-md-1 txt-font\">\r\n      {{file.size | number:'.2-2'}}&nbsp;MB\r\n    </div>\r\n    <div class=\"col-md-2 txt-font\">\r\n        {{file.downloads}} &nbsp;Downloads \r\n      </div>\r\n    <div class=\"col-md-5\">\r\n      <div class=\"action-buttons\">\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"addDownloadCount(file)\">\r\n          <a [href]=\"file.file_name\" class=\"btn-ga-white-download\" [download]=\"file.title\">Download</a>\r\n        </button>\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"setRemoveDataFile(file,'delete')\">Delete</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n<ng-template #assignmentData let-assignment let-level=\"level\">\r\n  <div class=\"row singleton-row material-row\" *ngFor=\"let file of assignment\">\r\n    <div class=\"col-md-4 material-title txt-color\" [ngStyle]=\"{'padding-left': level+'em'}\">\r\n      <h4 class=\"file__title\" title=\"{{file.title}}\">\r\n        <i [class]=\"file?.extension\" aria-hidden=\"true\"></i>\r\n        <span class=\"txt-title\"\r\n          title=\"{{file.title}}\">{{(file.title?.length>30)?(file.title | slice:0:30) + '...':(file.title)}}</span>\r\n      </h4>\r\n    </div>\r\n    <div class=\"col-md-1 txt-font\">\r\n      {{file.size | number:'.2-2'}}&nbsp;MB\r\n    </div>\r\n    <div class=\"col-md-2 txt-font\">\r\n        {{file.downloads}} &nbsp;Downloads \r\n      </div>\r\n    <div class=\"col-md-5\">\r\n      <div class=\"action-buttons\">\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"addDownloadCount(file)\">\r\n          <a [href]=\"file.file_name\" class=\"btn-ga-white-download\" [download]=\"file.title\">Download</a>\r\n        </button>\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"setRemoveDataFile(file,'delete')\">Delete</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n<ng-template #notesData let-notes let-level=\"level\">\r\n  <div class=\"row singleton-row material-row\" *ngFor=\"let file of notes\">\r\n    <div class=\"col-md-4 material-title txt-color\" [ngStyle]=\"{'padding-left': level+'em'}\">\r\n      <h4 class=\"file__title\" title=\"{{file.title}}\">\r\n        <i [class]=\"file?.extension\" aria-hidden=\"true\"></i>\r\n        <span class=\"txt-title\"\r\n          title=\"{{file.title}}\">{{(file.title?.length>30)?(file.title | slice:0:30) + '...':(file.title)}}</span>\r\n      </h4>\r\n    </div>\r\n    <div class=\"col-md-1 txt-font\">\r\n      {{file.size | number :'.2-2'}}&nbsp;MB\r\n    </div>\r\n    <div class=\"col-md-2 txt-font\">\r\n        {{file.downloads}} &nbsp;Downloads \r\n      </div>\r\n    <div class=\"col-md-5\">\r\n      <div class=\"action-buttons\">\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"addDownloadCount(file)\">\r\n          <a [href]=\"file.file_name\" class=\"btn-ga-white-download\" [download]=\"file.title\">Download</a>\r\n        </button>\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"setRemoveDataFile(file,'delete')\">Delete</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n<ng-template #audioNotesData let-audios let-level=\"level\">\r\n  <div class=\"row singleton-row material-row\" *ngFor=\"let audio of audios\">\r\n    <div class=\"col-md-4 material-title txt-color\" [ngStyle]=\"{'padding-left': level+'em'}\">\r\n      <h4 class=\"file__title\" title=\"{{audio.title}}\">\r\n        <i [class]=\"audio?.extension\" aria-hidden=\"true\"></i>\r\n        <span class=\"txt-title\"\r\n          title=\"{{audio.title}}\">{{(audio.title?.length>30)?(audio.title | slice:0:30) + '...':(audio.title)}}</span>\r\n      </h4>\r\n    </div>\r\n    <div class=\"col-md-1 txt-font\">\r\n      {{audio.size | number :'.2-2'}}&nbsp;MB\r\n    </div>\r\n    <div class=\"col-md-2 txt-font\">\r\n        {{audio.downloads}} &nbsp;Downloads \r\n      </div>\r\n    <div class=\"col-md-5\">\r\n      <div class=\"action-buttons\">\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"addDownloadCount(audio)\">\r\n          <a [href]=\"audio.file_name\" class=\"btn-ga-white\" [download]=\"audio.title\">Download</a>\r\n        </button>\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"setRemoveDataFile(audio,'delete')\">Delete</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n<ng-template #previousYearQuesListData let-previousYearQuesList let-level=\"level\">\r\n  <div class=\"row singleton-row material-row\" *ngFor=\"let file of previousYearQuesList\">\r\n    <div class=\"col-md-4 material-title txt-color\" [ngStyle]=\"{'padding-left': level+'em'}\">\r\n      <h4 class=\"file__title\" title=\"{{file.title}}\">\r\n        <i [class]=\"file?.extension\" aria-hidden=\"true\"></i>\r\n        <span class=\"txt-title\"\r\n          title=\"{{file.title}}\">{{(file.title?.length>30)?(file.title | slice:0:30) + '...':(file.title)}}</span>\r\n      </h4>\r\n    </div>\r\n    <div class=\"col-md-1 txt-font\">\r\n      {{file.size | number :'.2-2'}}&nbsp;MB\r\n    </div>\r\n    <div class=\"col-md-2 txt-font\">\r\n        {{file.downloads}} &nbsp;Downloads \r\n      </div>\r\n    <div class=\"col-md-5\">\r\n      <div class=\"action-buttons\">\r\n        {{file.downloads}}&nbsp;Downloads &nbsp; &nbsp;\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"addDownloadCount(file)\">\r\n          <a [href]=\"file.file_name\" class=\"btn-ga-white-download\" [download]=\"file.title\">Download</a>\r\n        </button>\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"setRemoveDataFile(file,'delete')\">Delete</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n\r\n<ng-template #slidesListData let-slidesList let-level=\"level\">\r\n  <div class=\"row singleton-row material-row\" *ngFor=\"let file of slidesList\">\r\n    <div class=\"col-md-4 material-title txt-color\" [ngStyle]=\"{'padding-left': level+'em'}\">\r\n      <h4 class=\"file__title\" title=\"{{file.title}}\">\r\n        <i [class]=\"file?.extension\" aria-hidden=\"true\"></i>\r\n        <span class=\"txt-title\"\r\n          title=\"{{file.title}}\">{{(file.title?.length>30)?(file.title | slice:0:30) + '...':(file.title)}}</span>\r\n      </h4>\r\n    </div>\r\n    <div class=\"col-md-1 txt-font\">\r\n      {{file.size | number:'.2-2'}}&nbsp;MB\r\n    </div>\r\n    <div class=\"col-md-2 txt-font\">\r\n        {{file.downloads}} &nbsp;Downloads \r\n      </div>\r\n    <div class=\"col-md-5\">\r\n      <div class=\"action-buttons\">\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"addDownloadCount(file)\">\r\n          <a [href]=\"file.file_name\" class=\"btn-ga-white-download\" [download]=\"file.title\">Download</a>\r\n        </button>\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"setRemoveDataFile(file,'delete')\">Delete</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n<ng-template #studyMaterialList let-studyList let-level=\"level\">\r\n  <div class=\"row singleton-row material-row\" *ngFor=\"let file of studyList\">\r\n    <div class=\"col-md-4 material-title txt-color\" [ngStyle]=\"{'padding-left': level+'em'}\">\r\n      <h4 class=\"file__title\" title=\"{{file.title}}\">\r\n        <i [class]=\"file?.extension\" aria-hidden=\"true\"></i>\r\n        <span class=\"txt-title\"\r\n          title=\"{{file.title}}\">{{(file.title?.length>30)?(file.title | slice:0:30) + '...':(file.title)}}</span>\r\n      </h4>\r\n    </div>\r\n    <div class=\"col-md-1 txt-font\">\r\n      {{file.size | number:'.2-2'}}&nbsp;MB\r\n    </div>\r\n    <div class=\"col-md-2 txt-font\">\r\n        {{file.downloads}} &nbsp;Downloads \r\n      </div>\r\n    <div class=\"col-md-5\">\r\n      <div class=\"action-buttons\">\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"addDownloadCount(file)\">\r\n          <a [href]=\"file.file_name\" class=\"btn-ga-white-download\" [download]=\"file.title\">Download</a>\r\n        </button>\r\n        <button class=\"btn btn-xs btn-ga-white\" (click)=\"setRemoveDataFile(file,'delete')\">Delete</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n<div class=\"ga-modal-wrapper\" *ngIf=\"showModal\">\r\n  <div class=\"ga-modal-container\">\r\n    <div class=\"ga-modal\">\r\n      <div class=\"ga-modal-head\" *ngIf=\"type!='unlink all' && type!='unlink'\">\r\n        <span>Do you want to {{type}} this file ?</span>\r\n      </div>\r\n      <div class=\"ga-modal-head\" *ngIf=\"type=='unlink all'\">\r\n        <span>Do you want to {{type}} video(s) ?</span>\r\n      </div>\r\n      <div class=\"ga-modal-head\" *ngIf=\"type=='unlink'\">\r\n        <span>Do you want to {{type}} this video ?</span>\r\n      </div>\r\n      <div class=\"ga-modal-body\">\r\n        <div class=\"row upload-box\">\r\n          <div class=\"col-md-12 file-form\">\r\n            <button class=\"btn btn-xs btn-ga-white btn-border btn-type\" (click)=\"removeData(type)\">{{type|titlecase}}</button>\r\n            <button class=\"btn btn-xs btn-ga-white btn-border\" (click)=\"showModal = false\">Cancel</button>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"ga-modal-wrapper\" [hidden]=\"showVideo\">\r\n  <div class=\"ga-modal-container\">\r\n    <div class=\"ga-modal\" >\r\n      <div class=\"ga-modal-head\" style=\"text-align: left;padding:.5em 1em .5em 1em\" >\r\n        <span>{{tempData.title}}</span>\r\n\r\n\r\n        <div class=\"btn_cross\" > \r\n            <button  class=\"btn btn-xs btn-ga-white\" style=\"position: absolute;right: 0;\" (click)=\"stopVideo()\">X</button>\r\n          </div>\r\n      </div>\r\n      <div class=\"ga-modal-body\">\r\n        <div class=\"row upload-box\">\r\n          <div id=\"embedBox\" style=\"width:700px;max-width:100%;height:auto;\"></div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<app-upload-file></app-upload-file>"

/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/ecourse-subject-list/ecourse-subject-list.component.scss":
/***/ (function(module, exports) {

module.exports = ".scroll_table {\n  height: 80vh;\n  overflow-x: hidden; }\n\n.subject-title {\n  cursor: pointer;\n  font-weight: 900;\n  font-size: 1.4em;\n  margin-bottom: 0.4em; }\n\n.subject-label {\n  cursor: pointer;\n  padding: 0.6em 1em;\n  font-weight: bold;\n  border-radius: 3px;\n  font-size: 0.95em;\n  border: 1pt solid #eee;\n  background-color: #fff;\n  -webkit-box-shadow: 0 1pt 2pt 0 rgba(0, 0, 0, 0.16);\n          box-shadow: 0 1pt 2pt 0 rgba(0, 0, 0, 0.16); }\n\n.subject-label:hover {\n    background-color: #cedff3; }\n\n.subject-label:after {\n    content: '>';\n    position: absolute;\n    right: 19px;\n    top: 25%;\n    width: 21px;\n    height: 21px;\n    z-index: 0;\n    font-size: 1rem; }\n\n#addDiv {\n  text-align: right;\n  position: absolute;\n  right: 0;\n  top: -3rem; }\n\n#addDiv .btn_addecourse {\n    padding: 8px;\n    border-radius: 13px;\n    color: #fff;\n    background: #2680eb;\n    font-weight: 600;\n    font-size: 12px; }\n\n.row {\n  margin: 0; }\n\n.text-red {\n  color: red; }\n\n.text-blue {\n  color: #2680eb; }\n\n.img-color {\n  color: blueviolet; }\n\n.doc-color {\n  color: #3d89f0; }\n\n.assign-color {\n  color: #c59441; }\n\n.btn-ga-white-download {\n  color: #555; }\n\n.txt-notes {\n  color: #3d89f0; }\n\n.audio-color {\n  color: #9968be; }\n\n.pdf-color {\n  color: #d55252; }\n\n.epub-color {\n  color: #2bc38a; }\n\ni.fa {\n  margin-right: .4em;\n  font-size: 12px; }\n\n.txt-color {\n  color: #3f2e2e !important;\n  text-decoration: none; }\n\n.txt-color .txt-title {\n    font-weight: 400;\n    font-size: 12px;\n    display: inline-block;\n    overflow: hidden;\n    width: 72%;\n    text-overflow: ellipsis;\n    line-height: 15px;\n    white-space: nowrap; }\n\n.txt-font {\n  font-size: 12px; }\n\n.btn-ga-collapse {\n  vertical-align: middle;\n  background: transparent; }\n\n.btn-ga-collapse:hover {\n    color: #3f2e2e; }\n\n.btn-ga-white {\n  padding: .2em .8em;\n  height: auto;\n  -webkit-box-shadow: 1pt 1pt 0 #f1f1f1;\n          box-shadow: 1pt 1pt 0 #f1f1f1;\n  color: #555; }\n\n.btn-ga-white:hover {\n    color: #07f; }\n\n.btn-ga-white:focus {\n    outline: none; }\n\n.btn-ga-white:active {\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    color: #fff;\n    background: #0084f6;\n    border: 1px solid #0084f6; }\n\n.btn-xs {\n  font-size: .8em; }\n\n.field-checkbox-wrapper,\n.field-radio-wrapper {\n  position: absolute;\n  margin-left: -0.6em;\n  margin-top: .4em; }\n\n.singleton-row .action-buttons {\n  visibility: hidden; }\n\n.singleton-row:hover {\n  background: #ebf6ff; }\n\n.singleton-row:hover .action-buttons {\n    visibility: visible; }\n\n.material-row,\n.topic-data {\n  padding-left: 1.2em !important; }\n\n.main-topic-row {\n  padding: 0;\n  margin: 1em 0;\n  border: 1pt solid #ddd;\n  background: white; }\n\n.topic-row {\n  padding: 0; }\n\n.topic-data {\n  border-top: 1px solid #eee;\n  padding: .4em 0;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex; }\n\n.topic-data .topic-name {\n    margin: auto; }\n\n.main-topic-data {\n  color: #000;\n  font-weight: bold;\n  padding-left: 0 !important; }\n\n.topic-material-data {\n  padding: 0; }\n\n.topic-material-data .material-row {\n    border-top: 1px solid #eee;\n    padding: .4em 0;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex; }\n\n.topic-material-data .material-row .material-title {\n      margin: auto;\n      width: 32%;\n      display: inline-block;\n      line-height: 15px;\n      padding: 0 7px;\n      word-wrap: break-word; }\n\n.subTopics-data {\n  padding: 0; }\n\n.ga-modal-wrapper {\n  right: 0;\n  position: fixed;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  background: rgba(136, 136, 136, 0.6);\n  z-index: 999; }\n\n.ga-modal-wrapper .ga-modal-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    overflow-y: auto;\n    height: 100%; }\n\n.ga-modal-wrapper .ga-modal-container .ga-modal {\n      margin: auto;\n      background: #fff;\n      border: 2pt solid #fff;\n      border-radius: .2em;\n      -webkit-box-shadow: 0 2pt 3pt #999;\n              box-shadow: 0 2pt 3pt #999;\n      min-width: 30%; }\n\n.ga-modal-wrapper .ga-modal-container .ga-modal .ga-modal-head {\n        padding: .5em 1em;\n        border-bottom: 1pt solid #ddd;\n        font-weight: bold;\n        text-align: center; }\n\n.ga-modal-wrapper .ga-modal-container .ga-modal .ga-modal-body {\n        padding: 1em;\n        text-align: center; }\n\n.black-bg {\n  background: rgba(12, 11, 11, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 6;\n  width: 100%; }\n"

/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/ecourse-subject-list/ecourse-subject-list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EcourseSubjectListComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_http_service__ = __webpack_require__("./src/app/services/http.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__node_modules_angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__core_upload_file_upload_file_component__ = __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/core/upload-file/upload-file.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var EcourseSubjectListComponent = /** @class */ (function () {
    function EcourseSubjectListComponent(_http, auth, route, router, msgService) {
        var _this = this;
        this._http = _http;
        this.auth = auth;
        this.route = route;
        this.router = router;
        this.msgService = msgService;
        this.subjectList = [];
        this.existVideos = [];
        this.isRippleLoad = false;
        this.showModal = false;
        this.showVideo = true;
        this.type = 'delete';
        this.outputMessage = '';
        this.tempData = {};
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.route.params.subscribe(function (params) {
            _this.ecourse_id = params.ecourse_id;
        });
        this.route
            .queryParams
            .subscribe(function (params) {
            var name = window.atob(params['data']);
            if (sessionStorage.getItem('routeListForEcourse')) {
                _this._http.routeList = JSON.parse(sessionStorage.getItem('routeListForEcourse'));
                _this._http.routeList.splice(1, _this._http.routeList.length);
                var obj = { routeLink: '/view/activity/ecourse-file-manager/ecourses/' + _this.ecourse_id + '/subjects', data: { data: params['data'] }, name: name };
                _this._http.routeList.push(obj);
                sessionStorage.setItem('routeListForEcourse', JSON.stringify(_this._http.routeList));
            }
        });
    }
    EcourseSubjectListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.getSubjectList();
        this._http.routeList.splice(2, this._http.routeList.length);
        this._http.updatedDataSelection('subject-list');
        this._http.data.subscribe(function (data) {
            if (data == 'subject') {
                _this.getSubjectList();
                _this._http.updatedDataSelection(null);
            }
        });
    };
    EcourseSubjectListComponent.prototype.uploadPopupOpen = function (topic) {
        // console.log(topic);
        this.uploadFile.showParentTopicModel = (this.uploadFile.showParentTopicModel) ? false : true;
        this.uploadFile.showModal = true;
        this.uploadFile.material_dataShow = true;
        this.uploadFile.material_dataFlag = 'subject-list';
        this.uploadFile.varJson.course_types = this.ecourse_id;
        this.uploadFile.getSubjectsList(this.ecourse_id);
        this.uploadFile.varJson.subject_id = topic.subject_id;
        this.uploadFile.getTopicsList(topic.subject_id);
        if (topic.topic_id && topic.topic_id != '-1') {
            this.uploadTopicPopupOpen(topic);
        }
    };
    // get otp details to show video 
    EcourseSubjectListComponent.prototype.getVdocipherVideoOtp = function (video) {
        var _this = this;
        if (video.category_name == 'VDOCipher') {
            var url = "/api/v1/instFileSystem/videoOTP";
            var data = {
                "videoID": video.videoID,
                "institute_id": sessionStorage.getItem("institute_id"),
                "user_id": sessionStorage.getItem("userid")
            };
            this.tempData = video;
            console.log(video);
            this.isRippleLoad = true;
            this._http.postData(url, data).subscribe(function (response) {
                _this.isRippleLoad = false;
                console.log(response);
                if (response == null) {
                    var obj = {
                        "otp": "20160313versASE323ND0ylfz5VIJXZEVtOIgZO8guUTY5fTa92lZgixRcokG2xm",
                        "playbackInfo": "eyJ2aWRlb0lkIjoiNGQ1YjRiMzA5YjQ5NGUzYTgxOGU1ZDE3NDZiNzU2ODAifQ=="
                    };
                    console.log(obj);
                    _this.ShowVideo(obj.otp, obj.playbackInfo);
                }
                else {
                    var obj = {
                        "otp": response['otp'],
                        "playbackInfo": response['playbackInfo']
                    };
                    console.log(obj);
                    _this.ShowVideo(obj.otp, obj.playbackInfo);
                }
            }, function (err) {
                _this.isRippleLoad = false;
                _this.msgService.showErrorMessage('error', '', err.error.message);
            });
        }
    };
    // vdocipher stop video
    EcourseSubjectListComponent.prototype.stopVideo = function () {
        this.showVideo = true;
        if (this.videoObject) {
            this.videoObject.pause(); // removes video 
        }
    };
    // vdocipher start video
    EcourseSubjectListComponent.prototype.ShowVideo = function (otpString, playbackInfoString) {
        this.showVideo = false;
        var video = new window.VdoPlayer({
            otp: otpString,
            playbackInfo: playbackInfoString,
            theme: "9ae8bbe8dd964ddc9bdb932cca1cb59a",
            container: document.querySelector("#embedBox"),
        });
        this.videoObject = video;
        // video.addEventListener(`mpmlLoad`, (data) => {
        //   video.play();
        // });
        var container = document.querySelector('.embedBox');
    };
    EcourseSubjectListComponent.prototype.uploadTopicPopupOpen = function (topic) {
        // console.log(topic);
        if (topic.parent_topic_id == 0) {
            this.uploadFile.showModal = true;
            this.uploadFile.varJson.topic_id = topic.topic_id; // parent 
            this.uploadFile.getSubtopicList(topic.topic_id);
        }
        else {
            this.uploadFile.showModal = false;
            this.uploadFile.jsonData.mainTopic = topic.topic_name;
            this.uploadFile.varJson.sub_topic_id = topic.parent_topic_id; // topic
            this.uploadFile.varJson.topic_id = topic.topic_id; // parent  
            this.uploadFile.jsonData.parentTopic = topic.parent_topic_name;
        }
    };
    EcourseSubjectListComponent.prototype.getSubjectList = function () {
        var _this = this;
        this.subjectList = [];
        var array = [];
        this.isRippleLoad = true;
        var url = "/api/v1/instFileSystem/subjectMaterials";
        var object = {
            "institute_id": this.institute_id,
            "ecoursesIDArray": [this.ecourse_id],
            "itemTypesArray": []
        };
        this._http.postData(url, object).subscribe(function (res) {
            console.log(res);
            _this.isRippleLoad = false;
            if (res && res.length > 0 && res[0].subjectsList && res[0].subjectsList.length > 0) {
                _this.subjectList = res[0].subjectsList;
                _this.subjectList.forEach(function (element) {
                    if (element && element.subject_id) {
                        element.isExpand = false;
                        _this.addMaterialExtension(element);
                        array.push(element);
                    }
                });
            }
            if (_this.subjectList.length == 0) {
                _this.outputMessage = 'No data found';
            }
            _this.subjectList = array;
        }, function (err) {
            _this.isRippleLoad = false;
        });
    };
    EcourseSubjectListComponent.prototype.toggleObject = function (subject) {
        subject.isExpand = !subject.isExpand;
        if (subject.isExpand) {
            subject.topic_id = subject.topic_id == undefined ? '-1' : subject.topic_id;
            this.getTopicListData(subject.subject_id, subject);
        }
    };
    EcourseSubjectListComponent.prototype.getTopicListData = function (subject_id, subject) {
        var _this = this;
        this.isRippleLoad = true;
        var url = "/api/v1/topic_manager/subject/" + subject_id + "/topicMaterials";
        var data = {
            "institute_id": this.institute_id,
            "parent_topic_id": subject.topic_id,
        };
        this._http.postData(url, data).subscribe(function (res) {
            console.log(res);
            _this.isRippleLoad = false;
            subject.subTopics = res;
            if (subject.subTopics.length == 0) {
                _this.outputMessage = 'No data found';
            }
            else {
                subject.subTopics.forEach(function (element) {
                    element.parent_topic_name = subject.topic_id == '-1' ? null : subject.topic_name;
                    element.subject_id = subject_id;
                    element.isExpand = false;
                    element.subTopics = [];
                    _this.addMaterialExtension(element);
                });
                // console.log(this.subTopics);
            }
        }, function (err) {
            _this.isRippleLoad = false;
        });
    };
    /// removed data
    EcourseSubjectListComponent.prototype.removeData = function (key) {
        if (key != 'unlink all') {
            var data = [this.tempfile.file_id];
            this.deleteFiles(key, data);
        }
        else {
            this.getVDOCipherLinkedDate(key);
        }
    };
    EcourseSubjectListComponent.prototype.deleteFiles = function (key, fileIdArray) {
        var _this = this;
        this.showModal = false;
        this.isRippleLoad = true;
        var url = "/api/v1/instFileSystem/deleteFiles?key=" + key;
        var data = {
            "institute_id": this.institute_id,
            "fileIdArray": fileIdArray
        };
        console.log(data);
        this._http.deleteData(url, data).subscribe(function (res) {
            // console.log(res);
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage('success', '', res.message);
            _this.getSubjectList();
        }, function (err) {
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage('error', '', err.error.message);
        });
    };
    EcourseSubjectListComponent.prototype.getVDOCipherLinkedDate = function (key) {
        var _this = this;
        this.isRippleLoad = true;
        var url = "/api/v1/instFileSystem/VDOCipher/" + this.institute_id;
        this.existVideos = [];
        this._http.getData(url).subscribe(function (res) {
            console.log(res);
            _this.isRippleLoad = false;
            if (res) {
                _this.existVideos = res;
                _this.UnlikeAllVideos();
            }
        }, function (err) {
            _this.isRippleLoad = false;
            _this.existVideos = [];
        });
    };
    EcourseSubjectListComponent.prototype.UnlikeAllVideos = function () {
        var array_ids = [];
        if (this.existVideos && this.existVideos.length) {
            for (var i = 0; i < this.existVideos.length; i++) {
                var object = this.existVideos[i];
                if (object.video_id == this.tempfile.videoID) {
                    object && object.link_video_list && object.link_video_list.forEach(function (video) {
                        array_ids.push(video.file_id);
                    });
                    if (array_ids.length) {
                        this.deleteFiles('unlink', array_ids);
                    }
                    else {
                        this.showModal = false;
                        this.msgService.showErrorMessage('info', '', 'No data found to unlink');
                    }
                }
            }
        }
    };
    EcourseSubjectListComponent.prototype.addDownloadCount = function (file) {
        var _this = this;
        this.isRippleLoad = true;
        var url = "/api/v1/instFileSystem/fileDownloadCount";
        var data = {
            "institute_id": this.institute_id,
            "file_id": file.file_id
        };
        this._http.postData(url, data).subscribe(function (res) {
            // console.log(res);
            _this.isRippleLoad = false;
            file.downloads++;
        }, function (err) {
            _this.isRippleLoad = false;
        });
    };
    EcourseSubjectListComponent.prototype.getToSubjectMaterials = function (subject) {
        this.router.navigate(["/view/activity/ecourse-file-manager/ecourses/" + this.ecourse_id + "/subjects/" + subject.subject_id + "/materials"], { queryParams: { data: window.btoa(subject.subject_name) } });
    };
    EcourseSubjectListComponent.prototype.setRemoveDataFile = function (file, type) {
        this.tempfile = file;
        this.type = type;
        this.showModal = true;
    };
    EcourseSubjectListComponent.prototype.addMaterialExtension = function (object) {
        var keys = ["notesList", "assignmentList", "studyMaterialList", "imageList", "previousYearQuesList", "audioNotesList", "slidesList"];
        keys.forEach(function (key) {
            if (object[key]) {
                object[key].forEach(function (element) {
                    var str = element.file_path;
                    var ext = str.substr(str.lastIndexOf(".") + 1, str.length);
                    switch (ext) {
                        case 'epub': {
                            element.extension = "fa fa-file epub-color";
                            break;
                        }
                        case 'pdf': {
                            element.extension = "fa fa-file-pdf-o pdf-color";
                            break;
                        }
                        case 'docx':
                        case 'doc': {
                            element.extension = "fa fa-book assign-color ";
                            break;
                        }
                        case 'xls':
                        case 'xlsx': {
                            element.extension = "fa fa-file-excel-o assign-color";
                            break;
                        }
                        case 'ppt':
                        case 'pptx': {
                            element.extension = "fa fa-file-powerpoint-o text-blue";
                            break;
                        }
                        case 'mp3':
                        case 'wav':
                        case 'aac':
                        case 'wma': {
                            element.extension = "fa fa-file-audio-o audio-color";
                            break;
                        }
                        case 'jpeg':
                        case 'jpg':
                        case 'png':
                        case 'gif': {
                            element.extension = "fa fa-file-image-o img-color";
                            break;
                        }
                        default: {
                            element.extension = "fa fa-file-o assign-color";
                        }
                    }
                });
            }
        });
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])(__WEBPACK_IMPORTED_MODULE_4__core_upload_file_upload_file_component__["a" /* UploadFileComponent */]),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_4__core_upload_file_upload_file_component__["a" /* UploadFileComponent */])
    ], EcourseSubjectListComponent.prototype, "uploadFile", void 0);
    EcourseSubjectListComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-ecourse-subject-list',
            template: __webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-subject-list/ecourse-subject-list.component.html"),
            styles: [__webpack_require__("./src/app/components/eStore-module/ecourse-file-manager/ecourse-subject-list/ecourse-subject-list.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_http_service__["a" /* HttpService */],
            __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_3__node_modules_angular_router__["ActivatedRoute"],
            __WEBPACK_IMPORTED_MODULE_3__node_modules_angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_5__services_message_show_service__["a" /* MessageShowService */]])
    ], EcourseSubjectListComponent);
    return EcourseSubjectListComponent;
}());



/***/ }),

/***/ "./src/app/components/eStore-module/ecourse-file-manager/file.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FileService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var FileService = /** @class */ (function () {
    function FileService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.storageData = {
            storage_allocated: 10,
            uploaded_size: 1,
            width: 1
        };
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    FileService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */],
            __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], FileService);
    return FileService;
}());



/***/ })

});
//# sourceMappingURL=ecourse-file-manager.module.chunk.js.map