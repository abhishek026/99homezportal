webpackJsonp(["course-class.module"],{

/***/ "./src/app/components/course-module/create-course/course-class/class-add/class-add.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<section class=\"middle-section clearFix\" style=\"padding: 10px 10px;\">\r\n    <div class=\"heading-section\">\r\n        <h1>\r\n            Class Schedule Details\r\n        </h1>\r\n    </div>\r\n  <section class=\"cal-view\">\r\n    <aside class=\"boxPadding15\">\r\n      <!-- ==================================================================================== -->\r\n      <!-- ==================================================================================== -->\r\n      <!-- ========================== Header Section ========================================== -->\r\n      <!-- ==================================================================================== -->\r\n      <!-- ==================================================================================== -->\r\n      <!-- ========================== Body Section ============================================ -->\r\n      <section class=\"schedule-class-box\">\r\n        <!-- ==================================================================================== -->\r\n        <!-- ==================================================================================== -->\r\n        <!-- ========================== Search bar ============================================== -->\r\n        <section class=\"common-search-filter\" style=\"padding:5px 5px 10px 5px\">\r\n          <div class=\"filter-search\">\r\n            <div class=\"filter-box clearFix\">\r\n              <div class=\"row\">\r\n                <div class=\"c-lg-12 c-md-12 c-sm-12\">\r\n                  <div class=\"search-filter-wrapper\" *ngIf=\"isProfessional\">\r\n                    <div class=\"row\">\r\n                      <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': fetchMasterBatchModule.standard_id != '-1'}\">\r\n                          <label for=\"smc\">Select Master Course\r\n                            <span class=\"text-danger\">*</span>\r\n                          </label>\r\n                          <select id=\"smc\" class=\"form-ctrl\" [(ngModel)]=\"fetchMasterBatchModule.standard_id\" (ngModelChange)=\"updateSubjectList($event)\">\r\n                            <option value=\"-1\">Select Standard Name</option>\r\n                            <option [value]=\"std.standard_id\" *ngFor=\"let  std of courseModelStdList\">\r\n                              {{std.standard_name}}\r\n                            </option>\r\n                          </select>\r\n\r\n                        </div>\r\n                      </div>\r\n                      <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': fetchMasterBatchModule.subject_id != '-1'}\">\r\n                          <label for=\"sc\">Select Course\r\n                            <span class=\"text-danger\">*</span>\r\n                          </label>\r\n                          <select id=\"sc\" class=\"form-ctrl\" [(ngModel)]=\"fetchMasterBatchModule.subject_id\" (ngModelChange)=\"filterSubjectBatches($event)\">\r\n                            <option value=\"-1\">Select Subject Name</option>\r\n                            <option [value]=\"subject.subject_id\" *ngFor=\"let subject of courseModelSubList\">\r\n                              {{subject.subject_name}}\r\n                            </option>\r\n                          </select>\r\n                        </div>\r\n                      </div>\r\n                      <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': fetchMasterBatchModule.batch_id != '-1'}\">\r\n                          <label for=\"bn\">Select Batch Name\r\n                            <span class=\"text-danger\">*</span>\r\n                          </label>\r\n                          <select id=\"bn\" class=\"form-ctrl\" [(ngModel)]=\"fetchMasterBatchModule.batch_id\" (ngModelChange)=\"batchUpdated($event)\">\r\n                            <option value=\"-1\">Select Batch Name</option>\r\n                            <option [value]=\"batch.batch_id\" *ngFor=\"let batch of courseModelBatchList\">\r\n                              {{batch.batch_name}}\r\n                            </option>\r\n                          </select>\r\n\r\n                        </div>\r\n                      </div>\r\n                      <div class=\"c-lg-1 c-md-1 c-sm-1\" style=\"margin-top: 15px\">\r\n                        <button class=\"btn fullBlue\" (click)=\"submitMasterBatch()\">Go</button>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"row\" *ngIf=\"isClassFormFilled\" style=\"margin-top:5px;margin-left:0px;font-size: 12px;\">\r\n                      <span>Batch Duration: </span>\r\n                      <span style=\"font-weight: 600;\">{{batchDetails?.batch_start_date}} - </span>\r\n                      <span style=\"font-weight: 600;\">{{batchDetails?.batch_end_date}}</span>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"search-filter-wrapper\" *ngIf=\"!isProfessional\">\r\n                    <div class=\"row\">\r\n                      <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': fetchMasterCourseModule.master_course != '-1'}\">\r\n                          <label for=\"smc\">Select Master Course\r\n                            <span class=\"text-danger\">*</span>\r\n                          </label>\r\n                          <select id=\"smc\" class=\"form-ctrl\" [(ngModel)]=\"fetchMasterCourseModule.master_course\" (ngModelChange)=\"updateCourseList($event)\">\r\n                            <option value=\"-1\">Select Master Course</option>\r\n                            <option [value]=\"master.master_course\" *ngFor=\"let  master of masterCourse\">\r\n                              {{master.master_course}}\r\n                            </option>\r\n                          </select>\r\n\r\n                        </div>\r\n                      </div>\r\n                      <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                        <div class=\"field-wrapper\" [ngClass]=\"{'has-value': fetchMasterCourseModule.course_id != '-1'}\">\r\n                          <label for=\"sc\">Select Course\r\n                            <span class=\"text-danger\">*</span>\r\n                          </label>\r\n                          <select id=\"sc\" class=\"form-ctrl\" [(ngModel)]=\"fetchMasterCourseModule.course_id\" (ngModelChange)=\"onCourseListSelection($event)\">\r\n                            <option value=\"-1\">Select Course</option>\r\n                            <option [value]=\"course.course_id\" *ngFor=\"let course of courseList\">\r\n                              {{course.course_name}}\r\n                            </option>\r\n                          </select>\r\n\r\n                        </div>\r\n                      </div>\r\n                      <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                        <div class=\"field-wrapper  datePickerBox\" [ngClass]=\"{'has-value': (fetchMasterCourseModule.requested_date != 'Invalid date' && fetchMasterCourseModule.requested_date != '' )}\">\r\n                          <label for=\"csd\">Class Schedule Date\r\n                            <!--<span class=\"text-danger\">*</span> -->\r\n                          </label>\r\n                          <input type=\"text\" value=\"\" id=\"csd\" class=\"form-ctrl\" [(ngModel)]=\"fetchMasterCourseModule.requested_date\" readonly=\"true\"\r\n                            name=\"csd\" bsDatepicker>\r\n\r\n                          <!-- <span class=\"date-clear\" name=\"csdc\" (click)=\"fetchMasterCourseModule.requested_date = ''\">clear</span> -->\r\n                        </div>\r\n                      </div>\r\n                      <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                        <input type=\"button\" class=\"fullBlue btn\" style=\"margin-top:5%;\" value=\"Go\" (click)=\"submitMasterCourse()\" id=\"goInp8\">\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"row\" *ngIf=\"courseStartDate\" style=\"margin-top:5px;margin-left:0px;font-size: 12px;\">\r\n                      <span>Course Duration: </span>\r\n                      <span style=\"font-weight: 600;\">{{courseStartDate}} - </span>\r\n                      <span style=\"font-weight: 600;\">{{courseEndDate}}</span>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </section>\r\n        <!-- ==================================================================================== -->\r\n        <!-- ==================================================================================== -->\r\n        <!-- ========================== View Type List/Calendar ================================= -->\r\n        <section class=\"schedule-class\" *ngIf=\"isClassFormFilled\">\r\n          <div class=\"row\">\r\n            <div class=\"c-lg-7 c-sm-7 c-md-7 c-xs-12\">\r\n              <div class=\"schedule-class-left\">\r\n                <label>Schedule Class</label>\r\n              </div>\r\n            </div>\r\n            <div class=\"c-lg-5 c-sm-5 c-md-5 c-xs-12 align-right\">\r\n\r\n              <button class=\"btn\" *ngIf=\"hidePastClass() && !isProfessional && classScheduleArray.length > 0\" (click)=\"sendReminder()\"\r\n                style=\"padding: 5px;\">Send Reminder</button>\r\n\r\n              <!-- <input type=\"button\" value=\"Calendar View fullBlue\" class=\"btn fullBlue\">\r\n                <input type=\"button\" value=\"List View\" class=\"btn \"> -->\r\n            </div>\r\n          </div>\r\n        </section>\r\n        <!-- ==================================================================================== -->\r\n        <!-- ==================================================================================== -->\r\n        <!-- ========================== Account 5 Course Schedule ================================= -->\r\n        <section class=\"\" *ngIf=\"isClassFormFilled && !isProfessional\">\r\n\r\n          <div class=\"table-wrapper tableStyling\">\r\n            <div class=\"table-scroll-wrapper\">\r\n              <div class=\"table table-responsive classScheduleTable\">\r\n                <table class=\"table-main\">\r\n                  <thead>\r\n                    <tr>\r\n                      <th class=\"subj\">\r\n                        Subject\r\n                        <span class=\"text-danger\">*</span>\r\n                      </th>\r\n                      <th>\r\n                        Topic\r\n                        <!--<span class=\"text-danger\">*</span> -->\r\n                      </th>\r\n                      <th>\r\n                        Start Time\r\n                        <span class=\"text-danger\">*</span>\r\n                      </th>\r\n                      <th>\r\n                        End Time\r\n                        <span class=\"text-danger\">*</span>\r\n                      </th>\r\n                      <th>\r\n                        Select Faculty\r\n                        <span class=\"text-danger\">*</span>\r\n                      </th>\r\n                      <th class=\"desc\">\r\n                        Description\r\n                        <span title=\"Special characters not allowed in Description\">\r\n\r\n                          <!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">\r\n                          <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n                            width=\"14px\" height=\"14px\" viewBox=\"0 0 48 48\" enable-background=\"new 0 0 48 48\" xml:space=\"preserve\">\r\n                            <path fill=\"#1385F2\" d=\"M24.067,0c-13.255,0-24,10.746-24,24s10.745,24,24,24c13.252,0,23.997-10.746,23.997-24S37.319,0,24.067,0z\r\n\t M23.779,38.121c-1.035,0.802-2.029,1.208-2.991,1.208c-0.625,0-1.145-0.188-1.549-0.561c-0.402-0.374-0.603-0.847-0.603-1.421\r\n\tc0-0.581,0.188-1.524,0.573-2.845l3.017-10.371c0.482-1.688,0.72-2.752,0.72-3.193c0-0.327-0.117-0.597-0.362-0.818\r\n\tc-0.237-0.216,0.198-0.335-0.208-0.335c-0.345,0-0.376,0.088-1.376,0.263v-0.891l7.237-1.328L23.295,34.07\r\n\tc-0.308,1.091-0.645,1.746-0.645,1.96c0,0.246-0.025,0.443,0.123,0.595c0.144,0.158,0.261,0.232,0.449,0.232\r\n\tc0.251,0,0.509-0.123,0.817-0.374c0.874-0.688,1.756-1.671,2.663-2.96l0.79,0.547C26.439,35.663,25.195,37.016,23.779,38.121z\r\n\t M28.818,12.606c-0.445,0.46-0.987,0.691-1.621,0.691c-0.636,0-1.175-0.231-1.637-0.691c-0.463-0.462-0.69-0.999-0.69-1.637\r\n\tc0-0.638,0.224-1.172,0.68-1.626c0.441-0.448,0.997-0.673,1.646-0.673c0.653,0,1.196,0.225,1.642,0.673\r\n\tc0.438,0.454,0.659,0.988,0.659,1.626C29.498,11.607,29.271,12.144,28.818,12.606z\" />\r\n                          </svg>\r\n\r\n                        </span>\r\n                      </th>\r\n                      <th class=\"room\">\r\n                        Room No.\r\n                      </th>\r\n                      <th class=\"cl-type\">\r\n                        Class Type\r\n                      </th>\r\n                      <th>\r\n                        Repeat\r\n                      </th>\r\n                      <th>\r\n\r\n                      </th>\r\n                    </tr>\r\n                  </thead>\r\n\r\n                  <tbody>\r\n\r\n                    <tr class=\"adder\">\r\n\r\n                      <td class=\"subj\">\r\n                        <div class=\"form-wrapper\" [ngClass]=\"{'has-value' : addClassDetails.subject_id != '-1' && addClassDetails.subject_id != '' }\">\r\n                          <select id=\"subjectSelctionDDN\" class=\"side-form-ctrl\" name=\"row.subject_id\" [(ngModel)]=\"addClassDetails.subject_id\" (ngModelChange)=\"onSubjectSelection($event)\">\r\n                            <option value=\"-1\"> </option>\r\n                            <option *ngFor=\"let opt of subjectListDataSource\" [value]=\"opt.subject_id\">\r\n                              {{opt.subject_name}}\r\n                            </option>\r\n                          </select>\r\n                        </div>\r\n                      </td>\r\n\r\n                      <td class=\"topic\">\r\n                        <div class=\"form-wrapper\" *ngIf=\"addLinkStatus==''\" [ngClass]=\"{'has-value' : addClassDetails.class_desc != '' && addClassDetails.class_desc != null }\">\r\n                          <input type=\"textbox\" class=\"side-form-ctrl topic-link\" name=\"label\" style=\"height: 31px;\" id=\"classDetailsTxt9\" placeholder=\"Link\"\r\n                            readonly (click)=\"topicListing()\">\r\n                          <i class=\"fa fa-link\" aria-hidden=\"true\" (click)=\"topicListing  ()\" style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;position: absolute; top: 10px; right: 15px;\"></i>\r\n                        </div>\r\n                        <div class=\"form-wrapper\" *ngIf=\"addLinkStatus=='linked'\">\r\n                          <input type=\"textbox\" class=\"side-form-ctrl topic-linked\" name=\"label\" style=\"height: 31px;\" id=\"classDetailsTxt9\" placeholder=\"Linked\"\r\n                            readonly (click)=\"topicListing()\">\r\n                          <i class=\"fa fa-link\" aria-hidden=\"true\" (click)=\"topicListing()\" style=\"cursor: pointer;color: #1283f4;font-size: 15px;position: absolute; top: 10px; right: 15px;\"></i>\r\n                        </div>\r\n                      </td>\r\n\r\n                      <td class=\"\">\r\n                        <div class=\"timePickerParent\">\r\n                          <div class=\"form-wrapper\">\r\n                            <select id=\"followuptime\" class=\"side-form-ctrl field-wrapper hourTime\" [(ngModel)]=\"addClassDetails.start_hour\" name=\"followuptime\">\r\n                              <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                                {{time}}\r\n                              </option>\r\n                            </select>\r\n                          </div>\r\n                          <div class=\"form-wrapper\">\r\n                            <select id=\"minute\" class=\"side-form-ctrl fields-wrapper minuteTime\" [(ngModel)]=\"addClassDetails.start_minute\" name=\"minute\">\r\n                              <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                                {{minute}}\r\n                              </option>\r\n                            </select>\r\n                          </div>\r\n                        </div>\r\n                      </td>\r\n\r\n                      <td class=\"\">\r\n                        <div class=\"timePickerParent\">\r\n                          <div class=\"form-wrapper\">\r\n                            <select id=\"followuptime\" class=\"side-form-ctrl field-wrapper hourTime\" [(ngModel)]=\"addClassDetails.end_hour\" name=\"followuptime\">\r\n                              <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                                {{time}}\r\n                              </option>\r\n                            </select>\r\n                          </div>\r\n                          <div class=\"form-wrapper\">\r\n                            <select id=\"minute\" class=\"side-form-ctrl fields-wrapper minuteTime\" [(ngModel)]=\"addClassDetails.end_minute\" name=\"minute\">\r\n                              <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                                {{minute}}\r\n                              </option>\r\n                            </select>\r\n                          </div>\r\n                        </div>\r\n                      </td>\r\n\r\n\r\n                      <td>\r\n                        <div class=\"form-wrapper\" [ngClass]=\"{'has-value' : addClassDetails.teacher_id != '-1' && addClassDetails.teacher_id != '' }\">\r\n                          <select id=\"\" class=\"side-form-ctrl viewClass\" name=\"row.category_id\" [(ngModel)]=\"addClassDetails.teacher_id\" disabled=\"{{userType==3}}\">\r\n                            <option value=\"-1\"></option>\r\n                            <option *ngFor=\"let opt of teacherListDataSource\" [value]=\"opt.teacher_id\">\r\n                              {{opt.teacher_name}}\r\n                            </option>\r\n                          </select>\r\n                        </div>\r\n                      </td>\r\n\r\n                      <td class=\"desc\">\r\n                        <div class=\"form-wrapper\" [ngClass]=\"{'has-value' : addClassDetails.class_desc != '' && addClassDetails.class_desc != null }\">\r\n                          <input type=\"textbox\" class=\"side-form-ctrl viewClass\" name=\"label\" [(ngModel)]=\"addClassDetails.class_desc\" style=\"height: 31px;\"\r\n                            id=\"classDetailsTxt9\">\r\n                        </div>\r\n                      </td>\r\n\r\n                      <td class=\"room\">\r\n                        <div class=\"form-wrapper\" [ngClass]=\"{'has-value' : addClassDetails.room_no != '' && addClassDetails.room_no != null }\">\r\n                          <input type=\"text\" class=\"side-form-ctrl viewClass\" name=\"label\" [(ngModel)]=\"addClassDetails.room_no\" style=\"height: 31px;\"\r\n                            id=\"addClassInp9\">\r\n                        </div>\r\n                      </td>\r\n\r\n                      <td class=\"cl-type\">\r\n                        <div class=\"form-wrapper\" [ngClass]=\"{'has-value' : addClassDetails.custom_class_type != '-1' && addClassDetails.custom_class_type != '' }\">\r\n                          <select id=\"\" class=\"side-form-ctrl\" name=\"row.category_id\" [(ngModel)]=\"addClassDetails.custom_class_type\" style=\"background: transparent;\">\r\n                            <option *ngFor=\"let opt of customListDataSource\">\r\n                              {{opt}}\r\n                            </option>\r\n                          </select>\r\n                        </div>\r\n                      </td>\r\n\r\n                      <!-- Recurrence to be empty by default -->\r\n                      <td>\r\n                      </td>\r\n\r\n                      <td>\r\n                        <button class=\"btn\" (click)=\"addClassSchedule()\">\r\n                          <a id=\"addAnch10\">Add</a>\r\n                        </button>\r\n                      </td>\r\n\r\n                    </tr>\r\n\r\n                    <tr id=\"row{{i}}\" *ngFor=\"let row of classScheduleArray; let i= index ; trackBy : index\">\r\n                      <td class=\"subj\">\r\n                        {{row.subject_name}}\r\n                      </td>\r\n                      <td class=\"topic\" *ngIf=\"row.topics_covered!='0' && row.topics_covered!=''\">\r\n                        <div class=\"form-wrapper\">\r\n                          <input type=\"textbox\" class=\"side-form-ctrl topic-linked\" name=\"label\" style=\"height: 31px;\" id=\"classDetailsTxt9\" placeholder=\"Linked\"\r\n                            readonly (click)=\"topicListingForAlreadyLinkedTopics(row, row.subject_id, row.topics_covered)\">\r\n                          <i class=\"fa fa-link\" aria-hidden=\"true\" (click)=\"topicListingForAlreadyLinkedTopics(row, row.subject_id, row.topics_covered)\"\r\n                            style=\"cursor: pointer;color: #1283f4;font-size: 15px;position: absolute; top: 10px; right: 15px;\"></i>\r\n                        </div>\r\n                      </td>\r\n                      <td class=\"topic\" *ngIf=\"(row.topics_covered=='')||(row.topics_covered=='0')\">\r\n                        <div class=\"form-wrapper\">\r\n                          <input type=\"textbox\" class=\"side-form-ctrl topic-link\" name=\"label\" style=\"height: 31px;\" id=\"classDetailsTxt9\" placeholder=\"Link\"\r\n                            readonly (click)=\"topicListingForAlreadyLinkedTopics(row, row.subject_id, row.topics_covered)\">\r\n                          <i class=\"fa fa-link\" aria-hidden=\"true\" (click)=\"topicListingForAlreadyLinkedTopics(row, row.subject_id, row.topics_covered)\"\r\n                            style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;position: absolute; top: 10px; right: 15px;\"></i>\r\n                        </div>\r\n                      </td>\r\n                      <td>\r\n                        {{row.start_time}}\r\n                      </td>\r\n                      <td>\r\n                        {{row.end_time}}\r\n                      </td>\r\n                      <td>\r\n                        <div class=\"form-wrapper\">\r\n                          <select id=\"\" class=\"side-form-ctrl\" name=\"row.category_id\" style=\"background: transparent\" [(ngModel)]=\"row.teacher_id\" disabled=\"{{userType==3}}\">\r\n                            <option value=\"-1\"></option>\r\n                            <option *ngFor=\"let opt of teacherListDataSource\" [value]=\"opt.teacher_id\">\r\n                              {{opt.teacher_name}}\r\n                            </option>\r\n                          </select>\r\n                        </div>\r\n                      </td>\r\n                      <td class=\"desc\">\r\n                        <div class=\"form-wrapper\">\r\n                          <input type=\"text\" class=\"side-form-ctrl editCellInput\" style=\"background: transparent\" [(ngModel)]=\"row.class_desc\" name=\"label\"\r\n                            id=\"rowInp1\">\r\n                        </div>\r\n                      </td>\r\n                      <td class=\"room\">\r\n                        <div class=\"form-wrapper\">\r\n                          <input type=\"text\" class=\"side-form-ctrl editCellInput\" style=\"background: transparent\" [(ngModel)]=\"row.room_no\" name=\"label\"\r\n                            id=\"rowInp2\">\r\n                        </div>\r\n                      </td>\r\n\r\n                      <td class=\"cl-type\">\r\n                        <div class=\"form-wrapper\">\r\n                          <select id=\"\" class=\"side-form-ctrl\" name=\"row.category_id\" style=\"background: transparent\" [(ngModel)]=\"row.custom_class_type\">\r\n                            <option *ngFor=\"let opt of customListDataSource\" [value]=\"opt\">\r\n                              {{opt}}\r\n                            </option>\r\n                          </select>\r\n                        </div>\r\n                      </td>\r\n\r\n                      <td>\r\n                        <div class=\"form-wrapper\">\r\n                          <select *ngIf=\"(row.class_schedule_id != 0)\" id=\"\" style=\"background: transparent\" class=\"side-form-ctrl\" name=\"row.category_id\"\r\n                            (change)=\"weeklyScheduleChange($event , row)\">\r\n                            <option value=\"1\">Does Not Repeat</option>\r\n                            <option value=\"2\">Select Dates</option>\r\n                            <option value=\"3\">Custom</option>\r\n                          </select>\r\n                        </div>\r\n                      </td>\r\n                      <td>\r\n                        <div class=\"action-box\">\r\n                          <span *ngIf=\"row.class_schedule_id != 0 && row.is_attendance_marked == 'N'\" class=\"reschedule-icon\" title=\"Cancel Class\"\r\n                            (click)=\"cancelCourseClicked(row)\"></span>\r\n                          <span *ngIf=\"row.class_schedule_id == 0\" (click)=\"removeRowFromSchedule(i , row)\" title=\"Delete\" class=\"delete-btn\">\r\n                            <i class=\"fa fa-trash-o\" style=\"font-family: FontAwesome;\" aria-hidden=\"true\"></i>\r\n                          </span>\r\n                          <!-- <span class=\"edit-icon\"></span> -->\r\n                        </div>\r\n                      </td>\r\n                    </tr>\r\n\r\n                  </tbody>\r\n\r\n                  <tbody *ngIf=\"classScheduleArray.length ==0\">\r\n                    <tr>\r\n                      <td colspan=\"10\">\r\n                        No Schedule For Current Date Found\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n\r\n                </table>\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"extraMargin row\" style=\"margin-right: 15px; margin-bottom:10px;\">\r\n            <div class=\"pull-left\">\r\n              <button type=\"button\" class=\"btn\" style=\"margin-left: 0px;\" name=\"button\" routerLink=\"/view/course/coursePlanner/class\" *ngIf=\"coursePlannerStatus=='true'\">Back</button>\r\n            </div>\r\n            <div class=\"pull-right\">\r\n              <button class=\"btn\" routerLink=\"/view/course/create/class/home\" id=\"BtnCancelBtn\">Cancel</button>\r\n              <button class=\"btn fullBlue\" (click)=\"saveCourseSchedule()\" id=\"btnSaveBtn\">Save</button>\r\n            </div>\r\n          </div>\r\n        </section>\r\n\r\n        <!-- ==================================================================================== -->\r\n        <!-- ========================== Account 4 Batch Schedule ================================= -->\r\n        <section class=\"batch-schedule\" *ngIf=\"isClassFormFilled && isProfessional\">\r\n\r\n          <div class=\"filter-Section\">\r\n            <div class=\"row\">\r\n              <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n                <select class=\"side-form-ctrl\" name=\"row.category_id\" (ngModelChange)=\"scheduleSelection($event)\" [(ngModel)]=\"batchFrequency\">\r\n                  <option value=\"1\">Weekly</option>\r\n                  <option value=\"2\">Custom</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"weekly-Schedule\" *ngIf=\"batchFrequency == '1'\">\r\n\r\n            <div class=\"weeklyDiv\">\r\n\r\n              <div class=\"row weeklyAdd\">\r\n                <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                  <div class=\"field-wrapper datePickerBox\" style=\"padding: 0px;\" [ngClass]=\"{'has-value': custom.date!=''}\">\r\n                    <label for=\"csd\">Schedule Date\r\n                      <span class=\"text-danger\">*</span>\r\n                    </label>\r\n                    <input type=\"text\" value=\"\" id=\"csd\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"custom.date\" readonly=\"true\" name=\"csd\"\r\n                      bsDatepicker>\r\n                  </div>\r\n                </div>\r\n                \r\n                <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n                  <div class=\"form-wrapper timepick\">\r\n                    <label for=\"startTime\">Start Time</label>\r\n                    <div class=\"tbox\">\r\n                      <div class=\"times\">\r\n                        <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"mainStartTime.hour\" name=\"startTime\">\r\n                          <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                            {{time}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                      <div class=\"times\">\r\n                        <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"mainStartTime.minute\" name=\"minute\">\r\n                          <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                            {{minute}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"c-sm-2 c-md-2 c-lg-2\">\r\n                  <div class=\"form-wrapper timepick\">\r\n                    <label for=\"startTime\">End Time</label>\r\n                    <div class=\"tbox\">\r\n                      <div class=\"times\">\r\n                        <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"mainEndTime.hour\" name=\"startTime\">\r\n                          <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                            {{time}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                      <div class=\"times\">\r\n                        <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"mainEndTime.minute\" name=\"minute\">\r\n                          <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                            {{minute}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"pull-right btnGroup\">\r\n                  <button class=\"btn fullBlue\" (click)=\"applyButtonClick()\">Apply</button>\r\n                  <button class=\"btn fullBlue\" *ngIf=\"showCancelWeeklyBtn\" (click)=\"cancelWeeklyScheduledClass()\">Cancel Weekly Scheduled Class</button>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"table-scroll-wrapper\">\r\n                <div class=\"table-responsive \">\r\n                  <table>\r\n                    <thead>\r\n                      <tr>\r\n                        <th>\r\n                          Week Days\r\n                        </th>\r\n                        <th>\r\n                          Start Time\r\n                        </th>\r\n                        <th>\r\n                          End Time\r\n                        </th>\r\n                      </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                      <tr *ngFor=\"let row of weekDaysTable; let i=index ; trackBy : index \">\r\n                        <td>\r\n                          <div class=\"field-checkbox-wrapper\">\r\n\r\n                            <input type=\"checkbox\" name=\"chk\" name=\"checkbx\" id=\"checkbx{{i}}\" [(ngModel)]=\"row.uiSelected\" class=\"form-checkbox\">\r\n                            <label for=\"checkbx{{i}}\">\r\n                              {{row.data_value}}\r\n                            </label>\r\n                          </div>\r\n                        </td>\r\n                        <td>\r\n                          <div class=\"form-wrapper timepick\">\r\n                            <div class=\"tbox\">\r\n                              <div class=\"times\">\r\n                                <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"row.start_time.hour\" name=\"startTime\">\r\n                                  <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                                    {{time}}\r\n                                  </option>\r\n                                </select>\r\n                              </div>\r\n                              <div class=\"times\">\r\n                                <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"row.start_time.minute\" name=\"minute\">\r\n                                  <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                                    {{minute}}\r\n                                  </option>\r\n                                </select>\r\n                              </div>\r\n                            </div>\r\n                          </div>\r\n                        </td>\r\n                        <td>\r\n                          <div class=\"form-wrapper timepick\">\r\n                            <div class=\"tbox\">\r\n                              <div class=\"times\">\r\n                                <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"row.end_time.hour\" name=\"startTime\">\r\n                                  <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                                    {{time}}\r\n                                  </option>\r\n                                </select>\r\n                              </div>\r\n                              <div class=\"times\">\r\n                                <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"row.end_time.minute\" name=\"minute\">\r\n                                  <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                                    {{minute}}\r\n                                  </option>\r\n                                </select>\r\n                              </div>\r\n                            </div>\r\n                          </div>\r\n                        </td>\r\n                      </tr>\r\n                      <tr *ngIf=\"weekDaysTable.length == 0\">\r\n                        <td colspan=\"3\" style=\"text-align: center\">\r\n                          No Schedule Of Week Found\r\n                        </td>\r\n                      </tr>\r\n                    </tbody>\r\n                  </table>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"row btn-table\" style=\"margin: 10px 0px;\">\r\n                <div class=\"pull-left\">\r\n                  <button type=\"button\" class=\"btn\" style=\"margin-left: 0px;\" name=\"button\" routerLink=\"/view/course/coursePlanner/class\" *ngIf=\"coursePlannerStatus=='true'\">Back </button>\r\n                </div>\r\n                <div class=\"pull-right\">\r\n                  <button class=\"btn fullBlue \" [disabled]=\"isRippleLoad\" (click)=\"updateWeeklySchedule()\">Update </button>\r\n                </div>\r\n              </div>\r\n\r\n            </div>\r\n\r\n          </div>\r\n\r\n          <div class=\"custom-Schedule\" *ngIf=\"batchFrequency == '2'\">\r\n\r\n            <div class=\"row adderCustom\">\r\n              <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                <div class=\"field-wrapper datePickerBox\" [ngClass]=\"{'has-value': custom.date!=''}\">\r\n                  <label for=\"csd\">Date\r\n                    <span class=\"text-danger\">*</span>\r\n                  </label>\r\n                  <input type=\"text\" value=\"\" id=\"csd\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"custom.date\" readonly=\"true\" name=\"csd\"\r\n                    bsDatepicker>\r\n\r\n                </div>\r\n              </div>\r\n              <div class=\"c-lg-2 c-md-2 c-sm-2\" style=\"margin-top: 10px;padding: 0;width: 10%;\">\r\n                <label>\r\n                  <span class=\"topic-lbl\">Topic</span></label><br>\r\n                 <div class=\"form-wrapper\" style=\"margin:0px !important;border:1px solid #0084f6\" *ngIf=\"selectedTopicsListObj.length\">\r\n                  <input type=\"textbox\" class=\"side-form-ctrl topic-link\" name=\"label\" style=\"height: 30px;color:#0084f6\" id=\"classDetailsTxt9\" placeholder=\"Linked\"\r\n                    readonly (click)=\"fetchSelectedTopics()\">\r\n                  <i class=\"fa fa-link\" aria-hidden=\"true\" (click)=\"fetchSelectedTopics()\"  style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;position: absolute; top: 8px; right: 15px;color: #0084f6\"></i>\r\n                </div>\r\n                <div class=\"form-wrapper\" style=\"margin:0px !important;border:1px solid rgba(119, 119, 119, 0);\" *ngIf=\"!selectedTopicsListObj.length\">\r\n                  <input type=\"textbox\" class=\"side-form-ctrl topic-link\" name=\"label\" style=\"height: 30px;\" id=\"classDetailsTxt9\" placeholder=\"Link\"\r\n                    readonly (click)=\"fetchTopics()\">\r\n                  <i class=\"fa fa-link\" aria-hidden=\"true\" (click)=\"fetchTopics()\"  style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;position: absolute; top: 8px; right: 15px;\"></i>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-sm-2 c-md-2 c-lg-2\" style=\"margin-top: 10px\">\r\n                <div class=\"form-wrapper timepick\">\r\n                  <label for=\"startTime\">Start Time</label>\r\n                  <div class=\"tbox\">\r\n                    <div class=\"times\">\r\n                      <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"custom.start_hour\" name=\"startTime\">\r\n                        <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                          {{time}}\r\n                        </option>\r\n                      </select>\r\n                    </div>\r\n                    <div class=\"times\">\r\n                      <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"custom.start_minute\" name=\"minute\">\r\n                        <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                          {{minute}}\r\n                        </option>\r\n                      </select>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-sm-2 c-md-2 c-lg-2\" style=\"margin-top: 10px\">\r\n                <div class=\"form-wrapper timepick\">\r\n                  <label for=\"startTime\">End Time</label>\r\n                  <div class=\"tbox\">\r\n                    <div class=\"times\">\r\n                      <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"custom.end_hour\" name=\"startTime\">\r\n                        <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                          {{time}}\r\n                        </option>\r\n                      </select>\r\n                    </div>\r\n                    <div class=\"times\">\r\n                      <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"custom.end_minute\" name=\"minute\">\r\n                        <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                          {{minute}}\r\n                        </option>\r\n                      </select>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                <div class=\"field-wrapper\" [ngClass]=\"{'has-value' : custom.desc != ''}\">\r\n                  <label for=\"customDescTxt\">Description\r\n                    <span title=\"Special characters not allowed in Description\">\r\n\r\n                      <!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">\r\n                      <svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n                        width=\"14px\" height=\"14px\" viewBox=\"0 0 48 48\" enable-background=\"new 0 0 48 48\" xml:space=\"preserve\">\r\n                        <path fill=\"#1385F2\" d=\"M24.067,0c-13.255,0-24,10.746-24,24s10.745,24,24,24c13.252,0,23.997-10.746,23.997-24S37.319,0,24.067,0z\r\nM23.779,38.121c-1.035,0.802-2.029,1.208-2.991,1.208c-0.625,0-1.145-0.188-1.549-0.561c-0.402-0.374-0.603-0.847-0.603-1.421\r\nc0-0.581,0.188-1.524,0.573-2.845l3.017-10.371c0.482-1.688,0.72-2.752,0.72-3.193c0-0.327-0.117-0.597-0.362-0.818\r\nc-0.237-0.216,0.198-0.335-0.208-0.335c-0.345,0-0.376,0.088-1.376,0.263v-0.891l7.237-1.328L23.295,34.07\r\nc-0.308,1.091-0.645,1.746-0.645,1.96c0,0.246-0.025,0.443,0.123,0.595c0.144,0.158,0.261,0.232,0.449,0.232\r\nc0.251,0,0.509-0.123,0.817-0.374c0.874-0.688,1.756-1.671,2.663-2.96l0.79,0.547C26.439,35.663,25.195,37.016,23.779,38.121z\r\nM28.818,12.606c-0.445,0.46-0.987,0.691-1.621,0.691c-0.636,0-1.175-0.231-1.637-0.691c-0.463-0.462-0.69-0.999-0.69-1.637\r\nc0-0.638,0.224-1.172,0.68-1.626c0.441-0.448,0.997-0.673,1.646-0.673c0.653,0,1.196,0.225,1.642,0.673\r\nc0.438,0.454,0.659,0.988,0.659,1.626C29.498,11.607,29.271,12.144,28.818,12.606z\" />\r\n                      </svg>\r\n\r\n                    </span>\r\n                  </label>\r\n                  <textarea class=\"form-ctrl\" [(ngModel)]=\"custom.desc\" id=\"customDescTxt\" name=\"customDescTxt\"></textarea>\r\n\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"\" style=\"margin-top: 25px\">\r\n                <button class=\"btn fullBlue\" (click)=\"addNewCustomClass()\">Add</button>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"table-scroll-wrapper\">\r\n              <div class=\"table-responsive\">\r\n                <table>\r\n                  <thead>\r\n                    <tr>\r\n                      <th>\r\n                        Date\r\n                      </th>\r\n                      <th>\r\n                        Topics\r\n                      </th>  \r\n                      <th>\r\n                        Start Time\r\n                      </th>\r\n                      <th>\r\n                        End Time\r\n                      </th>\r\n                      <th>\r\n                        Class Description\r\n                      </th>\r\n                      <th>\r\n                        Action\r\n                      </th>\r\n                    </tr>\r\n                  </thead>\r\n                  <tbody>\r\n                    <tr *ngFor=\"let row of customTable; let i=index ; trackBy : index\">\r\n                      <td>\r\n                        {{row.class_date}}\r\n                      </td>\r\n                       <td>\r\n                         \r\n                        <input type=\"textbox\" class=\"side-form-ctrl topic-link\" *ngIf=\"row.topics_covered != '' && row.topics_covered != null\" name=\"label\" style=\"height: 30px;border:1px solid blue;text-align:center;cursor:pointer\" id=\"classDetailsTxt9\" placeholder=\"Linked\"\r\n                        readonly (click)=\"editTopics(row)\" />\r\n                        <i class=\"fa fa-link\" (click)=\"editTopics(row)\" *ngIf=\"row.topics_covered != '' && row.topics_covered != null\" style=\"cursor: pointer;font-size: 15px;margin-left: -30px;margin-top:6px;color:#0084f6\"></i>\r\n\r\n                        <input type=\"textbox\" class=\"side-form-ctrl topic-link\" *ngIf=\"row.topics_covered == '' || row.topics_covered == null\" name=\"label\" style=\"height: 30px;cursor:pointer;text-align:center;border:1px solid lightgrey\" id=\"classDetailsTxt9\" placeholder=\"Link\"\r\n                        readonly (click)=\"editTopics(row)\"/>\r\n                        <i class=\"fa fa-link\" (click)=\"editTopics(row)\" *ngIf=\"row.topics_covered == '' || row.topics_covered == null\" style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;margin-left: -30px;margin-top:6px\"></i>\r\n                         \r\n                       </td>                      \r\n                      <td>\r\n                        {{row.start_time}}\r\n                      </td>\r\n                      <td>\r\n                        {{row.end_time}}\r\n                      </td>\r\n                      <td>\r\n                        {{row.note}}\r\n                      </td>\r\n                      <td>\r\n                        <a *ngIf=\"checkCurrentDate(row,row.class_date) || row.schd_id == 0\" style=\"cursor:pointer; margin-right: 5px\" (click)=\"deleteFromCustomTable(row , i)\"\r\n                          id=\"deleteAnch1\">Delete</a>\r\n                        <a style=\"cursor:pointer; margin-right: 5px\" *ngIf=\"row.schd_id !='0' && row.is_attendance_marked=='N' && checkNotifyDate(row)\" (click)=\"notifyOfCustomClass(row , index)\"\r\n                          id=\"notifyAnch2\">  Notify</a>\r\n                        <a style=\"cursor:pointer;\" *ngIf=\"row.schd_id !='0' && row.is_attendance_marked=='N'\" (click)=\"cancelClassOfCustomClass(row , index)\"\r\n                          id=\"cancelAnch3\">Cancel Class</a>\r\n                      </td>\r\n                    </tr>\r\n                    <tr *ngIf=\"customTable.length == 0\">\r\n                      <td colspan=\"5\">\r\n                        No Custom Schedule Found\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                </table>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"row\" style=\"margin: 10px 0px;\">\r\n              <div class=\"pull-left\">\r\n                <button type=\"button\" class=\"btn\" style=\"margin-left: 0px;\" name=\"button\" routerLink=\"/view/course/coursePlanner/class\" *ngIf=\"coursePlannerStatus=='true'\">Back</button>\r\n              </div>\r\n              <div class=\"pull-right\">\r\n                <button class=\"btn fullBlue\" style=\"margin-right: 15px\" [disabled]=\"isRippleLoad\" (click)=\"updateCustomClass()\"> Update</button>\r\n              </div>\r\n            </div>\r\n\r\n          </div>\r\n\r\n          <div class=\"common-section\" >\r\n\r\n            <div class=\"divExtraClass\" *ngIf=\"batchFrequency == '1'\">\r\n\r\n              <h4>Extra Class</h4>\r\n\r\n              <div class=\"row adder-Row\">\r\n\r\n                <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                  <div class=\"field-wrapper datePickerBox has-value\">\r\n                    <label for=\"csd\">Date\r\n                      <span class=\"text-danger\">*</span>\r\n                    </label>\r\n                    <input type=\"text\" value=\"\" id=\"csd\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"addExtraClass.date\" readonly=\"true\" name=\"csd\"\r\n                      bsDatepicker>\r\n\r\n                  </div>\r\n                </div>\r\n                <div class=\"c-lg-2 c-md-2 c-sm-2\" style=\"margin-top: 10px;padding: 0;width: 10%;\">\r\n                  <label>\r\n                    <span class=\"topic-lbl\">Topic</span></label><br>\r\n                   <div class=\"form-wrapper\" style=\"margin:0px !important;border:1px solid #0084f6\" *ngIf=\"selectedTopicsListObj.length\">\r\n                    <input type=\"textbox\" class=\"side-form-ctrl topic-link\" name=\"label\" style=\"height: 30px;color:#0084f6\" id=\"classDetailsTxt9\" placeholder=\"Linked\"\r\n                      readonly (click)=\"fetchSelectedTopics()\">\r\n                    <i class=\"fa fa-link\" aria-hidden=\"true\" (click)=\"fetchSelectedTopics()\"  style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;position: absolute; top: 8px; right: 15px;color: #0084f6\"></i>\r\n                  </div>\r\n                  <div class=\"form-wrapper\" style=\"margin:0px !important;border:1px solid rgba(119, 119, 119, 0);\" *ngIf=\"!selectedTopicsListObj.length\">\r\n                    <input type=\"textbox\" class=\"side-form-ctrl topic-link\" name=\"label\" style=\"height: 30px;\" id=\"classDetailsTxt9\" placeholder=\"Link\"\r\n                      readonly (click)=\"fetchTopics()\">\r\n                    <i class=\"fa fa-link\" aria-hidden=\"true\" (click)=\"fetchTopics()\"  style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;position: absolute; top: 8px; right: 15px;\"></i>\r\n                  </div>\r\n                </div>\r\n\r\n                <div class=\"c-sm-2 c-md-2 c-lg-2\" style=\"margin-top: 10px\">\r\n                  <div class=\"form-wrapper timepick\">\r\n                    <label for=\"startTime\">Start Time</label>\r\n                    <div class=\"tbox\">\r\n                      <div class=\"times\">\r\n                        <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"addExtraClass.start_hour\" name=\"startTime\">\r\n                          <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                            {{time}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                      <div class=\"times\">\r\n                        <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"addExtraClass.start_minute\" name=\"minute\">\r\n                          <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                            {{minute}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n\r\n                <div class=\"c-sm-2 c-md-2 c-lg-2\" style=\"margin-top: 10px\">\r\n                  <div class=\"form-wrapper timepick\">\r\n                    <label for=\"startTime\">End Time</label>\r\n                    <div class=\"tbox\">\r\n                      <div class=\"times\">\r\n                        <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"addExtraClass.end_hour\" name=\"startTime\">\r\n                          <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                            {{time}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                      <div class=\"times\">\r\n                        <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"addExtraClass.end_minute\" name=\"minute\">\r\n                          <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                            {{minute}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n\r\n                <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                  <div class=\"field-wrapper\" [ngClass]=\"{'has-value':addExtraClass.desc != ''}\">\r\n                    <label for=\"divDesc\">Class Description</label>\r\n                    <textarea class=\"form-ctrl textBox\" id=\"divDesc\" name=\"desc\" [(ngModel)]=\"addExtraClass.desc\"></textarea>\r\n\r\n                  </div>\r\n                </div>\r\n\r\n                <div style=\"padding-top: 25px\">\r\n                  <button class=\"btn fullBlue\" (click)=\"addNewExtraClass()\">Add</button>\r\n                </div>\r\n\r\n              </div>\r\n\r\n              <div class=\"extraClass\">\r\n                <div class=\"table-scroll-wrapper\">\r\n                  <div class=\"table-responsive\">\r\n                    <table>\r\n                      <thead>\r\n                        <tr>\r\n                          <th>\r\n                            Date\r\n                          </th>\r\n                          <th>\r\n                            Topics\r\n                          </th>\r\n                          <th>\r\n                            Start Time\r\n                          </th>\r\n                          <th>\r\n                            End Time\r\n                          </th>\r\n                          <th>\r\n                            Class Description\r\n                          </th>\r\n                          <th>\r\n                            Action\r\n                          </th>\r\n                        </tr>\r\n                      </thead>\r\n                      <tbody>\r\n                        <tr *ngFor=\"let row of extraClassTable; let i=index ; trackBy : index\">\r\n                          <td>\r\n                            {{row.class_date}}\r\n                          </td>\r\n                          <td>\r\n                         \r\n                            <input type=\"textbox\" class=\"side-form-ctrl topic-link\" *ngIf=\"row.topics_covered != '' && row.topics_covered != null\" name=\"label\" style=\"height: 30px;border:1px solid blue;text-align:center;cursor:pointer\" id=\"classDetailsTxt9\" placeholder=\"Linked\"\r\n                            readonly (click)=\"editTopics(row)\" />\r\n                            <i class=\"fa fa-link\" (click)=\"editTopics(row)\" *ngIf=\"row.topics_covered != '' && row.topics_covered != null\" style=\"cursor: pointer;font-size: 15px;margin-left: -30px;margin-top:6px;color:#0084f6\"></i>\r\n    \r\n                            <input type=\"textbox\" class=\"side-form-ctrl topic-link\" *ngIf=\"row.topics_covered == '' || row.topics_covered == null\" name=\"label\" style=\"height: 30px;cursor:pointer;text-align:center;border:1px solid lightgrey\" id=\"classDetailsTxt9\" placeholder=\"Link\"\r\n                            readonly (click)=\"editTopics(row)\"/>\r\n                            <i class=\"fa fa-link\" (click)=\"editTopics(row)\" *ngIf=\"row.topics_covered == '' || row.topics_covered == null\" style=\"cursor: pointer;color: #bdbdbd;font-size: 15px;margin-left: -30px;margin-top:6px\"></i>\r\n                             \r\n                           </td>\r\n                          <td>\r\n                            {{row.start_time}}\r\n                          </td>\r\n                          <td>\r\n                            {{row.end_time}}\r\n                          </td>\r\n                          <td>\r\n                            {{row.note}}\r\n                          </td>\r\n                          <td>\r\n                            <a style=\"cursor:pointer;margin-right: 5px\" *ngIf=\"row.schd_id != '0' && row.is_attendance_marked=='N'\" (click)=\"cancelExtraClassSchedule(row)\"\r\n                              id=\"cancelAnch4\">Cancel</a>\r\n                            <a style=\"cursor:pointer;margin-right: 5px\" *ngIf=\"row.schd_id != '0' && row.is_attendance_marked=='N'\" (click)=\"notifyExtraClassSchedule(row)\"\r\n                              id=\"notifyAnch5\"> Notify</a>\r\n                            <a *ngIf=\"checkCurrentDate(row,row.class_date) || row.schd_id == '0'\" style=\"cursor:pointer\" (click)=\"deleteExtraClassSchedule(row , i)\" id=\"deleteAnch6\">Delete</a>\r\n                          </td>\r\n                        </tr>\r\n                        <tr *ngIf=\"extraClassTable.length == 0\">\r\n                          <td colspan=\"5\" style=\"text-align: center\">\r\n                            No Extra Class Schedule Found\r\n                          </td>\r\n                        </tr>\r\n                      </tbody>\r\n                    </table>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"row btn-table\">\r\n                <button class=\"btn fullBlue pull-right\" style=\"margin-right: 10px\" [disabled]=\"isRippleLoad\" (click)=\"updateExtraClass()\">Update</button>\r\n              </div>\r\n\r\n            </div>\r\n\r\n            <div class=\"divCancelClass\">\r\n              <h4>Cancelled Class</h4>\r\n\r\n              <div class=\"table-scroll-wrapper cancelTable\">\r\n                <div class=\"table table-responsive\">\r\n                  <table>\r\n                    <thead>\r\n                      <tr>\r\n                        <th>\r\n                          Date\r\n                        </th>\r\n                        <th>\r\n                          Start Time\r\n                        </th>\r\n                        <th>\r\n                          End Time\r\n                        </th>\r\n                        <th>\r\n                          Cancel Reason\r\n                        </th>\r\n                        <th>\r\n                          Action\r\n                        </th>\r\n                      </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                      <tr *ngFor=\"let row of canceLClassTable; let i=index ; trackBy : index\">\r\n                        <td>\r\n                          {{row.class_date}}\r\n                        </td>\r\n                        <td>\r\n                          {{row.start_time}}\r\n                        </td>\r\n                        <td>\r\n                          {{row.end_time}}\r\n                        </td>\r\n                        <td>\r\n                          {{row.cancel_note}}\r\n                        </td>\r\n                        <td>\r\n                          <!-- <a style=\"cursor:pointer;margin-right: 5px\" (click)=\"notifyOfCancelClass(row)\" id=\"notifyAnch7\"> Notify</a> -->\r\n                          <span>Last Notified</span> {{row.last_notify_sent_time}}\r\n                        </td>\r\n                      </tr>\r\n                      <tr *ngIf=\"canceLClassTable.length == 0\">\r\n                        <td colspan=\"5\" style=\"text-align: center\">\r\n                          No Cancelled Class Schedule Found\r\n                        </td>\r\n                      </tr>\r\n                    </tbody>\r\n                  </table>\r\n                </div>\r\n              </div>\r\n\r\n            </div>\r\n\r\n          </div>\r\n\r\n\r\n        </section>\r\n\r\n\r\n      </section>\r\n      <!-- ==================================================================================== -->\r\n      <!-- ==================================================================================== -->\r\n    </aside>\r\n  </section>\r\n</section>\r\n\r\n\r\n\r\n<!-- //////////////////////////////////POPUP///////////////////////////////// -->\r\n<!-- //////////////////////////////////POPUP///////////////////////////////// -->\r\n<!-- //////////////////////////////////POPUP///////////////////////////////// -->\r\n<!-- //////////////////////////////////POPUP///////////////////////////////// -->\r\n<!-- //////////////////////////////////POPUP///////////////////////////////// -->\r\n\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"showPopUpRecurence\">\r\n  <div class=\"popup pos-abs popup-body-container\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closePopup()\">\r\n        <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\"\r\n          width=\"24px\" x=\"0\" y=\"0\">\r\n          <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\"\r\n            style=\"fill: currentColor\"></path>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content\">\r\n        <h2 style=\"margin-left: 10px\">Custom Recurrence for class {{selctedScheduledClass.subject_name}}</h2>\r\n\r\n        <div class=\"row extraMargin\">\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n            <div class=\"form-wrapper timepick\">\r\n              <label for=\"startTime\">Start Time</label>\r\n              <div class=\"tbox\">\r\n                <div class=\"times \">\r\n                  <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"weeklyCommonStartTime.hour\" name=\"startTime\">\r\n                    <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                      {{time}}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n                <div class=\"times\">\r\n                  <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"weeklyCommonStartTime.minute\" name=\"minute\">\r\n                    <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                      {{minute}}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n            <div class=\"form-wrapper timepick\">\r\n              <label for=\"startTime\">End Time</label>\r\n              <div class=\"tbox\">\r\n                <div class=\"times \">\r\n                  <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"weeklyCommonEndTime.hour\" name=\"startTime\">\r\n                    <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                      {{time}}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n                <div class=\"times\">\r\n                  <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"weeklyCommonEndTime.minute\" name=\"minute\">\r\n                    <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                      {{minute}}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n            <button type=\"button\" class=\"btn fullBlue\" style=\"margin-top: 15px;\" name=\"button\" (click)=\"applyTimeForAll()\">Apply</button>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"weekly-schedule-table-container\">\r\n          <div class=\"table-heading-container\">\r\n            <div class=\"heading-item\">\r\n              <span>Week Days</span>\r\n            </div>\r\n            <div class=\"heading-item\">\r\n              <span>Start Time</span>\r\n            </div>\r\n            <div class=\"heading-item\">\r\n              <span>End Time</span>\r\n            </div>\r\n          </div>\r\n          <div class=\"table-outer-container\">\r\n            <div class=\"table-value-container\" *ngFor=\"let day of weekDaysList\">\r\n              <div class=\"value-item\">\r\n                <div class=\"field-checkbox-wrapper\" style=\"margin-top: 5px\">\r\n                  <input type=\"checkbox\" value=\"\" [(ngModel)]=\"day.uiSelected\" class=\"form-checkbox\" id=\"{{day.data_key}}\">\r\n                  <label for=\"{{day.data_key}}\">{{day.data_value}}</label>\r\n                </div>\r\n              </div>\r\n              <div class=\"value-item\">\r\n                <div class=\"tbox\">\r\n                  <div class=\"times \">\r\n                    <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"day.start_time.hour\" name=\"startTime\">\r\n                      <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                        {{time}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                  <div class=\"times\">\r\n                    <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"day.start_time.minute\" name=\"minute\">\r\n                      <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                        {{minute}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"value-item\">\r\n                <div class=\"tbox\">\r\n                  <div class=\"times \">\r\n                    <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"day.end_time.hour\" name=\"startTime\">\r\n                      <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                        {{time}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                  <div class=\"times\">\r\n                    <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"day.end_time.minute\" name=\"minute\">\r\n                      <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                        {{minute}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n        </div>\r\n\r\n        <!-- <div class=\"row extraMargin \">\r\n          <h3>Ends</h3>\r\n        </div> -->\r\n\r\n        <!-- <div class=\"row extraMargin \">\r\n\r\n          <div class=\"radio-options \">\r\n            <div class=\"row extraMargin \">\r\n              <div class=\"field-radio-wrapper c-sm-6 c-md-6 c-lg-6 \">\r\n                <input type=\"radio \" name=\"sFilter \" class=\"form-radio \" (click)=\"radioButtonClick($event) \" value=\"false\r\n                    \" id=\"idCourseEndDate \">\r\n                <label for=\"active \">Course End Date</label>\r\n              </div>\r\n              <div class=\"field-wrapper datePickerBox c-sm-3 c-md-3 c-lg-3 \" [ngClass]=\"{ 'disabled': customRec.radioEndDate.radioEndDateSelection==false } \">\r\n                <input type=\"text \" value=\" \" readonly=\"true \" [(ngModel)]=\"customRec.radioEndDate.radioDate \" class=\"form-ctrl\r\n                    bsDatepicker \" name=\"endDate \" bsDatepicker>\r\n              </div>\r\n            </div>\r\n            <div class=\"row extraMargin \">\r\n              <div class=\"field-radio-wrapper c-sm-6 c-md-6 c-lg-6 \">\r\n                <input type=\"radio \" name=\"sFilter \" class=\"form-radio \" value=\"false \" (click)=\"radioButtonClick($event)\r\n                    \" id=\"idOn \">\r\n                <label for=\"active \">On</label>\r\n              </div>\r\n              <div class=\"c-sm-3 c-md-3 c-lg-3 \" [ngClass]=\"{ 'disabled': customRec.radioOn.radioONSelection==false } \">\r\n                <div class=\"field-wrapper datePickerBox \">\r\n                  <input type=\"text \" value=\" \" readonly=\"true \" [(ngModel)]=\"customRec.radioOn.radioOnDate \" class=\"form-ctrl\r\n                    bsDatepicker \" name=\"endDate \" bsDatepicker>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"row extraMargin \">\r\n              <div class=\"field-radio-wrapper c-sm-6 c-md-6 c-lg-6 \">\r\n                <input type=\"radio \" name=\"sFilter \" class=\"form-radio \" (click)=\"radioButtonClick($event) \" value=\"false\r\n                    \" id=\"idAfter \">\r\n                <label for=\"active \">After</label>\r\n              </div>\r\n              <div class=\"field-wrapper c-sm-3 c-md-3 c-lg-3 \">\r\n                <input type=\"number \" [readonly]=\"customRec.radioAfter.radioAfterSelection==false\" #idSlot class=\"form-ctrl\r\n                    halfwidth \" name=\"slotNew \" [(ngModel)]=\"customRec.radioAfter.occurenceValue \">\r\n              </div>\r\n              <span>occurrences</span>\r\n            </div>\r\n          </div>\r\n        </div> -->\r\n\r\n        <div class=\"row extraMargin\" style=\"margin:10px 15px;\">\r\n          <aside class=\"pull-left\">\r\n            <span>This selection will add future classes till course end date.</span>\r\n          </aside>\r\n          <aside class=\"pull-right\" style=\"margin-right: 15px\">\r\n            <button class=\"btn\" (click)=\"closePopup()\">Cancel</button>\r\n            <button class=\"btn fullBlue\" (click)=\"saveCustomRecurrences()\" [disabled]=\"multiClickDisabled\">Save</button>\r\n          </aside>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n\r\n<!-- //////////////////////////////////////// Select Dates///////////////////////////////////////////// -->\r\n<!-- //////////////////////////////////////// Select Dates///////////////////////////////////////////// -->\r\n<!-- //////////////////////////////////////// Select Dates///////////////////////////////////////////// -->\r\n<!-- //////////////////////////////////////// Select Dates///////////////////////////////////////////// -->\r\n<!-- //////////////////////////////////////// Select Dates///////////////////////////////////////////// -->\r\n\r\n<section id=\"popup \" class=\"popupWrapper fadeIn \" *ngIf=\"showPopUp\">\r\n  <div class=\"popup pos-abs popup-body-container \">\r\n    <div class=\"popup-wrapper pos-rel \">\r\n\r\n      <span class=\"closePopup pos-abs fbold show \" id=\"popupCloseBtn \" (click)=\"closePopup()\">\r\n        <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\"\r\n          width=\"24px\" x=\"0\" y=\"0\">\r\n          <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\"\r\n            style=\"fill: currentColor\"></path>\r\n        </svg>\r\n      </span>\r\n\r\n      <div class=\"popup-content popup-date-selection\">\r\n\r\n        <h2>Select Dates for Class</h2>\r\n\r\n        <div class=\"\">\r\n          <label>Edit Selected Schedule</label>\r\n        </div>\r\n\r\n        <div class=\"row\">\r\n          <div class=\"form-wrapper has-value c-sm-6 c-md-6 c-lg-6\">\r\n            <label for=\"row.category_id \">Teacher Name</label>\r\n            <select id=\" \" class=\" form-ctrl side-form-ctrl \" name=\"row.category_id \" [(ngModel)]=\"selctedScheduledClass.teacher_id \">\r\n              <option value=\"-1 \"></option>\r\n              <option *ngFor=\"let opt of teacherListDataSource \" [value]=\"opt.teacher_id \">\r\n                {{opt.teacher_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 paddingFive\">\r\n            <div class=\"form-wrapper timepick\">\r\n              <label for=\"startTime\">Start Time</label>\r\n              <div class=\"tbox\">\r\n                <div class=\"times\">\r\n                  <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"selctedScheduledClass.startTime.hour\" name=\"startTime\">\r\n                    <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                      {{time}}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n                <div class=\"times\">\r\n                  <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"selctedScheduledClass.startTime.minute\" name=\"minute\">\r\n                    <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                      {{minute}}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"c-sm-3 c-md-3 c-lg-3 dig1 paddingFive\">\r\n            <div class=\"form-wrapper timepick\">\r\n              <label for=\"startTime\">End Time</label>\r\n              <div class=\"tbox\">\r\n                <div class=\"times\">\r\n                  <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"selctedScheduledClass.endTime.hour\" name=\"startTime\">\r\n                    <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                      {{time}}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n                <div class=\"times\">\r\n                  <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"selctedScheduledClass.endTime.minute\" name=\"minute\">\r\n                    <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                      {{minute}}\r\n                    </option>\r\n                  </select>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"row\">\r\n\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"form-wrapper has-value\">\r\n              <label for=\"label\">Room No</label>\r\n              <input type=\"text\" id=\"label\" class=\"side-form-ctrl\" name=\"label\" [(ngModel)]=\"selctedScheduledClass.room_no\">\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"form-wrapper has-value\">\r\n              <label for=\"row.category_id \">Class Type</label>\r\n              <select id=\"row.category_id\" class=\"form-ctrl side-form-ctrl\" name=\"row.category_id \" style=\"background: transparent; \" [(ngModel)]=\"selctedScheduledClass.custom_class_type \">\r\n                <option *ngFor=\"let opt of customListDataSource \">\r\n                  {{opt}}\r\n                </option>\r\n              </select>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"row desc\">\r\n          <div class=\"c-sm-6 c-md-6 c-lg-6\">\r\n            <div class=\"form-wrapper has-value\">\r\n              <label for=\"label\">Description</label>\r\n              <input type=\"textbox\" class=\"form-ctrl side-form-ctrl\" name=\"label \" [(ngModel)]=\"selctedScheduledClass.class_desc \" id=\"slctdTxt3\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n\r\n        <div class=\"table-selectdate-wrapper\">\r\n          <div class=\"row extraMargin table-warpper-custom\">\r\n            <div class=\"table-scroll-wrapper \">\r\n              <div class=\"table table-responsive \">\r\n                <table>\r\n                  <thead>\r\n                    <tr>\r\n                      <th>\r\n                        Schedule Date\r\n                      </th>\r\n                      <th>\r\n                        Action\r\n                      </th>\r\n                      <th>\r\n                      </th>\r\n                    </tr>\r\n                  </thead>\r\n                  <tbody>\r\n                    <tr>\r\n                      <td>\r\n                        <div class=\"field-wrapper datePickerBox\">\r\n                          <input type=\"textbox\" value=\"\" readonly=\"true\" [(ngModel)]=\"addDates.selectedDate\" class=\"form-ctrl bsDatepicker\" name=\"endDate\"\r\n                            bsDatepicker id=\"endTxt3\">\r\n                        </div>\r\n                      </td>\r\n                      <td>\r\n                        <a style=\"font-size: 24px;font-weight: 600;\" alt=\"Add \" title=\"Add\" (click)=\"addDateToArray() \" id=\"addAnch11\">+</a>\r\n                      </td>\r\n                      <td>\r\n                      </td>\r\n                    </tr>\r\n                    <tr *ngFor=\"let row of selectedDateArray; let i=index ; trackBy : index \">\r\n                      <td>\r\n                        {{row.selectedDate}}\r\n                      </td>\r\n                      <td>\r\n                        <i class=\"fas fa fa-trash \" (click)=\"removeDateToArray(i, row) \" style=\"font-size: 19px; font-family:\r\n                      FontAwesome; \" alt=\"Remove \" title=\"Remove \" id=\"removeIcon1\"></i>\r\n                      </td>\r\n                      <td style=\"color:#0084f6\">\r\n                        {{row.error}}\r\n                      </td>\r\n                    </tr>\r\n                  </tbody>\r\n                </table>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n\r\n        <div style=\"margin-top: 5px;\">\r\n          <button class=\"btn fullBlue pull-right \" (click)=\"saveSelectedDateSchedule()\">Save Class Schedule</button>\r\n          <button class=\"btn pull-right\" (click)=\"closePopup()\">Cancel</button>\r\n        </div>\r\n\r\n      </div>\r\n\r\n    </div>\r\n\r\n  </div>\r\n\r\n</section>\r\n\r\n<!-- //////////////////////////////////////// Cancellation PopUp ///////////////////////////////////////////// -->\r\n<!-- //////////////////////////////////////// Cancellation PopUp///////////////////////////////////////////// -->\r\n<!-- //////////////////////////////////////// Cancellation PopUp///////////////////////////////////////////// -->\r\n<!-- //////////////////////////////////////// Cancellation PopUp///////////////////////////////////////////// -->\r\n<!-- //////////////////////////////////////// Cancellation PopUp///////////////////////////////////////////// -->\r\n\r\n<section id=\"popup \" class=\"popupWrapper fadeIn \" *ngIf=\"showPopUpCancellation\">\r\n  <div class=\"popup pos-abs popup-body-container \">\r\n    <div class=\"popup-wrapper pos-rel \">\r\n      <span class=\"closePopup pos-abs fbold show \" id=\"popupCloseBtn \" (click)=\"closePopup()\">\r\n        <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\"\r\n          width=\"24px\" x=\"0\" y=\"0\">\r\n          <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\"\r\n            style=\"fill: currentColor\"></path>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content cancelWraper\">\r\n        <h2 *ngIf=\"isProfessional\">Cancel Schedule\r\n          <span style=\"color: #9b9b9b\"> of {{cancelRowSelected.batch_name}}</span>\r\n        </h2>\r\n        <h2 *ngIf=\"!isProfessional\">Cancel Schedule\r\n          <span style=\"color: #9b9b9b\">of {{cancelRowSelected.subject_name}}</span>\r\n        </h2>\r\n        <div class=\"row\" style=\"margin:20px 10px\">\r\n          <div class=\"field-wrapper c-sm-6 c-md-6 c-lg-6\">\r\n            <textarea class=\"textBox\" id=\"idTexboxReason\" placeholder=\"Cancellation Reason\"></textarea>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"row extraMargin\">\r\n          <div class=\"field-checkbox-wrapper pull-left\">\r\n\r\n            <input type=\"checkbox\" checked name=\"enableSMS\" class=\"form-checkbox\" id=\"idChkbxEnable\">\r\n            <label for=\"idChkbxEnable\">Notify students</label>\r\n          </div>\r\n          <div class=\"pull-right\" *ngIf=\"!isProfessional\" style=\"margin-right: 15px\">\r\n            <button class=\"btn\" (click)=\"closePopup()\">Close</button>\r\n            <button class=\"btn fullBlue\" (click)=\"cancelCourseSchedule()\">Cancel</button>\r\n          </div>\r\n          <div class=\"pull-right\" *ngIf=\"isProfessional\" style=\"margin-right: 15px\">\r\n            <button class=\"btn\" (click)=\"closePopup()\">Close</button>\r\n            <button class=\"btn fullBlue\" (click)=\"cancelBatchSchedule()\">Cancel Class</button>\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n<!-- ///////////////////////////////////////////Warning PopUp///////////////////////////////////////////////////// -->\r\n<!-- ///////////////////////////////////////////Warning PopUp///////////////////////////////////////////////////// -->\r\n<!-- ///////////////////////////////////////////Warning PopUp///////////////////////////////////////////////////// -->\r\n<!-- ///////////////////////////////////////////Warning PopUp///////////////////////////////////////////////////// -->\r\n<!-- ///////////////////////////////////////////Warning PopUp///////////////////////////////////////////////////// -->\r\n<!-- ///////////////////////////////////////////Warning PopUp///////////////////////////////////////////////////// -->\r\n<section id=\"popup \" class=\"popupWrapper fadeIn \" *ngIf=\"showWarningPopup\">\r\n  <div class=\"popup pos-abs popup-body-container \">\r\n    <div class=\"popup-wrapper pos-rel \">\r\n      <span class=\"closePopup pos-abs fbold show \" id=\"popupCloseBtn \" (click)=\"closeWarningPopUp()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg \" viewBox=\"9310 2185 16 16 \">\r\n          <g id=\"Group_1228 \" data-name=\"Group 1228 \" transform=\"translate(8298 1888) \">\r\n            <g id=\"Group_1213 \" data-name=\"Group 1213 \" transform=\"translate(34.189 -7.77) \">\r\n              <line id=\"Line_274 \" data-name=\"Line 274 \" class=\"cls-1 \" y2=\"19.798 \" transform=\"translate(992.81 305.77)\r\n                      rotate(45) \" />\r\n              <line id=\"Line_275 \" data-name=\"Line 275 \" class=\"cls-1 \" x1=\"19.798 \" transform=\"translate(978.81 305.77)\r\n                      rotate(45) \" />\r\n            </g>\r\n            <rect id=\"Rectangle_686 \" data-name=\"Rectangle 686 \" style=\"stroke:none; \" class=\"cls-2 \" width=\"16\r\n                      \" height=\"16 \" transform=\"translate(1012 297) \" />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content\">\r\n        <div class=\"\" *ngIf=\"batchFrequency == '1'\">\r\n          <div class=\"row warningNote \">\r\n              <h5 style=\"padding: 10px;\">\r\n                  <b style=\"font-weight: 600;\">If custom schedule already exist, below changes are applicable:</b>\r\n                  <br>\r\n                  <br>\r\n                  <span> 1. &nbsp; Past and current date schedule will not be deleted.</span>\r\n                  <br>\r\n                  <span> 2. &nbsp; New schedule will be applicable from current date.</span>\r\n                  <br>\r\n                  <span> 3. &nbsp; Cancelled classes will not be deleted</span>\r\n                </h5>\r\n          </div>\r\n          <div class=\"row\">\r\n            <div class=\"pull-right\" style=\"margin-right: 20px;\">\r\n              <input class=\"btn\" type=\"button\" value=\"Close\" (click)=\"closeWarningPopUp()\" id=\"closeInp3\">\r\n              <input class=\"btn fullBlue\" type=\"button\" value=\"Add\" (click)=\"createWeeklySchedule()\" id=\"addInp4\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"\" *ngIf=\"batchFrequency == '2'\">\r\n          <div class=\"row warningNote\">\r\n              <h5 style=\"padding: 10px;\">\r\n                  <b style=\"font-weight: 600;\"> If weekly schedule already exist, below changes are applicable:</b>\r\n                  <br>\r\n                  <br>\r\n                  <span> 1. &nbsp; Past and current date schedule will not be deleted.</span>\r\n                  <br>\r\n                  <span> 2. &nbsp; New schedule will be applicable from current date.</span>\r\n                  <br>\r\n                  <span> 3. &nbsp; Cancelled classes will not be deleted.</span>\r\n                </h5>\r\n          </div>\r\n          <div class=\"row\">\r\n            <div class=\"pull-right\" style=\"margin-right: 20px;\">\r\n              <input class=\"btn\" type=\"button\" value=\"Close\" (click)=\"closeWarningPopUp()\" id=\"closeTxt6\">\r\n              <input class=\"btn fullBlue\" type=\"button\" value=\"Add\" (click)=\"createCustomClasses()\" id=\"createInp6\">\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n\r\n\r\n<!-- //////////////////////////////////////// Cancel Weekly Schedule ///////////////////////////////////////////// -->\r\n<!-- //////////////////////////////////////// Cancel Weekly Schedule///////////////////////////////////////////// -->\r\n<!-- //////////////////////////////////////// Cancel Weekly Schedule///////////////////////////////////////////// -->\r\n<!-- //////////////////////////////////////// Cancel Weekly Schedule///////////////////////////////////////////// -->\r\n<!-- //////////////////////////////////////// Cancel Weekly Schedule///////////////////////////////////////////// -->\r\n\r\n<section id=\"popup \" class=\"popupWrapper fadeIn \" *ngIf=\"cancelWeeklySchedulePop\">\r\n  <div class=\"popup pos-abs popup-body-container \">\r\n    <div class=\"popup-wrapper pos-rel \">\r\n      <span class=\"closePopup pos-abs fbold show \" id=\"popupCloseBtn \" (click)=\"closeWeeklySchedulePopup()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg \" viewBox=\"9310 2185 16 16 \">\r\n          <g id=\"Group_1228 \" data-name=\"Group 1228 \" transform=\"translate(8298 1888) \">\r\n            <g id=\"Group_1213 \" data-name=\"Group 1213 \" transform=\"translate(34.189 -7.77) \">\r\n              <line id=\"Line_274 \" data-name=\"Line 274 \" class=\"cls-1 \" y2=\"19.798 \" transform=\"translate(992.81 305.77)\r\n                    rotate(45) \" />\r\n              <line id=\"Line_275 \" data-name=\"Line 275 \" class=\"cls-1 \" x1=\"19.798 \" transform=\"translate(978.81 305.77)\r\n                    rotate(45) \" />\r\n            </g>\r\n            <rect id=\"Rectangle_686 \" data-name=\"Rectangle 686 \" style=\"stroke:none; \" class=\"cls-2 \" width=\"16\r\n                    \" height=\"16 \" transform=\"translate(1012 297) \" />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content cancelWraper\">\r\n        <h2 *ngIf=\"isProfessional\">Batch Weekly Schedule Cancellation</h2>\r\n        <div class=\"row\">\r\n          <div class=\"c-lg-6 c-md-6 c-sm-6\">\r\n            <div class=\"field-wrapper datePickerBox has-value\">\r\n              <label for=\"dateWee\">Date\r\n                <span class=\"text-danger\">*</span>\r\n              </label>\r\n              <input type=\"text\" value=\"\" id=\"dateWee\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"weeklyScheduleCan.date\" readonly=\"true\"\r\n                name=\"csd\" bsDatepicker>\r\n\r\n            </div>\r\n          </div>\r\n          <div class=\"field-wrapper c-sm-6 c-md-6 c-lg-6\">\r\n            <textarea class=\"textBox\" id=\"idTexboxReason\" [(ngModel)]=\"weeklyScheduleCan.cancel_note\" placeholder=\"Cancellation Reason\"></textarea>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"row extraMargin\">\r\n          <div class=\"field-checkbox-wrapper pull-left\">\r\n\r\n            <input type=\"checkbox\" [(ngModel)]=\"weeklyScheduleCan.is_notified\" name=\"enableSMS\" class=\"form-checkbox\" id=\"NotifyStusde\">\r\n            <label for=\"NotifyStusde\">Notify students</label>\r\n          </div>\r\n          <div class=\"pull-right\" style=\"margin-right: 15px\">\r\n            <button class=\"btn\" (click)=\"closeWeeklySchedulePopup()\">Close</button>\r\n            <button class=\"btn fullBlue\" (click)=\"cancelWeeklySchedule()\">Cancel Class</button>\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n\r\n<section [hidden]=\"topicBox\">\r\n  <div class=\"topicBox\">\r\n    <div class=\"close-btn\">\r\n      <span (click)=\"closeAlert()\">X</span>\r\n    </div>\r\n    <div class=\"header-container\">\r\n      <div class=\"sub-header\">\r\n        <span style=\"font-weight: 600;\">Subject : </span>\r\n        <span id=\"topicSubName\">{{subject_name}}</span>\r\n      </div>\r\n      <div class=\"total-topic\">\r\n        <span style=\"font-weight: 600;\">Total Topic : </span>\r\n        <span id=\"topicCount\">{{topicsData?.length}}</span>\r\n      </div>\r\n    </div>\r\n    <!-- <div class=\"field-checkbox-wrapper\" style=\"margin:10px;\">\r\n      <input type=\"checkbox\" name=\"checkbx\" id=\"select_all_topics\" [(ngModel)]=\"selectAllTopics\" (ngModelChange)=\"checkAllTopics()\"\r\n        class=\"form-checkbox\">\r\n      <label for=\"select_all_topics\">\r\n        Select All\r\n      </label>\r\n    </div> -->\r\n    <div class=\"topic-listing-container\">\r\n      <kendo-treeview [nodes]=\"topicsData\" [hasChildren]=\"hasChildren\" [children]=\"children\" kendoTreeViewSelectable kendoTreeViewHierarchyBinding\r\n        kendoTreeViewExpandable textField=\"topicName\" [kendoTreeViewCheckable]=\"checkableSettings\" [(checkedKeys)]=\"checkedKeys\"\r\n        checkBy=\"topicId\" (checkedChange)=\"handleChecking($event)\">\r\n      </kendo-treeview>\r\n    </div>\r\n    <!-- <div class=\"example-config\">\r\n           Checked keys: {{checkedKeys.length}} {{checkedKeys.join(\"|\")}}\r\n       </div> -->\r\n    <div class=\"extraMargin row  pull-right\" style=\"margin: 15px\">\r\n      <button class=\"btn\" (click)=\"closeAlert()\">Cancel</button>\r\n      <button class=\"btn fullBlue\" (click)=\"saveTopic()\">Save</button>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n<section *ngIf=\"showTopicsModal\">\r\n  <div class=\"topicBox\">\r\n    <div class=\"close-btn\">\r\n      <span (click)=\"closeTopicModal()\">X</span>\r\n    </div>\r\n    <div class=\"header-container\">\r\n      <div class=\"sub-header\">\r\n        <span style=\"font-weight: 600;\">Subject : </span>\r\n        <span id=\"topicSubName\">{{selectedSubjectInBatch}}</span>\r\n      </div>\r\n     \r\n    </div>\r\n    <div  style=\"min-height: 110px;overflow-x: hidden;\">\r\n       <ng-container *ngTemplateOutlet=\"topicsRecursiveList; context:{$implicit: topicsList, level: 1 }\"></ng-container> \r\n    </div>\r\n    <div class=\"extraMargin row  pull-right\" style=\"margin: 15px\">\r\n      <button class=\"btn\" (click)=\"closeTopicModal()\">Cancel</button>\r\n      <button class=\"btn fullBlue\" *ngIf=\"showTopicsModal && !showCustomEditModal\" (click)=\"saveSelectedTopics()\">Save</button>\r\n      <button class=\"btn fullBlue\" *ngIf=\"showCustomEditModal\" (click)=\"linkTopics()\">Save</button>\r\n    </div>\r\n  </div>\r\n</section><!--class=\"topic-listing-container\"-->\r\n\r\n\r\n\r\n\r\n<ng-template #topicsRecursiveList let-topicsList let-level=\"level\">\r\n  <div style=\"margin:2px !important\" *ngFor=\"let topic of topicsList\">\r\n    <div class=\"topic-container\" [ngClass]=\"level == 1 ? 'level1Topic': 'subTopicLevel'\">\r\n      <div class=\"arrow-icon\"  [style.visibility]=\"topic.subTopic.length ? 'visible':'hidden'\" (click)=\"toggleArrow(topic)\">\r\n        <i [ngClass]=\"topic.isExpand ? 'fa fa-caret-down': 'fa fa-caret-right'\" style=\"font-size: 15px!important;\"></i>\r\n      </div>\r\n      <div class=\"field-checkbox-wrapper\" style=\"margin-bottom: 5px !important;padding-left:0px !important\">\r\n       <input type=\"checkbox\" [(ngModel)]=\"topic.checked\"  class=\"form-checkbox\" value=\"{{topic.checked}}\" (click)=\"selectTopics(topic,$event)\" id=\"topic-{{topic.topicId}}\" />\r\n      \r\n        <label for=\"topic-{{topic.topicId}}\" style=\"margin-left:25px !important\">{{topic.topicName}}</label>\r\n      \r\n        <div *ngIf=\"topic.isExpand\">\r\n          <ng-container  *ngTemplateOutlet=\"topicsRecursiveList; context:{ $implicit: topic.subTopic, level: level + 1  }\">\r\n          </ng-container>\r\n        </div>\r\n      </div>      \r\n      \r\n    </div> \r\n  </div >\r\n</ng-template>\r\n\r\n<div class=\"black-bg\" id=\"black-bg\" [hidden]=\"topicBox\" (click)=\"closeAlert()\">\r\n\r\n</div>\r\n<div class=\"black-bg\" id=\"black-bg\" [hidden]=\"!showTopicsModal\" >\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-class/class-add/class-add.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/* ========================================================================================= */\n.classScheduleTable table.table-main {\n  border-bottom: 1px solid rgba(211, 212, 213, 0.5); }\n.classScheduleTable table.table-main tr th {\n    text-align: center;\n    padding: 10px 5px;\n    width: 9%; }\n.classScheduleTable table.table-main tr th.subj {\n      width: 10%; }\n.classScheduleTable table.table-main tr th.desc {\n      width: 12%; }\n.classScheduleTable table.table-main tr th.topic {\n      width: 12%; }\n.classScheduleTable table.table-main tr th.room {\n      width: 4%; }\n.classScheduleTable table.table-main tr th.cl-type {\n      width: 7%; }\n.classScheduleTable table.table-main tr th:last-child {\n      width: 2%; }\n.classScheduleTable table.table-main tr td {\n    padding: 5px 5px;\n    font-size: 12px;\n    border-top: none;\n    border-bottom: none; }\n.classScheduleTable table.table-main tr td.subj {\n      width: 10%; }\n.classScheduleTable table.table-main tr td.desc {\n      width: 12%; }\n.classScheduleTable table.table-main tr td.room {\n      width: 4%; }\n.classScheduleTable table.table-main tr td.cl-type {\n      width: 7%; }\n.classScheduleTable table.table-main tr td:last-child {\n      width: 2%; }\n.classScheduleTable table.table-main tr.adder {\n    background: #efefef; }\n.classScheduleTable table.table-main tr.adder .pckr {\n      display: -webkit-inline-box;\n      display: -ms-inline-flexbox;\n      display: inline-flex;\n      margin: 0px;\n      width: 100%; }\n.classScheduleTable table.table-main tr.adder td .timePickerParent {\n      display: -webkit-inline-box;\n      display: -ms-inline-flexbox;\n      display: inline-flex; }\n.classScheduleTable table.table-main tr.adder td .timePickerParent .form-wrapper .hourTime {\n        width: 100%; }\n.classScheduleTable table.table-main tr.adder td .timePickerParent .form-wrapper .minuteTime {\n        width: 100%; }\n.classScheduleTable table.table-main tr.adder td .field-wrapper {\n      position: relative; }\n.classScheduleTable table.table-main tr.adder td .field-wrapper.datepicker {\n        padding-top: 3px; }\n.classScheduleTable table.table-main tr.adder td .field-wrapper.datepicker span {\n          position: relative;\n          right: 25px;\n          font-weight: 600;\n          font-size: 16px;\n          color: red;\n          cursor: pointer;\n          width: 20px;\n          text-align: center;\n          /* &::before {\r\n                                        content: '';\r\n                                        background: url('/assets/images/calendar.svg') no-repeat;\r\n                                        position: absolute;\r\n                                        right: 25px;\r\n                                        top: 0px;\r\n                                        width: 21px;\r\n                                        height: 21px;\r\n                                        z-index: 0;\r\n                                    } */ }\n.classScheduleTable table.table-main tr.adder td .field-wrapper .form-ctrl {\n        background: transparent;\n        display: block;\n        width: 100%;\n        -webkit-box-sizing: border-box;\n                box-sizing: border-box;\n        outline: none;\n        border: 0;\n        height: 36px;\n        z-index: 10;\n        font: 400 12px 'Open sans',sans-serif;\n        -webkit-box-shadow: none;\n                box-shadow: none;\n        border-radius: 0;\n        line-height: 24px; }\n/* ========================================================================================= */\n.cal-view {\n  margin: 10px; }\n.cal-view .common-search-filter {\n    margin-top: 5px;\n    background: white; }\n.cal-view .common-search-filter .field-wrapper {\n      background: transparent; }\n.cal-view .common-search-filter .field-wrapper .form-ctrl {\n        background: transparent; }\n/* ========================================================================================= */\n/* ========================================================================================= */\n.classSchedule-Add {\n  padding: 15px 5px 10px 5px;\n  background: #efefef; }\n.classSchedule-Add .field-wrapper {\n    background: transparent; }\n.classSchedule-Add .field-wrapper .form-ctrl {\n      background: transparent; }\n.classSchedule-Add fieldset legend {\n    font-size: 12px;\n    position: absolute;\n    color: #0084f6;\n    top: -12px; }\n.classSchedule-Add fieldset .time-picker .field-wrapper {\n    display: inline !important;\n    margin: 0px 0px 0px 0px !important;\n    background: transparent; }\n.classSchedule-Add fieldset .time-picker .field-wrapper .form-ctrl {\n      background: transparent;\n      width: inherit !important; }\n.classSchedule-Add fieldset .time-picker .hour {\n    width: 75px; }\n.classSchedule-Add fieldset .time-picker .minute {\n    width: 75px; }\n.classSchedule-Add fieldset .time-picker .meridian {\n    width: 100px; }\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n.courses-list-table tr td:first-child {\n  text-align: left;\n  padding: 10px;\n  width: 20px; }\n.edit-view {\n  display: none; }\n.edit-view .radio-options {\n    margin-top: 0; }\n.edit-view .field-wrapper {\n    width: 130px;\n    padding-top: 0;\n    margin: 0 auto; }\n.edit-view .field-wrapper .form-ctrl {\n      padding: 0;\n      height: 28px; }\n.edit-view .field-wrapper.datePickerBox:after {\n      top: 2px; }\n.edit-view .radio-options > div {\n    margin-bottom: 0; }\n.data-view {\n  display: block; }\n.edit-mod .edit-view {\n  display: block; }\n.edit-mod .data-view {\n  display: none; }\n.common-tab {\n  padding-top: 5px; }\n.common-tab ul {\n    font-size: 0; }\n.common-tab ul li {\n      margin-right: 1px;\n      display: inline-block;\n      width: 19%;\n      max-width: 158px; }\n.common-tab ul li a {\n        display: block;\n        padding: 10px 5px;\n        background: #eff7ff;\n        border: 1px solid #cccdcd;\n        color: #0084f6;\n        text-align: center;\n        font-size: 14px;\n        font-weight: 600; }\n.common-tab ul li:hover a, .common-tab ul li.active a {\n        background: #0084f6;\n        color: #fff;\n        border-color: #0084f6;\n        font-weight: normal; }\n.view-icon,\n.edit-icon {\n  margin-right: 5px; }\n.create-standard-field {\n  margin-bottom: 10px; }\n.filter-for-courses label {\n  margin-top: 15px;\n  display: block; }\n.filter-for-courses .form-btn-head {\n  width: 30px;\n  height: 30px;\n  background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%22504 4 22 22%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2%2C .cls-3 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1%2C .cls-2 %7B%0D        stroke%3A %230060a3%3B%0D        stroke-width%3A 1.3px%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1199%22 data-name%3D%22Group 1199%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Cg id%3D%22Group_1190%22 data-name%3D%22Group 1190%22 transform%3D%22translate(-1)%22%3E%0D      %3Ccircle id%3D%22Ellipse_28%22 data-name%3D%22Ellipse 28%22 class%3D%22cls-1%22 cx%3D%228.75%22 cy%3D%228.75%22 r%3D%228.75%22 transform%3D%22translate(552 21)%22%2F%3E%0D      %3Cpath id%3D%22Path_449%22 data-name%3D%22Path 449%22 class%3D%22cls-2%22 d%3D%22M5%2C5%2C0%2C0%22 transform%3D%22translate(567 36)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Crect id%3D%22Rectangle_683%22 data-name%3D%22Rectangle 683%22 class%3D%22cls-3%22 width%3D%2222%22 height%3D%2222%22 transform%3D%22translate(550 20)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat center center;\n  background-size: 20px 20px;\n  margin-top: 2px;\n  cursor: pointer;\n  margin-right: 20px;\n  -webkit-filter: grayscale(100%);\n          filter: grayscale(100%); }\n.filter-search {\n  margin-bottom: 10px; }\n.filter-search > div {\n    margin-bottom: 0; }\n.filter-search .export-print {\n    margin-top: 6px; }\n.course-second .filter-for-courses {\n  margin-top: 0; }\n.course-second .filter-search {\n  margin-bottom: 0; }\n.course-second .filter-for-courses label {\n  margin-top: 10px; }\n.edit-view-btn > div {\n  display: inline-block;\n  margin: 0 5px; }\n.add-edit {\n  margin-bottom: 0;\n  margin-top: 20px; }\n.add-edit i {\n    border: 1px solid #0084f6;\n    display: inline-block;\n    width: 17px;\n    height: 17px;\n    border-radius: 50%;\n    line-height: 17px;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle;\n    margin-right: 4px; }\n.add-edit span {\n    display: inline-block; }\n.add-edit .expend-box i {\n    line-height: 12px;\n    font-size: 14px; }\n.create-standard-form {\n  margin: 10px 0;\n  padding: 10px 20px 20px;\n  background: #efefef;\n  border-top: 1px solid #d8d8d8; }\n.create-standard-form .field-checkbox-wrapper {\n    margin-top: 15px;\n    background: transparent; }\n.create-standard-form .field-checkbox-wrapper .form-checkbox + label {\n      font-size: 12px;\n      font-weight: 600;\n      color: #777; }\n.create-standard-form .field-checkbox-wrapper .form-checkbox:checked + label {\n      color: #0084f6; }\n.create-standard-form .field-checkbox-wrapper .form-checkbox + label:after {\n      -webkit-transform: scale(0.7);\n              transform: scale(0.7); }\n.create-standard-form .field-checkbox-wrapper .form-checkbox + label:before {\n      -webkit-transform: rotate(-45deg) scale(0.7);\n              transform: rotate(-45deg) scale(0.7); }\n.create-standard-form .field-wrapper {\n    margin-top: -10px; }\n.create-standard-form .field-wrapper label {\n      top: 25px;\n      font-size: 13px;\n      font-weight: 600; }\n.create-standard-form .form-ctrl {\n    background: transparent; }\n.create-standard-form p {\n    margin-top: 5px;\n    font-size: 10px;\n    color: #979797; }\n.create-cancel-small {\n  margin-top: 10px; }\n.create-cancel-small .btn {\n    font-size: 14px;\n    font-weight: normal;\n    height: 36px; }\n.edit-view-of-couse > tr > td {\n  padding: 0px !important; }\n.course-list-edit {\n  background: #fff;\n  padding: 20px;\n  -webkit-box-shadow: 0px 0px 1px 1px #c6c4c4 inset;\n          box-shadow: 0px 0px 1px 1px #c6c4c4 inset;\n  max-height: 200px;\n  overflow: auto; }\n.course-list-edit .evoc-box {\n    padding: 10px; }\n.course-list-edit .evoc-box .field-checkbox-wrapper {\n      background: transparent; }\n.course-list-edit .evoc-box .field-checkbox-wrapper label span {\n        font-size: 13px;\n        font-weight: 600;\n        top: -3px;\n        position: relative; }\n.ce-list-top {\n  padding-bottom: 10px;\n  border-bottom: 1px solid #ccc; }\n.ce-list-top label {\n    font-weight: 400; }\n.ce-list-top span {\n    font-weight: 600;\n    margin: 0 5px; }\n.ce-list-bottom .table-responsive tbody tr th {\n  background: #d8d8d8;\n  font-weight: 600;\n  font-size: 14px;\n  color: #333;\n  padding: 5px 10px;\n  text-align: left; }\n.ce-list-bottom .table-responsive tbody tr th:last-child {\n    width: 200px;\n    text-align: center; }\n.ce-list-bottom .table-responsive tbody tr th:first-child {\n    width: 100px; }\n.ce-list-bottom .table-responsive tbody tr td {\n  padding: 7px 10px;\n  background: #fff;\n  font-size: 12px;\n  text-align: left;\n  border-bottom: 1px solid #ededed; }\n.ce-list-bottom .table-responsive tbody tr td:last-child {\n    text-align: center; }\n.ce-list-bottom .table-responsive tbody tr:hover td {\n  background: #fff; }\n.ce-list-bottom .table-responsive tbody tr:last-child td {\n  border-bottom: 0; }\n.ce-list-bottom .field-checkbox-wrapper .form-checkbox + label:before {\n  -webkit-transform: scale(0.7) rotate(-45deg);\n          transform: scale(0.7) rotate(-45deg); }\n.ce-list-bottom .field-checkbox-wrapper .form-checkbox + label:after {\n  -webkit-transform: scale(0.6);\n          transform: scale(0.6); }\n.delete-btn a {\n  color: #f44336; }\n.delete-btn a i {\n    font-size: 18px !important;\n    vertical-align: middle;\n    margin-right: 5px; }\n.close-accor {\n  float: right;\n  width: 24px;\n  font-size: 31px;\n  height: 24px;\n  text-align: center;\n  border: none;\n  border-radius: 50%;\n  line-height: 16px;\n  margin-right: 4px;\n  margin-top: 5px;\n  cursor: pointer;\n  color: #0084f6;\n  font-weight: 400; }\n.schedule-class-box .filter-box .field-wrapper {\n  margin-top: -10px; }\n.schedule-class {\n  padding-bottom: 10px;\n  margin-bottom: 10px;\n  border-bottom: 1px solid #ccc; }\n.schedule-class .btn {\n    font-weight: 600;\n    font-size: 13px;\n    height: 30px; }\n.schedule-class .schedule-class-left {\n    padding-top: 10px; }\n.schedule-class .schedule-class-left label {\n      font-weight: 600;\n      margin-right: 15px; }\n.view-tab li {\n  display: inline-block;\n  margin-right: 0px; }\n.view-tab li .btn {\n    margin-left: 0;\n    height: 25px;\n    line-height: 12px;\n    font-weight: normal;\n    font-size: 12px;\n    padding: 5px 10px; }\n.view-c-detail {\n  margin-top: 5px; }\n.view-c-detail .filter-search {\n    margin-bottom: 0; }\n.view-c-detail .filter-search .export-print {\n      margin-bottom: 0; }\n.view-c-detail .vcd-l {\n    padding-top: 10px; }\n.view-c-detail .vcd-l label {\n      font-weight: 600;\n      font-size: 15px; }\n.calender-course {\n  margin-bottom: 15px;\n  margin-top: 8px;\n  position: relative; }\n.calender-course .c-control {\n    position: absolute;\n    width: 30px;\n    height: 100%;\n    background: #efefef;\n    border: 1px solid #cccccc;\n    cursor: pointer;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box; }\n.calender-course .c-control.cal-left {\n      left: 0;\n      top: 0;\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%222883.408 2074.83 10.462 21.337%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1 %7B%0D        fill%3A none%3B%0D        stroke%3A %23004a7e%3B%0D        stroke-miterlimit%3A 10%3B%0D        stroke-width%3A 2px%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cpath id%3D%22Path_557%22 data-name%3D%22Path 557%22 class%3D%22cls-1%22 d%3D%22M.7%2C20.7l8.4-9.3a1.049%2C1.049%2C0%2C0%2C0%2C0-1.3L.7.7%22 transform%3D%22translate(2893.825 2096.2) rotate(180)%22%2F%3E%0D%3C%2Fsvg%3E%0D\") no-repeat center center;\n      background-size: 11px; }\n.calender-course .c-control.cal-left:hover {\n        border: 1px solid #0084f6; }\n.calender-course .c-control.cal-right {\n      right: 0;\n      top: 0;\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%223990.754 2074.834 10.462 21.337%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1 %7B%0D        fill%3A none%3B%0D        stroke%3A %23004a7e%3B%0D        stroke-miterlimit%3A 10%3B%0D        stroke-width%3A 2px%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cpath id%3D%22Path_556%22 data-name%3D%22Path 556%22 class%3D%22cls-1%22 d%3D%22M.7%2C20.7l8.4-9.3a1.049%2C1.049%2C0%2C0%2C0%2C0-1.3L.7.7%22 transform%3D%22translate(3990.8 2074.8)%22%2F%3E%0D%3C%2Fsvg%3E%0D\") no-repeat center center;\n      background-size: 11px; }\n.calender-course .c-control.cal-right:hover {\n        border: 1px solid #0084f6; }\n.calender-course ul {\n    text-align: center;\n    padding-left: 40px;\n    padding-right: 40px; }\n.calender-course ul li {\n      display: inline-block;\n      padding: 5px 10px;\n      border: 1px solid #f0f0f0;\n      width: 8.8%;\n      background: #efefef;\n      vertical-align: top; }\n.calender-course ul li span.c-date {\n        font-size: 24px;\n        color: #0084f6; }\n.calender-course ul li.active {\n        background: #ddedfd;\n        border: 1px solid #ccc; }\n.class-cancel {\n  display: inline-block;\n  width: 12px;\n  height: 12px;\n  text-align: center;\n  line-height: 10px;\n  font-size: 11px;\n  color: #fff;\n  cursor: pointer;\n  vertical-align: middle; }\n.class-cancel.blue {\n    background: #0084f6; }\n.class-cancel.red {\n    background: red; }\n.class-cancel.yellow {\n    background: #f8b238; }\n.exam-is {\n  display: inline-block;\n  width: 12px;\n  height: 12px;\n  border-radius: 50%;\n  background: #f8b238;\n  vertical-align: middle; }\n.class-is {\n  display: inline-block;\n  width: 12px;\n  height: 12px;\n  border-radius: 50%;\n  background: #0084f6;\n  vertical-align: middle; }\n.calender-class-detail > div:last-child {\n  padding-top: 5px; }\n.calender-class-detail > div:last-child span {\n    margin-left: 5px; }\n.calender-view1 th {\n  padding: 10px;\n  font-size: 13px;\n  text-align: center; }\n.calender-view1 .table-responsive {\n  margin-top: 10px; }\n.calender-view1 .table-accor-head .open-accor {\n  display: block; }\n.calender-view1 .table-accor-head .close-accor {\n  display: none; }\n.calender-view1 .table-accor-head.active .accordian-heading .open-accor {\n  display: none; }\n.calender-view1 .table-accor-head.active .accordian-heading .close-accor {\n  display: block; }\n.calender-view1 .table-accor-head td {\n  padding: 0;\n  background: #fff; }\n.calender-view1 .accordian-heading h4 {\n  padding: 3px !important;\n  color: #444;\n  border: 1px solid #eaecee;\n  border-radius: 20px;\n  margin: 4px 0 2px;\n  background: #e6f2fe;\n  text-align: left; }\n.calender-view1 .accordian-heading h4 .open-accor,\n  .calender-view1 .accordian-heading h4 .close-accor {\n    float: left; }\n.calender-view1 .accordian-heading h4 .close-accor {\n    width: 18px;\n    height: 18px;\n    line-height: 11px;\n    margin-top: 0; }\n.calender-view1 .accordian-heading h4 .open-accor {\n    width: 18px;\n    height: 18px;\n    line-height: 18px;\n    margin-top: 0; }\n.calender-view1 .accordian-heading h4 .date-c {\n    font-size: 13px;\n    line-height: 20px;\n    margin-left: 10px;\n    font-weight: 600; }\n.calender-view1 .accordian-heading h4 .delete-icon {\n    font-size: 18px;\n    color: #f44336;\n    margin-left: 10px;\n    margin-right: 9px;\n    cursor: pointer; }\n.calender-view1 .accordian-heading h4 .delete-icon svg {\n      width: 15px;\n      vertical-align: top;\n      display: inline-block;\n      margin-top: 3px; }\n.calender-view1 .accordian-heading h4 .delete-icon svg line {\n        stroke-width: 2; }\n.delete-btn svg {\n  width: 15px;\n  vertical-align: top;\n  display: inline-block;\n  margin-top: 3px; }\n.delete-btn svg line {\n    stroke-width: 2; }\n.mail-notification {\n  width: 20px;\n  height: 20px;\n  background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%223872.5 2200.5 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-3 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %2395989a%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        fill%3A %230084f6%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1424%22 data-name%3D%22Group 1424%22 transform%3D%22translate(2798 1737)%22%3E%0D    %3Cg id%3D%22Group_1414%22 data-name%3D%22Group 1414%22 transform%3D%22translate(-174 -64)%22%3E%0D      %3Cg id%3D%22Group_1453%22 data-name%3D%22Group 1453%22%3E%0D        %3Cellipse id%3D%22Ellipse_63%22 data-name%3D%22Ellipse 63%22 class%3D%22cls-1%22 cx%3D%222.595%22 cy%3D%222.595%22 rx%3D%222.595%22 ry%3D%222.595%22 transform%3D%22translate(1260.811 530)%22%2F%3E%0D        %3Cpath id%3D%22Path_547%22 data-name%3D%22Path 547%22 class%3D%22cls-1%22 d%3D%22M15.7%2C9.838v4.541a1.735%2C1.735%2C0%2C0%2C1-1.73%2C1.73H2.73A1.735%2C1.735%2C0%2C0%2C1%2C1%2C14.378V5.73A1.735%2C1.735%2C0%2C0%2C1%2C2.73%2C4h7.308%22 transform%3D%22translate(1249 527.297)%22%2F%3E%0D        %3Cpath id%3D%22Path_548%22 data-name%3D%22Path 548%22 class%3D%22cls-1%22 d%3D%22M1%2C8l7.351%2C4.324%2C3.027-1.73%22 transform%3D%22translate(1249 525.027)%22%2F%3E%0D      %3C%2Fg%3E%0D      %3Ccircle id%3D%22Ellipse_64%22 data-name%3D%22Ellipse 64%22 class%3D%22cls-2%22 cx%3D%221.73%22 cy%3D%221.73%22 r%3D%221.73%22 transform%3D%22translate(1261.676 530.865)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Cpath id%3D%22Path_552%22 data-name%3D%22Path 552%22 class%3D%22cls-3%22 d%3D%22M.5.5h18v18H.5Z%22 transform%3D%22translate(1074 463)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n  cursor: pointer;\n  display: inline-block; }\n.mail-notify {\n  width: 20px;\n  height: 20px;\n  background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%223872.5 2200.5 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-3 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %23fff%3B%0D%09%09fill%3A %23004a7e%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        fill%3A %23004a7e%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1424%22 data-name%3D%22Group 1424%22 transform%3D%22translate(2798 1737)%22%3E%0D    %3Cg id%3D%22Group_1414%22 data-name%3D%22Group 1414%22 transform%3D%22translate(-174 -64)%22%3E%0D      %3Cg id%3D%22Group_1453%22 data-name%3D%22Group 1453%22%3E%0D        %3Cellipse id%3D%22Ellipse_63%22 data-name%3D%22Ellipse 63%22 class%3D%22cls-1%22 cx%3D%222.595%22 cy%3D%222.595%22 rx%3D%222.595%22 ry%3D%222.595%22 transform%3D%22translate(1260.811 530)%22%2F%3E%0D        %3Cpath id%3D%22Path_547%22 fill%3D%22%23004a7e%22 data-name%3D%22Path 547%22  d%3D%22M15.7%2C9.838v4.541a1.735%2C1.735%2C0%2C0%2C1-1.73%2C1.73H2.73A1.735%2C1.735%2C0%2C0%2C1%2C1%2C14.378V5.73A1.735%2C1.735%2C0%2C0%2C1%2C2.73%2C4h7.308%22 transform%3D%22translate(1249 527.297)%22%2F%3E%0D        %3Cpath id%3D%22Path_548%22 stroke%3D%22%23004a7e%22 data-name%3D%22Path 548%22 class%3D%22cls-1%22 d%3D%22M1%2C8l7.351%2C4.324%2C3.027-1.73%22 transform%3D%22translate(1249 525.027)%22%2F%3E%0D      %3C%2Fg%3E%0D      %3Ccircle id%3D%22Ellipse_64%22 data-name%3D%22Ellipse 64%22 class%3D%22cls-2%22 cx%3D%221.73%22 cy%3D%221.73%22 r%3D%221.73%22 transform%3D%22translate(1261.676 530.865)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Cpath id%3D%22Path_552%22 data-name%3D%22Path 552%22 class%3D%22cls-3%22 d%3D%22M.5.5h18v18H.5Z%22 transform%3D%22translate(1074 463)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n  cursor: pointer;\n  display: inline-block; }\n.reschedule-icon {\n  width: 20px;\n  height: 20px;\n  background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%223900.5 2201 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %2395989a%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1423%22 data-name%3D%22Group 1423%22 transform%3D%22translate(2798 1737.5)%22%3E%0D    %3Cg id%3D%22Group_1451%22 data-name%3D%22Group 1451%22%3E%0D      %3Cpath id%3D%22Path_542%22 data-name%3D%22Path 542%22 class%3D%22cls-1%22 d%3D%22M.7%2C19.391%2C2.091%2C18l1.391%2C1.391%22 transform%3D%22translate(1103.3 453.913)%22%2F%3E%0D      %3Cpath id%3D%22Path_543%22 data-name%3D%22Path 543%22 class%3D%22cls-1%22 d%3D%22M5.7%2C5.522A6.6%2C6.6%2C0%2C0%2C1%2C18.57%2C7.609%22 transform%3D%22translate(1100.039 465)%22%2F%3E%0D      %3Cpath id%3D%22Path_544%22 data-name%3D%22Path 544%22 class%3D%22cls-1%22 d%3D%22M17.57%2C20.783A6.6%2C6.6%2C0%2C0%2C1%2C4.7%2C18.7V18%22 transform%3D%22translate(1100.691 453.913)%22%2F%3E%0D      %3Cpath id%3D%22Path_545%22 data-name%3D%22Path 545%22 class%3D%22cls-1%22 d%3D%22M41.483%2C18l-1.391%2C1.391L38.7%2C18%22 transform%3D%22translate(1078.517 453.913)%22%2F%3E%0D      %3Cline id%3D%22Line_234%22 data-name%3D%22Line 234%22 class%3D%22cls-1%22 y2%3D%220.696%22 transform%3D%22translate(1118.609 472.609)%22%2F%3E%0D      %3Cpath id%3D%22Path_546%22 data-name%3D%22Path 546%22 class%3D%22cls-1%22 d%3D%22M25.091%2C16.522%2C23.7%2C15.13V12%22 transform%3D%22translate(1088.3 457.826)%22%2F%3E%0D      %3Ccircle id%3D%22Ellipse_62%22 data-name%3D%22Ellipse 62%22 class%3D%22cls-1%22 cx%3D%224.174%22 cy%3D%224.174%22 r%3D%224.174%22 transform%3D%22translate(1107.826 468.435)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Cpath id%3D%22Path_551%22 data-name%3D%22Path 551%22 class%3D%22cls-2%22 d%3D%22M.5.5h18v18H.5Z%22 transform%3D%22translate(1102 463)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n  cursor: pointer;\n  display: inline-block; }\n.action-box {\n  text-align: right;\n  width: 105px;\n  float: right; }\n.action-box .delete-btn {\n    font-size: 18px;\n    color: #f44336; }\n.action-box span {\n    display: inline-block;\n    vertical-align: middle;\n    margin: 0 8px 0 0;\n    cursor: pointer; }\n.action-box .edit-icon {\n    width: 19px;\n    height: 16px; }\n.tick-mark1 {\n  width: 15px;\n  height: 6px;\n  border-left: 2px solid green;\n  border-bottom: 2px solid green;\n  -webkit-transform: rotate(-45deg);\n          transform: rotate(-45deg);\n  display: inline-block;\n  vertical-align: top;\n  margin-top: 1px; }\n.ledgend-footer {\n  margin-top: 15px; }\n.ledgend-footer label {\n    font-weight: 600;\n    margin-right: 16px; }\n.ledgend-footer div {\n    margin-right: 20px;\n    font-size: 11px; }\n.ledgend-footer div span {\n      display: inline-block;\n      vertical-align: middle;\n      margin-right: 3px; }\n.date-arrow {\n  position: relative; }\n.date-arrow div {\n    position: relative; }\n.date-arrow div span {\n      background: #fff;\n      display: inline-block;\n      padding: 4px 20px;\n      z-index: 1;\n      font-size: 12px;\n      font-weight: 600;\n      position: relative; }\n.date-arrow div:after {\n      position: absolute;\n      left: 20px;\n      top: 0;\n      bottom: 0;\n      margin: auto;\n      content: \"\\f104\";\n      display: inline-block;\n      font: normal normal normal 14px/1 FontAwesome;\n      font-size: inherit;\n      text-rendering: auto;\n      -webkit-font-smoothing: antialiased;\n      width: 5px;\n      height: 16px; }\n.date-arrow div:before {\n      position: absolute;\n      right: 20px;\n      top: 0;\n      bottom: 0;\n      margin: auto;\n      content: \"\\f105\";\n      display: inline-block;\n      font: normal normal normal 14px/1 FontAwesome;\n      font-size: inherit;\n      text-rendering: auto;\n      -webkit-font-smoothing: antialiased;\n      width: 5px;\n      height: 16px; }\n.date-arrow:after {\n    content: '';\n    position: absolute;\n    left: 0;\n    right: 0;\n    top: 20px;\n    margin: auto;\n    width: 88%;\n    height: 0px;\n    border-bottom: 1px solid #ccc; }\n.calender-view1.cal-view-2 .accordian-heading h4 .open-accor,\n.calender-view1.cal-view-2 .accordian-heading h4 .close-accor {\n  float: right;\n  margin-right: 0; }\n.calender-view1.cal-view-2 td {\n  font-weight: 600;\n  font-size: 14px;\n  padding: 0; }\n.calender-view1.cal-view-2 td:first-child {\n    text-align: left; }\n.calender-view1.cal-view-2 td .accordian-heading h4 .date-c {\n    color: #004a7e;\n    font-size: 14px; }\n.new-action > div {\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.new-action > div span {\n    margin: 0; }\n.new-action > div > div {\n    width: 50%;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    border-right: 1px solid #ccc;\n    text-align: center;\n    padding: 5px; }\n.new-action > div > div:last-child {\n      border-right: 1px solid transparent; }\n.new-action > div:first-child {\n    border-bottom: 1px solid #ccc; }\n.cal-view-2 .action-box,\n.cal-view-2 .new-action {\n  width: 65px; }\n.cal-view-2 .action-box {\n  padding-right: 5px;\n  margin: 5px 0; }\n.read-more-view {\n  font-size: 12px;\n  margin-top: 10px;\n  color: #004a7e; }\n.new-tick-mark {\n  height: 72px;\n  width: 35px;\n  border-right: 2px solid #fff;\n  margin-right: 8px;\n  text-align: center;\n  position: relative; }\n.new-tick-mark .tick-mark1 {\n    position: absolute;\n    top: 0;\n    bottom: 0;\n    margin: auto;\n    right: 0;\n    left: 0; }\n.tick-mark-new > div {\n  display: inline-block;\n  vertical-align: middle; }\n.course-detail-section {\n  margin-top: 30px; }\n.course-detail-section .cd-s {\n    font-size: 13px;\n    font-weight: 600; }\n.course-detail-section label {\n    margin-right: 15px; }\n.course-detail-section span {\n    font-weight: 600;\n    margin-right: 10px; }\n.schedule-class-inner {\n  padding: 20px 15px 25px;\n  background: #efefef; }\n.schedule-class-inner .form-ctrl {\n    background: transparent; }\n.schedule-class-inner .s-c-1 {\n    font-weight: 600;\n    font-weight: 14px;\n    padding-bottom: 10px;\n    border-bottom: 1px solid #ccc; }\n.schedule-class-inner .choose-class-type {\n    margin-top: 20px; }\n.schedule-class-inner .choose-class-type .field-radio-wrapper {\n      display: inline-block;\n      margin-right: 20px; }\n.schedule-class-inner .select-days {\n    margin-top: 20px; }\n.schedule-class-inner .select-days span {\n      float: left; }\n.schedule-class-inner .select-days .field-checkbox-wrapper {\n      float: left;\n      margin-right: 2%;\n      background: transparent;\n      margin-left: 2%; }\n.schedule-class-inner .select-days .field-checkbox-wrapper .form-checkbox + label:after {\n        -webkit-transform: scale(0.7);\n                transform: scale(0.7); }\n.schedule-class-inner .select-days .field-checkbox-wrapper .form-checkbox + label:before {\n        -webkit-transform: rotate(-45deg) scale(0.7);\n                transform: rotate(-45deg) scale(0.7); }\n.create-class-schedule h4 {\n  font-size: 14px;\n  font-weight: 600;\n  margin-bottom: 10px;\n  margin-top: 15px; }\n.s-form-control {\n  margin-top: 30px;\n  border-top: 1px solid #ccc; }\n@media only screen and (min-width: 1000px) and (max-width: 1200px) {\n  .calender-course ul li {\n    width: 8%; } }\n@media only screen and (min-width: 768px) and (max-width: 999px) {\n  .calender-course ul li {\n    width: 6%; } }\n@media only screen and (max-width: 960px) {\n  .calender-class-detail > div {\n    width: 100%;\n    text-align: center; }\n  .calender-class-detail > div:last-child span {\n    margin: 0; } }\n@media only screen and (max-width: 767px) {\n  .common-tab ul li {\n    margin-right: 0;\n    width: 20%; }\n    .common-tab ul li a {\n      padding: 5px 5px;\n      font-size: 12px; }\n  .filter-for-courses label {\n    margin-top: 0;\n    margin-bottom: 5px; }\n  .filter-for-courses .filter-search .btn {\n    margin-right: 0;\n    margin-left: 10px; }\n  .radio-options {\n    text-align: left; }\n    .radio-options .field-radio-wrapper {\n      margin-bottom: 10px !important; }\n      .radio-options .field-radio-wrapper:last-child {\n        margin-bottom: 0 !important; }\n  .create-standard-form {\n    padding-left: 0;\n    padding-right: 0; }\n  .create-cancel-small .btn {\n    margin-right: 0;\n    margin-left: 10px; }\n  .schedule-class-box .filter-box .fullBlue.btn {\n    margin-top: 15px;\n    margin-bottom: 0; }\n  .schedule-class .schedule-class-left label {\n    display: block;\n    margin-bottom: 5px; }\n  .schedule-class .schedule-class-left span {\n    display: block;\n    margin-bottom: 10px; }\n  .schedule-class .btn {\n    margin-right: 0;\n    margin-left: 10px;\n    margin-bottom: 0; }\n  .view-tab li .btn {\n    margin-right: 0;\n    margin-bottom: 0; }\n  .calender-course ul li {\n    padding: 5px 5px;\n    width: 17%;\n    margin-bottom: 5px; }\n  .ledgend-footer label {\n    display: block;\n    width: 100%;\n    margin-right: 0;\n    margin-bottom: 10px; }\n  .ledgend-footer div {\n    margin-bottom: 5px; }\n  .cal-view .middle-top .btn {\n    margin-bottom: 0; }\n  .courses-list-table table,\n  .calender-view1 table {\n    min-width: 600px; }\n  .calender-course ul li span.c-date {\n    font-size: 19px; }\n  .date-arrow:after {\n    width: 72%; }\n  .course-detail-section {\n    margin-top: 20px; }\n    .course-detail-section > div {\n      margin-bottom: 5px; }\n  .filter-box {\n    padding: 10px 0px; }\n  .popup-btn .btn {\n    font-size: 12px;\n    height: 32px; } }\n@media only screen and (max-width: 420px) {\n  .common-tab ul li {\n    width: auto; }\n    .common-tab ul li a {\n      font-size: 10px; }\n  .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 12px; } }\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 65%;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 05%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n.extraMargin {\n  margin-left: 10px;\n  margin-top: 10px; }\n.l-circle {\n  width: 28px;\n  height: 28px;\n  border-radius: 50%;\n  font-size: 12px;\n  display: inline-block;\n  padding: 6px;\n  text-align: center; }\n.l-text {\n  color: rgba(0, 0, 0, 0.7);\n  background: #fff;\n  font-weight: 700;\n  border: 1px solid rgba(25, 31, 34, 0.156863); }\n.side-circles span {\n  margin-right: 5px; }\n.p-text {\n  background: #0084f6;\n  color: #fff;\n  font-weight: 700;\n  padding: 7px 7px; }\n.radio-options .field-radio-wrapper .form-radio:checked + label:before {\n  content: '';\n  width: 10px;\n  height: 10px;\n  background: #0084f6;\n  border-radius: 50%;\n  left: 3px;\n  top: 3px; }\n.cancelWraper ::-webkit-scrollbar {\n  display: block;\n  width: 7px;\n  height: 7px; }\n.cancelWraper .textBox {\n  width: 100%;\n  height: 100px;\n  padding: 10px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  resize: none;\n  border: 1px solid #0084f6 !important;\n  overflow-x: hidden;\n  overflow-y: auto; }\n.cancelWraper .textBox:focus {\n    padding: 10px; }\n.customTableWrapper {\n  max-height: 400px;\n  overflow-x: hidden;\n  overflow-y: scroll; }\n.rowAllignCustomAdd {\n  margin-left: 5px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  background: #efefef;\n  margin-right: 0px;\n  padding-top: 10px;\n  padding-bottom: 5px; }\n.textBoxContent {\n  max-height: 60px;\n  background: transparent;\n  min-height: 40px;\n  border-bottom: 1px solid #0084f6; }\n.marginTopBottom {\n  margin-top: 15px;\n  margin-bottom: 15px; }\n.class-wrapper {\n  border-bottom: 1px solid #ccc;\n  margin-top: 5px;\n  padding-bottom: 10px; }\n.extra-wrapper {\n  border-bottom: 1px solid #ccc;\n  margin-top: 5px;\n  padding-bottom: 10px; }\n.cancel-wrapper {\n  margin-top: 5px;\n  border-bottom: 1px solid #ccc; }\n.tableStyling {\n  margin-top: 10px; }\n.form-wrapper {\n  background: transparent;\n  margin: 5px 0px;\n  position: relative; }\n.form-wrapper label {\n    font-size: 12px;\n    font-weight: 400;\n    color: rgba(0, 0, 0, 0.77);\n    text-decoration: none;\n    -webkit-font-smoothing: antialiased; }\n.form-wrapper .side-form-ctrl {\n    background: white;\n    border: 1px solid rgba(119, 119, 119, 0.419608);\n    width: 100%;\n    padding: 5px 0px;\n    font-weight: 400;\n    font-size: 12px;\n    color: black; }\n.form-wrapper .side-form-ctrl.bsDatepicker {\n      padding: 5px;\n      width: 100%; }\n.form-wrapper.timepick {\n    display: inline !important;\n    width: 50%;\n    padding: 1px 0px; }\n.form-wrapper.timepick .tbox {\n      width: 100%; }\n.form-wrapper.timepick .tbox .times {\n        display: inline-block; }\n.form-wrapper.timepick .tbox .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        padding: 4px 5px;\n        font-weight: 600;\n        font-size: 14px;\n        color: black; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mins {\n          width: 70px;\n          height: 30px;\n          font-size: 12px; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mers {\n          width: 50px;\n          height: 30px;\n          font-size: 12px; }\n.form-wrapper .topic-link {\n    text-align: center;\n    cursor: pointer; }\n.form-wrapper .topic-linked {\n    text-align: center;\n    cursor: pointer;\n    border: 1px solid #1283f4; }\n.form-wrapper .topic-linked::-webkit-input-placeholder {\n    color: #1283f4; }\n.form-wrapper .topic-linked:-ms-input-placeholder {\n    color: #1283f4; }\n.form-wrapper .topic-linked::-ms-input-placeholder {\n    color: #1283f4; }\n.form-wrapper .topic-linked::placeholder {\n    color: #1283f4; }\n.popup-date-selection .row.desc {\n  margin-bottom: 5px; }\n.popup-date-selection .paddingFive {\n  padding-top: 5px; }\n.popup-date-selection .table-selectdate-wrapper {\n  border-spacing: 0px 5px;\n  border-top: 1px solid #efefef;\n  max-height: 215px;\n  overflow: hidden; }\n.popup-date-selection .table-selectdate-wrapper ::-webkit-scrollbar {\n    display: block; }\n.popup-date-selection .table-selectdate-wrapper .table-warpper-custom {\n    max-height: 200px;\n    overflow: auto; }\n.popup-date-selection .table-selectdate-wrapper .table-warpper-custom tr th {\n      text-align: left;\n      padding: 15px 10px; }\n.popup-date-selection .table-selectdate-wrapper .table-warpper-custom tr td {\n      text-align: left;\n      padding: 15px 10px; }\n.popup-date-selection .table-selectdate-wrapper .table-warpper-custom tr td .field-wrapper {\n        padding: 0px;\n        border: 1px solid #c6c6c6;\n        width: 225px;\n        height: 28px; }\n.popup-date-selection .table-selectdate-wrapper .table-warpper-custom tr td .field-wrapper .form-ctrl {\n          display: block;\n          width: 100%;\n          -webkit-box-sizing: border-box;\n                  box-sizing: border-box;\n          padding: 0px 6px 8px;\n          outline: none;\n          border: 0;\n          border-bottom: none;\n          height: 36px;\n          z-index: 10;\n          -webkit-box-shadow: none;\n                  box-shadow: none;\n          border-radius: 0;\n          line-height: 24px; }\n.popup-date-selection .table-selectdate-wrapper .table-warpper-custom tr td .field-wrapper.datePickerBox:after {\n          top: 2px; }\n.table .table-responsive table thead tr {\n  padding: 0px;\n  margin: 0px; }\n.table .table-responsive table thead tr th:first-child {\n    text-align: left; }\n.table .table-responsive table tbody tr {\n  padding: 0px;\n  margin: 0px; }\n.table .table-responsive table tbody tr td {\n    padding: 0px;\n    margin: 0px; }\n.table .table-responsive table tbody tr td .field-wrapper .form-ctrl.datePicker-box {\n      padding: 1px;\n      border: 1px solid black; }\n.tableDatePickerBox {\n  border: 1px solid #c6c6c6;\n  margin-left: 30%;\n  width: 225px;\n  height: 28px; }\n.tableDatePickerBox .form-ctrl.bsDatepicker {\n    border-bottom: none;\n    margin-top: -15px;\n    padding: 5px 5px; }\n.tableDatePickerBox.field-wrapper.datePickerBox:after {\n    top: 2px; }\n.field-wrapper.datePickerBox:after {\n  top: 30px; }\n.batch-schedule tr th {\n  padding: 10px; }\n.batch-schedule tr td .field-checkbox-wrapper {\n  width: 75px !important;\n  height: 25px !important; }\n.batch-schedule tr td .field-checkbox-wrapper .form-checkbox {\n  opacity: 0;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 20px;\n  height: 20px;\n  z-index: 1; }\n.batch-schedule tr td .field-checkbox-wrapper .form-checkbox + label {\n  vertical-align: middle;\n  font-size: 14px;\n  display: inline-block; }\n.batch-schedule tr td .field-checkbox-wrapper .form-checkbox + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 2px;\n  position: absolute;\n  left: 0;\n  top: 0; }\n.batch-schedule tr td .field-checkbox-wrapper .form-checkbox:checked + label:after {\n  border: 2px solid #0084f6; }\n.batch-schedule tr td .field-checkbox-wrapper .form-checkbox + label:before {\n  width: 1px;\n  height: 1px;\n  left: 8px;\n  top: 9px;\n  position: absolute;\n  content: '';\n  border-top: 0;\n  border-right: 0;\n  border-left: 2px solid transparent;\n  border-bottom: 2px solid transparent;\n  -webkit-transform: rotate(-45deg);\n          transform: rotate(-45deg); }\n.batch-schedule tr td .field-checkbox-wrapper .form-checkbox:checked + label:before {\n  border-left: 2px solid #0084f6;\n  border-bottom: 2px solid #0084f6;\n  width: 12px;\n  height: 5px;\n  left: 2px;\n  top: 5px; }\n.batch-schedule .filter-Section {\n  margin: 0px 0px 5px 0px; }\n.batch-schedule .weekly-Schedule .btnGroup {\n  padding-top: 10px;\n  margin-right: 15px; }\n.batch-schedule .weekly-Schedule .btn-table {\n  margin-right: 0px; }\n.batch-schedule .weekly-Schedule .weeklyDiv {\n  margin: 10px 0px; }\n.batch-schedule .weekly-Schedule .weeklyDiv .weeklyAdd {\n    margin-bottom: 10px; }\n.batch-schedule .weekly-Schedule .weeklyDiv .weekTable {\n    margin-bottom: 10px; }\n.batch-schedule .custom-Schedule .adderCustom {\n  margin: 10px 0px; }\n.batch-schedule .custom-Schedule .customTable {\n  margin-bottom: 10px; }\n.batch-schedule .common-section .divExtraClass {\n  margin-bottom: 10px; }\n.batch-schedule .common-section .divExtraClass .adder-Row {\n    margin: 10px 0px; }\n.batch-schedule .common-section .divExtraClass .extraClass {\n    margin-bottom: 10px; }\n.batch-schedule .common-section .divCancelClass {\n  margin: 10px 0px; }\n.batch-schedule .common-section .divCancelClass .cancelTable {\n    margin: 10px 0px; }\n.warningNote {\n  margin: 15px 10px;\n  border: 2px solid #efefef;\n  border-spacing: 5px 5px; }\n.table-scroll-wrapper {\n  overflow: auto; }\n.black-bg {\n  background: rgba(10, 10, 10, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 1;\n  width: 100%; }\n.topicBox {\n  position: fixed;\n  top: 20%;\n  left: 20%;\n  right: 20%;\n  width: 60%;\n  z-index: 100;\n  background: #f7f5f5;\n  -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n          box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);\n  border-radius: 4px; }\n.close-btn {\n  position: absolute;\n  right: 10px;\n  top: 10px;\n  font-size: 16px;\n  font-weight: 600; }\n.close-btn span {\n    cursor: pointer; }\n.header-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  padding: 10px;\n  margin-top: 20px;\n  border-bottom: 1px solid rgba(10, 10, 10, 0.7); }\n.sub-header {\n  width: 30%; }\n.total-topic {\n  width: 20%;\n  margin-left: 10%; }\n.topic-listing-container {\n  overflow-y: scroll;\n  max-height: 270px; }\n.tooltip {\n  position: relative;\n  display: inline-block;\n  border-bottom: 1px dotted black;\n  /* If you want dots under the hoverable text */ }\n/* Tooltip text */\n.tooltip .tooltiptext {\n  visibility: hidden;\n  width: 120px;\n  background-color: black;\n  color: #fff;\n  text-align: center;\n  padding: 5px 0;\n  border-radius: 6px;\n  /* Position the tooltip text - see examples below! */\n  position: absolute;\n  z-index: 1; }\n/* Show the tooltip text when you mouse over the tooltip container */\n.tooltip:hover .tooltiptext {\n  visibility: visible; }\n.k-treeview .k-in.k-state-selected {\n  background-color: transparent;\n  color: #656565; }\n.k-checkbox:indeterminate + .k-checkbox-label::after {\n  background-color: #0084f6; }\n.k-checkbox:checked + .k-checkbox-label::before {\n  border-color: #0084f6;\n  background-color: #0084f6; }\n.k-treeview .k-content, .k-treeview > .k-group, .k-treeview .k-item > .k-group {\n  padding: 10px; }\n.k-checkbox:indeterminate + .k-checkbox-label::after {\n  background-color: #0084f6; }\n.k-checkbox:indeterminate + .k-checkbox-label::after {\n  content: \"\";\n  -webkit-transform: scale(1);\n  transform: scale(1);\n  width: 8px;\n  height: 8px;\n  top: 4px;\n  left: 4px; }\n.weekly-schedule-table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  margin: 0px 15px;\n  margin-top: 15px;\n  width: auto;\n  border: 1px solid #ccc;\n  border-radius: 4px; }\n.weekly-schedule-table-container .table-heading-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    border-bottom: 1px solid #ccc; }\n.weekly-schedule-table-container .table-heading-container .heading-item {\n      text-align: left;\n      font-weight: 600;\n      width: 33%;\n      padding: 10px; }\n.weekly-schedule-table-container .table-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column; }\n.weekly-schedule-table-container .table-value-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row; }\n.weekly-schedule-table-container .table-value-container .value-item {\n      text-align: left;\n      font-weight: 400;\n      width: 33%;\n      padding: 10px; }\n.tbox {\n  width: 100%; }\n.tbox .times {\n    display: inline-block; }\n.tbox .side-form-ctrl {\n    background: white;\n    border: 1px solid rgba(119, 119, 119, 0.419608);\n    width: 100%;\n    padding: 4px 5px;\n    font-weight: 600;\n    font-size: 14px;\n    color: black; }\n.tbox .side-form-ctrl.mins {\n      width: 70px;\n      height: 30px;\n      font-size: 12px; }\n.tbox .side-form-ctrl.mers {\n      width: 50px;\n      height: 30px;\n      font-size: 12px; }\n.field-checkbox-wrapper .form-checkbox + label {\n  vertical-align: middle;\n  font-size: 14px;\n  display: inline-block; }\n.field-checkbox-wrapper .form-checkbox + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 2px;\n  position: absolute;\n  left: 0;\n  top: 0; }\n.field-checkbox-wrapper .form-checkbox:checked + label:after {\n  border: 2px solid #0084f6; }\n.field-checkbox-wrapper .form-checkbox + label:before {\n  width: 1px;\n  height: 1px;\n  left: 8px;\n  top: 9px;\n  position: absolute;\n  content: '';\n  border-top: 0;\n  border-right: 0;\n  border-left: 2px solid transparent;\n  border-bottom: 2px solid transparent;\n  -webkit-transform: rotate(-45deg);\n          transform: rotate(-45deg); }\n.field-checkbox-wrapper .form-checkbox:checked + label:before {\n  border-left: 2px solid #0084f6;\n  border-bottom: 2px solid #0084f6;\n  width: 12px;\n  height: 5px;\n  left: 2px;\n  top: 5px; }\n.field-checkbox-wrapper .form-checkbox:checked + label {\n  color: #0084f6; }\n.topic-container {\n  margin-right: 0 !important;\n  margin-left: 0 !important;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  margin: 2px; }\n.arrow-icon {\n  padding: 0 5px; }\n.level1Topic {\n  padding-top: 4px;\n  padding-bottom: 2px; }\n.subTopicLevel {\n  padding-top: 8px; }\n.pt-4 {\n  padding-top: 4px !important; }\n.topic-lbl {\n  font-size: 12px;\n  font-weight: 400;\n  color: rgba(0, 0, 0, 0.77);\n  text-decoration: none;\n  -webkit-font-smoothing: antialiased; }\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-class/class-add/class-add.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ClassAddComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_rxjs_observable_of__ = __webpack_require__("./node_modules/rxjs/_esm5/observable/of.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4____ = __webpack_require__("./src/app/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_course_services_class_schedule_service__ = __webpack_require__("./src/app/services/course-services/class-schedule.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_course_services_topic_listing_service__ = __webpack_require__("./src/app/services/course-services/topic-listing.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var ClassAddComponent = /** @class */ (function () {
    function ClassAddComponent(router, login, classService, topicService, auth, msgService, cd) {
        this.router = router;
        this.login = login;
        this.classService = classService;
        this.topicService = topicService;
        this.auth = auth;
        this.msgService = msgService;
        this.cd = cd;
        this.checkedKeys = [];
        this.customTable = [];
        this.courseModelStdList = [];
        this.courseModelSubList = [];
        this.courseModelBatchList = [];
        this.subBranch = [];
        this.masterCourse = [];
        this.teachers = [];
        this.instituteSetting = [];
        this.courseList = [];
        this.subjectListDataSource = [];
        this.fetchedCourseData = [];
        this.teacherListDataSource = [];
        this.customListDataSource = [];
        this.classScheduleArray = [];
        this.selectedDateArray = [];
        this.selctedScheduledClass = [];
        this.weekDaysSelected = [];
        this.weekDays = [];
        this.weekDaysTable = [];
        this.canceLClassTable = [];
        this.extraClassTable = [];
        this.hourArr = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];
        this.minArr = ['00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55'];
        this.meridianArr = ["AM", "PM"];
        this.times = ['1 AM', '2 AM', '3 AM', '4 AM', '5 AM', '6 AM', '7 AM', '8 AM', '9 AM', '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM', '4 PM', '5 PM', '6 PM', '7 PM', '8 PM', '9 PM', '10 PM', '11 PM', '12 AM'];
        this.addClassDetails = {
            batch_id: '',
            subject_id: '',
            subject_name: '',
            start_hour: '12 PM',
            start_minute: '00',
            start_meridian: '',
            end_hour: '1 PM',
            end_minute: '00',
            end_meridian: '',
            teacher_id: '',
            teacher_name: '',
            class_desc: '',
            room_no: '',
            custom_class_type: 'Regular',
            duration: ''
        };
        this.customRec = {
            start_hour: '',
            start_minute: '',
            start_meridian: '',
            end_hour: '',
            end_minute: '',
            end_meridian: '',
            radioEndDate: {
                radioEndDateSelection: false,
                radioDate: '',
            },
            radioOn: {
                radioONSelection: false,
                radioOnDate: '',
            },
            radioAfter: {
                radioAfterSelection: false,
                occurenceValue: ''
            }
        };
        this.addDates = {
            selectedDate: '',
            error: '',
        };
        this.timepicker = {
            universalStartTime: {
                hour: '',
                minute: '',
                meridian: ''
            },
            universalEndTime: {
                hour: '',
                minute: '',
                meridian: ''
            },
        };
        this.fetchMasterCourseModule = {
            master_course: "-1",
            requested_date: __WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-DD"),
            inst_id: sessionStorage.getItem('institute_id'),
            course_id: "-1"
        };
        this.fetchMasterBatchModule = {
            standard_id: "-1",
            subject_id: "-1",
            batch_id: '-1',
            inst_id: sessionStorage.getItem('institute_id'),
            assigned: "N"
        };
        this.custom = {
            date: __WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-DD"),
            start_hour: '12 PM',
            start_minute: '00',
            end_hour: '1 PM',
            end_minute: '00',
            desc: '',
            topics_covered: '',
        };
        this.addExtraClass = {
            date: __WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-DD"),
            start_hour: '12 PM',
            start_minute: '00',
            end_hour: '1 PM',
            end_minute: '00',
            desc: '',
            topics_covered: '',
        };
        this.mainStartTime = {
            hour: '12 PM',
            minute: '00',
        };
        this.mainEndTime = {
            hour: '1 PM',
            minute: '00',
        };
        this.weeklyCommonStartTime = {
            hour: '12 PM',
            minute: '00',
        };
        this.weeklyCommonEndTime = {
            hour: '1 PM',
            minute: '00',
        };
        this.cancelRowSelected = '';
        this.courseStartDate = '';
        this.courseEndDate = '';
        this.selectedClassFrequency = 'WEEK';
        this.batchFrequency = '1';
        this.showPopUp = false;
        this.showPopUpRecurence = false;
        this.showPopUpCancellation = false;
        this.isProfessional = false;
        this.isRippleLoad = false;
        this.isClassFormFilled = false;
        this.createCustomSchedule = false;
        this.showCancelWeeklyBtn = false;
        this.showWarningPopup = false;
        this.cancelWeeklySchedulePop = false;
        this.IsTopicSelectedMode = 'add';
        this.subject_name = '';
        this.topicsList = [];
        this.showTopicsModal = false;
        this.totalTopicsList = [];
        this.selectedTopics = ''; //join ids by '|'
        this.selectedTopicsNames = '';
        this.selectedTopicsListObj = []; //checked item list --> batch modal
        this.showCustomEditModal = false;
        this.getSubjectObject = '';
        this.weeklyScheduleCan = {
            date: __WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-DD"),
            cancel_note: '',
            is_notified: true
        };
        this.weekDaysList = [];
        this.topicBox = true;
        this.selectAllTopics = false;
        this.addLinkStatus = '';
        this.multiClickDisabled = false;
        if (sessionStorage.getItem('userid') == null) {
            this.router.navigate(['/authPage']);
        }
    }
    Object.defineProperty(ClassAddComponent.prototype, "checkableSettings", {
        get: function () {
            return {
                checkChildren: true,
                checkParents: true,
                enabled: true,
                mode: 'multiple',
                checkOnClick: false
            };
        },
        enumerable: true,
        configurable: true
    });
    ClassAddComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.messages = this.msgService.object;
        /* Prerequiste loaded */
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        /* fetching prefilled data */
        this.fetchPrefillData();
        if (!this.isProfessional) {
            this.checkForEditMode();
        }
        this.switchActiveView();
        this.checkForCoursePlannerRoute();
        this.getAllWeekDay();
    };
    ClassAddComponent.prototype.ngOnDestroy = function () {
        sessionStorage.setItem('isFromCoursePlanner', String(false));
    };
    ClassAddComponent.prototype.checkForCoursePlannerRoute = function () {
        this.coursePlannerStatus = sessionStorage.getItem('isFromCoursePlanner');
    };
    ClassAddComponent.prototype.checkNotifyDate = function (data) {
        if (__WEBPACK_IMPORTED_MODULE_2_moment__(data.class_date).valueOf() <= __WEBPACK_IMPORTED_MODULE_2_moment__().subtract(1, 'days').valueOf()) {
            return false;
        }
        else
            return true;
    };
    ClassAddComponent.prototype.checkCurrentDate = function (data, class_date) {
        if (data.is_attendance_marked == 'N') {
            if (__WEBPACK_IMPORTED_MODULE_2_moment__(class_date).valueOf() <= __WEBPACK_IMPORTED_MODULE_2_moment__(new Date()).valueOf()) {
                return false;
            }
            else
                return true;
        }
        else {
            if (__WEBPACK_IMPORTED_MODULE_2_moment__(class_date).valueOf() <= __WEBPACK_IMPORTED_MODULE_2_moment__(new Date()).valueOf()) {
                return false;
            }
            else
                return true;
        }
    };
    // For Weekly class schedule
    // All day of the week
    ClassAddComponent.prototype.getAllWeekDay = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.classService.getDayofWeekAll().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.weekDaysList = res;
            console.log(_this.weekDaysList);
        }, function (err) {
            _this.isRippleLoad = false;
            console.log(err);
        });
    };
    // Apply start time and end time for all week days
    ClassAddComponent.prototype.applyTimeForAll = function () {
        var _this = this;
        var startTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.createTimeInFormat(this.weeklyCommonStartTime.hour, this.weeklyCommonStartTime.minute, 'comp'), 'h:mma');
        var endTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.createTimeInFormat(this.weeklyCommonEndTime.hour, this.weeklyCommonEndTime.minute, 'comp'), 'h:mma');
        if (!(startTime.isBefore(endTime))) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter correct start time and end time');
            return;
        }
        else {
            this.weekDaysList.forEach(function (element) {
                element.start_time = _this.getNewTimeFormatJson(_this.weeklyCommonStartTime.hour.split(' ')[0] + ':' + _this.weeklyCommonStartTime.minute + ' ' + _this.weeklyCommonStartTime.hour.split(' ')[1]);
                element.end_time = _this.getNewTimeFormatJson(_this.weeklyCommonEndTime.hour.split(' ')[0] + ':' + _this.weeklyCommonEndTime.minute + ' ' + _this.weeklyCommonEndTime.hour.split(' ')[1]);
            });
        }
    };
    ClassAddComponent.prototype.handleChecking = function (itemLookup) {
        var subTopic = itemLookup.item.dataItem.subTopic;
        var arrayIndex = this.checkedKeys.indexOf(itemLookup.item.dataItem.topicId);
        if (arrayIndex > -1) {
            // this.checkedKeys.splice(arrayIndex, 1);
            var subTopic_1 = itemLookup.item.dataItem.subTopic;
            subTopic_1.length ? this.removeNLevelTopic(subTopic_1) : '';
        }
        else {
            // this.checkedKeys.push(itemLookup.item.dataItem.topicId);
            if (subTopic.length)
                this.AddNLevelTopic(subTopic);
        }
        this.cd.markForCheck();
    };
    ClassAddComponent.prototype.removeNLevelTopic = function (subTopics) {
        var _this = this;
        if (subTopics.length == 0) {
            var arrayIndex = this.checkedKeys.indexOf(subTopics.topicId);
            this.checkedKeys.splice(arrayIndex, 1);
            return;
        }
        else {
            subTopics.forEach(function (object) {
                var arrayIndex = _this.checkedKeys.indexOf(object.topicId);
                if (arrayIndex > -1) {
                    _this.checkedKeys.splice(arrayIndex, 1);
                }
                if (object.subTopic.length) {
                    _this.removeNLevelTopic(object.subTopic);
                }
            });
        }
        this.cd.markForCheck();
    };
    ClassAddComponent.prototype.AddNLevelTopic = function (subTopics) {
        var _this = this;
        if (subTopics.length == 0) {
            this.checkedKeys.push(subTopics.topicId);
            return;
        }
        else {
            subTopics.forEach(function (object) {
                var arrayIndex = _this.checkedKeys.indexOf(object.topicId);
                if (arrayIndex == -1) {
                    _this.checkedKeys.push(object.topicId);
                }
                if (object.subTopic.length) {
                    _this.AddNLevelTopic(object.subTopic);
                }
            });
        }
    };
    ClassAddComponent.prototype.checkForEditMode = function () {
        var _this = this;
        var str = sessionStorage.getItem('editClass');
        if (str == "" || str == null || str == undefined) {
            return;
        }
        var data = JSON.parse(str);
        if (data == "" || data == null || data == undefined) {
            return false;
        }
        else {
            this.fetchMasterCourseModule = {
                master_course: data.master_course,
                requested_date: __WEBPACK_IMPORTED_MODULE_2_moment__(data.id).format("YYYY-MM-DD"),
                inst_id: sessionStorage.getItem('institute_id'),
                course_id: data.course_id
            };
            this.getCustomList();
            this.getTeacherList();
            this.updateCourseList(this.fetchMasterCourseModule.master_course);
            setTimeout(function () {
                _this.getAllSubjectListFromServer(_this.fetchMasterCourseModule);
            }, 300);
            sessionStorage.setItem('editClass', '');
        }
    };
    ClassAddComponent.prototype.fetchPrefillData = function () {
        var _this = this;
        this.isRippleLoad = true;
        /* Batch Model */
        if (this.isProfessional) {
            this.classService.getStandardSubjectList(this.fetchMasterBatchModule.standard_id, this.fetchMasterBatchModule.subject_id, this.fetchMasterBatchModule.assigned).subscribe(function (res) {
                _this.courseModelBatch = res;
                if (_this.fetchMasterBatchModule.standard_id == '-1' && _this.fetchMasterBatchModule.subject_id == '-1') {
                    _this.courseModelStdList = res.standardLi;
                    _this.courseModelBatchList = res.batchLi;
                    _this.courseModelSubList = [];
                }
                else if (_this.fetchMasterBatchModule.standard_id != '-1' && _this.fetchMasterBatchModule.subject_id == '-1') {
                    _this.courseModelBatchList = res.batchLi;
                    _this.courseModelSubList = res.subjectLi;
                }
                else if (_this.fetchMasterBatchModule.standard_id != '-1' && _this.fetchMasterBatchModule.subject_id != '-1') {
                    _this.courseModelStdList = res.standardLi;
                    _this.courseModelBatchList = res.batchLi;
                }
            });
            this.getWeekOfDaysFromServer();
        } /* Course Model */
        else {
            /* Get in class schedule || course planner || Time Table */
            this.classService.getAllSubBranches().subscribe(function (res) {
                _this.subBranch = res;
            }, function (err) { });
            /* Get in class schedule || course planner || Time Table*/
            this.classService.getAllMasterCourse().subscribe(function (res) {
                _this.masterCourse = res;
            }, function (err) { });
            /* Get in class schedule || Time Table*/
            this.classService.getAllTeachers().subscribe(function (res) {
                _this.teachers = res;
            }, function (err) { });
        }
        return this.classService.getInstituteSettings().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.instituteSetting = res;
        }, function (err) { });
    };
    ClassAddComponent.prototype.updateCourseList = function (ev) {
        var _this = this;
        this.isRippleLoad = true;
        this.isClassFormFilled = false;
        this.classService.getCourseFromMasterById(ev).subscribe(function (res) {
            if (res.coursesList) {
                _this.courseList = res.coursesList;
                _this.isRippleLoad = false;
            }
            else {
                _this.courseList = [];
                _this.isRippleLoad = false;
            }
        }, function (err) {
            _this.courseList = [];
            _this.isRippleLoad = false;
        });
    };
    ClassAddComponent.prototype.submitMasterCourse = function () {
        if (this.fetchMasterCourseModule.master_course == '-1' || this.fetchMasterCourseModule.course_id == '-1' ||
            this.fetchMasterCourseModule.requested_date == '' || this.fetchMasterCourseModule.requested_date == 'Invalid date'
            || this.fetchMasterCourseModule.requested_date == null) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter all mandatory details');
            return;
        }
        else {
            if (__WEBPACK_IMPORTED_MODULE_2_moment__(this.courseStartDate).format("YYYY-MM-DD") <= __WEBPACK_IMPORTED_MODULE_2_moment__(this.fetchMasterCourseModule.requested_date).format("YYYY-MM-DD") && __WEBPACK_IMPORTED_MODULE_2_moment__(this.fetchMasterCourseModule.requested_date).format("YYYY-MM-DD") <= __WEBPACK_IMPORTED_MODULE_2_moment__(this.courseEndDate).format("YYYY-MM-DD")) {
                this.isClassFormFilled = true;
                this.fetchMasterCourseModule.requested_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.fetchMasterCourseModule.requested_date).format("YYYY-MM-DD");
                this.getAllSubjectListFromServer(this.fetchMasterCourseModule);
                this.getCustomList();
                this.getTeacherList();
            }
            else {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please provides date in between course start and end date');
                return;
            }
        }
    };
    ClassAddComponent.prototype.updateSubjectList = function (ev) {
        var _this = this;
        this.isRippleLoad = true;
        this.isClassFormFilled = false;
        this.fetchMasterBatchModule.subject_id = '-1';
        this.classService.getStandardSubjectList(ev, this.fetchMasterBatchModule.subject_id, this.fetchMasterBatchModule.assigned).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.courseModelBatch = res;
            if (ev == '-1') {
                if (_this.fetchMasterBatchModule.subject_id == "-1") {
                    _this.courseModelStdList = res.standardLi;
                    _this.courseModelBatchList = res.batchLi;
                    _this.fetchMasterBatchModule.batch_id = "-1";
                    _this.fetchMasterBatchModule.subject_id = "-1";
                    _this.courseModelSubList = [];
                }
                else {
                    _this.courseModelBatchList = res.batchLi;
                    _this.fetchMasterBatchModule.batch_id = "-1";
                    _this.fetchMasterBatchModule.subject_id = "-1";
                    _this.courseModelSubList = [];
                }
            }
            else if (ev != '-1') {
                if (_this.fetchMasterBatchModule.subject_id == '-1') {
                    _this.fetchMasterBatchModule.batch_id = "-1";
                    _this.fetchMasterBatchModule.subject_id = "-1";
                    _this.courseModelBatchList = res.batchLi;
                    _this.courseModelSubList = res.subjectLi;
                }
                else if (_this.fetchMasterBatchModule.subject_id != '-1') {
                    _this.fetchMasterBatchModule.batch_id = "-1";
                    _this.fetchMasterBatchModule.subject_id = "-1";
                    _this.courseModelBatchList = res.batchLi;
                    _this.courseModelSubList = res.subjectLi;
                }
            }
        });
    };
    ClassAddComponent.prototype.submitMasterBatch = function () {
        /* standard selected */
        if (this.fetchMasterBatchModule.standard_id != '-1' && this.fetchMasterBatchModule.standard_id != -1 && this.fetchMasterBatchModule.standard_id != undefined) {
            /* subject selected  */
            if (this.fetchMasterBatchModule.subject_id != '-1' && this.fetchMasterBatchModule.subject_id != undefined) {
                /* batch selected */
                /* Success */
                /*  */
                if (this.fetchMasterBatchModule.batch_id != '-1' && this.fetchMasterBatchModule.batch_id != undefined) {
                    this.batchDetected(this.fetchMasterBatchModule.batch_id);
                }
                else if (this.fetchMasterBatchModule.batch_id == '-1' || this.fetchMasterBatchModule.batch_id == undefined) {
                    this.msgService.showErrorMessage(this.msgService.toastTypes.error, this.messages.batchMsg.notSelect, 'Please select valid input');
                }
            }
            else if (this.fetchMasterBatchModule.subject_id == '-1' || this.fetchMasterBatchModule.subject_id == undefined) {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, this.messages.batchMsg.inValid, 'Please select valid input');
            }
        }
        else if (this.fetchMasterBatchModule.standard_id == '-1' || this.fetchMasterBatchModule.standard_id == undefined) {
            /* subject selected  */
            if (this.fetchMasterBatchModule.subject_id != '-1' && this.fetchMasterBatchModule.subject_id != undefined) {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, this.messages.batchMsg.notStandard, 'Please select valid input');
            }
            else if (this.fetchMasterBatchModule.subject_id == '-1' || this.fetchMasterBatchModule.subject_id == undefined) {
                /* batch selected */
                /* Success */
                /*  */
                if (this.fetchMasterBatchModule.batch_id != '-1' && this.fetchMasterBatchModule.batch_id != undefined) {
                    this.batchDetected(this.fetchMasterBatchModule.batch_id);
                }
                else if (this.fetchMasterBatchModule.batch_id == '-1' || this.fetchMasterBatchModule.batch_id == undefined) {
                    this.msgService.showErrorMessage(this.msgService.toastTypes.error, this.messages.batchMsg.selectAll, 'Please select valid input');
                }
            }
        }
    };
    ClassAddComponent.prototype.filterSubjectBatches = function (ev) {
        var _this = this;
        console.log(ev);
        this.isRippleLoad = true;
        this.classService.getStandardSubjectList(this.fetchMasterBatchModule.standard_id, ev, this.fetchMasterBatchModule.assigned).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.courseModelBatch = res;
            if (_this.fetchMasterBatchModule.standard_id == '-1' && _this.fetchMasterBatchModule.subject_id == '-1') {
                _this.courseModelStdList = res.standardLi;
                _this.courseModelBatchList = res.batchLi;
                _this.courseModelSubList = [];
            }
            else if (_this.fetchMasterBatchModule.standard_id != '-1' && _this.fetchMasterBatchModule.subject_id == '-1') {
                _this.courseModelBatchList = res.batchLi;
                _this.courseModelSubList = res.subjectLi;
            }
            else if (_this.fetchMasterBatchModule.standard_id != '-1' && _this.fetchMasterBatchModule.subject_id != '-1') {
                _this.courseModelBatchList = res.batchLi;
            }
            else {
            }
            _this.getSubjectName(ev);
        }, function (err) {
        });
    };
    ClassAddComponent.prototype.getSubjectName = function (ev) {
        this.selectedSubjectInBatch = '';
        this.selectedSubjectInBatch = this.courseModelSubList.find(function (elem) { return elem.subject_id == ev; }).subject_name;
    };
    ClassAddComponent.prototype.batchUpdated = function (ev) {
        this.isClassFormFilled = false;
        /* standard not selected */
        if (this.fetchMasterBatchModule.standard_id == '-1' || this.fetchMasterBatchModule.standard_id == undefined || this.fetchMasterBatchModule.standard_id == null) {
            /* subject not selected */
            if (this.fetchMasterBatchModule.subject_id == '-1' || this.fetchMasterBatchModule.subject_id == undefined ||
                this.fetchMasterBatchModule.subject_id == null) {
                /* batch not selected */
                if (this.fetchMasterBatchModule.batch_id == '-1' || this.fetchMasterBatchModule.batch_id == undefined || this.fetchMasterBatchModule.batch_id == null) {
                } /* batch selected */
                else {
                }
            }
        }
        else {
            /* subject not selected */
            if (this.fetchMasterBatchModule.subject_id == '-1' || this.fetchMasterBatchModule.subject_id == undefined || this.fetchMasterBatchModule.subject_id == null) {
                /* batch not selected */
                if (this.fetchMasterBatchModule.batch_id == '-1' || this.fetchMasterBatchModule.batch_id == undefined || this.fetchMasterBatchModule.batch_id == null) {
                } /* batch selected */
                else {
                }
            }
            else {
                /* batch not selected */
                if (this.fetchMasterBatchModule.batch_id == '-1' || this.fetchMasterBatchModule.batch_id == undefined || this.fetchMasterBatchModule.batch_id == null) {
                } /* batch selected */
                else {
                }
            }
        }
    };
    ClassAddComponent.prototype.getMasterCourse = function () {
        var _this = this;
        if (this.isProfessional) {
            /* Only Batch selected */
            if (this.fetchMasterBatchModule.standard_id == '-1' || this.fetchMasterBatchModule.standard_id == undefined) {
                var temp_1;
                this.courseModelBatchList.forEach(function (e) {
                    if (e.batch_id == _this.fetchMasterBatchModule.batch_id) {
                        temp_1 = e.batch_name;
                    }
                });
                return temp_1;
            } /* Both std subject and batch selected */
            else {
                var temp_2;
                this.courseModelStdList.forEach(function (e) {
                    if (e.standard_id == _this.fetchMasterBatchModule.standard_id) {
                        temp_2 = e.standard_name;
                    }
                });
                return temp_2;
            }
        }
        else {
            var temp_3;
            this.masterCourse.forEach(function (e) {
                if (e.master_course == _this.fetchMasterCourseModule.master_course) {
                    temp_3 = e.master_course;
                }
            });
            return temp_3;
        }
    };
    ClassAddComponent.prototype.getCourseName = function () {
        var _this = this;
        if (this.isProfessional) {
            var temp_4 = '';
            this.courseModelSubList.forEach(function (e) { if (e.subject_id == _this.fetchMasterBatchModule.subject_id) {
                temp_4 = e.subject_name;
            } });
            return temp_4;
        }
        else {
            var temp_5 = '';
            this.courseList.forEach(function (e) { if (e.course_id == _this.fetchMasterCourseModule.course_id) {
                temp_5 = e.course_name;
            } });
            return temp_5;
        }
    };
    ClassAddComponent.prototype.batchDetected = function (id) {
        var _this = this;
        this.isRippleLoad = true;
        this.classService.getBatchDetailsById(id).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.isClassFormFilled = true;
            _this.batchDetails = _this.keepCloning(res);
            _this.calculateFieldForTables(res);
        }, function (err) {
            //console.log(err);
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassAddComponent.prototype.updateClassFrequency = function (ev) {
        if (ev == "OTHER") {
            this.createCustomSchedule = true;
        }
        else {
            this.createCustomSchedule = false;
        }
    };
    ClassAddComponent.prototype.getAllSubjectListFromServer = function (data) {
        var _this = this;
        this.isClassFormFilled = true;
        this.isRippleLoad = true;
        this.fetchMasterCourseModule.requested_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.fetchMasterCourseModule.requested_date).format('YYYY-MM-DD');
        this.classService.getAllSubjectlist(this.fetchMasterCourseModule).subscribe(function (res) {
            _this.fetchedCourseData = res;
            _this.isRippleLoad = false;
            _this.subjectListDataSource = _this.getSubjectList(res);
            _this.classScheduleArray = _this.constructJSONForTable(res);
        }, function (err) {
            //console.log(err);
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassAddComponent.prototype.constructJSONForTable = function (data) {
        var courseScheduleList = [];
        var batchesList = [];
        var arr = [];
        batchesList = data.coursesList[0].batchesList;
        if (data.coursesList[0].courseClassSchdList != null) {
            courseScheduleList = data.coursesList[0].courseClassSchdList;
            for (var i = 0; i < courseScheduleList.length; i++) {
                for (var j = 0; j < batchesList.length; j++) {
                    if (courseScheduleList[i].batch_id == batchesList[j].batch_id) {
                        var obj = {};
                        obj.class_schedule_id = courseScheduleList[i].class_schedule_id;
                        obj.custom_class_type = courseScheduleList[i].custom_class_type;
                        obj.start_time = courseScheduleList[i].start_time;
                        obj.end_time = courseScheduleList[i].end_time;
                        obj.duration = courseScheduleList[i].duration;
                        obj.subject_name = courseScheduleList[i].subject_name;
                        obj.subject_id = courseScheduleList[i].subject_id;
                        obj.teacher_id = courseScheduleList[i].alloted_teacher_id;
                        obj.batch_id = courseScheduleList[i].batch_id;
                        obj.class_desc = courseScheduleList[i].class_desc;
                        obj.room_no = courseScheduleList[i].room_no;
                        obj.course_id = data.coursesList[0].course_id;
                        obj.start_date = __WEBPACK_IMPORTED_MODULE_2_moment__(data.coursesList[0].start_date).format('YYYY-MM-DD');
                        obj.end_date = __WEBPACK_IMPORTED_MODULE_2_moment__(data.coursesList[0].end_date).format('YYYY-MM-DD');
                        obj.is_attendance_marked = courseScheduleList[i].is_attendance_marked;
                        obj.topics_covered = courseScheduleList[i].topics_covered;
                        arr.push(obj);
                    }
                }
            }
        }
        return arr;
    };
    ClassAddComponent.prototype.getClassSchedule = function (data) {
        var obj = [];
        if (data.courseClassSchdList != null) {
            obj = data.courseClassSchdList;
        }
        return obj;
    };
    ClassAddComponent.prototype.getCustomList = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.classService.getCustomClassListFromServer().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.customListDataSource = res;
        }, function (err) {
            //console.log(err);
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassAddComponent.prototype.getTeacherList = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.classService.getAllActiveTeachersList().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.teacherListDataSource = res;
        }, function (err) {
            //console.log(err);
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassAddComponent.prototype.clearClassScheduleForm = function () {
        this.addClassDetails = {
            batch_id: '',
            subject_id: '',
            subject_name: '',
            start_hour: '12 PM',
            start_minute: '00',
            start_meridian: '',
            end_hour: '1 PM',
            end_minute: '00',
            end_meridian: '',
            teacher_id: '',
            teacher_name: '',
            class_desc: '',
            room_no: '',
            custom_class_type: 'Regular',
            duration: ''
        };
        this.checkedKeys = [];
        this.selectAllTopics = false;
        // this.topicsData = "";
    };
    ClassAddComponent.prototype.onSubjectSelection = function (event) {
        var _this = this;
        this.subjectListDataSource.forEach(function (ele) {
            if (ele.subject_id == event) {
                _this.addClassDetails.teacher_id = ele.teacher_id;
                return;
            }
        });
    };
    ClassAddComponent.prototype.topicListing = function () {
        var _this = this;
        if (this.addClassDetails.subject_id == '' || this.addClassDetails.subject_id == null || this.addClassDetails.subject_id == '-1') {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please Select Subject');
            return;
        }
        else {
            if (!this.isRippleLoad) {
                this.isRippleLoad = true;
                this.topicService.getAllTopicsSubTopics(this.addClassDetails.subject_id).subscribe(function (res) {
                    var temp;
                    temp = res;
                    if (temp != null && temp.length != 0) {
                        _this.topicBox = false;
                        console.log(res);
                        _this.isRippleLoad = false;
                        _this.topicsData = res;
                        var subjectName_1 = "";
                        _this.subjectListDataSource.forEach(function (ele) {
                            if (ele.subject_id == _this.addClassDetails.subject_id) {
                                subjectName_1 = ele.subject_name;
                            }
                        });
                        document.getElementById("topicSubName").innerHTML = subjectName_1;
                        _this.children = function (dataItem) { return Object(__WEBPACK_IMPORTED_MODULE_3_rxjs_observable_of__["a" /* of */])(dataItem.subTopic); };
                        _this.hasChildren = function (item) { return item.subTopic && item.subTopic.length > 0; };
                    }
                    else {
                        _this.isRippleLoad = false;
                        _this.msgService.showErrorMessage(_this.msgService.toastTypes.info, 'Info', "No topics available to Link");
                    }
                }, function (err) {
                    _this.isRippleLoad = false;
                    _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
                });
            }
        }
    };
    ClassAddComponent.prototype.fetchTopics = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.totalTopicsList = [];
        this.topicService.getAllTopicsSubTopics(this.fetchMasterBatchModule.subject_id).subscribe(function (resp) {
            _this.topicsList = [];
            _this.topicsList = resp;
            if (_this.topicsList.length && _this.topicsList != null) {
                _this.showTopicsModal = true;
                _this.isRippleLoad = false;
                _this.topicsList.forEach(function (tpc) {
                    _this.totalTopicsList.push(tpc);
                    tpc.checked = false;
                    if (tpc.subTopic.length) {
                        _this.getAllTopics(tpc.subTopic);
                    }
                });
            }
            else {
                _this.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.info, 'Info', "No topics available to Link");
            }
        }, function (err) {
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassAddComponent.prototype.getAllTopics = function (topic) {
        var _this = this;
        topic.forEach(function (obj) {
            _this.totalTopicsList.push(obj);
            obj.checked = false;
            if (obj.subTopic.length) {
                _this.getAllTopics(obj.subTopic);
            }
        });
    };
    ClassAddComponent.prototype.selectTopics = function (topic, event) {
        topic.checked = !topic.checked;
        if (topic.subTopic.length) {
            this.checkAllSubTopics(topic.subTopic, event.target.checked);
        }
        if (!event.target.checked) {
            if (topic.parentTopicId != 0) {
                this.uncheckParent(topic);
            }
        }
        this.checkParents(topic);
    };
    //uncheck parent if any of the child is deselected
    ClassAddComponent.prototype.uncheckParent = function (topic) {
        var getParentTopic = this.totalTopicsList.find(function (obj) { return obj.topicId == topic.parentTopicId; });
        if (getParentTopic != undefined) {
            getParentTopic.checked = false;
            if (getParentTopic.parentTopicId != 0) {
                this.uncheckParent(getParentTopic);
            }
        }
    };
    //check parent if all subtopics are checked
    ClassAddComponent.prototype.checkParents = function (topic) {
        var checkAll = true;
        if (this.totalTopicsList.find(function (el) { return el.topicId == topic.topicId; }) != undefined) {
            var parentTopic = this.totalTopicsList.find(function (ele) { return ele.topicId == topic.parentTopicId; });
            if (parentTopic != undefined) {
                if (parentTopic.subTopic.length) {
                    parentTopic.subTopic.forEach(function (subTpc) {
                        if (!subTpc.checked) {
                            checkAll = false;
                        }
                    });
                    if (checkAll) {
                        parentTopic.checked = true;
                        if (parentTopic.parentTopicId != 0) {
                            this.checkParents(parentTopic);
                        }
                    }
                }
            }
        }
    };
    ClassAddComponent.prototype.fetchSelectedTopics = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.showTopicsModal = true;
        this.selectedTopicsListObj.forEach(function (obj) {
            var getTopicObject = _this.totalTopicsList.find(function (ele) { return ele.topicId == obj.topicId; });
            getTopicObject.checked = true;
        });
        this.isRippleLoad = false;
    };
    ClassAddComponent.prototype.saveSelectedTopics = function () {
        /* if(this.totalTopicsList.filter(el => el.checked == true).length == 0){
          this.msgService.showErrorMessage(this.msgService.toastTypes.info, 'Info', "No topics selected");
        }
        else { */
        this.isRippleLoad = true;
        this.selectedTopicsListObj = [];
        this.selectedTopicsListObj = this.totalTopicsList.filter(function (obj) { return obj.checked == true; });
        if (this.selectedTopicsListObj != undefined) {
            this.selectedTopics = this.selectedTopicsListObj.map(function (obj) {
                return obj.topicId;
            });
            this.selectedTopics = this.selectedTopics.join('|');
            this.selectedTopicsNames = this.selectedTopicsListObj.map(function (obj) {
                return obj.topicName;
            });
            this.selectedTopicsNames = this.selectedTopicsNames.join(',');
        }
        this.msgService.showErrorMessage(this.msgService.toastTypes.success, '', "Topics linked successfully!");
        this.isRippleLoad = false;
        this.showTopicsModal = false;
        // }
    };
    // check/uncheck all subtopics if parent is checked/unchecked
    ClassAddComponent.prototype.checkAllSubTopics = function (topic, param) {
        var _this = this;
        topic.forEach(function (obj) {
            if (param) {
                obj.checked = true;
            }
            else {
                obj.checked = false;
            }
            if (obj.subTopic.length) {
                _this.checkAllSubTopics(obj.subTopic, param);
            }
        });
    };
    ClassAddComponent.prototype.closeTopicModal = function () {
        this.showTopicsModal = false;
    };
    ClassAddComponent.prototype.toggleArrow = function (topic) {
        topic.isExpand = !(topic.isExpand);
    };
    ClassAddComponent.prototype.linkTopics = function () {
        var _this = this;
        /* if(this.totalTopicsList.filter(el => el.checked == true).length == 0){
          this.msgService.showErrorMessage(this.msgService.toastTypes.info, 'Info', "No topics selected");
        }
        else { */
        this.isRippleLoad = true;
        var getSelectedTopics = this.totalTopicsList.filter(function (el) { return el.checked == true; });
        var getTopicIds;
        if (getSelectedTopics != undefined) {
            getTopicIds = getSelectedTopics.map(function (obj) {
                return obj.topicId;
            });
            getTopicIds = getTopicIds.join('|');
            this.getSubjectObject.topics_covered = getTopicIds;
            if (this.batchFrequency == 2) {
                this.customTable.find(function (ele) { return ele.schd_id == _this.getSubjectObject.schd_id; }).topics_covered = getTopicIds;
            }
            else {
                this.extraClassTable.find(function (ele) { return ele.schd_id == _this.getSubjectObject.schd_id; }).topics_covered = getTopicIds;
            }
        }
        this.msgService.showErrorMessage('success', '', "Topics updated successfully");
        this.showTopicsModal = false;
        this.isRippleLoad = false;
        //}
    };
    ClassAddComponent.prototype.editTopics = function (row) {
        var _this = this;
        console.log('inside edit topics:', row);
        this.getSubjectObject = '';
        this.getSubjectObject = row;
        this.isRippleLoad = true;
        if (row.topics_covered != '' && row.topics_covered != null) {
            var selectedTopicIds = row.topics_covered.split('|');
        }
        var list = [];
        this.topicService.getAllTopicsSubTopics(this.fetchMasterBatchModule.subject_id).subscribe(function (res) {
            _this.topicsList = [];
            _this.topicsList = res;
            if (_this.topicsList != null && _this.topicsList.length) {
                _this.showTopicsModal = true;
                _this.showCustomEditModal = true;
                _this.isRippleLoad = false;
                _this.topicsList.forEach(function (obj) {
                    list.push(obj);
                    if (selectedTopicIds != undefined) {
                        if (selectedTopicIds.indexOf((obj.topicId).toString()) > -1) {
                            obj.checked = true;
                        }
                    }
                    if (obj.subTopic.length) {
                        _this.fetchAllTopics(obj.subTopic, list, selectedTopicIds);
                    }
                });
                _this.totalTopicsList = [];
                _this.totalTopicsList = list;
            }
            else {
                _this.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, 'Error', "No topics available to Link");
            }
        }, function (err) {
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, 'Error', err.error.message);
        });
    };
    ClassAddComponent.prototype.fetchAllTopics = function (topic, list, idList) {
        var _this = this;
        topic.forEach(function (key) {
            if (idList != undefined && idList != null) {
                if (idList.indexOf((key.topicId).toString()) > -1) {
                    key.checked = true;
                }
            }
            list.push(key);
            if (key.subTopic.length) {
                _this.fetchAllTopics(key.subTopic, list, idList);
            }
        });
    };
    ClassAddComponent.prototype.topicListingForAlreadyLinkedTopics = function (row, subject_id, preSelectedTopics) {
        var _this = this;
        this.addLinkStatus = '';
        this.selectedSubId = subject_id;
        this.selectedRow = row;
        this.topicsData = [];
        if (!this.isRippleLoad) {
            this.isRippleLoad = true;
            this.topicService.getAllTopicsSubTopics(subject_id).subscribe(function (res) {
                var temp;
                temp = res;
                if (temp != null && temp.length != 0) {
                    _this.checkedKeys = [];
                    _this.topicBox = false;
                    console.log(res);
                    _this.isRippleLoad = false;
                    _this.topicsData = res;
                    var array = _this.selectedRow.topics_covered.split("|"); //add selected array data
                    array.forEach(function (value) {
                        if (value != " " || value != "0") {
                            _this.checkedKeys.push(Number(value));
                        }
                    });
                    _this.subject_name = _this.selectedRow.subject_name;
                    _this.children = function (dataItem) { return Object(__WEBPACK_IMPORTED_MODULE_3_rxjs_observable_of__["a" /* of */])(dataItem.subTopic); };
                    _this.hasChildren = function (item) { return item.subTopic && item.subTopic.length > 0; };
                }
                else {
                    _this.isRippleLoad = false;
                    _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', "No topics available to Link");
                }
            }, function (err) {
                _this.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            });
        }
    };
    ClassAddComponent.prototype.checkAllTopics = function () {
        var _this = this;
        if (this.selectAllTopics) {
            this.checkedKeys = [];
            this.topicsData.forEach(function (ele) {
                _this.checkedKeys.push(ele.topicId);
            });
            // this.topicsData.forEach(function(entry){
            // console.log(entry.topicName)
            // } );
            //
            // const iterate = (obj) => {
            //     Object.keys(obj).forEach(key => {
            //
            //     console.log(`key: ${key}, value: ${obj[key]}`)
            //
            //     if (typeof obj[key] === 'object') {
            //             iterate(obj[key])
            //         }
            //     })
            // }
        }
        else {
            this.checkedKeys = [];
        }
    };
    ClassAddComponent.prototype.saveTopic = function () {
        var _this = this;
        if (this.selectedSubId != null && this.selectedSubId != undefined && this.selectedSubId != "") {
            var temp = this.checkedKeys;
            this.selectedRow.topics_covered = temp.join("|");
            var topicsName_1 = [];
            this.checkedKeys.forEach(function (ele) {
                _this.topicsData.forEach(function (e) {
                    if (ele == e)
                        topicsName_1.push(e.topicName);
                });
            });
            this.checkedKeys = [];
            this.selectedSubId = "";
            this.selectedRow = "";
        }
        else {
            if (this.checkedKeys.length > 0) {
                this.addLinkStatus = 'linked';
            }
            else {
                this.addLinkStatus = '';
            }
        }
        this.topicBox = true;
    };
    ClassAddComponent.prototype.closeAlert = function () {
        this.checkedKeys = [];
        this.topicBox = true;
        this.selectedSubId = "";
    };
    ClassAddComponent.prototype.addClassSchedule = function () {
        var _this = this;
        this.addLinkStatus = '';
        var obj = {};
        if (this.addClassDetails.subject_id == '' || this.addClassDetails.subject_id == null || this.addClassDetails.subject_id == '-1') {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please Select Subject');
            return;
        }
        else {
            obj.subject_id = this.addClassDetails.subject_id;
        }
        obj.class_schedule_id = 0;
        if (this.addClassDetails.custom_class_type == "" || this.addClassDetails.custom_class_type == null) {
            obj.custom_class_type = "Regular";
        }
        else {
            obj.custom_class_type = this.addClassDetails.custom_class_type;
        }
        this.timeChanges(this.addClassDetails.start_hour, "addClassDetails.start_hour");
        this.timeChanges(this.addClassDetails.end_hour, "addClassDetails.end_hour");
        if (this.addClassDetails.start_hour == "" && this.addClassDetails.start_minute == "") {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter correct start time');
            return;
        }
        if (this.addClassDetails.end_hour == "" && this.addClassDetails.end_minute == "") {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter correct end time');
            return;
        }
        var startTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.addClassDetails.start_hour + ':' + this.addClassDetails.start_minute + this.addClassDetails.start_meridian, 'h:mma');
        var endTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.addClassDetails.end_hour + ':' + this.addClassDetails.end_minute + this.addClassDetails.end_meridian, 'h:mma');
        if (!(startTime.isBefore(endTime))) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter correct start time and end time');
            this.convertTimeToBindableFormat();
            return;
        }
        else {
            obj.start_time = this.addClassDetails.start_hour + ':' + this.addClassDetails.start_minute + ' ' + this.addClassDetails.start_meridian;
            obj.end_time = this.addClassDetails.end_hour + ':' + this.addClassDetails.end_minute + ' ' + this.addClassDetails.end_meridian;
        }
        startTime = this.convertIntoFullClock(this.addClassDetails.start_hour, this.addClassDetails.start_minute, this.addClassDetails.start_meridian);
        endTime = this.convertIntoFullClock(this.addClassDetails.end_hour, this.addClassDetails.end_minute, this.addClassDetails.end_meridian);
        obj.duration = this.getDifference(startTime, endTime);
        obj.subject_name = this.getValueFromArray(this.subjectListDataSource, 'subject_id', obj.subject_id, 'subject_name');
        if (this.addClassDetails.teacher_id == "" || this.addClassDetails.teacher_id == '-1') {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter correct teacher name');
            this.convertTimeToBindableFormat();
            return;
        }
        else {
            obj.teacher_id = Number(this.addClassDetails.teacher_id);
        }
        obj.batch_id = this.getBatchID(obj.subject_id);
        obj.class_desc = this.addClassDetails.class_desc;
        obj.room_no = this.addClassDetails.room_no;
        var topicsName = [];
        this.checkedKeys.forEach(function (ele) {
            _this.topicsData.forEach(function (e) {
                if (ele == e.topicId)
                    topicsName.push(e.topicName);
            });
        });
        console.log(topicsName);
        var tempKeys = this.checkedKeys;
        obj.topics_covered = tempKeys.join("|");
        this.classScheduleArray.push(obj);
        this.checkedKeys = [];
        this.clearClassScheduleForm();
    };
    ClassAddComponent.prototype.convertTimeToBindableFormat = function () {
        this.addClassDetails.start_hour = this.addClassDetails.start_hour + ' ' + this.addClassDetails.start_meridian;
        this.addClassDetails.start_meridian = "";
        this.addClassDetails.end_hour = this.addClassDetails.end_hour + ' ' + this.addClassDetails.end_meridian;
        this.addClassDetails.end_meridian = "";
    };
    ClassAddComponent.prototype.timeChanges = function (data, name) {
        var time = data.split(' ');
        if (name == "addClassDetails.start_hour") {
            this.addClassDetails.start_hour = time[0];
            this.addClassDetails.start_meridian = time[1];
        }
        else if (name == "addClassDetails.end_hour") {
            this.addClassDetails.end_hour = time[0];
            this.addClassDetails.end_meridian = time[1];
        }
    };
    ClassAddComponent.prototype.getBatchID = function (subject_id) {
        for (var i = 0; i < this.subjectListDataSource.length; i++) {
            if (this.subjectListDataSource[i].subject_id == subject_id) {
                return this.subjectListDataSource[i].batch_id;
            }
        }
    };
    ClassAddComponent.prototype.convertIntoFullClock = function (hr, min, meridian) {
        var result = '';
        if (meridian == "AM") {
            if (hr == "12") {
                hr = "00";
            }
            result = hr + ':' + min;
        }
        else {
            if (hr == "12") {
                hr = "12";
            }
            else {
                hr = Number(hr) + 12;
            }
            result = hr + ':' + min;
        }
        return result;
    };
    ClassAddComponent.prototype.getDifference = function (startTime, endTime) {
        var start = __WEBPACK_IMPORTED_MODULE_2_moment__["utc"](startTime, "HH:mm");
        var end = __WEBPACK_IMPORTED_MODULE_2_moment__["utc"](endTime, "HH:mm");
        if (end.isBefore(start))
            end.add(1, 'day');
        var d = __WEBPACK_IMPORTED_MODULE_2_moment__["duration"](end.diff(start));
        return d._milliseconds / 60000;
    };
    ClassAddComponent.prototype.getValueFromArray = function (data, key, compareVal, getKey) {
        var result = '';
        for (var i = 0; i < data.length; i++) {
            if (data[i][key] == compareVal) {
                result = data[i][getKey];
            }
        }
        return result;
    };
    ClassAddComponent.prototype.onCourseListSelection = function (event) {
        if (event != '-1') {
            for (var i = 0; i < this.courseList.length; i++) {
                if (this.courseList[i].course_id == event) {
                    this.courseStartDate = this.courseList[i].start_date;
                    this.courseEndDate = this.courseList[i].end_date;
                }
            }
        }
        else {
            this.courseStartDate = '';
            this.courseEndDate = '';
        }
    };
    ClassAddComponent.prototype.cancelCourseClicked = function (rowData) {
        this.showPopUpCancellation = true;
        this.cancelRowSelected = rowData;
    };
    ClassAddComponent.prototype.cancelCourseSchedule = function () {
        var _this = this;
        var dataTosend = this.makeCancelClassJson();
        if (dataTosend == false) {
            return false;
        }
        if (dataTosend != undefined) {
            this.isRippleLoad = true;
            this.classService.cancelClassSchedule(dataTosend).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Success', 'Class Cancelled Successfull');
                _this.showPopUpCancellation = false;
                _this.getAllSubjectListFromServer(_this.fetchMasterCourseModule);
            }, function (err) {
                //console.log(err);
                _this.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            });
        }
    };
    ClassAddComponent.prototype.makeCancelClassJson = function () {
        var text = document.getElementById('idTexboxReason').value;
        if (text == "" || text == null || text == undefined) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter cancellation reason');
            return false;
        }
        var chkbxValue = document.getElementById('idChkbxEnable').checked;
        if (chkbxValue == true) {
            chkbxValue = "Y";
        }
        else {
            chkbxValue = "N";
        }
        var obj = {};
        obj.batch_id = this.cancelRowSelected.batch_id;
        obj.cancelSchd = [
            {
                cancel_note: text,
                schd_id: this.cancelRowSelected.class_schedule_id,
                is_notified: chkbxValue
            }
        ];
        return obj;
    };
    ClassAddComponent.prototype.sendReminder = function () {
        var _this = this;
        if (confirm("Are you sure, You want to notify?")) {
            var obj = {};
            obj.course_id = this.fetchedCourseData.coursesList[0].course_id;
            obj.requested_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.fetchedCourseData.requested_date).format('YYYY-MM-DD');
            this.classService.sendReminderToServer(obj).subscribe(function (res) {
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Success', 'Reminder Notification sent successfully');
            }, function (err) {
                //console.log(err);
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            });
        }
        ;
    };
    ClassAddComponent.prototype.saveCourseSchedule = function () {
        var _this = this;
        if (this.classScheduleArray.length == 0) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'No Schedule to create/update');
            return;
        }
        var obj = this.makeJsonForCourseSave();
        this.isRippleLoad = true;
        this.classService.saveDataOnServer(obj).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Saved', 'Your class added successfully');
            _this.getAllSubjectListFromServer(_this.fetchMasterCourseModule);
            // this.router.navigate(['/view/course/class']);
        }, function (err) {
            _this.isRippleLoad = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassAddComponent.prototype.removeRowFromSchedule = function (index, row) {
        if (confirm("Are you sure you want to delete?")) {
            this.classScheduleArray.splice(index, 1);
        }
    };
    ClassAddComponent.prototype.makeJsonForCourseSave = function () {
        var obj = {};
        obj.master_course = this.getValueFromArray(this.masterCourse, 'master_course', this.fetchMasterCourseModule.master_course, 'master_course');
        obj.requested_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.fetchMasterCourseModule.requested_date).format("YYYY-MM-DD");
        obj.course_id = this.fetchMasterCourseModule.course_id;
        obj.coursesList = [];
        var temp = {};
        temp.course_id = this.fetchMasterCourseModule.course_id;
        temp.courseClassSchdList = [];
        for (var i = 0; i < this.classScheduleArray.length; i++) {
            var test = {};
            test.alloted_teacher_id = this.classScheduleArray[i].teacher_id;
            test.batch_id = this.classScheduleArray[i].batch_id;
            test.class_desc = this.classScheduleArray[i].class_desc;
            test.class_schedule_id = this.classScheduleArray[i].class_schedule_id;
            test.custom_class_type = this.classScheduleArray[i].custom_class_type;
            test.duration = this.classScheduleArray[i].duration;
            test.room_no = this.classScheduleArray[i].room_no;
            test.start_time = this.classScheduleArray[i].start_time;
            test.end_time = this.classScheduleArray[i].end_time;
            test.topics_covered = this.classScheduleArray[i].topics_covered;
            temp.courseClassSchdList.push(test);
        }
        obj.coursesList.push(temp);
        return obj;
    };
    ClassAddComponent.prototype.getSubjectList = function (data) {
        var obj = {};
        for (var i = 0; i < data.coursesList.length; i++) {
            if (data.coursesList[i].course_id == this.fetchMasterCourseModule.course_id) {
                return data.coursesList[i].batchesList;
            }
        }
    };
    ClassAddComponent.prototype.weeklyScheduleChange = function ($event, row) {
        this.selctedScheduledClass = row;
        this.selctedScheduledClass.startTime = this.setChangesOnTime(this.selctedScheduledClass.start_time);
        this.selctedScheduledClass.endTime = this.setChangesOnTime(this.selctedScheduledClass.end_time);
        var selectedValue = $event.target.value;
        if (selectedValue == 1) {
        }
        else if (selectedValue == 2) {
            this.selectedDatesOption();
        }
        else {
            this.customRecurrence();
        }
    };
    ClassAddComponent.prototype.setChangesOnTime = function (data) {
        var obj = {};
        var time = data.split(':');
        obj.hour = time[0] + ' ' + time[1].split(' ')[1];
        obj.minute = time[1].split(' ')[0];
        return obj;
    };
    ClassAddComponent.prototype.convertTimeToHourMinMeridian = function (data) {
        var obj = {};
        var time = data.split(':');
        obj.hour = time[0];
        obj.minute = time[1].split(' ')[0];
        obj.meridian = time[1].split(' ')[1];
        return obj;
    };
    ClassAddComponent.prototype.selectedDatesOption = function () {
        this.showPopUp = true;
        this.selectedDateArray = [];
    };
    ClassAddComponent.prototype.customRecurrence = function () {
        this.getWeeklyScheduleData();
    };
    //////// POPUP /////////////////////////
    ClassAddComponent.prototype.getWeeklyScheduleData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.classService.getWeeklySchedule(this.selctedScheduledClass.batch_id).subscribe(function (res) {
            _this.isRippleLoad = false;
            // if (res.weekSchd && (res.weekSchd.length > 0)) {
            // this.selctedScheduledClass.startTime = this.getNewTimeFormatJson(res.weekSchd[0].start_time);
            // this.selctedScheduledClass.endTime = this.getNewTimeFormatJson(res.weekSchd[0].end_time);
            _this.weekDaysList.forEach(function (element) {
                element.uiSelected = false;
                element.start_time = _this.getNewTimeFormatJson("12:00 PM");
                element.end_time = _this.getNewTimeFormatJson("1:00 PM");
            });
            if (res.weekSchd && (res.weekSchd.length > 0)) {
                for (var i = 0; i < _this.weekDaysList.length; i++) {
                    for (var l = 0; l < res.weekSchd.length; l++) {
                        if (_this.weekDaysList[i].data_key == res.weekSchd[l].day_of_week) {
                            _this.weekDaysList[i].start_time = _this.getNewTimeFormatJson(res.weekSchd[l].start_time);
                            _this.weekDaysList[i].end_time = _this.getNewTimeFormatJson(res.weekSchd[l].end_time);
                            _this.weekDaysList[i].uiSelected = true;
                        }
                    }
                }
            }
            _this.showPopUpRecurence = true;
            // }
        }, function (err) {
            _this.isRippleLoad = false;
            console.log(err);
        });
    };
    ClassAddComponent.prototype.closePopup = function () {
        this.showPopUpRecurence = false;
        this.showPopUp = false;
        this.showPopUpCancellation = false;
        if (!this.isProfessional) {
            this.getAllSubjectListFromServer(this.fetchMasterCourseModule);
        }
    };
    ClassAddComponent.prototype.onWeekDaysSelection = function (event) {
        if ((document.getElementById(event.target.id).classList).contains('l-text')) {
            document.getElementById(event.target.id).classList.remove('l-text');
            document.getElementById(event.target.id).classList.add('p-text');
        }
        else {
            document.getElementById(event.target.id).classList.add('l-text');
            document.getElementById(event.target.id).classList.remove('p-text');
        }
    };
    ClassAddComponent.prototype.radioButtonClick = function ($event) {
        this.clearSelection();
        if ($event.target.id == "idCourseEndDate") {
            this.customRec.radioEndDate.radioEndDateSelection = true;
        }
        else if ($event.target.id == "idOn") {
            this.customRec.radioOn.radioONSelection = true;
        }
        else {
            this.customRec.radioAfter.radioAfterSelection = true;
        }
    };
    ClassAddComponent.prototype.clearSelection = function () {
        this.customRec.radioEndDate.radioEndDateSelection = false;
        this.customRec.radioEndDate.radioDate = '';
        this.customRec.radioOn.radioONSelection = false;
        this.customRec.radioOn.radioOnDate = '';
        this.customRec.radioAfter.radioAfterSelection = false;
        this.customRec.radioAfter.occurenceValue = '';
    };
    ClassAddComponent.prototype.addDateToArray = function () {
        if (this.addDates.selectedDate != "" && this.addDates.selectedDate != undefined && this.addDates.selectedDate != null) {
            var obj = new Object;
            obj.selectedDate = __WEBPACK_IMPORTED_MODULE_2_moment__(this.addDates.selectedDate).format("YYYY-MM-DD");
            obj.error = '';
            this.selectedDateArray.push(obj);
            this.addDates.selectedDate = '';
            this.addDates.error = '';
        }
    };
    ClassAddComponent.prototype.removeDateToArray = function (index, row) {
        if (confirm("Are you sure you want to delete?")) {
            this.selectedDateArray.splice(index, 1);
        }
    };
    ClassAddComponent.prototype.saveCustomRecurrences = function () {
        var _this = this;
        this.multiClickDisabled = true;
        this.isRippleLoad = true;
        var JsonToSend = this.makeJsonForRecurrence();
        this.classService.saveCustomRecurrenceToServer(JsonToSend).subscribe(function (res) {
            _this.showPopUpRecurence = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Success', 'Saved Successfully');
            _this.isRippleLoad = false;
            _this.multiClickDisabled = false;
        }, function (err) {
            //console.log(err);
            _this.isRippleLoad = false;
            _this.multiClickDisabled = false;
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassAddComponent.prototype.getSelectedDaysOfWeek = function () {
        var arr = [];
        var elementArray = document.getElementsByClassName('p-text');
        for (var t = 0; t < elementArray.length; t++) {
            arr.push(elementArray[t].id.split('-')[1].trim());
        }
        return arr;
    };
    ClassAddComponent.prototype.saveSelectedDateSchedule = function () {
        var _this = this;
        if (!this.validateAllFields()) {
            return;
        }
        ;
        var jsonToSend = this.makeJsonOFSelectedDate();
        this.classService.selectedDateScheduleToServer(jsonToSend).subscribe(function (res) {
            _this.checkDatesOverLapping(res);
        }, function (err) {
            //console.log(err);
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassAddComponent.prototype.checkDatesOverLapping = function (response) {
        for (var i = 0; i < Object.keys(response.copyClassScheduleDatesMapStatusMsg).length; i++) {
            for (var t = 0; t < this.selectedDateArray.length; t++) {
                var key = Object.keys(response.copyClassScheduleDatesMapStatusMsg)[i];
                if (this.selectedDateArray[t].selectedDate == key) {
                    this.selectedDateArray[t].error = response.copyClassScheduleDatesMapStatusMsg[key];
                }
            }
        }
    };
    ClassAddComponent.prototype.validateAllFields = function () {
        if (this.selctedScheduledClass.startTime.hour == "" || this.selctedScheduledClass.startTime.minute == "") {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter valid start time');
            return false;
        }
        if (this.selctedScheduledClass.endTime.hour == "" || this.selctedScheduledClass.endTime.minute == "") {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter valid end time');
            return false;
        }
        if (this.selctedScheduledClass.subject_id == "-1" || this.selctedScheduledClass.subject_id == " ") {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter subject name');
            return false;
        }
        if (this.selctedScheduledClass.teacher_id == "-1" || this.selctedScheduledClass.teacher_id == " ") {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter teacher name');
            return false;
        }
        return true;
    };
    ClassAddComponent.prototype.makeJsonOFSelectedDate = function () {
        var obj = {};
        obj.course_id = Number(this.fetchMasterCourseModule.course_id);
        obj.courseClassSchdList = [];
        var test = {};
        test.batch_id = this.selctedScheduledClass.batch_id.toString();
        test.start_time = this.selctedScheduledClass.startTime.hour.split(' ')[0] + ':' + this.selctedScheduledClass.startTime.minute + ' ' + this.selctedScheduledClass.startTime.hour.split(' ')[1];
        test.end_time = this.selctedScheduledClass.endTime.hour.split(' ')[0] + ':' + this.selctedScheduledClass.endTime.minute + ' ' + this.selctedScheduledClass.endTime.hour.split(' ')[1];
        test.class_desc = this.selctedScheduledClass.class_desc;
        test.duration = this.getDifference(test.start_time, test.end_time);
        test.room_no = this.selctedScheduledClass.room_no;
        test.class_schedule_id = 0;
        test.alloted_teacher_id = this.selctedScheduledClass.teacher_id;
        test.custom_class_type = this.selctedScheduledClass.custom_class_type;
        obj.courseClassSchdList.push(test);
        obj.reqDateList = this.getSelectedDatesFromArray();
        return obj;
    };
    ClassAddComponent.prototype.getSelectedDatesFromArray = function () {
        var arr = [];
        if (this.selectedDateArray.length != 0) {
            for (var t = 0; t < this.selectedDateArray.length; t++) {
                if (this.selectedDateArray[t].selectedDate != "" && this.selectedDateArray[t].selectedDate != null) {
                    arr.push(this.selectedDateArray[t].selectedDate);
                }
            }
        }
        else {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter date');
            return;
        }
        return arr;
    };
    ClassAddComponent.prototype.makeJsonForRecurrence = function () {
        var weekDaysSelectedCount = 0;
        this.weekDaysList.forEach(function (element) {
            if (element.uiSelected) {
                weekDaysSelectedCount++;
            }
        });
        if (weekDaysSelectedCount == 0) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter days of week');
            return;
        }
        else {
            var obj = {};
            var seletected = false;
            obj.batch_id = this.selctedScheduledClass.batch_id;
            obj.weekSchd = [];
            for (var t = 0; t < this.weekDaysList.length; t++) {
                if (this.weekDaysList[t].uiSelected) {
                    var test = {};
                    test.day_of_week = Number(this.weekDaysList[t].data_key);
                    test.start_time = this.weekDaysList[t].start_time.hour.split(' ')[0] + ':' + this.weekDaysList[t].start_time.minute + ' ' + this.weekDaysList[t].start_time.hour.split(' ')[1];
                    ;
                    test.end_time = this.weekDaysList[t].end_time.hour.split(' ')[0] + ':' + this.weekDaysList[t].end_time.minute + ' ' + this.weekDaysList[t].end_time.hour.split(' ')[1];
                    ;
                    var duration = this.getDifference(test.start_time, test.end_time);
                    test.duration = duration;
                    var startTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.createTimeInFormat(this.weekDaysList[t].start_time.hour, this.weekDaysList[t].start_time.minute, 'comp'), 'h:mma');
                    var endTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.createTimeInFormat(this.weekDaysList[t].end_time.hour, this.weekDaysList[t].end_time.minute, 'comp'), 'h:mma');
                    if (!(startTime.isBefore(endTime))) {
                        this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter correct start time and end time');
                        return;
                    }
                    else {
                        obj.weekSchd.push(test);
                    }
                }
            }
            obj.course_id = this.selctedScheduledClass.course_id;
            obj.start_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.selctedScheduledClass.start_date).format("YYYY-MM-DD");
            obj.end_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.selctedScheduledClass.end_date).format("YYYY-MM-DD");
            obj.requested_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.fetchMasterCourseModule.requested_date).format("YYYY-MM-DD");
            obj.courseClassSchdList = [{
                    class_schedule_id: this.selctedScheduledClass.class_schedule_id
                }];
            return obj;
        }
    };
    /* =================================Batch Model=========================================================== */
    ClassAddComponent.prototype.getWeekOfDaysFromServer = function () {
        var _this = this;
        this.classService.getWeekOfDays().subscribe(function (res) {
            _this.weekDays = _this.addKeyInData(res);
        }, function (err) {
            //console.log(err);
        });
    };
    ClassAddComponent.prototype.calculateFieldForTables = function (data) {
        this.customTable = [];
        this.weekDaysTable = [];
        this.extraClassTable = [];
        this.canceLClassTable = [];
        var temp_mode = this.batchFrequency;
        this.batchFrequency = '1';
        if (data.cancelSchd != null) {
            this.canceLClassTable = data.cancelSchd;
        }
        if (data.extraSchd != null) {
            this.extraClassTable = data.extraSchd;
        }
        if (data.weekSchd != null) {
            this.weekDays.forEach(function (element) {
                element.uiSelected = false;
            });
            this.weekDaysTable = this.weekDays;
            if (data.weekSchd.length > 0) {
                this.makeJsonForWeekTable(data.weekSchd);
            }
        }
        else {
            this.weekDays.forEach(function (element) {
                element.uiSelected = false;
            });
            this.weekDaysTable = this.weekDays;
        }
        if (data.otherSchd != null) {
            if (data.otherSchd.length > 0) {
                this.customTable = data.otherSchd;
                if ((data.weekSchd && data.weekSchd.length == 0)) {
                    this.batchFrequency = '2';
                }
                else {
                    this.batchFrequency = '1';
                }
                this.scheduleSelection(this.batchFrequency);
            }
        }
    };
    ClassAddComponent.prototype.scheduleSelection = function (event) {
        this.batchFrequency = event;
        this.custom.date = __WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-DD");
    };
    /// Week Section////
    ClassAddComponent.prototype.makeJsonForWeekTable = function (data) {
        this.showCancelWeeklyBtn = false;
        this.weekDaysTable = this.weekDays;
        for (var i = 0; i < this.weekDaysTable.length; i++) {
            for (var t = 0; t < data.length; t++) {
                if (data[t].day_of_week == this.weekDaysTable[i].data_key) {
                    this.showCancelWeeklyBtn = true;
                    this.weekDaysTable[i].uiSelected = true;
                    this.weekDaysTable[i].day_of_week = data[t].day_of_week;
                    this.weekDaysTable[i].data_value = this.weekDays[i].data_value;
                    this.weekDaysTable[i].schd_id = data[t].schd_id;
                    this.weekDaysTable[i].duration = data[t].duration;
                    this.weekDaysTable[i].start_time = this.getNewTimeFormatJson(data[t].start_time);
                    this.weekDaysTable[i].end_time = this.getNewTimeFormatJson(data[t].end_time);
                }
            }
        }
    };
    ClassAddComponent.prototype.updateWeeklySchedule = function () {
        if (this.batchDetails.otherSchd != null) {
            if (this.batchDetails.otherSchd.length > 0) {
                this.showWarningPopup = true;
            }
            else {
                this.createWeeklySchedule();
            }
        }
        else {
            this.createWeeklySchedule();
        }
    };
    ClassAddComponent.prototype.createWeeklySchedule = function () {
        var data = this.prepareJSONDATA();
        if (data == false) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please specify at least one day to create a schedule');
            return;
        }
        if (this.custom.date == '') {
            data.request_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.batchDetails.batch_start_date).format("YYYY-MM-DD");
        }
        else {
            if (__WEBPACK_IMPORTED_MODULE_2_moment__(this.custom.date).valueOf() < __WEBPACK_IMPORTED_MODULE_2_moment__(this.batchDetails.batch_start_date).valueOf()) {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'selected date should be greater than or equal to batch start date ' + __WEBPACK_IMPORTED_MODULE_2_moment__(this.batchDetails.batch_start_date).format("DD-MMM-YYYY"));
                return;
            }
            else {
                data.request_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.custom.date).format("YYYY-MM-DD");
            }
        }
        if (this.batchDetails.weekSchd != null) {
            if (this.batchDetails.weekSchd.length > 0) {
                this.serverCallPUT(data);
            }
            else {
                if (this.batchDetails.otherSchd
                    && this.batchDetails.otherSchd.length > 0) {
                    this.serverCallPUT(data);
                }
                else {
                    this.serverCallPOST(data);
                }
            }
        }
        else {
            this.serverCallPOST(data);
        }
    };
    ClassAddComponent.prototype.prepareJSONDATA = function () {
        var obj = {};
        var seletected = false;
        obj.batch_id = this.batchDetails.batch_id;
        obj.class_freq = "WEEK";
        obj.weekSchd = [];
        for (var i = 0; i < this.weekDaysTable.length; i++) {
            if (this.weekDaysTable[i].uiSelected == true) {
                seletected = true;
                var test = {};
                test.day_of_week = this.weekDaysTable[i].data_key;
                var startTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.createTimeInFormat(this.weekDaysTable[i].start_time.hour, this.weekDaysTable[i].start_time.minute, 'comp'), 'h:mma');
                var endTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.createTimeInFormat(this.weekDaysTable[i].end_time.hour, this.weekDaysTable[i].end_time.minute, 'comp'), 'h:mma');
                if (!(startTime.isBefore(endTime))) {
                    this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter correct start time and end time');
                    return;
                }
                else {
                    test.start_time = this.createTimeInFormat(this.weekDaysTable[i].start_time.hour, this.weekDaysTable[i].start_time.minute, '');
                    test.end_time = this.createTimeInFormat(this.weekDaysTable[i].end_time.hour, this.weekDaysTable[i].end_time.minute, '');
                }
                startTime = this.convertToFullTimeFormat(this.weekDaysTable[i].start_time.hour, this.weekDaysTable[i].start_time.minute);
                endTime = this.convertToFullTimeFormat(this.weekDaysTable[i].end_time.hour, this.weekDaysTable[i].end_time.minute);
                test.duration = this.getDifference(startTime, endTime);
                obj.weekSchd.push(test);
            }
        }
        if (seletected == false) {
            return false;
        }
        else {
            return obj;
        }
    };
    ClassAddComponent.prototype.applyButtonClick = function () {
        var startTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.createTimeInFormat(this.mainStartTime.hour, this.mainStartTime.minute, 'comp'), 'h:mma');
        var endTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.createTimeInFormat(this.mainEndTime.hour, this.mainEndTime.minute, 'comp'), 'h:mma');
        if (!(startTime.isBefore(endTime))) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter correct start time and end time');
            return;
        }
        else {
            for (var t = 0; t < this.weekDaysTable.length; t++) {
                this.weekDaysTable[t].start_time.hour = this.mainStartTime.hour;
                this.weekDaysTable[t].start_time.minute = this.mainStartTime.minute;
                this.weekDaysTable[t].end_time.hour = this.mainEndTime.hour;
                this.weekDaysTable[t].end_time.minute = this.mainEndTime.minute;
            }
        }
    };
    ClassAddComponent.prototype.cancelWeeklyScheduledClass = function () {
        this.cancelWeeklySchedulePop = true;
    };
    ClassAddComponent.prototype.closeWeeklySchedulePopup = function () {
        this.cancelWeeklySchedulePop = false;
    };
    ClassAddComponent.prototype.cancelWeeklySchedule = function () {
        var _this = this;
        var notify = "";
        if (this.weeklyScheduleCan.is_notified == true) {
            notify = "Y";
        }
        else {
            notify = "N";
        }
        var obj = {
            batch_id: this.batchDetails.batch_id,
            class_freq: 'WEEK',
            requested_date: '',
            cancelSchd: [{
                    cancel_note: this.weeklyScheduleCan.cancel_note,
                    class_date: __WEBPACK_IMPORTED_MODULE_2_moment__(this.weeklyScheduleCan.date).format('YYYY-MM-DD'),
                    schd_id: 0,
                    is_notified: notify,
                }]
        };
        this.classService.cancelClassSchedule(obj).subscribe(function (res) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Cancelled', 'Class schedule cancelled successfully');
            _this.cancelWeeklySchedulePop = false;
            _this.updateTableDataAgain();
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            //console.log(err);
        });
    };
    /// Custom Section////
    ClassAddComponent.prototype.addNewCustomClass = function () {
        var obj = {};
        obj.class_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.custom.date).format("YYYY-MM-DD");
        if (__WEBPACK_IMPORTED_MODULE_2_moment__(this.custom.date).valueOf() < __WEBPACK_IMPORTED_MODULE_2_moment__(this.batchDetails.batch_start_date).valueOf()) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter valid date');
            return;
        }
        var startTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.createTimeInFormat(this.custom.start_hour, this.custom.start_minute, 'comp'), 'h:mma');
        var endTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.createTimeInFormat(this.custom.end_hour, this.custom.end_minute, 'comp'), 'h:mma');
        if (!(startTime.isBefore(endTime))) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter correct start time and end time');
            return;
        }
        else {
            obj.start_time = this.createTimeInFormat(this.custom.start_hour, this.custom.start_minute, '');
            obj.end_time = this.createTimeInFormat(this.custom.end_hour, this.custom.end_minute, '');
        }
        obj.note = this.custom.desc;
        obj.batch_id = this.batchDetails.batch_id;
        obj.schd_id = 0;
        obj.is_attendance_marked = 'N';
        obj.topics_covered = this.selectedTopics;
        obj.topicName = this.selectedTopicsNames;
        this.customTable.push(obj);
        this.custom = {
            date: __WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-DD"),
            start_hour: '12 PM',
            start_minute: '00',
            end_hour: '1 PM',
            end_minute: '00',
            desc: '',
            topics_covered: ''
        };
        this.selectedTopicsListObj = [];
        this.selectedTopics = '';
        this.selectedTopicsNames = '';
    };
    ClassAddComponent.prototype.deleteFromCustomTable = function (row, index) {
        if (confirm("Are you sure you want to delete?")) {
            this.customTable.splice(index, 1);
        }
    };
    ClassAddComponent.prototype.updateCustomClass = function () {
        if (this.batchDetails.weekSchd != null) {
            if (this.batchDetails.weekSchd.length > 0) {
                this.showWarningPopup = true;
            }
            else {
                this.createCustomClasses();
            }
        }
        else {
            this.createCustomClasses();
        }
        this.selectedTopics = '';
        this.selectedTopicsListObj = [];
    };
    ClassAddComponent.prototype.makeJsonForCustomClass = function () {
        var obj = {};
        obj.batch_id = this.batchDetails.batch_id.toString();
        obj.class_freq = "OTHER";
        obj.otherSchd = [];
        if (this.customTable.length > 0) {
            for (var i = 0; i < this.customTable.length; i++) {
                var t = {};
                t.class_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.customTable[i].class_date).format('YYYY-MM-DD');
                t.request_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.customTable[i].class_date).format('YYYY-MM-DD');
                t.start_time = this.customTable[i].start_time;
                t.end_time = this.customTable[i].end_time;
                t.note = this.customTable[i].note;
                t.topics_covered = this.customTable[i].topics_covered;
                t.schd_id = this.customTable[i].schd_id;
                var testStart = this.convertTimeToHourMinMeridian(t.start_time);
                var testStart1 = this.convertTimeToHourMinMeridian(t.end_time);
                var start = this.convertIntoFullClock(testStart.hour, testStart.minute, testStart.meridian);
                var end = this.convertIntoFullClock(testStart1.hour, testStart1.minute, testStart1.meridian);
                t.duration = this.getDifference(start, end);
                obj.otherSchd.push(t);
            }
        }
        return obj;
    };
    ClassAddComponent.prototype.createCustomClasses = function () {
        var obj = this.makeJsonForCustomClass();
        if (this.batchDetails.otherSchd != null) {
            if (this.batchDetails.otherSchd.length > 0) {
                this.serverCallPUT(obj);
            }
            else {
                if (this.batchDetails.weekSchd && this.batchDetails.weekSchd.length > 0) {
                    this.serverCallPUT(obj);
                }
                else {
                    this.serverCallPOST(obj);
                }
            }
        }
        else {
            this.serverCallPOST(obj);
        }
    };
    ClassAddComponent.prototype.serverCallPUT = function (data) {
        var _this = this;
        if (!this.isRippleLoad) {
            this.isRippleLoad = true;
            this.classService.createCustomBatchPUT(data).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Updated', 'Class scheduled successfully!');
                _this.showWarningPopup = false;
                _this.updateTableDataAgain();
            }, function (err) {
                _this.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
                //console.log(err);
            });
        }
    };
    ClassAddComponent.prototype.serverCallPOST = function (data) {
        var _this = this;
        if (!this.isRippleLoad) {
            this.isRippleLoad = true;
            this.classService.createWeeklyBatchPost(data).subscribe(function (res) {
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Updated', 'Class scheduled successfully!');
                _this.showWarningPopup = false;
                _this.isRippleLoad = false;
                _this.updateTableDataAgain();
            }, function (err) {
                _this.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
                //console.log(err);
            });
        }
    };
    ClassAddComponent.prototype.notifyOfCustomClass = function (data, index) {
        if (confirm('Are you sure you want to send Regular Class Schedule SMS to the batch?')) {
            this.notifyExtraClassCancel(data, "OTHER");
        }
    };
    ClassAddComponent.prototype.cancelClassOfCustomClass = function (row, index) {
        this.showPopUpCancellation = true;
        this.cancelRowSelected = row;
    };
    ///// Extra Class Section //////////////
    ClassAddComponent.prototype.addNewExtraClass = function () {
        var obj = {};
        obj.class_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.addExtraClass.date).format("YYYY-MM-DD");
        var startTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.createTimeInFormat(this.addExtraClass.start_hour, this.addExtraClass.start_minute, 'comp'), 'h:mma');
        var endTime = __WEBPACK_IMPORTED_MODULE_2_moment__(this.createTimeInFormat(this.addExtraClass.end_hour, this.addExtraClass.end_minute, 'comp'), 'h:mma');
        if (!(startTime.isBefore(endTime))) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter correct start time and end time');
            return;
        }
        else {
            obj.start_time = this.createTimeInFormat(this.addExtraClass.start_hour, this.addExtraClass.start_minute, '');
            obj.end_time = this.createTimeInFormat(this.addExtraClass.end_hour, this.addExtraClass.end_minute, '');
        }
        obj.note = this.addExtraClass.desc;
        obj.batch_id = this.batchDetails.batch_id;
        obj.schd_id = 0;
        obj.is_attendance_marked = 'N';
        obj.topics_covered = this.selectedTopics;
        this.extraClassTable.push(obj);
        this.addExtraClass = {
            date: __WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-DD"),
            start_hour: '12 PM',
            start_minute: '00',
            end_hour: '1 PM',
            end_minute: '00',
            desc: '',
            topics_covered: '',
        };
        this.selectedTopics = '';
        this.selectedTopicsListObj = [];
    };
    ClassAddComponent.prototype.updateExtraClass = function () {
        var data = this.makeJsonForExtraClass();
        if (this.batchDetails.extraSchd != null) {
            if (this.batchDetails.extraSchd.length > 0) {
                this.serverCallPUT(data);
            }
            else {
                this.serverCallPOST(data);
            }
        }
        else {
            this.serverCallPOST(data);
        }
        this.selectedTopicsListObj = [];
        this.selectedTopics = '';
    };
    ClassAddComponent.prototype.makeJsonForExtraClass = function () {
        var obj = {};
        obj.batch_id = this.batchDetails.batch_id;
        obj.class_freq = "EXTRA";
        obj.extraSchd = [];
        if (this.extraClassTable.length > 0) {
            for (var i = 0; i < this.extraClassTable.length; i++) {
                var t = {};
                t.class_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.extraClassTable[i].class_date).format('YYYY-MM-DD');
                t.request_date = __WEBPACK_IMPORTED_MODULE_2_moment__(this.extraClassTable[i].class_date).format('YYYY-MM-DD');
                t.start_time = this.extraClassTable[i].start_time;
                t.end_time = this.extraClassTable[i].end_time;
                t.note = this.extraClassTable[i].note;
                t.schd_id = this.extraClassTable[i].schd_id;
                t.topics_covered = this.extraClassTable[i].topics_covered;
                var testStart = this.convertTimeToHourMinMeridian(t.start_time);
                var testStart1 = this.convertTimeToHourMinMeridian(t.end_time);
                var start = this.convertIntoFullClock(testStart.hour, testStart.minute, testStart.meridian);
                var end = this.convertIntoFullClock(testStart1.hour, testStart1.minute, testStart1.meridian);
                t.duration = this.getDifference(start, end);
                obj.extraSchd.push(t);
            }
        }
        return obj;
    };
    ClassAddComponent.prototype.cancelExtraClassSchedule = function (row) {
        this.showPopUpCancellation = true;
        this.cancelRowSelected = row;
    };
    ClassAddComponent.prototype.notifyExtraClassSchedule = function (row) {
        if (confirm("Are you sure you want to send Extra Class Schedule SMS to the batch?")) {
            this.notifyExtraClassCancel(row, "week");
        }
    };
    ClassAddComponent.prototype.deleteExtraClassSchedule = function (row, index) {
        if (confirm("Are you sure you want to delete?")) {
            this.extraClassTable.splice(index, 1);
        }
    };
    /// Cancel Class /////
    ClassAddComponent.prototype.notifyOfCancelClass = function (row) {
        var _this = this;
        if (confirm("Are you sure, You want to notify?")) {
            var is_exam_schedule = '';
            if (row.hasOwnProperty('is_exam_schedule')) {
                is_exam_schedule = row.is_exam_schedule;
            }
            else {
                is_exam_schedule = "N";
            }
            var data = {
                batch_id: row.batch_id,
                class_schedule_id: row.schd_id,
                is_exam_schedule: is_exam_schedule
            };
            this.classService.notifyCancelledClassSchedule(data).subscribe(function (res) {
                _this.updateTableDataAgain();
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Notified', 'Notification Sent');
            }, function (err) {
                //console.log(err);
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            });
        }
    };
    /// Cancellation POpup /////////
    ClassAddComponent.prototype.cancelBatchSchedule = function () {
        var _this = this;
        var data = this.makeJSONToSendBatchDet();
        if (data == false) {
            return;
        }
        this.classService.cancelClassSchedule(data).subscribe(function (res) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Notified', 'Cancelled Successfully');
            _this.showPopUpCancellation = false;
            _this.updateTableDataAgain();
        }, function (err) {
            //console.log(err);
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ClassAddComponent.prototype.makeJSONToSendBatchDet = function () {
        var text = document.getElementById('idTexboxReason').value;
        if (text == "" || text == null || text == undefined) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please enter cancellation reason');
            return false;
        }
        var chkbxValue = document.getElementById('idChkbxEnable').checked;
        if (chkbxValue == true) {
            chkbxValue = "Y";
        }
        else {
            chkbxValue = "N";
        }
        var obj = {};
        obj.batch_id = this.cancelRowSelected.batch_id;
        obj.class_freq = this.cancelRowSelected.freq;
        obj.cancelSchd = [
            {
                cancel_note: text,
                is_notified: chkbxValue,
                schd_id: this.cancelRowSelected.schd_id,
            }
        ];
        return obj;
    };
    // Common function for notification///
    ClassAddComponent.prototype.notifyExtraClassCancel = function (row, type) {
        var _this = this;
        this.classService.sendNotification(row.schd_id, type).subscribe(function (res) {
            //console.log(res);
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Notified', 'Notification Sent');
        }, function (err) {
            //console.log(err);
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
        });
    };
    ////////////////////////////
    ClassAddComponent.prototype.showHideCommonSection = function () {
        if (this.batchFrequency == "1") {
            if (this.batchDetails.weekSchd != null) {
                if (this.batchDetails.weekSchd.length > 0) {
                    return true;
                }
                else {
                    return false;
                }
            }
            else {
                return false;
            }
        }
        else {
            if (this.batchDetails.otherSchd != null) {
                if (this.batchDetails.otherSchd.length > 0) {
                    return true;
                }
                else {
                    return false;
                }
            }
            else {
                return false;
            }
        }
    };
    ClassAddComponent.prototype.closeWarningPopUp = function () {
        this.showWarningPopup = false;
    };
    ClassAddComponent.prototype.addKeyInData = function (data) {
        data.forEach(function (element) {
            element.uiSelected = '';
            element.schd_id = '';
            element.duration = '';
            element.day_of_week = '';
            element.start_time = {
                hour: '12 PM',
                minute: '00',
            };
            element.end_time = {
                hour: '1 PM',
                minute: '00',
            };
        });
        return data;
    };
    ClassAddComponent.prototype.createTimeInFormat = function (hrMeri, minute, format) {
        var time = hrMeri.split(' ');
        if (format == "comp") {
            var t = time[0] + ":" + minute + time[1];
            return t;
        }
        else {
            var t = time[0] + ":" + minute + " " + time[1];
            return t;
        }
    };
    ClassAddComponent.prototype.getNewTimeFormatJson = function (data) {
        var time = {};
        time.hour = data.split(':')[0] + " " + data.split(' ')[1];
        time.minute = data.split(':')[1].split(' ')[0];
        return time;
    };
    ClassAddComponent.prototype.convertToFullTimeFormat = function (hr, min) {
        var result = "";
        var hour;
        var time = hr.split(' ');
        if (time[1] == "AM") {
            if (time[0] == "12") {
                hour = "00";
            }
            else {
                hour = time[0];
            }
            result = hour + ":" + min;
            return result;
        }
        else {
            if (time[0] != "12") {
                hour = Number(time[0]) + 12;
            }
            else {
                hour = Number(time[0]);
            }
            result = hour + ":" + min;
            return result;
        }
    };
    ClassAddComponent.prototype.updateTableDataAgain = function () {
        this.batchDetected(this.fetchMasterBatchModule.batch_id);
    };
    ClassAddComponent.prototype.keepCloning = function (objectpassed) {
        if (objectpassed === null || typeof objectpassed !== 'object') {
            return objectpassed;
        }
        var temporaryStorage = objectpassed.constructor();
        for (var key in objectpassed) {
            temporaryStorage[key] = this.keepCloning(objectpassed[key]);
        }
        return temporaryStorage;
    };
    // change by laxmi
    ClassAddComponent.prototype.switchActiveView = function () {
        var classArray = ['liStandard', 'liSubject', 'liExam', 'liManageBatch'];
        classArray.forEach(function (classname) {
            document.getElementById(classname).classList.remove('active');
        });
        document.getElementById('liClass').classList.add('active');
    };
    ClassAddComponent.prototype.hidePastClass = function () {
        if (__WEBPACK_IMPORTED_MODULE_2_moment__().format('YYYY-MM-DD') <= __WEBPACK_IMPORTED_MODULE_2_moment__(this.fetchMasterCourseModule.requested_date).format('YYYY-MM-DD')) {
            return true;
        }
        else {
            return false;
        }
    };
    ClassAddComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-class-add',
            template: __webpack_require__("./src/app/components/course-module/create-course/course-class/class-add/class-add.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/create-course/course-class/class-add/class-add.component.scss")],
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_4____["h" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_5__services_course_services_class_schedule_service__["a" /* ClassScheduleService */],
            __WEBPACK_IMPORTED_MODULE_6__services_course_services_topic_listing_service__["a" /* TopicListingService */],
            __WEBPACK_IMPORTED_MODULE_4____["b" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4____["i" /* MessageShowService */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"]])
    ], ClassAddComponent);
    return ClassAddComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/course-class/class-home/class-home.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<section class=\"middle-section clearFix\" style=\"padding: 5px 0px\">\r\n  <section class=\"cal-view\">\r\n    <aside class=\"boxPadding15\">\r\n      <!-- ==================================================================================== -->\r\n      <!-- ==================================================================================== -->\r\n      <!-- ========================== Header Section ========================================== -->\r\n      <section class=\"middle-top clearFix\">\r\n        <div class=\"header-container\">\r\n          <!-- <h1 class=\"pull-left\" style=\"padding-top: 5px;\">\r\n            Class Schedule\r\n          </h1> -->\r\n          <h4 style=\"padding-top: 10px;\">Choose filter to view class schedule</h4>\r\n\r\n          <div  style=\"margin-right: 15px\">\r\n            <p-button label=\"Multiple Delete\" (click)=\"deleteMultipleSchedule()\" *ngIf=\"showDeleteBTN()\" icon=\"fa fa-times\"\r\n              iconPos=\"left\"></p-button>\r\n            <input *ngIf=\"showManageClass\" type=\"button\" [routerLink]=\"['../add']\" value=\"Add/Edit Class\" class=\"btn\">\r\n          </div>\r\n        </div>\r\n\r\n      </section>\r\n      <!-- ==================================================================================== -->\r\n      <!-- ==================================================================================== -->\r\n      <!-- ========================== Body Section ============================================ -->\r\n      <section class=\"schedule-class-box\">\r\n        <!-- ==================================================================================== -->\r\n        <!-- ==================================================================================== -->\r\n        <!-- ========================== Search bar ============================================== -->\r\n        <section class=\"common-search-filter\">\r\n          <div class=\"filter-search\">\r\n            <div class=\"filter-box clearFix\" *ngIf=\"!showAdvanceFilter\">\r\n\r\n              <!-- Batch Module -->\r\n              <div class=\"search-filter-wrapper row\" *ngIf=\"isLangInstitute\">\r\n                <div class=\"row\">\r\n                  <div class=\"c-sm-10 c-md-10 c-lg-10\">\r\n                    <div class=\"c-sm-12 c-md-12 c-lg-12\">\r\n                      <div class=\"c-sm-4 c-md-4 c-lg-4\" style=\"margin-top :20px;\">\r\n                        <div class=\"radio-main\">\r\n                          <div class=\"field-radio-wrapper\">\r\n                            <input type=\"radio\" [(ngModel)]=\"selectedRadioButton\" (click)=\"checkInputType($event)\" name=\"sFilter\" class=\"form-radio\"\r\n                              value=\"All\" id=\"idAll\">\r\n                            <label for=\"idAll\">All</label>\r\n                          </div>\r\n                          <div class=\"field-radio-wrapper\">\r\n                            <input type=\"radio\" [(ngModel)]=\"selectedRadioButton\" (click)=\"checkInputType($event)\" name=\"sFilter\"\r\n                            value=\"Teacher\" class=\"form-radio\"    id=\"idTeacher\">\r\n                            <label for=\"idTeacher\">Faculty</label>\r\n                          </div>\r\n                          <div class=\"field-radio-wrapper\">\r\n                            <input type=\"radio\" [(ngModel)]=\"selectedRadioButton\" (click)=\"checkInputType($event)\" name=\"sFilter\"\r\n                            value=\"Batch\" class=\"form-radio\"   id=\"idBatch\">\r\n                            <label for=\"idBatch\">Batch</label>\r\n                          </div>\r\n                        </div>\r\n                      </div>\r\n                      <div class=\"c-sm-8 c-md-8 c-lg-8\">\r\n                        <div class=\"c-sm-4 c-md-4 c-lg-4\" *ngIf=\"selectedRadioButton == 'Teacher'\">\r\n                          <div class=\"field-wrapper fieldPro\">\r\n                            <label for=\"sc\">Select Faculty</label>\r\n                            <select id=\"sc\" class=\"form-ctrl\" [(ngModel)]=\"fetchBatchModule.teacher_id\">\r\n                              <option value=\"-1\"></option>\r\n                              <option [value]=\"subject.teacher_id\" *ngFor=\"let subject of teacherList\">\r\n                                {{subject.teacher_name}}\r\n                              </option>\r\n                            </select>\r\n                          </div>\r\n                        </div>\r\n\r\n                        <div *ngIf=\"selectedRadioButton == 'Batch'\" class=\"field-main\">\r\n                          <div class=\"c-sm-4 c-lg-4 c-sm-4\">\r\n                            <div class=\"field-wrapper\">\r\n                              <label for=\"smc\">Select Master Course</label>\r\n                              <select id=\"smc\" class=\"form-ctrl\" [(ngModel)]=\"batchData.standard_id\" (ngModelChange)=\"onBatchMasterCourseSelection($event)\">\r\n                                <option value=\"0\"></option>\r\n                                <option [value]=\"master.standard_id\" *ngFor=\"let  master of batchMasterCourse\">\r\n                                  {{master.standard_name}}\r\n                                </option>\r\n                              </select>\r\n                            </div>\r\n                          </div>\r\n\r\n                          <div class=\"c-sm-4 c-lg-4 c-sm-4\">\r\n                            <div class=\"field-wrapper\">\r\n                              <label for=\"sc\">Select Course</label>\r\n                              <select id=\"sc\" class=\"form-ctrl\" [(ngModel)]=\"batchData.subject_id\" (ngModelChange)=\"onSubjectSelection($event)\">\r\n                                <option value=\"0\"></option>\r\n                                <option [value]=\"course.subject_id\" *ngFor=\"let course of subjectListBatch\">\r\n                                  {{course.subject_name}}\r\n                                </option>\r\n                              </select>\r\n                            </div>\r\n                          </div>\r\n\r\n                          <div class=\"c-sm-4 c-lg-4 c-sm-4\">\r\n                            <div class=\"field-wrapper\">\r\n                              <label for=\"sc\">Batch</label>\r\n                              <select id=\"sc\" class=\"form-ctrl\" [(ngModel)]=\"batchData.batch_id\">\r\n                                <option value=\"0\"></option>\r\n                                <option [value]=\"subject.batch_id\" *ngFor=\"let subject of batchList\">\r\n                                  {{subject.batch_name}}\r\n                                </option>\r\n                              </select>\r\n                            </div>\r\n                          </div>\r\n\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"c-sm-2 c-md-2 c-lg-2\" style=\"margin-top: 15px\">\r\n                    <input type=\"button\" class=\"fullBlue btn\" value=\"View\" (click)=\"submitMasterCourse()\">\r\n                  </div>\r\n                </div>\r\n              </div>\r\n\r\n              <!-- Course Module -->\r\n              <div class=\"search-filter-wrapper row\" *ngIf=\"!isLangInstitute\" style=\"margin-bottom: 5px;\">\r\n                <div class=\"c-lg-9 c-md-9 c-sm-9\">\r\n                  <div class=\"row\">\r\n                    <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                      <div class=\"field-wrapper\">\r\n                        <label for=\"smc\">Select Master Course</label>\r\n                        <select id=\"smc\" class=\"form-ctrl\" [(ngModel)]=\"fetchMasterCourseModule.master_course\"\r\n                          (ngModelChange)=\"updateCourseList($event)\">\r\n                          <option value=\"-1\"></option>\r\n                          <option [value]=\"master.master_course\" *ngFor=\"let  master of masterCourse\">\r\n                            {{master.master_course}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                      <div class=\"field-wrapper\">\r\n                        <label for=\"sc\">Select Course</label>\r\n                        <select id=\"sc\" class=\"form-ctrl\" [(ngModel)]=\"fetchMasterCourseModule.course_id\"\r\n                          (ngModelChange)=\"updateSubjectList($event)\">\r\n                          <option value=\"-1\"></option>\r\n                          <option [value]=\"course.course_id\" *ngFor=\"let course of courseList.coursesList\">\r\n                            {{course.course_name}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                      <div class=\"field-wrapper\">\r\n                        <label for=\"selectsub\">Select Subject</label>\r\n                        <select id=\"selectsub\" class=\"form-ctrl\" [(ngModel)]=\"fetchMasterCourseModule.subject_id\">\r\n                          <option value=\"-1\"></option>\r\n                          <option [value]=\"subject.batch_id\" *ngFor=\"let subject of subjectList\">\r\n                            {{subject.subject_name}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n                      <div class=\"field-wrapper\">\r\n                        <label for=\"selectteacher\">Select Faculty</label>\r\n                        <select id=\"selectteacher\" class=\"form-ctrl\" [(ngModel)]=\"fetchMasterCourseModule.teacher_id\">\r\n                          <option value=\"-1\"></option>\r\n                          <option [value]=\"subject.teacher_id\" *ngFor=\"let subject of teacherList\">\r\n                            {{subject.teacher_name}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n                <div class=\"c-sm-1 c-md-1 c-lg-1\" style=\"margin-top:15px;\">\r\n                  <input type=\"button\" class=\"fullBlue btn\" value=\"View\" (click)=\"submitMasterCourse()\">\r\n                </div>\r\n                <div class=\"c-sm-2 c-md-2 c-lg-2\" style=\"margin-top:15px;\">\r\n                  <a class=\"pull-right\" style=\"cursor: pointer;\" (click)=\"showhideAdvanceFilter('1');\">Advance Filter</a>\r\n                </div>\r\n              </div>\r\n\r\n              <!-- <div class=\"row\" style=\"margin-top: 10px\">\r\n                <a class=\"pull-right advancefilter\" style=\"cursor: pointer;\" (click)=\"showhideAdvanceFilter('1');\">Advance Filter</a>\r\n              </div> -->\r\n\r\n            </div>\r\n\r\n            <div class=\"\" *ngIf=\"showAdvanceFilter\">\r\n              <p>Maximum 30 days date range filter can be applied.</p>\r\n              <div class=\"row advanceDateFilter\" style=\"margin-bottom: 5px;\">\r\n\r\n                <div class=\"c-sm-9 c-md-9 c-lg-9\">\r\n                  <div class=\"c-lg-3 c-md-3 c-sm-3\" *ngIf=\"!isLangInstitute\">\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"smc\">Select Master Course\r\n                        <span style=\"color:red\">*</span>\r\n                      </label>\r\n                      <select id=\"smc\" class=\"form-ctrl\" [(ngModel)]=\"fetchMasterCourseModule.master_course\"\r\n                        (ngModelChange)=\"updateCourseList($event)\">\r\n                        <option value=\"-1\"></option>\r\n                        <option [value]=\"master.master_course\" *ngFor=\"let  master of masterCourse\">\r\n                          {{master.master_course}}\r\n                        </option>\r\n                      </select>\r\n                    </div>\r\n                  </div>\r\n\r\n                  <div class=\"c-lg-3 c-md-3 c-sm-3\" *ngIf=\"!isLangInstitute\">\r\n                    <div class=\"field-wrapper\">\r\n                      <label for=\"sc\">Select Course\r\n                       <span class=\"text-danger\">*</span>\r\n                      </label>\r\n                      <select id=\"sc\" class=\"form-ctrl\" [(ngModel)]=\"fetchMasterCourseModule.course_id\" (ngModelChange)=\"updateSubjectList($event)\">\r\n                        <option value=\"-1\"></option>\r\n                        <option [value]=\"course.course_id\" *ngFor=\"let course of courseList.coursesList\">\r\n                          {{course.course_name}}\r\n                        </option>\r\n                      </select>\r\n                    </div>\r\n                  </div>\r\n\r\n                  <div class=\"c-lg-6 c-md-6 c-sm-6\" *ngIf=\"isLangInstitute\">\r\n                    <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n                      <div class=\"field-wrapper\">\r\n                        <label for=\"smc\" style=\"white-space: nowrap;\">Select Master Course\r\n                         <span class=\"text-danger\">*</span>\r\n                        </label>\r\n                        <select id=\"smc\" class=\"form-ctrl\" [(ngModel)]=\"batchData.standard_id\" (ngModelChange)=\"onBatchMasterCourseSelection($event)\">\r\n                          <option value=\"-1\"></option>\r\n                          <option [value]=\"master.standard_id\" *ngFor=\"let  master of batchMasterCourse\">\r\n                            {{master.standard_name}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n\r\n                    <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n                      <div class=\"field-wrapper\">\r\n                        <label for=\"sc\">Select Course\r\n                         <span class=\"text-danger\">*</span>\r\n                        </label>\r\n                        <select id=\"sc\" class=\"form-ctrl\" [(ngModel)]=\"batchData.subject_id\" (ngModelChange)=\"onSubjectSelection($event)\">\r\n                          <option value=\"-1\"></option>\r\n                          <option [value]=\"course.subject_id\" *ngFor=\"let course of subjectListBatch\">\r\n                            {{course.subject_name}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n\r\n                    <div class=\"c-lg-4 c-md-4 c-sm-4\">\r\n                      <div class=\"field-wrapper\">\r\n                        <label for=\"sc\">Batch\r\n                         <span class=\"text-danger\">*</span>\r\n                        </label>\r\n                        <select id=\"sc\" class=\"form-ctrl\" [(ngModel)]=\"batchData.batch_id\">\r\n                          <option value=\"-1\"></option>\r\n                          <option [value]=\"subject.batch_id\" *ngFor=\"let subject of batchList\">\r\n                            {{subject.batch_name}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n\r\n                  <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                    <div class=\"field-wrapper datePickerBox\">\r\n                      <label for=\"strtDate\">Start Date\r\n                       <span class=\"text-danger\">*</span>\r\n                      </label>\r\n                      <input type=\"text\" value=\"\" id=\"strtDate\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"advanceFilter.startdate\"\r\n                        readonly=\"true\" name=\"strtDate\" bsDatepicker>\r\n                    </div>\r\n                  </div>\r\n\r\n                  <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n                    <div class=\"field-wrapper datePickerBox\">\r\n                      <label for=\"endDate\">End Date\r\n                       <span class=\"text-danger\">*</span>\r\n                      </label>\r\n                      <input type=\"text\" value=\"\" id=\"endDate\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"advanceFilter.enddate\"\r\n                        readonly=\"true\" name=\"endDate\" bsDatepicker>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n\r\n                <div class=\"c-sm-1 c-md-1 c-lg-1 btn-wrapper\">\r\n                  <button class=\"btn fullBlue\" (click)=\"advanceFilterView()\">View</button>\r\n                </div>\r\n                <div class=\"c-sm-1 c-md-1 c-lg-1\">\r\n                  <a class=\"pull-right\" style=\"margin-top: 30px;cursor: pointer;\" (click)=\"showhideAdvanceFilter('0');\">Back</a>\r\n                </div>\r\n              </div>\r\n\r\n              <!-- <div class=\"row\" style=\"margin-top: 10px;\">\r\n                <a class=\"pull-right\" style=\"cursor: pointer; right: 85px;\r\n                top: 150px;\" (click)=\"showhideAdvanceFilter('0');\">Back</a>\r\n              </div> -->\r\n            </div>\r\n\r\n          </div>\r\n\r\n        </section>\r\n        <!-- ==================================================================================== -->\r\n        <!-- ==================================================================================== -->\r\n        <!-- ========================== Weeks Tabs and Navigator ================================ -->\r\n        <section class=\"calender-course clearFix view-c-detail\" *ngIf=\"showContent\">\r\n          <div class=\"row\">\r\n            <div class=\"c-lg-2 c-md-2 c-sm-2 vcd-l\">\r\n              <label>\r\n\r\n              </label>\r\n            </div>\r\n            <div class=\"c-lg-8 c-md-8 c-sm-8 align-center  vcd-l date-arrow\">\r\n              <div>\r\n                <span *ngIf=\"!showAdvanceFilter\" class=\"\">{{weekStart}} to {{weekEnd}}</span>\r\n                <span *ngIf=\"showAdvanceFilter\" class=\"\">{{advanceFilter.startdate | dateMonthYearFromat}} to\r\n                  {{advanceFilter.enddate\r\n                  | dateMonthYearFromat}}</span>\r\n              </div>\r\n            </div>\r\n            <div class=\"c-lg-2 c-md-2 c-sm-2 align-right filter-search\">\r\n            </div>\r\n          </div>\r\n          <div class=\"cal-left c-control\" *ngIf=\"!showAdvanceFilter\" (click)=\"gotoPreviousWeek()\"></div>\r\n          <div class=\"cal-right c-control\" *ngIf=\"!showAdvanceFilter\" (click)=\"gotoNextWeek()\"></div>\r\n        </section>\r\n        <!-- ==================================================================================== -->\r\n        <!-- ==================================================================================== -->\r\n        <!-- ========================== Class Schedule Table ==================================== -->\r\n\r\n        <div class=\"row\" *ngIf=\"weekScheduleList.length > 0\">\r\n          <div class=\"pull-right extra-button\">\r\n            <button class=\"btn\" (click)=\"expandAllRows()\">Expand/Collapse All</button>\r\n            <button class=\"btn\" *ngIf=\"!isChecked\" (click)=\"checkAllCheckbox()\">Check All</button>\r\n            <button class=\"btn\"  *ngIf=\"isChecked\" (click)=\"checkAllCheckbox()\">Uncheck All</button>\r\n          </div>\r\n        </div>\r\n\r\n        <section class=\"clearFix calender-view1\" >\r\n          <div class=\"table-responsive \">\r\n            <table>\r\n              <thead>\r\n                <tr>\r\n                  <th style=\"width:10%\"></th>\r\n                  <th style=\"width:10%\">Type</th>\r\n                  <th style=\"width:15%\">Subject</th>\r\n                  <th style=\"width:10%\">Start Time</th>\r\n                  <th style=\"width:10%\">End Time</th>\r\n                  <th style=\"width:15%\">Faculty</th>\r\n                  <th style=\"width:15%\">Topic</th>\r\n                  <!-- <th>Home Work</th>\r\n                  <th width=\"100 \">Status</th> -->\r\n                  <th style=\"width:15%\">Action</th>\r\n                </tr>\r\n              </thead>\r\n              <tbody id=\"tbodyItem{{i}}\" class=\"table-accor-head\" *ngFor=\"let class of weekScheduleList; let i=index;\">\r\n                <tr>\r\n                  <td colspan=\"8\">\r\n                    <div class=\"accordian-heading row\">\r\n                      <div class=\"pull-left headingDiv\" (click)=\"toggleTbodyClass(i)\" style=\"width:95%\">\r\n                        <h4 class=\"clearFix \">\r\n                          <span class=\"close-accor\">-</span>\r\n                          <span class=\"open-accor\">+</span>\r\n                          <span class=\"date-c\">{{class.id}}</span>\r\n                          <!-- <span class=\"pull-right delete-icon\" style=\"font-family: FontAwesome;\" (click)=\"delete('course', i, null)\">\r\n                                <i class=\"fa fa-trash-o \" aria-hidden=\"true\"></i>\r\n                              </span> -->\r\n                        </h4>\r\n                      </div>\r\n                      <div class=\"pull-right\" *ngIf=\"isLangInstitute == false\" style=\"width:5%\">\r\n                        <span class=\"\" (click)=\"editClass(class)\" title=\"Edit\">\r\n                          <i class=\"fas fa-edit\" style=\"font-family: FontAwesome;font-size: 20px;color: rgba(0, 0, 255, 0.49019607843137253);\"></i>\r\n                        </span>\r\n                        <span class=\"mail-notification\" *ngIf=\"hidePastClassAction(class)\" (click)=\"notify(class)\"\r\n                          title=\"Send Reminder\"></span>\r\n                      </div>\r\n                    </div>\r\n                  </td>\r\n                </tr>\r\n                <tr id=\"tbodyView{{i}}\" class=\"hide\">\r\n                  <td colspan=\"8\">\r\n                    <table>\r\n                      <tbody class=\"table-accor-view \">\r\n                        <tr *ngFor=\"let sc of class.data; let y= index;\">\r\n                          <td style=\"width:10%\">\r\n                            <div class=\"field-checkbox-wrapper\">\r\n                              <input type=\"checkbox\" name=\"uiSelected\" class=\"form-checkbox\" [(ngModel)]=\"sc.selected\"\r\n                                id=\"uiSelected{{i}}\" (ngModelChange)=\"userSelectedData($event , sc)\">\r\n                              <label ></label>\r\n                            </div>\r\n                          </td>\r\n                          <td style=\"width:10%\">{{sc.class_type}}</td>\r\n                          <td style=\"width:15%\">{{sc.subject_name}}</td>\r\n                          <td style=\"width:10%\">{{sc.start_time}}</td>\r\n                          <td style=\"width:10%\">{{sc.end_time}}</td>\r\n                          <td style=\"width:15%\" class=\"editTeacherTd\">\r\n\r\n                            <div *ngIf=\"sc.class_type != 'Exam'\" class=\"changeteacher\">\r\n                              <span id=\"teacher{{sc.schd_id}}\">{{sc.teacher_name}}\r\n                                <i (click)=\"changeTeacher(sc)\" class=\"edit-icon\" aria-hidden=\"true\" title=\"Edit\" style=\"margin-right:5px\"></i>\r\n                              </span>\r\n                              <span id=\"editTeacher{{sc.schd_id}}\" class=\"hide spanSection\">\r\n                                <div class=\"field-wrapper editSection\">\r\n                                  <select id=\"teacherList\" class=\"form-ctrl ddnChangeTeacher\" [(ngModel)]=\"allotedTeacher\">\r\n                                    <option [value]=\"subject.teacher_id\" *ngFor=\"let subject of teacherList\">\r\n                                      {{subject.teacher_name}}\r\n                                    </option>\r\n                                  </select>\r\n                                </div>\r\n                                <i (click)=\"updateTeacher(sc)\" class=\"fas fa-check\" style=\"font-family: FontAwesome ;font-size: 19px;margin-left:0px 2px\"\r\n                                  title=\"Update\"></i>\r\n                                <i (click)=\"cancelChangeTeacher(sc)\" class=\"fas fa fa-times\" style=\"font-family: FontAwesome ;font-size: 19px;\"\r\n                                  title=\"Cancel\"></i>\r\n                              </span>\r\n                            </div>\r\n\r\n                            <div *ngIf=\"sc.class_type == 'Exam'\">\r\n                              {{sc.teacher_name}}\r\n                            </div>\r\n\r\n                          </td>\r\n                          <td style=\"width:15%\">{{sc.topics_covered}}</td>\r\n                          <td style=\"width:15%\">\r\n                            <div class=\"action-box\" *ngIf=\"!isLangInstitute\">\r\n                              <span class=\"mail-notification\" *ngIf=\"hidePastClassAction(class) && sc.isAttendanceMarked == 'N'\"\r\n                                (click)=\"notifySubjectLevel(sc ,class )\" title=\"Send Reminder\"></span>\r\n                              <span class=\"reschedule-icon\" *ngIf=\"sc.isAttendanceMarked == 'N'\" (click)=\"rescheduleClassData(sc)\"\r\n                                title=\"Reschedule\"></span>\r\n                              <span class=\"delete-btn\" *ngIf=\" sc.isAttendanceMarked == 'N'\" style=\"font-family: FontAwesome;\"\r\n                                (click)=\"CancelClass(sc)\" title=\"Cancel Class\">\r\n                                <i class=\"fa fa-trash-o \" aria-hidden=\"true \"></i>\r\n                              </span>\r\n                              <!-- <span class=\"edit-icon \"></span> -->\r\n                            </div>\r\n                          </td>\r\n                        </tr>\r\n                      </tbody>\r\n                    </table>\r\n                  </td>\r\n                </tr>\r\n              </tbody>\r\n              <tbody *ngIf=\"weekScheduleList.length==0\">\r\n                <tr>\r\n                  <td colspan=\"8\">\r\n                    No Classes Found\r\n                  </td>\r\n                </tr>\r\n              </tbody>\r\n            </table>\r\n          </div>\r\n          <!-- <div class=\"fullwidth clearFix ledgend-footer \">\r\n            <label class=\"pull-left \">Ledgend</label>\r\n            <div class=\"pull-left \">\r\n              <span class=\"class-is \"></span>Class</div>\r\n            <div class=\"pull-left \">\r\n              <span class=\"exam-is \"></span>Exam</div>\r\n            <div class=\"pull-left \">\r\n              <span class=\"class-cancel blue \">x</span>Cancelled Class</div>\r\n            <div class=\"pull-left \">\r\n              <span class=\"class-cancel yellow \">x</span>Cancelled Exam</div>\r\n          </div> -->\r\n\r\n        </section>\r\n      </section>\r\n    </aside>\r\n  </section>\r\n</section>\r\n\r\n\r\n\r\n<!-- //////////////////////////////////POPUP///////////////////////////////// -->\r\n<!-- //////////////////////////////////POPUP///////////////////////////////// -->\r\n<!-- //////////////////////////////////POPUP///////////////////////////////// -->\r\n<!-- //////////////////////////////////POPUP///////////////////////////////// -->\r\n<!-- //////////////////////////////////POPUP///////////////////////////////// -->\r\n\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"reschedulePopUp\">\r\n  <div class=\"popup pos-abs popup-body-container\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closeRescheduleClass()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n          <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n            <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n              <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n            </g>\r\n            <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\"\r\n              transform=\"translate(1012 297)\" />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content\" style=\"padding-left: 15px;\">\r\n\r\n        <h2 widget-header>Reschedule - {{rescheduleDet.batchName}}</h2>\r\n\r\n        <div class=\"rescheduleWrapper\" widget-content>\r\n          <div class=\"row\">\r\n            <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n              <div class=\"field-wrapper datePickerBox\" [ngClass]=\"{'has-value': reschedDate != ''}\">\r\n                <label for=\"reschDate\" style=\"color: black\">Reschedule Date</label>\r\n                <input type=\"text\" id=\"reschDate\" name=\"reschDate\" readonly=\"true\" class=\"form-ctrl bsDatepicker\"\r\n                  [(ngModel)]=\"reschedDate\" bsDatepicker>\r\n\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n              <div class=\"form-wrapper timepick rescheduleTime\">\r\n                <label for=\"startTime\">Start Time</label>\r\n                <div class=\"tbox\">\r\n                  <div class=\"times\">\r\n                    <select class=\"mins side-form-ctrl\" [(ngModel)]=\"timepicker.reschedStartTime.hour\" name=\"startTime\">\r\n                      <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                        {{time}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                  <div class=\"times\">\r\n                    <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"timepicker.reschedStartTime.minute\" name=\"minute\">\r\n                      <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                        {{minute}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n              <div class=\"form-wrapper timepick rescheduleTime\">\r\n                <label for=\"endtime\">End Time</label>\r\n                <div class=\"tbox\">\r\n                  <div class=\"times \">\r\n                    <select id=\"\" class=\"mins side-form-ctrl\" [(ngModel)]=\"timepicker.reschedEndTime.hour\" name=\"endtime\">\r\n                      <option [value]=\"time\" *ngFor=\"let time of times\">\r\n                        {{time}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                  <div class=\"times\">\r\n                    <select id=\"\" class=\"mers side-form-ctrl\" [(ngModel)]=\"timepicker.reschedEndTime.minute\" name=\"minute\">\r\n                      <option *ngFor=\"let minute of minArr\" [value]=\"minute\">\r\n                        {{minute}}\r\n                      </option>\r\n                    </select>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n\r\n          </div>\r\n          <div class=\"row\">\r\n            <div class=\"field-wrapper\" style=\"width: 50%;\">\r\n              <textarea type=\"text\" style=\"height:50px;\" id=\"reschreason\" name=\"reschreason\" [(ngModel)]=\"reschedReason\"\r\n                value=\"\" placeholder=\"Reschedule Reason\" class=\"form-ctrl textbox\">\r\n                </textarea>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"\" widget-footer>\r\n          <div class=\"clearfix\">\r\n            <aside class=\"pull-left\" style=\"margin-top: 10px;\">\r\n              <div class=\"field-checkbox-wrapper\">\r\n\r\n                <input type=\"checkbox\" value=\"\" class=\"form-checkbox\" id=\"is_reshedule_notified\" [checked]=\"getCheckedStatus('resheduleNotified')\"\r\n                  (change)=\"notifyRescheduleUpdate($event)\">\r\n                <label for=\"is_reshedule_notified\">Notify Students\r\n                  <div class=\"questionInfo lefts\" style=\"margin-left: 30px;\">\r\n                    <span class=\"qInfoIcon\">?</span>\r\n                    <div class=\"tooltip-box-field\">\r\n                      Reschedule SMS will be sent to student.\r\n                    </div>\r\n                  </div>\r\n                </label>\r\n\r\n              </div>\r\n            </aside>\r\n            <aside class=\"pull-right popup-btn\">\r\n              <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closeRescheduleClass()\">\r\n              <input type=\"button\" value=\"Reschedule Class\" (click)=\"rescheduleClass()\" class=\"fullBlue btn\">\r\n            </aside>\r\n\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n<!-- //////////////////////////////////Cancel///////////////////////////////// -->\r\n<!-- //////////////////////////////////Cancel///////////////////////////////// -->\r\n<!-- //////////////////////////////////Cancel///////////////////////////////// -->\r\n<!-- //////////////////////////////////Cancel///////////////////////////////// -->\r\n<!-- //////////////////////////////////Cancel///////////////////////////////// -->\r\n\r\n\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"isCourseCancel\">\r\n  <div class=\"popup pos-abs popup-body-container\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"closeCourseCancelClass()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n          <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n            <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n              <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n            </g>\r\n            <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\"\r\n              transform=\"translate(1012 297)\" />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content\">\r\n\r\n        <h2 widget-header>Cancel Class </h2>\r\n\r\n        <div class=\"CancelWrapper\" widget-content>\r\n          <div class=\"row cancelField\">\r\n            <div class=\"c-lg-6 c-md-6 c-sm-6\">\r\n              <div class=\"field-wrapper\">\r\n                <textarea class=\"form-ctrl textBox\" style=\"height: 100px;\" placeholder=\"Cancellation Reason:\" value=\"\"\r\n                  [(ngModel)]=\"cancellationReason\">\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n            </textarea>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"row notifyChkbx\">\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"\" widget-footer>\r\n          <div class=\"clearfix\">\r\n            <aside class=\"pull-left\">\r\n              <div class=\"field-checkbox-wrapper\">\r\n\r\n                <input type=\"checkbox\" value=\"\" class=\"form-checkbox\" id=\"notifyCancel\" [checked]=\"getCheckedStatus('notifyCancel')\"\r\n                  (change)=\"notifyCancelUpdate($event)\">\r\n                <label for=\"notifyCancel\">Notify Students</label>\r\n\r\n              </div>\r\n            </aside>\r\n            <aside class=\"pull-right popup-btn\">\r\n              <input type=\"button\" value=\"Cancel\" class=\"btn\" (click)=\"closeCourseCancelClass()\">\r\n              <input type=\"button\" value=\"Save\" (click)=\"cancelClass()\" class=\"btn fullBlue\">\r\n            </aside>\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-class/class-home/class-home.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n/* ========================================================================================= */\n/* ========================================================================================= */\n.header-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  width: 100%;\n  padding: 0px;\n  border: none; }\n.cal-view {\n  margin: 0 10px;\n  overflow: hidden; }\n.cal-view ::-webkit-scrollbar {\n    display: block !important;\n    width: 7px;\n    height: 7px; }\n.cal-view .common-search-filter {\n    border-bottom: 1px solid #d3d4d5;\n    padding: 5px 5px 0;\n    margin: 10px 0px; }\n.cal-view .common-search-filter .field-wrapper {\n      background: transparent; }\n.cal-view .common-search-filter .field-wrapper .form-ctrl {\n        background: white; }\n/* ========================================================================================= */\n/* ========================================================================================= */\n.classSchedule-Add {\n  padding: 15px 5px 10px;\n  background: #efefef; }\n.classSchedule-Add .field-wrapper {\n    background: transparent; }\n.classSchedule-Add .field-wrapper .form-ctrl {\n      background: transparent; }\n.classSchedule-Add fieldset legend {\n    font-size: 12px;\n    position: absolute;\n    color: #0084f6;\n    top: -12px; }\n.classSchedule-Add fieldset .time-picker .field-wrapper {\n    display: inline-block !important;\n    margin: 0 10px 0 0 !important;\n    background: transparent; }\n.classSchedule-Add fieldset .time-picker .field-wrapper .form-ctrl {\n      background: transparent;\n      width: inherit !important; }\n.classSchedule-Add fieldset .time-picker .hour {\n    width: 75px; }\n.classSchedule-Add fieldset .time-picker .minute {\n    width: 75px; }\n.classSchedule-Add fieldset .time-picker .meridian {\n    width: 100px; }\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n/* ========================================================================================= */\n.courses-list-table tr td:first-child {\n  text-align: left;\n  padding: 10px;\n  width: 20px; }\n.edit-view {\n  display: none; }\n.edit-view .radio-options {\n    margin-top: 0; }\n.edit-view .field-wrapper {\n    width: 130px;\n    padding-top: 0;\n    margin: 0 auto; }\n.edit-view .field-wrapper .form-ctrl {\n      padding: 0;\n      height: 28px;\n      border-bottom: solid 1px #0060a3; }\n.edit-view .field-wrapper.datePickerBox:after {\n      top: 2px; }\n.edit-view .radio-options > div {\n    margin-bottom: 0; }\n.data-view {\n  display: block; }\n.edit-mod .edit-view {\n  display: block; }\n.edit-mod .data-view {\n  display: none; }\n.common-tab {\n  padding-top: 5px; }\n.common-tab ul {\n    font-size: 0; }\n.common-tab ul li {\n      margin-right: 1px;\n      display: inline-block;\n      width: 19%;\n      max-width: 158px; }\n.common-tab ul li a {\n        display: block;\n        padding: 10px 5px;\n        background: #eff7ff;\n        border: 1px solid #cccdcd;\n        color: #0084f6;\n        text-align: center;\n        font-size: 14px;\n        font-weight: 600; }\n.common-tab ul li.active a, .common-tab ul li:hover a {\n        background: #0084f6;\n        color: #fff;\n        border-color: #0084f6;\n        font-weight: normal; }\n.edit-icon,\n.view-icon {\n  margin-right: 5px; }\n.create-standard-field {\n  margin-bottom: 10px; }\n.filter-for-courses label {\n  margin-top: 15px;\n  display: block; }\n.filter-for-courses .form-btn-head {\n  width: 30px;\n  height: 30px;\n  background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%22504 4 22 22%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2%2C .cls-3 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1%2C .cls-2 %7B%0D        stroke%3A %230060a3%3B%0D        stroke-width%3A 1.3px%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1199%22 data-name%3D%22Group 1199%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Cg id%3D%22Group_1190%22 data-name%3D%22Group 1190%22 transform%3D%22translate(-1)%22%3E%0D      %3Ccircle id%3D%22Ellipse_28%22 data-name%3D%22Ellipse 28%22 class%3D%22cls-1%22 cx%3D%228.75%22 cy%3D%228.75%22 r%3D%228.75%22 transform%3D%22translate(552 21)%22%2F%3E%0D      %3Cpath id%3D%22Path_449%22 data-name%3D%22Path 449%22 class%3D%22cls-2%22 d%3D%22M5%2C5%2C0%2C0%22 transform%3D%22translate(567 36)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Crect id%3D%22Rectangle_683%22 data-name%3D%22Rectangle 683%22 class%3D%22cls-3%22 width%3D%2222%22 height%3D%2222%22 transform%3D%22translate(550 20)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat center center;\n  background-size: 20px 20px;\n  margin-top: 2px;\n  cursor: pointer;\n  margin-right: 20px;\n  -webkit-filter: grayscale(100%);\n          filter: grayscale(100%); }\n.filter-search > div {\n  margin-bottom: 0; }\n.filter-search .export-print {\n  margin-top: 6px; }\n.course-second .filter-for-courses {\n  margin-top: 0; }\n.course-second .filter-search {\n  margin-bottom: 0; }\n.course-second .filter-for-courses label {\n  margin-top: 10px; }\n.edit-view-btn > div {\n  display: inline-block;\n  margin: 0 5px; }\n.btn-new {\n  float: right; }\n.add-edit {\n  margin-bottom: 0;\n  margin-top: 20px; }\n.add-edit i {\n    border: 1px solid #0084f6;\n    display: inline-block;\n    width: 17px;\n    height: 17px;\n    border-radius: 50%;\n    line-height: 17px;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle;\n    margin-right: 4px; }\n.add-edit span {\n    display: inline-block; }\n.add-edit .expend-box i {\n    line-height: 12px;\n    font-size: 22px; }\n.create-standard-form {\n  margin: 10px 0;\n  padding: 10px 20px 20px;\n  background: #efefef;\n  border-top: 1px solid #d8d8d8; }\n.create-standard-form .field-checkbox-wrapper {\n    margin-top: 15px;\n    background: transparent; }\n.create-standard-form .field-checkbox-wrapper .form-checkbox + label {\n      font-size: 12px;\n      font-weight: 600;\n      color: #777; }\n.create-standard-form .field-checkbox-wrapper .form-checkbox:checked + label {\n      color: #0084f6; }\n.create-standard-form .field-checkbox-wrapper .form-checkbox + label:after {\n      -webkit-transform: scale(0.7);\n              transform: scale(0.7); }\n.create-standard-form .field-checkbox-wrapper .form-checkbox + label:before {\n      -webkit-transform: rotate(-45deg) scale(0.7);\n              transform: rotate(-45deg) scale(0.7); }\n.create-standard-form .field-wrapper {\n    margin-top: -10px; }\n.create-standard-form .field-wrapper label {\n      top: 25px;\n      font-size: 13px;\n      font-weight: 600; }\n.create-standard-form .form-ctrl {\n    background: transparent;\n    border-bottom: solid 1px #cccccc; }\n.create-standard-form p {\n    margin-top: 5px;\n    font-size: 10px;\n    color: #979797; }\n.create-cancel-small {\n  margin-top: 10px; }\n.create-cancel-small .btn {\n    font-size: 14px;\n    font-weight: normal;\n    height: 36px; }\n.edit-view-of-couse > tr > td {\n  padding: 0 !important; }\n.course-list-edit {\n  background: #fff;\n  padding: 20px;\n  -webkit-box-shadow: 0 0 1px 1px #c6c4c4 inset;\n          box-shadow: 0 0 1px 1px #c6c4c4 inset;\n  max-height: 200px;\n  overflow: auto; }\n.course-list-edit .evoc-box {\n    padding: 10px; }\n.course-list-edit .evoc-box .field-checkbox-wrapper {\n      background: transparent; }\n.course-list-edit .evoc-box .field-checkbox-wrapper label span {\n        font-size: 13px;\n        font-weight: 600;\n        top: -3px;\n        position: relative; }\n.ce-list-top {\n  padding-bottom: 10px;\n  border-bottom: 1px solid #ccc; }\n.ce-list-top label {\n    font-weight: 400; }\n.ce-list-top span {\n    font-weight: 600;\n    margin: 0 5px; }\n.ce-list-bottom .table-responsive tbody tr th {\n  background: #d8d8d8;\n  font-weight: 600;\n  font-size: 14px;\n  color: #333;\n  padding: 5px 10px;\n  text-align: left; }\n.ce-list-bottom .table-responsive tbody tr th:last-child {\n    width: 200px;\n    text-align: center; }\n.ce-list-bottom .table-responsive tbody tr th:first-child {\n    width: 100px; }\n.ce-list-bottom .table-responsive tbody tr td {\n  padding: 7px 10px;\n  background: #fff;\n  font-size: 12px;\n  text-align: left;\n  border-bottom: 1px solid #ededed; }\n.ce-list-bottom .table-responsive tbody tr td:last-child {\n    text-align: center; }\n.ce-list-bottom .table-responsive tbody tr:hover td {\n  background: #fff; }\n.ce-list-bottom .table-responsive tbody tr:last-child td {\n  border-bottom: 0; }\n.ce-list-bottom .field-checkbox-wrapper .form-checkbox + label:before {\n  -webkit-transform: scale(0.7) rotate(-45deg);\n          transform: scale(0.7) rotate(-45deg); }\n.ce-list-bottom .field-checkbox-wrapper .form-checkbox + label:after {\n  -webkit-transform: scale(0.6);\n          transform: scale(0.6); }\n.delete-btn a {\n  color: #f44336; }\n.delete-btn a i {\n    font-size: 18px !important;\n    vertical-align: middle;\n    margin-right: 5px; }\n.close-accor {\n  float: right;\n  width: 24px;\n  font-size: 31px;\n  height: 24px;\n  text-align: center;\n  border: none;\n  border-radius: 50%;\n  line-height: 16px;\n  margin-right: 4px;\n  margin-top: 5px;\n  cursor: pointer;\n  color: #0084f6;\n  font-weight: 400; }\n.schedule-class-box .filter-box .field-wrapper {\n  margin-top: -10px; }\n.schedule-class {\n  margin-top: 20px;\n  padding-bottom: 10px;\n  margin-bottom: 10px;\n  border-bottom: 1px solid #ccc; }\n.schedule-class .btn {\n    font-weight: 600;\n    font-size: 13px;\n    height: 30px; }\n.schedule-class .schedule-class-left {\n    padding-top: 10px; }\n.schedule-class .schedule-class-left label {\n      font-weight: 600;\n      margin-right: 15px; }\n.view-tab li {\n  display: inline-block;\n  margin-right: 0; }\n.view-tab li .btn {\n    margin-left: 0;\n    height: 25px;\n    line-height: 12px;\n    font-weight: normal;\n    font-size: 12px;\n    padding: 5px 10px; }\n.view-c-detail .filter-search {\n  margin-bottom: 0; }\n.view-c-detail .filter-search .export-print {\n    margin-bottom: 0; }\n.view-c-detail .vcd-l {\n  padding-top: 10px; }\n.view-c-detail .vcd-l label {\n    font-weight: 600;\n    font-size: 15px; }\n.calender-course {\n  position: relative; }\n.calender-course .c-control {\n    position: absolute;\n    width: 30px;\n    height: 100%;\n    background: #efefef;\n    border: 1px solid #cccccc;\n    cursor: pointer;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box; }\n.calender-course .c-control.cal-left {\n      left: 0;\n      top: 0;\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%222883.408 2074.83 10.462 21.337%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1 %7B%0D        fill%3A none%3B%0D        stroke%3A %23004a7e%3B%0D        stroke-miterlimit%3A 10%3B%0D        stroke-width%3A 2px%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cpath id%3D%22Path_557%22 data-name%3D%22Path 557%22 class%3D%22cls-1%22 d%3D%22M.7%2C20.7l8.4-9.3a1.049%2C1.049%2C0%2C0%2C0%2C0-1.3L.7.7%22 transform%3D%22translate(2893.825 2096.2) rotate(180)%22%2F%3E%0D%3C%2Fsvg%3E%0D\") no-repeat center center;\n      background-size: 11px; }\n.calender-course .c-control.cal-left:hover {\n        border: 1px solid #0084f6; }\n.calender-course .c-control.cal-right {\n      right: 0;\n      top: 0;\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%223990.754 2074.834 10.462 21.337%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1 %7B%0D        fill%3A none%3B%0D        stroke%3A %23004a7e%3B%0D        stroke-miterlimit%3A 10%3B%0D        stroke-width%3A 2px%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cpath id%3D%22Path_556%22 data-name%3D%22Path 556%22 class%3D%22cls-1%22 d%3D%22M.7%2C20.7l8.4-9.3a1.049%2C1.049%2C0%2C0%2C0%2C0-1.3L.7.7%22 transform%3D%22translate(3990.8 2074.8)%22%2F%3E%0D%3C%2Fsvg%3E%0D\") no-repeat center center;\n      background-size: 11px; }\n.calender-course .c-control.cal-right:hover {\n        border: 1px solid #0084f6; }\n.calender-course ul {\n    text-align: center;\n    padding-left: 40px;\n    padding-right: 40px; }\n.calender-course ul li {\n      display: inline-block;\n      padding: 5px 10px;\n      border: 1px solid #f0f0f0;\n      width: 14%;\n      background: #efefef;\n      vertical-align: top; }\n.calender-course ul li span.c-date {\n        font-size: 24px;\n        color: #0084f6; }\n.calender-course ul li.active {\n        background: #ddedfd;\n        border: 1px solid #ccc; }\n.class-cancel {\n  display: inline-block;\n  width: 12px;\n  height: 12px;\n  text-align: center;\n  line-height: 10px;\n  font-size: 11px;\n  color: #fff;\n  cursor: pointer;\n  vertical-align: middle; }\n.class-cancel.blue {\n    background: #0084f6; }\n.class-cancel.red {\n    background: red; }\n.class-cancel.yellow {\n    background: #f8b238; }\n.exam-is {\n  display: inline-block;\n  width: 12px;\n  height: 12px;\n  border-radius: 50%;\n  background: #f8b238;\n  vertical-align: middle; }\n.class-is {\n  display: inline-block;\n  width: 12px;\n  height: 12px;\n  border-radius: 50%;\n  background: #0084f6;\n  vertical-align: middle; }\n.calender-class-detail > div:last-child {\n  padding-top: 5px; }\n.calender-class-detail > div:last-child span {\n    margin-left: 5px; }\n.calender-view1 {\n  max-height: 260px;\n  overflow: hidden; }\n.calender-view1 th {\n    padding: 10px;\n    font-size: 13px;\n    text-align: center; }\n.calender-view1 .table-responsive {\n    margin-top: 10px;\n    max-height: 250px;\n    overflow-y: auto;\n    overflow-x: hidden; }\n.calender-view1 .table-accor-head .open-accor {\n    display: block; }\n.calender-view1 .table-accor-head .close-accor {\n    display: none; }\n.calender-view1 .table-accor-head.active .accordian-heading .open-accor {\n    display: none; }\n.calender-view1 .table-accor-head.active .accordian-heading .close-accor {\n    display: block; }\n.calender-view1 .table-accor-head td {\n    padding: 0;\n    background: #fff; }\n.calender-view1 .accordian-heading {\n    margin: 0;\n    padding: 3px !important;\n    color: #444;\n    border: 1px solid #eaecee;\n    border-radius: 20px;\n    margin: 4px 0 2px;\n    background: #e6f2fe;\n    text-align: left; }\n.calender-view1 .accordian-heading .headingDiv .close-accor,\n    .calender-view1 .accordian-heading .headingDiv .open-accor {\n      float: left; }\n.calender-view1 .accordian-heading .headingDiv .close-accor {\n      width: 18px;\n      height: 18px;\n      line-height: 15px;\n      margin-top: 0; }\n.calender-view1 .accordian-heading .headingDiv .open-accor {\n      width: 18px;\n      height: 18px;\n      line-height: 16px;\n      margin-top: 0; }\n.calender-view1 .accordian-heading .headingDiv .date-c {\n      font-size: 13px;\n      line-height: 20px;\n      margin-left: 10px;\n      font-weight: 600; }\n.calender-view1 .accordian-heading .headingDiv .delete-icon {\n      font-size: 18px;\n      color: #f44336;\n      margin-left: 10px;\n      margin-right: 9px;\n      cursor: pointer; }\n.calender-view1 .accordian-heading .headingDiv .delete-icon svg {\n        width: 15px;\n        vertical-align: top;\n        display: inline-block;\n        margin-top: 3px; }\n.calender-view1 .accordian-heading .headingDiv .delete-icon svg line {\n          stroke-width: 2; }\n.delete-btn svg {\n  width: 15px;\n  vertical-align: top;\n  display: inline-block;\n  margin-top: 3px; }\n.delete-btn svg line {\n    stroke-width: 2; }\n.mail-notification {\n  width: 20px;\n  height: 20px;\n  background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%223872.5 2200.5 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-3 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %2395989a%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        fill%3A %230084f6%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1424%22 data-name%3D%22Group 1424%22 transform%3D%22translate(2798 1737)%22%3E%0D    %3Cg id%3D%22Group_1414%22 data-name%3D%22Group 1414%22 transform%3D%22translate(-174 -64)%22%3E%0D      %3Cg id%3D%22Group_1453%22 data-name%3D%22Group 1453%22%3E%0D        %3Cellipse id%3D%22Ellipse_63%22 data-name%3D%22Ellipse 63%22 class%3D%22cls-1%22 cx%3D%222.595%22 cy%3D%222.595%22 rx%3D%222.595%22 ry%3D%222.595%22 transform%3D%22translate(1260.811 530)%22%2F%3E%0D        %3Cpath id%3D%22Path_547%22 data-name%3D%22Path 547%22 class%3D%22cls-1%22 d%3D%22M15.7%2C9.838v4.541a1.735%2C1.735%2C0%2C0%2C1-1.73%2C1.73H2.73A1.735%2C1.735%2C0%2C0%2C1%2C1%2C14.378V5.73A1.735%2C1.735%2C0%2C0%2C1%2C2.73%2C4h7.308%22 transform%3D%22translate(1249 527.297)%22%2F%3E%0D        %3Cpath id%3D%22Path_548%22 data-name%3D%22Path 548%22 class%3D%22cls-1%22 d%3D%22M1%2C8l7.351%2C4.324%2C3.027-1.73%22 transform%3D%22translate(1249 525.027)%22%2F%3E%0D      %3C%2Fg%3E%0D      %3Ccircle id%3D%22Ellipse_64%22 data-name%3D%22Ellipse 64%22 class%3D%22cls-2%22 cx%3D%221.73%22 cy%3D%221.73%22 r%3D%221.73%22 transform%3D%22translate(1261.676 530.865)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Cpath id%3D%22Path_552%22 data-name%3D%22Path 552%22 class%3D%22cls-3%22 d%3D%22M.5.5h18v18H.5Z%22 transform%3D%22translate(1074 463)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n  cursor: pointer;\n  display: inline-block; }\n.mail-notify {\n  width: 20px;\n  height: 20px;\n  background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%223872.5 2200.5 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-3 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %23fff%3B%0D%09%09fill%3A %23004a7e%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        fill%3A %23004a7e%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1424%22 data-name%3D%22Group 1424%22 transform%3D%22translate(2798 1737)%22%3E%0D    %3Cg id%3D%22Group_1414%22 data-name%3D%22Group 1414%22 transform%3D%22translate(-174 -64)%22%3E%0D      %3Cg id%3D%22Group_1453%22 data-name%3D%22Group 1453%22%3E%0D        %3Cellipse id%3D%22Ellipse_63%22 data-name%3D%22Ellipse 63%22 class%3D%22cls-1%22 cx%3D%222.595%22 cy%3D%222.595%22 rx%3D%222.595%22 ry%3D%222.595%22 transform%3D%22translate(1260.811 530)%22%2F%3E%0D        %3Cpath id%3D%22Path_547%22 fill%3D%22%23004a7e%22 data-name%3D%22Path 547%22  d%3D%22M15.7%2C9.838v4.541a1.735%2C1.735%2C0%2C0%2C1-1.73%2C1.73H2.73A1.735%2C1.735%2C0%2C0%2C1%2C1%2C14.378V5.73A1.735%2C1.735%2C0%2C0%2C1%2C2.73%2C4h7.308%22 transform%3D%22translate(1249 527.297)%22%2F%3E%0D        %3Cpath id%3D%22Path_548%22 stroke%3D%22%23004a7e%22 data-name%3D%22Path 548%22 class%3D%22cls-1%22 d%3D%22M1%2C8l7.351%2C4.324%2C3.027-1.73%22 transform%3D%22translate(1249 525.027)%22%2F%3E%0D      %3C%2Fg%3E%0D      %3Ccircle id%3D%22Ellipse_64%22 data-name%3D%22Ellipse 64%22 class%3D%22cls-2%22 cx%3D%221.73%22 cy%3D%221.73%22 r%3D%221.73%22 transform%3D%22translate(1261.676 530.865)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Cpath id%3D%22Path_552%22 data-name%3D%22Path 552%22 class%3D%22cls-3%22 d%3D%22M.5.5h18v18H.5Z%22 transform%3D%22translate(1074 463)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n  cursor: pointer;\n  display: inline-block; }\n.reschedule-icon {\n  width: 20px;\n  height: 20px;\n  background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%223900.5 2201 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-1 %7B%0D        stroke%3A %2395989a%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1423%22 data-name%3D%22Group 1423%22 transform%3D%22translate(2798 1737.5)%22%3E%0D    %3Cg id%3D%22Group_1451%22 data-name%3D%22Group 1451%22%3E%0D      %3Cpath id%3D%22Path_542%22 data-name%3D%22Path 542%22 class%3D%22cls-1%22 d%3D%22M.7%2C19.391%2C2.091%2C18l1.391%2C1.391%22 transform%3D%22translate(1103.3 453.913)%22%2F%3E%0D      %3Cpath id%3D%22Path_543%22 data-name%3D%22Path 543%22 class%3D%22cls-1%22 d%3D%22M5.7%2C5.522A6.6%2C6.6%2C0%2C0%2C1%2C18.57%2C7.609%22 transform%3D%22translate(1100.039 465)%22%2F%3E%0D      %3Cpath id%3D%22Path_544%22 data-name%3D%22Path 544%22 class%3D%22cls-1%22 d%3D%22M17.57%2C20.783A6.6%2C6.6%2C0%2C0%2C1%2C4.7%2C18.7V18%22 transform%3D%22translate(1100.691 453.913)%22%2F%3E%0D      %3Cpath id%3D%22Path_545%22 data-name%3D%22Path 545%22 class%3D%22cls-1%22 d%3D%22M41.483%2C18l-1.391%2C1.391L38.7%2C18%22 transform%3D%22translate(1078.517 453.913)%22%2F%3E%0D      %3Cline id%3D%22Line_234%22 data-name%3D%22Line 234%22 class%3D%22cls-1%22 y2%3D%220.696%22 transform%3D%22translate(1118.609 472.609)%22%2F%3E%0D      %3Cpath id%3D%22Path_546%22 data-name%3D%22Path 546%22 class%3D%22cls-1%22 d%3D%22M25.091%2C16.522%2C23.7%2C15.13V12%22 transform%3D%22translate(1088.3 457.826)%22%2F%3E%0D      %3Ccircle id%3D%22Ellipse_62%22 data-name%3D%22Ellipse 62%22 class%3D%22cls-1%22 cx%3D%224.174%22 cy%3D%224.174%22 r%3D%224.174%22 transform%3D%22translate(1107.826 468.435)%22%2F%3E%0D    %3C%2Fg%3E%0D    %3Cpath id%3D%22Path_551%22 data-name%3D%22Path 551%22 class%3D%22cls-2%22 d%3D%22M.5.5h18v18H.5Z%22 transform%3D%22translate(1102 463)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n  cursor: pointer;\n  display: inline-block; }\n.action-box {\n  text-align: right;\n  width: 115px;\n  float: right; }\n.action-box .delete-btn {\n    font-size: 18px;\n    color: #f44336; }\n.action-box span {\n    display: inline-block;\n    vertical-align: middle;\n    margin: 0 8px 0 0;\n    cursor: pointer; }\n.action-box .edit-icon {\n    width: 19px;\n    height: 16px; }\n.tick-mark1 {\n  width: 15px;\n  height: 6px;\n  border-left: 2px solid green;\n  border-bottom: 2px solid green;\n  -webkit-transform: rotate(-45deg);\n          transform: rotate(-45deg);\n  display: inline-block;\n  vertical-align: top;\n  margin-top: 1px; }\n.ledgend-footer {\n  margin-top: 15px; }\n.ledgend-footer label {\n    font-weight: 600;\n    margin-right: 16px; }\n.ledgend-footer div {\n    margin-right: 20px;\n    font-size: 11px; }\n.ledgend-footer div span {\n      display: inline-block;\n      vertical-align: middle;\n      margin-right: 3px; }\n.date-arrow {\n  position: relative; }\n.date-arrow div {\n    position: relative; }\n.date-arrow div span {\n      background: #fff;\n      display: inline-block;\n      padding: 4px 20px;\n      z-index: 1;\n      font-size: 12px;\n      font-weight: 600;\n      position: relative; }\n.date-arrow div:after {\n      position: absolute;\n      left: 20px;\n      top: 0;\n      bottom: 0;\n      margin: auto;\n      content: \"\\f104\";\n      display: inline-block;\n      font: normal normal normal 14px/1 FontAwesome;\n      font-size: inherit;\n      text-rendering: auto;\n      -webkit-font-smoothing: antialiased;\n      width: 5px;\n      height: 16px; }\n.date-arrow div:before {\n      position: absolute;\n      right: 20px;\n      top: 0;\n      bottom: 0;\n      margin: auto;\n      content: \"\\f105\";\n      display: inline-block;\n      font: normal normal normal 14px/1 FontAwesome;\n      font-size: inherit;\n      text-rendering: auto;\n      -webkit-font-smoothing: antialiased;\n      width: 5px;\n      height: 16px; }\n.date-arrow:after {\n    content: '';\n    position: absolute;\n    left: 0;\n    right: 0;\n    top: 20px;\n    margin: auto;\n    width: 88%;\n    height: 0;\n    border-bottom: 1px solid #ccc; }\n.calender-view1.cal-view-2 .accordian-heading h4 .close-accor,\n.calender-view1.cal-view-2 .accordian-heading h4 .open-accor {\n  float: right;\n  margin-right: 0; }\n.calender-view1.cal-view-2 td {\n  font-weight: 600;\n  font-size: 14px;\n  padding: 0; }\n.calender-view1.cal-view-2 td:first-child {\n    text-align: left; }\n.calender-view1.cal-view-2 td .accordian-heading h4 .date-c {\n    color: #004a7e;\n    font-size: 14px; }\n.new-action > div {\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.new-action > div span {\n    margin: 0; }\n.new-action > div > div {\n    width: 50%;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    border-right: 1px solid #ccc;\n    text-align: center;\n    padding: 5px; }\n.new-action > div > div:last-child {\n      border-right: 1px solid transparent; }\n.new-action > div:first-child {\n    border-bottom: 1px solid #ccc; }\n.cal-view-2 .action-box,\n.cal-view-2 .new-action {\n  width: 65px; }\n.cal-view-2 .action-box {\n  padding-right: 5px;\n  margin: 5px 0; }\n.read-more-view {\n  font-size: 12px;\n  margin-top: 10px;\n  color: #004a7e; }\n.new-tick-mark {\n  height: 72px;\n  width: 35px;\n  border-right: 2px solid #fff;\n  margin-right: 8px;\n  text-align: center;\n  position: relative; }\n.new-tick-mark .tick-mark1 {\n    position: absolute;\n    top: 0;\n    bottom: 0;\n    margin: auto;\n    right: 0;\n    left: 0; }\n.tick-mark-new > div {\n  display: inline-block;\n  vertical-align: middle; }\n.course-detail-section {\n  margin-top: 30px; }\n.course-detail-section .cd-s {\n    font-size: 13px;\n    font-weight: 600; }\n.course-detail-section label {\n    margin-right: 15px; }\n.course-detail-section span {\n    font-weight: 600;\n    margin-right: 10px; }\n.schedule-class-inner {\n  padding: 20px 15px 25px;\n  background: #efefef; }\n.schedule-class-inner .form-ctrl {\n    border-bottom: 1px solid #ccc;\n    background: transparent; }\n.schedule-class-inner .s-c-1 {\n    font-weight: 600;\n    font-weight: 14px;\n    padding-bottom: 10px;\n    border-bottom: 1px solid #ccc; }\n.schedule-class-inner .choose-class-type {\n    margin-top: 20px; }\n.schedule-class-inner .choose-class-type .field-radio-wrapper {\n      display: inline-block;\n      margin-right: 20px; }\n.schedule-class-inner .select-days {\n    margin-top: 20px; }\n.schedule-class-inner .select-days span {\n      float: left; }\n.schedule-class-inner .select-days .field-checkbox-wrapper {\n      float: left;\n      margin-right: 2%;\n      background: transparent;\n      margin-left: 2%; }\n.schedule-class-inner .select-days .field-checkbox-wrapper .form-checkbox + label:after {\n        -webkit-transform: scale(0.7);\n                transform: scale(0.7); }\n.schedule-class-inner .select-days .field-checkbox-wrapper .form-checkbox + label:before {\n        -webkit-transform: rotate(-45deg) scale(0.7);\n                transform: rotate(-45deg) scale(0.7); }\n.create-class-schedule h4 {\n  font-size: 14px;\n  font-weight: 600;\n  margin-bottom: 10px;\n  margin-top: 15px; }\n.s-form-control {\n  margin-top: 30px;\n  border-top: 1px solid #ccc; }\n@media only screen and (min-width: 1000px) and (max-width: 1200px) {\n  .calender-course ul li {\n    width: 12%; } }\n@media only screen and (min-width: 768px) and (max-width: 999px) {\n  .calender-course ul li {\n    width: 12%; } }\n@media only screen and (max-width: 960px) {\n  .calender-class-detail > div {\n    width: 100%;\n    text-align: center; }\n  .calender-class-detail > div:last-child span {\n    margin: 0; } }\n@media only screen and (max-width: 767px) {\n  .common-tab ul li {\n    margin-right: 0;\n    width: 20%; }\n    .common-tab ul li a {\n      padding: 5px;\n      font-size: 12px; }\n  .filter-for-courses label {\n    margin-top: 0;\n    margin-bottom: 5px; }\n  .filter-for-courses .filter-search .btn {\n    margin-right: 0;\n    margin-left: 10px; }\n  .radio-options {\n    text-align: left; }\n    .radio-options .field-radio-wrapper {\n      margin-bottom: 10px !important; }\n      .radio-options .field-radio-wrapper:last-child {\n        margin-bottom: 0 !important; }\n  .create-standard-form {\n    padding-left: 0;\n    padding-right: 0; }\n  .create-cancel-small .btn {\n    margin-right: 0;\n    margin-left: 10px; }\n  .schedule-class-box .filter-box .fullBlue.btn {\n    margin-top: 15px;\n    margin-bottom: 0; }\n  .schedule-class .schedule-class-left label {\n    display: block;\n    margin-bottom: 5px; }\n  .schedule-class .schedule-class-left span {\n    display: block;\n    margin-bottom: 10px; }\n  .schedule-class .btn {\n    margin-right: 0;\n    margin-left: 10px;\n    margin-bottom: 0; }\n  .view-tab li .btn {\n    margin-right: 0;\n    margin-bottom: 0; }\n  .calender-course ul li {\n    padding: 5px;\n    width: 14%;\n    margin-bottom: 5px; }\n  .ledgend-footer label {\n    display: block;\n    width: 100%;\n    margin-right: 0;\n    margin-bottom: 10px; }\n  .ledgend-footer div {\n    margin-bottom: 5px; }\n  .cal-view .middle-top .btn {\n    margin-bottom: 0; }\n  .calender-view1 table,\n  .courses-list-table table {\n    min-width: 600px; }\n  .calender-course ul li span.c-date {\n    font-size: 19px; }\n  .date-arrow:after {\n    width: 72%; }\n  .course-detail-section {\n    margin-top: 20px; }\n    .course-detail-section > div {\n      margin-bottom: 5px; }\n  .filter-box {\n    padding: 10px 0; }\n  .popup-btn .btn {\n    font-size: 12px;\n    height: 32px; } }\n@media only screen and (max-width: 420px) {\n  .common-tab ul li {\n    width: auto; }\n    .common-tab ul li a {\n      font-size: 10px; }\n  .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 12px; } }\n.filter-fields {\n  padding: 0 15px 20px;\n  background: #fff;\n  border: 1px solid #ccc;\n  position: absolute;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  z-index: 1;\n  left: 0;\n  top: 70%;\n  -webkit-transition: all .3s;\n  transition: all .3s;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-box-shadow: 0 2px 1px #e2e0e0;\n          box-shadow: 0 2px 1px #e2e0e0; }\n.filter-fields .field-wrapper {\n    margin: 15px 0; }\n.filter-fields .form-ctrl {\n  background: transparent;\n  font: 400 12px 'Open sans',sans-serif;\n  border-bottom: solid 1px #d2d2d2; }\n.filter-fields .btn {\n  margin: 0;\n  width: 100%;\n  margin-top: 20px;\n  padding: 10px 12px;\n  height: auto; }\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all .5s ease-in;\n  transition: all .5s ease-in; }\n.popupWrapper .popup {\n    max-width: 50%;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all .5s ease-in;\n  transition: all .5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all .5s ease-in;\n  transition: all .5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n.radio-main .field-radio-wrapper .form-radio:checked + label:before {\n  content: '';\n  width: 10px;\n  height: 10px;\n  background: #0084f6;\n  border-radius: 50%;\n  left: 3px;\n  top: 3px; }\n.radio-main .field-radio-wrapper label {\n  margin-left: 10px; }\n.form-wrapper {\n  background: transparent;\n  margin: 5px 0; }\n.form-wrapper.datepicker span {\n    position: absolute;\n    top: 35px;\n    right: 20px;\n    font-weight: 600;\n    font-size: 16px;\n    color: red;\n    cursor: pointer;\n    width: 20px;\n    text-align: center;\n    /* &::before {\r\n                content: '';\r\n                background: url('/assets/images/calendar.svg') no-repeat;\r\n                position: absolute;\r\n                right: 25px;\r\n                top: 0px;\r\n                width: 21px;\r\n                height: 21px;\r\n                z-index: 0;\r\n            } */ }\n.form-wrapper label {\n    font-size: 12px;\n    font-weight: 400;\n    color: rgba(0, 0, 0, 0.77);\n    padding-bottom: 2px;\n    text-decoration: none;\n    -webkit-font-smoothing: antialiased; }\n.form-wrapper .side-form-ctrl {\n    background: white;\n    border: 1px solid rgba(119, 119, 119, 0.419608);\n    width: 100%;\n    padding: 8px 5px;\n    font-weight: 600;\n    font-size: 14px;\n    color: black; }\n.form-wrapper .side-form-ctrl.bsDatepicker {\n      padding: 5px;\n      width: 100%; }\n.form-wrapper.timepick {\n    width: 50%;\n    padding: 1px 0; }\n.form-wrapper.timepick .tbox {\n      width: 100%; }\n.form-wrapper.timepick .tbox .times {\n        display: inline-block; }\n.form-wrapper.timepick .tbox .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        padding: 8px 5px;\n        font-weight: 600;\n        font-size: 14px;\n        color: black; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mins {\n          width: 80px; }\n.form-wrapper.timepick .tbox .side-form-ctrl.mers {\n          width: 50px; }\n.field-wrapper.datePickerBox:after {\n  content: '';\n  background: url(/./assets/images/calendar.svg) no-repeat;\n  position: absolute;\n  right: 5px;\n  top: 28px;\n  width: 21px;\n  height: 21px;\n  z-index: 20; }\n.rescheduleWrapper {\n  padding: 0 15px; }\n.rescheduleWrapper .row {\n    margin-top: 5px;\n    margin-bottom: 5px; }\n.rescheduleWrapper .notifyChkbx {\n    margin-top: 10px !important; }\n.notifyChkbx {\n  margin-top: 15px; }\n.rescheduleTime {\n  display: inline; }\n.rescheduleTime label {\n    text-transform: none; }\n.rescheduleTime .tbox {\n    padding: 0; }\n.rescheduleTime .tbox .times .side-form-ctrl.mins {\n      padding: 0; }\n.rescheduleTime .tbox .times .side-form-ctrl.mers {\n      padding: 0; }\n.questionInfo {\n  position: relative;\n  left: 40%;\n  top: -20px;\n  height: 20px;\n  width: 20px;\n  z-index: 2; }\n.questionInfo.lefts {\n    left: 80%; }\n.questionInfo.lefts .tooltip-box-field {\n      color: black;\n      min-height: 22px;\n      width: 140px !important;\n      left: 30px !important;\n      z-index: 1;\n      padding: 5px 10px !important;\n      top: -10px !important; }\n.questionInfo.lefts .tooltip-box-field:after {\n        display: none; }\n.questionInfo .qInfoIcon {\n    margin-left: 5px;\n    width: 20px;\n    height: 20px;\n    border: 1px solid #ccc;\n    border-radius: 50%;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    line-height: 20px;\n    font-weight: 600;\n    font-size: 12px;\n    cursor: pointer;\n    -webkit-box-shadow: 0 0 1px 0 #ccc inset;\n            box-shadow: 0 0 1px 0 #ccc inset;\n    color: #888;\n    -webkit-transition: all .2s linear;\n    transition: all .2s linear; }\n.questionInfo .qInfoIcon:hover {\n      border-color: #0060A3;\n      -webkit-box-shadow: 0 0 1px 0 #0060A3 inset;\n              box-shadow: 0 0 1px 0 #0060A3 inset; }\n.questionInfo.hover.lefts {\n    left: 80%; }\n.questionInfo.hover.lefts .tooltip-box-field {\n      color: black;\n      min-height: 22px;\n      width: 140px !important;\n      left: -35px !important;\n      z-index: 1;\n      padding: 5px 10px !important;\n      top: -30px !important; }\n.questionInfo.hover.lefts .tooltip-box-field:after {\n        display: none; }\n.editTeacherTd .changeteacher .spanSection {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex; }\n.editTeacherTd .changeteacher .spanSection .editSection {\n    width: 120px;\n    padding: 0 !important; }\n.editTeacherTd .changeteacher .spanSection .editSection .ddnChangeTeacher {\n      height: 25px !important;\n      padding: 0 !important; }\n.advancefilter {\n  position: absolute;\n  right: 35px;\n  top: 125px;\n  font-size: 14px;\n  color: #0084f6; }\n.advanceDateFilter {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex; }\n.advanceDateFilter .btn-wrapper {\n    padding-top: 25px; }\n.advanceDateFilter .goBack-wrapper {\n    margin: auto; }\n.radio-main {\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  width: 100%; }\n.radio-main .field-radio-wrapper {\n    margin-right: 10px; }\n.extra-button {\n  margin-top: 5px;\n  margin-right: 15px; }\n.extra-button .btn {\n    padding: 5px;\n    background: #fff;\n    border: 1px solid #ccc;\n    margin-left: 10px;\n    display: inline-block;\n    font-size: 12px;\n    font-weight: 600;\n    -webkit-box-sizing: border-box;\n    box-sizing: border-box;\n    height: auto;\n    cursor: pointer;\n    color: #0084f6; }\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-class/class-home/class-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ClassHomeComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return DateFormat; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_course_services_class_schedule_service__ = __webpack_require__("./src/app/services/course-services/class-schedule.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var ClassHomeComponent = /** @class */ (function () {
    function ClassHomeComponent(router, classService, toastCtrl, auth) {
        this.router = router;
        this.classService = classService;
        this.toastCtrl = toastCtrl;
        this.auth = auth;
        this.userType = 0;
        this.masterCourse = [];
        this.courseList = [];
        this.subjectList = [];
        this.teacherList = [];
        this.timeTableResponse = [];
        this.weekScheduleList = [];
        this.times = ['', '1 AM', '2 AM', '3 AM', '4 AM', '5 AM', '6 AM', '7 AM', '8 AM', '9 AM', '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM', '4 PM', '5 PM', '6 PM', '7 PM', '8 PM', '9 PM', '10 PM', '11 PM', '12 AM'];
        this.hourArr = ['', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];
        this.minArr = ['', '00', '15', '30', '45'];
        this.meridianArr = ['', "AM", "PM"];
        this.combinedData = [];
        this.batchMasterCourse = [];
        this.subjectListBatch = [];
        this.batchList = [];
        this.showContent = false;
        this.isLangInstitute = false;
        this.isRippleLoad = false;
        this.reschedulePopUp = false;
        this.isCourseCancel = false;
        this.showManageClass = false;
        this.showAdvanceFilter = false;
        this.isChecked = false;
        this.isExpand = true;
        this.currentDate = new Date();
        this.reschedDate = new Date();
        this.weekStart = __WEBPACK_IMPORTED_MODULE_2_moment__(this.currentDate).isoWeekday("Monday").format("DD MMMM YYYY");
        this.weekEnd = __WEBPACK_IMPORTED_MODULE_2_moment__(this.currentDate).isoWeekday("Sunday").format("DD MMMM YYYY");
        this.cancellationReason = '';
        this.classMarkedForAction = '';
        this.selectedRadioButton = 'All';
        this.is_notified = 'Y';
        this.allotedTeacher = '-1';
        this.reschedReason = "";
        this.resheduleNotified = "Y";
        this.rescheduleDet = "";
        this.fetchMasterCourseModule = {
            master_course: "-1",
            course_id: "-1",
            subject_id: '-1',
            teacher_id: '-1',
        };
        this.timepicker = {
            reschedStartTime: {
                hour: '12 PM',
                minute: '00',
                meridian: ''
            },
            reschedEndTime: {
                hour: '1 PM',
                minute: '00',
                meridian: ''
            },
        };
        this.fetchBatchModule = {
            batch_id: null,
            master_course: "",
            course_id: -1,
            subject_id: -1,
            teacher_id: null,
        };
        this.batchData = {
            standard_id: -1,
            subject_id: -1,
            batch_id: -1,
        };
        this.advanceFilter = {
            startdate: __WEBPACK_IMPORTED_MODULE_2_moment__().subtract(30, 'days').format('YYYY-MM-DD'),
            enddate: __WEBPACK_IMPORTED_MODULE_2_moment__().format('YYYY-MM-DD'),
            type: '3',
            isExamIncludedInTimeTable: 'Y'
        };
        this.selectedArray = {
            examSchldId: [],
            classSchldId: []
        };
        if (sessionStorage.getItem('userid') == null) {
            this.router.navigate(['/authPage']);
        }
    }
    ClassHomeComponent.prototype.ngOnInit = function () {
        this.userType = sessionStorage.getItem('userType');
        this.checkUserPermission();
        this.checkInstituteType();
        this.getPrefillData();
        this.checkForCoursePlannerRoute();
    };
    ClassHomeComponent.prototype.ngOnDestroy = function () {
        sessionStorage.setItem('isFromCoursePlanner', String(false));
    };
    ClassHomeComponent.prototype.checkForCoursePlannerRoute = function () {
        var coursePlannerStatus = sessionStorage.getItem('isFromCoursePlanner');
    };
    ClassHomeComponent.prototype.checkUserPermission = function () {
        var permissionArray = sessionStorage.getItem('permissions');
        if (permissionArray == "" || permissionArray == null) {
            this.showManageClass = true;
        }
        else {
            if (permissionArray != "") {
                if (permissionArray.indexOf('701') != -1 || permissionArray.indexOf('402') != -1) {
                    this.showManageClass = true;
                }
                else {
                    this.showManageClass = false;
                }
            }
        }
    };
    ClassHomeComponent.prototype.getPrefillData = function () {
        if (this.isLangInstitute) {
            this.submitMasterCourse();
            this.getCombinedData();
        }
        else {
            this.getMasterCourseList();
        }
        this.getTeachers();
    };
    ClassHomeComponent.prototype.getCombinedData = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.classService.getCombinedDataFromServer(this.batchData.standard_id, this.batchData.subject_id).subscribe(function (res) {
            _this.isRippleLoad = false;
            //console.log('Combined data', res);
            _this.combinedData = res;
            if (res.standardLi != null) {
                _this.batchMasterCourse = res.standardLi;
            }
            if (res.subjectLi != null) {
                _this.subjectListBatch = res.subjectLi;
            }
            if (res.batchLi != null) {
                _this.batchList = res.batchLi;
            }
        }, function (err) {
            _this.isRippleLoad = false;
            //console.log(err);
            _this.messageToast('error', '', err.error.message);
        });
    };
    ClassHomeComponent.prototype.getMasterCourseList = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.classService.getAllMasterCourse().subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.masterCourse = res;
            //console.log('master', res);
        }, function (err) {
            _this.isRippleLoad = false;
            _this.messageToast('error', '', err.error.message);
            //console.log(err);
        });
    };
    ClassHomeComponent.prototype.getTeachers = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.classService.getAllTeachersList().subscribe(function (res) {
            // console.log('teacher', res);
            _this.isRippleLoad = false;
            _this.teacherList = res;
            _this.teacherList.sort(function (a, b) {
                var textA = a.teacher_name.toUpperCase();
                var textB = b.teacher_name.toUpperCase();
                return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
            });
        }, function (err) {
            _this.isRippleLoad = false;
            _this.messageToast('error', '', err.error.message);
        });
    };
    ClassHomeComponent.prototype.updateCourseList = function (ev) {
        var _this = this;
        this.showContent = false;
        this.isRippleLoad = true;
        this.classService.getCourseFromMasterById(ev).subscribe(function (res) {
            if (res.coursesList) {
                //console.log("course", res);
                _this.courseList = res;
                _this.isRippleLoad = false;
            }
            else {
                _this.courseList = [];
                _this.isRippleLoad = false;
            }
        }, function (err) {
            //console.log(err);
            _this.courseList = [];
            _this.isRippleLoad = false;
            _this.messageToast('error', '', err.error.message);
        });
    };
    ClassHomeComponent.prototype.updateSubjectList = function (event) {
        var _this = this;
        this.showContent = false;
        this.isRippleLoad = true;
        this.classService.getSubjectList(event).subscribe(function (res) {
            _this.isRippleLoad = false;
            //console.log('Subject', res);
            _this.subjectList = res.batchesList;
        }, function (err) {
            _this.messageToast('error', '', err.error.message);
            _this.isRippleLoad = false;
            //console.log(err);
        });
    };
    ClassHomeComponent.prototype.getClassList = function () {
        var temp = [];
        var dataList = [];
        if (this.isLangInstitute) {
            dataList = this.timeTableResponse.batchTimeTableList;
        }
        else {
            if (this.showAdvanceFilter) {
                dataList = this.timeTableResponse.batchTimeTableList;
            }
            else {
                if (this.fetchMasterCourseModule.master_course != "" && this.fetchMasterCourseModule.course_id == "-1" && this.fetchMasterCourseModule.teacher_id == "-1" && this.fetchMasterCourseModule.subject_id == "-1") {
                    dataList = this.timeTableResponse[0].batchTimeTableList;
                }
                else {
                    dataList = this.timeTableResponse.batchTimeTableList;
                }
            }
        }
        var _loop_1 = function (key) {
            var arr = [];
            var obj = {
                id: key,
                data: arr
            };
            if (dataList[key].length > 0) {
                var schList = dataList[key];
                schList.map(function (ele) {
                    if (ele.class_type != "Exam") {
                        ele['selected'] = false;
                        ele['date'] = key;
                        arr.push(ele);
                    }
                });
                // for (let i = 0; i < schList.length; i++) {
                //   schList[i]['selected'] = false;
                //   schList[i]['date'] = key;
                // }
            }
            if (obj.data.length > 0) {
                temp.push(obj);
            }
        };
        for (var key in dataList) {
            _loop_1(key);
        }
        return temp;
    };
    ClassHomeComponent.prototype.toggleTbodyClass = function (i) {
        document.getElementById('tbodyItem' + i).classList.toggle("active");
        document.getElementById('tbodyView' + i).classList.toggle("hide");
        //document.getElementById('tbodyItem'+i).classList.toggle('active');
    };
    // it expands all rows for show child records
    ClassHomeComponent.prototype.expandAll = function (i) {
        document.getElementById('tbodyItem' + i).classList.add("active");
        document.getElementById('tbodyView' + i).classList.remove("hide");
    };
    // it collapes all rows for hide child records
    ClassHomeComponent.prototype.collapesAll = function (i) {
        document.getElementById('tbodyItem' + i).classList.remove("active");
        document.getElementById('tbodyView' + i).classList.add("hide");
    };
    ClassHomeComponent.prototype.submitMasterCourse = function () {
        var _this = this;
        var data;
        if (this.isLangInstitute) {
            var fieldCheck = this.checkFieldFilled();
            if (fieldCheck == false) {
                return;
            }
            data = this.makeJsonForBatch();
        }
        else {
            data = this.makeJsonForSubmit();
        }
        this.weekScheduleList = [];
        this.isRippleLoad = true;
        this.classService.getTimeTable(data).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.timeTableResponse = res;
            _this.showContent = true;
            _this.weekScheduleList = _this.getClassList();
        }, function (err) {
            //console.log(err);
            _this.isRippleLoad = false;
            _this.messageToast('error', '', err.error.message);
        });
    };
    ClassHomeComponent.prototype.makeJsonForSubmit = function () {
        var obj = {};
        obj.batch_id = this.fetchMasterCourseModule.subject_id;
        obj.course_id = this.fetchMasterCourseModule.course_id;
        obj.master_course = this.courseList.master_course;
        obj.subject_id = -1;
        obj.teacher_id = this.fetchMasterCourseModule.teacher_id;
        obj.standard_id = -1;
        obj.isExamIncludedInTimeTable = 'Y';
        obj.startdate = this.getStartDate();
        obj.enddate = this.getEndDate();
        obj.type = 2;
        return obj;
    };
    ClassHomeComponent.prototype.makeJsonForBatch = function () {
        var obj = {};
        obj.batch_id = this.batchData.batch_id;
        obj.course_id = this.fetchBatchModule.course_id;
        obj.master_course = this.fetchBatchModule.master_course;
        obj.subject_id = this.batchData.subject_id;
        obj.teacher_id = this.fetchBatchModule.teacher_id;
        obj.standard_id = this.batchData.standard_id;
        obj.isExamIncludedInTimeTable = 'Y';
        obj.startdate = this.getStartDate();
        obj.enddate = this.getEndDate();
        obj.type = 2;
        return obj;
    };
    ClassHomeComponent.prototype.checkFieldFilled = function () {
        if (this.batchData.standard_id == -1 && this.batchData.subject_id == -1 && this.batchData.batch_id == -1) {
            return true;
        }
        else {
            if (this.batchData.batch_id != -1) {
                return true;
            }
            else {
                this.messageToast('error', '', 'Please enter batch details');
                return false;
            }
        }
    };
    ClassHomeComponent.prototype.getEndDate = function () {
        var currentDate = __WEBPACK_IMPORTED_MODULE_2_moment__(this.currentDate).format("YYYY-MM-DD");
        return __WEBPACK_IMPORTED_MODULE_2_moment__(currentDate).weekday(7).format("YYYY-MM-DD");
    };
    ClassHomeComponent.prototype.getStartDate = function () {
        var currentDate = __WEBPACK_IMPORTED_MODULE_2_moment__(this.currentDate).format("YYYY-MM-DD");
        return __WEBPACK_IMPORTED_MODULE_2_moment__(currentDate).weekday(1).format("YYYY-MM-DD");
    };
    ClassHomeComponent.prototype.getValueOfStandardID = function (data, key, value) {
        for (var t = 0; t < data.length; t++) {
            if (data[t][key] == value) {
                return data[t].standard_id;
            }
        }
    };
    ClassHomeComponent.prototype.messageToast = function (errorType, errorTitle, errorMeassage) {
        var data = {
            type: errorType,
            title: errorTitle,
            body: errorMeassage
        };
        this.toastCtrl.popToast(data);
    };
    ClassHomeComponent.prototype.checkInstituteType = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isLangInstitute = true;
            }
            else {
                _this.isLangInstitute = false;
                _this.showhideAdvanceFilter('0');
            }
        });
    };
    ClassHomeComponent.prototype.gotoPreviousWeek = function () {
        this.currentDate = new Date(__WEBPACK_IMPORTED_MODULE_2_moment__(this.currentDate).subtract(7, 'd').format("YYYY-MM-DD"));
        this.weekStart = __WEBPACK_IMPORTED_MODULE_2_moment__(this.currentDate).isoWeekday("Monday").format("DD MMMM YYYY");
        this.weekEnd = __WEBPACK_IMPORTED_MODULE_2_moment__(this.currentDate).isoWeekday("Sunday").format("DD MMMM YYYY");
        this.submitMasterCourse();
    };
    /* ============================================================================================ */
    /* ============================================================================================ */
    ClassHomeComponent.prototype.gotoNextWeek = function () {
        this.currentDate = new Date(__WEBPACK_IMPORTED_MODULE_2_moment__(this.currentDate).add(7, 'd').format("YYYY-MM-DD"));
        this.weekStart = __WEBPACK_IMPORTED_MODULE_2_moment__(this.currentDate).isoWeekday("Monday").format("DD MMMM YYYY");
        this.weekEnd = __WEBPACK_IMPORTED_MODULE_2_moment__(this.currentDate).isoWeekday("Sunday").format("DD MMMM YYYY");
        this.submitMasterCourse();
    };
    ClassHomeComponent.prototype.delete = function (level, index, subIndex) {
        if (level == 'course') {
            //console.log(this.weekScheduleList[index]);
            //console.log('this has to be deleted');
        }
        else if (level == 'subject') {
            //console.log(this.weekScheduleList[index].data[subIndex]);
            //console.log('this has to be deleted');
        }
        else if (level == 'batch') { }
    };
    ClassHomeComponent.prototype.notify = function (notify) {
        var _this = this;
        if (confirm("Are you sure, You want to notify?")) {
            var obj = {
                course_ids: this.fetchMasterCourseModule.course_id,
                inst_id: sessionStorage.getItem('institute_id'),
                master_course: this.fetchMasterCourseModule.master_course,
                requested_date: __WEBPACK_IMPORTED_MODULE_2_moment__(notify.id).format("YYYY-MM-DD")
            };
            this.classService.remindCourseLevel(obj).subscribe(function (res) {
                var msg = {
                    type: 'success',
                    title: '',
                    body: 'Student(s) has been notified'
                };
                _this.toastCtrl.popToast(msg);
            }, function (err) {
                var msg = {
                    type: 'error',
                    title: '',
                    body: 'please contact support@proctur.com'
                };
                _this.toastCtrl.popToast(msg);
            });
        }
    };
    ClassHomeComponent.prototype.notifySubjectLevel = function (rowdata, dateRow) {
        var _this = this;
        if (confirm("Are you sure, You want to notify?")) {
            var obj = {};
            obj.batch_id = rowdata.batch_id;
            obj.class_schedule_id = rowdata.schd_id;
            obj.is_exam_schedule = "N";
            this.classService.sendReminderToServerSubject(obj).subscribe(function (res) {
                _this.messageToast('success', 'Success', 'Reminder Notification sent successfully');
            }, function (err) {
                //console.log(err);
                _this.messageToast('error', '', err.error.message);
            });
        }
        ;
    };
    ClassHomeComponent.prototype.rescheduleClassData = function (rowData) {
        this.reschedulePopUp = true;
        this.rescheduleDet = rowData;
    };
    ClassHomeComponent.prototype.getCheckedStatus = function (id) {
        if (id === "notifyCancel") {
            return true;
        }
        else if (id === 'resheduleNotified') {
            return true;
        }
    };
    ClassHomeComponent.prototype.closeRescheduleClass = function () {
        this.reschedulePopUp = false;
        this.reschedDate = new Date();
        this.reschedReason = "";
        this.timepicker = {
            reschedStartTime: {
                hour: '12 PM',
                minute: '00',
                meridian: ''
            },
            reschedEndTime: {
                hour: '1 PM',
                minute: '00',
                meridian: ''
            }
        };
        if (this.showAdvanceFilter) {
            this.advanceFilterView();
        }
        else {
            this.submitMasterCourse();
        }
    };
    ClassHomeComponent.prototype.notifyRescheduleUpdate = function (e) {
        if (e.target.checked) {
            this.resheduleNotified = "Y";
        }
        else {
            this.resheduleNotified = "N";
        }
    };
    ClassHomeComponent.prototype.checkIfTimeProvided = function (data) {
        if (data == "" || data == null) {
            var msg = {
                type: 'error',
                title: '',
                body: 'Please enter correct time'
            };
            this.toastCtrl.popToast(msg);
            return false;
        }
        else {
            return true;
        }
    };
    ClassHomeComponent.prototype.rescheduleClass = function () {
        var _this = this;
        var check = this.checkIfTimeProvided(this.timepicker.reschedStartTime.hour);
        if (check) {
            var startTime = this.timepicker.reschedStartTime.hour.split(' ');
            this.timepicker.reschedStartTime.hour = startTime[0];
            this.timepicker.reschedStartTime.meridian = startTime[1];
        }
        else {
            return;
        }
        var check1 = this.checkIfTimeProvided(this.timepicker.reschedEndTime.hour);
        if (check1) {
            var endTime = this.timepicker.reschedEndTime.hour.split(' ');
            this.timepicker.reschedEndTime.hour = endTime[0];
            this.timepicker.reschedEndTime.meridian = endTime[1];
        }
        else {
            return;
        }
        if (this.reSheduleFormValid()) {
            var temp1 = {
                cancel_note: this.reschedReason,
                schd_id: this.rescheduleDet.schd_id,
                is_notified: this.resheduleNotified
            };
            var temp2 = {
                class_date: __WEBPACK_IMPORTED_MODULE_2_moment__(this.reschedDate).format("YYYY-MM-DD"),
                start_time: this.timepicker.reschedStartTime.hour + ":" + this.timepicker.reschedStartTime.minute + " " + this.timepicker.reschedStartTime.meridian,
                end_time: this.timepicker.reschedEndTime.hour + ":" + this.timepicker.reschedEndTime.minute + " " + this.timepicker.reschedEndTime.meridian,
                duration: this.getDifference()
            };
            var obj = {
                batch_id: this.rescheduleDet.batch_id,
                cancelSchd: [],
                extraSchd: []
            };
            obj.cancelSchd.push(temp1);
            obj.extraSchd.push(temp2);
            this.classService.reScheduleClass(obj).subscribe(function (res) {
                var msg = {
                    type: 'success',
                    title: '',
                    body: 'The request has been processed'
                };
                _this.toastCtrl.popToast(msg);
                _this.closeRescheduleClass();
            }, function (err) {
                var msg = {
                    type: 'error',
                    title: '',
                    body: err.message
                };
                _this.toastCtrl.popToast(msg);
            });
        }
        else {
            this.timepicker.reschedStartTime.hour = this.timepicker.reschedStartTime.hour + " " + this.timepicker.reschedStartTime.meridian;
            this.timepicker.reschedEndTime.hour = this.timepicker.reschedEndTime.hour + " " + this.timepicker.reschedEndTime.meridian;
        }
    };
    ClassHomeComponent.prototype.getDifference = function () {
        var startTime = this.timepicker.reschedStartTime.hour + ":" + this.timepicker.reschedStartTime.minute + " " + this.timepicker.reschedStartTime.meridian;
        var endTime = this.timepicker.reschedEndTime.hour + ":" + this.timepicker.reschedEndTime.minute + " " + this.timepicker.reschedEndTime.meridian;
        var start = __WEBPACK_IMPORTED_MODULE_2_moment__["utc"](startTime, "HH:mm A");
        var end = __WEBPACK_IMPORTED_MODULE_2_moment__["utc"](endTime, "HH:mm A");
        if (end.isBefore(start)) {
            end.add(1, 'day');
        }
        var d = __WEBPACK_IMPORTED_MODULE_2_moment__["duration"](end.diff(start));
        return d._milliseconds / 60000;
    };
    ClassHomeComponent.prototype.reSheduleFormValid = function () {
        /* Date Validation */
        if (this.reschedDate != '' && this.reschedDate != 'Invalid Date') {
            /* Reschedule Reason */
            if (this.reschedReason.trim() != '') {
                /* Validate Time */
                if (this.isTimeValid()) {
                    return true;
                }
                else {
                    var msg = {
                        type: 'error',
                        title: '',
                        body: 'Please enter a complete start and end time for rescheduling'
                    };
                    this.toastCtrl.popToast(msg);
                    return false;
                }
            }
            else {
                var msg = {
                    type: 'error',
                    title: 'Reschedule Reason Missing',
                    body: 'Please mention a reason for rescheduling the class'
                };
                this.toastCtrl.popToast(msg);
                return false;
            }
        }
        else {
            var msg = {
                type: 'error',
                title: 'Date Missing',
                body: 'Please select a date to reschedule class'
            };
            this.toastCtrl.popToast(msg);
            return false;
        }
    };
    ClassHomeComponent.prototype.isTimeValid = function () {
        if (this.timepicker.reschedStartTime.hour.trim() != '' && this.timepicker.reschedStartTime.minute.trim() != '' && this.timepicker.reschedStartTime.meridian.trim() != '' && this.timepicker.reschedEndTime.hour.trim() != '' && this.timepicker.reschedEndTime.minute.trim() != '' && this.timepicker.reschedEndTime.meridian.trim() != '') {
            var startTime = this.timepicker.reschedStartTime.hour + ":" + this.timepicker.reschedStartTime.minute + " " + this.timepicker.reschedStartTime.meridian;
            var endTime = this.timepicker.reschedEndTime.hour + ":" + this.timepicker.reschedEndTime.minute + " " + this.timepicker.reschedEndTime.meridian;
            var start = __WEBPACK_IMPORTED_MODULE_2_moment__["utc"](startTime, "HH:mm A");
            var end = __WEBPACK_IMPORTED_MODULE_2_moment__["utc"](endTime, "HH:mm A");
            if ((parseInt(start.format("HH")) < parseInt(end.format("HH")))) {
                return true;
            }
            else if ((parseInt(start.format("HH")) == parseInt(end.format("HH"))) && (parseInt(start.format("mm")) < parseInt(end.format("mm")))) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    };
    ClassHomeComponent.prototype.checkInputType = function (event) {
        if (event.target.value == "All") {
            this.weekScheduleList = [];
            this.selectedRadioButton = "All";
            this.fetchBatchModule = {
                batch_id: null,
                master_course: "",
                course_id: -1,
                subject_id: -1,
                teacher_id: null,
            };
            this.batchData = {
                standard_id: -1,
                subject_id: -1,
                batch_id: -1,
            };
            this.getPrefillData();
        }
        else if (event.target.value == "Teacher") {
            this.weekScheduleList = [];
            this.selectedRadioButton = "Teacher";
        }
        else {
            this.weekScheduleList = [];
            this.selectedRadioButton = "Batch";
        }
    };
    ClassHomeComponent.prototype.onBatchMasterCourseSelection = function (event) {
        this.batchData.subject_id = -1;
        this.batchData.batch_id = -1;
        this.getCombinedData();
    };
    ClassHomeComponent.prototype.onSubjectSelection = function (event) {
        this.batchList = [];
        this.batchData.batch_id = -1;
        this.getCombinedData();
    };
    ClassHomeComponent.prototype.CancelClass = function (rowData) {
        this.isCourseCancel = true;
        this.classMarkedForAction = rowData;
    };
    ClassHomeComponent.prototype.closeCourseCancelClass = function () {
        this.isCourseCancel = false;
        this.cancellationReason = '';
        if (this.showAdvanceFilter) {
            this.advanceFilterView();
        }
        else {
            this.submitMasterCourse();
        }
    };
    ClassHomeComponent.prototype.cancelClass = function () {
        var _this = this;
        var data = {};
        data.batch_id = this.classMarkedForAction.batch_id;
        data.cancelSchd = [
            {
                cancel_note: this.cancellationReason,
                is_notified: this.is_notified,
                schd_id: this.classMarkedForAction.schd_id
            }
        ];
        this.classService.cancelClassSchedule(data).subscribe(function (res) {
            var msg = {
                type: 'success',
                title: '',
                body: 'The requested scheduled has been cancelled'
            };
            _this.toastCtrl.popToast(msg);
            _this.closeCourseCancelClass();
        }, function (err) {
            var msg = {
                type: 'error',
                title: '',
                body: err.cancelResponseMessage
            };
            _this.toastCtrl.popToast(msg);
        });
    };
    ClassHomeComponent.prototype.notifyCancelUpdate = function (e) {
        if (e.target.checked) {
            this.is_notified = "Y";
        }
        else {
            this.is_notified = "N";
        }
    };
    ClassHomeComponent.prototype.editClass = function (data) {
        var obj = {
            course_id: this.fetchMasterCourseModule.course_id,
            master_course: this.fetchMasterCourseModule.master_course,
            date: data.id.split('(')[0]
        };
        sessionStorage.setItem('editClass', JSON.stringify(obj));
        this.router.navigateByUrl('/view/course/class/add');
    };
    ClassHomeComponent.prototype.printTimeTableData = function () {
    };
    ClassHomeComponent.prototype.changeTeacher = function (data) {
        document.getElementById('teacher' + data.schd_id).classList.add('hide');
        document.getElementById('editTeacher' + data.schd_id).classList.remove('hide');
    };
    ClassHomeComponent.prototype.cancelChangeTeacher = function (data) {
        document.getElementById('teacher' + data.schd_id).classList.remove('hide');
        document.getElementById('editTeacher' + data.schd_id).classList.add('hide');
        this.allotedTeacher = '-1';
    };
    ClassHomeComponent.prototype.updateTeacher = function (data) {
        var _this = this;
        if (this.allotedTeacher == "-1" || this.allotedTeacher == null) {
            this.messageToast('error', '', 'Please enter teacher');
            return false;
        }
        else {
            if (confirm('Are you sure you want to change the teacher?')) {
                var obj = {
                    alloted_teacher_id: this.allotedTeacher,
                    batch_id: data.batch_id,
                    class_schedule_id: data.schd_id,
                    cousre_planner_update_operation: 'teacher',
                    is_exam_schedule: 'N',
                };
                this.classService.changeClassTeacher(obj).subscribe(function (res) {
                    _this.messageToast('success', 'Updated', 'Teacher updated successfully');
                    _this.allotedTeacher = '-1';
                    _this.cancelChangeTeacher(data);
                    if (_this.showAdvanceFilter) {
                        _this.advanceFilterView();
                    }
                    else {
                        _this.submitMasterCourse();
                    }
                }, function (err) {
                    console.log(err);
                    _this.messageToast('error', '', err.error.message);
                });
            }
        }
    };
    //Advance Filter Functionality
    ClassHomeComponent.prototype.advanceFilterView = function () {
        var _this = this;
        var validate = this.validateAllFields();
        if (validate) {
            var dataToSend = this.makeJsonForAdvanceFilter();
            this.isRippleLoad = true;
            this.classService.getTimeTable(dataToSend).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.timeTableResponse = res;
                _this.showContent = true;
                _this.weekScheduleList = _this.getClassList();
            }, function (err) {
                _this.isRippleLoad = false;
                _this.messageToast('error', '', err.error.message);
            });
        }
    };
    ClassHomeComponent.prototype.makeJsonForAdvanceFilter = function () {
        var data;
        if (this.isLangInstitute) {
            data = this.makeJsonForBatch();
        }
        else {
            data = this.makeJsonForSubmit();
        }
        data.type = this.advanceFilter.type;
        data.startdate = this.advanceFilter.startdate;
        data.enddate = this.advanceFilter.enddate;
        return data;
    };
    ClassHomeComponent.prototype.validateAllFields = function () {
        var days = 0;
        days = __WEBPACK_IMPORTED_MODULE_2_moment__(this.advanceFilter.enddate).diff(__WEBPACK_IMPORTED_MODULE_2_moment__(this.advanceFilter.startdate), 'days');
        if (days > 31) {
            this.messageToast('error', '', 'Please enter date range of 30 days only');
            return false;
        }
        else {
            this.advanceFilter.startdate = __WEBPACK_IMPORTED_MODULE_2_moment__(this.advanceFilter.startdate).format('YYYY-MM-DD');
            this.advanceFilter.enddate = __WEBPACK_IMPORTED_MODULE_2_moment__(this.advanceFilter.enddate).format('YYYY-MM-DD');
        }
        if (this.isLangInstitute) {
            if (this.batchData.standard_id == -1) {
                this.messageToast('error', '', 'Please enter Master Course');
                return false;
            }
            if (this.batchData.subject_id == -1) {
                this.messageToast('error', '', 'Please enter Course');
                return false;
            }
            if (this.batchData.batch_id == -1) {
                this.messageToast('error', '', 'Please enter Batch');
                return false;
            }
        }
        else {
            if (this.fetchMasterCourseModule.master_course == "-1") {
                this.messageToast('error', '', 'Please enter Master Course');
                return false;
            }
            if (this.fetchMasterCourseModule.course_id == "-1") {
                this.messageToast('error', '', 'Please enter Course');
                return false;
            }
        }
        return true;
    };
    ClassHomeComponent.prototype.showhideAdvanceFilter = function (key) {
        this.weekScheduleList = [];
        if (key == '0') {
            this.showAdvanceFilter = false;
            var obj = { target: {
                    value: this.selectedRadioButton
                } };
            this.checkInputType(obj);
            if (this.userType == '3') {
                this.showAdvanceFilter = true;
            }
        }
        else {
            this.showAdvanceFilter = true;
        }
        this.showContent = false;
        this.fetchMasterCourseModule = {
            master_course: "-1",
            course_id: "-1",
            subject_id: '-1',
            teacher_id: '-1',
        };
        this.batchData = {
            standard_id: -1,
            subject_id: -1,
            batch_id: -1,
        };
        this.selectedArray = {
            examSchldId: [],
            classSchldId: []
        };
    };
    /// Delete Schedule
    ClassHomeComponent.prototype.deleteMultipleSchedule = function () {
        var _this = this;
        if (confirm('All the selected future class and exam schedule will be deleted. Do you want to continue?')) {
            var dataToSend = this.makeMultipleDelete();
            if (dataToSend == false) {
                return false;
            }
            this.classService.deleteMultiple(dataToSend).subscribe(function (res) {
                _this.messageToast('success', 'Deleted Successfully', '');
                if (_this.showAdvanceFilter) {
                    _this.advanceFilterView();
                }
                else {
                    _this.submitMasterCourse();
                }
                _this.selectedArray = {
                    examSchldId: [],
                    classSchldId: []
                };
            }, function (err) {
                _this.messageToast('error', '', err.error.message);
            });
        }
    };
    ClassHomeComponent.prototype.makeMultipleDelete = function () {
        var obj = {
            examSchldId: [],
            classSchldId: []
        };
        for (var key in this.weekScheduleList) {
            if (__WEBPACK_IMPORTED_MODULE_2_moment__(this.weekScheduleList[key].id) > __WEBPACK_IMPORTED_MODULE_2_moment__()) {
                var data = this.weekScheduleList[key].data;
                for (var i = 0; i < data.length; i++) {
                    if (data[i].selected) {
                        if (__WEBPACK_IMPORTED_MODULE_2_moment__(data[i].date) > __WEBPACK_IMPORTED_MODULE_2_moment__()) {
                            if (data[i].class_type == "Exam") {
                                obj.examSchldId.push(data[i].schd_id);
                            }
                            else {
                                obj.classSchldId.push(data[i].schd_id);
                            }
                        }
                        else {
                            this.messageToast('error', '', "Past Date Schedule Can't Deleted");
                            return false;
                        }
                    }
                }
            }
        }
        if (obj.examSchldId.length == 0 && obj.classSchldId.length == 0) {
            this.messageToast('error', '', "You haven't selected any future schedule");
            return false;
        }
        return obj;
    };
    ClassHomeComponent.prototype.userSelectedData = function (event, data) {
        var isUnseleted = false;
        if (event) {
            if (__WEBPACK_IMPORTED_MODULE_2_moment__(data.date) > __WEBPACK_IMPORTED_MODULE_2_moment__()) {
                if (data.class_type == "Exam") {
                    this.selectedArray.examSchldId.push(data.schd_id);
                }
                else {
                    this.selectedArray.classSchldId.push(data.schd_id);
                }
            }
            else {
                if (data.class_type == "Exam") {
                    if (this.selectedArray.examSchldId.indexOf(data.schd_id) > -1) {
                        this.selectedArray.examSchldId.splice(this.selectedArray.examSchldId.indexOf(data.schd_id), 1);
                    }
                }
                else {
                    if (this.selectedArray.classSchldId.indexOf(data.schd_id) > -1) {
                        this.selectedArray.classSchldId.splice(this.selectedArray.classSchldId.indexOf(data.schd_id), 1);
                    }
                    else {
                        this.selectedArray.classSchldId.push(data.schd_id);
                    }
                }
            }
        }
        else {
            if (data.class_type == "Exam") {
                if (this.selectedArray.examSchldId.indexOf(data.schd_id) > -1) {
                    this.selectedArray.examSchldId.splice(this.selectedArray.examSchldId.indexOf(data.schd_id), 1);
                }
            }
            else {
                if (this.selectedArray.classSchldId.indexOf(data.schd_id) > -1) {
                    this.selectedArray.classSchldId.splice(this.selectedArray.classSchldId.indexOf(data.schd_id), 1);
                }
                else {
                    this.selectedArray.classSchldId.push(data.schd_id);
                }
            }
        }
        if (this.weekScheduleList.length > 0) {
            for (var i = 0; i < this.weekScheduleList.length; i++) {
                if (this.weekScheduleList[i].data.length > 0) {
                    this.weekScheduleList[i].data.forEach(function (sch) {
                        if (sch.selected == false) {
                            isUnseleted = true;
                            return;
                        }
                    });
                }
            }
        }
        this.isChecked = isUnseleted ? false : true;
    };
    ClassHomeComponent.prototype.showDeleteBTN = function () {
        if (this.selectedArray.examSchldId.length > 0) {
            return true;
        }
        if (this.selectedArray.classSchldId.length > 0) {
            return true;
        }
        return false;
    };
    // Expand All
    ClassHomeComponent.prototype.expandAllRows = function () {
        var count = this.weekScheduleList.length;
        for (var i = 0; i < count; i++) {
            if (this.isExpand) {
                this.expandAll(i);
            }
            else {
                this.collapesAll(i);
            }
        }
        this.isExpand = (!this.isExpand);
    };
    ClassHomeComponent.prototype.checkAllCheckbox = function () {
        var _this = this;
        this.isChecked = (!this.isChecked);
        this.expandAllRows();
        if (this.weekScheduleList.length > 0) {
            for (var i = 0; i < this.weekScheduleList.length; i++) {
                if (this.weekScheduleList[i].data.length > 0) {
                    document.getElementById('tbodyItem' + i).classList.add("active");
                    document.getElementById('tbodyView' + i).classList.remove("hide");
                    this.weekScheduleList[i].data.forEach(function (sch) {
                        if (!_this.isChecked) {
                            if (sch.class_type != "Exam") {
                                if (sch.selected == true) {
                                    sch.selected = false;
                                    if (_this.selectedArray.classSchldId.indexOf(sch.schd_id) > -1) {
                                        _this.selectedArray.classSchldId.splice(_this.selectedArray.classSchldId.indexOf(sch.schd_id), 1);
                                    }
                                }
                            }
                        }
                        else {
                            if (sch.class_type != "Exam") {
                                if (sch.selected == false) {
                                    sch.selected = true;
                                    _this.selectedArray.classSchldId.push(sch.schd_id);
                                }
                            }
                        }
                    });
                }
            }
        }
    };
    // Hide Past Schedules
    ClassHomeComponent.prototype.hidePastClassAction = function (data) {
        var date = data.id.split('(');
        if (__WEBPACK_IMPORTED_MODULE_2_moment__(date[0]).format('YYYY-MM-DD') >= __WEBPACK_IMPORTED_MODULE_2_moment__().format('YYYY-MM-DD')) {
            return true;
        }
        else {
            return false;
        }
    };
    ClassHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-class-home',
            template: __webpack_require__("./src/app/components/course-module/create-course/course-class/class-home/class-home.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/create-course/course-class/class-home/class-home.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_3__services_course_services_class_schedule_service__["a" /* ClassScheduleService */],
            __WEBPACK_IMPORTED_MODULE_4__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_5__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], ClassHomeComponent);
    return ClassHomeComponent;
}());

var DateFormat = /** @class */ (function () {
    function DateFormat() {
    }
    DateFormat.prototype.transform = function (value) {
        if (value != "" && value != null && value != undefined) {
            return __WEBPACK_IMPORTED_MODULE_2_moment__(value).format('DD-MMM-YYYY');
        }
        else {
            return value;
        }
    };
    DateFormat = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Pipe"])({
            name: 'dateMonthYearFromat'
        })
    ], DateFormat);
    return DateFormat;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/course-class/course-class.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-class/course-class.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/course-module/create-course/course-class/course-class.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CourseClassComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var CourseClassComponent = /** @class */ (function () {
    function CourseClassComponent() {
    }
    CourseClassComponent.prototype.ngOnInit = function () {
    };
    CourseClassComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-course-class',
            template: __webpack_require__("./src/app/components/course-module/create-course/course-class/course-class.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/create-course/course-class/course-class.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], CourseClassComponent);
    return CourseClassComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/course-class/course-class.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseClassModule", function() { return CourseClassModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__progress_kendo_angular_treeview__ = __webpack_require__("./node_modules/@progress/kendo-angular-treeview/dist/fesm5/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__course_class_routing_module__ = __webpack_require__("./src/app/components/course-module/create-course/course-class/course-class.routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__course_class_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-class/course-class.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__class_home_class_home_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-class/class-home/class-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__class_add_class_add_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-class/class-add/class-add.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10_hammerjs__ = __webpack_require__("./node_modules/hammerjs/hammer.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10_hammerjs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10_hammerjs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12_ngx_bootstrap_custome_timepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/timepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13_primeng_primeng__ = __webpack_require__("./node_modules/primeng/primeng.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13_primeng_primeng___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_13_primeng_primeng__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__services_course_services_class_schedule_service__ = __webpack_require__("./src/app/services/course-services/class-schedule.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__services_course_services_topic_listing_service__ = __webpack_require__("./src/app/services/course-services/topic-listing.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};















// import { TreeviewModule } from 'ngx-treeview';

var CourseClassModule = /** @class */ (function () {
    function CourseClassModule() {
    }
    CourseClassModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__progress_kendo_angular_treeview__["a" /* TreeViewModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_3__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_4__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_11_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_12_ngx_bootstrap_custome_timepicker__["a" /* TimepickerModule */],
                __WEBPACK_IMPORTED_MODULE_13_primeng_primeng__["FileUploadModule"],
                __WEBPACK_IMPORTED_MODULE_13_primeng_primeng__["SplitButtonModule"],
                __WEBPACK_IMPORTED_MODULE_13_primeng_primeng__["ButtonModule"],
                __WEBPACK_IMPORTED_MODULE_13_primeng_primeng__["MenuModule"],
                __WEBPACK_IMPORTED_MODULE_2__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_5__course_class_routing_module__["a" /* CourseClassRouting */],
            ],
            exports: [],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_6__course_class_component__["a" /* CourseClassComponent */],
                __WEBPACK_IMPORTED_MODULE_7__class_home_class_home_component__["a" /* ClassHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_8__class_add_class_add_component__["a" /* ClassAddComponent */],
                __WEBPACK_IMPORTED_MODULE_7__class_home_class_home_component__["b" /* DateFormat */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_14__services_course_services_class_schedule_service__["a" /* ClassScheduleService */],
                __WEBPACK_IMPORTED_MODULE_15__services_course_services_topic_listing_service__["a" /* TopicListingService */]
            ]
        })
    ], CourseClassModule);
    return CourseClassModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/create-course/course-class/course-class.routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CourseClassRouting; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__course_class_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-class/course-class.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__class_home_class_home_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-class/class-home/class-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__class_add_class_add_component__ = __webpack_require__("./src/app/components/course-module/create-course/course-class/class-add/class-add.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var CourseClassRouting = /** @class */ (function () {
    function CourseClassRouting() {
    }
    CourseClassRouting = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__course_class_component__["a" /* CourseClassComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                redirectTo: 'home'
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_3__class_home_class_home_component__["a" /* ClassHomeComponent */]
                            },
                            {
                                path: 'add',
                                component: __WEBPACK_IMPORTED_MODULE_4__class_add_class_add_component__["a" /* ClassAddComponent */]
                            }
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], CourseClassRouting);
    return CourseClassRouting;
}());



/***/ })

});
//# sourceMappingURL=course-class.module.chunk.js.map