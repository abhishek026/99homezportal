webpackJsonp(["report.module"],{

/***/ "./src/app/components/library-management/report/fine-collection/fine-collection.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<section>\r\n  <div class=\"filter-date-container\">\r\n    <button class=\"pull-right\" (click)=\"openCalendar('fineCollectionRange')\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">\r\n            <g fill=\"#0084F6\" fill-rule=\"nonzero\">\r\n                <path d=\"M18.667 5.5H16.5v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1H5.333C4.598 5.5 4 6.096 4 6.833v11.833C4 19.403 4.597 20 5.333 20h13.334c.736 0 1.333-.597 1.333-1.334V6.833c0-.737-.596-1.333-1.333-1.333zM19 18.666c0 .184-.15.334-.333.334H5.333A.334.334 0 0 1 5 18.666V6.833c0-.184.15-.333.333-.333H7.5v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h2.167c.183 0 .333.15.333.333v11.833z\"\r\n                />\r\n                <path d=\"M7.5 10h2v1.5h-2zM7.5 12.5h2V14h-2zM7.5 15h2v1.5h-2zM11 15h2v1.5h-2zM11 12.5h2V14h-2zM11 10h2v1.5h-2zM14.5 15h2v1.5h-2zM14.5 12.5h2V14h-2zM14.5 10h2v1.5h-2z\"\r\n                />\r\n            </g>\r\n        </svg>\r\n    </button>\r\n    <input type=\"text\" value=\"\" id=\"fineCollectionRange\" class=\"widgetDatepicker bsDatepicker\" name=\"fineCollectionRange\" [(ngModel)]=\"fineCollectionRange\"\r\n        (ngModelChange)=\"updateDateRange($event)\" readonly=\"true\" bsDaterangepicker/>\r\n    <span class=\"enquiry-state-date pull-right\">\r\n        {{getStartDate()| date: 'dd MMM yyyy'}} To {{getEndDate()| date: 'dd MMM yyyy'}}\r\n    </span>\r\n  </div>\r\n  <div class=\"filter-search-container\">\r\n    <input class=\"search-box form-ctrl\" type=\"text\" placeholder=\"Search\" (keyup)=\"searchDatabase()\" [(ngModel)]=\"searchText\">\r\n  </div>\r\n</section>\r\n\r\n<section>\r\n  <div class=\"table-container\">\r\n    <div class=\"heading-container\">\r\n      <div class=\"heading-item\">\r\n        <span>BooK Title</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Borrower</span>\r\n      </div>\r\n      <div class=\"heading-item\" style=\"width: 15%;\">\r\n        <span>Issue Date</span>\r\n      </div>\r\n      <div class=\"heading-item\" style=\"width: 15%;\">\r\n        <span>Due Date</span>\r\n      </div>\r\n      <div class=\"heading-item\" style=\"width: 22%;\">\r\n        <span>Return Date</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>No Of Late Days</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Status</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Total Fine</span>\r\n      </div> \r\n    </div>\r\n    <div class=\"value-outer-container\">\r\n      <div class=\"value-container\" *ngFor=\"let report of tempFineCollectionReportList\">\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.title}}\">{{ (report.title.length > 20) ? (report.title | slice:0:20) + '...' : report.title }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.borrower}}\">{{ (report.borrower.length > 20) ? (report.borrower | slice:0:20) + '...' : report.borrower }}</span>\r\n        </div>\r\n        <div class=\"value-item\" style=\"width: 15%;\">\r\n          <span title=\"{{report.issuedDate | date: 'dd MMM yyyy'}}\">{{report.issuedDate | date: 'dd MMM yyyy'}}</span>\r\n        </div>\r\n        <div class=\"value-item\" style=\"width: 15%;\">\r\n          <span title=\"{{report.returnDate | date: 'dd MMM yyyy'}}\">{{report.returnDate | date: 'dd MMM yyyy'}}</span>\r\n        </div>\r\n        <div class=\"value-item\" style=\"width: 22%;\">\r\n          <span *ngIf=\"(report.status !== 40 && report.status !== 60)\" title=\"{{report.actualReturnDate | date: 'dd MMM yyyy'}}\">{{report.actualReturnDate | date: 'dd MMM yyyy'}}</span>\r\n          <span title=\"-\" *ngIf=\"(report.status === 40 || report.status === 60)\">-</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n          <span title=\"{{report.noOfLateDays==0 ?'-':report.noOfLateDays}}\">{{report.noOfLateDays==0 ?'-':report.noOfLateDays}}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n          <span *ngIf=\"report.status==10\" title=\"Issued\">Issued</span>            \r\n          <span *ngIf=\"report.status==20\" title=\"Returned\">Returned</span>\r\n          <span *ngIf=\"report.status==30\" title=\"Overdue\">Overdue</span>\r\n          <span *ngIf=\"report.status==40\" title=\"Lost By Student\">Lost By Student</span>\r\n          <span *ngIf=\"report.status==50\" title=\"Scrapped By Student\">Scrapped By Student</span>\r\n          <span *ngIf=\"report.status==60\" title=\"Lost In Library\">Lost In Library</span>\r\n          <span *ngIf=\"report.status==70\" title=\"Scrapped In Library\">Scrapped In Library</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n          <span title=\"{{report.totalFine}}\">{{report.totalFine}}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"no-records\" *ngIf=\"tempFineCollectionReportList?.length == 0 || tempFineCollectionReportList==null\">\r\n        <span>No Records Found</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n<div class=\"row filter-res pagination\" #pager id=\"pager\" style=\"width: 100%;\">\r\n    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n      <pagination (goPage)=\"fectchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\"\r\n        [pagesToShow]=\"10\" [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [sizeArr]=\"sizeArr\"\r\n        (sizeChange)=\"updateTableBatchSize($event)\" [count]=\"totalCount\">\r\n      </pagination>\r\n    </div>\r\n  </div>"

/***/ }),

/***/ "./src/app/components/library-management/report/fine-collection/fine-collection.component.scss":
/***/ (function(module, exports) {

module.exports = ".filter-date-container {\n  position: relative; }\n  .filter-date-container .enquiry-state-date {\n    font-size: 14px;\n    color: #666;\n    margin-right: 10px;\n    padding-top: 4px;\n    display: inline-block; }\n  .widgetDatepicker {\n  position: absolute;\n  margin-left: -10%;\n  width: 1px;\n  visibility: hidden;\n  opacity: 0; }\n  button {\n  background: transparent; }\n  button.drag-button {\n    cursor: all-scroll;\n    margin-left: 16px; }\n  .table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%; }\n  .table-container .heading-container {\n    background: #e0eaec;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    font-size: 14px;\n    font-weight: 600;\n    text-align: left;\n    padding: 10px;\n    border: 1px solid #ccc; }\n  .table-container .heading-container .heading-item {\n      width: 20%; }\n  .table-container .value-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    min-height: 50vh;\n    max-height: 50vh;\n    overflow-x: hidden;\n    overflow-y: auto;\n    border: 1px solid #ccc; }\n  .table-container .value-outer-container .value-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      text-align: left;\n      padding: 10px;\n      font-size: 12px;\n      border-bottom: 1px solid #ccc;\n      border-top: none; }\n  .table-container .value-outer-container .value-container .value-item {\n        width: 20%; }\n  .table-container .value-outer-container .no-records {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: center;\n          -ms-flex-pack: center;\n              justify-content: center;\n      padding: 10px;\n      font-size: 14px;\n      font-weight: 600;\n      border: 1px solid #ccc;\n      border-top: none; }\n  ::ng-deep bs-daterangepicker-container {\n  z-index: 1100;\n  left: 650px !important; }\n  .search-box {\n  border: 1px solid #ccc;\n  padding: 5px;\n  width: 20%;\n  float: right;\n  margin-right: 25px;\n  margin-bottom: 10px; }\n"

/***/ }),

/***/ "./src/app/components/library-management/report/fine-collection/fine-collection.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FineCollectionComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_library_report_report_service__ = __webpack_require__("./src/app/services/library/report/report.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var FineCollectionComponent = /** @class */ (function () {
    function FineCollectionComponent(router, cd, reportService) {
        this.router = router;
        this.cd = cd;
        this.reportService = reportService;
        this.jsonFlag = {
            isProfessional: false,
            isRippleLoad: false
        };
        this.fineCollectionReportList = {
            results: [],
            totalRecords: 0
        };
        this.tempFineCollectionReportList = [];
        this.fineCollectionRange = [];
        this.sort = false;
        // FOR PAGINATION
        this.pageIndex = 1;
        this.displayBatchSize = 10;
        this.totalCount = 0;
        this.sizeArr = [10, 25, 50, 100, 150, 200, 500];
    }
    FineCollectionComponent.prototype.ngOnInit = function () {
        this.fineCollectionRange[0] = new Date(__WEBPACK_IMPORTED_MODULE_3_moment__().date(1).format("YYYY-MM-DD"));
        this.fineCollectionRange[1] = new Date();
        this.getFineCollectionReport(this.fineCollectionRange[0], this.fineCollectionRange[1]);
    };
    FineCollectionComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            var searchData = void 0;
            var data_1 = this.fineCollectionReportList.results;
            var peopleArray = Object.keys(data_1).map(function (i) { return data_1[i]; });
            searchData = peopleArray.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.tempFineCollectionReportList = searchData;
        }
        else {
            this.tempFineCollectionReportList = this.fineCollectionReportList.results;
        }
    };
    FineCollectionComponent.prototype.getFineCollectionReport = function (startDate, endDate) {
        var _this = this;
        var obj = {
            "between": {
                "from": startDate,
                "to": endDate
            },
            "sortBy": {
                "assending": this.sort
            },
            "pageNo": this.pageIndex,
            "noOfRecords": this.displayBatchSize
        };
        this.jsonFlag.isRippleLoad = true;
        this.reportService.getFineCollectionReport(obj).subscribe(function (response) {
            _this.jsonFlag.isRippleLoad = false;
            var res;
            res = response;
            _this.fineCollectionReportList = res;
            _this.totalCount = res.totalRecords;
            _this.tempFineCollectionReportList = res.results;
        }, function (errorResponse) {
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    FineCollectionComponent.prototype.getStartDate = function () {
        this.cd.markForCheck();
        var date = __WEBPACK_IMPORTED_MODULE_3_moment__().date(1).format("YYYY-MM-DD");
        return this.fineCollectionRange[0];
    };
    FineCollectionComponent.prototype.getEndDate = function () {
        this.cd.markForCheck();
        return this.fineCollectionRange[1];
    };
    FineCollectionComponent.prototype.updateDateRange = function (e) {
        this.cd.markForCheck();
        this.getFineCollectionReport(__WEBPACK_IMPORTED_MODULE_3_moment__(e[0]).format("YYYY-MM-DD"), __WEBPACK_IMPORTED_MODULE_3_moment__(e[1]).format("YYYY-MM-DD"));
    };
    FineCollectionComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    FineCollectionComponent.prototype.sortTable = function (obj) {
        this.sort = !this.sort;
        // this.fineCollectionRange[0] = new Date(moment().date(1).format("YYYY-MM-DD"));
        // this.fineCollectionRange[1] = new Date();
        // console.log(this.fineCollectionRange)
        this.getFineCollectionReport(__WEBPACK_IMPORTED_MODULE_3_moment__(this.fineCollectionRange[0]).format("YYYY-MM-DD"), __WEBPACK_IMPORTED_MODULE_3_moment__(this.fineCollectionRange[1]).format("YYYY-MM-DD"));
    };
    /*** pagination functions */
    /* Fetch next set of data from server and update table */
    FineCollectionComponent.prototype.fetchNext = function () {
        this.pageIndex++;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch previous set of data from server and update table */
    FineCollectionComponent.prototype.fetchPrevious = function () {
        this.pageIndex--;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch table data by page index */
    FineCollectionComponent.prototype.fectchTableDataByPage = function (index) {
        this.pageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.getFineCollectionReport(__WEBPACK_IMPORTED_MODULE_3_moment__(this.fineCollectionRange[0]).format("YYYY-MM-DD"), __WEBPACK_IMPORTED_MODULE_3_moment__(this.fineCollectionRange[1]).format("YYYY-MM-DD"));
    };
    /* Fetches Data as per the user selected batch size */
    FineCollectionComponent.prototype.updateTableBatchSize = function (num) {
        this.pageIndex = 1;
        this.displayBatchSize = parseInt(num);
        this.getFineCollectionReport(__WEBPACK_IMPORTED_MODULE_3_moment__(this.fineCollectionRange[0]).format("YYYY-MM-DD"), __WEBPACK_IMPORTED_MODULE_3_moment__(this.fineCollectionRange[1]).format("YYYY-MM-DD"));
    };
    FineCollectionComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-fine-collection',
            template: __webpack_require__("./src/app/components/library-management/report/fine-collection/fine-collection.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/report/fine-collection/fine-collection.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"],
            __WEBPACK_IMPORTED_MODULE_1__services_library_report_report_service__["a" /* ReportService */]])
    ], FineCollectionComponent);
    return FineCollectionComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/report/issued-book/issued-book.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<section>\r\n  <div class=\"filter-date-container\">\r\n    <button class=\"pull-right\" (click)=\"openCalendar('issueBookRange')\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">\r\n            <g fill=\"#0084F6\" fill-rule=\"nonzero\">\r\n                <path d=\"M18.667 5.5H16.5v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1H5.333C4.598 5.5 4 6.096 4 6.833v11.833C4 19.403 4.597 20 5.333 20h13.334c.736 0 1.333-.597 1.333-1.334V6.833c0-.737-.596-1.333-1.333-1.333zM19 18.666c0 .184-.15.334-.333.334H5.333A.334.334 0 0 1 5 18.666V6.833c0-.184.15-.333.333-.333H7.5v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h2.167c.183 0 .333.15.333.333v11.833z\"\r\n                />\r\n                <path d=\"M7.5 10h2v1.5h-2zM7.5 12.5h2V14h-2zM7.5 15h2v1.5h-2zM11 15h2v1.5h-2zM11 12.5h2V14h-2zM11 10h2v1.5h-2zM14.5 15h2v1.5h-2zM14.5 12.5h2V14h-2zM14.5 10h2v1.5h-2z\"\r\n                />\r\n            </g>\r\n        </svg>\r\n    </button>\r\n    <input type=\"text\" value=\"\" id=\"issueBookRange\" class=\"widgetDatepicker bsDatepicker\" name=\"issueBookRange\" [(ngModel)]=\"issueBookRange\"\r\n        (ngModelChange)=\"updateDateRange($event)\" readonly=\"true\" bsDaterangepicker/>\r\n    <span class=\"enquiry-state-date pull-right\">\r\n        {{getStartDate()| date: 'dd MMM yyyy'}} To {{getEndDate()| date: 'dd MMM yyyy'}}\r\n    </span>\r\n  </div>\r\n  <div class=\"filter-search-container\">\r\n    <input class=\"search-box form-ctrl\" type=\"text\" placeholder=\"Search\" (keyup)=\"searchDatabase()\" [(ngModel)]=\"searchText\">\r\n  </div>\r\n</section>\r\n\r\n<section>\r\n  <div class=\"table-container\">\r\n    <div class=\"heading-container\">\r\n      <div class=\"heading-item\">\r\n        <span>Book Title</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Borrower Name</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Issue Date</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Due Date</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"value-outer-container\">\r\n      <div class=\"value-container\" *ngFor=\"let report of issueBookReportList\">\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.title}}\">{{ (report.title.length > 20) ? (report.title | slice:0:20) + '...' : report.title }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.borrower}}\">{{ (report.borrower.length > 20) ? (report.borrower | slice:0:20) + '...' : report.borrower }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n          <span title=\"{{report.issuedDate | date: 'dd MMM yyyy'}}\">{{report.issuedDate | date: 'dd MMM yyyy'}}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n          <span title=\"{{report.returnDate | date: 'dd MMM yyyy'}}\">{{report.returnDate | date: 'dd MMM yyyy'}}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"no-records\" *ngIf=\"issueBookReportList?.length == 0 ||issueBookReportList==null \">\r\n        <span>No Records Found</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n<div class=\"row filter-res pagination\" #pager id=\"pager\" style=\"width: 100%;\">\r\n    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n      <pagination (goPage)=\"fectchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\"\r\n        [pagesToShow]=\"10\" [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [sizeArr]=\"sizeArr\"\r\n        (sizeChange)=\"updateTableBatchSize($event)\" [count]=\"totalCount\">\r\n      </pagination>\r\n    </div>\r\n  </div>"

/***/ }),

/***/ "./src/app/components/library-management/report/issued-book/issued-book.component.scss":
/***/ (function(module, exports) {

module.exports = ".filter-date-container {\n  position: relative; }\n  .filter-date-container .enquiry-state-date {\n    font-size: 14px;\n    color: #666;\n    margin-right: 10px;\n    padding-top: 4px;\n    display: inline-block; }\n  ::ng-deep bs-datepicker-container, bs-daterangepicker-container {\n  left: 650 !important; }\n  .widgetDatepicker {\n  position: absolute;\n  right: 30%;\n  width: 1px;\n  visibility: hidden;\n  opacity: 0; }\n  .search-box {\n  border: 1px solid #ccc;\n  padding: 5px;\n  width: 20%;\n  float: right;\n  margin-right: 25px;\n  margin-bottom: 10px; }\n  button {\n  background: transparent; }\n  button.drag-button {\n    cursor: all-scroll;\n    margin-left: 16px; }\n  .table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%; }\n  .table-container .heading-container {\n    background: #e0eaec;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    font-size: 14px;\n    font-weight: 600;\n    text-align: left;\n    padding: 10px;\n    border: 1px solid #ccc; }\n  .table-container .heading-container .heading-item {\n      width: 20%; }\n  .table-container .value-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    min-height: 50vh;\n    max-height: 50vh;\n    overflow-x: hidden;\n    overflow-y: auto;\n    border: 1px solid #ccc; }\n  .table-container .value-outer-container .value-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      text-align: left;\n      padding: 10px;\n      font-size: 12px;\n      border-bottom: 1px solid #ccc;\n      border-top: none; }\n  .table-container .value-outer-container .value-container .value-item {\n        width: 20%; }\n  .table-container .value-outer-container .no-records {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: center;\n          -ms-flex-pack: center;\n              justify-content: center;\n      padding: 10px;\n      font-size: 14px;\n      font-weight: 600;\n      border: 1px solid #ccc;\n      border-top: none; }\n"

/***/ }),

/***/ "./src/app/components/library-management/report/issued-book/issued-book.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return IssuedBookComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_library_report_report_service__ = __webpack_require__("./src/app/services/library/report/report.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var IssuedBookComponent = /** @class */ (function () {
    function IssuedBookComponent(router, cd, reportService) {
        this.router = router;
        this.cd = cd;
        this.reportService = reportService;
        this.jsonFlag = {
            isProfessional: false,
            isRippleLoad: false
        };
        this.issueBookReportList = [];
        this.issueBookRange = [];
        // FOR PAGINATION
        this.pageIndex = 1;
        this.displayBatchSize = 10;
        this.totalCount = 0;
        this.sizeArr = [10, 25, 50, 100, 150, 200, 500];
    }
    IssuedBookComponent.prototype.ngOnInit = function () {
        this.issueBookRange[0] = new Date(__WEBPACK_IMPORTED_MODULE_3_moment__().date(1).format("YYYY-MM-DD"));
        this.issueBookRange[1] = new Date(__WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-DD"));
        // this.getIssueBookReport(this.issueBookRange[0], this.issueBookRange[1]);
    };
    IssuedBookComponent.prototype.getIssueBookReport = function (startDate, endDate) {
        var _this = this;
        var obj = {
            "between": {
                "from": startDate,
                "to": endDate
            },
            "in": [
                {
                    "column": "status",
                    "values": [10]
                }
            ],
            "pageNo": this.pageIndex,
            "noOfRecords": this.displayBatchSize
        };
        this.jsonFlag.isRippleLoad = true;
        this.reportService.getIssueBookReport(obj).subscribe(function (response) {
            _this.jsonFlag.isRippleLoad = false;
            var res;
            res = response;
            _this.issueBookReportList = res.results;
            _this.fixedIssueBookList = res.results;
            _this.totalCount = res.totalRecords;
        }, function (errorResponse) {
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    IssuedBookComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            var searchData = void 0;
            var peopleArray = Object.keys(this.fixedIssueBookList).map(function (i) { return _this.fixedIssueBookList[i]; });
            searchData = peopleArray.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.issueBookReportList = searchData;
        }
        else {
            this.issueBookReportList = this.fixedIssueBookList;
        }
    };
    IssuedBookComponent.prototype.getStartDate = function () {
        this.cd.markForCheck();
        var date = new Date(__WEBPACK_IMPORTED_MODULE_3_moment__().date(1).format("YYYY-MM-DD"));
        return this.issueBookRange[0];
    };
    IssuedBookComponent.prototype.getEndDate = function () {
        this.cd.markForCheck();
        return this.issueBookRange[1];
    };
    IssuedBookComponent.prototype.updateDateRange = function (e) {
        this.cd.markForCheck();
        this.getIssueBookReport(__WEBPACK_IMPORTED_MODULE_3_moment__(e[0]).format("YYYY-MM-DD"), __WEBPACK_IMPORTED_MODULE_3_moment__(e[1]).format("YYYY-MM-DD"));
    };
    IssuedBookComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    /*** pagination functions */
    /* Fetch next set of data from server and update table */
    IssuedBookComponent.prototype.fetchNext = function () {
        this.pageIndex++;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch previous set of data from server and update table */
    IssuedBookComponent.prototype.fetchPrevious = function () {
        this.pageIndex--;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch table data by page index */
    IssuedBookComponent.prototype.fectchTableDataByPage = function (index) {
        this.pageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.getIssueBookReport(__WEBPACK_IMPORTED_MODULE_3_moment__(this.issueBookRange[0]).format("YYYY-MM-DD"), __WEBPACK_IMPORTED_MODULE_3_moment__(this.issueBookRange[1]).format("YYYY-MM-DD"));
    };
    /* Fetches Data as per the user selected batch size */
    IssuedBookComponent.prototype.updateTableBatchSize = function (num) {
        this.pageIndex = 1;
        this.displayBatchSize = parseInt(num);
        this.getIssueBookReport(__WEBPACK_IMPORTED_MODULE_3_moment__(this.issueBookRange[0]).format("YYYY-MM-DD"), __WEBPACK_IMPORTED_MODULE_3_moment__(this.issueBookRange[1]).format("YYYY-MM-DD"));
    };
    IssuedBookComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-issued-book',
            template: __webpack_require__("./src/app/components/library-management/report/issued-book/issued-book.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/report/issued-book/issued-book.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"],
            __WEBPACK_IMPORTED_MODULE_1__services_library_report_report_service__["a" /* ReportService */]])
    ], IssuedBookComponent);
    return IssuedBookComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/report/lost-book/lost-book.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<section>\r\n  <div class=\"filter-date-container\">\r\n    <button class=\"pull-right\" (click)=\"openCalendar('lostbookrange')\">\r\n      <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">\r\n        <g fill=\"#0084F6\" fill-rule=\"nonzero\">\r\n          <path d=\"M18.667 5.5H16.5v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1H5.333C4.598 5.5 4 6.096 4 6.833v11.833C4 19.403 4.597 20 5.333 20h13.334c.736 0 1.333-.597 1.333-1.334V6.833c0-.737-.596-1.333-1.333-1.333zM19 18.666c0 .184-.15.334-.333.334H5.333A.334.334 0 0 1 5 18.666V6.833c0-.184.15-.333.333-.333H7.5v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h2.167c.183 0 .333.15.333.333v11.833z\"\r\n          />\r\n          <path d=\"M7.5 10h2v1.5h-2zM7.5 12.5h2V14h-2zM7.5 15h2v1.5h-2zM11 15h2v1.5h-2zM11 12.5h2V14h-2zM11 10h2v1.5h-2zM14.5 15h2v1.5h-2zM14.5 12.5h2V14h-2zM14.5 10h2v1.5h-2z\"\r\n          />\r\n        </g>\r\n      </svg>\r\n    </button>\r\n    <input type=\"text\" value=\"\" id=\"lostbookrange\" class=\"widgetDatepicker bsDatepicker\" name=\"lostbookrange\"\r\n      [(ngModel)]=\"lostbookrange\" (ngModelChange)=\"updateEnqChartByDate($event)\"  bsDaterangepicker/>\r\n    <span class=\"enquiry-state-date pull-right\">\r\n        {{getStartDate()| date: 'dd MMM yyyy'}} To {{getEndDate()| date: 'dd MMM yyyy'}}\r\n    </span>\r\n  </div>\r\n  <div class=\"filter-search-container\">\r\n    <input class=\"search-box form-ctrl\" type=\"text\" placeholder=\"Search\" (keyup)=\"searchDatabase()\" [(ngModel)]=\"searchText\">\r\n  </div>\r\n</section>\r\n\r\n<section>\r\n  <div class=\"table-container\">\r\n    <div class=\"heading-container\">\r\n      <div class=\"heading-item\">\r\n        <span>Book Title</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Borrower Name</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Lost Date</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Remarks</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"value-outer-container\">\r\n      <div class=\"value-container\" *ngFor=\"let report of lostBookReportList\">\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.title}}\">{{ (report.title.length > 20) ? (report.title | slice:0:20) + '...' : report.title }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.borrower}}\">{{ (report.borrower.length > 20) ? (report.borrower | slice:0:20) + '...' : report.borrower }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n          <span title=\"{{report.date | date: 'dd MMM yyyy'}}\">{{report.date | date: 'dd MMM yyyy'}}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.remark}}\">{{ (report.remark.length > 20) ? (report.remark | slice:0:20) + '...' : report.remark }}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"no-records\" *ngIf=\"lostBookReportList.length == 0\">\r\n        <span>No Records Found</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n"

/***/ }),

/***/ "./src/app/components/library-management/report/lost-book/lost-book.component.scss":
/***/ (function(module, exports) {

module.exports = ".filter-date-container .enquiry-state-date {\n  font-size: 14px;\n  color: #666;\n  margin-right: 10px;\n  padding-top: 4px;\n  display: inline-block; }\n\n.widgetDatepicker {\n  position: absolute;\n  margin-left: -10%;\n  width: 1px;\n  visibility: hidden;\n  opacity: 0; }\n\n.bsDatepicker {\n  padding: 5px;\n  width: 100%;\n  position: absolute; }\n\n.search-box {\n  border: 1px solid #ccc;\n  padding: 5px;\n  width: 20%;\n  float: right;\n  margin-right: 25px;\n  margin-bottom: 10px; }\n\nbutton {\n  background: transparent; }\n\nbutton.drag-button {\n    cursor: all-scroll;\n    margin-left: 16px; }\n\n.table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%; }\n\n.table-container .heading-container {\n    background: #e0eaec;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    font-size: 14px;\n    font-weight: 600;\n    text-align: left;\n    padding: 10px;\n    border: 1px solid #ccc; }\n\n.table-container .heading-container .heading-item {\n      width: 20%; }\n\n.table-container .value-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    min-height: 50vh;\n    max-height: 50vh;\n    overflow-x: hidden;\n    overflow-y: auto;\n    border: 1px solid #ccc; }\n\n.table-container .value-outer-container .value-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      text-align: left;\n      padding: 10px;\n      font-size: 12px;\n      border-bottom: 1px solid #ccc;\n      border-top: none; }\n\n.table-container .value-outer-container .value-container .value-item {\n        width: 20%; }\n\n.table-container .value-outer-container .no-records {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: center;\n          -ms-flex-pack: center;\n              justify-content: center;\n      padding: 10px;\n      font-size: 14px;\n      font-weight: 600;\n      border: 1px solid #ccc;\n      border-top: none; }\n"

/***/ }),

/***/ "./src/app/components/library-management/report/lost-book/lost-book.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LostBookComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_library_report_report_service__ = __webpack_require__("./src/app/services/library/report/report.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var LostBookComponent = /** @class */ (function () {
    function LostBookComponent(router, cd, reportService) {
        this.router = router;
        this.cd = cd;
        this.reportService = reportService;
        this.jsonFlag = {
            isProfessional: false,
            isRippleLoad: false
        };
        this.lostbookrange = [];
        this.lostBookReportList = [];
    }
    LostBookComponent.prototype.ngOnInit = function () {
        this.lostbookrange[0] = new Date(__WEBPACK_IMPORTED_MODULE_2_moment__().date(1).format("YYYY-MM-DD"));
        this.lostbookrange[1] = new Date(__WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-DD"));
        // this.getLostBookReport(this.lostbookrange[0],this.lostbookrange[1]);
    };
    LostBookComponent.prototype.getLostBookReport = function (startDate, endDate) {
        var _this = this;
        var obj = {
            "between": {
                "from": startDate,
                "to": endDate
            },
            "in": [
                {
                    "column": "status",
                    "values": [40, 60]
                }
            ]
        };
        this.jsonFlag.isRippleLoad = true;
        this.reportService.getLostBookReport(obj).subscribe(function (response) {
            _this.jsonFlag.isRippleLoad = false;
            var result;
            result = response;
            if (result.length > 0) {
                _this.lostBookReportList = result;
                _this.fixedLostBookList = result;
            }
        }, function (errorResponse) {
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    LostBookComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            var searchData = void 0;
            var peopleArray = Object.keys(this.fixedLostBookList).map(function (i) { return _this.fixedLostBookList[i]; });
            searchData = peopleArray.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.lostBookReportList = searchData;
        }
        else {
            this.lostBookReportList = this.fixedLostBookList;
        }
    };
    LostBookComponent.prototype.getStartDate = function () {
        this.cd.markForCheck();
        var date = __WEBPACK_IMPORTED_MODULE_2_moment__().date(1).format("YYYY-MM-DD");
        return this.lostbookrange[0];
    };
    LostBookComponent.prototype.getEndDate = function () {
        this.cd.markForCheck();
        return this.lostbookrange[1];
    };
    LostBookComponent.prototype.updateEnqChartByDate = function (e) {
        this.cd.markForCheck();
        this.getLostBookReport(__WEBPACK_IMPORTED_MODULE_2_moment__(e[0]).format("YYYY-MM-DD"), __WEBPACK_IMPORTED_MODULE_2_moment__(e[1]).format("YYYY-MM-DD"));
    };
    LostBookComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    LostBookComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-lost-book',
            template: __webpack_require__("./src/app/components/library-management/report/lost-book/lost-book.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/report/lost-book/lost-book.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"],
            __WEBPACK_IMPORTED_MODULE_3__services_library_report_report_service__["a" /* ReportService */]])
    ], LostBookComponent);
    return LostBookComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/report/never-issued/never-issued.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<!-- <section>\r\n  <div class=\"filter-date-container\">\r\n    <button class=\"pull-right\" (click)=\"openCalendar('neverIssueCollectionRange')\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">\r\n            <g fill=\"#0084F6\" fill-rule=\"nonzero\">\r\n                <path d=\"M18.667 5.5H16.5v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1H5.333C4.598 5.5 4 6.096 4 6.833v11.833C4 19.403 4.597 20 5.333 20h13.334c.736 0 1.333-.597 1.333-1.334V6.833c0-.737-.596-1.333-1.333-1.333zM19 18.666c0 .184-.15.334-.333.334H5.333A.334.334 0 0 1 5 18.666V6.833c0-.184.15-.333.333-.333H7.5v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h2.167c.183 0 .333.15.333.333v11.833z\"\r\n                />\r\n                <path d=\"M7.5 10h2v1.5h-2zM7.5 12.5h2V14h-2zM7.5 15h2v1.5h-2zM11 15h2v1.5h-2zM11 12.5h2V14h-2zM11 10h2v1.5h-2zM14.5 15h2v1.5h-2zM14.5 12.5h2V14h-2zM14.5 10h2v1.5h-2z\"\r\n                />\r\n            </g>\r\n        </svg>\r\n    </button>\r\n    <input type=\"text\" value=\"\" id=\"neverIssueCollectionRange\" class=\"widgetDatepicker bsDatepicker\" name=\"fineCollectionRange\" [(ngModel)]=\"neverIssueCollectionRange\"\r\n        (ngModelChange)=\"updateDateRange($event)\" readonly=\"true\" bsDaterangepicker/>\r\n    <span class=\"enquiry-state-date pull-right\">\r\n        {{getStartDate()| date: 'dd MMM yyyy'}} To {{getEndDate()| date: 'dd MMM yyyy'}}\r\n    </span>\r\n  </div>\r\n</section> -->\r\n<section>\r\n  <div class=\"table-container\">\r\n    <div class=\"heading-container\">\r\n      <div class=\"heading-item\">\r\n        <span>Book Title</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Book Count</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Added Date</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Edition</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Publication</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Subject</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Volume</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"value-outer-container\">\r\n      <div class=\"value-container\" *ngFor=\"let report of neverIssuedBookReportList\">\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.book.title}}\">{{ (report.book.title.length > 20) ? (report.book.title | slice:0:20) + '...' : report.book.title }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.count}}\">{{ (report.count.length > 20) ? (report.count | slice:0:20) + '...' : report.count }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n          <span title=\"{{report.book.createdDate | date: 'dd MMM yyyy'}}\">{{report.book.createdDate | date: 'dd MMM yyyy'}}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.book.edition}}\">{{ (report.book.edition.length > 20) ? (report.book.edition | slice:0:20) + '...' : report.book.edition }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.book.publication.name}}\">{{ (report.book.publication.name.length > 20) ? (report.book.publication.name | slice:0:20) + '...' : report.book.publication.name }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.book.subject.name}}\">{{ (report.book.subject.name.length > 20) ? (report.book.subject.name | slice:0:20) + '...' : report.book.subject.name }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.book.volume}}\">{{ (report.book.volume.length > 20) ? (report.book.volume | slice:0:20) + '...' : report.book.volume }}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"no-records\" *ngIf=\"neverIssuedBookReportList.length == 0\">\r\n        <span>No Records Found</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n"

/***/ }),

/***/ "./src/app/components/library-management/report/never-issued/never-issued.component.scss":
/***/ (function(module, exports) {

module.exports = ".table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%; }\n  .table-container .heading-container {\n    background: #e0eaec;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    font-size: 14px;\n    font-weight: 600;\n    text-align: left;\n    padding: 10px;\n    border: 1px solid #ccc; }\n  .table-container .heading-container .heading-item {\n      width: 20%; }\n  .table-container .value-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    min-height: 50vh;\n    max-height: 50vh;\n    overflow-x: hidden;\n    overflow-y: auto;\n    border: 1px solid #ccc; }\n  .table-container .value-outer-container .value-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      text-align: left;\n      padding: 10px;\n      font-size: 12px;\n      border-bottom: 1px solid #ccc;\n      border-top: none; }\n  .table-container .value-outer-container .value-container .value-item {\n        width: 20%; }\n  .table-container .value-outer-container .no-records {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: center;\n          -ms-flex-pack: center;\n              justify-content: center;\n      padding: 10px;\n      font-size: 14px;\n      font-weight: 600;\n      border: 1px solid #ccc;\n      border-top: none; }\n  .search-box {\n  border: 1px solid #ccc;\n  padding: 5px;\n  width: 20%;\n  float: right;\n  margin-right: 25px;\n  margin-bottom: 10px; }\n  ::ng-deep bs-datepicker-container, bs-daterangepicker-container {\n  left: 650 !important; }\n  .filter-date-container {\n  position: relative; }\n  .filter-date-container .enquiry-state-date {\n    font-size: 14px;\n    color: #666;\n    margin-right: 10px;\n    padding-top: 4px;\n    display: inline-block; }\n"

/***/ }),

/***/ "./src/app/components/library-management/report/never-issued/never-issued.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return NeverIssuedComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_library_report_report_service__ = __webpack_require__("./src/app/services/library/report/report.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var NeverIssuedComponent = /** @class */ (function () {
    function NeverIssuedComponent(reportService, cd) {
        this.reportService = reportService;
        this.cd = cd;
        this.jsonFlag = {
            isProfessional: false,
            isRippleLoad: false
        };
        this.neverIssuedBookReportList = [];
        this.lostbookrange = [];
        this.lostBookReportList = [];
        this.neverIssueCollectionRange = [];
    }
    NeverIssuedComponent.prototype.ngOnInit = function () {
        this.lostbookrange[0] = new Date(__WEBPACK_IMPORTED_MODULE_2_moment__().date(1).format("YYYY-MM-DD"));
        this.lostbookrange[1] = new Date(__WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-DD"));
        this.getNeverIssuedBookReport();
    };
    NeverIssuedComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    NeverIssuedComponent.prototype.getStartDate = function () {
        this.cd.markForCheck();
        var date = __WEBPACK_IMPORTED_MODULE_2_moment__().date(1).format("YYYY-MM-DD");
        return this.neverIssueCollectionRange[0];
    };
    NeverIssuedComponent.prototype.getEndDate = function () {
        this.cd.markForCheck();
        return this.neverIssueCollectionRange[1];
    };
    NeverIssuedComponent.prototype.getNeverIssuedBookReport = function () {
        var _this = this;
        this.jsonFlag.isRippleLoad = true;
        this.reportService.getNeverIssuedBookReport().subscribe(function (response) {
            _this.jsonFlag.isRippleLoad = false;
            var res;
            res = response;
            _this.neverIssuedBookReportList = res.response;
            console.log(_this.neverIssuedBookReportList);
        }, function (errorResponse) {
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    NeverIssuedComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-never-issued',
            template: __webpack_require__("./src/app/components/library-management/report/never-issued/never-issued.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/report/never-issued/never-issued.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_library_report_report_service__["a" /* ReportService */],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"]])
    ], NeverIssuedComponent);
    return NeverIssuedComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/report/overdue-book/overdue-book.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<!-- <section>\r\n  <div class=\"filter-date-container\">\r\n    <button class=\"pull-right\" (click)=\"openCalendar('overdueCollectionRange')\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">\r\n            <g fill=\"#0084F6\" fill-rule=\"nonzero\">\r\n                <path d=\"M18.667 5.5H16.5v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1H5.333C4.598 5.5 4 6.096 4 6.833v11.833C4 19.403 4.597 20 5.333 20h13.334c.736 0 1.333-.597 1.333-1.334V6.833c0-.737-.596-1.333-1.333-1.333zM19 18.666c0 .184-.15.334-.333.334H5.333A.334.334 0 0 1 5 18.666V6.833c0-.184.15-.333.333-.333H7.5v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h2.167c.183 0 .333.15.333.333v11.833z\"\r\n                />\r\n                <path d=\"M7.5 10h2v1.5h-2zM7.5 12.5h2V14h-2zM7.5 15h2v1.5h-2zM11 15h2v1.5h-2zM11 12.5h2V14h-2zM11 10h2v1.5h-2zM14.5 15h2v1.5h-2zM14.5 12.5h2V14h-2zM14.5 10h2v1.5h-2z\"\r\n                />\r\n            </g>\r\n        </svg>\r\n    </button>\r\n    <input type=\"text\" value=\"\" id=\"overdueCollectionRange\" class=\"widgetDatepicker bsDatepicker\" name=\"overdueCollectionRange\" [(ngModel)]=\"overdueCollectionRange\"\r\n        (ngModelChange)=\"updateDateRange($event)\" readonly=\"true\" bsDaterangepicker/>\r\n    <span class=\"enquiry-state-date pull-right\">\r\n        {{getStartDate()| date: 'dd MMM yyyy'}} To {{getEndDate()| date: 'dd MMM yyyy'}}\r\n    </span>\r\n  </div>\r\n  <div class=\"filter-search-container\">\r\n    <input class=\"search-box form-ctrl\" type=\"text\" placeholder=\"Search\" (keyup)=\"searchDatabase()\" [(ngModel)]=\"searchText\">\r\n  </div>\r\n</section> -->\r\n\r\n<section>\r\n  <div class=\"table-container\">\r\n    <div class=\"heading-container\">\r\n      <div class=\"heading-item\">\r\n        <span>Book Title</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Borrower Name</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Issued Date</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Due Date</span>\r\n      </div>\r\n      <div class=\"heading-item\" style=\"text-align:center;\">\r\n        <span>No of Late Days</span>\r\n      </div>\r\n      <div class=\"heading-item\" style=\"text-align:center;\">\r\n        <span>Total Fine</span>\r\n      </div>\r\n      <!-- <div class=\"heading-item\" style=\"text-align:center;\">\r\n        <span>Action</span>\r\n      </div> -->\r\n    </div>\r\n    <div class=\"value-outer-container\">\r\n      <div class=\"value-container\" *ngFor=\"let report of overdueBookReportList\">\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.title}}\">{{ (report.title.length > 20) ? (report.title | slice:0:20) + '...' : report.title }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.borrower}}\">{{ (report.borrower.length > 20) ? (report.borrower | slice:0:20) + '...' : report.borrower }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n          <span title=\"{{report.issuedDate | date: 'dd MMM yyyy'}}\">{{report.issuedDate | date: 'dd MMM yyyy'}}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n          <span title=\"{{report.returnDate | date: 'dd MMM yyyy'}}\">{{report.returnDate | date: 'dd MMM yyyy'}}</span>\r\n        </div>\r\n        <div class=\"value-item\"  style=\"text-align:center;\">\r\n            <span title=\"{{report.noOfLateDays}}\">{{ (report.noOfLateDays.length > 20) ? (report.noOfLateDays | slice:0:20) + '...' : report.noOfLateDays }}</span>\r\n        </div>\r\n        <div class=\"value-item\"  style=\"text-align:center;\">\r\n            <span title=\"{{report.totalFine}}\">{{ (report.totalFine.length > 20) ? (report.totalFine | slice:0:20) + '...' : report.totalFine }}</span>\r\n        </div>\r\n        <!-- <div class=\"value-item\"  style=\"text-align:center;\">\r\n          <i class=\"fa fa-download\" aria-hidden=\"true\"  style=\"cursor: pointer;\" (click)=printFeeReceipt(report.issueBookId)></i>\r\n        </div> -->\r\n      </div>\r\n      <div class=\"no-records\" *ngIf=\"overdueBookReportList.length == 0\">\r\n        <span>No Records Found</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n</section>\r\n<div class=\"row filter-res pagination\" #pager id=\"pager\" style=\"width: 100%;margin-bottom: 0;\">\r\n  <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n    <pagination (goPage)=\"fectchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\"\r\n      [pagesToShow]=\"10\" [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [sizeArr]=\"sizeArr\"\r\n      (sizeChange)=\"updateTableBatchSize($event)\" [count]=\"totalCount\">\r\n    </pagination>\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./src/app/components/library-management/report/overdue-book/overdue-book.component.scss":
/***/ (function(module, exports) {

module.exports = ".table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%; }\n  .table-container .heading-container {\n    background: #e0eaec;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    font-size: 14px;\n    font-weight: 600;\n    text-align: left;\n    padding: 10px;\n    border: 1px solid #ccc; }\n  .table-container .heading-container .heading-item {\n      width: 20%; }\n  .table-container .value-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    min-height: 50vh;\n    max-height: 50vh;\n    overflow-x: hidden;\n    overflow-y: auto;\n    border: 1px solid #ccc; }\n  .table-container .value-outer-container .value-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      text-align: left;\n      padding: 10px;\n      font-size: 12px;\n      border-bottom: 1px solid #ccc;\n      border-top: none; }\n  .table-container .value-outer-container .value-container .value-item {\n        width: 20%; }\n  .table-container .value-outer-container .no-records {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: center;\n          -ms-flex-pack: center;\n              justify-content: center;\n      padding: 10px;\n      font-size: 14px;\n      font-weight: 600;\n      border: 1px solid #ccc;\n      border-top: none; }\n  .filter-date-container {\n  position: relative; }\n  .filter-date-container .enquiry-state-date {\n    font-size: 14px;\n    color: #666;\n    margin-right: 10px;\n    padding-top: 4px;\n    display: inline-block; }\n  .search-box {\n  border: 1px solid #ccc;\n  padding: 5px;\n  width: 20%;\n  float: right;\n  margin-right: 25px;\n  margin-bottom: 10px; }\n  ::ng-deep bs-datepicker-container, bs-daterangepicker-container {\n  left: 650 !important; }\n"

/***/ }),

/***/ "./src/app/components/library-management/report/overdue-book/overdue-book.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return OverdueBookComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_library_report_report_service__ = __webpack_require__("./src/app/services/library/report/report.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var OverdueBookComponent = /** @class */ (function () {
    function OverdueBookComponent(cd, reportService) {
        this.cd = cd;
        this.reportService = reportService;
        this.jsonFlag = {
            isProfessional: false,
            isRippleLoad: false
        };
        this.overdueBookReportList = [];
        this.tempOverdueBookReportList = {};
        this.overdueCollectionRange = [];
        // FOR PAGINATION
        this.pageIndex = 1;
        this.displayBatchSize = 10;
        this.totalCount = 0;
        this.sizeArr = [10, 25, 50, 100, 150, 200, 500];
    }
    OverdueBookComponent.prototype.ngOnInit = function () {
        this.overdueCollectionRange[0] = new Date(__WEBPACK_IMPORTED_MODULE_2_moment__().date(1).format("YYYY-MM-DD"));
        this.overdueCollectionRange[1] = new Date();
        this.getOverDueBookReport();
    };
    OverdueBookComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            var searchData = void 0;
            var data_1 = this.tempOverdueBookReportList;
            var peopleArray = Object.keys(data_1).map(function (i) { return data_1[i]; });
            searchData = peopleArray.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.tempOverdueBookReportList = searchData;
        }
        else {
            this.overdueBookReportList = this.tempOverdueBookReportList;
        }
    };
    OverdueBookComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    OverdueBookComponent.prototype.getStartDate = function () {
        this.cd.markForCheck();
        var date = __WEBPACK_IMPORTED_MODULE_2_moment__().date(1).format("YYYY-MM-DD");
        return this.overdueCollectionRange[0];
    };
    OverdueBookComponent.prototype.getEndDate = function () {
        this.cd.markForCheck();
        return this.overdueCollectionRange[1];
    };
    OverdueBookComponent.prototype.getOverDueBookReport = function () {
        var _this = this;
        var obj = {
            "pageNo": this.pageIndex,
            "noOfRecords": this.displayBatchSize
        };
        this.jsonFlag.isRippleLoad = true;
        this.reportService.getOverDueBookReport(obj).subscribe(function (response) {
            _this.jsonFlag.isRippleLoad = false;
            var res;
            res = response;
            if (res.results.length > 0) {
                _this.overdueBookReportList = res.results;
                _this.tempOverdueBookReportList = res;
                _this.totalCount = res.totalRecords;
            }
        }, function (errorResponse) {
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    // printFeeReceipt(issueBookId){
    //   this.jsonFlag.isRippleLoad = true;
    //   this.reportService.downloadReceipt(issueBookId).subscribe(
    //     response => {
    //       let res: any;
    //       res = response;
    //       this.jsonFlag.isRippleLoad = false;
    //       let byteArr = this.convertBase64ToArray(res.document);
    //       let fileName = res.docTitle;
    //       let file = new Blob([byteArr], { type: 'text/csv;charset=utf-8;' });
    //       let url = URL.createObjectURL(file);
    //       let dwldLink = document.getElementById('timeTable_download');
    //       dwldLink.setAttribute("href", url);
    //       dwldLink.setAttribute("download", fileName);
    //       document.body.appendChild(dwldLink);
    //       dwldLink.click();
    //     })
    // }
    //
    // convertBase64ToArray(val) {
    //
    //   var binary_string = window.atob(val);
    //   var len = binary_string.length;
    //   var bytes = new Uint8Array(len);
    //   for (var i = 0; i < len; i++) {
    //     bytes[i] = binary_string.charCodeAt(i);
    //   }
    //   return bytes.buffer;
    //
    // }
    /*** pagination functions */
    /* Fetch next set of data from server and update table */
    OverdueBookComponent.prototype.fetchNext = function () {
        this.pageIndex++;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch previous set of data from server and update table */
    OverdueBookComponent.prototype.fetchPrevious = function () {
        this.pageIndex--;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch table data by page index */
    OverdueBookComponent.prototype.fectchTableDataByPage = function (index) {
        this.pageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.getOverDueBookReport();
    };
    /* Fetches Data as per the user selected batch size */
    OverdueBookComponent.prototype.updateTableBatchSize = function (num) {
        this.pageIndex = 1;
        this.displayBatchSize = parseInt(num);
        this.getOverDueBookReport();
    };
    OverdueBookComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-overdue-book',
            template: __webpack_require__("./src/app/components/library-management/report/overdue-book/overdue-book.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/report/overdue-book/overdue-book.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"],
            __WEBPACK_IMPORTED_MODULE_1__services_library_report_report_service__["a" /* ReportService */]])
    ], OverdueBookComponent);
    return OverdueBookComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/report/report-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReportRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__report_component__ = __webpack_require__("./src/app/components/library-management/report/report.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__lost_book_lost_book_component__ = __webpack_require__("./src/app/components/library-management/report/lost-book/lost-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__scrap_book_scrap_book_component__ = __webpack_require__("./src/app/components/library-management/report/scrap-book/scrap-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__fine_collection_fine_collection_component__ = __webpack_require__("./src/app/components/library-management/report/fine-collection/fine-collection.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__issued_book_issued_book_component__ = __webpack_require__("./src/app/components/library-management/report/issued-book/issued-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__overdue_book_overdue_book_component__ = __webpack_require__("./src/app/components/library-management/report/overdue-book/overdue-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__never_issued_never_issued_component__ = __webpack_require__("./src/app/components/library-management/report/never-issued/never-issued.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__return_book_return_book_component__ = __webpack_require__("./src/app/components/library-management/report/return-book/return-book.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var ReportRoutingModule = /** @class */ (function () {
    function ReportRoutingModule() {
    }
    ReportRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__report_component__["a" /* ReportComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                component: __WEBPACK_IMPORTED_MODULE_3__lost_book_lost_book_component__["a" /* LostBookComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_3__lost_book_lost_book_component__["a" /* LostBookComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'lost',
                                component: __WEBPACK_IMPORTED_MODULE_3__lost_book_lost_book_component__["a" /* LostBookComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'scrap',
                                component: __WEBPACK_IMPORTED_MODULE_4__scrap_book_scrap_book_component__["a" /* ScrapBookComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'fine',
                                component: __WEBPACK_IMPORTED_MODULE_5__fine_collection_fine_collection_component__["a" /* FineCollectionComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'issued',
                                component: __WEBPACK_IMPORTED_MODULE_6__issued_book_issued_book_component__["a" /* IssuedBookComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'overdue',
                                component: __WEBPACK_IMPORTED_MODULE_7__overdue_book_overdue_book_component__["a" /* OverdueBookComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'never-issued',
                                component: __WEBPACK_IMPORTED_MODULE_8__never_issued_never_issued_component__["a" /* NeverIssuedComponent */],
                                pathMatch: 'prefix'
                            },
                            {
                                path: 'retrun-book',
                                component: __WEBPACK_IMPORTED_MODULE_9__return_book_return_book_component__["a" /* ReturnBookComponent */],
                                pathMatch: 'prefix'
                            }
                        ]
                    }
                ])],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]]
        })
    ], ReportRoutingModule);
    return ReportRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/library-management/report/report.component.html":
/***/ (function(module, exports) {

module.exports = "<section>\r\n  <div class=\"horizontal-menu\">\r\n    <div class=\"horizontal-menu-item active-menu\" id=\"lost\">\r\n      <span routerLink=\"/view/library/report/lost\" (click)=\"toggle('lost')\">Lost Books</span>\r\n    </div>\r\n    <div class=\"horizontal-menu-item hide\" id=\"scrap\">\r\n      <span routerLink=\"/view/library/report/scrap\" (click)=\"toggle('scrap')\">Scrap Books</span>\r\n    </div>\r\n    <div class=\"horizontal-menu-item\" id=\"fine\">\r\n      <span routerLink=\"/view/library/report/fine\" (click)=\"toggle('fine')\">Fine Collection</span>\r\n    </div>\r\n    <div class=\"horizontal-menu-item\" id=\"issued\">\r\n      <span routerLink=\"/view/library/report/issued\" (click)=\"toggle('issued')\">Issued Books</span>\r\n    </div>\r\n    <div class=\"horizontal-menu-item\" id=\"overdue\">\r\n      <span routerLink=\"/view/library/report/overdue\" (click)=\"toggle('overdue')\">Overdue Books</span>\r\n    </div>\r\n    <div class=\"horizontal-menu-item\" id=\"never\">\r\n      <span routerLink=\"/view/library/report/never-issued\" (click)=\"toggle('never')\">Never Issued Books</span>\r\n    </div>\r\n    <div class=\"horizontal-menu-item\" id=\"return\">\r\n      <span routerLink=\"/view/library/report/retrun-book\" (click)=\"toggle('return')\">Returned Books</span>\r\n    </div>\r\n  </div>\r\n</section>\r\n\r\n<section class=\"report-sction\">\r\n  <router-outlet></router-outlet>\r\n</section>\r\n"

/***/ }),

/***/ "./src/app/components/library-management/report/report.component.scss":
/***/ (function(module, exports) {

module.exports = ".horizontal-menu {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row; }\n  .horizontal-menu .horizontal-menu-item {\n    display: inline-block;\n    margin: 0 16px;\n    font-weight: bold;\n    position: relative;\n    bottom: -1px; }\n  .horizontal-menu .horizontal-menu-item span {\n      color: #9b9b9b;\n      padding-bottom: 8px;\n      cursor: pointer; }\n  .horizontal-menu .active-menu span {\n    border-bottom: 3px solid #528ff0;\n    color: #528ff0; }\n  .horizontal-menu .horizontal-menu-item span:hover {\n    color: #528ff0;\n    border-bottom: 3px solid #528ff0;\n    padding-bottom: 10px;\n    cursor: pointer; }\n  .report-sction {\n  margin-top: 20px; }\n"

/***/ }),

/***/ "./src/app/components/library-management/report/report.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReportComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var ReportComponent = /** @class */ (function () {
    function ReportComponent(router) {
        this.router = router;
    }
    ReportComponent.prototype.ngOnInit = function () {
        this.checkWhichTabIsOpen();
    };
    ReportComponent.prototype.toggle = function (id) {
        for (var i = 0; i < 7; i++) {
            document.getElementsByClassName("horizontal-menu-item")[i].classList.remove("active-menu");
        }
        document.getElementById(id).classList.add("active-menu");
    };
    ReportComponent.prototype.checkWhichTabIsOpen = function () {
        if (this.router.url.includes('lost')) {
            this.toggle('lost');
        }
        else if (this.router.url.includes('scrap')) {
            this.toggle('scrap');
        }
        else if (this.router.url.includes('fine')) {
            this.toggle('fine');
        }
        else if (this.router.url.includes('report/issued')) {
            this.toggle('issued');
        }
        else if (this.router.url.includes('overdue')) {
            this.toggle('overdue');
        }
        else if (this.router.url.includes('never')) {
            this.toggle('never');
        }
        else if (this.router.url.includes('retrun-book')) {
            this.toggle('return');
        }
    };
    ReportComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-report',
            template: __webpack_require__("./src/app/components/library-management/report/report.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/report/report.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"]])
    ], ReportComponent);
    return ReportComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/report/report.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportModule", function() { return ReportModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__report_routing_module__ = __webpack_require__("./src/app/components/library-management/report/report-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__report_component__ = __webpack_require__("./src/app/components/library-management/report/report.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__lost_book_lost_book_component__ = __webpack_require__("./src/app/components/library-management/report/lost-book/lost-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__scrap_book_scrap_book_component__ = __webpack_require__("./src/app/components/library-management/report/scrap-book/scrap-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__fine_collection_fine_collection_component__ = __webpack_require__("./src/app/components/library-management/report/fine-collection/fine-collection.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__issued_book_issued_book_component__ = __webpack_require__("./src/app/components/library-management/report/issued-book/issued-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__overdue_book_overdue_book_component__ = __webpack_require__("./src/app/components/library-management/report/overdue-book/overdue-book.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__never_issued_never_issued_component__ = __webpack_require__("./src/app/components/library-management/report/never-issued/never-issued.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_12_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__services_library_report_report_service__ = __webpack_require__("./src/app/services/library/report/report.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__return_book_return_book_component__ = __webpack_require__("./src/app/components/library-management/report/return-book/return-book.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
















var ReportModule = /** @class */ (function () {
    function ReportModule() {
    }
    ReportModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_10__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_10__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_11_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_2__report_routing_module__["a" /* ReportRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_13__shared_shared_module__["a" /* SharedModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_3__report_component__["a" /* ReportComponent */],
                __WEBPACK_IMPORTED_MODULE_4__lost_book_lost_book_component__["a" /* LostBookComponent */],
                __WEBPACK_IMPORTED_MODULE_5__scrap_book_scrap_book_component__["a" /* ScrapBookComponent */],
                __WEBPACK_IMPORTED_MODULE_6__fine_collection_fine_collection_component__["a" /* FineCollectionComponent */],
                __WEBPACK_IMPORTED_MODULE_7__issued_book_issued_book_component__["a" /* IssuedBookComponent */],
                __WEBPACK_IMPORTED_MODULE_8__overdue_book_overdue_book_component__["a" /* OverdueBookComponent */],
                __WEBPACK_IMPORTED_MODULE_9__never_issued_never_issued_component__["a" /* NeverIssuedComponent */],
                __WEBPACK_IMPORTED_MODULE_15__return_book_return_book_component__["a" /* ReturnBookComponent */]
            ],
            entryComponents: [
                __WEBPACK_IMPORTED_MODULE_4__lost_book_lost_book_component__["a" /* LostBookComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_14__services_library_report_report_service__["a" /* ReportService */]
            ]
        })
    ], ReportModule);
    return ReportModule;
}());



/***/ }),

/***/ "./src/app/components/library-management/report/return-book/return-book.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n\r\n<section>\r\n\r\n    <div style=\"text-align: center;color: #9b9b9b;font-size: 18px;margin-top: 10%;\">Comming Soon</div>\r\n\r\n  <!-- <div class=\"filter-date-container\">\r\n    <button class=\"pull-right\" (click)=\"openCalendar('returnbookrange')\">\r\n      <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">\r\n        <g fill=\"#0084F6\" fill-rule=\"nonzero\">\r\n          <path d=\"M18.667 5.5H16.5v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1H5.333C4.598 5.5 4 6.096 4 6.833v11.833C4 19.403 4.597 20 5.333 20h13.334c.736 0 1.333-.597 1.333-1.334V6.833c0-.737-.596-1.333-1.333-1.333zM19 18.666c0 .184-.15.334-.333.334H5.333A.334.334 0 0 1 5 18.666V6.833c0-.184.15-.333.333-.333H7.5v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h2.167c.183 0 .333.15.333.333v11.833z\"\r\n          />\r\n          <path d=\"M7.5 10h2v1.5h-2zM7.5 12.5h2V14h-2zM7.5 15h2v1.5h-2zM11 15h2v1.5h-2zM11 12.5h2V14h-2zM11 10h2v1.5h-2zM14.5 15h2v1.5h-2zM14.5 12.5h2V14h-2zM14.5 10h2v1.5h-2z\"\r\n          />\r\n        </g>\r\n      </svg>\r\n    </button>\r\n    <input style=\"margin-left:12%;\" type=\"text\" value=\"\" id=\"returnbookrange\" class=\"widgetDatepicker bsDatepicker\" name=\"returnbookrange\"\r\n      [(ngModel)]=\"returnbookrange\" (ngModelChange)=\"updateEnqChartByDate($event)\"  bsDaterangepicker/>\r\n    <span class=\"enquiry-state-date pull-right\">\r\n        {{getStartDate()| date: 'dd MMM yyyy'}} To {{getEndDate()| date: 'dd MMM yyyy'}}\r\n    </span>\r\n  </div>\r\n  <div class=\"filter-search-container\">\r\n    <input class=\"search-box form-ctrl\" type=\"text\" placeholder=\"Search\" (keyup)=\"searchDatabase()\" [(ngModel)]=\"searchText\">\r\n  </div> -->\r\n</section>\r\n\r\n<!-- <section>\r\n  <div class=\"table-container\">\r\n    <div class=\"heading-container\">\r\n      <div class=\"heading-item\">\r\n        <span>Book Title</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Borrower Name</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Issued Date</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Return Date</span>\r\n      </div>\r\n      <div class=\"heading-item\" style=\"text-align:center;\">\r\n        <span>No of Late Days</span>\r\n      </div>\r\n      <div class=\"heading-item\" style=\"text-align:center;\">\r\n        <span>Total Fine</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"value-outer-container\">\r\n      <div class=\"value-container\" *ngFor=\"let report of returnBookReportList\">\r\n        <div class=\"value-item\">\r\n          <span>{{report.title}}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n          <span>{{report.borrower}}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n          <span>{{report.issuedDate | date: 'dd MMM yyyy'}}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n          <span>{{report.returnDate | date: 'dd MMM yyyy'}}</span>\r\n        </div>\r\n        <div class=\"value-item\"  style=\"text-align:center;\">\r\n          <span>{{report.noOfLateDays}}</span>\r\n        </div>\r\n        <div class=\"value-item\"  style=\"text-align:center;\">\r\n          <span>{{report.totalFine}}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"no-records\" *ngIf=\"returnBookReportList.length == 0\">\r\n        <span>No Records Found</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section> -->\r\n"

/***/ }),

/***/ "./src/app/components/library-management/report/return-book/return-book.component.scss":
/***/ (function(module, exports) {

module.exports = ".filter-date-container .enquiry-state-date {\n  font-size: 14px;\n  color: #666;\n  margin-right: 10px;\n  padding-top: 4px;\n  display: inline-block; }\n\n.widgetDatepicker {\n  position: absolute;\n  margin-left: -10%;\n  width: 1px;\n  visibility: hidden;\n  opacity: 0; }\n\n.bsDatepicker {\n  padding: 5px;\n  width: 100%;\n  position: absolute; }\n\n.search-box {\n  border: 1px solid #ccc;\n  padding: 5px;\n  width: 20%;\n  float: right;\n  margin-right: 25px;\n  margin-bottom: 10px; }\n\nbutton {\n  background: transparent; }\n\nbutton.drag-button {\n    cursor: all-scroll;\n    margin-left: 16px; }\n\n.table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%; }\n\n.table-container .heading-container {\n    background: #e0eaec;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    font-size: 14px;\n    font-weight: 600;\n    text-align: left;\n    padding: 10px;\n    border: 1px solid #ccc; }\n\n.table-container .heading-container .heading-item {\n      width: 20%; }\n\n.table-container .value-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    min-height: 50vh;\n    max-height: 50vh;\n    overflow-x: hidden;\n    overflow-y: auto;\n    border: 1px solid #ccc; }\n\n.table-container .value-outer-container .value-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      text-align: left;\n      padding: 10px;\n      font-size: 12px;\n      border-bottom: 1px solid #ccc;\n      border-top: none; }\n\n.table-container .value-outer-container .value-container .value-item {\n        width: 20%; }\n\n.table-container .value-outer-container .no-records {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: center;\n          -ms-flex-pack: center;\n              justify-content: center;\n      padding: 10px;\n      font-size: 14px;\n      font-weight: 600;\n      border: 1px solid #ccc;\n      border-top: none; }\n\n.search-box {\n  border: 1px solid #ccc;\n  padding: 5px;\n  width: 20%;\n  float: right;\n  margin-right: 25px;\n  margin-bottom: 10px; }\n\n::ng-deep bs-datepicker-container, bs-daterangepicker-container {\n  left: 650 !important; }\n"

/***/ }),

/***/ "./src/app/components/library-management/report/return-book/return-book.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReturnBookComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_library_report_report_service__ = __webpack_require__("./src/app/services/library/report/report.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ReturnBookComponent = /** @class */ (function () {
    function ReturnBookComponent(router, cd, reportService) {
        this.router = router;
        this.cd = cd;
        this.reportService = reportService;
        this.jsonFlag = {
            isProfessional: false,
            isRippleLoad: false
        };
        this.returnbookrange = [];
        this.returnBookReportList = [];
    }
    ReturnBookComponent.prototype.ngOnInit = function () {
        this.returnbookrange[0] = new Date(__WEBPACK_IMPORTED_MODULE_2_moment__().date(1).format("YYYY-MM-DD"));
        this.returnbookrange[1] = new Date(__WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-DD"));
        // this.getReturnBookReport(this.returnbookrange[0],this.returnbookrange[1]);
    };
    ReturnBookComponent.prototype.getReturnBookReport = function (startDate, endDate) {
        var _this = this;
        var obj = {
            "between": {
                "from": startDate,
                "to": endDate
            },
            "in": [
                {
                    "column": "status",
                    "values": [40, 60]
                }
            ]
        };
        this.jsonFlag.isRippleLoad = true;
        this.reportService.getReturnBookReport(obj).subscribe(function (response) {
            _this.jsonFlag.isRippleLoad = false;
            var result;
            result = response;
            if (result.length > 0) {
                _this.returnBookReportList = result;
                _this.fixedReturnBookList = result;
            }
        }, function (errorResponse) {
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    ReturnBookComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            var searchData = void 0;
            var peopleArray = Object.keys(this.fixedReturnBookList).map(function (i) { return _this.fixedReturnBookList[i]; });
            searchData = peopleArray.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.returnBookReportList = searchData;
        }
        else {
            this.returnBookReportList = this.fixedReturnBookList;
        }
    };
    ReturnBookComponent.prototype.getStartDate = function () {
        this.cd.markForCheck();
        var date = __WEBPACK_IMPORTED_MODULE_2_moment__().date(1).format("YYYY-MM-DD");
        return this.returnbookrange[0];
    };
    ReturnBookComponent.prototype.getEndDate = function () {
        this.cd.markForCheck();
        return this.returnbookrange[1];
    };
    ReturnBookComponent.prototype.updateEnqChartByDate = function (e) {
        this.cd.markForCheck();
        this.getReturnBookReport(__WEBPACK_IMPORTED_MODULE_2_moment__(e[0]).format("YYYY-MM-DD"), __WEBPACK_IMPORTED_MODULE_2_moment__(e[1]).format("YYYY-MM-DD"));
    };
    ReturnBookComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    ReturnBookComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-return-book',
            template: __webpack_require__("./src/app/components/library-management/report/return-book/return-book.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/report/return-book/return-book.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"],
            __WEBPACK_IMPORTED_MODULE_3__services_library_report_report_service__["a" /* ReportService */]])
    ], ReturnBookComponent);
    return ReturnBookComponent;
}());



/***/ }),

/***/ "./src/app/components/library-management/report/scrap-book/scrap-book.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<section>\r\n  <div class=\"filter-date-container\">\r\n    <button class=\"pull-right\" (click)=\"openCalendar('scrapbookrange')\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">\r\n            <g fill=\"#0084F6\" fill-rule=\"nonzero\">\r\n                <path d=\"M18.667 5.5H16.5v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1h-3v-1a.5.5 0 1 0-1 0v1H5.333C4.598 5.5 4 6.096 4 6.833v11.833C4 19.403 4.597 20 5.333 20h13.334c.736 0 1.333-.597 1.333-1.334V6.833c0-.737-.596-1.333-1.333-1.333zM19 18.666c0 .184-.15.334-.333.334H5.333A.334.334 0 0 1 5 18.666V6.833c0-.184.15-.333.333-.333H7.5v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h3v1a.5.5 0 1 0 1 0v-1h2.167c.183 0 .333.15.333.333v11.833z\"\r\n                />\r\n                <path d=\"M7.5 10h2v1.5h-2zM7.5 12.5h2V14h-2zM7.5 15h2v1.5h-2zM11 15h2v1.5h-2zM11 12.5h2V14h-2zM11 10h2v1.5h-2zM14.5 15h2v1.5h-2zM14.5 12.5h2V14h-2zM14.5 10h2v1.5h-2z\"\r\n                />\r\n            </g>\r\n        </svg>\r\n    </button>\r\n    <input type=\"text\" value=\"\" id=\"scrapbookrange\" class=\"widgetDatepicker bsDatepicker\" name=\"scrapbookrange\" [(ngModel)]=\"scrapbookrange\"\r\n        (ngModelChange)=\"updateEnqChartByDate($event)\" readonly=\"true\" bsDaterangepicker/>\r\n    <span class=\"enquiry-state-date pull-right\">\r\n        {{getStartDate()| date: 'dd MMM yyyy'}} To {{getEndDate()| date: 'dd MMM yyyy'}}\r\n    </span>\r\n  </div>\r\n  <div class=\"filter-search-container\">\r\n    <input class=\"search-box form-ctrl\" type=\"text\" placeholder=\"Search\" (keyup)=\"searchDatabase()\" [(ngModel)]=\"searchText\">\r\n  </div>\r\n</section>\r\n\r\n<section>\r\n  <div class=\"table-container\">\r\n    <div class=\"heading-container\">\r\n      <div class=\"heading-item\">\r\n        <span>Book Title</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Borrower Name</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Scrap Date</span>\r\n      </div>\r\n      <div class=\"heading-item\">\r\n        <span>Remarks</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"value-outer-container\">\r\n      <div class=\"value-container\" *ngFor=\"let report of scrapBookReportList\">\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.title}}\">{{ (report.title.length > 20) ? (report.title | slice:0:20) + '...' : report.title }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.borrower}}\">{{ (report.borrower.length > 20) ? (report.borrower | slice:0:20) + '...' : report.borrower }}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n\r\n          <span title=\"{{report.date | date: 'dd MMM yyyy'}}\">{{report.date | date: 'dd MMM yyyy'}}</span>\r\n        </div>\r\n        <div class=\"value-item\">\r\n            <span title=\"{{report.remark}}\">{{ (report.remark.length > 20) ? (report.remark | slice:0:20) + '...' : report.remark }}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"no-records\" *ngIf=\"scrapBookReportList.length == 0\">\r\n        <span>No Records Found</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n"

/***/ }),

/***/ "./src/app/components/library-management/report/scrap-book/scrap-book.component.scss":
/***/ (function(module, exports) {

module.exports = ".filter-date-container .enquiry-state-date {\n  font-size: 14px;\n  color: #666;\n  margin-right: 10px;\n  padding-top: 4px;\n  display: inline-block; }\n\n.widgetDatepicker {\n  position: absolute;\n  margin-left: -10%;\n  width: 1px;\n  visibility: hidden;\n  opacity: 0; }\n\nbutton {\n  background: transparent; }\n\nbutton.drag-button {\n    cursor: all-scroll;\n    margin-left: 16px; }\n\n.search-box {\n  border: 1px solid #ccc;\n  padding: 5px;\n  width: 20%;\n  float: right;\n  margin-right: 25px;\n  margin-bottom: 10px; }\n\n.table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%; }\n\n.table-container .heading-container {\n    background: #e0eaec;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    font-size: 14px;\n    font-weight: 600;\n    text-align: left;\n    padding: 10px;\n    border: 1px solid #ccc; }\n\n.table-container .heading-container .heading-item {\n      width: 20%; }\n\n.table-container .value-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    min-height: 50vh;\n    max-height: 50vh;\n    overflow-x: hidden;\n    overflow-y: auto;\n    border: 1px solid #ccc; }\n\n.table-container .value-outer-container .value-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      text-align: left;\n      padding: 10px;\n      font-size: 12px;\n      border-bottom: 1px solid #ccc;\n      border-top: none; }\n\n.table-container .value-outer-container .value-container .value-item {\n        width: 20%; }\n\n.table-container .value-outer-container .no-records {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-pack: center;\n          -ms-flex-pack: center;\n              justify-content: center;\n      padding: 10px;\n      font-size: 14px;\n      font-weight: 600;\n      border: 1px solid #ccc;\n      border-top: none; }\n\n.search-box {\n  border: 1px solid #ccc;\n  padding: 5px;\n  width: 20%;\n  float: right;\n  margin-right: 25px;\n  margin-bottom: 10px; }\n\n::ng-deep bs-datepicker-container, bs-daterangepicker-container {\n  left: 650 !important; }\n"

/***/ }),

/***/ "./src/app/components/library-management/report/scrap-book/scrap-book.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ScrapBookComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_library_report_report_service__ = __webpack_require__("./src/app/services/library/report/report.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ScrapBookComponent = /** @class */ (function () {
    function ScrapBookComponent(router, cd, reportService) {
        this.router = router;
        this.cd = cd;
        this.reportService = reportService;
        this.jsonFlag = {
            isProfessional: false,
            isRippleLoad: false
        };
        this.scrapbookrange = [];
        this.scrapBookReportList = [];
    }
    ScrapBookComponent.prototype.ngOnInit = function () {
        this.scrapbookrange[0] = new Date(__WEBPACK_IMPORTED_MODULE_2_moment__().date(1).format("YYYY-MM-DD"));
        this.scrapbookrange[1] = new Date(__WEBPACK_IMPORTED_MODULE_2_moment__().format("YYYY-MM-DD"));
        // this.getScrapBookReport(this.scrapbookrange[0],this.scrapbookrange[1]);
    };
    ScrapBookComponent.prototype.getScrapBookReport = function (startDate, endDate) {
        var _this = this;
        var obj = {
            "between": {
                "from": startDate,
                "to": endDate
            },
            "in": [
                {
                    "column": "status",
                    "values": [50, 70] //  Book scraped by librarian or student
                }
            ]
        };
        this.jsonFlag.isRippleLoad = true;
        this.reportService.getScrapBookReport(obj).subscribe(function (response) {
            _this.jsonFlag.isRippleLoad = false;
            var result;
            result = response;
            if (result.length > 0) {
                _this.scrapBookReportList = result;
                _this.fixedScrapBookList = result;
            }
        }, function (errorResponse) {
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    ScrapBookComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            var searchData = void 0;
            var peopleArray = Object.keys(this.fixedScrapBookList).map(function (i) { return _this.fixedScrapBookList[i]; });
            searchData = peopleArray.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.scrapBookReportList = searchData;
        }
        else {
            this.scrapBookReportList = this.fixedScrapBookList;
        }
    };
    ScrapBookComponent.prototype.getStartDate = function () {
        this.cd.markForCheck();
        var date = __WEBPACK_IMPORTED_MODULE_2_moment__().date(1).format("YYYY-MM-DD");
        return this.scrapbookrange[0];
    };
    ScrapBookComponent.prototype.getEndDate = function () {
        this.cd.markForCheck();
        return this.scrapbookrange[1];
    };
    ScrapBookComponent.prototype.updateEnqChartByDate = function (e) {
        this.cd.markForCheck();
        this.getScrapBookReport(__WEBPACK_IMPORTED_MODULE_2_moment__(e[0]).format("YYYY-MM-DD"), __WEBPACK_IMPORTED_MODULE_2_moment__(e[1]).format("YYYY-MM-DD"));
    };
    ScrapBookComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    ScrapBookComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-scrap-book',
            template: __webpack_require__("./src/app/components/library-management/report/scrap-book/scrap-book.component.html"),
            styles: [__webpack_require__("./src/app/components/library-management/report/scrap-book/scrap-book.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"],
            __WEBPACK_IMPORTED_MODULE_3__services_library_report_report_service__["a" /* ReportService */]])
    ], ScrapBookComponent);
    return ScrapBookComponent;
}());



/***/ }),

/***/ "./src/app/services/library/report/report.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReportService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ReportService = /** @class */ (function () {
    function ReportService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.userid = sessionStorage.getItem('userid');
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]();
            _this.headers = _this.headers.append('Content-Type', 'application/json');
            _this.headers = _this.headers.append('Authorization', _this.Authorization);
            _this.headers = _this.headers.append("Accept", "*");
            _this.headers = _this.headers.append("x-proc-inst-id", _this.institute_id.toString());
            _this.headers = _this.headers.append("x-proc-user-id", _this.userid.toString());
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    ReportService.prototype.getLostBookReport = function (obj) {
        var url = this.baseUrl + "/library/report/lostBookReport";
        return this.http.post(url, obj, { headers: this.headers }).map(function (response) {
            return response;
        }, function (errorResponse) {
            return errorResponse;
        });
    };
    ReportService.prototype.getScrapBookReport = function (obj) {
        var url = this.baseUrl + "/library/report/scrapBookReport";
        return this.http.post(url, obj, { headers: this.headers }).map(function (response) {
            return response;
        }, function (errorResponse) {
            return errorResponse;
        });
    };
    ReportService.prototype.getOverDueBookReport = function (obj) {
        var url = this.baseUrl + "/library/report/overdueBookReport";
        return this.http.post(url, obj, { headers: this.headers }).map(function (response) {
            return response;
        }, function (errorResponse) {
            return errorResponse;
        });
    };
    ReportService.prototype.getNeverIssuedBookReport = function () {
        var url = this.baseUrl + "/library/analytics/never-issued-books";
        return this.http.get(url, { headers: this.headers }).map(function (response) {
            return response;
        }, function (errorResponse) {
            return errorResponse;
        });
    };
    ReportService.prototype.getFineCollectionReport = function (obj) {
        var url = this.baseUrl + "/library/report/fineCollectionReportBorrowerWise";
        return this.http.post(url, obj, { headers: this.headers }).map(function (response) {
            return response;
        }, function (errorResponse) {
            return errorResponse;
        });
    };
    ReportService.prototype.getIssueBookReport = function (obj) {
        var url = this.baseUrl + "/library/report/issuedBookReport";
        return this.http.post(url, obj, { headers: this.headers }).map(function (response) {
            return response;
        }, function (errorResponse) {
            return errorResponse;
        });
    };
    ReportService.prototype.getReturnBookReport = function (obj) {
        var url = this.baseUrl + "/library/report/overdueBookReport";
        return this.http.post(url, obj, { headers: this.headers }).map(function (response) {
            return response;
        }, function (errorResponse) {
            return errorResponse;
        });
    };
    ReportService.prototype.downloadReceipt = function (issueBookId) {
        var url = this.baseUrl + "/library/book/download?issueBookId=" + issueBookId;
        return this.http.get(url, { headers: this.headers }).map(function (response) {
            return response;
        }, function (errorResponse) {
            return errorResponse;
        });
    };
    ReportService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */],
            __WEBPACK_IMPORTED_MODULE_2__authenticator_service__["a" /* AuthenticatorService */]])
    ], ReportService);
    return ReportService;
}());



/***/ })

});
//# sourceMappingURL=report.module.chunk.js.map