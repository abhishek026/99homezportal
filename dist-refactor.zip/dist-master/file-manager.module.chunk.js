webpackJsonp(["file-manager.module"],{

/***/ "./node_modules/primeng/tree.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* Shorthand */

function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(__webpack_require__("./node_modules/primeng/components/tree/tree.js"));

/***/ }),

/***/ "./src/app/components/course-module/file-manager/drive-home/drive-home.component.html":
/***/ (function(module, exports) {

module.exports = "<!-- Main screen where content will be rendered -->\r\n<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\"\r\n  *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<div class=\"center-content\">\r\n\r\n  <div id=\"dropZone\" #dropZone (drop)=\"onDrop($event)\" (dragover)=\"onDragOver($event)\" (dragleave)=\"onDragLeave($event)\" class=\"drop-area\">\r\n\r\n    <p-fileUpload #uploaders mode=\"advanced\" *ngIf=\"dragoverflag\" customUpload=\"true\" multiple=\"multiple\" (onSelect)=\"onSelect($event, uploaders)\"\r\n      (clear)=\"clearSelectedFiles($event)\">\r\n    </p-fileUpload>\r\n\r\n  </div>\r\n\r\n\r\n  <!-- Header for the Drive -->\r\n  <header class=\"top-nav\">\r\n\r\n    <h1 class=\"pull-left\">\r\n      <a routerLink=\"/view/course\">\r\n        Course\r\n      </a>\r\n      <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>File Manager\r\n      <div style=\"font-size: 12px;margin-top: 6px;\">\r\n        <a class=\"pathAnchor\" *ngFor=\"let path of pathArray; let j = index\" (click)=\"collapseString(j)\">\r\n          {{path}} /\r\n        </a>\r\n      </div>\r\n    </h1>\r\n    <div class=\"pull-right\" style=\"position: relative;top: 14px; width:10%;\">\r\n      <i class=\"fa fa-upload\" (click)=\"uploadBox()\" title=\"Upload File\" style=\"font-family: 'FontAwesome' ; display: inline-block; font-size: 17px; color: #52454596;\"\r\n        id=\"upload\">\r\n      </i>&nbsp;&nbsp;&nbsp;\r\n      <i class=\"fa fa-folder-open\" style=\"font-size: 17px; color: #52454596; margin-left: 1%; display: inline-block;\" title=\"Make Folder\"\r\n        (click)=\"makeFolderOpen()\"></i>\r\n    </div>\r\n  </header>\r\n\r\n  <div class=\"files-cont\">\r\n    <!-- Files and Folder for Group to be Inserted  -->\r\n    <div #DragContainer class=\"grid__container row row--no-right\">\r\n      <!-- Side Tree View For Folder Display -->\r\n      <div class=\"col-sm-3 tree__view\" (dragover)=\"onDragOverFolder($event, null)\" (dragleave)=\"onDragLeaveFolder($event, null)\">\r\n        <h3></h3>\r\n        <p-tree (onNodeCollapse)=\"onNodeCollapse($event)\" (onNodeContextMenuSelect)=\"onNodeContextMenuSelect($event)\" (onNodeExpand)=\"onNodeExpand($event)\"\r\n          (onNodeSelect)=\"onNodeSelect($event)\" [styleClass]=\"'tree__view_list'\" #expandingTree [value]=\"treeNodeData\">\r\n        </p-tree>\r\n\r\n      </div>\r\n\r\n      <!-- Preview Mode for Viewing the files on grid or list view -->\r\n      <div class=\"col-sm-9\">\r\n        <div class=\"\" (dragover)=\"onDragOverFolder($event, null)\" (dragleave)=\"onDragLeaveFolder($event, null)\">\r\n          <div class=\"file table__header\">\r\n            <div class=\"file__img\"></div>\r\n            <div class=\"file__info\">\r\n              <h2 class=\"file__details file__header__name\">\r\n                File Name\r\n              </h2>\r\n\r\n              <div class=\"file__details\" style=\"width:15%;\">\r\n                Category\r\n              </div>\r\n\r\n              <div class=\"file__details file__owner\">\r\n                Owner\r\n              </div>\r\n\r\n              <div class=\"file__details file__date\">\r\n                Uploaded On\r\n              </div>\r\n\r\n              <div class=\"file__details file__size\">\r\n                File Size\r\n              </div>\r\n\r\n              <div class=\"file__details\">\r\n                Downloads\r\n              </div>\r\n\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div>\r\n          <div (dragover)=\"onDragOverFolder($event, folder)\" (dragleave)=\"onDragLeaveFolder($event, folder)\" (dblclick)=\"folderSelected(folder)\"\r\n            *ngFor=\"let folder of folderDisplayArr\" class=\"file folder folder-file\">\r\n            <div class=\"file__img\"></div>\r\n            <div class=\"file__info\">\r\n\r\n              <h2 class=\"file__title\" title=\"{{folder.label}}\">\r\n                {{folder.label}}\r\n              </h2>\r\n\r\n              <div class=\"file__details\">\r\n                {{folder.type}}\r\n              </div>\r\n\r\n              <div class=\"file__details file__owner\">{{folder.data.uploaded_by}}</div>\r\n\r\n              <div class=\"file__details file__date\">{{folder.data.uploaded_time}}</div>\r\n\r\n              <div class=\"file__details file__size\">{{folder.data.size}} KB</div>\r\n\r\n              <div class=\"file__details file__Data\">{{folder.data.downloads}}</div>\r\n\r\n              <i class=\"fa fa-trash\" style=\"font-size: 17px; color: #52454596;\" title=\"Delete folder\" (click)=\"getFilesDeleted(folder)\"></i>\r\n\r\n\r\n            </div>\r\n          </div>\r\n\r\n          <div *ngIf=\"fileDisplayArr.length != 0\">\r\n            <file-card (draggedover)=\"onDragOver($event)\" (draggedleave)=\"onDragLeave($event)\" [data]=\"folder\" *ngFor=\"let folder of fileDisplayArr\"\r\n              (getFilesAndFolder)=\"getFilesAndFolder($event)\" (status)=\"status($event)\" (downloadStatus)=\"downloadStatus($event)\" (getPopupValue)=\"getPopupValue($event)\"\r\n              (fileid)=\"fileId($event)\" (fileArr)=\"fileArr($event)\" (shareOptions)=\"handleOptions($event)\" [fileDisplayArr]=\"fileDisplayArr\"\r\n              [selectedFolder]=\"selectedFolder\" (filePath)=\"filePath($event)\">\r\n            </file-card>\r\n          </div>\r\n\r\n          <div class=\"file folder folder-file\" *ngIf=\"isFolderEmpty == true\">\r\n            <h2 class=\"file__title\" id=\"noFFs\">\r\n              No Files Or Folders Found\r\n            </h2>\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n      <!-- ======================================================= -->\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n\r\n<app-upload-popup *ngIf=\"addCategoryPopup\" [manualUpload]=\"manualUpload\" [selectedFiles]=\"selectedFiles\" [currentFolder]=\"selectedFolder\"\r\n  [pathArray]=\"pathArray\" (closePopupValue)=\"close($event)\" (getFilesAndFolder)=\"getFilesAndFolder($event)\" (filePath)=\"filePathUpload($event)\"\r\n  [currentFilesArray]=\"fileDisplayArr\" (uploadStatus)=\"uploadStatus($event)\">\r\n</app-upload-popup>\r\n\r\n<share-file *ngIf=\"getPopupOpen\" (treeUpdater)=\"treeUpdater($event)\" (closePopup)=\"closeSharePopup($event)\" [fileIdGet]=\"fileIdGet\"\r\n  [fileName]=\"fileName\" [shareOptions]=\"shareOptions\"></share-file>\r\n\r\n\r\n<proctur-popup [sizeWidth]=\"'small'\" *ngIf=\"createFolderControl\">\r\n\r\n  <span class=\"closePopup pos-abs fbold show\" close-button (click)=\"closeFolderControl()\">\r\n    <svg _ngcontent-c11=\"\" class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n      <path _ngcontent-c11=\"\" class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" style=\"fill: currentColor\"></path>\r\n    </svg>\r\n  </span>\r\n  <div popup-header class=\"popup-header-content\">\r\n    <h2>Create Folder</h2>\r\n  </div>\r\n  <div popup-content class=\"popup-header-content\">\r\n    <div class=\"row\">\r\n      <div class=\"c-lg-4 field-wrapper\">\r\n        <label>Folder Name\r\n          <div class=\"questionInfo inline-relative\">\r\n            <span class=\"qInfoIcon i-class\"> ?</span>\r\n            <div class=\"tooltip-box-field\">\r\n                Dot(.) is not allowed .\r\n            </div>\r\n          </div>\r\n        </label>\r\n        <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"createFetchFolder.folderName\">\r\n      </div>\r\n      <div class=\"c-lg-2\" style=\"margin-top: 4%;\">\r\n        <input type=\"button\" value=\"GO\" class=\"btn fullBlue\" (click)=\"createFolder()\">\r\n      </div>\r\n    </div>\r\n  </div>\r\n</proctur-popup>\r\n\r\n<div class=\"black-bg\" *ngIf=\"jsonFlag.downloading\">\r\n  <span>Downloading...</span>\r\n</div>\r\n\r\n<div class=\"black-bg\" *ngIf=\"jsonFlag.uploading\">\r\n  <span>Uploading...</span>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/file-manager/drive-home/drive-home.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.file-manager-header {\n  padding: 10px 30px; }\n.file-manager-header h1 {\n    font-size: 24px; }\n/*----------------------------------------\r\nCENTER CONTENT\r\n----------------------------------------*/\n.center-content {\n  display: table;\n  width: 100%;\n  height: 100%;\n  background-color: #fff; }\n/*----------------------------------------\r\nTOP BAR\r\n----------------------------------------*/\n.top-nav {\n  padding: 10px 15px 10px 20px;\n  background-color: #fff;\n  display: table;\n  width: 100%; }\n.top-nav h1 {\n    font-size: 14px; }\n.pathAnchor:hover {\n  cursor: pointer;\n  background: #efefef; }\n.search {\n  display: table-cell;\n  -webkit-appearance: none;\n  appearance: none;\n  -moz-appearance: none;\n  -o-appearance: none;\n  border: none;\n  -webkit-box-shadow: none;\n          box-shadow: none;\n  background-image: url(\"data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgd2lkdGg9IjE2cHgiIGhlaWdodD0iMTZweCIgdmlld0JveD0iMCAwIDYyNi41MiA2MjYuNTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDYyNi41MiA2MjYuNTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPGc+Cgk8cGF0aCBkPSJNNjExLjUzMSw1ODEuNDk0TDQ3MC45NzQsNDQwLjkzN2M0MS41NzMtNDYuOTAyLDY3LjYxNC0xMDcuODUsNjcuNjE0LTE3NS4yOTJDNTM4LjU2NiwxMTkuMTU1LDQxOS4zODksMCwyNzIuODk5LDAgICBDMTI2LjQzMSwwLDcuMjU0LDExOS4xNTUsNy4yNTQsMjY1LjY0NWMwLDE0Ni40NDcsMTE5LjE3NywyNjUuNjAyLDI2NS42NDUsMjY1LjYwMmM2MC4wNDIsMCwxMTQuODE5LTIwLjc1NSwxNTkuMzctNTQuNDMyICAgbDE0MS45MzgsMTQxLjk4YzUuMTc4LDUuMTU2LDExLjkwOCw3LjcyNCwxOC42NjEsNy43MjRzMTMuNTA2LTIuNTY3LDE4LjY2Mi03LjcyNCAgIEM2MjEuODQzLDYwOC41MDUsNjIxLjg0Myw1OTEuODA3LDYxMS41MzEsNTgxLjQ5NHogTTYwLjAyNSwyNjUuNjQ1YzAtMTE3LjM2NCw5NS41MS0yMTIuODk2LDIxMi44OTYtMjEyLjg5NiAgIGMxMTcuNDA4LDAsMjEyLjg5Niw5NS41MDksMjEyLjg5NiwyMTIuODk2cy05NS40ODgsMjEyLjgzMi0yMTIuODk2LDIxMi44MzJDMTU1LjUzNSw0NzguNDc3LDYwLjAyNSwzODMuMDMxLDYwLjAyNSwyNjUuNjQ1eiIgZmlsbD0iI2IzYjRiYSIvPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+Cjwvc3ZnPgo=\");\n  height: 45px;\n  padding: 8px 15px 8px 38px;\n  background-repeat: no-repeat;\n  background-position-x: 12px;\n  background-position-y: center;\n  background-size: 15px;\n  background-color: #fff;\n  font-size: 20px;\n  font-weight: 500;\n  transition: all 0.3s;\n  -webkit-transition: all 0.3s;\n  -moz-transition: all 0.3s;\n  -ms-transition: all 0.3s;\n  -o-transition: all 0.3s; }\n.search:focus {\n  padding-left: 18px;\n  background-position-x: -50px; }\n.search--width {\n  width: 25%;\n  border-bottom: 1px solid #777;\n  float: right; }\n.user-box {\n  display: none;\n  height: 100%;\n  width: 20%;\n  text-align: center; }\n.more__info {\n  width: 30px;\n  height: 30px;\n  font-size: 24px;\n  display: inline-block;\n  vertical-align: middle;\n  color: #777;\n  cursor: pointer; }\n.grid__view {\n  width: 30px;\n  height: 27px;\n  font-size: 24px;\n  display: inline-block;\n  vertical-align: middle;\n  color: #777;\n  cursor: pointer; }\n.list__view {\n  width: 30px;\n  height: 27px;\n  font-size: 24px;\n  display: inline-block;\n  vertical-align: middle;\n  color: #777;\n  cursor: pointer; }\n/*----------------------------------------\r\nFILE\r\n----------------------------------------*/\n.row__title {\n  font-size: 16px;\n  font-weight: 600;\n  margin: 0; }\n.row__title-box {\n  padding-left: 30px;\n  margin-bottom: 20px;\n  margin-top: 20px; }\n.row--no-right {\n  margin-right: 0px;\n  margin-left: -50px; }\n.row--no-right.bread {\n    margin-left: -50px; }\n.files-cont {\n  margin: 0 auto;\n  padding: 0px 0px 0 50px; }\n.file__details {\n  font-size: 13px;\n  color: #8087a2;\n  font-weight: 500;\n  padding: 0px 5px;\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  width: 15%;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap; }\n.file__details.file__date {\n    font-size: 13px;\n    color: #8087a2;\n    font-weight: 500;\n    padding: 0px 5px;\n    width: 15%; }\n.file__details.file__size {\n    width: 10%; }\n.file__details.file__header__name {\n    width: 20%; }\n.file__details.file__owner {\n    width: 15%; }\n.file__details.file__Data {\n    width: 10%; }\n.grid__container ::-webkit-scrollbar {\n  display: block; }\n.grid__container .file {\n  cursor: pointer;\n  width: 100%;\n  border-radius: 10px;\n  background-color: #fff;\n  -webkit-box-shadow: 0px 5px 5px -2px rgba(0, 0, 0, 0.2);\n          box-shadow: 0px 5px 5px -2px rgba(0, 0, 0, 0.2);\n  border: 1px solid rgba(0, 0, 0, 0.07);\n  float: left;\n  margin-left: 5px;\n  transition: all 0.3s;\n  -webkit-transition: all 0.3s;\n  -moz-transition: all 0.3s;\n  -ms-transition: all 0.3s;\n  -o-transition: all 0.3s;\n  margin-bottom: 0px; }\n.grid__container .file.table__header {\n    cursor: default;\n    width: 100%;\n    border-radius: 10px;\n    background-color: #fff;\n    -webkit-box-shadow: 0px 0px 1px 0px rgba(30, 35, 40, 0.36);\n            box-shadow: 0px 0px 1px 0px rgba(30, 35, 40, 0.36);\n    border: 1px solid rgba(0, 0, 0, 0.07);\n    float: left;\n    margin-left: 5px;\n    transition: all 0.3s;\n    -webkit-transition: all 0.3s;\n    -moz-transition: all 0.3s;\n    -ms-transition: all 0.3s;\n    -o-transition: all 0.3s;\n    margin-bottom: 5px; }\n.grid__container .file.table__header:hover {\n      -webkit-transform: translate(0, 0px);\n              transform: translate(0, 0px);\n      -webkit-box-shadow: none;\n              box-shadow: none; }\n.grid__container .file:hover {\n    -webkit-transform: translate(0, -4px);\n            transform: translate(0, -4px);\n    -webkit-box-shadow: 0px 7px 8px -2px rgba(0, 0, 0, 0.2);\n            box-shadow: 0px 7px 8px -2px rgba(0, 0, 0, 0.2); }\n.grid__container .file__img {\n  width: 10%;\n  height: 0;\n  padding-bottom: 0;\n  margin-top: 0;\n  background-repeat: no-repeat;\n  background-size: contain;\n  background-position: center;\n  border-top-right-radius: 10px;\n  border-top-left-radius: 10px; }\n.grid__container .file__title {\n  font-size: 14px;\n  font-weight: 600;\n  color: #252a3b;\n  width: 20%;\n  display: inline-block;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  line-height: 15px;\n  white-space: nowrap;\n  padding: 0px 7px; }\n.grid__container #noFFs {\n  width: 100% !important;\n  text-align: center !important; }\n.grid__container #noFFs::before {\n  content: none !important; }\n.grid__container .file__title:before {\n  width: 16px;\n  position: absolute;\n  left: 14px;\n  top: 9px; }\n.grid__container .file__date {\n  font-size: 13px;\n  color: #8087a2;\n  font-weight: 500; }\n.grid__container .file__info {\n  padding: 8px 5px 5px 35px;\n  position: relative; }\n.grid__container .preview__pane {\n  overflow: auto;\n  height: 70vh; }\n.grid__container .tree__view {\n  overflow: auto;\n  height: 70vh; }\n::ng-deep .tree__view_list {\n  width: 100%; }\n::ng-deep .prime__btn {\n  font-size: 12px;\n  padding: 7px 5px;\n  margin: 0px !important; }\n::ng-deep .ui-tree .ui-treenode-label {\n  display: inline-block;\n  padding: 0 .25em;\n  vertical-align: middle;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  width: 80%;\n  font-size: 14px;\n  text-transform: capitalize;\n  color: #89898c;\n  font-weight: 400; }\n::ng-deep .ui-tree .ui-treenode-icon {\n  font-size: 20px;\n  color: teal; }\n.folder-file .file__img {\n  background-image: url('folder.jpg'); }\n.folder .file__title:before {\n  content: url(\"data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgd2lkdGg9IjE2cHgiIGhlaWdodD0iMTZweCIgdmlld0JveD0iMCAwIDQ3NS4wODIgNDc1LjA4MiIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNDc1LjA4MiA0NzUuMDgyOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CjxnPgoJPHBhdGggZD0iTTQ1Ni4yMzksMTI4LjQ3NWMtMTIuNTYtMTIuNTYyLTI3LjU5Ny0xOC44NDItNDUuMTEtMTguODQyaC0xOTEuODZ2LTkuMTM2YzAtMTcuNTExLTYuMjgzLTMyLjU0OC0xOC44NDMtNDUuMTA3ICAgYy0xMi41NjItMTIuNTYyLTI3LjYtMTguODQ2LTQ1LjExMS0xOC44NDZINjMuOTUzYy0xNy41MTUsMC0zMi41NTEsNi4yODMtNDUuMTExLDE4Ljg0NkM2LjI4LDY3Ljk0OSwwLDgyLjk4NiwwLDEwMC40OTd2Mjc0LjA4OCAgIGMwLDE3LjUwOCw2LjI4LDMyLjU0NSwxOC44NDIsNDUuMTA0YzEyLjU2MiwxMi41NjUsMjcuNiwxOC44NDksNDUuMTExLDE4Ljg0OWgzNDcuMTc1YzE3LjUxNCwwLDMyLjU1MS02LjI4Myw0NS4xMS0xOC44NDkgICBjMTIuNTY2LTEyLjU2LDE4Ljg0My0yNy41OTcsMTguODQzLTQ1LjEwNFYxNzMuNTlDNDc1LjA4MiwxNTYuMDc4LDQ2OC44MDUsMTQxLjA0Miw0NTYuMjM5LDEyOC40NzV6IiBmaWxsPSIjZmZjYTQ1Ii8+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==\"); }\n.drop-area {\n  position: absolute;\n  right: 0;\n  left: 5.3%;\n  bottom: 0;\n  top: 22%;\n  width: 94%;\n  background: transparent; }\n.drop-area ::ng-deep .ui-tree .ui-treenode {\n    padding: 10px 5px; }\n.drop-area ::ng-deep .ui-button {\n    display: none; }\n.drop-area ::ng-deep .ui-fileupload {\n    width: 100%;\n    cursor: pointer; }\n.drop-area ::ng-deep .ui-fileupload-buttonbar {\n    display: none; }\n.drop-area ::ng-deep .ui-fileupload-content {\n    height: 71vh;\n    padding: 5px;\n    border-top: none;\n    cursor: pointer;\n    cursor: pointer; }\n.drop-area ::ng-deep .ui-fileupload-content::after {\n      content: \"Drag & Drop Files Here\";\n      color: rgba(0, 0, 0, 0.09);\n      position: absolute;\n      top: 35%;\n      left: 25%;\n      font-size: 36px; }\n.over {\n  z-index: 100;\n  background-color: rgba(147, 147, 147, 0.5);\n  border: 3px dashed #128cf7; }\n.drop-zone {\n  margin: auto;\n  height: 100px;\n  border: 2px dotted #0782d0;\n  border-radius: 30px; }\n.content {\n  color: #0782d0;\n  height: 100px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center; }\n.questionInfo {\n  position: absolute;\n  right: 55px;\n  bottom: 37px;\n  height: 20px;\n  width: 20px;\n  z-index: 2; }\n.questionInfo .qInfoIcon {\n    width: 20px;\n    height: 20px;\n    border: 1px solid #ccc;\n    border-radius: 50%;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    line-height: 20px;\n    font-weight: 600;\n    font-size: 12px;\n    cursor: pointer;\n    -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n            box-shadow: 0px 0px 1px 0px #ccc inset;\n    color: #888;\n    -webkit-transition: all 0.6s linear;\n    transition: all 0.6s linear; }\n.questionInfo .qInfoIcon:hover {\n      border-color: #0060A3;\n      -webkit-box-shadow: 0px 0px 1px 0px #0060A3 inset;\n              box-shadow: 0px 0px 1px 0px #0060A3 inset;\n      color: #0060A3; }\n.black-bg {\n  background: rgba(10, 10, 10, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 101;\n  width: 100%; }\n.black-bg span {\n    font-size: 18px;\n    color: white;\n    font-weight: 600;\n    text-align: center;\n    position: fixed;\n    top: 43%;\n    left: 46%; }\n/*\r\n============================================================================================\r\n================================== REjected Grid View ==================================\r\n============================================================================================\r\n*/\n/*\r\n.row__title {\r\n    font-size: 16px;\r\n    font-weight: 600;\r\n    margin: 0;\r\n}\r\n\r\n.row__title-box {\r\n    padding-left: 30px;\r\n    margin-bottom: 40px;\r\n    margin-top: 40px;\r\n}\r\n\r\n.row--no-right {\r\n    margin-right: 0px;\r\n    margin-left: -50px;\r\n}\r\n\r\n.files-cont {\r\n    max-width: 1200px;\r\n    margin: 0 auto;\r\n    padding: 0 50px;\r\n}\r\n\r\n.file {\r\n    cursor: pointer;\r\n    width: calc(15% - 30px);\r\n    border-radius: 10px;\r\n    background-color: #fff;\r\n    box-shadow: 0px 9px 10px -2px rgba(0, 0, 0, 0.2);\r\n    border: 1px solid rgba(0, 0, 0, 0.05);\r\n    float: left;\r\n    margin-left: 30px;\r\n    transition: all 0.3s;\r\n    -webkit-transition: all 0.3s;\r\n    -moz-transition: all 0.3s;\r\n    -ms-transition: all 0.3s;\r\n    -o-transition: all 0.3s;\r\n    margin-bottom: 30px;\r\n}\r\n\r\n.file:hover {\r\n    transform: translate(0, -4px);\r\n    box-shadow: 0px 17px 19px -2px rgba(0, 0, 0, 0.2);\r\n}\r\n\r\n.file__img {\r\n    width: 100%;\r\n    height: 0;\r\n    //padding-bottom: 50%;\r\n    padding-bottom: 35%;\r\n    margin-top: 5%;\r\n    background-repeat: no-repeat;\r\n    background-size: contain;\r\n    background-position: center;\r\n    border-top-right-radius: 10px;\r\n    border-top-left-radius: 10px;\r\n}\r\n\r\n\r\n.file__title {\r\n    font-size: 14px;\r\n    margin-bottom: 5px;\r\n    margin-top: 0px;\r\n    font-weight: 600;\r\n    color: #252a3b;\r\n    text-overflow: ellipsis;\r\n    white-space: nowrap;\r\n    overflow: hidden;\r\n    line-height: 18px;\r\n}\r\n\r\n.file__title:before {\r\n    width: 16px;\r\n    position: absolute;\r\n    left: 14px;\r\n    top: 22px;\r\n}\r\n\r\n\r\n.file__date {\r\n    font-size: 13px;\r\n    color: #8087a2;\r\n    font-weight: 500;\r\n}\r\n\r\n.file__info {\r\n    padding: 20px 20px 20px 45px;\r\n    position: relative;\r\n}\r\n\r\n@media screen and (max-width:1440px) {\r\n    .btn--small {\r\n        padding: 0 5px;\r\n        width: auto;\r\n    }\r\n    .starage-pro {\r\n        display: none;\r\n    }\r\n}\r\n\r\n@media screen and (max-width:1024px) {}\r\n\r\n@media screen and (max-width:767px) {\r\n    .center-content {\r\n        padding-left: 0;\r\n    }\r\n    .search--width {\r\n        width: 100%;\r\n        height: 40px;\r\n        font-size: 11px;\r\n    }\r\n    .top-nav {\r\n        padding: 15px;\r\n    }\r\n    .file {\r\n        margin-left: 15px;\r\n        margin-bottom: 15px;\r\n        width: calc(10% - 15px);\r\n    }\r\n    .file__info {\r\n        padding: 12px 12px 12px 35px;\r\n    }\r\n    .file__date {\r\n        font-size: 12px;\r\n    }\r\n    .file__title {\r\n        font-size: 13px;\r\n        margin-bottom: 0;\r\n        line-height: 20px;\r\n    }\r\n    .file__title:before {\r\n        left: 10px;\r\n        top: 14px;\r\n    }\r\n    .row--no-right {\r\n        margin: 0 0px 0 -15px;\r\n    }\r\n    .files-cont {\r\n        padding: 0 20px;\r\n    }\r\n    .row__title-box {\r\n        padding-left: 30px;\r\n        margin-bottom: 15px;\r\n        margin-top: 15px;\r\n    }\r\n    .row__title {\r\n        font-size: 20px;\r\n    }\r\n}\r\n\r\n@media screen and (max-width:640px) {\r\n    .file {\r\n        margin-left: 15px;\r\n        margin-bottom: 15px;\r\n        width: calc(33.3% - 15px);\r\n    }\r\n    .file__date {\r\n        font-size: 11px;\r\n    }\r\n    .file__title {\r\n        font-size: 12px;\r\n        margin-bottom: 0;\r\n        line-height: 20px;\r\n    }\r\n    .row__title {\r\n        font-size: 18px;\r\n    }\r\n    .file--last {\r\n        display: none;\r\n    }\r\n    .row__title-box {\r\n        padding-left: 15px;\r\n        margin-bottom: 20px;\r\n        margin-top: 20px;\r\n    }\r\n}\r\n\r\n@media screen and (max-width:480px) {\r\n    .file {\r\n        margin-left: 15px;\r\n        margin-bottom: 15px;\r\n        width: calc(50% - 15px);\r\n    }\r\n    .file--last {\r\n        display: block;\r\n    }\r\n}\r\n\r\n@media screen and (max-width:360px) {\r\n    .file {\r\n        margin-left: 0;\r\n        margin-bottom: 20px;\r\n        width: 100%;\r\n    }\r\n    .row--no-right {\r\n        margin: 0;\r\n    }\r\n    .row__title-box {\r\n        padding-left: 0;\r\n    }\r\n    .row__title {\r\n        font-size: 16px;\r\n    }\r\n}\r\n\r\n\r\n*/\n"

/***/ }),

/***/ "./src/app/components/course-module/file-manager/drive-home/drive-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DriveHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_primeng_tree__ = __webpack_require__("./node_modules/primeng/tree.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_primeng_tree___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_primeng_tree__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__file_manager_service__ = __webpack_require__("./src/app/components/course-module/file-manager/file-manager.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var DriveHomeComponent = /** @class */ (function () {
    function DriveHomeComponent(zone, fileService, msgService) {
        this.zone = zone;
        this.fileService = fileService;
        this.msgService = msgService;
        this.jsonFlag = {
            isRippleLoad: false,
            downloading: false,
            uploading: false
        };
        this.treeNodeData = [
            {
                label: "My Drive",
                data: null,
                expandedIcon: "fa fa-folder-open",
                collapsedIcon: "fa fa-folder",
                type: "folder",
                children: []
            }
        ];
        this.createFetchFolder = {
            folderName: "",
            institute_id: this.fileService.institute_id,
            keyName: ""
        };
        this.customstyle = "drop-area";
        this.selectedFiles = [];
        this.getCategoryData = [];
        this.addNewRow = [];
        this.pathArray = [];
        this.children = [];
        this.fileDisplayArr = [];
        this.folderDisplayArr = [];
        this.folderFileArr = [];
        this.isFolderEmpty = false;
        this.collapseFlag = false;
        this.getPopupOpen = false;
        this.createFolderControl = false;
        this.dragoverflag = false;
        this.addCategoryPopup = false;
        this.isGridView = true;
        this.isFirstTimeLoad = false;
        this.manualUpload = false;
        this.msg = '';
        this.getPath = "";
        this.headertext = '';
    }
    DriveHomeComponent.prototype.ngOnInit = function (refreshTree) {
        var institute_id = sessionStorage.getItem("institute_id");
        if (refreshTree == true) {
            this.fetchPrefillFolderAndFiles(institute_id + "/", refreshTree);
        }
        else {
            this.fetchPrefillFolderAndFiles(institute_id + "/");
        }
        this.fetchUsedSpace();
    };
    DriveHomeComponent.prototype.fetchPrefillFolderAndFiles = function (path, backLoad) {
        var _this = this;
        var institute_id = sessionStorage.getItem("institute_id");
        var obj = { keyName: path, institute_id: institute_id };
        this.fileService.getAllFolderFiles(obj).subscribe(function (res) {
            _this.children = res;
            _this.getPath = obj.keyName;
            _this.pathArray = _this.getPath.split('/');
            _this.pathArray.pop();
            // for End Empty Character
            if (backLoad) {
                _this.generateTreeNodes(res, obj.keyName, true);
            }
            else {
                _this.generateTreeNodes(res, obj.keyName);
            }
        });
    };
    DriveHomeComponent.prototype.fetchUsedSpace = function () {
        var _this = this;
        this.fileService.getUsedSpace().subscribe(function (res) {
            _this.usedSpaceDetails = res;
        });
    };
    DriveHomeComponent.prototype.getFilesAndFolder = function (event) {
        if (event >= 200 && event < 300) {
            this.fetchPrefillFolderAndFiles(this.filePathPopup, true);
        }
    };
    DriveHomeComponent.prototype.closeSharePopup = function (event) {
        console.log(event);
        this.getPopupOpen = event;
    };
    DriveHomeComponent.prototype.collapseString = function (index) {
        // let pathArray = this.getPath.split('/');
        this.pathArray = this.pathArray.filter(function (ele, i) {
            if (index >= i) {
                return true;
            }
            else {
                return false;
            }
        });
        // console.log(this.pathArray);
        var basePath = this.pathArray.join('/');
        // console.log(basePath);
        if (this.pathArray.length == 1) {
            basePath = basePath + '/';
            this.fetchPrefillFolderAndFiles(basePath, true);
        }
        else {
            this.collapseFlag = true;
            this.fetchPrefillFolderAndFiles(basePath + '/');
        }
    };
    DriveHomeComponent.prototype.getFilesDeleted = function (data) {
        var _this = this;
        var path = this.pathArray.join('/') + '/' + data.label + "/";
        var getDeletedFiles = [{
                file_id: "0",
                keyName: path
            }];
        if (confirm('Are you sure, you want to delete the file?')) {
            this.fileService.deleteFiles(getDeletedFiles).subscribe(function (data) {
                _this.msgService.showErrorMessage('success', '', "Folder Deleted Successfully");
                var path = getDeletedFiles[0].keyName.split('/');
                path.pop();
                path.pop();
                var newPath = path.join('/');
                if (newPath == _this.fileService.institute_id + '/') {
                    _this.fetchPrefillFolderAndFiles(newPath + "/", true);
                }
                else {
                    _this.fetchPrefillFolderAndFiles(newPath + '/', true);
                }
            }, function (error) {
                _this.msgService.showErrorMessage('success', '', error.error.message);
            });
        }
    };
    DriveHomeComponent.prototype.fileId = function (event) {
        this.fileIdGet = event;
    };
    DriveHomeComponent.prototype.fileArr = function (event) {
        this.fileName = event;
    };
    DriveHomeComponent.prototype.makeFolderOpen = function () {
        this.createFolderControl = true;
    };
    DriveHomeComponent.prototype.duplicateFolderCheck = function (name) {
        for (var i = 0; i < this.folderDisplayArr.length; i++) {
            if (this.folderDisplayArr[i].label == name) {
                this.msgService.showErrorMessage('error', '', "Folder already exists");
                return false;
            }
        }
        return true;
    };
    DriveHomeComponent.prototype.createFolder = function () {
        var _this = this;
        if (this.duplicateFolderCheck(this.createFetchFolder.folderName) == false) {
            return;
        }
        else if (this.createFetchFolder.folderName == "") {
            this.msgService.showErrorMessage('error', '', "Folder name is manadatory");
            return;
        }
        else {
            var path = "";
            var institute_id = sessionStorage.getItem("institute_id");
            path = this.pathArray.join('/') + '/';
            this.createFetchFolder.keyName = path;
            this.jsonFlag.isRippleLoad = true;
            this.fileService.craeteFolder(this.createFetchFolder).subscribe(function (data) {
                _this.jsonFlag.isRippleLoad = false;
                _this.createFolderControl = false;
                _this.createFetchFolder.folderName = "";
                _this.msgService.showErrorMessage('success', '', "Folder Created successfully");
                _this.fetchPrefillFolderAndFiles(_this.createFetchFolder.keyName, true);
                // this.ngOnInit(true);
            }, function (error) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage('error', '', error.error.message);
            });
        }
    };
    DriveHomeComponent.prototype.toggleView = function () {
        var _this = this;
        this.zone.runOutsideAngular(function () {
            if (_this.dragBox.nativeElement.classList.contains("grid__container")) {
                _this.dragBox.nativeElement.classList.remove("grid__container");
                _this.dragBox.nativeElement.classList.add("list__container");
                _this.isGridView = false;
            }
            else {
                _this.dragBox.nativeElement.classList.add("grid__container");
                _this.dragBox.nativeElement.classList.remove("list__container");
                _this.isGridView = true;
            }
        });
    };
    DriveHomeComponent.prototype.openSettings = function () { };
    DriveHomeComponent.prototype.onNodeExpand = function (event) {
    };
    DriveHomeComponent.prototype.onNodeSelect = function (event) {
    };
    DriveHomeComponent.prototype.searchDatabase = function (eve) {
    };
    DriveHomeComponent.prototype.onNodeCollapse = function (event) {
    };
    DriveHomeComponent.prototype.folderSelected = function (folder) {
        this.selectedFolder = folder;
        // this.getChildFolders(folder);
        if (folder.data.hasOwnProperty('keyName')) {
            this.fetchPrefillFolderAndFiles(folder.data.keyName, true);
        }
    };
    DriveHomeComponent.prototype.generateTreeNodes = function (res, path, backLoad) {
        if (backLoad == true) {
            this.isFirstTimeLoad = false;
        }
        else {
            this.prevLocalFolder = this.folderDisplayArr;
        }
        this.fileDisplayArr = [];
        this.folderDisplayArr = [];
        /* Local Directory Structure to be created from the incoming response */
        var localFolder = [];
        var childArr = [];
        var folderArr = [];
        if (res.files != null) {
            childArr = this.getChildArray(res.files);
        }
        if (res.folders != null) {
            folderArr = this.getChildFolders(res.folders);
        }
        if (res.files == null && res.folders == null) {
            var temp = [{
                    label: 'empty',
                    data: [],
                    expandedIcon: "",
                    collapsedIcon: "",
                    type: "",
                    children: []
                }];
            this.isFolderEmpty = true;
            this.updateTreeNode(temp);
            return;
        }
        this.isFolderEmpty = false;
        this.fileDisplayArr = childArr;
        this.folderDisplayArr = folderArr;
        localFolder = folderArr.concat(childArr);
        this.folderFileArr = localFolder;
        if (backLoad == true) {
            this.prevLocalFolder = localFolder;
        }
        /* Only When Calling the Home Folder Refresh the TreeNode */
        if (path.split("/")[1] == "") {
            /* If user has requested API for first time then fetch shell of outer folder */
            if (!this.isFirstTimeLoad) {
                this.treeNodeData = localFolder;
                this.isFirstTimeLoad = true;
            }
            else {
                this.updateTreeNode(localFolder);
            }
        }
        else {
            if (this.collapseFlag == true) {
                this.collapseFlag = false;
            }
            else {
                this.updateTreeNode(localFolder);
            }
        }
    };
    DriveHomeComponent.prototype.updateTreeNode = function (localFolder) {
        var _this = this;
        this.treeNodeData.forEach(function (node) {
            if (node.type == "folder") {
                if (node.label == _this.selectedFolder.label) {
                    if (node.children.length == 0) {
                        node.children = localFolder;
                    }
                    else {
                        _this.findNode(node, localFolder);
                    }
                }
                else {
                    if (node.children.length != 0) {
                        _this.findNode(node, localFolder);
                    }
                }
            }
        });
    };
    DriveHomeComponent.prototype.getCategories = function () {
        var _this = this;
        this.addCategoryPopup = true;
        this.fileService.getCategories().subscribe(function (data) {
            _this.getCategoryData = data;
        }, function (error) {
        });
    };
    DriveHomeComponent.prototype.closeCategoryPopup = function () {
        this.addCategoryPopup = false;
    };
    DriveHomeComponent.prototype.addNewRowToPopup = function (a) {
        var arr = [];
        if (this.addNewRow.length > 4) {
        }
        else {
            this.addNewRow.push(arr);
        }
    };
    DriveHomeComponent.prototype.findNode = function (node, localFolder) {
        var _this = this;
        this.nodes = node;
        this.localFolder = localFolder;
        node.children.forEach(function (child) {
            if (child.type === "folder") {
                if (child.label === _this.selectedFolder.label) {
                    child.children = localFolder;
                }
                else {
                    if (child.children != null) {
                        if (child.children.length != 0) {
                            _this.findNode(child, localFolder);
                        }
                        else {
                            child.children = [];
                        }
                    }
                    else {
                        child.children = [];
                    }
                }
            }
        });
    };
    DriveHomeComponent.prototype.getChildArray = function (obj) {
        var tempChildArr = [];
        var size = Object.keys(obj).length;
        if (size > 0) {
            for (var key in obj) {
                /* Structure for child files directly  under a folder */
                var childFile = { label: this.generateName(key, 'file'), icon: this.generateFileType(key), data: obj[key], type: "file" };
                tempChildArr.push(childFile);
            }
            return tempChildArr;
        }
        return tempChildArr;
    };
    DriveHomeComponent.prototype.getChildFolders = function (obj) {
        var tempFolderArr = [];
        var size = Object.keys(obj).length;
        if (size > 0) {
            for (var key in obj) {
                /* Structure to define a folder */
                var folderObj = {
                    label: this.generateName(key, 'folder'),
                    data: obj[key],
                    expandedIcon: "fa fa-folder-open",
                    collapsedIcon: "fa fa-folder",
                    type: "folder",
                    children: []
                };
                tempFolderArr.push(folderObj);
            }
            return tempFolderArr;
        }
        return tempFolderArr;
    };
    DriveHomeComponent.prototype.generateName = function (key, type) {
        var tempArr = key.split('/');
        if (tempArr.length >= 1) {
            if (type == "file") {
                return tempArr[tempArr.length - 1];
            }
            return tempArr[tempArr.length - 2];
        }
        return "";
    };
    DriveHomeComponent.prototype.generateFileType = function (key) {
        var tempArr = key.split('.');
        if (tempArr.length >= 1) {
            var type = tempArr[1];
            if (type == "pdf") {
                return "fa-file-pdf-o";
            }
            else if (type == "mp3") {
                return "fa fa-music";
            }
            else if (type == "wav") {
                return "fa fa-music";
            }
            else if (type == "wmv") {
                return "fa fa-music";
            }
            else if (type == "mp4") {
                return "fa fa-film";
            }
            else if (type == "flv") {
                return "fa fa-film";
            }
            else if (type == "mov") {
                return "fa fa-film";
            }
            else if (type == "jpg") {
                return "fa fa-picture-o";
            }
            else if (type == "jpeg") {
                return "fa fa-picture-o";
            }
            else if (type == "gif") {
                return "fa fa-picture-o";
            }
            else if (type == "png") {
                return "fa fa-picture-o";
            }
            else if (type == "doc") {
                return "fa fa-file-word-o";
            }
            else if (type == "docx") {
                return "fa fa-file-word-o";
            }
            else if (type == "xls") {
                return "fa fa-file-excel-o";
            }
            else if (type == "xlsx") {
                return "fa fa-file-excel-o";
            }
            else if (type == "csv") {
                return "fa fa-file-excel-o";
            }
            else if (type == "ppt") {
                return "fa fa-file-powerpoint-o";
            }
            else if (type == "pptx") {
                return "fa fa-file-powerpoint-o";
            }
            else if (type == "zip") {
                return "fa fa-file-archive-o";
            }
            else if (type == "rar") {
                return "fa fa-file-archive-o";
            }
            else if (type == "7z") {
                return "fa fa-file-archive-o";
            }
            return "fa-file-o";
        }
        return "fa-file-o";
    };
    DriveHomeComponent.prototype.navigateTo = function (location) {
        if (location == "") {
            var institute_id = sessionStorage.getItem("institute_id");
            this.fetchPrefillFolderAndFiles(institute_id + "/");
        }
    };
    DriveHomeComponent.prototype.preventAndStop = function (event) {
        event.stopPropagation();
        event.preventDefault();
    };
    DriveHomeComponent.prototype.onDragOver = function (event) {
        this.dragoverflag = true;
        this.dropZone.nativeElement.classList.add("over");
        this.preventAndStop(event);
    };
    DriveHomeComponent.prototype.onDragLeave = function (event) {
        if (event.target.classList.contains("ui-fileupload-content")) {
            this.dragoverflag = false;
            this.dropZone.nativeElement.classList.remove("over");
            this.preventAndStop(event);
        }
        this.preventAndStop(event);
    };
    DriveHomeComponent.prototype.onDrop = function (event) {
        this.preventAndStop(event);
        this.dropZone.nativeElement.classList.remove("over");
        this.dragoverflag = false;
        alert("files Uploaded");
    };
    DriveHomeComponent.prototype.onDragOverFolder = function (event, folder) {
        console.log(folder);
        this.dragoverflag = true;
        this.dropZone.nativeElement.classList.add("over");
        this.preventAndStop(event);
        if (folder != null) {
        }
    };
    DriveHomeComponent.prototype.onDragLeaveFolder = function (event, folder) {
        this.dragoverflag = true;
        this.dropZone.nativeElement.classList.add("over");
        this.preventAndStop(event);
        if (folder != null) {
        }
    };
    DriveHomeComponent.prototype.uploadBox = function () {
        this.manualUpload = true;
        this.addCategoryPopup = true;
    };
    DriveHomeComponent.prototype.getPopupValue = function (event) {
        this.getPopupOpen = true;
    };
    DriveHomeComponent.prototype.close = function (event) {
        this.manualUpload = false;
        this.addCategoryPopup = false;
    };
    DriveHomeComponent.prototype.onSelect = function (event, uploaders) {
        /* Remove the overlay from layout  */
        this.dropZone.nativeElement.classList.remove("over");
        this.dragoverflag = false;
        this.addCategoryPopup = true;
        this.selectedFiles = event.files;
    };
    DriveHomeComponent.prototype.status = function (event) {
        if (event == 200) {
            this.fetchPrefillFolderAndFiles(this.filePath1 + '/', true);
            // this.generateTreeNodes(event, "");
        }
        else {
        }
    };
    DriveHomeComponent.prototype.downloadStatus = function (event) {
        this.jsonFlag.isRippleLoad = event;
        this.jsonFlag.downloading = event;
    };
    DriveHomeComponent.prototype.uploadStatus = function (event) {
        this.jsonFlag.isRippleLoad = event;
        this.jsonFlag.uploading = event;
    };
    DriveHomeComponent.prototype.treeUpdater = function (event) {
        var institute_id = this.fileService.institute_id;
        if (event == true) {
            this.fetchPrefillFolderAndFiles(this.getPath, true); // it maintain the state of file  user stay in that state -- laxmi
        }
    };
    DriveHomeComponent.prototype.filePath = function (event) {
        this.filePath1 = event;
    };
    DriveHomeComponent.prototype.filePathUpload = function (event) {
        this.filePathPopup = event;
    };
    DriveHomeComponent.prototype.handleOptions = function (options) {
        this.shareOptions = options;
    };
    DriveHomeComponent.prototype.closeFolderControl = function () {
        this.createFolderControl = false;
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('DragContainer'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], DriveHomeComponent.prototype, "dragBox", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('dropZone'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], DriveHomeComponent.prototype, "dropZone", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('uploaders'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], DriveHomeComponent.prototype, "uploaders", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('expandingTree'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_1_primeng_tree__["Tree"])
    ], DriveHomeComponent.prototype, "expandingTree", void 0);
    DriveHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-drive-home',
            template: __webpack_require__("./src/app/components/course-module/file-manager/drive-home/drive-home.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/file-manager/drive-home/drive-home.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgZone"],
            __WEBPACK_IMPORTED_MODULE_2__file_manager_service__["a" /* FileManagerService */],
            __WEBPACK_IMPORTED_MODULE_3__services_message_show_service__["a" /* MessageShowService */]])
    ], DriveHomeComponent);
    return DriveHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/file-manager/file-card/file-card.component.html":
/***/ (function(module, exports) {

module.exports = "<div #fileHeader class=\"file\" (dragover)=\"onDragOver($event)\" (dragleave)=\"onDragLeave($event)\">\r\n  <div #fileImage class=\"file__img\"></div>\r\n  <div class=\"file__info\" *ngIf=\"fileDisplayArr.length!=0\">\r\n    <h2 class=\"file__title\" title=\"{{getFileName(fileObj.name)}}\">\r\n      {{getOriginalFileName(fileObj.res.file_name)}}\r\n    </h2>\r\n\r\n    <div class=\"file__made\" title=\"{{fileObj.res.category_name}}\">\r\n      {{fileObj.res.category_name}}\r\n    </div>\r\n\r\n    <div class=\"file__details file__owner\">{{fileObj.res.uploadedBy}}</div>\r\n\r\n    <div class=\"file__details file__date\">{{fileObj.res.uploaded_time}}</div>\r\n\r\n    <div class=\"file__details file__size\">{{fileObj.res.size}} KB</div>\r\n\r\n    <div class=\"file__details\">{{fileObj.res.downloads}}</div>\r\n\r\n    <i class=\"fa fa-trash\" style=\"font-size: 17px;  color: #52454596;\" title=\"Delete File\" (click)=\"getFilesDeleted(fileObj)\"></i>\r\n    <i class=\"fa fa-share-alt\" style=\"font-size: 17px; color: #52454596; margin-left: 1%;\" title=\"Share File\" (click)=\"getPopupOpen(fileObj)\"></i>\r\n    <a class=\"fa fa-download\" style=\"font-size: 17px; color: #52454596; margin-left: 1%;\" title=\"Download File\" (click)=\"getFileDownloaded(fileObj);\"\r\n      id=\"downloadFile\" ></a>\r\n    <a [href]='fileURL' id=\"downloadFileClick\" class=\"hide\" ></a>\r\n  </div>\r\n  <!-- <div *ngIf=\"fileDisplayArr.length == 0\" class=\"file__info\">\r\n    <h2 class=\"file__title\">\r\n      No Files Found !!\r\n    </h2>\r\n  </div> -->\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/file-manager/file-card/file-card.component.scss":
/***/ (function(module, exports) {

module.exports = ".file {\n  cursor: pointer;\n  width: 100%;\n  border-radius: 10px;\n  background-color: #fff;\n  -webkit-box-shadow: 0px 5px 5px -2px rgba(0, 0, 0, 0.2);\n          box-shadow: 0px 5px 5px -2px rgba(0, 0, 0, 0.2);\n  border: 1px solid rgba(0, 0, 0, 0.07);\n  float: left;\n  margin-left: 5px;\n  transition: all 0.3s;\n  -webkit-transition: all 0.3s;\n  -moz-transition: all 0.3s;\n  -ms-transition: all 0.3s;\n  -o-transition: all 0.3s;\n  margin-bottom: 0px; }\n  .file.table__header {\n    cursor: default;\n    width: 100%;\n    border-radius: 10px;\n    background-color: #fff;\n    -webkit-box-shadow: 0px 0px 1px 0px rgba(30, 35, 40, 0.36);\n            box-shadow: 0px 0px 1px 0px rgba(30, 35, 40, 0.36);\n    border: 1px solid rgba(0, 0, 0, 0.07);\n    float: left;\n    margin-left: 5px;\n    transition: all 0.3s;\n    -webkit-transition: all 0.3s;\n    -moz-transition: all 0.3s;\n    -ms-transition: all 0.3s;\n    -o-transition: all 0.3s;\n    margin-bottom: 5px; }\n  .file.table__header:hover {\n      -webkit-transform: translate(0, 0px);\n              transform: translate(0, 0px);\n      -webkit-box-shadow: none;\n              box-shadow: none; }\n  .file:hover {\n    -webkit-transform: translate(0, -4px);\n            transform: translate(0, -4px);\n    -webkit-box-shadow: 0px 7px 8px -2px rgba(0, 0, 0, 0.2);\n            box-shadow: 0px 7px 8px -2px rgba(0, 0, 0, 0.2); }\n  .file:hover {\n  -webkit-transform: translate(0, -4px);\n          transform: translate(0, -4px);\n  -webkit-box-shadow: 0px 17px 19px -2px rgba(0, 0, 0, 0.2);\n          box-shadow: 0px 17px 19px -2px rgba(0, 0, 0, 0.2); }\n  .file__img {\n  width: 10%;\n  height: 0;\n  padding-bottom: 0;\n  margin-top: 0;\n  background-repeat: no-repeat;\n  background-size: contain;\n  background-position: center;\n  border-top-right-radius: 10px;\n  border-top-left-radius: 10px; }\n  .file__info {\n  padding: 8px 5px 5px 35px;\n  position: relative; }\n  .file__title {\n  font-size: 14px;\n  font-weight: 600;\n  color: #252a3b;\n  width: 20%;\n  display: inline-block;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  line-height: 15px;\n  white-space: nowrap;\n  padding: 0px 7px; }\n  .file__made {\n  font-size: 13px;\n  color: #8087a2;\n  width: 15%;\n  display: inline-block;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  line-height: 15px;\n  white-space: nowrap;\n  padding: 0px 7px; }\n  .file__title:before {\n  width: 16px;\n  position: absolute;\n  left: 10px;\n  top: 6px; }\n  .file__details {\n  font-size: 13px;\n  color: #8087a2;\n  font-weight: 500;\n  padding: 0px 5px;\n  display: -webkit-inline-box;\n  display: -ms-inline-flexbox;\n  display: inline-flex;\n  width: 10%;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap; }\n  .file__details.file__date {\n    font-size: 13px;\n    color: #8087a2;\n    font-weight: 500;\n    padding: 0px 5px;\n    width: 15%; }\n  .file__details.file__size {\n    width: 10%; }\n  .file__details.file__size.small {\n      color: green; }\n  .file__details.file__size.normal {\n      color: blue; }\n  .file__details.file__size.large {\n      color: red; }\n  .file__details.file__owner {\n    width: 15%; }\n  .tree__view {\n  overflow: auto;\n  height: 375px; }\n  .audio-file .file__img {\n  background-image: url(\"data:image/svg+xml,%3C%3Fxml version%3D%221.0%22 encoding%3D%22utf-8%22%3F%3E%0D%3C!-- Generator%3A Adobe Illustrator 18.1.1%2C SVG Export Plug-In . SVG Version%3A 6.00 Build 0)  --%3E%0D%3Csvg version%3D%221.0%22  xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22 x%3D%220px%22 y%3D%220px%22%0D%09 viewBox%3D%220 0 48 48%22 enable-background%3D%22new 0 0 48 48%22 xml%3Aspace%3D%22preserve%22%3E%0D%3Crect x%3D%22204%22 y%3D%220%22 fill%3D%22none%22 width%3D%2248%22 height%3D%2248%22%2F%3E%0D%3Cg%3E%0D%09%3Cpolygon fill%3D%22%2390CAF9%22 points%3D%22244%2C45 212%2C45 212%2C3 234%2C3 244%2C13 %09%22%2F%3E%0D%3C%2Fg%3E%0D%3Cpolygon fill%3D%22%23E1F5FE%22 points%3D%22242.5%2C14 233%2C14 233%2C4.5 %22%2F%3E%0D%3Cg%3E%0D%09%3Ccircle fill%3D%22%231976D2%22 cx%3D%22227%22 cy%3D%2230%22 r%3D%224%22%2F%3E%0D%09%3Cpolygon fill%3D%22%231976D2%22 points%3D%22234%2C21 229%2C19 229%2C30 231%2C30 231%2C22.9 234%2C24 %09%22%2F%3E%0D%3C%2Fg%3E%0D%3Cg%3E%0D%09%3Cpolygon fill%3D%22%2390CAF9%22 points%3D%2240%2C45 8%2C45 8%2C3 30%2C3 40%2C13 %09%22%2F%3E%0D%3C%2Fg%3E%0D%3Cpolygon fill%3D%22%23E1F5FE%22 points%3D%2238.5%2C14 29%2C14 29%2C4.5 %22%2F%3E%0D%3Cg%3E%0D%09%3Ccircle fill%3D%22%231976D2%22 cx%3D%2223%22 cy%3D%2230%22 r%3D%224%22%2F%3E%0D%09%3Cpolygon fill%3D%22%231976D2%22 points%3D%2230%2C21 25%2C19 25%2C30 27%2C30 27%2C22.9 30%2C24 %09%22%2F%3E%0D%3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\"); }\n  .doc-file .file__img {\n  background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAeLUlEQVR42u2dC5QU1ZnHv+rumZ4X7zfIUxAkEPGJGKKAMMAggkJ8LQZFJjEHj3vYeA67SVzmrHs8muUcNyZGNyRGoysbH0sWVERgBgVEfIGCw1MQ5I0gMG/m0Xu/mmkyDFPdt6qr6lZ1/X/nFDXM1HR9t6fvv+79vu9+V6MAM/Pjk+3FaZI4RorjGnEMFEd31XYBdzj5+aZlGW3az3j3zhvqVNuiCk21AW4jOn1EnKaLYzY1dv6IapuAGr79dANp4fCqcFZuwep7xwRSBAIjAE0df5Y4fkmNT3oQcFgAdEKhknBm9LY19004o9omtwmEAIjOf704PSuOEaptAd7hvAAItHDkM6LYuJLCKYESgbQWgKanPj/xf0UY6oMWNBcARouwCGjTSuZOPqjaNrdIWwEQnT9PnJaKY7xqW4A3aSkAjBYO7xP/ji0pLNiv2j43SEsBEJ2fPfmrxDFMtS3Au7QmAIwuAqHQlJIHJm9XbaPTpJ0AND351xHm+yAJRgLAaKHQGdJ4JDBls2o7nSQdBWAFNYb3AEhIIgFgGkUgNF5MBz5RbatTpJUAiM7/c3FapNoO4A+SCYBOKHSOYlSw9qe3rFFtrxOkjQCIzs+x/a3iyFJtC/AHUgLAaFptOJo1dc19E1aqttlu0kkA2OM/XbUdwD9ICwATCtWHIhn3F8+Z+JJqu+0kLQRAdH729m9VbQfwF6YEoJFYOCt7jhgJvKDadrtIFwH4rTg9pNoO4C8sCAATC2fnLFgze/x/qLbfDtJFAI4QVvEBk1gUAJ1QZnShmA78m+o2pIrvBUB0fo73p3WsFjhDKgLAiOnA78V0YJ7qdqRCOggAr/BLK8cMcIdUBYAJRTL+Ujx38mzVbbFKOgjAQnEqUm0H8B92CAATima90VBTc9faB6f6rqYABAAEFrsEgOHCIrH6hgK/iQAEAAQWOwWAieTkvt9QX59ffH9+jeq2yQIBAIHFbgFgGguL0LiSwgJfFBaBAIDA4oQAMKFo1pcUo7HFc/JPqG5jMiAAILA4JQCMGAns05cTz53s6cIiEAAQWJwUAEaIwAEtFM4vfmDiTtVtNbRRtQGpAgEAVnFaABgtEjkmpgOTSwoLPJmsBgEAgcUNAWDEKOAshUL5YjqwSXWbL7JNtQGpAgEAVnFLABgxHaiKxRomr/3JLe+pbvcFdqk2IFUgAMAqbgqATmNhkWlr7puwQnXbz5uk2oBUgQAAq7guAEwoVB/Jzrlr9b3jXlfdfgYCAAKLEgFohGsK/GTN7PF/VP0eQABAYFEoAAxXF5ovpgO/UWkEBAAEFsUCoBPKjD5RPGfiv6i6PwQABBYvCAATjmb955r78+eruDcEAAQWrwgAo0UiL5fMLbjX9fuqbniqQACAVbwkAEwokrG0eO7k2928JwQABBavCQCjhcMrNS00XQhBtSv3U93gVIEAAKt4UQCYcGZ0fayhYYIbIgABAIHFqwLAhDIyN8RiDdNK5hacdPI+EAAQWLwsAEwoI6M0FiOuKXDcqXtAAEBg8boAMLoINDRMKSmc8rUTrw8BAIHl5OaNJDqXajOSooUjR0VPFSOBgh22v7bqxqUKBABY5fTOL6iuvEy1GVLoIkB0c0lhQamtr6u6YakCAQBWqTi0n6qOHlRthjRaKFRJmjZOTAdsKywCAQCBpa6ygk5v36LaDFMIEajSi43aJAIQABBoTu8Q04AKf0wDzqNpdZGsnBmrZ9+8LOWXUt2WVIEAgFSoOX2Syr6y3bfmPJrWIETgtlRFAAIAAs+ZnVuptvysajPMI0QgHM3+xzX3jf+d5ZdQ3YZUgQCAVKmvrqTvSrcQxWKqTbFCLJyV87BVEYAAACCoOnaYKg7uU22GVWJiJPD4mvsn/MrsL0IAAGji7Fc76NxpR1PvHcVKYREIAABNxOrr6czubVRXUa7aFMuEMqMvFM+ZeL/s9RAAAJrRUHuOzuzaRvXVVapNsYyZwiIQAABakCYi8CZp2o+KH5iUsKYABACAVmioq6Oze0r9lyTUDL2wSCw2IZEIQAAAMCAWa6Czu0uptuyMalMsI0RgQ4xoWvGcia16NyEAACSARwJVxw7qYUKf5gk01hQgbWzJA5MuKiwCAQAgCWIYrU8Fyg98RfVVlarNsQSLAGmhSWIk8E3z70MAAJCEw4RVxw+L0cAh/Wu/oUUiRzUtNLb4gUnnFz9AAAAwSV11JVUdOagvJCIfVBRqDhcWCUez8lf/eNxW/f+qDUoVCABQAZcS42lB9cnjVHv2tB469AtaOFwRyc67edWsmzZBAABIAe74tZXlVF9ZoQsCFxnxgxhwYZFoh875EAAAUoSdhOwcrK9pTBxi/wB/3VBbK0YK3vUVaKFwHQQAAJvgkGGdGA3E6utUmyINBAAAG+HRQENNNdXp4ULv5w1AAABwAJ4G8Gigoa5WtSkJgQAA4CD156p1x6BXswghAAA4DK8p0KMD52pUm3IREAAAXIKjArWVZZ5KHoIAAOAiesiwutIztQYgAAAooKG+Ti89pjpkCAEAQBFeCBlCAABQDGcL8mhARcgQAgCAR6g/V6PnDrgZMoQAAOAh3A4ZQgAA8CAcMqyrLNOXHTsJBAAAj9IYMqzSw4ZOAQEAwOM4GTKEAADgE3g0wOXI7HQSQgAA8BF6yNDGqkMQAAB8SGPIkFcZpuYkhAAA4FPsCBlCAADwOZxByAVJrYQMIQAApAFWQ4YQAADSCD1kyIVJ6+RChhAAANIQLkuurzJMEjKEAACQpsiEDCEAAKQ5iUKGEAAAAoAeMhRTAi5A0hwIAAABojFkWH5+yzIIAAABo3nIEAIAQEDhkCEEAIAAAwEAIMBAAAAIMBAAAAIMBACAAAMBACDAQAAACDAQAAACDAQAgAADAQAgwEAAAAgwEAAAAgwEAIAAAwEAIMBAAAAIMBAAAAIMBACAAAMBACDAQAAACDAQAAACDAQAgAADAQAgwEAAAAgwEAAAAgwEAIAAAwEAIMBAAAAIMBAAAAKM7wVgxqYTC7VQqEi1HQD4Ed8LwG3rDi4MZ2UXqbYDAD/iewGYVrx3YUabdkWq7QDAj/heAKau2rUw2r5TkWo7APAjlgVgzHPLssRpmDiGiONSV60OhUgLhcURokhO3phIds4YV+8PAo2WkUnhaBZ/9igUiag2J7W2mLlYdPo8cbpLHHeKY7Q4slQ3AACVsAhktu9I0Y5ddFHwG1ICIDp+d3FaII654shTbTQAXoSFIKdnH4pk56o2RZqkAiA6/zxx+ndxtFdtLAB+IKtrD8rt1U+fonodQwEQHb+zOC0Rx3jVRgLgN8JZOdSm/yB9iuBlWhUA0fnZsbeUGh18AAAriBFAXu8Bun/Aq6OBiwRAdP6B4rROHN1VGweA79E03S8Qbd+JQtEs8V9vRd4vsKbJy/8x4ckPgG1o4TDl9OpL4cwsiuRy6DBDtUl/t635f4QAvCZOM1UbBUC6Ec7K1kcCTCgjU/cNeGFacF4AROfnjv+aaoMASFeinbtRZtumYJqYCkSycyiUqXZaoN+5Katvuzj6qX6TAEhXOHs1t3d/fUpw/nvhiBgN5CqbFsQF4EFxelb1GwRAuhPt1JUy23W46PuhzKieQOT2tCAuAFupMa8fAOAg/KTP7TOg9R8qmBZoovOPEOfNqt8YAIICOwPZKWiEm9MCFgDO8X9C9ZsCQFDI7NCJoh06J71OnxYIIdA056YFLADLxfkW1W8KAEEhLDp1TvdL5C5umhaEo9ly15uEBWC3OA9U/aYAEBQ0MbTPM/IDGP2OPi2wv/4AC0BM9RsCEtOnfR71aptLHXOi1Dm39TXnx8qr6FRlNR34rpyOiq/9RF5mhPp3bEu92uVSt7yLn3RVtfWifZV06EwF7TtVRvUx/39k2wwYbOn37J4WeFoABnZqS8O7d6S2WZm2vF75uVo6W32OjpZV6R+mU1U1qpvYKtzZbxzQg67u1ZmGdutA2RnmVL+qto5Kj31Hnx76lj7cf4z2fVemukkXEBbD2hE9O+ltHNGzsy5wspyrq6fS441tK9lzmA6drVDdHEtYFQAdG6cFnhQA/kD8YtyVNLiLsyUIzggxaOwoJ+j9vUfoREW1sjZnhkM0YdAlNHVoX9vbvefbM/TWjgP0tjjO1Tcoa2PH7CjNGD6AJg2+RIxm7Kmes+Xwt/TG1n20/uujytplhZQEoAkt0jQtCFufFnhOAHg4+PyPxlCXPGecHongD9GLn+ykPSfPunrfSZf1psKRQ2zrFEbwFOGVLXvob9u+dnUYzX/Tu68cRDOH9afMSDj1F2yFnSdO0zMffElbj55yrV2pYIcAxOFSZGExIrAyLfCcANw9YiD9ZOTlSm14Z+c34sO0TUwZ6hy9T6+2OWKkc5U+zHeTA6fL6cmSLfpQ2mlG9elG83843DVBX1a6n57b+CVViamCl7FTAHT0aUGu6bqEnhOAp6f9QJ/3q+ZEeRUVrfrUsU5yk5j/LhgzwvT83i7qGxroD5t20KtffOXI6/M8v1AI+Z1XuFswmmGBe3Tlx/rZq9guAE2YnRZ4TgCW3HMzdW+To9oMHXY4PV68md7bd8TW150xvD89dIM3Mq+XlX5NT6/fZuuUIFsM8x8dfzWN6ttNWbvKa2rpF+985NkpgVMCEEd2WuA5ASj56VTVJlwAPykfW/2ZbSLgpc4fZ9Xug7rQ2QF3/ienjBSjuE6qm6VHQx7+vw2u+3RkcFoAdDTeNyNHL0RieAkEIDksAvOXb0z5aTK6X3d6bOK1ln+fP9D8YeYQZpxwSNPDhv07tklpOvHSZ7vo+Y93pvxeFU24Rp/eWIGf2ntOntHDtHE4OtKnQx7179BGtNW8k4uncoVvvK9HfLyEKwLQBK8p4OzD1qYFvhUADv9sOXyy1Z91yc06/2Hh5Bk+uJOk0kHYg174+vuWcwfY4bd45k2mbeBpyDu7vqHVuw/pIUujoTrPudmZOH5QLz2qYMXbvuCtD+mjgycsv0ezrhpED1xrrpoct2+VaNtK0cZEAssjCxYWDiMO7NzO1D3e23tY9+d4CTcFIA4vQOJqxc1XGvpWAF74ZCe9+OkuU6/NnZCHptf27qI/jc12Eg4TsnPJCs9MH23a289D8+c2lpoWHY63zxEdccrlfUz9Hj8t57y21lL0Y2jXDvT0tBtMPaU/+ua47n8wm8wz/Xv96GfXDzX191vwthC3b6yLm92oEACdFtOCQAlAc7iTPDx6mHiq9DT1e1Y+SPxEXjB2hPT1/FRc9P7n+pMxFTgE9+j4q0yNOpZu20dPb9hm6j48+lg880Y9nVeWVP9+LDiPTbxGOneCk6F4KuAVlAlAE/FpQWAFIM4d37+UfjZqqPT1Zj9IPId9+a5x0nFwu/wNcTik+mTBSGkR4PvP/utaU0/lKUP60CM3XSF9/R82baclW/ak3LbBXdrRU1NvkG7bvKXrqPT46ZTvaweqBSBO4AWAMZt89IsVH9HGA8ekrjXbOR4v/izlJ39LeE0Bi4Ds8NzMKICf/kv+4WbqkisncJxk9eTaLba1bdylPfWQowx2fmZSBQJggAoBYIomXC09Hdi4/5geY5bhudt/KJ3b76Sz6kExZ5ZNyuFow4y/vCuVTWemA7KPYfZfS2zP0uN1I7yOIhlm/m5OAwEwQJUAsE/gxTvHUl40eRkmHibPeGlV0tASr2Zkz78MPO+/+5U1jq1Q5KkIJ1nJzpkXvfe5voAoGU9NHaWv6JOB0485omE3sn87jhrNX/6B7fe3AgTAAFUCwBRedzndc6VcbRSZD/OcawfTvVddJvV6r2/dqy9mcRIzSUjsoV/w9qaE13C49dVZE6Rej3MX+Onv1CIkmRBkKlEcu4EAGKBSALrnZYv5rNxmyMV7DtFjaz5LeI2Z4T93Dqdz1zmW/saP86WcZjwimfrCOwmXD986tC/N/+H3pe797MZSx9YdMDzC4dFWotoCRe9+Yntat1UgAAaoFACGlyJzVl0yjpZV6kN2I3gJ7PL7J0vd080Qlex8meE02kTRiEdvvorGDewl9Vp3v7L6ggw/J+ApFy8ma03g3tt7hIpWfeLo/c0AATBAtQDMu+F7NHO4XL22qX9eYZg0w573RbeMUtqW1jDjtPvdB9v0YhtGvCpGSzLhTR7Z8AjHDTg0yElQI3p00hOFOINz6Zdf05LNezxVSgwCYIBqATCTtDNv6XrD5cJm8gseeXOjXuLKDdhhxtMAGd7avp8Wvf9Fqz9rl5VJf5s9UfJ1DuiJTeDvQAAMUC0AnGH2zG2jpa5NFLPnIhi3Du0n9TqJRhJO8Ma9+fr6iGQk8pqbeZ+eXr9VfwqDvwMBMEC1AHRvk01L7pFzBCbKaOPEm+t6d036GhxKnP7iStvbkQjZoiuJ/BxmphJey8P3AhAAA1QLgF02yHYyrmX34P+uc6QdRsg6AjkhqOD5Fa3+7Lbv9aOHRw+Xut+cV9d6rjKxaiAABvhJABKltcpWNlKRnGJmejL2v5a3+v3ZV19G910j9yF2IwLgNyAABkAAnMdM57VDAMb/4U1PeeC9AATAgKAJgEzGnd24LQBGrxFkIAAGBE0AVIwAzOQ6QACcAQJggJ8E4JXNe2jxR9tb/ZlsGjBn2nHGnZtwOfJJg3tLXWuHANzx8iqluy55EQiAAaoFwEwYMJENi6ZcT1df0iXpayRLKXYC2RBlIttYQFhIZIAT8GIgAAaoFgAzCS6JlsyaecpO/ONbru7Zx0tnZTbkTBSi5HJjj0++Tup+PMUxKuAaVCAABqgWADOpwIkqA5mpMlT4+nuu1a7nVXMr506RujZRgRIu0/38HWOkXke2toAdsLCxjyO+FoCLkPCybV4L4KXtwiAABqgWgId/MIxuG9Zf6tpES3jN7AGQbNGNnfC23FxHT4ZEewVwKbCVcwukyoy5UeuA4XUOXJy0taInW4+epEfe/FDp7sjNgQAYoFoAZJcD83r5iX962/DnZopluFmqykyREi6ekWjbbVlHJ+9nMO9v6x1vW7Jp158+3kEvf7bbcTtkgAAYoFIAzHRamQ+1bCiQxWTGS++6siCIKxT3apcrdS3XBUxUokw2nChbQi0V+G/H73eiEQnvOsSbu3gBCIABKgXATGjrlc27afFHOxJe88iNV0hvzuHGNMBMjYJ9p8r0TULsej2n/QAyJcFURFyMgAAYoEoAzBbNTFYthzHjB3C6Zh5jpoCnzF6B/J7x0mKZQqpOVj1if8TLd49LOtpyszBJMiAABqgSADNe+xMVVXT3f69J2ln5g8nFN7h4hgx2bZjRGmbCdozsCj4zC4ucWhYsG7lBUdCLgQBQY0iLHVqye80lygBsidl6/FxlyO6lsyxAi2fcKL07kRmnnZnS5/wE5pCnnZ54rr3IjluZtjkpsGaBABjgtgBw6OipW2+QSoxh2KHF80jZ1FYZ51RzuJPMX/aBbfsD8CiEM/9kshLjJPP+t8TM1IL9AOwPsAsz25HPWlJseiNSp4AAGOCmAPBuwY9PHind+ZllpfvpqXVfSF/PcOlsLqEti10iwGXAF4y9UrqDMFbm6lz4hAugyGLXk9jMoiYVay4SAQEwwA0BYOcVbzHNHn8zO+eW19TSrP8pNh3O4iE4h99knGVxOIPt8eLNtOWItRRaHppzXHxg53amfk/GudkaZkqEMzwSeGbDNkvZeSxsvN+imfuZ2c/RDSAABtglALyopzm8eSUn+AwTTyv2zpvp+HFS2drK7BbhcVbtPqgnr8huGtKrba4eEpswqJf0tCOOla3B4/BUh+fiZkSOw3IvfrJLb6NM9IOnM1zKjJOZZP0ZzKcHT9Ajb31oqV1OAQEwQFYA3IY/pPxETgUzm3K0hJ/K/EHefvw7PWTYvMPwFObSTu1oVN9uUnUIW4OH/uz4S8VBd1P/HlSUf43p3+MR1fp9R+nzI9/q+Qfl52rP/ywvM0MX7it6dKbR/btLR1TisGOV8xm8thoRAmDA6sIppp9cTmNXHjkPXZ+cMlJ00k6qm3QBvHkGd347OknhyMvpnhFy+yu6Ae8GxLsCeQ0IgAGy6bNuwZ1/wVubbFtJxk8wrhVgdm7uFNz55y/faNu+hDxM53LhZhyPTuGlsF9LIAAG8GqugZ280Tm4Xh9vKGn3MlIeCXCGoJnQnBPwVIIXIdm9KSmLAPs7rE537OAV0fEXb5LL1VABBMAAM4U0nIIX5/DKsVe/2OvYPbiT8B52d14xQMmUh1cgcj1DJxfo8NqKe68a5Gr7+G/3mw3b6G2X6g9YBQJgwHW9u9CTBdcruz8nwDy3sdS1hBGuQPTw6GHS24inCg/5F2/aYTmaYRYuzMEhO9kViKnAFYw4ycit4iqpAAFIgJkEDzvg3P7iPYf1p4bdw2FZODTJT0ynfAPc8TmJ6Y2te13dh5DhvIupQ/vqzkHZxVZm4L8fhxO5SrNf9h+AACSBOwR/aPjJaDb0YwSHhHjIy97uA6fL6OtTZXp4zUtPjKFd21PBkL40qm/XlDsLD4fZj1Hy1WF9ZKO6Gg4LAf9dC4b00cOVsmsvjOCwKIs2e/n90vHjQABAUjibjztKv45tqH/HtnqyjVGE5FRljf4k5OSanSfO6PkCvKhHdac3gh2hw3t0pMs6txejnrZ6u3jHYk7Yagmvv+C1F+y05IVS20W7eDt1J/0XTgMBACDAQAAACDAQAAACDAQAgADjJQHg8jPyC+IBAKmhadSmv1xpdsdNEQLAS9zMr1MFAFgilBml3Ev6qTZDhwVgsTjPVW0IAEEhkteWsruqXyzFsADcJ85/Vm0IAEEhq3M3ymjrTup3MlgAuJojL5g2XyIHAGCa3D4DKBSRr5zkJBr/I0TgNXGaqdoYANKdcHYu5fRQt0y6JXEBGCNO3tgyBYA0JrtbT4rkJt981i20+BdCBFaJ03jVBgGQrnjJ+x+nuQDwzopbCb4AABwhp2cfCmfJVzN2A635f4QILBCnJ1QbBUC6wV5/9v57Da3lN4QILBWn6aoNAyBd4KF/Tq8+pGneqnbNtCYAnBa8QhyjVRsHgN8JZWRSdo/eFIp4c2attfbNJhFYzl+qNhAAv+L1zs9oRj8QIsBWPyWOh1QbCYDfCGfnUHbXnqSFUyt75jRasguEENwiTr8VRz/VxgLgeTSNoh27UGa7DqotkTNX5iIhAlyd8qfi+GdxdFdtNACeQ3T8jDbtKbN9R08P+S8y28zFTULAEYI7qTFpCHUEQKDhuD5n9mXktfX8cL81TAlAc5p8BMOajktdtToU1t9sLRSiSE7emEhW9pj4jxrqavUDAKfQwhHdwReOZumfQT9jWQC8wq1r9izMbNuhqPn36muqqa6qgshnteIBcBvfC8D0tfsXRnLzilp+PxZroLrKCmo4V6PaRAA8i+8F4PYPjiwUw7Eio5/zdKCuooxiDd7cIAMAlfheAGZ+fHKhOBUluiYmpgL11VXiqFRtLgCeIhACEKehvk6fFsTgJARAJ1ACEAdOQgAaCaQAMOwTYBGAkxAEmcAKQJyG2loxLYCTEASTwAsAAychCCoQgGbASQiCBgSgFeAkBEEBAmAAnIQgCEAAkgAnIUhnIAASwEkI0hUIgAngJATpBgTAAnASgnQBAmAROAlBOgABSBE4CYGfgQDYAJyEwK9AAGwETkLgNyAADgAnIfALEACHgJMQ+AEIgMPASQi8DATABeAkBF4FAuAicBICr5EOAjBLnF5SbYcZ4CQEHqEiHQRghDhtVm2HWeAkBB5gt+8FgBEicIR8umsxnIRAIcvTRQB+K04PqbbDKnASAiXEYv+aLgLAOxRvVW1HqsBJCFzmprQQAEaIwFJxmq7aDjuAkxC4wEnx+eqeTgIwkBpHAVmqbbEDOAmBw/x+ef7geWkjAIwQgZ+L0yLVdtgJnITACUTHv2JZ/uAv0koAGCECK8Rpkmo77AROQmAnotMvFZ3/9qav0wshAHnitE4cI1TbYjdwEgIbqBFPlO8vnzhkF/8n7QSAESLAOQGrxDFMtS1OACchSIEFYu7/6/h/0lIAmKaRAEcGxqu2xQngJARm0WKx15ZNHHLHBd9TbZSTCBGIiNMvxfErcURU2+MEcBICKWL0gfhnkhj6lzX/dloLQBwhBNeL07OUhn4BBk5CkAjx5F8iPiM/Xj7p8rqLfqbaOLdoGg3wykEeEQxUbY8TwEkIWnBGdPB/WpY/+HmjCwIjAHGahIAzBmdTY7gw7aYGcBIGnpPi+JMY9j+xfOLg7xJdGDgBaI4Qg/bUKAIjxXENNY4MfLmqsCVwEgaKM+LYK4b6G2OatlJ8/e7y/MHVMr/4//o84b8GUOQCAAAAAElFTkSuQmCC\"); }\n  .file-file .file__img {\n  background-image: url(\"data:image/svg+xml,%3C%3Fxml version%3D%221.0%22 encoding%3D%22utf-8%22%3F%3E%0D%3C!-- Generator%3A Adobe Illustrator 18.1.1%2C SVG Export Plug-In . SVG Version%3A 6.00 Build 0)  --%3E%0D%3Csvg version%3D%221.0%22  xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22 x%3D%220px%22 y%3D%220px%22%0D%09 viewBox%3D%220 0 48 48%22 enable-background%3D%22new 0 0 48 48%22 xml%3Aspace%3D%22preserve%22%3E%0D%3Cg%3E%0D%09%3Cpolygon fill%3D%22%2390CAF9%22 points%3D%2240%2C45 8%2C45 8%2C3 30%2C3 40%2C13 %09%22%2F%3E%0D%3C%2Fg%3E%0D%3Cpolygon fill%3D%22%23E1F5FE%22 points%3D%2238.5%2C14 29%2C14 29%2C4.5 %22%2F%3E%0D%3C%2Fsvg%3E%0D\"); }\n  .folder-file .file__img {\n  background-image: url('folder.jpg'); }\n  .image-file .file__img {\n  background-image: url(\"data:image/svg+xml,%3C%3Fxml version%3D%221.0%22 encoding%3D%22utf-8%22%3F%3E%0D%3C!-- Generator%3A Adobe Illustrator 18.1.1%2C SVG Export Plug-In . SVG Version%3A 6.00 Build 0)  --%3E%0D%3Csvg version%3D%221.0%22  xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22 x%3D%220px%22 y%3D%220px%22%0D%09 viewBox%3D%220 0 48 48%22 enable-background%3D%22new 0 0 48 48%22 xml%3Aspace%3D%22preserve%22%3E%0D%3Cg%3E%0D%09%3Cpolygon fill%3D%22%2390CAF9%22 points%3D%2240%2C45 8%2C45 8%2C3 30%2C3 40%2C13 %09%22%2F%3E%0D%3C%2Fg%3E%0D%3Cpolygon fill%3D%22%23E1F5FE%22 points%3D%2238.5%2C14 29%2C14 29%2C4.5 %22%2F%3E%0D%3Cpolygon fill%3D%22%231565C0%22 points%3D%2221%2C23 14%2C33 28%2C33 %22%2F%3E%0D%3Cpolygon fill%3D%22%231976D2%22 points%3D%2228%2C26.4 23%2C33 33%2C33 %22%2F%3E%0D%3Ccircle fill%3D%22%231976D2%22 cx%3D%2231.5%22 cy%3D%2224.5%22 r%3D%221.5%22%2F%3E%0D%3C%2Fsvg%3E%0D\"); }\n  .pdf-file .file__img {\n  background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEXiV0z///+1NinXUETUTULhSz7hTkHhUUbqkIr2z83yu7jiVUrxs6/hT0Prk430xMG0MiTgRTfof3jjXVLupKD++fnvqaW2JxTla2L31tT77Ou2Igy1HgDgQzXgSDrFQjb23Nrxt7O2MCDphn/45OLsmpTlbWT0ycbnd2/77ey2JxP429njYFbYVku2MSHmc2roUbmEAAAGiElEQVR4nO3da4OiNhQGYHCXi2YYRcXqtNJlx9vU6c7//3dFJQFCggRwOcee9+MuSh4OhIBMsGx1dom/XliDhP37pmlUq1jKf92cYtdjwwAt6/uvPokqYTQPvaF0V+Hs5+6hwjdrUF8qHM1+9lfFqvDNGWz3FMLR7FdvVawII2to4EXYYxUrwvdgaOBVOOrtWJSFm3BoXyYczf7ohygL5wP3Mrmwrx1VEr4BKCEX9lRFSZi4Q/OsXNjPsSgJfQA7aS7spYqScD34qcIqCvsgSsIFMGEPO6okZNCE3asIXti5ivCFo9k/nYgIhB2riEHYrYoohJ26GxzCLkQkwg5ELML2RDTC0ezPdkQ8wrSKP55cmFaxDRGTsN2xiErYqoq4hG2ORWTCdABnSsQmNCeiExrvqPiEpt0NQqHhjopRaFZFlEKjKuIUjmZ/nZ9cmFaxKRGrMD0WGxLRChsT8QpT4ubJhQ27G8zCtLtpUEXUwrSK94m4hU2qiFzYoIrYhfd7VPTCu0T8wnvEJxCmxDEy4TdD4WhU191AFFrGwrod9TmEdScNkMK/zYkj7bEIUmja1Vzzl4YIUthiN9VXEabQvDfVVxGmsNWRqKkiUGGPRKjClkTFjgpW2FsV4QrbdjdHPMLU2KKOM5kIWnjJN9N8d5AJjcOspxcyEmIPCUkIPyQkIfyQkITwQ0ISwg8JSQg/JCQh/JCQhPBDQhLCDwlJCD8kJKHiG73A5QkCTzlZWGGRdJmgZmrU4pKXhVu0p2+hF+xf8qz289CRkWw7X5WX8UJH2XYW+y+lrL6coYXBuy1n/B6XjOyzOjtgtNmz6iyizKvOKJCYEnsWskWlSWl2p2KzQs30h9NP2eiontoyncmxZ2GwUrd+FYtFvGqVeSZMKrZyQxhOdNiz0JGfz+FJBDF40Qrt6KvYfPW22Bjupn0LtU/Jr3jD3IleaNt+of2er1piClVoH1gToe3nVVQL34c9DmuEu20jof0lBErhceC+VAjHp/kly8LfPJ48SfhjfMlmF5VWGbl8nUK4mx6zTF9j/cp/r3Aae5cE27y3yLZ+LvS3ziWxe3gpIie8SkI4uS2YxjWfT/VhQt5MR+xqWXFy4avH2xBsi2cZPmlqLuwyE+7DhdZWjEvWGuH1g/N8pfxQwyIMlvzLbr2gWmi5BWI2SToWoXfiX7YPaoRWnPextwXRCNmaf9mqVsg8sdZs2IJFmNdwWSu0nCn/jwiXsOFxmILyI/HWJ2ERhqIvPdT0pZemxGK1ew+R0Hnl36U9H/LE4sJx5SIQhrcxTZiPLStjGlnoiL+KvG2fXOiwLICEG//1kmVhdqO5PC6tCEVXMy4Lp97iFrfF+1KGvLaQha5OmOdo/saiIa8PG9ewkDOYa4tKltVr/IpQfFgv5Ndg8IQTse1r+lJxXpmW+9LSljJ9781vEhbutemFYb54gExYul+qH9OI4V324hCl0PiNG48XRsd56Z63flyaiM8syqO2QsZD39UXwvPymr3/tZV+t9BeWwTiVsbHbZ/OhRFPYn5CfNiYZhtcUz1/6YROfqc4u61dHdO4LYZvjx95NxQGX/laszNCVWjugyMM1vnttl3W8QIfeZsIWbAtdir8FUz4hX54uwkaW/vi74S8hE8g3FxuZU+P54/yOsUZD79Qnb3gPKkwKfyW+pTCZJsvCVN4vNsoN6kB7ouXf+I3YEhC8RO2/hJA/bvnNed1iSLuJRtfT5S+pednMXijPvUfjKW+k2czj+VnMbKTSKf32/X9PI27v37Or9nq7LP6lEx0Xn7Glat3drgOdF47vey192ei3MPkmKxr28Sc8jNRS/8QqJ+J8qyX4+TQ7W22D3iuzXXce5/yglI87WpYcP/L7rWHnk0cuoGdQ0ISwg8JSQg/JCQh/JCQhPBDQhLCDwlJCD8kJCH8kJCE8ENCEsIPCUkIPyQkIfyQkITwQ0ISwg8JSQg/JCQh/JCQhPBDQhLCDwlJCD8kJCH8kJCE8ENCEsIPCUkIP/97Yae/9YcR+YUUktB4djR4yecxVgp901kK4UWeh0MSdppVBEbk2WIk4Uc4dAM7J/yoFRq/1QVcCjNMq4Ub7EUMz3eE9nu3mUWGTvXtTBVhZGE+YTAruiu031rMvwwlzK2+W6oqtN8srDtqYClenqUQ2tE8xNijeuG8sotqhGmPeopd85m0Bwzz3Pi0UVrUwnRXTfz1Yuh2N85i7Seat7vZ/wEZOaZYHrwlvwAAAABJRU5ErkJggg==\"); }\n  .text-file .file__img {\n  background-image: url('txt.png'); }\n  .video-file .file__img {\n  background-image: url(\"data:image/svg+xml,%3C%3Fxml version%3D%221.0%22 encoding%3D%22utf-8%22%3F%3E%0D%3C!-- Generator%3A Adobe Illustrator 18.1.1%2C SVG Export Plug-In . SVG Version%3A 6.00 Build 0)  --%3E%0D%3Csvg version%3D%221.0%22  xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22 x%3D%220px%22 y%3D%220px%22%0D%09 viewBox%3D%220 0 48 48%22 enable-background%3D%22new 0 0 48 48%22 xml%3Aspace%3D%22preserve%22%3E%0D%3Cg%3E%0D%09%3Cpolygon fill%3D%22%2390CAF9%22 points%3D%2240%2C45 8%2C45 8%2C3 30%2C3 40%2C13 %09%22%2F%3E%0D%3C%2Fg%3E%0D%3Cpolygon fill%3D%22%23E1F5FE%22 points%3D%2238.5%2C14 29%2C14 29%2C4.5 %22%2F%3E%0D%3Cpolygon fill%3D%22%231976D2%22 points%3D%2230%2C28 20%2C22 20%2C34 %22%2F%3E%0D%3C%2Fsvg%3E%0D\"); }\n  .xlsx-file .file__img {\n  background-image: url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEXh+ez///9VpH70/fhQonvn/fFYpoGDvqH2/flJn3fG3tLj+u3R799DnXNMoHiHwKP2+fjE3NCw0sA3d1OOwKfe7OWGr5cuckxjq4inzbq41sd3tJbW597p8+7P49mbx7FyspNproyQwKgfbUTG1cylva9Rhmdym4OVsqG4zMAPZzvS3dahyrWCpJDu9fI7mm5pGuNxAAAF80lEQVR4nO3dfXfiKBQH4JoyWpyB0Uyy1Ri1trO7M91u5/t/u1UTLnnD+pKBwP7uHz0nNVIeIRdIj+FuFHrcua7Ab49zhQ/2wo3w/s5WfJ6kgQs/fRX9EgcolLxX4gCFLBJ56MJeicMU9kkcqLBH4lCF/REHK4zENHRhJDahC3siDlnYD3HQwl6uxWELIzEPXdgDcejCSGShC29uxeELb21FD4Q3En0Q3kb0QngT0Q/hLURPhJFYhi68nuiN8GqiP8JriR4JryT6JIzENnThVUS/hBG/nOiZ8IpW9E14eSt6J4x4ErrwUqKHwguJPgovI3opvIjopzDik9CFkTyb6Kvw/Fb0Vnh2K/orPJfosTCST6ELI7kKXXgW0W/hOUTPhWdci74LI7kLXRixD4j+Cz8iDk84EZfGr8XMJ+Hdpyvi3ivhNQEhhBC6DwghhNB9QAghhO4DQgghdB8QQgih+4AQQgjdB4QQQug+IIQQQvcBIYQQug8IIYTQfUAIIYTuA0IIIXQfEEIIofuAEEII3QeEEELoPiCEEEL3ASGEELoPCCGE0H1ACOE+Hq55WkXv0bswT3RMhhBf+hZOBRtUiC+f+xbyC5+F85uDQwghhM4DQgghdB8QWhIyWUbvwIEIWRIvDxEv+ycOQ8hpY00RunAGIYQQQgghhBB6LFTTTsk6j01CKYQcjw8/qw+zpkms7D52IZTLuIzkWFX5po63zCzk42V+fCL1LM1Wgozsa6beffxTbKUOM4fCN/XqkcAWdPbEKGRRbYv092d6aUy/XB3eLdJTf9pWLxVr9fKhETnt8bopqt0hlKvmA8Vzprr4svp2pncB6GpCW0JG+y2k+0oJOnkcGYSVelOs1XXG3yvv59TUbw6vwz2K6rFjus/G3CjseiR82eIRo71iYqn77Lo7D1sbLagiGacuO1OntoS6I66zLKeyd2U/FTmdL2P14qp78wBrQl1nvedSourUEgrVD7NfUgraTSxW4wOlqkSoxt4YhlJ7Iz5VOlGclOrUbkNV2vGYGn1Dja5yVU4f17j7z1oU0sVDaXVH3aolXNSOZZwWkVEu4arp1OcWm6ZSFmdtIq+fmOkTzW24PI70styTQidL+VwvzDzdsyisjPPHOlUSQ/s6pFSabseCy3YS0eP8MRLjHiU2Z968tpn7tjJ6tduweur7dLvgzbGuPmCm5hm71bWFfNCn1UavjjlNYzxcL5vzaj6vvLwwbzNjV1jZRPKpWqeOEX/XKnjZaCepP4TsxIrNqpBXNgFPqk3S0YZsnDdLzmslVy9r01hoW1hLNbMPhPtcsto0iq5BaqlmMoxeKmo1rvas7vUh4yzJaimz0rVZbdvU9xMdx+Jo0djPrZIdjHcxGBdioteJesTXQ34RS3MGtyfUa54icq05eZ+GiZ3S6CuRx/XCjJM2i0Kaeq9VfRPjrI0G/KIs2jechhh9Sat8ZEw2FttQnfCsPv6ZbpGmUF19xdRVKmGq3kEzwJxWZYbFkz0hpZkZp0rFpvUhLfrWTOxXT0xN1uflG3SamdCH8e549aTTTCz1/0NVsmldh/pm0yaLdQpW7cTV5GgtNNbw/2NrdzFozTSuzFdUsmnPS9+axdZOpzSzn9zSurP7RpS1O8JU46moDtYT0x1hkbUKpjtROs0cpg10kRqSja02pJcPg7buWeVI3TFaiOZwMErV3UQ9czjOGhid0Zls7Aj1lVcsc/TQWNx56RoP+ao2nZltaaTQuzIXJ1Jzd85s7AgX03kR0+JjZs/qF/Pi+K08rkxa9vOZJzVnW88neoEo4/LkaZlbqPRNVyNa6qVcBVO1L0PWj+vpkEkhosUiEoJXqy4bb26V7kLoMCCEEEL3ASGEELoPCCGE0H1AeLlwzseDCtn794BH/75+K+Lxj3vX3+M+hAl4w7fV/3xRQnPpQ4gbvo///SV04Sj99hi4cDT76zFw4Wj090vowtGP19CFo5+voQtH/wQv/B88nwZCxwEhhBC6DwghhNB9QAjhkTjoeDhR83OF/kb4wv8A4wD3fzyZ35cAAAAASUVORK5CYII=\"); }\n  .zip-file .file__img {\n  background-image: url(\"data:image/svg+xml,%3C%3Fxml version%3D%221.0%22 encoding%3D%22iso-8859-1%22%3F%3E%0D%3C!-- Generator%3A Adobe Illustrator 19.1.1%2C SVG Export Plug-In . SVG Version%3A 6.00 Build 0)  --%3E%0D%3Csvg version%3D%221.1%22  xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22 x%3D%220px%22 y%3D%220px%22%0D%09 viewBox%3D%220 0 48 48%22 style%3D%22enable-background%3Anew 0 0 48 48%3B%22 xml%3Aspace%3D%22preserve%22%3E%0D%3Cpolygon style%3D%22fill%3A%23FF9100%3B%22 points%3D%2240%2C45 8%2C45 8%2C3 30%2C3 40%2C13 %22%2F%3E%0D%3Cpolygon style%3D%22fill%3A%23FFE0B2%3B%22 points%3D%2238.5%2C14 29%2C14 29%2C4.5 %22%2F%3E%0D%3Cg%3E%0D%09%3Cpath style%3D%22fill%3A%23FFE0B2%3B%22 d%3D%22M17.393%2C31.331h4.102V33h-6.453v-1.211l4.06-7.066H15v-1.676h6.419v1.184L17.393%2C31.331z%22%2F%3E%0D%09%3Cpath style%3D%22fill%3A%23FFE0B2%3B%22 d%3D%22M24.83%2C33h-2.01v-9.953h2.01V33z%22%2F%3E%0D%09%3Cpath style%3D%22fill%3A%23FFE0B2%3B%22 d%3D%22M28.528%2C29.5V33h-2.01v-9.953h3.391c0.984%2C0%2C1.769%2C0.305%2C2.354%2C0.916%0D%09%09c0.586%2C0.611%2C0.879%2C1.404%2C0.879%2C2.379s-0.29%2C1.744-0.868%2C2.31c-0.579%2C0.566-1.381%2C0.848-2.406%2C0.848H28.528z M28.528%2C27.824h1.381%0D%09%09c0.383%2C0%2C0.679-0.125%2C0.889-0.375c0.209-0.25%2C0.315-0.615%2C0.315-1.094c0-0.496-0.107-0.891-0.321-1.188%0D%09%09c-0.215-0.293-0.502-0.441-0.861-0.445h-1.401V27.824z%22%2F%3E%0D%3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\"); }\n  .image .file__title:before {\n  content: url(\"data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTguMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDMxNS41OCAzMTUuNTgiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDMxNS41OCAzMTUuNTg7IiB4bWw6c3BhY2U9InByZXNlcnZlIiB3aWR0aD0iMTZweCIgaGVpZ2h0PSIxNnB4Ij4KPGc+Cgk8cGF0aCBkPSJNMzEwLjU4LDMzLjMzMUg1Yy0yLjc2MSwwLTUsMi4yMzgtNSw1djIzOC45MThjMCwyLjc2MiwyLjIzOSw1LDUsNWgzMDUuNThjMi43NjMsMCw1LTIuMjM4LDUtNVYzOC4zMzEgICBDMzE1LjU4LDM1LjU2OSwzMTMuMzQzLDMzLjMzMSwzMTAuNTgsMzMuMzMxeiBNMjg1LjU4LDI0Mi4zODZsLTY4Ljc2Ni03MS4yMTRjLTAuNzYtMC43ODUtMi4wMDMtMC44MzYtMi44MjMtMC4xMTRsLTQ3LjY5NSw0MS45NzkgICBsLTYwLjk2Mi03NS4wNjFjLTAuMzk2LTAuNDktMC45NzUtMC43Ny0xLjYzLTAuNzU2Yy0wLjYzMSwwLjAxMy0xLjIyLDAuMzE2LTEuNTk3LDAuODIyTDMwLDIzNC43OTdWNjMuMzMxaDI1NS41OFYyNDIuMzg2eiIgZmlsbD0iIzQ4ODVmNCIvPgoJPHBhdGggZD0iTTIxMC4wNTksMTM1LjU1NWMxMy41MzgsMCwyNC41MjktMTAuOTgyLDI0LjUyOS0yNC41MzFjMC0xMy41NDUtMTAuOTkxLTI0LjUzMy0yNC41MjktMjQuNTMzICAgYy0xMy41NDksMC0yNC41MjgsMTAuOTg4LTI0LjUyOCwyNC41MzNDMTg1LjUzMSwxMjQuNTcyLDE5Ni41MTEsMTM1LjU1NSwyMTAuMDU5LDEzNS41NTV6IiBmaWxsPSIjNDg4NWY0Ii8+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==\"); }\n  .folder .file__title:before {\n  content: url(\"data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgd2lkdGg9IjE2cHgiIGhlaWdodD0iMTZweCIgdmlld0JveD0iMCAwIDQ3NS4wODIgNDc1LjA4MiIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNDc1LjA4MiA0NzUuMDgyOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CjxnPgoJPHBhdGggZD0iTTQ1Ni4yMzksMTI4LjQ3NWMtMTIuNTYtMTIuNTYyLTI3LjU5Ny0xOC44NDItNDUuMTEtMTguODQyaC0xOTEuODZ2LTkuMTM2YzAtMTcuNTExLTYuMjgzLTMyLjU0OC0xOC44NDMtNDUuMTA3ICAgYy0xMi41NjItMTIuNTYyLTI3LjYtMTguODQ2LTQ1LjExMS0xOC44NDZINjMuOTUzYy0xNy41MTUsMC0zMi41NTEsNi4yODMtNDUuMTExLDE4Ljg0NkM2LjI4LDY3Ljk0OSwwLDgyLjk4NiwwLDEwMC40OTd2Mjc0LjA4OCAgIGMwLDE3LjUwOCw2LjI4LDMyLjU0NSwxOC44NDIsNDUuMTA0YzEyLjU2MiwxMi41NjUsMjcuNiwxOC44NDksNDUuMTExLDE4Ljg0OWgzNDcuMTc1YzE3LjUxNCwwLDMyLjU1MS02LjI4Myw0NS4xMS0xOC44NDkgICBjMTIuNTY2LTEyLjU2LDE4Ljg0My0yNy41OTcsMTguODQzLTQ1LjEwNFYxNzMuNTlDNDc1LjA4MiwxNTYuMDc4LDQ2OC44MDUsMTQxLjA0Miw0NTYuMjM5LDEyOC40NzV6IiBmaWxsPSIjZmZjYTQ1Ii8+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==\"); }\n  .audio .file__title:before {\n  content: url(\"data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDU1IDU1IiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA1NSA1NTsiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIxNnB4IiBoZWlnaHQ9IjE2cHgiPgo8cGF0aCBkPSJNNTIuNjYsMC4yNDljLTAuMjE2LTAuMTg5LTAuNTAxLTAuMjc1LTAuNzg5LTAuMjQxbC0zMSw0LjAxMUMyMC4zNzMsNC4wODQsMjAsNC41MDcsMjAsNS4wMXY2LjAxN3Y0LjIxMnYyNS4zODQgIEMxOC4xNzQsMzguNDI4LDE1LjI3MywzNywxMiwzN2MtNS41MTQsMC0xMCw0LjAzNy0xMCw5czQuNDg2LDksMTAsOXMxMC00LjAzNywxMC05YzAtMC4yMzItMC4wMTktMC40Ni0wLjAzOS0wLjY4NyAgQzIxLjk3NCw0NS4yNDgsMjIsNDUuMTg5LDIyLDQ1LjEyMVYxNi4xMThsMjktMy43NTN2MTguMjU3QzQ5LjE3NCwyOC40MjgsNDYuMjczLDI3LDQzLDI3Yy01LjUxNCwwLTEwLDQuMDM3LTEwLDlzNC40ODYsOSwxMCw5ICBjNS40NjQsMCw5LjkxMy0zLjk2Niw5Ljk5My04Ljg2N2MwLTAuMDEzLDAuMDA3LTAuMDI0LDAuMDA3LTAuMDM3VjExLjIyN1Y3LjAxNlYxQzUzLDAuNzEyLDUyLjg3NiwwLjQzOCw1Mi42NiwwLjI0OXoiIGZpbGw9IiNmZjUwNDEiLz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==\"); }\n  .video .file__title:before {\n  content: url(\"data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgd2lkdGg9IjE2cHgiIGhlaWdodD0iMTZweCIgdmlld0JveD0iMCAwIDkwIDkwIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA5MCA5MDsiIHhtbDpzcGFjZT0icHJlc2VydmUiPgo8Zz4KCTxwYXRoIGlkPSJZb3VUdWJlX194MjhfYWx0X3gyOV8iIGQ9Ik05MCwyNi45NThDOTAsMTkuNTI1LDgzLjk3OSwxMy41LDc2LjU1LDEzLjVoLTYzLjFDNi4wMjEsMTMuNSwwLDE5LjUyNSwwLDI2Ljk1OHYzNi4wODQgICBDMCw3MC40NzUsNi4wMjEsNzYuNSwxMy40NSw3Ni41aDYzLjFDODMuOTc5LDc2LjUsOTAsNzAuNDc1LDkwLDYzLjA0MlYyNi45NTh6IE0zNiw2MC4yMjVWMjYuMzNsMjUuNzAyLDE2Ljk0N0wzNiw2MC4yMjV6IiBmaWxsPSIjOTk3MmZlIi8+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==\"); }\n  .pdf .file__title:before {\n  content: url(\"data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCINCgkgdmlld0JveD0iMCAwIDUxMiA1MTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUxMiA1MTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxwYXRoIHN0eWxlPSJmaWxsOiNFMkU1RTc7IiBkPSJNMTI4LDBjLTE3LjYsMC0zMiwxNC40LTMyLDMydjQ0OGMwLDE3LjYsMTQuNCwzMiwzMiwzMmgzMjBjMTcuNiwwLDMyLTE0LjQsMzItMzJWMTI4TDM1MiwwSDEyOHoiLz4NCjxwYXRoIHN0eWxlPSJmaWxsOiNCMEI3QkQ7IiBkPSJNMzg0LDEyOGg5NkwzNTIsMHY5NkMzNTIsMTEzLjYsMzY2LjQsMTI4LDM4NCwxMjh6Ii8+DQo8cG9seWdvbiBzdHlsZT0iZmlsbDojQ0FEMUQ4OyIgcG9pbnRzPSI0ODAsMjI0IDM4NCwxMjggNDgwLDEyOCAiLz4NCjxwYXRoIHN0eWxlPSJmaWxsOiNGMTU2NDI7IiBkPSJNNDE2LDQxNmMwLDguOC03LjIsMTYtMTYsMTZINDhjLTguOCwwLTE2LTcuMi0xNi0xNlYyNTZjMC04LjgsNy4yLTE2LDE2LTE2aDM1MmM4LjgsMCwxNiw3LjIsMTYsMTYNCglWNDE2eiIvPg0KPGc+DQoJPHBhdGggc3R5bGU9ImZpbGw6I0ZGRkZGRjsiIGQ9Ik0xMDEuNzQ0LDMwMy4xNTJjMC00LjIyNCwzLjMyOC04LjgzMiw4LjY4OC04LjgzMmgyOS41NTJjMTYuNjQsMCwzMS42MTYsMTEuMTM2LDMxLjYxNiwzMi40OA0KCQljMCwyMC4yMjQtMTQuOTc2LDMxLjQ4OC0zMS42MTYsMzEuNDg4aC0yMS4zNnYxNi44OTZjMCw1LjYzMi0zLjU4NCw4LjgxNi04LjE5Miw4LjgxNmMtNC4yMjQsMC04LjY4OC0zLjE4NC04LjY4OC04LjgxNlYzMDMuMTUyeg0KCQkgTTExOC42MjQsMzEwLjQzMnYzMS44NzJoMjEuMzZjOC41NzYsMCwxNS4zNi03LjU2OCwxNS4zNi0xNS41MDRjMC04Ljk0NC02Ljc4NC0xNi4zNjgtMTUuMzYtMTYuMzY4SDExOC42MjR6Ii8+DQoJPHBhdGggc3R5bGU9ImZpbGw6I0ZGRkZGRjsiIGQ9Ik0xOTYuNjU2LDM4NGMtNC4yMjQsMC04LjgzMi0yLjMwNC04LjgzMi03Ljkydi03Mi42NzJjMC00LjU5Miw0LjYwOC03LjkzNiw4LjgzMi03LjkzNmgyOS4yOTYNCgkJYzU4LjQ2NCwwLDU3LjE4NCw4OC41MjgsMS4xNTIsODguNTI4SDE5Ni42NTZ6IE0yMDQuNzIsMzExLjA4OFYzNjguNGgyMS4yMzJjMzQuNTQ0LDAsMzYuMDgtNTcuMzEyLDAtNTcuMzEySDIwNC43MnoiLz4NCgk8cGF0aCBzdHlsZT0iZmlsbDojRkZGRkZGOyIgZD0iTTMwMy44NzIsMzEyLjExMnYyMC4zMzZoMzIuNjI0YzQuNjA4LDAsOS4yMTYsNC42MDgsOS4yMTYsOS4wNzJjMCw0LjIyNC00LjYwOCw3LjY4LTkuMjE2LDcuNjgNCgkJaC0zMi42MjR2MjYuODY0YzAsNC40OC0zLjE4NCw3LjkyLTcuNjY0LDcuOTJjLTUuNjMyLDAtOS4wNzItMy40NC05LjA3Mi03Ljkydi03Mi42NzJjMC00LjU5MiwzLjQ1Ni03LjkzNiw5LjA3Mi03LjkzNmg0NC45MTINCgkJYzUuNjMyLDAsOC45NiwzLjM0NCw4Ljk2LDcuOTM2YzAsNC4wOTYtMy4zMjgsOC43MDQtOC45Niw4LjcwNGgtMzcuMjQ4VjMxMi4xMTJ6Ii8+DQo8L2c+DQo8cGF0aCBzdHlsZT0iZmlsbDojQ0FEMUQ4OyIgZD0iTTQwMCw0MzJIOTZ2MTZoMzA0YzguOCwwLDE2LTcuMiwxNi0xNnYtMTZDNDE2LDQyNC44LDQwOC44LDQzMiw0MDAsNDMyeiIvPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPC9zdmc+DQo=\"); }\n  .docx .file__title:before {\n  content: url(\"data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCINCgkgdmlld0JveD0iMCAwIDUxMiA1MTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUxMiA1MTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxwb2x5Z29uIHN0eWxlPSJmaWxsOiNFMkUyRTI7IiBwb2ludHM9IjMzOC44NTYsMCA0NDUuODgsMTA3LjAyNCA0NDUuODgsNTEyIDU5LjI0LDUxMiA1OS4yNCwwICIvPg0KPHBvbHlnb24gc3R5bGU9ImZpbGw6Izk5OTk5OTsiIHBvaW50cz0iNDQ1Ljg4LDEwNy4wMjQgMzM4Ljg0LDEwNy4wMjQgMzM4Ljg0LDAgIi8+DQo8cG9seWdvbiBzdHlsZT0iZmlsbDojMzMzMzMzOyIgcG9pbnRzPSI0MDcuNTI4LDQyMi44OTYgMjIuMDQsNDIyLjg5NiAyMi4wNCwyOTMuMDA4IDQ4OS45NiwyOTMuMDA4ICIvPg0KPHBvbHlnb24gc3R5bGU9ImZpbGw6Izk5OTk5OTsiIHBvaW50cz0iNTkuMjQsNDYwLjA4IDU5LjI0LDQyMi44OTYgMjIuMDQsNDIyLjg5NiAiLz4NCjxnPg0KCTxwYXRoIHN0eWxlPSJmaWxsOiNGRkZGRkY7IiBkPSJNODcuODY0LDM5NS40NTZWMzIwLjhoMzYuNzA0YzEwLjQxNiwwLDE3LjcxMiwyLjI4OCwyMS44ODgsNi44NDgNCgkJYzQuMTkyLDQuNTYsNi4yNzIsMTIuNTQ0LDYuMjcyLDIzLjk1MmMwLDE4LjYyNC0xLjY2NCwzMC41OTItNS4wMjQsMzUuOTA0Yy0zLjM0NCw1LjI5Ni0xMC45MjgsNy45NTItMjIuNjg4LDcuOTUyTDg3Ljg2NCwzOTUuNDU2DQoJCUw4Ny44NjQsMzk1LjQ1NnogTTEwMi4wNCwzODMuNTM2aDIwLjE3NmM2Ljc4NCwwLDExLjE2OC0xLjU2OCwxMy4xNTItNC42NzJjMS45ODQtMy4xMiwyLjk5Mi0xMCwyLjk5Mi0yMC42NTYNCgkJYzAtMTEuMDA4LTAuODk2LTE4LTIuNjg4LTIwLjk5MmMtMS43NzYtMi45OTItNS45NjgtNC40NjQtMTIuNTc2LTQuNDY0SDEwMi4wNFYzODMuNTM2eiIvPg0KCTxwYXRoIHN0eWxlPSJmaWxsOiNGRkZGRkY7IiBkPSJNMTk0LjA3MiwzMjAuMTQ0YzEzLjU2OCwwLDIyLjMwNCwyLjI3MiwyNi4yMDgsNi43NjhjMy44ODgsNC40OTYsNS44NCwxNC41NzYsNS44NCwzMC4yMDgNCgkJYzAsMTcuMTA0LTEuOTUyLDI3Ljg3Mi01Ljg3MiwzMi4zMzZjLTMuOTIsNC40NjQtMTMuNDA4LDYuNjcyLTI4LjQ2NCw2LjY3MmMtMTMuNTY4LDAtMjIuMzM2LTIuMjA4LTI2LjMwNC02LjU5Mg0KCQljLTMuOTg0LTQuMzg0LTUuOTY4LTE0LjA2NC01Ljk2OC0yOC45OTJjMC0xNy43OTIsMS45NTItMjguOTc2LDUuODU2LTMzLjUzNkMxNjkuMjU2LDMyMi40MTYsMTc4Ljg0LDMyMC4xNDQsMTk0LjA3MiwzMjAuMTQ0eg0KCQkgTTE5Mi45NjgsMzMyLjMwNGMtOS41MiwwLTE1LjA3MiwxLjIxNi0xNi42NzIsMy42NjRjLTEuNjE2LDIuNDMyLTIuNCwxMC45MTItMi40LDI1LjM3NmMwLDEwLjcyLDAuOTQ0LDE3LjE2OCwyLjgxNiwxOS4zNg0KCQljMS44NzIsMi4xOTIsNy40MDgsMy4yOCwxNi41OTIsMy4yOGM4LjgsMCwxNC4wNjQtMS4yMzIsMTUuODA4LTMuNjhjMS43NDQtMi40NjQsMi42MjQtOS45MiwyLjYyNC0yMi4zODQNCgkJYzAtMTIuNTEyLTAuODMyLTE5LjkwNC0yLjQ4LTIyLjE5MkMyMDcuNTkyLDMzMy40MjQsMjAyLjE2OCwzMzIuMzA0LDE5Mi45NjgsMzMyLjMwNHoiLz4NCgk8cGF0aCBzdHlsZT0iZmlsbDojRkZGRkZGOyIgZD0iTTI4MS43NjgsMzY4LjgzMmgxNC4yMjR2Mi41NmMwLDEwLjM4NC0xLjg3MiwxNy4xMDQtNS42OCwyMC4xNmMtMy43NzYsMy4wNC0xMi4xNiw0LjU2LTI1LjE1Miw0LjU2DQoJCWMtMTQuNzA0LDAtMjMuNzYtMi40LTI3LjE1Mi03LjIxNnMtNS4wODgtMTcuNjgtNS4wODgtMzguNjA4YzAtMTIuMzM2LDIuMzA0LTIwLjQxNiw2Ljg5Ni0yNC4zMg0KCQljNC41OTItMy44NzIsMTQuMjA4LTUuODI0LDI4LjgzMi01LjgyNGMxMC42MjQsMCwxNy43NDQsMS42MTYsMjEuMzEyLDQuOGMzLjYsMy4xODQsNS4zNzYsOS41Miw1LjM3NiwxOS4wMDhsMC4wMzIsMS42OTZoLTE0LjIyNA0KCQl2LTEuOTJjMC00Ljg5Ni0wLjkxMi04LjAxNi0yLjc1Mi05LjM3NmMtMS44NC0xLjM3Ni02LjAzMi0yLjA0OC0xMi41OTItMi4wNDhjLTguOCwwLTE0LjA2NCwxLjA1Ni0xNS44MjQsMy4yMTYNCgkJYy0xLjc3NiwyLjE2LTIuNjU2LDguNTI4LTIuNjU2LDE5LjEzNmMwLDE0LjMwNCwwLjgsMjIuNzUyLDIuMzY4LDI1LjM3NmMxLjYsMi42MjQsNi43MDQsMy45MzYsMTUuMzkyLDMuOTM2DQoJCWM3LjAyNCwwLDExLjYtMC43MzYsMTMuNjgtMi4xOTJzMy4xNTItNC42NzIsMy4xNTItOS42MzJMMjgxLjc2OCwzNjguODMyeiIvPg0KCTxwYXRoIHN0eWxlPSJmaWxsOiNGRkZGRkY7IiBkPSJNMzY3LjgxNiwzMjAuOEwzNDUuNCwzNTYuOTZsMjMuOTA0LDM4LjQ5NkgzNTIuNjhsLTEwLjcyLTE3LjkzNg0KCQljLTEuNjY0LTIuNzY4LTMuMjE2LTUuNTg0LTQuNzItOC40MTZsLTEuNTM2LTIuOTZsLTEuNTg0LTIuOTEyaC0wLjIyNGwtMS41ODQsMi45NzZjLTEuOTA0LDMuNTY4LTQuMDY0LDcuMzQ0LTYuNDY0LDExLjMxMg0KCQlsLTEwLjc2OCwxNy45MzZoLTE3LjA1NmwyNC40OTYtMzguNDk2bC0yMi43NTItMzYuMTZoMTYuODk2bDkuOTY4LDE2LjYyNGMxLjU2OCwyLjYyNCwzLjAyNCw1LjIxNiw0LjQxNiw3Ljc3NmwxLjM2LDIuNjI0DQoJCWwxLjM3NiwyLjYyNGgwLjIyNGMwLjYyNC0xLjE2OCwxLjA3Mi0yLjA0OCwxLjM3Ni0yLjYyNGwxLjM2LTIuNTc2YzEuMTY4LTIuMjcyLDIuNjI0LTQuODQ4LDQuMzY4LTcuNzZsOS45NTItMTYuNjg4DQoJCUwzNjcuODE2LDMyMC44TDM2Ny44MTYsMzIwLjh6Ii8+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8L3N2Zz4NCg==\"); }\n  .xlsx .file__title:before {\n  content: url(\"data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCINCgkgdmlld0JveD0iMCAwIDUxMiA1MTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUxMiA1MTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNNDM5LjY1OCw5MS4yMUwzNTEuNDM1LDIuOTg3QzM0OS41MjIsMS4wNzUsMzQ2LjkyOCwwLDM0NC4yMjMsMEg3OS41NTRjLTUuNjMzLDAtMTAuMTk5LDQuNTY2LTEwLjE5OSwxMC4xOTl2NDkxLjYwMg0KCQkJYzAsNS42MzMsNC41NjYsMTAuMTk5LDEwLjE5OSwxMC4xOTloMzUyLjg5MmM1LjYzMiwwLDEwLjE5OS00LjU2NiwxMC4xOTktMTAuMTk5Vjk4LjQyMg0KCQkJQzQ0Mi42NDUsOTUuNzE3LDQ0MS41Nyw5My4xMjMsNDM5LjY1OCw5MS4yMXogTTM1NC40MjIsMzQuODIzbDUzLjQwMSw1My40aC01My40MDFWMzQuODIzeiBNNDIyLjI0Nyw0OTEuNjAySDg5Ljc1M1YyMC4zOTgNCgkJCWgyNDQuMjcxdjc4LjAyNGMwLDUuNjMzLDQuNTY3LDEwLjE5OSwxMC4xOTksMTAuMTk5aDc4LjAyNFY0OTEuNjAyeiIvPg0KCTwvZz4NCjwvZz4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNMjgyLjAxMiw0NTQuODg0SDExOS4zMzFjLTUuNjMzLDAtMTAuMTk5LDQuNTY2LTEwLjE5OSwxMC4xOTlzNC41NjYsMTAuMTk5LDEwLjE5OSwxMC4xOTloMTYyLjY4MQ0KCQkJYzUuNjMyLDAsMTAuMTk5LTQuNTY2LDEwLjE5OS0xMC4xOTlTMjg3LjY0NCw0NTQuODg0LDI4Mi4wMTIsNDU0Ljg4NHoiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCgk8Zz4NCgkJPHBhdGggZD0iTTMzNC4wMjYsNDU0Ljg4NGgtMTEuMDY3Yy01LjYzMiwwLTEwLjE5OSw0LjU2Ni0xMC4xOTksMTAuMTk5czQuNTY3LDEwLjE5OSwxMC4xOTksMTAuMTk5aDExLjA2Nw0KCQkJYzUuNjMyLDAsMTAuMTk5LTQuNTY2LDEwLjE5OS0xMC4xOTlTMzM5LjY1OCw0NTQuODg0LDMzNC4wMjYsNDU0Ljg4NHoiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCgk8Zz4NCgkJPHBhdGggZD0iTTMxMS42LDI2My4xMzlsNzUuNzM3LTkzLjUzNGMyLjQ3My0zLjA1NiwyLjk3Mi03LjI2MSwxLjI3OC0xMC44MDljLTEuNjkyLTMuNTQ5LTUuMjc0LTUuODA4LTkuMjA1LTUuODA4aC04NC45NTINCgkJCWMtMy4wNzgsMC01Ljk5LDEuMzg5LTcuOTI2LDMuNzgxTDI1NiwxOTQuNDc1bC0zMC41MzItMzcuNzA2Yy0xLjkzNi0yLjM5Mi00Ljg0OS0zLjc4MS03LjkyNi0zLjc4MUgxMzIuNTkNCgkJCWMtMy45MzEsMC03LjUxMywyLjI1OS05LjIwNiw1LjgwOGMtMS42OTMsMy41NDgtMS4xOTQsNy43NTQsMS4yNzksMTAuODA5bDc1LjczNyw5My41MzRsLTc1LjczNyw5My41MzQNCgkJCWMtMi40NzQsMy4wNTYtMi45NzIsNy4yNjEtMS4yNzksMTAuODA5YzEuNjkzLDMuNTQ4LDUuMjc0LDUuODA4LDkuMjA2LDUuODA4aDg0Ljk1MmMzLjA3NywwLDUuOTktMS4zODksNy45MjYtMy43ODFMMjU2LDMzMS44MDQNCgkJCWwzMC41MzEsMzcuNzA2YzEuOTM2LDIuMzkyLDQuODQ5LDMuNzgxLDcuOTI2LDMuNzgxaDg0Ljk1M2MzLjkzMSwwLDcuNTEzLTIuMjU5LDkuMjA1LTUuODA4DQoJCQljMS42OTMtMy41NDgsMS4xOTUtNy43NTQtMS4yNzktMTAuODA5TDMxMS42LDI2My4xMzl6IE0yOTkuMzIzLDE3My4zODZoNTguNzA2bC01OS41NTMsNzMuNTQ1bC0yOS4zNTItMzYuMjVMMjk5LjMyMywxNzMuMzg2eg0KCQkJIE0yMTIuNjc3LDM1Mi44OTJoLTU4LjcwNmw1OS41NTItNzMuNTQ1bDI5LjM1MiwzNi4yNUwyMTIuNjc3LDM1Mi44OTJ6IE0yOTkuMzIzLDM1Mi44OTJMMTUzLjk3MSwxNzMuMzg2aDU4LjcwNmwxNDUuMzUxLDE3OS41MDYNCgkJCUgyOTkuMzIzeiIvPg0KCTwvZz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjwvc3ZnPg0K\"); }\n  .zip .file__title:before {\n  content: url(\"data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE4LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPCFET0NUWVBFIHN2ZyBQVUJMSUMgIi0vL1czQy8vRFREIFNWRyAxLjEvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkIj4NCjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCINCgkgdmlld0JveD0iMCAwIDU2IDU2IiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA1NiA1NjsiIHhtbDpzcGFjZT0icHJlc2VydmUiPg0KPGc+DQoJPHBhdGggc3R5bGU9ImZpbGw6I0U5RTlFMDsiIGQ9Ik0zNi45ODUsMEg3Ljk2M0M3LjE1NSwwLDYuNSwwLjY1NSw2LjUsMS45MjZWNTVjMCwwLjM0NSwwLjY1NSwxLDEuNDYzLDFoNDAuMDc0DQoJCWMwLjgwOCwwLDEuNDYzLTAuNjU1LDEuNDYzLTFWMTIuOTc4YzAtMC42OTYtMC4wOTMtMC45Mi0wLjI1Ny0xLjA4NUwzNy42MDcsMC4yNTdDMzcuNDQyLDAuMDkzLDM3LjIxOCwwLDM2Ljk4NSwweiIvPg0KCTxwb2x5Z29uIHN0eWxlPSJmaWxsOiNEOUQ3Q0E7IiBwb2ludHM9IjM3LjUsMC4xNTEgMzcuNSwxMiA0OS4zNDksMTIgCSIvPg0KCTxwYXRoIHN0eWxlPSJmaWxsOiM1NTYwODA7IiBkPSJNNDguMDM3LDU2SDcuOTYzQzcuMTU1LDU2LDYuNSw1NS4zNDUsNi41LDU0LjUzN1YzOWg0M3YxNS41MzdDNDkuNSw1NS4zNDUsNDguODQ1LDU2LDQ4LjAzNyw1NnoiLz4NCgk8Zz4NCgkJPHBhdGggc3R5bGU9ImZpbGw6I0ZGRkZGRjsiIGQ9Ik0yNS4yNjYsNDIuOTI0djEuMzI2bC00Ljc5OSw3LjIwNWwtMC4yNzMsMC4yMTloNS4wNzJWNTNoLTYuNjk5di0xLjMyNmw0Ljc5OS03LjIwNWwwLjI4Ny0wLjIxOQ0KCQkJaC01LjA4NnYtMS4zMjZIMjUuMjY2eiIvPg0KCQk8cGF0aCBzdHlsZT0iZmlsbDojRkZGRkZGOyIgZD0iTTI5LjI3MSw1M2gtMS42NjhWNDIuOTI0aDEuNjY4VjUzeiIvPg0KCQk8cGF0aCBzdHlsZT0iZmlsbDojRkZGRkZGOyIgZD0iTTMzLjQxNCw1M2gtMS42NDFWNDIuOTI0aDIuODk4YzAuNDI4LDAsMC44NTIsMC4wNjgsMS4yNzEsMC4yMDUNCgkJCWMwLjQxOSwwLjEzNywwLjc5NSwwLjM0MiwxLjEyOCwwLjYxNWMwLjMzMywwLjI3MywwLjYwMiwwLjYwNCwwLjgwNywwLjk5MXMwLjMwOCwwLjgyMiwwLjMwOCwxLjMwNg0KCQkJYzAsMC41MTEtMC4wODcsMC45NzMtMC4yNiwxLjM4OGMtMC4xNzMsMC40MTUtMC40MTUsMC43NjQtMC43MjUsMS4wNDZjLTAuMzEsMC4yODItMC42ODQsMC41MDEtMS4xMjEsMC42NTYNCgkJCXMtMC45MjEsMC4yMzItMS40NDksMC4yMzJoLTEuMjE3VjUzeiBNMzMuNDE0LDQ0LjE2OHYzLjk5MmgxLjUwNGMwLjIsMCwwLjM5OC0wLjAzNCwwLjU5NS0wLjEwMw0KCQkJYzAuMTk2LTAuMDY4LDAuMzc2LTAuMTgsMC41NC0wLjMzNXMwLjI5Ni0wLjM3MSwwLjM5Ni0wLjY0OWMwLjEtMC4yNzgsMC4xNS0wLjYyMiwwLjE1LTEuMDMyYzAtMC4xNjQtMC4wMjMtMC4zNTQtMC4wNjgtMC41NjcNCgkJCWMtMC4wNDYtMC4yMTQtMC4xMzktMC40MTktMC4yOC0wLjYxNWMtMC4xNDItMC4xOTYtMC4zNC0wLjM2LTAuNTk1LTAuNDkyYy0wLjI1NS0wLjEzMi0wLjU5My0wLjE5OC0xLjAxMi0wLjE5OEgzMy40MTR6Ii8+DQoJPC9nPg0KCTxnPg0KCQk8cGF0aCBzdHlsZT0iZmlsbDojQzhCREI4OyIgZD0iTTI4LjUsMjR2LTJoMnYtMmgtMnYtMmgydi0yaC0ydi0yaDJ2LTJoLTJ2LTJoMlY4aC0yVjZoLTJ2MmgtMnYyaDJ2MmgtMnYyaDJ2MmgtMnYyaDJ2MmgtMnYyaDJ2Mg0KCQkJaC00djVjMCwyLjc1NywyLjI0Myw1LDUsNXM1LTIuMjQzLDUtNXYtNUgyOC41eiBNMzAuNSwyOWMwLDEuNjU0LTEuMzQ2LDMtMywzcy0zLTEuMzQ2LTMtM3YtM2g2VjI5eiIvPg0KCQk8cGF0aCBzdHlsZT0iZmlsbDojQzhCREI4OyIgZD0iTTI2LjUsMzBoMmMwLjU1MiwwLDEtMC40NDcsMS0xcy0wLjQ0OC0xLTEtMWgtMmMtMC41NTIsMC0xLDAuNDQ3LTEsMVMyNS45NDgsMzAsMjYuNSwzMHoiLz4NCgk8L2c+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8L3N2Zz4NCg==\"); }\n  .texts .file__title:before {\n  content: url(\"data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB2aWV3Qm94PSIwIDAgNTggNTgiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDU4IDU4OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+DQo8cG9seWdvbiBzdHlsZT0iZmlsbDojRURFQURBOyIgcG9pbnRzPSI1MS41LDE0IDM3LjUsMCA2LjUsMCA2LjUsNTggNTEuNSw1OCAiLz4NCjxnPg0KCTxwYXRoIHN0eWxlPSJmaWxsOiNDRUM5QUU7IiBkPSJNMTYuNSwyM2gyNWMwLjU1MiwwLDEtMC40NDcsMS0xcy0wLjQ0OC0xLTEtMWgtMjVjLTAuNTUyLDAtMSwwLjQ0Ny0xLDFTMTUuOTQ4LDIzLDE2LjUsMjN6Ii8+DQoJPHBhdGggc3R5bGU9ImZpbGw6I0NFQzlBRTsiIGQ9Ik0xNi41LDE1aDEwYzAuNTUyLDAsMS0wLjQ0NywxLTFzLTAuNDQ4LTEtMS0xaC0xMGMtMC41NTIsMC0xLDAuNDQ3LTEsMVMxNS45NDgsMTUsMTYuNSwxNXoiLz4NCgk8cGF0aCBzdHlsZT0iZmlsbDojQ0VDOUFFOyIgZD0iTTQxLjUsMjloLTI1Yy0wLjU1MiwwLTEsMC40NDctMSwxczAuNDQ4LDEsMSwxaDI1YzAuNTUyLDAsMS0wLjQ0NywxLTFTNDIuMDUyLDI5LDQxLjUsMjl6Ii8+DQoJPHBhdGggc3R5bGU9ImZpbGw6I0NFQzlBRTsiIGQ9Ik00MS41LDM3aC0yNWMtMC41NTIsMC0xLDAuNDQ3LTEsMXMwLjQ0OCwxLDEsMWgyNWMwLjU1MiwwLDEtMC40NDcsMS0xUzQyLjA1MiwzNyw0MS41LDM3eiIvPg0KCTxwYXRoIHN0eWxlPSJmaWxsOiNDRUM5QUU7IiBkPSJNNDEuNSw0NWgtMjVjLTAuNTUyLDAtMSwwLjQ0Ny0xLDFzMC40NDgsMSwxLDFoMjVjMC41NTIsMCwxLTAuNDQ3LDEtMVM0Mi4wNTIsNDUsNDEuNSw0NXoiLz4NCjwvZz4NCjxwb2x5Z29uIHN0eWxlPSJmaWxsOiNDRUM5QUU7IiBwb2ludHM9IjM3LjUsMCAzNy41LDE0IDUxLjUsMTQgIi8+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8L3N2Zz4NCg==\"); }\n  /* \r\n============================================================================================\r\n================================== REjected Grid View ==================================\r\n============================================================================================\r\n*/\n  /* \r\n.file {\r\n    cursor: pointer;\r\n    width: calc(15% - 30px);\r\n    border-radius: 10px;\r\n    background-color: #fff;\r\n    box-shadow: 0px 9px 10px -2px rgba(0, 0, 0, 0.2);\r\n    border: 1px solid rgba(0, 0, 0, 0.07);\r\n    float: left;\r\n    margin-left: 15px;\r\n    transition: all 0.3s;\r\n    -webkit-transition: all 0.3s;\r\n    -moz-transition: all 0.3s;\r\n    -ms-transition: all 0.3s;\r\n    -o-transition: all 0.3s;\r\n    margin-bottom: 30px;\r\n}\r\n\r\n.file:hover {\r\n    transform: translate(0, -4px);\r\n    box-shadow: 0px 17px 19px -2px rgba(0, 0, 0, 0.2);\r\n}\r\n\r\n.file__img {\r\n    width: 100%;\r\n    height: 0;\r\n    padding-bottom: 35%;\r\n    margin-top: 5%;\r\n    background-repeat: no-repeat;\r\n    background-size: contain;\r\n    background-position: center;\r\n    border-top-right-radius: 10px;\r\n    border-top-left-radius: 10px;\r\n}\r\n\r\n.file__title {\r\n    font-size: 14px;\r\n    margin-bottom: 5px;\r\n    margin-top: 0px;\r\n    font-weight: 600;\r\n    color: #252a3b;\r\n    text-overflow: ellipsis;\r\n    white-space: nowrap;\r\n    overflow: hidden;\r\n    line-height: 18px;\r\n}\r\n\r\n.file__title:before {\r\n    width: 16px;\r\n    position: absolute;\r\n    left: 14px;\r\n    top: 22px;\r\n}\r\n\r\n.file__date {\r\n    font-size: 13px;\r\n    color: #8087a2;\r\n    font-weight: 500;\r\n}\r\n\r\n.file__info {\r\n    padding: 21px 5px 10px 35px;\r\n    position: relative;\r\n}\r\n*/\n  /* \r\n============================================================================================\r\n================================== Responsiveness Handles ==================================\r\n============================================================================================\r\n*/\n  @media screen and (max-width: 767px) {\n  .file {\n    margin-left: 15px;\n    margin-bottom: 15px;\n    width: calc(10% - 15px); }\n  .file__info {\n    padding: 21px 5px 10px 35px; }\n  .file__date {\n    font-size: 12px; }\n  .file__title {\n    font-size: 13px;\n    margin-bottom: 0;\n    line-height: 20px; }\n  .file__title:before {\n    left: 10px;\n    top: 14px; }\n  .center-content {\n    padding-left: 0; }\n  .search--width {\n    width: 100%;\n    height: 40px;\n    font-size: 11px; }\n  .top-nav {\n    padding: 15px; }\n  .row--no-right {\n    margin: 0 0px 0 15px; }\n  .files-cont {\n    padding: 0px 0px 0 20px; }\n  .row__title-box {\n    padding-left: 30px;\n    margin-bottom: 15px;\n    margin-top: 15px; }\n  .row__title {\n    font-size: 20px; } }\n  @media screen and (max-width: 640px) {\n  .row__title {\n    font-size: 18px; }\n  .row__title-box {\n    padding-left: 15px;\n    margin-bottom: 20px;\n    margin-top: 20px; }\n  .file {\n    margin-left: 15px;\n    margin-bottom: 15px;\n    width: calc(33.3% - 15px); }\n  .file__date {\n    font-size: 11px; }\n  .file__title {\n    font-size: 12px;\n    margin-bottom: 0;\n    line-height: 20px; }\n  .file--last {\n    display: none; } }\n  @media screen and (max-width: 480px) {\n  .file {\n    margin-left: 15px;\n    margin-bottom: 15px;\n    width: calc(50% - 15px); }\n  .file--last {\n    display: block; } }\n  @media screen and (max-width: 360px) {\n  .file {\n    margin-left: 0;\n    margin-bottom: 20px;\n    width: 100%; }\n  .row--no-right {\n    margin: 0; }\n  .row__title-box {\n    padding-left: 0; }\n  .row__title {\n    font-size: 16px; } }\n"

/***/ }),

/***/ "./src/app/components/course-module/file-manager/file-card/file-card.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export File */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FileCardComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__file_manager_service__ = __webpack_require__("./src/app/components/course-module/file-manager/file-manager.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_rxjs_Rx__ = __webpack_require__("./node_modules/rxjs/_esm5/Rx.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_platform_browser__ = __webpack_require__("./node_modules/@angular/platform-browser/esm5/platform-browser.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_http_service__ = __webpack_require__("./src/app/services/http.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var File = /** @class */ (function () {
    function File(name, type, res) {
        this.name = name;
        this.type = type;
        this.res = res;
    }
    return File;
}());

var FileCardComponent = /** @class */ (function () {
    function FileCardComponent(cd, fileService, appC, _http, sanitizer) {
        this.cd = cd;
        this.fileService = fileService;
        this.appC = appC;
        this._http = _http;
        this.sanitizer = sanitizer;
        // global variables
        this.jsonFlag = {
            isRippleLoad: false,
        };
        this.draggedover = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"](null);
        this.draggedleave = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"](null);
        this.fileid = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.status = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.filePath = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.fileDisplayArr = [];
        this.selectedFolder = [];
        this.getPopupValue = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.getPopupValueOpen = true;
        this.fileArr = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.shareOptions = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.dwnldLink = "";
        this.arr = [];
        this.downloadStatus = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
    }
    FileCardComponent.prototype.ngOnChanges = function () {
        this.generateFile(this.data);
    };
    FileCardComponent.prototype.ngOnInit = function () {
    };
    FileCardComponent.prototype.generateFile = function (data) {
        if (data.data.category_id == "182") {
            data.data.category_name = "Study Material";
        }
        var name = data.label.split(".")[0];
        var type = data.label.split(".")[1];
        this.fileObj = new File(name, type, data.data);
        this.setImageAndIcons(type);
        this.cd.detectChanges();
        this.cd.detach();
    };
    FileCardComponent.prototype.setImageAndIcons = function (type) {
        /* Document File */
        if (type === "doc" || type === "docx") {
            this.fileHeader.nativeElement.classList.add("docx");
            this.fileHeader.nativeElement.classList.add("doc-file");
        }
        else if (type === 'pdf') {
            this.fileHeader.nativeElement.classList.add("pdf");
            this.fileHeader.nativeElement.classList.add("pdf-file");
        }
        else if (type === 'xls' || type === "xlsx" || type === "csv") {
            this.fileHeader.nativeElement.classList.add("xlsx");
            this.fileHeader.nativeElement.classList.add("xlsx-file");
        }
        else if (type === 'txt' || type === "rtf") {
            this.fileHeader.nativeElement.classList.add("texts");
            this.fileHeader.nativeElement.classList.add("text-file");
        }
        else if (type === 'jpg' || type === 'jpeg' || type === 'png' || type == "bmp" || type === "tif") {
            this.fileHeader.nativeElement.classList.add("image");
            this.fileHeader.nativeElement.classList.add("image-file");
        }
        else if (type === 'mp4' || type === 'flv' || type === 'wmv' || type === 'mov') {
            this.fileHeader.nativeElement.classList.add("video");
            this.fileHeader.nativeElement.classList.add("video-file");
        }
        else if (type === 'ppt' || type === 'pptx') {
            this.fileHeader.nativeElement.classList.add("texts");
            this.fileHeader.nativeElement.classList.add("file-file");
        }
        else if (type === 'mp3' || type === 'wav') {
            this.fileHeader.nativeElement.classList.add("audio");
            this.fileHeader.nativeElement.classList.add("audio-file");
        }
        else if (type === 'rar' || type === 'zip') {
            this.fileHeader.nativeElement.classList.add("zip");
            this.fileHeader.nativeElement.classList.add("zip-file");
        }
        else {
            this.fileHeader.nativeElement.classList.add("texts");
            this.fileHeader.nativeElement.classList.add(".file-file");
        }
    };
    FileCardComponent.prototype.onDragOver = function (event) {
        this.draggedover.emit(event);
        this.preventAndStop(event);
    };
    FileCardComponent.prototype.onDragLeave = function (event) {
        //this.draggedleave.emit(event);
        this.draggedover.emit(event);
        this.preventAndStop(event);
    };
    FileCardComponent.prototype.preventAndStop = function (event) {
        event.stopPropagation();
        event.preventDefault();
    };
    FileCardComponent.prototype.getFilesDeleted = function (event) {
        var _this = this;
        var getDeletedFiles = [{
                file_id: event.res.file_id,
                keyName: event.res.keyName
            }];
        if (confirm('Are you sure, you want to delete the file?')) {
            this.fileService.deleteFiles(getDeletedFiles).subscribe(function (data) {
                var msg = {
                    type: "success",
                    body: "File Deleted Successfully"
                };
                var path = getDeletedFiles[0].keyName.split('/');
                path.pop();
                var newPath = path.join('/');
                _this.filePath.emit(newPath);
                _this.appC.popToast(msg);
                _this.status.emit(data.statusCode);
            }, function (error) {
                var msg = {
                    type: 'error',
                    body: error.error.message
                };
                _this.appC.popToast(msg);
            });
        }
    };
    FileCardComponent.prototype.getPopupOpen = function (fileObj) {
        var shareOptions = {
            publicShare: fileObj.res.public_share,
            instituteShare: fileObj.res.inst_share,
            batchShare: fileObj.res.student_batch_share,
            isReadonly: fileObj.res.is_readonly,
            fileType: fileObj.type
        };
        if (shareOptions.publicShare == 0 && shareOptions.instituteShare == 0 && shareOptions.batchShare == 0) {
            this.shareOptions.emit("new");
            this.shareOptions.emit(shareOptions);
        }
        else {
            this.shareOptions.emit(shareOptions);
        }
        this.fileArr.emit(fileObj);
        this.fileid.emit(fileObj.res.file_id);
        this.getPopupValue.emit(this.getPopupValueOpen);
    };
    FileCardComponent.prototype.convertBase64ToArray = function (val) {
        var binary_string = window.btoa(encodeURI(val));
        var len = binary_string.length;
        var bytes = new Uint8Array(len);
        for (var i = 0; i < len; i++) {
            bytes[i] = binary_string.charCodeAt(i);
        }
        return bytes.buffer;
    };
    FileCardComponent.prototype.getFileDownloaded = function (fileObj) {
        var _this = this;
        var file_type = fileObj.type;
        var url = "/api/v1/instFileSystem/downloadFile/" + this.fileService.institute_id + "?fileId=" + fileObj.res.file_id;
        this.downloadStatus.emit(true);
        this._http.downloadItem(url, file_type).subscribe(function (response) {
            if (response) {
                var blob = new Blob([response], { type: file_type });
                _this.fileURL = _this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));
                if (_this.fileURL != null) {
                    setTimeout(function () {
                        var hiddenDownload = document.getElementById('downloadFileClick');
                        hiddenDownload.href = _this.fileURL.changingThisBreaksApplicationSecurity;
                        hiddenDownload.download = fileObj.res.file_name;
                        hiddenDownload.click();
                        _this.downloadStatus.emit(false);
                    }, 500);
                }
            }
        }, function (err) {
            _this.downloadStatus.emit(false);
            console.log(err);
        });
    };
    /**
     *
     * Method to get the original file name from filename(with autoID)
     *
     */
    FileCardComponent.prototype.getFileName = function (fileName) {
        return fileName.substring(0, fileName.lastIndexOf("_"));
    };
    FileCardComponent.prototype.getOriginalFileName = function (fileName) {
        var filenamePart1 = fileName.substring(0, fileName.lastIndexOf("_"));
        var filenamePart2 = fileName.substring(fileName.lastIndexOf("."));
        fileName = filenamePart1 + filenamePart2;
        return fileName;
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], FileCardComponent.prototype, "data", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], FileCardComponent.prototype, "draggedover", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], FileCardComponent.prototype, "draggedleave", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], FileCardComponent.prototype, "fileid", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])("fileHeader"),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], FileCardComponent.prototype, "fileHeader", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])("fileHeader"),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], FileCardComponent.prototype, "fileImage", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], FileCardComponent.prototype, "status", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], FileCardComponent.prototype, "filePath", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], FileCardComponent.prototype, "fileDisplayArr", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], FileCardComponent.prototype, "selectedFolder", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], FileCardComponent.prototype, "getPopupValue", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], FileCardComponent.prototype, "fileArr", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], FileCardComponent.prototype, "shareOptions", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], FileCardComponent.prototype, "downloadStatus", void 0);
    FileCardComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'file-card',
            template: __webpack_require__("./src/app/components/course-module/file-manager/file-card/file-card.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/file-manager/file-card/file-card.component.scss")],
            changeDetection: __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectionStrategy"].OnPush
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"],
            __WEBPACK_IMPORTED_MODULE_1__file_manager_service__["a" /* FileManagerService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_5__services_http_service__["a" /* HttpService */],
            __WEBPACK_IMPORTED_MODULE_4__angular_platform_browser__["DomSanitizer"]])
    ], FileCardComponent);
    return FileCardComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/file-manager/file-manager-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FileManagerRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__file_manager_component__ = __webpack_require__("./src/app/components/course-module/file-manager/file-manager.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__drive_home_drive_home_component__ = __webpack_require__("./src/app/components/course-module/file-manager/drive-home/drive-home.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var FileManagerRoutingModule = /** @class */ (function () {
    function FileManagerRoutingModule() {
    }
    FileManagerRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__file_manager_component__["a" /* FileManagerComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                redirectTo: 'drive'
                            },
                            {
                                path: 'drive',
                                component: __WEBPACK_IMPORTED_MODULE_3__drive_home_drive_home_component__["a" /* DriveHomeComponent */]
                            }
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], FileManagerRoutingModule);
    return FileManagerRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/file-manager/file-manager.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>"

/***/ }),

/***/ "./src/app/components/course-module/file-manager/file-manager.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/course-module/file-manager/file-manager.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FileManagerComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var FileManagerComponent = /** @class */ (function () {
    function FileManagerComponent() {
    }
    FileManagerComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'file-manager',
            template: __webpack_require__("./src/app/components/course-module/file-manager/file-manager.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/file-manager/file-manager.component.scss")]
        })
    ], FileManagerComponent);
    return FileManagerComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/file-manager/file-manager.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileManagerModule", function() { return FileManagerModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_primeng_fileupload__ = __webpack_require__("./node_modules/primeng/fileupload.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_primeng_fileupload___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_primeng_fileupload__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_hammerjs__ = __webpack_require__("./node_modules/hammerjs/hammer.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_hammerjs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_hammerjs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_primeng_tree__ = __webpack_require__("./node_modules/primeng/tree.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_primeng_tree___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8_primeng_tree__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__file_manager_component__ = __webpack_require__("./src/app/components/course-module/file-manager/file-manager.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__file_manager_routing_module__ = __webpack_require__("./src/app/components/course-module/file-manager/file-manager-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__drive_home_drive_home_component__ = __webpack_require__("./src/app/components/course-module/file-manager/drive-home/drive-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__file_card_file_card_component__ = __webpack_require__("./src/app/components/course-module/file-manager/file-card/file-card.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__file_manager_service__ = __webpack_require__("./src/app/components/course-module/file-manager/file-manager.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__upload_popup_upload_popup_component__ = __webpack_require__("./src/app/components/course-module/file-manager/upload-popup/upload-popup.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__share_file_share_file_component__ = __webpack_require__("./src/app/components/course-module/file-manager/share-file/share-file.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
















var FileManagerModule = /** @class */ (function () {
    function FileManagerModule() {
    }
    FileManagerModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_3__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_3__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_4_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_7__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_10__file_manager_routing_module__["a" /* FileManagerRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_8_primeng_tree__["TreeModule"],
                __WEBPACK_IMPORTED_MODULE_2_primeng_fileupload__["FileUploadModule"]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_9__file_manager_component__["a" /* FileManagerComponent */],
                __WEBPACK_IMPORTED_MODULE_11__drive_home_drive_home_component__["a" /* DriveHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_12__file_card_file_card_component__["a" /* FileCardComponent */],
                __WEBPACK_IMPORTED_MODULE_14__upload_popup_upload_popup_component__["a" /* UploadPopupComponent */],
                __WEBPACK_IMPORTED_MODULE_15__share_file_share_file_component__["a" /* ShareFileComponent */]
            ],
            entryComponents: [
                __WEBPACK_IMPORTED_MODULE_12__file_card_file_card_component__["a" /* FileCardComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_13__file_manager_service__["a" /* FileManagerService */]
            ]
        })
    ], FileManagerModule);
    return FileManagerModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/file-manager/file-manager.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FileManagerService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var FileManagerService = /** @class */ (function () {
    function FileManagerService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    FileManagerService.prototype.getAllFolderFiles = function (obj) {
        var url = this.baseUrl + "/api/v1/instFileSystem/getFolder";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService.prototype.getUsedSpace = function () {
        var url = this.baseUrl + "/api/v1/instFileSystem/getUsedSpace/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService.prototype.getCategories = function () {
        var url = this.baseUrl + "/api/v1/instFileSystem/categories";
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService.prototype.createFiles = function (obj) {
        var url = this.baseUrl + "/api/v1/instFileSystem/createFiles";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService.prototype.deleteFiles = function (obj) {
        var url = this.baseUrl + "/api/v1/instFileSystem/deleteFolder";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService.prototype.downloadFromAWS = function (url, file_id) {
        var ur = url + "/api/v1/instFileSystem/downloadFile/" + this.institute_id + "/?fileId=" + file_id;
        return this.http.get(ur, { headers: this.headers, responseType: 'text' }).map(function (res) { return res; }, function (err) { return err; });
    };
    FileManagerService.prototype.getAllStandards = function () {
        var url = this.baseUrl + "/api/v1/standards/all/" + this.institute_id + "?active=Y";
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService.prototype.getSubjects = function (obj) {
        var url = this.baseUrl + "/api/v1/subjects/standards/" + obj + "?active=Y";
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService.prototype.shareFileWithStudents = function (obj) {
        var url = this.baseUrl + "/api/v1/fileShare/students";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService.prototype.shareFileWithBatches = function (obj) {
        var url = this.baseUrl + "/api/v1/fileShare/batches";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService.prototype.shareFile = function (obj) {
        var url = this.baseUrl + "/api/v1/fileShare";
        return this.http.put(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService.prototype.editFileShare = function (obj) {
        var url = this.baseUrl + "/api/v1/fileShare";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService.prototype.courseMapping = function () {
        var url = this.baseUrl + "/api/v1/institute/courseMapping/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService.prototype.craeteFolder = function (obj) {
        var url = this.baseUrl + "/api/v1/instFileSystem/createFolder";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    FileManagerService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */], __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], FileManagerService);
    return FileManagerService;
}());



/***/ }),

/***/ "./src/app/components/course-module/file-manager/share-file/share-file.component.html":
/***/ (function(module, exports) {

module.exports = "<proctur-popup [sizeWidth]=\"'medium'\">\r\n  <span class=\"closePopup pos-abs fbold show\" close-button (click)=\"close()\">\r\n    <svg  class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n      <path  class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" style=\"fill: currentColor\"></path>\r\n    </svg>\r\n  </span>\r\n  <div popup-header class=\"popup-header-content\">\r\n    <div class=\"row\">\r\n      <div class=\"c-lg-5\">\r\n        <h2>\r\n          Share File\r\n        </h2>\r\n      </div>\r\n\r\n      <div class=\"c-lg-5\" style=\"float:right;\">\r\n        <div class=\"c-lg-12 \">\r\n          <span class=\"form-file\">File Name :\r\n          </span>\r\n          <span class=\"bold-font\">{{fileName.res.keyName}}</span>\r\n        </div>\r\n        <div class=\"c-lg-12\">\r\n          <span class=\"form-file\">Downloads :\r\n          </span>\r\n          <span class=\"bold-font\">{{fileName.res.downloads}}</span>\r\n        </div>\r\n        <div class=\"c-lg-12 \">\r\n          <span class=\"form-file\">\r\n            File Size :\r\n          </span>\r\n          <span class=\"bold-font\">{{fileName.res.size}} KB</span>\r\n        </div>\r\n        <div class=\"c-lg-12\">\r\n          <span class=\"form-file\">\r\n            Category :\r\n          </span>\r\n          <span class=\"bold-font\">{{fileName.res.category_name}}</span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <div popup-content class=\"popup-header-content\">\r\n\r\n    <input type=\"button\" id=\"tab1\" (click)=\"selectTab(1)\" style=\"display: inline-block; margin-top: 1%;\" class=\"btn\" value=\"Student\"\r\n      [disabled]=\"categoryId == '62'\">\r\n    <input type=\"button\" id=\"tab2\" (click)=\"selectTab(2)\" style=\"display: inline-block; margin-top: 1%;\" class=\"btn\" value=\"Public\">\r\n    <input type=\"button\" id=\"tab3\" (click)=\"selectTab(3)\" style=\"display: inline-block; margin-top: 1%;\" class=\"btn\" value=\"Institute\"\r\n      [disabled]=\"categoryId != '62'\">\r\n    <br/>\r\n    <div id=\"tab1Content\">\r\n      <div class=\"tab\">\r\n        <div class=\"row\">\r\n          <div class=\"c-lg-4 field-wrapper\">\r\n            <label class=\"forms\" *ngIf=\"isProfessional\">Master Course</label>\r\n            <label class=\"forms\" *ngIf=\"!isProfessional\">Standards</label>\r\n            <select class=\"form-ctrl\" [(ngModel)]=\"getStandardsId\" (ngModelChange)=\"getAllSubjects($event)\">\r\n              <option></option>\r\n              <option *ngFor=\"let i of getStandards\" [value]=\"i.standard_id\">\r\n                {{i.standard_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n          <div class=\"c-lg-4 field-wrapper\">\r\n            <label class=\"forms\" *ngIf=\"isProfessional\">Course</label>\r\n            <label class=\"forms\" *ngIf=\"!isProfessional\">Subjects</label>\r\n            <select class=\"form-ctrl\" [(ngModel)]=\"subjectId\" (ngModelChange)=\"getBatches()\">\r\n              <option></option>\r\n              <option *ngFor=\"let i of getSubjects\" [value]=\"i.subject_id\">\r\n                {{i.subject_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n          <div class=\"c-lg-4 field-wrapper\">\r\n            <label class=\"forms\">Comments</label>\r\n            <textarea class=\"form-ctrl\" style=\"height: auto;\" [(ngModel)]=\"fetchShareOption.desc\"></textarea>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div style=\"    border: 1px solid;\r\n      margin-left: 10px;\r\n      border-top: none;\r\n      width: 92%;\">\r\n        <div class=\"row\">\r\n          <div class=\"c-lg-2 field-radio-wrapper\" style=\"margin-top: 10px; margin-left: 26px;\">\r\n            <input type=\"radio\" class=\"form-radio\" name=\"common\" id=\"batch\" [(ngModel)]=\"getBatch\" (ngModelChange)=\"fetchCoursesData(subjectId , $event)\"\r\n              [value]=\"0\">\r\n            <label for=\"batch\">Batch Level</label>\r\n          </div>\r\n          <div class=\"c-lg-2 field-radio-wrapper\" style=\"margin-top: 10px; margin-left: 15px;\">\r\n            <input type=\"radio\" class=\"form-radio\" name=\"common\" id=\"student\" [(ngModel)]=\"getStudent\" (ngModelChange)=\"fetchCoursesData(subjectId , $event, editBatchShare)\"\r\n              [value]=\"1\">\r\n            <label for=\"student\">Student Level</label>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"table table-responsive table-ne\" style=\"margin-left: 24px;\r\n        max-width: 94%;\">\r\n          <table>\r\n            <thead *ngIf=\"batchesId\">\r\n              <tr>\r\n                <th style=\"text-align: left;\r\n                padding: 5px 0px 10px 5px;\">\r\n                  <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;\r\n                  margin-top: 5px;\r\n                  height: 16px;\r\n                  margin-right: 10px; margin-left: 15px;\">\r\n                    <input type=\"checkbox\" class=\"form-checkbox\" [(ngModel)]=\"isChecked\" (ngModelChange)=\"fileSharedBatches($event)\">\r\n                    <label></label>\r\n                  </div>\r\n                  Batch Name\r\n                </th>\r\n                <th style=\"text-align: left;\">\r\n                  Access Start Date\r\n                </th>\r\n                <th style=\"text-align: left;\">\r\n                  Access End Date\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <thead *ngIf=\"studentsId\">\r\n              <tr style=\"text-align: left;\r\n              padding: 5px 0px 10px 5px;\">\r\n                <th style=\"text-align: left; \">\r\n                  <div class=\"field-checkbox-wrapper\" style=\"display: inline-block;\r\n                  margin-top: 5px;\r\n                  height: 16px;\r\n                  margin-right: 10px; margin-left: 9px;\">\r\n                    <input type=\"checkbox\" class=\"form-checkbox\" [(ngModel)]=\"isStudentChecked\" (ngModelChange)=\"fileSharedStudents($event)\">\r\n                    <label></label>\r\n                  </div>\r\n                  Id\r\n                </th>\r\n                <th>\r\n                  Student Name\r\n                </th>\r\n                <th style=\"text-align: left;\">\r\n                  Access Start Date\r\n                </th>\r\n                <th style=\"text-align: left;\">\r\n                  Access End Date\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody *ngIf=\"batchesId && getBatchesData.length!=0\">\r\n              <tr *ngFor=\"let i of getBatchesData ; let j =index;\">\r\n                <td style=\"text-align: left; \">\r\n                  <div class=\"field-checkbox-wrapper\">\r\n                    <input type=\"checkbox\" class=\"form-checkbox\" [(ngModel)]=\"i.isChecked\" (ngModelChange)=\"getFileSharedBatches($event , j)\">\r\n                    <label></label>\r\n                  </div>\r\n                  {{i.batch_name}}\r\n\r\n                </td>\r\n                <td style=\"text-align: left; padding: 0px;\">\r\n                  <div class=\"field-wrapper datePickerBox\">\r\n                    <input type=\"text\" readonly=\"true\" class=\"form-ctrl\" bsDatepicker [(ngModel)]=\"i.file_access_start_time\">\r\n                  </div>\r\n                  <!-- <div class=\"row row-fix\">\r\n                    <div class=\"c-lg-12\">\r\n                      <div class=\"c-lg-3\">\r\n                        <label class=\"norm\">Date</label>\r\n                        <select style=\"border: 1px solid #efefef;\" [(ngModel)]=\"i.start_date\" (ngModelChange)=\"getStartDate($event , j)\">\r\n                          <option></option>\r\n                          <option *ngFor=\"let date of date\" [value]=\"date\">\r\n                            {{date}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                      <div class=\"c-lg-3\">\r\n                        <label class=\"norm\">Month</label>\r\n                        <select style=\"border: 1px solid #efefef;\" [(ngModel)]=\"i.start_month\" (ngModelChange)=\"getStartMonth($event  , j)\">\r\n                          <option></option>\r\n                          <option *ngFor=\"let month of month\" [value]=\"month\">\r\n                            {{month}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                      <div class=\"c-lg-5\">\r\n                        <label class=\"norm\">Year</label>\r\n                        <select style=\"border: 1px solid #efefef;\" [(ngModel)]=\"i.start_year\" (ngModelChange)=\"getStartYear($event  , j)\">\r\n                          <option></option>\r\n                          <option *ngFor=\"let year of year\" [value]=\"year\">\r\n                            {{year}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                  </div> -->\r\n                </td>\r\n                <td style=\"text-align: left; padding: 0px;\">\r\n                  <div class=\"field-wrapper datePickerBox\">\r\n                    <input type=\"text\" readonly=\"true\" class=\"form-ctrl\" bsDatepicker [(ngModel)]=\"i.file_access_end_time\">\r\n                  </div>\r\n                  <!-- <div class=\"row row-fix\">\r\n                    <div class=\"c-lg-12\">\r\n                      <div class=\"c-lg-3\">\r\n                        <label class=\"norm\">Date</label>\r\n                        <select style=\"border: 1px solid #efefef;\" [(ngModel)]=\"i.end_date\" (ngModelChange)=\"getEndDate($event  , j)\">\r\n                          <option></option>\r\n                          <option *ngFor=\"let year of date\" [value]=\"year\">\r\n                            {{year}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                      <div class=\"c-lg-3\">\r\n                        <label class=\"norm\">Month</label>\r\n                        <select style=\"border: 1px solid #efefef;\" [(ngModel)]=\"i.end_month\" (ngModelChange)=\"getEndMonth($event  , j)\">\r\n                          <option></option>\r\n                          <option *ngFor=\"let month of month\" [value]=\"month\">\r\n                            {{month}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                      <div class=\"c-lg-5\">\r\n                        <label class=\"norm\">Year</label>\r\n                        <select style=\"border: 1px solid #efefef;\" [(ngModel)]=\"i.end_year\" (ngModelChange)=\"getEndYear($event  , j)\">\r\n                          <option></option>\r\n                          <option *ngFor=\"let year of year\" [value]=\"year\">\r\n                            {{year}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                  </div> -->\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n            <tbody *ngIf=\"batchesId && getBatchesData.length==0 && dataStatus === false\">\r\n              <tr>\r\n                <td colspan=\"3\">No Records Found</td>\r\n              </tr>\r\n            </tbody>\r\n            <tbody *ngIf=\"batchesId && getBatchesData.length == 0 && dataStatus === true\">\r\n              <tr *ngFor=\"let dummy of dummyArr\">\r\n                <td *ngFor=\"let c of columnMaps\" style=\"padding:10px;\">\r\n                  <div class=\"skeleton\">\r\n                  </div>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n            <tbody *ngIf=\"studentsId && getStudentsData.length!=0\">\r\n              <tr *ngFor=\"let i of getStudentsData ; let j =index;\">\r\n                <td style=\"text-align: left; width:21%;\">\r\n                  <div class=\"field-checkbox-wrapper\">\r\n                    <input type=\"checkbox\" class=\"form-checkbox\" [(ngModel)]=\"i.isChecked\" (ngModelChange)=\"getFileSharedStudents($event , j)\">\r\n                    <label></label>\r\n                  </div>\r\n                  {{i.student_disp_id}}\r\n                </td>\r\n                <td>\r\n                  {{i.student_name}}\r\n                </td>\r\n                <td style=\"text-align: left; padding: 0px;\">\r\n                  <div class=\"field-wrapper datePickerBox\">\r\n                    <input type=\"text\" readonly=\"true\" class=\"form-ctrl\" bsDatepicker [(ngModel)]=\"i.file_access_start_time\">\r\n                  </div>\r\n                  <!-- <div class=\"row row-fix\">\r\n                    <div class=\"c-lg-12\">\r\n                      <div class=\"c-lg-3\">\r\n                        <label class=\"norm\">Date</label>\r\n                        <select style=\"border: 1px solid #efefef;\" [(ngModel)]=\"i.start_date\" (ngModelChange)=\"getStartDate($event , j)\">\r\n                          <option></option>\r\n                          <option *ngFor=\"let date of date\" [value]=\"date\">\r\n                            {{date}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                      <div class=\"c-lg-3\">\r\n                        <label class=\"norm\">Month</label>\r\n                        <select style=\"border: 1px solid #efefef;\" [(ngModel)]=\"i.start_month\" (ngModelChange)=\"getStartMonth($event , j)\">\r\n                          <option></option>\r\n                          <option *ngFor=\"let month of month\" [value]=\"month\">\r\n                            {{month}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                      <div class=\"c-lg-5\">\r\n                        <label class=\"norm\">Year</label>\r\n                        <select style=\"border: 1px solid #efefef;\" [(ngModel)]=\"i.start_year\" (ngModelChange)=\"getStartYear($event , j)\">\r\n                          <option></option>\r\n                          <option *ngFor=\"let year of year\" [value]=\"year\">\r\n                            {{year}}\r\n                          </option>\r\n\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                  </div> -->\r\n                </td>\r\n                <td style=\"text-align: left; padding: 0px;\">\r\n                  <div class=\"field-wrapper datePickerBox\">\r\n                    <input type=\"text\" readonly=\"true\" class=\"form-ctrl\" bsDatepicker [(ngModel)]=\"i.file_access_end_time\">\r\n                  </div>\r\n                  <!-- <div class=\"row row-fix\">\r\n                    <div class=\"c-lg-12\">\r\n                      <div class=\"c-lg-3\">\r\n                        <label class=\"norm\">Date</label>\r\n                        <select style=\"border: 1px solid #efefef;\" [(ngModel)]=\"i.end_date\" (ngModelChange)=\"getEndDate($event , j)\">\r\n                          <option></option>\r\n                          <option *ngFor=\"let date of date\" [value]=\"date\">\r\n                            {{date}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                      <div class=\"c-lg-3\">\r\n                        <label class=\"norm\">Month</label>\r\n                        <select style=\"border: 1px solid #efefef;\" [(ngModel)]=\"i.end_month\" (ngModelChange)=\"getEndMonth($event , j)\">\r\n\r\n                          <option></option>\r\n                          <option *ngFor=\"let month of month\" [value]=\"month\">\r\n                            {{month}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                      <div class=\"c-lg-5\">\r\n\r\n                        <label class=\"norm\">Year</label>\r\n                        <select style=\"border: 1px solid #efefef;\" [(ngModel)]=\"i.end_year\" (ngModelChange)=\"getEndYear($event , j)\">\r\n\r\n                          <option></option>\r\n                          <option *ngFor=\"let year of year\" [value]=\"year\">\r\n                            {{year}}\r\n                          </option>\r\n                        </select>\r\n                      </div>\r\n                    </div>\r\n                  </div> -->\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n            <tbody *ngIf=\"studentsId && getStudentsData.length==0 && dataStatus === false\">\r\n              <tr>\r\n                <td colspan=\"4\">No Records Found</td>\r\n              </tr>\r\n            </tbody>\r\n            <tbody *ngIf=\"studentsId && getStudentsData.length == 0 && dataStatus === true\">\r\n              <tr *ngFor=\"let dummy of dummyArr\">\r\n                <td *ngFor=\"let c of columnMaps\" style=\"padding:10px;\">\r\n                  <div class=\"skeleton\">\r\n                  </div>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n\r\n    <div id=\"tab2Content\">\r\n      <div class=\"tab\" *ngIf=\"categoryId!=62\">\r\n        <div class=\"row\">\r\n          <div class=\"c-lg-4 field-wrapper\">\r\n            <label class=\"forms\" *ngIf=\"isProfessional\">Master Course</label>\r\n            <label class=\"forms\" *ngIf=\"!isProfessional\">Standards</label>\r\n            <select class=\"form-ctrl\" [(ngModel)]=\"fileSharePublic.standard_id\" (ngModelChange)=\"getAllSubjects($event)\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let i of getStandards\" [value]=\"i.standard_id\">\r\n                {{i.standard_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n          <div class=\"c-lg-4 field-wrapper\">\r\n            <label class=\"forms\" *ngIf=\"isProfessional\">Course</label>\r\n            <label class=\"forms\" *ngIf=\"!isProfessional\">Subjects</label>\r\n            <select class=\"form-ctrl\" [(ngModel)]=\"fileSharePublic.subject_id\">\r\n              <option value=\"-1\"></option>\r\n              <option *ngFor=\"let i of getSubjects\" [value]=\"i.subject_id\">\r\n                {{i.subject_name}}\r\n              </option>\r\n            </select>\r\n          </div>\r\n          <div class=\"c-lg-4 field-wrapper\">\r\n            <label class=\"forms\">Course Types<span class=\"text-danger\">*</span></label>\r\n            <select id=\"courses\" class=\"form-ctrl\" multiple [(ngModel)]=\"courseType\" style=\"height: auto;\" (ngModelChange)=\"courseTypeSelection($event)\">\r\n              <option *ngFor=\"let i of courseMappingArray\" [value]=\"i.course_type_id\" [selected]=\"prefillSelected(i.course_type_id)\">{{i.course_type}}</option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div id=\"tab3Content\" class=\"\">\r\n\r\n    </div>\r\n\r\n  </div>\r\n\r\n  <div popup-footer style=\"margin-top: 2%;\">\r\n    <div *ngIf=\"tabChoice == 'institute'\" class=\"row\" style=\"text-align: right ; width:94%;\">\r\n      <div class=\"c-lg-8\" *ngIf=\"!editInstituteShare\">\r\n        <div class=\"c-lg-3 field-checkbox-wrapper\" *ngIf=\"getFileType == 'pdf'\" style=\"width:26%;\" <input type=\"checkbox\" class=\"form-checkbox\"\r\n          id=\"institute\" [(ngModel)]=\"isReadonlyInst\" (ngModelChange)=\"getReadonlyinst($event)\">\r\n          <label for=\"institute\">\r\n            Read Only\r\n          </label>\r\n        </div>\r\n      </div>\r\n      <div class=\"c-lg-6\" *ngIf=\"editInstituteShare\">\r\n        <div class=\"c-lg-4 field-checkbox-wrapper\" *ngIf=\"getFileType == 'pdf'\" style=\"width:26%;\">\r\n          <input type=\"checkbox\" class=\"form-checkbox\" id=\"institute\" [(ngModel)]=\"isReadonlyInst\" (ngModelChange)=\"getReadonlyinst($event)\">\r\n          <label for=\"institute\">\r\n            Read Only\r\n          </label>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-2\" *ngIf=\"!editInstituteShare\" style=\"text-align: right;\">\r\n        <input type=\"button\" value=\"Share\" class=\"btn fullBlue\" (click)=\"shareFile()\" style=\"width:100%\">\r\n      </div>\r\n      <div class=\"c-lg-2\" *ngIf=\"editInstituteShare\">\r\n        <input type=\"button\" value=\"Update\" class=\"btn fullBlue\" (click)=\"shareFile()\" style=\"width:100%\">\r\n      </div>\r\n      <div class=\"c-lg-2\" *ngIf=\"editInstituteShare\">\r\n        <input type=\"button\" value=\"UnShare\" class=\"btn fullBlue\" (click)=\"shareFile('1')\" style=\"width:100%\">\r\n      </div>\r\n      <div class=\"c-lg-2\">\r\n        <input type=\"button\" value=\"Close\" class=\"btn fullBlue\" (click)=\"close()\" style=\"width:100%\">\r\n      </div>\r\n    </div>\r\n\r\n    <div *ngIf=\"tabChoice == 'public'\" class=\"row\" style=\"text-align: right ; width:94%\">\r\n      <div class=\"c-lg-8\" *ngIf=\"!editPublicShare\">\r\n        <div class=\"c-lg-3 field-checkbox-wrapper\" *ngIf=\"getFileType == 'pdf'\" style=\"width:26%;\">\r\n          <input type=\"checkbox\" class=\"form-checkbox\" id=\"public\" [(ngModel)]=\"isReadonlyPub\" (ngModelChange)=\"getReadonlypublic($event)\">\r\n          <label for=\"public\">\r\n            Read Only\r\n          </label>\r\n        </div>\r\n\r\n      </div>\r\n      <div class=\"c-lg-6\" *ngIf=\"editPublicShare\">\r\n        <div class=\"c-lg-4 field-checkbox-wrapper\" *ngIf=\"getFileType == 'pdf'\" style=\"width:26%;\">\r\n          <input type=\"checkbox\" class=\"form-checkbox\" id=\"public\" [(ngModel)]=\"isReadonlyPub\" (ngModelChange)=\"getReadonlypublic($event)\">\r\n          <label for=\"public\">\r\n            Read Only\r\n          </label>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-2\" *ngIf=\"!editPublicShare\" style=\"text-align: right;\">\r\n        <input type=\"button\" value=\"Share\" class=\"btn fullBlue\" (click)=\"shareFile()\" style=\"width:100%\">\r\n      </div>\r\n      <div class=\"c-lg-2\" *ngIf=\"editPublicShare \">\r\n        <input type=\"button\" value=\"Update\" class=\"btn fullBlue\" (click)=\"shareFile()\" style=\"width:100%\">\r\n      </div>\r\n      <div class=\"c-lg-2\" *ngIf=\"editPublicShare\">\r\n        <input type=\"button\" value=\"UnShare\" class=\"btn fullBlue\" (click)=\"shareFile('1')\" style=\"width:100%\">\r\n      </div>\r\n      <div class=\"c-lg-2\">\r\n        <input type=\"button\" value=\"Close\" class=\"btn fullBlue\" (click)=\"close()\" style=\"width:100%\">\r\n      </div>\r\n    </div>\r\n\r\n    <div *ngIf=\"tabChoice == 'student'\" class=\"row\" style=\"text-align: right ; width:94%\">\r\n      <div class=\"c-lg-8\">\r\n        <div class=\"c-lg-3 field-checkbox-wrapper\" *ngIf=\"getFileType == 'pdf'\" style=\"float: left;width:26%;\">\r\n          <input type=\"checkbox\" class=\"form-checkbox\" id=\"student\" [(ngModel)]=\"isReadonlyStu\" (ngModelChange)=\"getReadonlystu($event)\">\r\n          <label for=\"student\">\r\n            Read Only\r\n          </label>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"c-lg-2\">\r\n        <input *ngIf=\"!editBatchShare \" type=\"button\" value=\"Share\" class=\"btn fullBlue\" (click)=\"shareFile()\" style=\"width:100%\">\r\n        <input *ngIf=\"editBatchShare\" type=\"button\" value=\"Update\" class=\"btn fullBlue\" (click)=\"shareFile()\" style=\"width:100%\">\r\n      </div>\r\n      <div class=\"c-lg-2\">\r\n        <input type=\"button\" value=\"Close\" class=\"btn fullBlue\" (click)=\"close()\" style=\"width:100%\">\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n</proctur-popup>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/file-manager/share-file/share-file.component.scss":
/***/ (function(module, exports) {

module.exports = "#tab1Content {\n  display: block; }\n\n#tab2Content,\n#tab3Content {\n  display: none; }\n\n.skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 100%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n\n.skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n\n.forms {\n  color: black; }\n\n.row-fix .c-lg-5 {\n  width: 25%; }\n\n.table-ne .field-wrapper .form-ctrl {\n  width: 75%;\n  margin-bottom: 10px;\n  height: 25px;\n  background: transparent; }\n\n.table-ne .field-wrapper {\n  position: relative; }\n\n.table-ne .field-wrapper.datePickerBox .form-ctrl {\n    cursor: pointer;\n    position: relative;\n    z-index: 1;\n    background: transparent; }\n\n.table-ne .field-wrapper.datePickerBox:after {\n    content: '';\n    background: url(/./assets/images/calendar.svg) no-repeat;\n    position: absolute;\n    right: 65px;\n    top: 12px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n\n.tab {\n  padding-bottom: 18px;\n  margin-left: 10px;\n  background: #efefef;\n  color: #fff;\n  width: 92%;\n  /* height: 72%; */\n  /* min-height: 46%; */\n  /* max-height: 73vh; */\n  height: auto;\n  z-index: 4;\n  margin-top: 1px;\n  /* box-shadow: -15px 24px 5px #008; */ }\n\n.norm {\n  font-size: 8px; }\n\n.common {\n  color: black; }\n\n.form-file {\n  font-size: 14px;\n  color: #666666;\n  text-transform: uppercase; }\n\n.bold-font {\n  font-size: 14px;\n  color: black;\n  font-weight: bold; }\n"

/***/ }),

/***/ "./src/app/components/course-module/file-manager/share-file/share-file.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ShareFileComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__file_manager_service__ = __webpack_require__("./src/app/components/course-module/file-manager/file-manager.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var ShareFileComponent = /** @class */ (function () {
    function ShareFileComponent(fileService, appC, auth, services) {
        this.fileService = fileService;
        this.appC = appC;
        this.auth = auth;
        this.services = services;
        this.closePopup = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.CloseValuePopup = false;
        this.getStandards = [];
        this.getStandardsId = "";
        this.getSubjects = [];
        this.fetchBatchesData = {
            institute_id: this.fileService.institute_id,
            file_id: "",
            subject_id: ""
        };
        this.getStudentsData = [];
        this.subjectId = "";
        this.getBatchesData = [];
        this.studentsId = false;
        this.batchesId = true;
        this.dataStatus = false;
        this.isProfessional = false;
        this.dummyArr = [0, 1, 2, 0, 1, 2];
        this.columnMaps = [0, 1, 2, 3];
        this.getBatch = "0";
        this.getStudent = "";
        this.fetchShareOption = {
            batches: [],
            desc: "",
            file_id: "",
            institute_id: this.fileService.institute_id,
            share_type: "",
            standard_id: "",
            student_batch_share: "",
            students: [],
            subject_id: "",
            is_readonly: "N"
        };
        this.fileSharePublic = {
            course_types: "",
            file_id: "",
            institute_id: this.fileService.institute_id,
            public_share: 1,
            share_type: 2,
            standard_id: "",
            subject_id: "",
            is_readonly: "N"
        };
        this.startAccessTimeStudent = __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD');
        this.endAccessTimeStudent = __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD');
        this.endAccessTimeBatch = __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD');
        this.startAccessTimeBatch = __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD');
        this.isChecked = false;
        this.isStudentChecked = false;
        this.isReadonlyStu = false;
        this.isReadonlyInst = false;
        this.isReadonlyPub = false;
        this.treeUpdater = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.courseMappingArray = [];
        this.tabChoice = "student";
        this.editBatchShare = false;
        this.editInstituteShare = false;
        this.editPublicShare = false;
        this.courseValue = "";
        this.courseType = [];
        this.date = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31];
        this.month = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
        this.year = [2015, 2016, 2017, 2018, 2019, 2020];
        this.instituteObj = {
            file_id: '',
            institute_id: this.fileService.institute_id,
            share_type: 1,
            is_readonly: "N"
        };
        this.temparrBatch = [];
        this.temparrStudent = [];
        this.publicObj = {
            file_id: '',
            institute_id: this.fileService.institute_id,
            share_type: 2,
            is_readonly: "N"
        };
        this.getFileType = "";
    }
    ShareFileComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.getAllStandards();
        this.multiCourseMapping();
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
    };
    ShareFileComponent.prototype.ngOnChanges = function () {
        this.categoryId = this.fileName.res.category_id;
        this.editBatchShare = false;
        this.editInstituteShare = false;
        this.editPublicShare = false;
        this.selectTab(2);
    };
    ShareFileComponent.prototype.close = function () {
        this.closePopup.emit(this.CloseValuePopup);
    };
    ShareFileComponent.prototype.chooseTab = function (index) {
        this.getFileType = this.shareOptions.fileType;
        /*Disabling Buttons
        if(this.shareOptions.batchShare == '0'){
          (<HTMLFormElement>document.getElementById('tab1')).disabled = true;
        }else if(this.shareOptions.publicShare == '0'){
          (<HTMLFormElement>document.getElementById('tab2')).disabled = true;
        }else if(this.shareOptions.instituteShare == '0'){
          (<HTMLFormElement>document.getElementById('tab3')).disabled = true;
        }*/
        var share_type = 0;
        if (index == '1' && this.shareOptions.batchShare == '1') {
            share_type = 3;
            this.editBatchShare = true;
            if (this.shareOptions.isReadonly == "N") {
                this.isReadonlyStu = false;
            }
            else {
                this.isReadonlyStu = true;
            }
        }
        else if (index == '2' && this.shareOptions.publicShare == '1') {
            share_type = 2;
            this.editPublicShare = true;
            if (this.shareOptions.isReadonly == "N") {
                this.isReadonlyPub = false;
            }
            else {
                this.isReadonlyPub = true;
            }
        }
        else if (index == '3' && this.shareOptions.instituteShare == '1') {
            share_type = 1;
            this.editInstituteShare = true;
            if (this.shareOptions.isReadonly == "N") {
                this.isReadonlyInst = false;
            }
            else {
                this.isReadonlyInst = true;
            }
        }
        if (share_type != 0) {
            this.editFileFetch(share_type);
        }
    };
    ShareFileComponent.prototype.editApiSwitch = function (key) {
        switch (key) {
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
        }
    };
    ShareFileComponent.prototype.editFileFetch = function (share_type) {
        var _this = this;
        var Obj = {
            file_id: this.fileIdGet,
            institute_id: this.fileService.institute_id,
            share_type: share_type
        };
        this.fileService.editFileShare(Obj).subscribe(function (data) {
            if (share_type == '2') {
                if (_this.categoryId != '62') {
                    _this.fileSharePublic.standard_id = data.standard_id;
                    _this.getAllSubjects(data.standard_id);
                    _this.fileSharePublic.subject_id = data.subject_id;
                    _this.courseType = data.course_types.split(',');
                    // this.courseTypeSelection(this.courseType);
                    _this.fileSharePublic.course_types = data.course_types;
                    if (_this.shareOptions.isReadonly == "N") {
                        _this.isReadonlyPub = false;
                    }
                    else {
                        _this.isReadonlyPub = true;
                    }
                }
            }
            else if (share_type == '3') {
                _this.getStandardsId = data.standard_id;
                _this.getAllSubjects(data.standard_id);
                _this.subjectId = data.subject_id;
                _this.fetchShareOption.desc = data.desc;
                _this.getBatches(1);
                _this.fetchCoursesData(_this.subjectId, 0, 1);
                if (_this.shareOptions.isReadonly == "N") {
                    _this.isReadonlyStu = false;
                }
                else {
                    _this.isReadonlyStu = true;
                }
            }
        }, function (error) {
        });
    };
    ShareFileComponent.prototype.getAllStandards = function () {
        var _this = this;
        this.fileService.getAllStandards().subscribe(function (data) {
            _this.getStandards = data;
            _this.getStudentsData = [];
            _this.getBatchesData = [];
            _this.studentsId = false;
            _this.batchesId = true;
        }, function (error) {
        });
    };
    ShareFileComponent.prototype.getReadonlystu = function (event) {
        if (event == true) {
            this.fetchShareOption.is_readonly = "Y";
        }
        else {
            this.fetchShareOption.is_readonly = "N";
        }
    };
    ShareFileComponent.prototype.getReadonlypublic = function (event) {
        if (event == true) {
            this.fileSharePublic.is_readonly = "Y";
            this.publicObj.is_readonly = "Y";
        }
        else {
            this.fileSharePublic.is_readonly = "N";
            this.publicObj.is_readonly = "N";
        }
    };
    ShareFileComponent.prototype.getReadonlyinst = function (event) {
        if (event == true) {
            this.instituteObj.is_readonly = "Y";
        }
        else {
            this.instituteObj.is_readonly = "N";
        }
    };
    ShareFileComponent.prototype.getAllSubjects = function (i) {
        var _this = this;
        this.fileService.getSubjects(i).subscribe(function (data) {
            _this.getSubjects = data;
            _this.studentsId = false;
            _this.batchesId = true;
        }, function (error) {
        });
    };
    ShareFileComponent.prototype.getBatches = function (update) {
        var _this = this;
        this.getBatchesData = [];
        var batchesData = [];
        this.isChecked = false;
        this.getBatch = "0";
        this.batchesId = true;
        this.dataStatus = true;
        document.getElementById('batch').checked = true;
        this.fetchBatchesData = {
            institute_id: this.fileService.institute_id,
            file_id: this.fileIdGet,
            subject_id: this.subjectId
        };
        this.fileService.shareFileWithBatches(this.fetchBatchesData).subscribe(function (data) {
            var currentDate = new Date();
            _this.dataStatus = false;
            var filterbatches = data;
            filterbatches.forEach(function (batch) {
                var batchDate = new Date(batch.file_access_end_time);
                if (batchDate.getTime() >= currentDate.getTime()) {
                    batchesData.push(batch);
                }
            });
            _this.getBatchesData = batchesData;
            _this.getBatchesData.map(function (data) {
                if (data.file_access_start_time == "") {
                    data.file_access_start_time = __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD');
                }
                if (data.file_access_end_time == "") {
                    data.file_access_end_time = __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD');
                }
                if (update != 1) {
                    data.is_file_shared = "N";
                    data.isChecked = false;
                }
                else {
                    if (data.is_file_shared == 'Y') {
                        data.isChecked = true;
                    }
                    else {
                        data.isChecked = false;
                    }
                }
            });
        }, function (error) {
            _this.dataStatus = false;
        });
    };
    // fetchUpdatedBatches(){
    //   this.fetchBatchesData = {
    //     institute_id: this.fileService.institute_id,
    //     file_id: this.fileIdGet,
    //     subject_id: this.subjectId
    //   }
    //   this.fileService.shareFileWithBatches(this.fetchBatchesData).subscribe(
    //     (data: any) => {
    //       this.getBatchesData = data;
    //     }
    //   )
    // }
    // fetchStudentsShare(){
    //     this.studentsId = true;
    //     this.batchesId = false;
    //     this.fetchBatchesData = {
    //       institute_id: this.fileService.institute_id,
    //       file_id: this.fileIdGet,
    //       subject_id: subject_id
    //     }
    //     this.fileService.shareFileWithStudents(this.fetchBatchesData).subscribe(
    //       (data: any) => {
    //         this.getStudentsData = data;
    //         this.getStudentsData.map(
    //           (data: any) => {
    //             data.start_month = moment().month() + 1;
    //             data.start_year = moment().year();
    //             data.start_date = moment().date();
    //             data.end_date = moment().date();
    //             data.end_month = moment().month() + 1;
    //             data.end_year = moment().year();
    //             data.is_file_shared = "N",
    //               data.isChecked = false
    //           }
    //         )
    //       },
    //       (error: any) => {
    //       }
    //     )
    // }
    ShareFileComponent.prototype.prefillSelected = function (courseId) {
        for (var i = 0; i < this.courseType.length; i++) {
            if (this.courseType[i] == courseId) {
                return true;
            }
        }
        return false;
    };
    ShareFileComponent.prototype.multiCourseMapping = function () {
        var _this = this;
        this.fileService.courseMapping().subscribe(function (data) {
            _this.courseMappingArray = data;
        }, function (error) {
            var msg = {
                type: "error",
                body: error.error.message
            };
            _this.appC.popToast(msg);
        });
    };
    ShareFileComponent.prototype.fetchCoursesData = function (subject_id, event, update) {
        var _this = this;
        this.getStudentsData = [];
        this.dataStatus = true;
        this.isStudentChecked = false;
        (update == true) ? update = 1 : update = 0;
        if (event == 0) {
            var arr = [];
            this.studentsId = false;
            this.batchesId = true;
            this.dataStatus = false;
        }
        else if (event == "1") {
            this.studentsId = true;
            this.batchesId = false;
            this.fetchBatchesData = {
                institute_id: this.fileService.institute_id,
                file_id: this.fileIdGet,
                subject_id: subject_id
            };
            this.fileService.shareFileWithStudents(this.fetchBatchesData).subscribe(function (data) {
                _this.dataStatus = false;
                _this.getStudentsData = data;
                _this.getStudentsData.map(function (data) {
                    if (data.file_access_end_time == "") {
                        data.file_access_end_time = __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD');
                    }
                    if (data.file_access_start_time == "") {
                        data.file_access_start_time = __WEBPACK_IMPORTED_MODULE_3_moment__().format('YYYY-MM-DD');
                    }
                    if (update != 1) {
                        data.is_file_shared = "N";
                        data.isChecked = false;
                    }
                    else {
                        if (data.is_file_shared == 'Y') {
                            data.isChecked = true;
                        }
                        else {
                            data.isChecked = false;
                        }
                    }
                });
            }, function (error) {
                _this.dataStatus = false;
            });
        }
    };
    ShareFileComponent.prototype.fileSharedBatches = function (event) {
        if (event == true) {
            for (var i = 0; i < this.getBatchesData.length; i++) {
                this.getBatchesData[i].is_file_shared = "Y";
                this.getBatchesData[i].isChecked = true;
            }
        }
        else if (event == false) {
            for (var i = 0; i < this.getBatchesData.length; i++) {
                this.getBatchesData[i].is_file_shared = "N";
                this.getBatchesData[i].isChecked = false;
            }
        }
    };
    ShareFileComponent.prototype.fileSharedStudents = function (event) {
        if (event == true) {
            for (var i = 0; i < this.getStudentsData.length; i++) {
                this.getStudentsData[i].is_file_shared = "Y";
                this.getStudentsData[i].isChecked = true;
            }
        }
        else if (event == false) {
            for (var i = 0; i < this.getStudentsData.length; i++) {
                this.getStudentsData[i].is_file_shared = "N";
                this.getStudentsData[i].isChecked = false;
            }
        }
    };
    ShareFileComponent.prototype.getFileSharedBatches = function (event, index) {
        if (event == true) {
            this.getBatchesData[index].is_file_shared = "Y";
            this.getBatchesData[index].isChecked = true;
        }
        else {
            this.getBatchesData[index].is_file_shared = "N";
            this.isChecked = false;
            this.getBatchesData[index].isChecked = false;
        }
    };
    ShareFileComponent.prototype.getFileSharedStudents = function (event, index) {
        if (event == true) {
            this.getStudentsData[index].is_file_shared = "Y";
            this.getStudentsData[index].isChecked = true;
        }
        else {
            this.getStudentsData[index].is_file_shared = "N";
            this.isStudentChecked = false;
            this.getStudentsData[index].isChecked = false;
        }
    };
    ShareFileComponent.prototype.fetchApiStudentsAndBatches = function () {
        var _this = this;
        console.log(this.getBatchesData);
        console.log(this.getStudentsData);
        this.getBatchesData.map(function (ele) {
            if (ele.isChecked == true) {
                var obj = {
                    file_access_end_time: ele.file_access_end_time,
                    file_access_start_time: ele.file_access_start_time,
                    is_file_shared: ele.is_file_shared,
                    batch_id: ele.batch_id
                };
                _this.temparrBatch.push(obj);
            }
            else {
                var obj = {
                    is_file_shared: ele.is_file_shared,
                    batch_id: ele.batch_id
                };
                _this.temparrBatch.push(obj);
            }
        });
        this.getStudentsData.map(function (ele) {
            if (ele.isChecked == true) {
                var obj = {
                    file_access_end_time: ele.file_access_end_time,
                    file_access_start_time: ele.file_access_start_time,
                    is_file_shared: ele.is_file_shared,
                    student_id: ele.student_id
                };
                _this.temparrStudent.push(obj);
            }
            else {
                var obj = {
                    is_file_shared: ele.is_file_shared,
                    student_id: ele.student_id
                };
                _this.temparrStudent.push(obj);
            }
        });
        this.fileService.shareFile(this.fetchShareOption).subscribe(function (data) {
            var msg = {
                type: "success",
                body: "File Shared Successfully"
            };
            _this.appC.popToast(msg);
            _this.treeUpdater.emit(true);
            _this.closePopup.emit(_this.CloseValuePopup);
        }, function (error) {
            var msg = {
                type: "error",
                body: error.error.message
            };
            _this.appC.popToast(msg);
        });
    };
    ShareFileComponent.prototype.validationsOfTime = function () {
        var isNotCountSelected = 0;
        if (this.batchesId) {
            for (var i = 0; i < this.getBatchesData.length; i++) {
                if (this.getBatchesData[i].isChecked) {
                    var a = new Date(this.getBatchesData[i].file_access_start_time.toString());
                    var b = new Date(this.getBatchesData[i].file_access_end_time.toString());
                    if (a.getTime() > b.getTime()) {
                        this.services.showErrorMessage("error", "Incorrect Details", "Access start Date Cannot be more than access end date");
                        return false;
                    }
                }
                else {
                    isNotCountSelected++;
                }
            }
            if (isNotCountSelected == this.getBatchesData.length) {
                this.services.showErrorMessage("error", "Incorrect Details", "Please select batch for share file");
                return false;
            }
            return true;
        }
        else if (this.studentsId) {
            for (var i = 0; i < this.getStudentsData.length; i++) {
                if (__WEBPACK_IMPORTED_MODULE_3_moment__(this.getStudentsData[i].file_access_start_time) > __WEBPACK_IMPORTED_MODULE_3_moment__(this.getStudentsData[i].file_access_end_time)) {
                    this.services.showErrorMessage("error", "Incorrect Details", "Access start Date Cannot be more than access end date");
                    return false;
                }
            }
            return true;
        }
    };
    ShareFileComponent.prototype.shareFile = function (unshare) {
        var _this = this;
        // debugger
        this.fetchShareOption.file_id = this.fileIdGet;
        this.fetchShareOption.share_type = "3";
        this.fetchShareOption.student_batch_share = "1";
        this.fetchShareOption.standard_id = this.getStandardsId;
        this.fetchShareOption.subject_id = this.subjectId;
        this.fetchShareOption.batches = this.temparrBatch;
        this.fetchShareOption.students = this.temparrStudent;
        if (this.tabChoice == "student") {
            if (this.fetchShareOption.standard_id == "" || this.fetchShareOption.subject_id == "") {
                this.services.showErrorMessage("error", "Incorrect Details", "Please select master course and course");
            }
            else if (this.getBatchesData == []) {
                this.services.showErrorMessage("error", "Incorrect Details", "No batches/students found");
            }
            else {
                if (this.validationsOfTime() == true) {
                    this.fetchApiStudentsAndBatches();
                    return;
                }
            }
        }
        else if (this.tabChoice == "public") {
            if (unshare == '1') {
                var Obj = {
                    file_id: this.fileIdGet,
                    institute_id: this.fileService.institute_id,
                    public_share: '1',
                    share_type: 0
                };
                this.fileService.shareFile(Obj).subscribe(function (data) {
                    var msg = {
                        type: "success",
                        body: "File UnShared Successfully"
                    };
                    _this.appC.popToast(msg);
                    _this.treeUpdater.emit(true);
                    _this.closePopup.emit(_this.CloseValuePopup);
                }, function (error) {
                });
            }
            else {
                this.fileSharePublic.file_id = this.fileIdGet;
                if (this.categoryId != '62') {
                    if (this.fileSharePublic.standard_id == "" || this.fileSharePublic.subject_id == "") {
                        var msg = {
                            type: "error",
                            body: "Please select master course and course"
                        };
                        this.appC.popToast(msg);
                    }
                    else if (this.courseType.length == 0) {
                        var msg = {
                            type: "error",
                            body: "Course type is mandatory"
                        };
                        this.appC.popToast(msg);
                    }
                    else {
                        this.courseValue = this.courseType.join();
                        this.fileSharePublic.course_types = this.courseValue;
                        this.fileService.shareFile(this.fileSharePublic).subscribe(function (data) {
                            var msg = {
                                type: "success",
                                body: "File Shared Successfully"
                            };
                            _this.appC.popToast(msg);
                            _this.treeUpdater.emit(true);
                            _this.closePopup.emit(_this.CloseValuePopup);
                        }, function (error) {
                            var msg = {
                                type: "error",
                                body: error.error.message
                            };
                            _this.appC.popToast(msg);
                        });
                    }
                }
                else {
                    this.publicObj.file_id = this.fileIdGet;
                    this.fileService.shareFile(this.publicObj).subscribe(function (data) {
                        var msg = {
                            type: "success",
                            body: "File Shared Successfully"
                        };
                        _this.appC.popToast(msg);
                        _this.treeUpdater.emit(true);
                        _this.closePopup.emit(_this.CloseValuePopup);
                    }, function (error) {
                        var msg = {
                            type: "error",
                            body: error.error.message
                        };
                        _this.appC.popToast(msg);
                    });
                }
            }
        }
        else if (this.tabChoice == "institute") {
            this.instituteObj.file_id = this.fileIdGet;
            var mess_1 = "Shared";
            if (unshare == '1') {
                this.instituteObj.share_type = 0;
                mess_1 = "Unshared";
            }
            this.fileService.shareFile(this.instituteObj).subscribe(function (data) {
                var msg = {
                    type: "success",
                    body: "File " + mess_1 + " Successfully"
                };
                _this.appC.popToast(msg);
                _this.treeUpdater.emit(true);
                _this.closePopup.emit(_this.CloseValuePopup);
            }, function (error) {
            });
        }
    };
    ShareFileComponent.prototype.courseTypeSelection = function (event) {
        this.courseType = event;
    };
    ShareFileComponent.prototype.selectTab = function (tabIndex) {
        //Hide All Tabs
        document.getElementById('tab1Content').style.display = "none";
        document.getElementById('tab2Content').style.display = "none";
        document.getElementById('tab3Content').style.display = "none";
        if (tabIndex == 1) {
            document.getElementById('tab' + 1).style.backgroundColor = "#0084f6bf";
            document.getElementById('tab' + 1).style.color = "#fff";
            document.getElementById('tab' + 2).style.backgroundColor = "";
            document.getElementById('tab' + 2).style.color = "#0084f6";
            document.getElementById('tab' + 3).style.backgroundColor = "";
            document.getElementById('tab' + 3).style.color = "#0084f6";
            this.tabChoice = "student";
            document.getElementById('batch').checked = true;
        }
        else if (tabIndex == 2) {
            document.getElementById('tab' + 1).style.backgroundColor = "";
            document.getElementById('tab' + 2).style.backgroundColor = "#0084f6bf";
            document.getElementById('tab' + 2).style.color = "#fff";
            document.getElementById('tab' + 1).style.color = "#0084f6";
            document.getElementById('tab' + 3).style.backgroundColor = "";
            document.getElementById('tab' + 3).style.color = "#0084f6";
            this.tabChoice = "public";
        }
        else {
            document.getElementById('tab' + 1).style.backgroundColor = "";
            document.getElementById('tab' + 2).style.backgroundColor = "";
            document.getElementById('tab' + 1).style.color = "#0084f6";
            document.getElementById('tab' + 2).style.color = "#0084f6";
            document.getElementById('tab' + 3).style.backgroundColor = "#0084f6bf";
            document.getElementById('tab' + 3).style.color = "#fff";
            this.tabChoice = "institute";
        }
        //Show the Selected Tab
        document.getElementById('tab' + tabIndex + 'Content').style.display = "block";
        this.chooseTab(tabIndex);
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], ShareFileComponent.prototype, "closePopup", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", String)
    ], ShareFileComponent.prototype, "fileIdGet", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], ShareFileComponent.prototype, "fileName", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], ShareFileComponent.prototype, "shareOptions", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], ShareFileComponent.prototype, "treeUpdater", void 0);
    ShareFileComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'share-file',
            template: __webpack_require__("./src/app/components/course-module/file-manager/share-file/share-file.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/file-manager/share-file/share-file.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__file_manager_service__["a" /* FileManagerService */], __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */], __WEBPACK_IMPORTED_MODULE_4__services_authenticator_service__["a" /* AuthenticatorService */], __WEBPACK_IMPORTED_MODULE_5__services_message_show_service__["a" /* MessageShowService */]])
    ], ShareFileComponent);
    return ShareFileComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/file-manager/upload-popup/upload-popup.component.html":
/***/ (function(module, exports) {

module.exports = "<proctur-popup [sizeWidth]=\"'small'\">\r\n\r\n  <span class=\"closePopup pos-abs fbold show\" close-button (click)=\"close()\">\r\n    <svg  class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n      <path class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" style=\"fill: currentColor\"></path>\r\n    </svg>\r\n  </span>\r\n\r\n  <div popup-header class=\"popup-header-content\">\r\n    <h2 style=\"text-align: center;\">Upload File</h2>\r\n  </div>\r\n\r\n  <div popup-content class=\"popup-header-content\">\r\n\r\n    <div *ngIf=\"!manualUpload\">\r\n      <div class=\"row\">\r\n        <div class=\"c-lg-8 field-wrapper\">\r\n          <label>Select Category</label>\r\n          <select class=\"form-ctrl\" [(ngModel)]=\"category_id\" (ngModelChange)=\"categoryCheck($event)\">\r\n            <option value=\"-1\">Select Category</option>\r\n            <option *ngFor=\"let i of getCategoryData\" [value]=\"i.category_id\">\r\n              {{i.category_name}}\r\n            </option>\r\n          </select>\r\n        </div>\r\n        <div class=\"c-lg-1\">\r\n          <i class=\"fa fa-upload\" title=\"Upload File\" (click)=\"uploadHandler()\" style=\"font-family: 'FontAwesome' ; display: inline-block; font-size: 19px; color: #0d171f; margin-top: 30px;  margin-left: -14px;\">\r\n          </i>&nbsp;&nbsp;&nbsp;\r\n        </div>\r\n        <div class=\"c-lg-3\">\r\n          <div class=\"uploadProcessAndFileName clearfix\" *ngIf=\"isUploadingXls\">\r\n            <div class=\"file-uploaded\">\r\n              {{fileLoading}}\r\n            </div>\r\n            <div class=\"progress-bar-wrapper\">\r\n              <div class=\"upload-bar\">\r\n                <div id=\"progress-width\"></div>\r\n              </div>\r\n              <!-- <span>0</span>\r\n              <span style=\"margin-left: 55%;\">100</span> -->\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"row\" *ngIf=\"type!=''\" style=\"margin-top: 10px;\r\n      margin-left: 14px;\">\r\n        <label>Format supported :\r\n          <span>{{type}}</span>\r\n        </label>\r\n      </div>\r\n      <div class=\"row\" style=\"margin-left: 2%;\">\r\n\r\n        <ul *ngFor=\"let file of customFileArr\" style=\"display: inline-block; width:40%;\" class=\"shadow\">\r\n          <div class=\"row\">\r\n            <div class=\"c-lg-2\">\r\n              <li style=\"display:inline-block;width: 30px;\r\n                  display: inline-block;\r\n                  margin-top: 4px;\">\r\n                <img src=\"assets/images/file_manager/image.svg\" style=\"width: 96px;\r\n                    height: 32px;\r\n                    margin-left: -11px;\" *ngIf=\"category_image.hasOwnProperty(file.fileType)\">\r\n                <img src=\"assets/images/file_manager/xlsx.png\" style=\"width: 96px;\r\n                    height: 32px;\r\n                    margin-left: -11px;\" *ngIf=\"category_docx.hasOwnProperty(file.fileType)\">\r\n                <img src=\"assets/images/file_manager/pdf.png\" style=\"width: 96px;\r\n                    height: 32px;\r\n                    margin-left: -11px;\" *ngIf=\"category_pdf.hasOwnProperty(file.fileType)\">\r\n              </li>\r\n            </div>\r\n            <div class=\"c-lg-10\">\r\n              <li style=\"display: inline-block;\">\r\n                File Name : {{file.fileName}}\r\n              </li>\r\n              <li>\r\n                File Type : {{file.fileType}}\r\n              </li>\r\n              <li>\r\n                File Size : {{file.fileSize}}\r\n              </li>\r\n            </div>\r\n          </div>\r\n\r\n        </ul>\r\n\r\n      </div>\r\n    </div>\r\n    <div *ngIf=\"manualUpload\">\r\n      <div class=\"row\">\r\n        <div class=\"c-lg-8 field-wrapper\">\r\n          <label>Select Category</label>\r\n          <select class=\"form-ctrl\" [(ngModel)]=\"category_id\" (ngModelChange)=\"categoryCheck()\">\r\n            <option value=\"-1\">Select Category</option>\r\n            <option *ngFor=\"let i of getCategoryData\" [value]=\"i.category_id\">\r\n              {{i.category_name}}\r\n            </option>\r\n\r\n          </select>\r\n        </div>\r\n        <div class=\"c-lg-3\">\r\n          <div class=\"uploadProcessAndFileName clearfix\" *ngIf=\"isUploadingXls\">\r\n            <div class=\"file-uploaded\">\r\n              {{fileLoading}}\r\n            </div>\r\n            <div class=\"progress-bar-wrapper\">\r\n              <div class=\"upload-bar\">\r\n                <div id=\"progress-width\"></div>\r\n              </div>\r\n              <!-- <span>0</span>\r\n              <span style=\"margin-left: 55%;\">100</span> -->\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"row\" *ngIf=\"type!=''\" style=\"margin-top: 10px;\r\n      margin-left: 14px;\">\r\n        <label>Format supported :\r\n          <span>{{type}}</span>\r\n        </label>\r\n      </div>\r\n      <div class=\"row\">\r\n        <div class=\"c-lg-8 field-wrapper\">\r\n          <label>Choose Multiple Files(Ctrl + ) To Upload</label>\r\n          <input type=\"file\" class=\"form-ctrl\" id=\"uploadFileControl\" name=\"uploadFileBox\" (change)=\"fillFiles()\" multiple/>\r\n        </div>\r\n\r\n        <div class=\"c-lg-2\">\r\n          <button class=\"btn fullBlue\" (click)=\"uploadHandler()\" style=\"margin-top: 4vh;\">Upload</button>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</proctur-popup>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/file-manager/upload-popup/upload-popup.component.scss":
/***/ (function(module, exports) {

module.exports = ".shadow {\n  border: 1px solid #e8e5e5cf;\n  display: inline-block;\n  border-radius: 3px;\n  margin: 1%;\n  padding: 1%;\n  -webkit-box-shadow: 5px 5px 5px #efefef;\n          box-shadow: 5px 5px 5px #efefef; }\n\n.file-uploaded {\n  margin: 25px 0 30px;\n  font-weight: 600;\n  font-size: 16px; }\n\n.file-uploaded span {\n    display: inline-block;\n    vertical-align: middle;\n    cursor: pointer; }\n\n.file-uploaded span svg {\n      margin-right: 10px;\n      width: 15px; }\n\n.file-uploaded span svg .cls-1 {\n        stroke: #888;\n        stroke-width: 2; }\n\n.file-uploaded span svg:hover .cls-1 {\n        stroke: blue; }\n\n.progress-bar-wrapper {\n  float: left;\n  width: 80%; }\n\n.upload-bar {\n  position: relative;\n  height: 8px;\n  width: 100%;\n  background: #ccc;\n  border-radius: 0;\n  overflow: hidden;\n  margin: 10px 0 5px; }\n\n.upload-bar > div {\n    position: absolute;\n    height: 100%;\n    width: 0%;\n    left: 0;\n    background: blue;\n    top: 0;\n    border-radius: 0;\n    -webkit-transition: all 0.5s ease;\n    transition: all 0.5s ease; }\n\n.cancel-upload {\n  float: right;\n  cursor: pointer;\n  margin: 4px 0 0 0px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/file-manager/upload-popup/upload-popup.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UploadPopupComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__file_manager_service__ = __webpack_require__("./src/app/components/course-module/file-manager/file-manager.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var fileObj = /** @class */ (function () {
    function fileObj(fileName, fileType, fileSize) {
        this.fileName = fileName;
        this.fileType = fileType;
        this.fileSize = this.getSizeMB(fileSize);
    }
    fileObj.prototype.getSizeMB = function (size) {
        return size + "KB";
    };
    fileObj.prototype.getSize = function () {
        return this.fileSize;
    };
    return fileObj;
}());
var UploadPopupComponent = /** @class */ (function () {
    function UploadPopupComponent(cd, fileService, appC, auth) {
        this.cd = cd;
        this.fileService = fileService;
        this.appC = appC;
        this.auth = auth;
        this.getCategoryData = [];
        this.closePopupValue = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"](true);
        this.selectedFiles = [];
        this.currentFolder = null;
        this.manualUpload = false;
        this.pathArray = [];
        this.currentFilesArray = [];
        this.getFilesAndFolder = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.filesAndFolder = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.filePath = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.fileLoading = "";
        this.uploadStatus = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        this.progress = 0;
        this.type = "";
        this.customFileArr = [];
        this.category_id = "-1";
        this.category_image = {
            png: "1",
            jpg: "4",
            jpeg: "5",
            bmp: "6",
            mp4: "7",
            mp3: "8"
        };
        this.category_docx = {
            xls: "4",
            xlsx: "5",
        };
        this.category_pdf = {
            pdf: "2",
        };
        this.category_txt = {
            txt: "6",
            rtf: "7",
            gif: "7",
            tif: "8"
        };
        this.acceptedFiles = {
            62: {
                png: "1",
                pdf: "2",
                mp4: "3",
                jpg: "4",
                jpeg: "5",
                bmp: "6",
                gif: "7",
                tif: "8",
            },
            63: {
                pdf: "1",
                doc: "2",
                docx: "3",
                xls: "4",
                xlsx: "5",
                txt: "6",
                rtf: "7",
                jpg: "8",
                jpeg: "9",
                png: "10",
                pptx: "11",
                ppt: "12",
                zip: '13'
            },
            66: {
                pdf: "1",
                doc: "2",
                docx: "3",
                xls: "4",
                xlsx: "5",
                txt: "6",
                rtf: "7",
                jpg: "8",
                jpeg: "9",
                png: "10",
                pptx: "11",
                ppt: "12",
                zip: '13'
            },
            67: {
                pdf: "1",
                doc: "2",
                docx: "3",
                xls: "4",
                xlsx: "5",
                txt: "6",
                rtf: "7",
                zip: '8'
            },
            182: {
                pdf: "1",
                doc: "2",
                docx: "3",
                xls: "4",
                xlsx: "5",
                txt: "6",
                rtf: "7",
                zip: '8'
            }
        };
        /*category_gallery = {
          png: "1",
          pdf: "2",
          mp4: "3",
          jpg: "4",
          jpeg: "5",
          bmp: "6",
          gif: "7",
          tif: "8"
        }
      
        category_assignment = {
          pdf:"1",
          doc:"2",
          docx:"3",
          xls:"4",
          xlsx:"5",
          txt:"6",
          rtf:"7",
          jpg:"8",
          jpeg:"9",
          png:"10"
        }
      
        category_exam = {
          pdf:"1",
          doc:"2",
          docx:"3",
          xls:"4",
          xlsx:"5",
          txt:"6",
          rtf:"7",
          jpg:"8",
          jpeg:"9",
          png:"10"
        }
      
        category_other = {
          pdf:"1",
          doc:"2",
          docx:"3",
          xls:"4",
          xlsx:"5",
          txt:"6",
          rtf:"7"
        } */
        this.tempArr = [];
        this.isUploadingXls = false;
    }
    UploadPopupComponent.prototype.ngOnInit = function () {
        this.getCategories();
    };
    UploadPopupComponent.prototype.ngOnChanges = function () {
        this.customFileArr = this.generateFilePreview(this.selectedFiles);
        this.cd.detectChanges();
    };
    UploadPopupComponent.prototype.getCategories = function () {
        var _this = this;
        this.fileService.getCategories().subscribe(function (data) {
            _this.getCategoryData = data;
            _this.getCategoryData.map(function (ele) {
                if (ele.category_id == "182") {
                    ele.category_name = "Study Material";
                }
            });
            _this.cd.detectChanges();
        }, function (error) {
            var msg = {
                type: "error",
                body: error.error.message
            };
            _this.appC.popToast(msg);
        });
    };
    UploadPopupComponent.prototype.close = function () {
        this.manualUpload = false;
        this.closePopupValue.emit(false);
        this.cd.detectChanges();
    };
    UploadPopupComponent.prototype.getName = function (file) {
        return file.split(".")[0];
    };
    UploadPopupComponent.prototype.getType = function (file) {
        var str = file.substring(file.lastIndexOf(".") + 1, file.length);
        return str;
    };
    UploadPopupComponent.prototype.generateFilePreview = function (fileList) {
        var size = fileList.length;
        var tempArr = [];
        this.tempArr = tempArr;
        var file;
        if (size > 0) {
            for (var i = 0; i < size; i++) {
                file = fileList[i];
                tempArr.push(new fileObj(this.getName(file.name), this.getType(file.name), file.size));
            }
        }
        return tempArr;
    };
    UploadPopupComponent.prototype.convertBase64ToArray = function (val) {
        var binary_string = window.atob(val);
        var len = binary_string.length;
        var bytes = new Uint8Array(len);
        for (var i = 0; i < len; i++) {
            bytes[i] = binary_string.charCodeAt(i);
        }
        return bytes.buffer;
    };
    UploadPopupComponent.prototype.updateXlsHeaders = function (ev) {
        ev.xhr.setRequestHeader("processData", "false");
        ev.xhr.setRequestHeader("contentType", "false");
        ev.xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
        ev.xhr.setRequestHeader("enctype", "multipart/form-data");
        ev.xhr.setRequestHeader("Authorization", sessionStorage.getItem("Authorization"));
    };
    UploadPopupComponent.prototype.uploadHandler = function () {
        var _this = this;
        if (this.categoryCheck(this.category_id) == true) {
            if (this.selectedFiles.length == 0) {
                this.appC.popToast({ type: "error", body: "No file selected" });
                return;
            }
            if (this.duplicateFileCheck() == false) {
                this.appC.popToast({ type: "error", body: "File already exists" });
                return;
            }
            this.uploadStatus.emit(true);
            var path_1 = "";
            var institute_id = sessionStorage.getItem("institute_id");
            path_1 = this.pathArray.join('/') + '/';
            var formData_1 = new FormData();
            // formData.append("file", this.selectedFiles[0]);
            var arr = Array.from(this.selectedFiles);
            arr.map(function (ele, index) {
                formData_1.append("file_" + index, ele);
            });
            var base = this.auth.getBaseUrl();
            var urlPostXlsDocument = base + "/api/v1/instFileSystem/createFiles";
            var newxhr_1 = new XMLHttpRequest();
            var auths = {
                userid: sessionStorage.getItem('userid'),
                userType: sessionStorage.getItem('userType'),
                password: sessionStorage.getItem('password'),
                institution_id: sessionStorage.getItem('institute_id'),
            };
            var Authorization = btoa(auths.userid + "|" + auths.userType + ":" + auths.password + ":" + auths.institution_id);
            newxhr_1.open("POST", urlPostXlsDocument, true);
            // newxhr.setRequestHeader("Pragma", "no-cache");
            // newxhr.setRequestHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            // newxhr.setRequestHeader("processData", "false");
            newxhr_1.setRequestHeader("category_id", this.category_id.toString());
            newxhr_1.setRequestHeader("institute_id", institute_id);
            newxhr_1.setRequestHeader("Authorization", Authorization);
            newxhr_1.setRequestHeader("enctype", "multipart/form-data;");
            newxhr_1.setRequestHeader("keyName", path_1);
            newxhr_1.setRequestHeader("Accept", "application/json, text/javascript");
            // newxhr.setRequestHeader("contentType", "false");
            // newxhr.setRequestHeader("dataType", "json");
            newxhr_1.setRequestHeader("Access-Control-Allow-Origin", "*");
            this.isUploadingXls = true;
            var _loop_1 = function (file) {
                newxhr_1.upload.addEventListener('progress', function (e) {
                    if (e.lengthComputable) {
                        _this.progress = Math.round((e.loaded * 100) / e.total);
                        document.getElementById('progress-width').style.width = _this.progress + '%';
                        _this.fileLoading = file.name;
                    }
                }, false);
            };
            for (var _i = 0, _a = this.tempArr; _i < _a.length; _i++) {
                var file = _a[_i];
                _loop_1(file);
            }
            newxhr_1.onreadystatechange = function () {
                if (newxhr_1.readyState == 4) {
                    _this.progress = 0;
                    if (newxhr_1.status >= 200 && newxhr_1.status < 300) {
                        _this.isUploadingXls = false;
                        var data = {
                            type: 'success',
                            title: "File uploaded successfully",
                            body: newxhr_1.response.fileName
                        };
                        _this.appC.popToast(data);
                        _this.uploadStatus.emit(false);
                        _this.manualUpload = false;
                        _this.filePath.emit(path_1);
                        _this.closePopupValue.emit(false);
                        _this.getFilesAndFolder.emit(newxhr_1.status);
                    }
                    else {
                        _this.isUploadingXls = false;
                        _this.uploadStatus.emit(false);
                        var data = {
                            type: 'error',
                            title: "File uploaded failed",
                            body: newxhr_1.response.fileName
                        };
                        _this.appC.popToast(data);
                    }
                }
            };
            newxhr_1.send(formData_1);
        }
    };
    UploadPopupComponent.prototype.duplicateFileCheck = function () {
        for (var i = 0; i < this.selectedFiles.length; i++) {
            for (var j = 0; j < this.currentFilesArray.length; j++) {
                if (this.selectedFiles[i].name == this.currentFilesArray[j].file_name) {
                    return false;
                }
            }
        }
        return true;
    };
    UploadPopupComponent.prototype.categoryCheck = function (id) {
        if (this.category_id == '-1') {
            this.createErrorToast("Please select a category");
            return false;
        }
        else {
            this.type = Object.keys(this.acceptedFiles[this.category_id]).join();
            for (var i = 0; i < this.selectedFiles.length; i++) {
                var type = this.getType(this.selectedFiles[i].name);
                if (this.acceptedFiles[this.category_id].hasOwnProperty(type) == false) {
                    this.createErrorToast("File doesn\'t match with the selected category ");
                    return false;
                }
            }
            return true;
        }
    };
    UploadPopupComponent.prototype.fillFiles = function (files) {
        var _this = this;
        setTimeout(function () {
            var manualUploadedFileList = document.getElementById('uploadFileControl').files;
            var filesArr = Array.from(manualUploadedFileList);
            _this.selectedFiles = filesArr;
            _this.customFileArr = _this.generateFilePreview(_this.selectedFiles);
        }, 500);
    };
    UploadPopupComponent.prototype.createErrorToast = function (message) {
        var msg = {
            type: "error",
            body: message
        };
        this.appC.popToast(msg);
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('icon'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], UploadPopupComponent.prototype, "icon", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], UploadPopupComponent.prototype, "closePopupValue", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], UploadPopupComponent.prototype, "selectedFiles", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], UploadPopupComponent.prototype, "currentFolder", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Object)
    ], UploadPopupComponent.prototype, "fetchPrefillFolderAndFiles", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Boolean)
    ], UploadPopupComponent.prototype, "manualUpload", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], UploadPopupComponent.prototype, "pathArray", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])(),
        __metadata("design:type", Array)
    ], UploadPopupComponent.prototype, "currentFilesArray", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], UploadPopupComponent.prototype, "getFilesAndFolder", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], UploadPopupComponent.prototype, "filesAndFolder", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], UploadPopupComponent.prototype, "filePath", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])(),
        __metadata("design:type", Object)
    ], UploadPopupComponent.prototype, "uploadStatus", void 0);
    UploadPopupComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-upload-popup',
            template: __webpack_require__("./src/app/components/course-module/file-manager/upload-popup/upload-popup.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/file-manager/upload-popup/upload-popup.component.scss")],
            changeDetection: __WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectionStrategy"].OnPush
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_0__angular_core__["ChangeDetectorRef"],
            __WEBPACK_IMPORTED_MODULE_1__file_manager_service__["a" /* FileManagerService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], UploadPopupComponent);
    return UploadPopupComponent;
}());



/***/ })

});
//# sourceMappingURL=file-manager.module.chunk.js.map