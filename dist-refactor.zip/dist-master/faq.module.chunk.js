webpackJsonp(["faq.module"],{

/***/ "./src/app/components/help-home/faq/faq-card/faq-card.component.html":
/***/ (function(module, exports) {

module.exports = "<h1>FAQ Cards</h1>"

/***/ }),

/***/ "./src/app/components/help-home/faq/faq-card/faq-card.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/help-home/faq/faq-card/faq-card.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FAQCardComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FAQCardComponent = /** @class */ (function () {
    function FAQCardComponent() {
    }
    FAQCardComponent.prototype.ngOnChanges = function () {
    };
    FAQCardComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'faq-card',
            template: __webpack_require__("./src/app/components/help-home/faq/faq-card/faq-card.component.html"),
            styles: [__webpack_require__("./src/app/components/help-home/faq/faq-card/faq-card.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], FAQCardComponent);
    return FAQCardComponent;
}());



/***/ }),

/***/ "./src/app/components/help-home/faq/faq-head/faq-head.component.html":
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar navbar-default\" role=\"navigation\">\r\n    <!-- Brand and toggle get grouped for better mobile display -->\r\n    <div class=\"navbar-header\">\r\n        <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">\r\n            <span class=\"sr-only\">Toggle navigation</span>\r\n            <span class=\"icon-bar\"></span>\r\n            <span class=\"icon-bar\"></span>\r\n            <span class=\"icon-bar\"></span>\r\n        </button>\r\n        <a class=\"navbar-brand\"><h1>Help - Proctur </h1></a>\r\n    </div>\r\n\r\n    <!-- Collect the nav links, forms, and other content for toggling -->\r\n    <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">\r\n        <ul class=\"nav navbar-nav\">\r\n            <li class=\"active\">\r\n                <a>FAQ</a>\r\n            </li>\r\n            <li>\r\n                <a>Videos</a>\r\n            </li>\r\n            <!-- <li class=\"dropdown\">\r\n                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\">Some drop menu\r\n                    <b class=\"caret\"></b>\r\n                </a>\r\n                <ul class=\"dropdown-menu\">\r\n                    <li class=\"divider\"></li>\r\n                    <li>\r\n                        <a>Menu1</a>\r\n                    </li>\r\n                    <li>\r\n                        <a>Menu2</a>\r\n                    </li>\r\n                    <li>\r\n                        <a>Menu3</a>\r\n                    </li>\r\n                    <li class=\"divider\"></li>\r\n                </ul>\r\n            </li> -->\r\n        </ul>\r\n        <div class=\"col-sm-3 col-md-3\">\r\n            <form class=\"navbar-form\" role=\"search\">\r\n                <div class=\"input-group\">\r\n                    <input type=\"text\" class=\"form-control\" placeholder=\"Search\" name=\"q\">\r\n                    <div class=\"input-group-btn\">\r\n                        <button class=\"btn btn-default\" type=\"submit\">\r\n                            <i class=\"glyphicon glyphicon-search\"></i>\r\n                        </button>\r\n                    </div>\r\n                </div>\r\n            </form>\r\n        </div>\r\n        <ul class=\"nav navbar-nav navbar-right\">\r\n            <li>\r\n                <a>Generate Online Ticket</a>\r\n            </li>\r\n            <li class=\"dropdown\">\r\n                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\">Contact Us\r\n                    <b class=\"caret\"></b>\r\n                </a>\r\n                <ul class=\"dropdown-menu\">\r\n                    <li>\r\n                        <a>Call Us</a>\r\n                    </li>\r\n                    <li>\r\n                        <a>Email Support</a>\r\n                    </li>\r\n                    <li>\r\n                        <a>Write To Us</a>\r\n                    </li>\r\n                </ul>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n</nav>"

/***/ }),

/***/ "./src/app/components/help-home/faq/faq-head/faq-head.component.scss":
/***/ (function(module, exports) {

module.exports = ".navbar-default {\n  background-color: #1da2e8; }\n\n.navbar-default .navbar-brand {\n  color: #fff; }\n\n.navbar-default .navbar-nav > li > a {\n  color: #000;\n  font-size: 14px;\n  font-weight: 400; }\n\n.navbar-default .navbar-nav > .active > a,\n.navbar-default .navbar-nav > .active > a:focus,\n.navbar-default .navbar-nav > .active > a:hover {\n  color: #FFF;\n  background-color: #0060a3; }\n\na {\n  cursor: pointer; }\n"

/***/ }),

/***/ "./src/app/components/help-home/faq/faq-head/faq-head.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FAQHeadComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FAQHeadComponent = /** @class */ (function () {
    function FAQHeadComponent() {
    }
    FAQHeadComponent.prototype.ngOnChanges = function () {
    };
    FAQHeadComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'faq-head',
            template: __webpack_require__("./src/app/components/help-home/faq/faq-head/faq-head.component.html"),
            styles: [__webpack_require__("./src/app/components/help-home/faq/faq-head/faq-head.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], FAQHeadComponent);
    return FAQHeadComponent;
}());



/***/ }),

/***/ "./src/app/components/help-home/faq/faq-home/faq-home.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"middle-section clearFix\">\r\n    <faq-card></faq-card>\r\n</section>"

/***/ }),

/***/ "./src/app/components/help-home/faq/faq-home/faq-home.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/help-home/faq/faq-home/faq-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FAQHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FAQHomeComponent = /** @class */ (function () {
    function FAQHomeComponent() {
    }
    FAQHomeComponent.prototype.ngOnInit = function () {
    };
    FAQHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'faq-home',
            template: __webpack_require__("./src/app/components/help-home/faq/faq-home/faq-home.component.html"),
            styles: [__webpack_require__("./src/app/components/help-home/faq/faq-home/faq-home.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], FAQHomeComponent);
    return FAQHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/help-home/faq/faq-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FAQRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__faq_head_faq_head_component__ = __webpack_require__("./src/app/components/help-home/faq/faq-head/faq-head.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__faq_home_faq_home_component__ = __webpack_require__("./src/app/components/help-home/faq/faq-home/faq-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__faq_sidenav_faq_sidenav_component__ = __webpack_require__("./src/app/components/help-home/faq/faq-sidenav/faq-sidenav.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__faq_component__ = __webpack_require__("./src/app/components/help-home/faq/faq.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var FAQRoutingModule = /** @class */ (function () {
    function FAQRoutingModule() {
    }
    FAQRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_5__faq_component__["a" /* FAQComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: "",
                                redirectTo: 'home'
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_3__faq_home_faq_home_component__["a" /* FAQHomeComponent */],
                            },
                            {
                                path: "",
                                component: __WEBPACK_IMPORTED_MODULE_4__faq_sidenav_faq_sidenav_component__["a" /* FAQSidenavComponent */],
                                outlet: "sidebar"
                            },
                            {
                                path: "",
                                component: __WEBPACK_IMPORTED_MODULE_2__faq_head_faq_head_component__["a" /* FAQHeadComponent */],
                                outlet: "header"
                            },
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], FAQRoutingModule);
    return FAQRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/help-home/faq/faq-sidenav/faq-sidenav.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"help-sidenav\">\r\n    <ul>\r\n        <li class=\"main-element\" #MainElement *ngFor=\"let item of helpList; let i = index;\">\r\n            <div id=\"{{item.id}}\" (click)=\"toggleVisiblity(i)\" class=\"main-item\">\r\n                {{item.name}}\r\n            </div>\r\n\r\n            <ul class=\"sub-element-holder hide\">\r\n                <li id=\"{{child.id}}\" class=\"sub-element\" *ngFor=\"let child of item.children\">\r\n                    {{child.name}}\r\n                </li>\r\n            </ul>\r\n\r\n        </li>\r\n    </ul>\r\n</div>"

/***/ }),

/***/ "./src/app/components/help-home/faq/faq-sidenav/faq-sidenav.component.scss":
/***/ (function(module, exports) {

module.exports = ".help-sidenav {\n  width: 150px; }\n  .help-sidenav ul {\n    list-style: none; }\n  .help-sidenav ul li {\n      cursor: pointer; }\n  .help-sidenav ul li.main-element .main-item {\n        -webkit-box-shadow: 0px 0px 2px 1px #777;\n                box-shadow: 0px 0px 2px 1px #777;\n        padding: 10px;\n        background: #ffffff;\n        -webkit-box-sizing: border-box;\n                box-sizing: border-box;\n        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;\n        font-size: 14px;\n        text-align: center;\n        font-weight: 600;\n        text-transform: uppercase;\n        text-rendering: optimizeSpeed;\n        -webkit-font-feature-settings: initial;\n                font-feature-settings: initial; }\n  .help-sidenav ul li.main-element ul.sub-element-holder {\n        margin: 5px 0px; }\n  .help-sidenav ul li.main-element ul.sub-element-holder .sub-element {\n          padding: 10px;\n          background: #212121;\n          color: #ffffff; }\n  .help-sidenav ul li.main-element ul.sub-element-holder .sub-element:hover {\n            background: #fff;\n            color: #212121; }\n"

/***/ }),

/***/ "./src/app/components/help-home/faq/faq-sidenav/faq-sidenav.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FAQSidenavComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FAQSidenavComponent = /** @class */ (function () {
    function FAQSidenavComponent() {
        this.elementList = [];
    }
    FAQSidenavComponent.prototype.ngOnInit = function () {
        this.helpList = [
            {
                name: "Enquiry", id: "Enquiry_help", icon: "", children: [
                    { name: "Enquiry Add", id: "Enquiry_Add", icon: "" },
                    { name: "Enquiry Update", id: "Enquiry_Update", icon: "" },
                    { name: "Enquiry Edit", id: "Enquiry_Edit", icon: "" },
                    { name: "Enquiry Convert", id: "Enquiry_Convert", icon: "" },
                    { name: "Enquiry Delete", id: "Enquiry_Delete", icon: "" },
                    { name: "Enquiry Upload", id: "Enquiry_Upload", icon: "" },
                    { name: "Enquiry Registration Fee", id: "Enquiry_Registration", icon: "" },
                    { name: "Enquiry Export", id: "Enquiry_Export", icon: "" },
                    { name: "Enquiry Summary Download", id: "Enquiry_Summary", icon: "" },
                ]
            },
            {
                name: "Student", id: "Student_help", icon: "", children: [
                    { name: "Student Admission", id: "Student_Admission", icon: "" },
                    { name: "Student Course/Batch Management", id: "Student_Course_Management", icon: "" },
                    { name: "Student Fee Management", id: "Student_Fee_Management", icon: "" },
                    { name: "Student Upload", id: "Student_Upload", icon: "" },
                    { name: "Student Inventory Management", id: "Student_Inventory_Management", icon: "" },
                    { name: "Student Delete", id: "Student_Delete", icon: "" },
                    { name: "Student Leave Management", id: "Student_Leave_Management", icon: "" },
                ]
            },
            {
                name: "Course", id: "Course_help", icon: "", children: [
                    { name: "Standard Management", id: "Standard_Management", icon: "" },
                    { name: "Subject Management", id: "Subject_Management", icon: "" },
                    { name: "Course Management", id: "Course_Management", icon: "" },
                    { name: "Class Management", id: "Class_Management", icon: "" },
                    { name: "Exam Management", id: "Exam_Management", icon: "" },
                ]
            },
            {
                name: "Activity", id: "Activity_help", icon: "", children: [
                    { name: "Cheque Management", id: "Cheque_Management", icon: "" },
                    { name: "Archive", id: "Archive", icon: "" },
                    { name: "Monitoring Dashboard", id: "Monitoring_Dashboard", icon: "" },
                    { name: "Parent Teacher Meet", id: "PTM", icon: "" },
                    { name: "Fee Management", id: "Fee_Management", icon: "" },
                ]
            },
            {
                name: "Report", id: "Report_help", icon: "", children: [
                    { name: "SMS Reports", id: "SMS_Reports", icon: "" },
                    { name: "Attendance Reports", id: "Attendance_Reports", icon: "" },
                    { name: "Fee Reports", id: "Fee_Reports", icon: "" },
                    { name: "Exam Reports", id: "Exam_Reports", icon: "" },
                    { name: "Time Table", id: "Time_Table", icon: "" },
                    { name: "Email Reports", id: "Email_Reports", icon: "" },
                    { name: "Enquiry Reports", id: "Enquiry_Reports", icon: "" },
                ]
            },
            {
                name: "Inventory", id: "Inventory_help", icon: "", children: [
                    { name: "Category Management", id: "Category_Management", icon: "" },
                    { name: "Add/Remove Inventory", id: "AR_Inventory", icon: "" },
                    { name: "Multi Branch Inventory Management", id: "MB_Inventory", icon: "" },
                    { name: "Employee Inventory Management", id: "E_Inventory", icon: "" },
                ]
            },
            {
                name: "Campaign", id: "Campaign_help", icon: "", children: [
                    { name: "Campaign Management", id: "Campaign Management", icon: "" },
                    { name: "Campaign Upload", id: "", icon: "" },
                    { name: "Campaign SMS Promotion", id: "", icon: "" },
                    { name: "Campaign Convertion", id: "", icon: "" },
                ]
            },
        ];
    };
    FAQSidenavComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        this.elementList = [];
        this.element.forEach(function (e) {
            _this.elementList.push(e);
        });
    };
    FAQSidenavComponent.prototype.toggleVisiblity = function (i) {
        this.elementList.forEach(function (e, index) {
            if (index == i) {
                e.nativeElement.children[1].classList.toggle('hide');
            }
            else {
                e.nativeElement.children[1].classList.add('hide');
            }
        });
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChildren"])('MainElement'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["QueryList"])
    ], FAQSidenavComponent.prototype, "element", void 0);
    FAQSidenavComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'faq-sidenav',
            template: __webpack_require__("./src/app/components/help-home/faq/faq-sidenav/faq-sidenav.component.html"),
            styles: [__webpack_require__("./src/app/components/help-home/faq/faq-sidenav/faq-sidenav.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], FAQSidenavComponent);
    return FAQSidenavComponent;
}());



/***/ }),

/***/ "./src/app/components/help-home/faq/faq.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"c-lg-12\">\r\n    <router-outlet name=\"header\"></router-outlet>\r\n</div>\r\n\r\n<div class=\"c-lg-2 pull-left\">\r\n    <router-outlet name=\"sidebar\"></router-outlet>\r\n</div>\r\n<div class=\"c-lg-10\">\r\n    <router-outlet></router-outlet>\r\n</div>"

/***/ }),

/***/ "./src/app/components/help-home/faq/faq.component.scss":
/***/ (function(module, exports) {

module.exports = ".help-container {\n  display: inline; }\n"

/***/ }),

/***/ "./src/app/components/help-home/faq/faq.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FAQComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FAQComponent = /** @class */ (function () {
    function FAQComponent() {
    }
    FAQComponent.prototype.ngOnInit = function () {
    };
    FAQComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'faq',
            template: __webpack_require__("./src/app/components/help-home/faq/faq.component.html"),
            styles: [__webpack_require__("./src/app/components/help-home/faq/faq.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], FAQComponent);
    return FAQComponent;
}());



/***/ }),

/***/ "./src/app/components/help-home/faq/faq.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FaqModule", function() { return FaqModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__faq_routing_module__ = __webpack_require__("./src/app/components/help-home/faq/faq-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__faq_home_faq_home_component__ = __webpack_require__("./src/app/components/help-home/faq/faq-home/faq-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__faq_component__ = __webpack_require__("./src/app/components/help-home/faq/faq.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__faq_card_faq_card_component__ = __webpack_require__("./src/app/components/help-home/faq/faq-card/faq-card.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__faq_sidenav_faq_sidenav_component__ = __webpack_require__("./src/app/components/help-home/faq/faq-sidenav/faq-sidenav.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__faq_head_faq_head_component__ = __webpack_require__("./src/app/components/help-home/faq/faq-head/faq-head.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var FaqModule = /** @class */ (function () {
    function FaqModule() {
    }
    FaqModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_4__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_5__faq_routing_module__["a" /* FAQRoutingModule */]
            ],
            exports: [],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_6__faq_home_faq_home_component__["a" /* FAQHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_8__faq_card_faq_card_component__["a" /* FAQCardComponent */],
                __WEBPACK_IMPORTED_MODULE_7__faq_component__["a" /* FAQComponent */],
                __WEBPACK_IMPORTED_MODULE_9__faq_sidenav_faq_sidenav_component__["a" /* FAQSidenavComponent */],
                __WEBPACK_IMPORTED_MODULE_10__faq_head_faq_head_component__["a" /* FAQHeadComponent */]
            ],
            entryComponents: [
                __WEBPACK_IMPORTED_MODULE_8__faq_card_faq_card_component__["a" /* FAQCardComponent */],
                __WEBPACK_IMPORTED_MODULE_9__faq_sidenav_faq_sidenav_component__["a" /* FAQSidenavComponent */],
                __WEBPACK_IMPORTED_MODULE_10__faq_head_faq_head_component__["a" /* FAQHeadComponent */]
            ],
            providers: []
        })
    ], FaqModule);
    return FaqModule;
}());



/***/ })

});
//# sourceMappingURL=faq.module.chunk.js.map