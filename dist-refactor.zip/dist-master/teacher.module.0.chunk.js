webpackJsonp(["teacher.module.0"],{

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-add/teacher-add.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"clearfix\">\r\n  <div class=\"row\">\r\n    <h2 class=\"pull-left\" style=\"margin-left:15px\">Add Faculty</h2>\r\n  </div>\r\n  <aside class=\"c-lg-6 c-md-6 c-sm-6\">\r\n    <div class=\"pull-left\">\r\n      <form [formGroup]=\"addTeacherForm\" novalidate (ngSubmit)=\"addNewTeacherInfo()\">\r\n        <div class=\"row field-wrapper\">\r\n          <label for=\"name\">Faculty Name\r\n            <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <input type=\"text\" class=\"form-ctrl\" formControlName=\"teacher_name\" name=\"name\">\r\n\r\n          <div *ngIf=\"addTeacherForm.controls['teacher_name'].invalid && (addTeacherForm.controls['teacher_name'].dirty || addTeacherForm.controls['teacher_name'].touched)\"\r\n            class=\"alert alert-danger\">\r\n            <div *ngIf=\"addTeacherForm.controls['teacher_name'].hasError('required')\">\r\n              Faculty Name is required.\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row field-wrapper\">\r\n          <label for=\"contNumber\">Contact Number\r\n            <span class=\"text-danger\">*</span>\r\n          </label>\r\n          <input type=\"text\" maxlength=\"10\" class=\"form-ctrl\" formControlName=\"teacher_phone\" name=\"contNumber\">\r\n\r\n          <div *ngIf=\"addTeacherForm.controls['teacher_phone'].invalid && (addTeacherForm.controls['teacher_phone'].dirty || addTeacherForm.controls['teacher_phone'].touched)\"\r\n            class=\"alert alert-danger\">\r\n            <div *ngIf=\"addTeacherForm.controls['teacher_phone'].hasError('required')\">\r\n              Contact Number is required.\r\n            </div>\r\n            <div *ngIf=\"addTeacherForm.controls['teacher_phone'].hasError('minlength')\">\r\n              Contact Number is not valid.\r\n            </div>\r\n            <div *ngIf=\"addTeacherForm.controls['teacher_phone'].hasError('maxlength')\">\r\n              Contact Number is not valid.\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"row field-wrapper\">\r\n          <label for=\"emailID\">Email Id\r\n          </label>\r\n          <input type=\"email\" class=\"form-ctrl\" name=\"emailID\" pattern=\"[a-zA-Z0-9._%+-]+@[a-zA-Z]+\\.[a-zA-Z.]{2,5}$\" formControlName=\"teacher_email\">\r\n        </div>\r\n        <div class=\"row field-wrapper\">\r\n          <label for=\"CurrentAddress\">Current Address\r\n          </label>\r\n          <input type=\"text\" class=\"form-ctrl\" formControlName=\"teacher_curr_addr\" name=\"CurrentAddress\">\r\n        </div>\r\n        <div class=\"row field-wrapper\">\r\n          <label for=\"alternateNo\">Alternate Contact Number\r\n          </label>\r\n          <input type=\"text\" maxlength=\"10\" class=\"form-ctrl\" name=\"alternateNo\" formControlName=\"teacher_alt_phone\">\r\n        </div>\r\n        <div class=\"row field-wrapper\">\r\n          <label for=\"standard\">Standard\r\n          </label>\r\n          <input type=\"text\" class=\"form-ctrl\" name=\"standard\" formControlName=\"teacher_standards\">\r\n        </div>\r\n        <div class=\"row field-wrapper\">\r\n          <label for=\"subject\">Subjects\r\n          </label>\r\n          <input type=\"text\" class=\"form-ctrl\" name=\"subject\" formControlName=\"teacher_subjects\">\r\n\r\n        </div>\r\n        <div class=\"row field-wrapper\">\r\n          <label for=\"salary\">Salary (Per Hour)\r\n          </label>\r\n          <input type=\"text\" class=\"form-ctrl\" name=\"salary\" formControlName=\"hour_rate\">\r\n\r\n        </div>\r\n        <div class=\"row field-wrapper\" *ngIf=\"enableBiometric == '1'\">\r\n          <label for=\"biometric\">Attendance Card ID\r\n          </label>\r\n          <input type=\"text\" class=\"form-ctrl\" name=\"biometric\" formControlName=\"attendance_device_id\">\r\n\r\n        </div>\r\n        <div class=\"extra-margin\" style=\"margin-top: 15px;\">\r\n\r\n          <div class=\"field-checkbox-wrapper\" style=\"margin-left: -40px;\">\r\n            <div class=\"field-checkbox-wrapper\">\r\n              <input type=\"checkbox\" value=\"\" name=\"isActive\" formControlName=\"is_active\" class=\"form-checkbox\">\r\n              <label for=\"isActive\">Is Active</label>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"field-checkbox-wrapper\" style=\"margin-left: -40px;\">\r\n            <div class=\"field-checkbox-wrapper\">\r\n              <input type=\"checkbox\" value=\"\" name=\"allow\" formControlName=\"is_allow_teacher_to_only_mark_attendance\" class=\"form-checkbox\">\r\n              <label for=\"allow\">Allow faculty to only mark attendance</label>\r\n            </div>\r\n          </div>\r\n\r\n\r\n          <!-- <div class=\"field-checkbox-wrapper\" style=\"margin-left: -40px;\">\r\n            <div class=\"field-checkbox-wrapper\">\r\n              <input type=\"checkbox\" value=\"\" name=\"markAttendance\" formControlName=\"is_student_mgmt_flag\" class=\"form-checkbox\">\r\n              <label for=\"markAttendance\">Allow faculty to view Contact details of student</label>\r\n            </div>\r\n          </div> -->\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"pull-right\">\r\n            <button routerLink=\"/view/course/setup/teacher\" class=\"btn\">Cancel</button>\r\n            <button [disabled]='!addTeacherForm.valid' class=\"btn fullBlue\" style=\"font-size: 16px;height: 40px;\" type=\"submit\">Save</button>\r\n          </div>\r\n        </div>\r\n      </form>\r\n    </div>\r\n  </aside>\r\n  <aside class=\"c-lg-6 c-md-6 c-sm-6\">\r\n    <proctur-image [serverImg]=\"studentImage\" [containerWidth]=\"containerWidth\" (setImage)=\"setImage($event)\">\r\n\r\n    </proctur-image>\r\n  </aside>\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-add/teacher-add.component.scss":
/***/ (function(module, exports) {

module.exports = "input[type=number]::-webkit-inner-spin-button,\ninput[type=number]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0; }\n\n.countryCallingCode {\n  float: left;\n  border-left: solid 1px #e2ebee;\n  border-bottom: solid 1px #e2ebee;\n  border-top: solid 1px #e2ebee;\n  padding-bottom: 2%;\n  padding-top: 1%;\n  padding-right: 1%;\n  padding-left: 1%; }\n"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-add/teacher-add.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TeacherAddComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_teacherService_teacherApi_service__ = __webpack_require__("./src/app/services/teacherService/teacherApi.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__app_component__ = __webpack_require__("./src/app/app.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var TeacherAddComponent = /** @class */ (function () {
    function TeacherAddComponent(fb, teacherAPIService, route, toastCtrl) {
        this.fb = fb;
        this.teacherAPIService = teacherAPIService;
        this.route = route;
        this.toastCtrl = toastCtrl;
        this.studentImage = '';
        this.containerWidth = "200px";
        this.enableBiometric = 0;
    }
    TeacherAddComponent.prototype.ngOnInit = function () {
        this.createAddTeacherForm();
        this.enableBiometric = sessionStorage.getItem('biometric_attendance_feature');
    };
    TeacherAddComponent.prototype.createAddTeacherForm = function () {
        this.addTeacherForm = this.fb.group({
            teacher_name: ['', [__WEBPACK_IMPORTED_MODULE_1__angular_forms__["Validators"].required]],
            teacher_curr_addr: [''],
            teacher_phone: ['', [__WEBPACK_IMPORTED_MODULE_1__angular_forms__["Validators"].required, __WEBPACK_IMPORTED_MODULE_1__angular_forms__["Validators"].minLength(10), __WEBPACK_IMPORTED_MODULE_1__angular_forms__["Validators"].maxLength(10)]],
            teacher_alt_phone: [''],
            teacher_standards: [''],
            teacher_email: [''],
            teacher_subjects: [''],
            hour_rate: [''],
            attendance_device_id: [''],
            is_active: [true],
            is_allow_teacher_to_only_mark_attendance: [false],
            is_student_mgmt_flag: [true]
        });
    };
    TeacherAddComponent.prototype.addNewTeacherInfo = function () {
        var _this = this;
        var formData = this.addTeacherForm.value;
        if (!this.validateCaseSensitiveEmail(formData.teacher_email)) {
            this.messageToast('error', '', 'Please enter valid email address.');
            return;
        }
        if (!(this.validateNumber(formData.teacher_phone))) {
            this.messageToast('error', '', 'Please enter valid contact number.');
            return;
        }
        if (formData.teacher_alt_phone != '' && formData.teacher_alt_phone != null) {
            if (!(this.validateNumber(formData.teacher_alt_phone))) {
                this.messageToast('error', '', 'Please enter valid alternate phone number.');
                return;
            }
        }
        if (formData.hour_rate == "" || formData.hour_rate == null) {
            formData.hour_rate = 0;
        }
        if (this.studentImage != null && this.studentImage != "") {
            formData.photo = this.studentImage;
        }
        else {
            formData.photo = null;
        }
        if (formData.is_student_mgmt_flag == true) {
            formData.is_student_mgmt_flag = 1;
        }
        else {
            formData.is_student_mgmt_flag = 0;
        }
        if (formData.is_active == true) {
            formData.is_active = "Y";
        }
        else {
            formData.is_active = "N";
        }
        if (formData.is_allow_teacher_to_only_mark_attendance == true) {
            formData.is_allow_teacher_to_only_mark_attendance = "Y";
        }
        else {
            formData.is_allow_teacher_to_only_mark_attendance = "N";
        }
        formData.is_employee_to_be_create = "N";
        this.teacherAPIService.addNewTeacherDetails(formData).subscribe(function (data) {
            _this.messageToast('success', 'Added', 'Faculty Added Successfully.');
            _this.route.navigateByUrl('/view/course/setup/teacher');
        }, function (err) {
            _this.messageToast('error', '', err.error.message);
        });
    };
    TeacherAddComponent.prototype.messageToast = function (errorType, errorTitle, errorMeassage) {
        var data = {
            type: errorType,
            title: errorTitle,
            body: errorMeassage
        };
        this.toastCtrl.popToast(data);
    };
    TeacherAddComponent.prototype.validateCaseSensitiveEmail = function (email) {
        if (email != '' && email != null) {
            var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
            if (reg.test(email)) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return true;
        }
    };
    TeacherAddComponent.prototype.validateNumber = function (inputtxt) {
        var phoneno = /^\d{10}$/;
        if ((inputtxt.match(phoneno))) {
            return true;
        }
        else {
            return false;
        }
    };
    TeacherAddComponent.prototype.setImage = function (e) {
        this.studentImage = e;
    };
    TeacherAddComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-teacher-add',
            template: __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-add/teacher-add.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-add/teacher-add.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_forms__["FormBuilder"],
            __WEBPACK_IMPORTED_MODULE_2__services_teacherService_teacherApi_service__["a" /* TeacherAPIService */],
            __WEBPACK_IMPORTED_MODULE_3__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_4__app_component__["a" /* AppComponent */]])
    ], TeacherAddComponent);
    return TeacherAddComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-edit/teacher-edit.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"middle-section clearFix\">\r\n    <loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper black-bg\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n    </loaders-css>\r\n    <section class=\"middle-top mb0 clearFix\" style=\"margin-bottom: 10px;\">\r\n        <h1 class=\"pull-left\" *ngIf=\"selectedTeacherId==undefined\">\r\n            Add Faculty\r\n        </h1>\r\n        <h1 class=\"pull-left\" *ngIf=\"selectedTeacherId != undefined\">\r\n            Edit Faculty\r\n        </h1>\r\n    </section>\r\n\r\n    <section class=\"middle-main clearFix\">\r\n\r\n        <aside class=\"c-lg-6 c-md-6 c-sm-6\">\r\n            <div class=\"pull-left\">\r\n                <form [formGroup]=\"editTeacherForm\" novalidate (ngSubmit)=\"addOrEditFun()\">\r\n                    <div class=\"row field-wrapper\">\r\n                        <label for=\"name\">Faculty Name\r\n                            <span class=\"text-danger\">*</span>\r\n                        </label>\r\n                        <input type=\"text\" class=\"form-ctrl\" formControlName=\"teacher_name\" name=\"name\">\r\n\r\n                        <div *ngIf=\"editTeacherForm.controls['teacher_name'].invalid && (editTeacherForm.controls['teacher_name'].dirty || editTeacherForm.controls['teacher_name'].touched)\"\r\n                            class=\"alert alert-danger\">\r\n                            <div *ngIf=\"editTeacherForm.controls['teacher_name'].hasError('required')\">\r\n                                Faculty Name is required.\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                    <div class=\"row field-wrapper\">\r\n                        <label for=\"contNumber\">Contact Number\r\n                            <span class=\"text-danger\">*</span>\r\n                        </label><br>\r\n                        <span class=\"countryCallingCode\"style=\"width: 30%\">\r\n                                <select id=\"country_id\" class=\"form-ctrl\" formControlName=\"country_id\" name=\"country\"\r\n                                [disabled]=\"countryDetails.length<=1\" (change)=\"onChangeObj($event.target.value)\" style=\"height: 29px;padding: 0\">\r\n                                <option value=\"\"></option>\r\n                                <option [value]=\"data.id\" selected *ngFor='let data of countryDetails'>\r\n                                  {{data.country_code}} +{{data.country_calling_code}}\r\n                                </option>\r\n                              </select>\r\n                        </span>\r\n\r\n                        <input type=\"text\" onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\"\r\n                         style=\"width: 70%\"  class=\"form-ctrl\" formControlName=\"teacher_phone\" name=\"contNumber\" required>\r\n\r\n                        <div *ngIf=\"editTeacherForm.controls['teacher_phone'].invalid && (editTeacherForm.controls['teacher_phone'].dirty || editTeacherForm.controls['teacher_phone'].touched)\"\r\n                            class=\"alert alert-danger\">\r\n                            <div *ngIf=\"editTeacherForm.controls['teacher_phone'].hasError('required')\">\r\n                                Contact Number is required.\r\n                            </div>\r\n                            <div *ngIf=\"editTeacherForm.controls['teacher_phone'].hasError('minlength')\">\r\n                                Contact Number is not valid.\r\n                            </div>\r\n                            <div *ngIf=\"editTeacherForm.controls['teacher_phone'].hasError('maxlength')\">\r\n                                Contact Number is not valid.\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"row field-wrapper\">\r\n                        <label for=\"emailID\">Email Id\r\n                        </label>\r\n                        <input type=\"email\" class=\"form-ctrl\" name=\"emailID\" formControlName=\"teacher_email\">\r\n                    </div>\r\n                    <div class=\"row field-wrapper\">\r\n                        <label for=\"CurrentAddress\">Current Address\r\n                        </label>\r\n                        <input type=\"text\" class=\"form-ctrl\" formControlName=\"teacher_curr_addr\" name=\"CurrentAddress\">\r\n\r\n                    </div>\r\n\r\n                    <div class=\"row field-wrapper datePickerBox\">\r\n                        <label for=\"CurrentAddress\">Date of Birth\r\n                        </label>\r\n                        <input type=\"text\" class=\"form-ctrl\" readonly=\"true\" formControlName=\"dob\" name=\"dob\" bsDatepicker/>          \r\n                    </div>\r\n\r\n                    <div class=\"row field-wrapper datePickerBox\">\r\n                            <label for=\"CurrentAddress\">Date of Joining\r\n                            </label>\r\n                            <input type=\"text\" class=\"form-ctrl\" readonly=\"true\" formControlName=\"date_of_joining\" name=\"date_of_joining\" bsDatepicker/>                   \r\n                    </div>\r\n\r\n                    <div class=\"row field-wrapper\">\r\n                        <label for=\"alternateNo\">Alternate Contact Number\r\n                        </label><br>\r\n                        <span class=\"countryCallingCode\"style=\"width: 30%\">\r\n                            <select id=\"country_id\" class=\"form-ctrl\" formControlName=\"country_id\" name=\"country\" onkeypress=\"return (event.charCode >= 48 && event.charCode <= 57)\"\r\n                            [disabled]=\"countryDetails.length<=1\" (change)=\"onChangeObj($event.target.value)\" style=\"height: 29px;padding: 0\">\r\n                            <option value=\"\"></option>\r\n                            <option [value]=\"data.id\" selected *ngFor='let data of countryDetails'>\r\n                              {{data.country_code}} +{{data.country_calling_code}}\r\n                            </option>\r\n                          </select>\r\n                    </span>\r\n                        <input type=\"text\" style=\"width: 70%\" class=\"form-ctrl\" name=\"alternateNo\" formControlName=\"teacher_alt_phone\">\r\n\r\n                    </div>\r\n                    <div class=\"row field-wrapper\">\r\n                        <label for=\"standard\">Standard\r\n                        </label>\r\n                        <input type=\"text\" class=\"form-ctrl\" name=\"standard\" formControlName=\"teacher_standards\">\r\n\r\n                    </div>\r\n                    <div class=\"row field-wrapper\">\r\n                        <label for=\"subject\">Subjects\r\n                        </label>\r\n                        <input type=\"text\" class=\"form-ctrl\" name=\"subject\" formControlName=\"teacher_subjects\">\r\n\r\n                    </div>\r\n                    <div class=\"row field-wrapper\">\r\n                        <label for=\"salary\">Salary (Per Hour)\r\n                        </label>\r\n                        <input type=\"text\" class=\"form-ctrl\" name=\"salary\" formControlName=\"hour_rate\">\r\n\r\n                    </div>\r\n                    <div class=\"row field-wrapper\" *ngIf=\"enableBiometric == '1'\" [ngClass]=\"{'has-value' : attendance_device_id !=''}\">\r\n                        <label for=\"biometric\">Attendance Card ID\r\n                        </label>\r\n                        <input type=\"text\" class=\"form-ctrl\" name=\"biometric\" formControlName=\"attendance_device_id\">\r\n\r\n                    </div>\r\n                    <div class=\"extra-margin\" style=\"margin-top: 15px;\">\r\n\r\n                        <div class=\"field-checkbox-wrapper\" style=\"margin-left: -40px;\">\r\n                            <div class=\"field-checkbox-wrapper\">\r\n                                <input type=\"checkbox\" value=\"\" name=\"isActive\" formControlName=\"is_active\" class=\"form-checkbox\">\r\n                                <label for=\"isActive\">Is Active</label>\r\n                            </div>\r\n                        </div>\r\n\r\n                        <div class=\"field-checkbox-wrapper\" style=\"margin-left: -40px;\">\r\n                            <div class=\"field-checkbox-wrapper\">\r\n                                <input type=\"checkbox\" value=\"\" name=\"allow\" formControlName=\"is_allow_teacher_to_only_mark_attendance\" class=\"form-checkbox\">\r\n                                <label for=\"allow\">Allow faculty to only mark attendance</label>\r\n                            </div>\r\n                        </div>\r\n\r\n\r\n                        <!-- <div class=\"field-checkbox-wrapper\" style=\"margin-left: -40px;\">\r\n                            <div class=\"field-checkbox-wrapper\">\r\n                                <input type=\"checkbox\" value=\"\" name=\"markAttendance\" formControlName=\"is_student_mgmt_flag\" class=\"form-checkbox\">\r\n                                <label for=\"markAttendance\">Allow Faculty to view Contact details of student</label>\r\n                            </div>\r\n                        </div> -->\r\n                    </div>\r\n                    <div class=\"row\">\r\n                        <div class=\"pull-right\">\r\n                            <button routerLink=\"/view/course/setup/teacher\" class=\"btn\">Cancel</button>\r\n                            <button  class=\"btn fullBlue\" style=\"font-size: 16px;height: 40px;\" type=\"submit\">Save</button>\r\n                        </div>\r\n                    </div>\r\n                </form>\r\n            </div>\r\n        </aside>\r\n        <aside class=\"c-lg-6 c-md-6 c-sm-6\">\r\n            <div class=\"profileWrapper\">\r\n                <proctur-image [serverImg]=\"studentImage\" [containerWidth]=\"containerWidth\" (setImage)=\"setImage($event)\">\r\n\r\n                </proctur-image>\r\n            </div>\r\n            <div class=\"row\" style=\"margin-top:15%\">\r\n                <div class=\"c-sm-4 c-md-4 c-lg-4\" style=\"margin-top: 10px;padding-left: 40px\" *ngIf=\"(hasIdCard == 'Y')\">\r\n                    <fieldset>\r\n                        <legend style=\"color: #0084f6;\">Download Id-Card</legend>\r\n                        <a>\r\n                            <img #uploadedImage src=\"assets/images/download_doc.jpg\" style=\"width: 30px;\" (click)=\"downloadIdCard()\" title=\"Download Attachment\">\r\n                        </a>\r\n                        <a #uploadImageAnchor class=\"hide\"></a>\r\n                    </fieldset>\r\n                </div>\r\n                <div class=\"c-sm-4 c-md-4 c-lg-4\">\r\n                    <div class=\"field-wrapper\">\r\n                        <input class=\"hide\" type=\"file\" #idCardUpload accept=\"image/gif,image/jpeg,image/jpg,image/png\" (change)=\"onChangeIdCardUpload()\">\r\n                        <input *ngIf=\"(hasIdCard == 'Y')\" type=\"button\" class=\"btn\" value=\"Update Id-Card\" (click)=\"updateIdCard($event)\">\r\n                        <input *ngIf=\"(hasIdCard == 'N')\" type=\"button\" class=\"btn\" value=\"Upload Id-Card\" (click)=\"updateIdCard($event)\">\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </aside>\r\n\r\n    </section>\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-edit/teacher-edit.component.scss":
/***/ (function(module, exports) {

module.exports = "input[type=number]::-webkit-inner-spin-button,\ninput[type=number]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0; }\n\n.imagePreview {\n  width: 150px;\n  height: 150px; }\n\n.middle-section {\n  padding: 20px 30px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n\n.profileWrapper {\n  padding-right: 52px;\n  width: 40%;\n  height: 30%; }\n\n.imagePreview {\n  height: 150px;\n  width: 225px;\n  border-radius: 20px;\n  border: 1px solid #1f72ef; }\n\n.countryCallingCode {\n  float: left; }\n\n.black-bg {\n  background: rgba(12, 11, 11, 0.3);\n  position: fixed;\n  top: 0px;\n  height: 100%;\n  left: 0px;\n  z-index: 6;\n  width: 100%; }\n\n.field-wrapper.datePickerBox .form-ctrl {\n  z-index: 5; }\n"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-edit/teacher-edit.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TeacherEditComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_teacherService_teacherApi_service__ = __webpack_require__("./src/app/services/teacherService/teacherApi.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5____ = __webpack_require__("./src/app/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var TeacherEditComponent = /** @class */ (function () {
    function TeacherEditComponent(route, ApiService, fb, toastCtrl, routeParam, commonService) {
        var _this = this;
        this.route = route;
        this.ApiService = ApiService;
        this.fb = fb;
        this.toastCtrl = toastCtrl;
        this.routeParam = routeParam;
        this.commonService = commonService;
        this.hasIdCard = 'N';
        this.studentImage = '';
        this.containerWidth = "200px";
        this.enableBiometric = 0;
        this.instituteCountryDetObj = {};
        this.countryDetails = [];
        this.maxlength = 10;
        this.country_id = null;
        this.isRippleLoad = false;
        this.routeParam.params.subscribe(function (params) {
            _this.selectedTeacherId = params['id'];
        });
        console.log(this.selectedTeacherId);
    }
    TeacherEditComponent.prototype.ngOnInit = function () {
        this.fetchDataForCountryDetails();
        this.createEditTeacherForm();
        if (this.selectedTeacherId) {
            this.getTeacherInfo();
            this.enableBiometric = sessionStorage.getItem('biometric_attendance_feature');
        }
    };
    // created by: Nalini Walunj
    // Below two functions are written to fetch country details from the session stored at the time of login of institute
    TeacherEditComponent.prototype.fetchDataForCountryDetails = function () {
        var countryCodeEncryptedData = sessionStorage.getItem('country_data');
        var temp = JSON.parse(countryCodeEncryptedData);
        if (temp.length > 0) {
            this.countryDetails = temp;
            this.maxlength = this.countryDetails[0].country_phone_number_length;
            this.instituteCountryDetObj = this.countryDetails[0];
            this.country_id = this.countryDetails[0].id;
        }
    };
    TeacherEditComponent.prototype.onChangeObj = function (event) {
        for (var i = 0; i < this.countryDetails.length; i++) {
            if (this.countryDetails[i].id == event) {
                this.instituteCountryDetObj = this.countryDetails[i];
                this.maxlength = this.countryDetails[i].country_phone_number_length;
                this.country_id = this.countryDetails[i].id;
                this.editTeacherForm.setValue({
                    country_id: this.countryDetails[i].id,
                    teacher_name: this.editTeacherForm.value.teacher_name,
                    teacher_curr_addr: this.editTeacherForm.value.teacher_curr_addr,
                    teacher_phone: this.editTeacherForm.value.teacher_phone,
                    teacher_alt_phone: this.editTeacherForm.value.teacher_alt_phone,
                    teacher_standards: this.editTeacherForm.value.teacher_standards,
                    teacher_email: this.editTeacherForm.value.teacher_email,
                    teacher_subjects: this.editTeacherForm.value.teacher_subjects,
                    hour_rate: this.editTeacherForm.value.hour_rate,
                    attendance_device_id: this.editTeacherForm.value.attendance_device_id,
                    is_active: this.editTeacherForm.value.is_active,
                    is_allow_teacher_to_only_mark_attendance: this.editTeacherForm.value.is_allow_teacher_to_only_mark_attendance,
                    is_student_mgmt_flag: this.editTeacherForm.value.is_student_mgmt_flag,
                    dob: this.editTeacherForm.value.dob,
                    date_of_joining: this.editTeacherForm.value.date_of_joining
                });
                return;
            }
        }
    };
    TeacherEditComponent.prototype.getTeacherInfo = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.ApiService.getSelectedTeacherInfo(this.selectedTeacherId).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.selectedTeacherInfo = data;
            var setFormData = _this.getFormFieldsdata(data);
            _this.editTeacherForm.setValue(setFormData);
            _this.studentImage = data.photo;
            _this.hasIdCard = data.hasIDCard;
        }, function (error) {
            _this.isRippleLoad = false;
            console.log(error);
        });
    };
    TeacherEditComponent.prototype.createEditTeacherForm = function () {
        this.editTeacherForm = this.fb.group({
            teacher_name: ['', [__WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required]],
            teacher_curr_addr: [''],
            country_id: [this.countryDetails[0].id],
            teacher_phone: ['', [__WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required]],
            teacher_alt_phone: [''],
            teacher_standards: [''],
            teacher_email: [''],
            teacher_subjects: [''],
            hour_rate: [''],
            attendance_device_id: [''],
            is_active: [true],
            is_allow_teacher_to_only_mark_attendance: [false],
            is_student_mgmt_flag: [true],
            dob: [''],
            date_of_joining: ['']
        });
    };
    TeacherEditComponent.prototype.getFormFieldsdata = function (data) {
        var dataToBind = {};
        dataToBind.teacher_name = data.teacher_name;
        dataToBind.teacher_curr_addr = data.teacher_curr_addr;
        dataToBind.teacher_phone = data.teacher_phone;
        if (data.teacher_alt_phone == "" || data.teacher_alt_phone == null) {
            dataToBind.teacher_alt_phone = '';
        }
        else {
            dataToBind.teacher_alt_phone = data.teacher_alt_phone;
        }
        dataToBind.teacher_standards = data.teacher_standards;
        dataToBind.teacher_email = data.teacher_email;
        dataToBind.teacher_subjects = data.teacher_subjects;
        dataToBind.hour_rate = data.hour_rate;
        if (data.hour_rate == 0) {
            dataToBind.hour_rate = '';
        }
        if (data.is_active == "Y") {
            dataToBind.is_active = true;
        }
        else {
            dataToBind.is_active = false;
        }
        if (data.is_allow_teacher_to_only_mark_attendance == "Y") {
            dataToBind.is_allow_teacher_to_only_mark_attendance = true;
        }
        else {
            dataToBind.is_allow_teacher_to_only_mark_attendance = false;
        }
        if (data.is_student_mgmt_flag == "1") {
            dataToBind.is_student_mgmt_flag = true;
        }
        else {
            dataToBind.is_student_mgmt_flag = false;
        }
        dataToBind.attendance_device_id = data.attendance_device_id;
        dataToBind.country_id = data.country_id;
        // dataToBind.dob = '1998-2-2';
        // dataToBind.date_of_joining = '1998-2-2'
        dataToBind.dob = data.dob;
        dataToBind.date_of_joining = data.date_of_joining;
        this.country_id = data.country_id;
        console.log(dataToBind);
        return dataToBind;
    };
    TeacherEditComponent.prototype.addNewTeacherInfo = function () {
        var _this = this;
        var formData = this.editTeacherForm.value;
        if (!this.validateCaseSensitiveEmail(formData.teacher_email)) {
            this.messageToast('error', '', 'Please enter valid email address.');
            return;
        }
        var phoneCheck = this.commonService.phonenumberCheck(formData.teacher_phone, this.maxlength, this.country_id);
        if (phoneCheck == false) {
            this.messageToast('error', '', 'Please enter valid contact number.');
            return;
        }
        if (phoneCheck == 'noNumber') {
            this.messageToast('error', '', 'Please enter valid contact no.');
            return;
        }
        if (formData.teacher_alt_phone != '' && formData.teacher_alt_phone != null) {
            if (!(this.commonService.phonenumberCheck(formData.teacher_alt_phone, this.maxlength, this.country_id))) {
                this.messageToast('error', '', 'Please enter valid alternate phone number.');
                return;
            }
        }
        if (formData.teacher_name == "" || formData.teacher_name == null) {
            this.messageToast('error', '', 'Faculty Name is required.');
            return;
        }
        if (formData.hour_rate == "" || formData.hour_rate == null) {
            formData.hour_rate = 0;
        }
        if (this.studentImage != null && this.studentImage != "") {
            formData.photo = this.studentImage;
        }
        else {
            formData.photo = null;
        }
        if (formData.is_student_mgmt_flag == true) {
            formData.is_student_mgmt_flag = 1;
        }
        else {
            formData.is_student_mgmt_flag = 0;
        }
        if (formData.is_active == true) {
            formData.is_active = "Y";
        }
        else {
            formData.is_active = "N";
        }
        if (formData.is_allow_teacher_to_only_mark_attendance == true) {
            formData.is_allow_teacher_to_only_mark_attendance = "Y";
        }
        else {
            formData.is_allow_teacher_to_only_mark_attendance = "N";
        }
        formData.is_employee_to_be_create = "N";
        formData.country_id = this.instituteCountryDetObj.id;
        formData.dob = __WEBPACK_IMPORTED_MODULE_6_moment__(formData.dob).format('YYYY-MM-DD');
        formData.date_of_joining = __WEBPACK_IMPORTED_MODULE_6_moment__(formData.date_of_joining).format('YYYY-MM-DD');
        this.isRippleLoad = true;
        this.ApiService.addNewTeacherDetails(formData).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.messageToast('success', 'Added', 'Faculty Added Successfully.');
            _this.route.navigateByUrl('/view/course/setup/teacher');
        }, function (err) {
            _this.isRippleLoad = false;
            _this.messageToast('error', '', err.error.message);
        });
    };
    TeacherEditComponent.prototype.addOrEditFun = function () {
        if (this.selectedTeacherId == undefined) {
            this.addNewTeacherInfo();
        }
        else {
            this.saveTeacherInfo();
        }
    };
    TeacherEditComponent.prototype.saveTeacherInfo = function () {
        var _this = this;
        var formData = this.editTeacherForm.value;
        if (!this.validateCaseSensitiveEmail(formData.teacher_email)) {
            this.messageToast('error', '', 'Please enter valid email address.');
            return;
        }
        var phoneCheck = this.commonService.phonenumberCheck(formData.teacher_phone, this.maxlength, this.country_id);
        if (phoneCheck == false) {
            this.messageToast('error', '', 'Please enter valid contact number.');
            return;
        }
        if (phoneCheck == 'noNumber') {
            this.messageToast('error', '', 'Please enter valid contact no.');
            return;
        }
        if (formData.teacher_alt_phone != '' && formData.teacher_alt_phone != null) {
            if (!(this.commonService.phonenumberCheck(formData.teacher_alt_phone, this.maxlength, this.country_id))) {
                this.messageToast('error', '', 'Please enter valid alternate phone number.');
                return;
            }
        }
        if (formData.teacher_name == "" || formData.teacher_name == null) {
            this.messageToast('error', '', 'Faculty Name is required.');
            return;
        }
        if (formData.hour_rate == "" || formData.hour_rate == null) {
            formData.hour_rate = "0";
        }
        if (this.studentImage != null || this.studentImage != "") {
            formData.photo = this.studentImage;
        }
        else {
            formData.photo = null;
        }
        if (formData.is_student_mgmt_flag == true) {
            formData.is_student_mgmt_flag = 1;
        }
        else {
            formData.is_student_mgmt_flag = 0;
        }
        if (formData.is_active == true) {
            formData.is_active = "Y";
        }
        else {
            formData.is_active = "N";
        }
        if (formData.is_allow_teacher_to_only_mark_attendance == true) {
            formData.is_allow_teacher_to_only_mark_attendance = "Y";
        }
        else {
            formData.is_allow_teacher_to_only_mark_attendance = "N";
        }
        //this section is to handle id card
        if (sessionStorage.getItem('Id-card') != null || sessionStorage.getItem('Id-card') != undefined) {
            formData.id_file = sessionStorage.getItem('Id-card');
            formData.id_fileType = sessionStorage.getItem('imageType');
        }
        else {
            formData.id_file = null;
            formData.id_fileType = "";
        }
        formData.dob = __WEBPACK_IMPORTED_MODULE_6_moment__(formData.dob).format('YYYY-MM-DD');
        formData.date_of_joining = __WEBPACK_IMPORTED_MODULE_6_moment__(formData.date_of_joining).format('YYYY-MM-DD');
        this.isRippleLoad = true;
        this.ApiService.saveEditTeacherInformation(this.selectedTeacherInfo.teacher_id, formData).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.messageToast('success', 'Updated', 'Details Updated Successfully.');
            if (sessionStorage.getItem('userType') == '3') {
                _this.route.navigateByUrl('/view/home/admin');
            }
            else {
                _this.route.navigateByUrl('/view/course/setup/teacher');
            }
        }, function (err) {
            _this.isRippleLoad = false;
            _this.messageToast('error', '', err.error.message);
        });
    };
    TeacherEditComponent.prototype.onChangeIdCardUpload = function () {
        this.hasIdCard = 'Y';
        var fileBrowser = this.idCardTeacher.nativeElement;
        if (fileBrowser.files && fileBrowser.files[0]) {
            sessionStorage.setItem('imageType', fileBrowser.files[0].type.split('/')[1]);
            var reader_1 = new FileReader();
            reader_1.readAsDataURL(fileBrowser.files[0]);
            reader_1.onload = function () {
                sessionStorage.setItem('Id-card', reader_1.result.split(',')[1]);
            };
        }
    };
    TeacherEditComponent.prototype.downloadIdCard = function () {
        var _this = this;
        this.ApiService.downloadDocument(this.selectedTeacherId).subscribe(function (res) {
            // this.idCardImg.nativeElement.src = 'data:image/png;base64,' + res.document;
            _this.anchTag.nativeElement.href = 'data:image/png;base64,' + res.document;
            _this.anchTag.nativeElement.download = res.docTitle;
            _this.anchTag.nativeElement.click();
        }, function (err) {
            _this.messageToast('error', '', err.error.message);
        });
    };
    TeacherEditComponent.prototype.messageToast = function (errorType, errorTitle, errorMeassage) {
        var data = {
            type: errorType,
            title: errorTitle,
            body: errorMeassage
        };
        this.toastCtrl.popToast(data);
    };
    TeacherEditComponent.prototype.validateCaseSensitiveEmail = function (email) {
        if (email != "" && email != null) {
            var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
            if (reg.test(email)) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return true;
        }
    };
    TeacherEditComponent.prototype.validateNumber = function (inputtxt, maxlength) {
        console.log(maxlength);
        console.log(inputtxt);
        if (inputtxt.length == maxlength) {
            return true;
        }
        else {
            return false;
        }
    };
    TeacherEditComponent.prototype.setImage = function (e) {
        this.studentImage = e;
    };
    TeacherEditComponent.prototype.updateIdCard = function ($event) {
        $event.preventDefault();
        this.idCardTeacher.nativeElement.click();
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('idCardUpload'),
        __metadata("design:type", Object)
    ], TeacherEditComponent.prototype, "idCardTeacher", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('uploadedImage'),
        __metadata("design:type", Object)
    ], TeacherEditComponent.prototype, "idCardImg", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('uploadImageAnchor'),
        __metadata("design:type", Object)
    ], TeacherEditComponent.prototype, "anchTag", void 0);
    TeacherEditComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-teacher-edit',
            template: __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-edit/teacher-edit.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-edit/teacher-edit.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_2__services_teacherService_teacherApi_service__["a" /* TeacherAPIService */],
            __WEBPACK_IMPORTED_MODULE_3__angular_forms__["FormBuilder"],
            __WEBPACK_IMPORTED_MODULE_4__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["ActivatedRoute"],
            __WEBPACK_IMPORTED_MODULE_5____["c" /* CommonServiceFactory */]])
    ], TeacherEditComponent);
    return TeacherEditComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-list/teacher-list.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"middle-section clearFix\">\r\n  <section class=\"middle-top mb0 clearFix\" style=\"margin-bottom: 15px;\">\r\n    <div class=\"pull-left\" style=\"margin-top:20px;\">\r\n      <div class=\"header-title\">        \r\n          <h2>\r\n              <a routerLink=\"/view/{{type}}\" style=\"color: #0084f6;\">\r\n                {{ type | titlecase }}\r\n              </a>\r\n              <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" ></i> \r\n              <a routerLink=\"/view/{{type}}/setup\" style=\"color: #0084f6;\">\r\n                Data Setup\r\n              </a>\r\n              <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" ></i>Faculty\r\n          </h2>\r\n        </div> \r\n    </div>\r\n    <div class=\"\">\r\n      <div class=\"field-wrapper\">\r\n        <div class=\"btnWrapper\">\r\n          <button type=\"button\" class=\"btn pull-right\" name=\"button\" routerLink='/view/course/setup/teacher/add'>\r\n            <i class=\"fa fa-plus\" aria-hidden=\"true\"></i>\r\n            &nbsp; Add Faculty\r\n          </button>\r\n        </div>\r\n      </div>\r\n      <div class=\"search-filter-wrapper\">\r\n        <input type=\"text\" style=\"width:18%\" #teacherSearch class=\"normal-field pull-right\" id=\"searchTeacher\" placeholder=\"Search\"\r\n         [(ngModel)]=\"searchValue\" (keyup)=\"searchTeacher()\">\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <section style=\"margin-top: 10px;\">\r\n    <div class=\"table-scroll-wrapper\">\r\n      <div class=\"table table-responsive enquiry-table\">\r\n        <table class=\"teacherTable\">\r\n          <thead>\r\n            <tr>\r\n              <th>\r\n                Faculty Name\r\n              </th>\r\n              <th>\r\n                Contact No\r\n              </th>\r\n              <th>\r\n                Subject\r\n              </th>\r\n              <th>\r\n                  Date of Joining\r\n              </th>\r\n              <th>\r\n                Is Active\r\n              </th>\r\n              <th>\r\n                Edit\r\n              </th>\r\n              <th>\r\n                View Activity\r\n              </th>\r\n            </tr>\r\n          </thead>\r\n          <tbody *ngIf=\"teacherList.length != 0 \">\r\n            <tr id=\"row{{i}}\" (click)=\"rowSelectEvent(i)\" [class.selected]=\"i == selectedRow\" *ngFor=\"let row of teacherList; let i = index; trackBy: i;\">\r\n              <td style=\"text-align: left;\">\r\n                {{row.teacher_name}}\r\n              </td>\r\n              <td>\r\n                {{row.teacher_phone}}\r\n              </td>\r\n              <td>\r\n                {{row.teacher_subjects}}\r\n              </td>\r\n              <td>\r\n                <span *ngIf=\"row.date_of_joining==''\"> - </span>\r\n                <span *ngIf=\"row.date_of_joining!=''\">{{row.date_of_joining}}</span>  \r\n                </td>\r\n              <td>\r\n                {{row.is_active}}\r\n              </td>\r\n              <td class=\"anchorTags\">\r\n                <!-- (click)=\"editTeacherDeatils(row)\" -->\r\n                <a class=\"anchorTagCursor\" [routerLink]=\"['/view/course/setup/teacher/edit',  row.teacher_id]\" style=\"margin-right:5px\">\r\n                  <i class=\"edit-icon\" aria-hidden=\"true\" title=\"Edit\" style=\"margin-right:5px\"></i>Edit\r\n                </a>\r\n                <a class=\"anchorTagCursor\" (click)=\"deleteTeacherDeatils(row)\">\r\n                  <i class=\"fa fa-trash\" aria-hidden=\"true\" title=\"Delete\" style=\"margin-right:5px\"></i>Delete\r\n                </a>\r\n              </td>\r\n              <td class=\"anchorTags\">\r\n                  <!-- (click)=\"viewTeacherActivity(row)\" -->\r\n                <a class=\"anchorTagCursor\"   [routerLink]=\"['/view/course/setup/teacher/view',  row.teacher_id]\"  >\r\n                  <i class=\"fas fa fa-eye\" style=\"font-family: FontAwesome ;font-size: 19px;display: inline-block;vertical-align: middle; margin-right:5px\"\r\n                    title=\"View\"></i>\r\n                  View\r\n                </a>\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n          <tbody *ngIf=\"teacherList.length == 0 && dataStatus === 1\">\r\n            <tr *ngFor=\"let dummy of dummyArr\">\r\n              <td *ngFor=\"let c of columnMaps\">\r\n                <div class=\"skeleton\">\r\n                </div>\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n          <tbody *ngIf=\"(teacherList.length == 0 && dataStatus === 2)\">\r\n            <tr>\r\n              <td colspan=\"7\">\r\n                No Batch List Found\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n        </table>\r\n      </div>\r\n    </div>\r\n\r\n    <!-- Paginator Here -->\r\n    <div class=\"filter-res pagination\" style=\"width: 100%;\">\r\n      <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n        <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n          [page]=\"PageIndex\" [perPage]=\"studentdisplaysize\" [count]=\"totalRow\">\r\n        </pagination>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-list/teacher-list.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n\n.headEnq .field-wrapper {\n  padding: 0px !important; }\n\n.headEnq .field-wrapper .form-ctrl {\n    display: block;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 0px 0px 0px 5px;\n    outline: none;\n    border: 0;\n    height: 26px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 25px;\n    background: transparent;\n    width: 80px;\n    text-align: center;\n    border-bottom: 1px solid #ccc; }\n\n.headEnq .option-wrap {\n  width: 20px;\n  height: 20px; }\n\n.headEnq .btn .tooltip {\n  position: relative;\n  top: -20px;\n  right: 25px;\n  min-width: 80px;\n  font-size: 8px;\n  padding: 2px 0px 2px 18px;\n  height: auto;\n  border-radius: 8px;\n  background: rgba(0, 0, 0, 0.801);\n  color: white;\n  visibility: hidden;\n  opacity: 0; }\n\n.headEnq .btn:hover {\n  background: #d8d6d6; }\n\n.headEnq .btn:hover .tooltip {\n    position: relative;\n    top: 8px;\n    right: 25px;\n    min-width: 80px;\n    padding: 2px 0px 2px 18px;\n    border-radius: 8px;\n    font-size: 8px;\n    height: auto;\n    background: rgba(0, 0, 0, 0.801);\n    color: white;\n    visibility: visible;\n    opacity: 1;\n    -webkit-transition: all 0.2s;\n    transition: all 0.2s; }\n\n.headEnq .btn:focus {\n  outline: none; }\n\n.headEnq .btn:active {\n  -webkit-box-shadow: none;\n          box-shadow: none; }\n\n.anchorTags .anchorTagCursor {\n  cursor: pointer; }\n\n.teacherTable thead tr th {\n  padding-top: 10px;\n  padding-bottom: 10px; }\n\n.teacherTable tbody tr td {\n  padding-top: 10px;\n  padding-bottom: 10px; }\n\n.btnWrapper .btn .tooltip {\n  position: relative;\n  top: -30px;\n  right: -30px;\n  min-width: 100px;\n  font-size: 12px;\n  padding: 6px;\n  height: 35px;\n  border-radius: 5px;\n  background: rgba(0, 0, 0, 0.541);\n  color: white;\n  visibility: hidden;\n  opacity: 0; }\n\n.btnWrapper .btn:hover .tooltip {\n  position: relative;\n  top: -30px;\n  right: 120px;\n  min-width: 100px;\n  padding: 6px;\n  border-radius: 5px;\n  font-size: 12px;\n  height: 35px;\n  background: rgba(0, 0, 0, 0.541);\n  color: white;\n  visibility: visible;\n  opacity: 1;\n  -webkit-transition: all 0.2s;\n  transition: all 0.2s; }\n\n.btnWrapper .btn:focus {\n  outline: none; }\n\n.btnWrapper .btn:active {\n  -webkit-box-shadow: none;\n          box-shadow: none; }\n\n.tooltipWrapper {\n  right: 100px !important;\n  min-width: 83px !important;\n  top: -25px !important; }\n\n.addBtnOnHover {\n  padding-top: 10px !important;\n  padding-right: 6px !important; }\n\n.search-filter-wrapper .normal-field {\n  padding: 4px 10px;\n  border: 1px solid #ccc;\n  width: 50%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin: 0;\n  float: left;\n  height: 35px;\n  font-size: 14px; }\n\n.search-filter-wrapper .field-wrapper {\n  position: relative;\n  padding-top: 0px !important;\n  width: 30%;\n  float: left !important; }\n\n.search-filter-wrapper .field-wrapper .form-ctrl {\n    font: 400 12px 'Open sans',sans-serif;\n    border-top: none !important;\n    border-right: none !important;\n    border-left: none !important; }\n\n.search-filter-wrapper .field-wrapper label {\n  position: absolute !important;\n  left: 10% !important;\n  top: 1% !important; }\n\n.search-filter-wrapper .field-wrapper label:after {\n    left: 85% !important;\n    top: 10px !important; }\n\n.skeleton {\n  position: relative;\n  overflow: hidden;\n  width: 80%;\n  height: 12px;\n  background: #efefef;\n  border-radius: 2px; }\n\n.skeleton::after {\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background: -webkit-gradient(linear, left top, right top, from(#efefef), color-stop(white), to(#efefef));\n    background: linear-gradient(90deg, #efefef, white, #efefef);\n    -webkit-animation: progress 1s ease-in-out infinite;\n            animation: progress 1s ease-in-out infinite; }\n\n@-webkit-keyframes progress {\n  0% {\n    -webkit-transform: translate3d(-100%, 0, 0);\n            transform: translate3d(-100%, 0, 0); }\n  100% {\n    -webkit-transform: translate3d(100%, 0, 0);\n            transform: translate3d(100%, 0, 0); } }\n\n@keyframes progress {\n  0% {\n    -webkit-transform: translate3d(-100%, 0, 0);\n            transform: translate3d(-100%, 0, 0); }\n  100% {\n    -webkit-transform: translate3d(100%, 0, 0);\n            transform: translate3d(100%, 0, 0); } }\n"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-list/teacher-list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TeacherListComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_teacherService_teacherApi_service__ = __webpack_require__("./src/app/services/teacherService/teacherApi.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var TeacherListComponent = /** @class */ (function () {
    function TeacherListComponent(ApiService, route, toastCtrl, auth) {
        this.ApiService = ApiService;
        this.route = route;
        this.toastCtrl = toastCtrl;
        this.auth = auth;
        this.teacherListDataSource = [];
        this.teacherList = [];
        this.PageIndex = 1;
        this.studentdisplaysize = 10;
        this.searchData = [];
        this.searchDataFlag = false;
        this.isRippleLoad = false;
        this.dataStatus = 1;
        this.dummyArr = [0, 1, 2, 3, 4, 0, 1, 2, 3, 4];
        this.columnMaps = [0, 1, 2, 3, 4, 5];
        this.searchValue = "";
        this.type = '';
    }
    TeacherListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.getDataFromServer();
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.type = 'batch';
            }
            else {
                _this.type = 'course';
            }
        });
    };
    TeacherListComponent.prototype.getDataFromServer = function () {
        var _this = this;
        this.PageIndex = 1;
        this.isRippleLoad = true;
        this.ApiService.getAllTeacherList().subscribe(function (data) {
            _this.dataStatus = 2;
            _this.isRippleLoad = false;
            _this.totalRow = data.length;
            _this.teacherListDataSource = data;
            _this.teacherListDataSource.forEach(function (element) {
                if (element.date_of_joining != "") {
                    element.date_of_joining = __WEBPACK_IMPORTED_MODULE_5_moment__(element.date_of_joining).format('DD-MMM-YYYY');
                }
            });
            _this.fetchTableDataByPage(_this.PageIndex);
        }, function (error) {
            _this.dataStatus = 2;
            _this.isRippleLoad = false;
            var data = {
                type: "error",
                title: "",
                body: error.error.message
            };
            _this.toastCtrl.popToast(data);
        });
    };
    TeacherListComponent.prototype.deleteTeacherDeatils = function (row) {
        var _this = this;
        if (confirm("Are you sure, you want to delete this teacher?")) {
            this.ApiService.deleteTeacher(row.teacher_id).subscribe(function (res) {
                _this.searchValue = "";
                _this.searchDataFlag = false;
                var data = {
                    type: "success",
                    title: "",
                    body: "Faculty Deleted Successfully"
                };
                _this.toastCtrl.popToast(data);
                _this.getDataFromServer();
            }, function (err) {
                //console.log(err);
                var data = {
                    type: "error",
                    title: "",
                    body: err.error.message
                };
                _this.toastCtrl.popToast(data);
            });
        }
    };
    TeacherListComponent.prototype.searchTeacher = function () {
        var _this = this;
        if (this.searchValue != "" && this.searchValue != null) {
            var searchData = this.teacherListDataSource.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchValue.toLowerCase()); });
            });
            this.searchData = searchData;
            this.totalRow = searchData.length;
            this.searchDataFlag = true;
            this.fetchTableDataByPage(this.PageIndex);
        }
        else {
            this.searchDataFlag = false;
            this.fetchTableDataByPage(this.PageIndex);
            this.totalRow = this.teacherListDataSource.length;
        }
    };
    TeacherListComponent.prototype.rowSelectEvent = function (i) {
        this.selectedRow = i;
    };
    // pagination functions
    TeacherListComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.studentdisplaysize * (index - 1);
        this.teacherList = this.getDataFromDataSource(startindex);
    };
    TeacherListComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    TeacherListComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    TeacherListComponent.prototype.getDataFromDataSource = function (startindex) {
        var data = [];
        if (this.searchDataFlag) {
            data = this.searchData.slice(startindex, startindex + this.studentdisplaysize);
        }
        else {
            data = this.teacherListDataSource.slice(startindex, startindex + this.studentdisplaysize);
        }
        return data;
    };
    TeacherListComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-teacher-list',
            template: __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-list/teacher-list.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-list/teacher-list.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_teacherService_teacherApi_service__["a" /* TeacherAPIService */],
            __WEBPACK_IMPORTED_MODULE_2__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_3__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_4__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], TeacherListComponent);
    return TeacherListComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TeacherRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__teacher_component__ = __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__teacher_list_teacher_list_component__ = __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-list/teacher-list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__teacher_edit_teacher_edit_component__ = __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-edit/teacher-edit.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__teacher_view_teacher_view_component__ = __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-view/teacher-view.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var TeacherRoutingModule = /** @class */ (function () {
    function TeacherRoutingModule() {
    }
    TeacherRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_1__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_0__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__teacher_component__["a" /* TeacherComponent */],
                        children: [
                            {
                                path: '',
                                redirectTo: 'list'
                            },
                            {
                                path: 'list',
                                component: __WEBPACK_IMPORTED_MODULE_3__teacher_list_teacher_list_component__["a" /* TeacherListComponent */]
                            },
                            {
                                path: 'add',
                                component: __WEBPACK_IMPORTED_MODULE_4__teacher_edit_teacher_edit_component__["a" /* TeacherEditComponent */] //TeacherAddComponent make one comp for add and edit 
                            },
                            {
                                path: 'edit/:id',
                                component: __WEBPACK_IMPORTED_MODULE_4__teacher_edit_teacher_edit_component__["a" /* TeacherEditComponent */]
                            },
                            {
                                path: 'view/:id',
                                component: __WEBPACK_IMPORTED_MODULE_5__teacher_view_teacher_view_component__["a" /* TeacherViewComponent */]
                            }
                        ]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_0__angular_router__["RouterModule"]
            ],
            providers: [],
            declarations: []
        })
    ], TeacherRoutingModule);
    return TeacherRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-view/teacher-view.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"middle-section clearFix\">\r\n  <section class=\"middle-top mb0 clearFix\" style=\"margin-bottom: 10px;\">\r\n    <h1 class=\"pull-left\">\r\n      Faculty Profile\r\n    </h1>\r\n  </section>\r\n\r\n  <section class=\"middle-main clearFix\">\r\n    <div class=\"c-sm-12\">\r\n      <div class=\"c-sm-3\">\r\n        <proctur-image [containerHeight]=\"containerHeight\" [readonly]=\"readonly\" [serverImg]=\"studentImage\" [containerWidth]=\"containerWidth\"\r\n          (setImage)=\"setImage($event)\">\r\n\r\n        </proctur-image>\r\n      </div>\r\n      <div class=\"c-sm-9\" *ngIf=\"selectedTeacherInformation\">\r\n        <div class=\"c-sm-4\">\r\n          <div class=\"extraMargin\">\r\n            <label>Name:</label>\r\n            {{selectedTeacherInformation.teacher_name}}\r\n          </div>\r\n          <div class=\"extraMargin\">\r\n            <label>Email:</label>\r\n            {{selectedTeacherInformation.teacher_email}}\r\n          </div>\r\n          <div class=\"extraMargin\">\r\n            <label>Contact Number:</label>\r\n            {{selectedTeacherInformation.teacher_phone}}\r\n          </div>\r\n        </div>\r\n        <div class=\"c-sm-3\">\r\n          <div class=\"extraMargin\">\r\n            <label>Standard:</label>\r\n            {{selectedTeacherInformation.teacher_standards}}\r\n          </div>\r\n          <div class=\"extraMargin\">\r\n            <label>Subject:</label>\r\n            {{selectedTeacherInformation.teacher_subjects}}\r\n          </div>\r\n        </div>\r\n        <div class=\"c-sm-2\">\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"clearFix add-edit\">\r\n      <a (click)=\"toggleFilter()\">\r\n        <i id=\"showAddBtn\" class=\"addBtnClass\" style=\"border:none;\">+</i>\r\n        <i id=\"showCloseBtn\" style=\"display:none ; border:none;\" class=\"closeBtnClass\">-</i>\r\n        <span>Filter</span>\r\n      </a>\r\n    </div>\r\n    <section class=\"clearFix create-standard-form\" *ngIf=\"advanceFilter\">\r\n      <div class=\"row create-standard-field\">\r\n        <div class=\"c-sm-2\">\r\n        </div>\r\n        <div class=\"c-sm-2\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"\">Batch</label>\r\n            <select id=\"\" class=\"form-ctrl\" [(ngModel)]=\"selectedBatch\">\r\n              <option *ngFor=\"let opt of batchesList\" [value]=\"opt.batch_id\">\r\n                {{opt.batch_name}}\r\n              </option>\r\n            </select>\r\n\r\n          </div>\r\n        </div>\r\n        <div class=\"c-sm-8 \">\r\n          <div class=\"field-wrapper datePickerBox c-sm-3 madeDate\">\r\n            <label for=\"fromDate\">From Date</label>\r\n            <input type=\"text\" value=\"\" class=\"form-ctrl\" style=\"cursor: pointer;\" name=\"fromDate\" [(ngModel)]=\"selectedFromDate\" bsDatepicker/>\r\n\r\n            <!-- <span class=\"date-clear\" name=\"fromDate\" (click)=\"clearDate($event)\">Clear</span> -->\r\n          </div>\r\n          <div class=\"field-wrapper datePickerBox c-sm-3 madeDate\">\r\n            <label for=\"createdDate\">To Date</label>\r\n            <input type=\"text\" value=\"\" class=\"form-ctrl\" style=\"cursor: pointer;\" name=\"createdDate\" [(ngModel)]=\"selectedToDate\" bsDatepicker\r\n            />\r\n\r\n            <!-- <span class=\"date-clear\" name=\"createdDate\" (click)=\"clearDate($event)\">Clear</span> -->\r\n          </div>\r\n          <div class=\"c-sm-3\">\r\n            <button class=\"btn fullBlue\" (click)=\"searchTeacherInfo()\" style=\"margin-top:13%;\">Go</button>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n    </section>\r\n\r\n    <div>\r\n      <div>\r\n        <h2 class=\"pull-left marginTenPixel\">\r\n          Assigned Batches Details\r\n          <div class=\"questionInfo pos-rel\">\r\n            <span class=\"qInfoIcon\">?</span>\r\n            <div class=\"tooltip-box-field\">\r\n              Details of Assigned Batches to the teacher.\r\n            </div>\r\n          </div>\r\n        </h2>\r\n        <!-- <div class=\"c-sm-4\">\r\n          <button class=\"btn\" (click)=\"exportDetailsInExcel()\">Excel</button>\r\n          <button class=\"btn\" (click)=\"printBtnClick()\">Print</button>\r\n        </div> -->\r\n      </div>\r\n      <div class=\"common-table\">\r\n        <div class=\"table table-responsive\" style=\"overflow: hidden;\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  Batch\r\n                </th>\r\n                <th>\r\n                  Total Students\r\n                </th>\r\n                <th>\r\n                  Total Classes Marked\r\n                </th>\r\n                <th>\r\n                  Total Classes Taken\r\n                </th>\r\n                <th>\r\n                  Total Hours\r\n                </th>\r\n                <th>\r\n                  Computed Salary\r\n                </th>\r\n                <th>\r\n                  View Details\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr id=\"row{{i}}\" class=\"displayComp\" *ngFor=\"let row of assignedBatchList; let i = index; trackBy: i;\">\r\n                <td>\r\n                  {{row.batch_name}}\r\n                </td>\r\n                <td>\r\n                  {{row.total_students}}\r\n                </td>\r\n                <td>\r\n                  {{row.total_classes}}\r\n                </td>\r\n                <td>\r\n                  {{row.total_teacher_classes}}\r\n                </td>\r\n                <td>\r\n                  {{row.total_hours}}\r\n                </td>\r\n                <td>\r\n                  {{row.comp_sal}}\r\n                </td>\r\n                <td>\r\n                  <a style=\"cursor: pointer;\" (click)=\"viewDetailOfBatch(row , i)\">\r\n                    <i class=\"view-icon\"></i>View\r\n                  </a>\r\n                </td>\r\n              </tr>\r\n              <tr *ngIf=\"(assignedBatchList.length > 0)\">\r\n                <td colspan=\"2\" style=\"text-align:center;\">\r\n                  Total Classes Taken : {{totalClassesTaken}}\r\n                </td>\r\n                <td colspan=\"2\" style=\"text-align:center;\">\r\n                  Total Hours Spent : {{totalHourSpent}}\r\n                </td>\r\n                <td colspan=\"4\">\r\n                </td>\r\n              </tr>\r\n              <tr *ngIf=\"(assignedBatchList.length == 0)\">\r\n                <td colspan=\"8\" style=\"text-align:center;\">\r\n                  <span>No Assigned Batches</span>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div>\r\n      <div>\r\n        <h2 class=\"pull-left marginTenPixel\">\r\n          Visiting Batches Details\r\n          <div class=\"questionInfo pos-rel\">\r\n            <span class=\"qInfoIcon\">?</span>\r\n            <div class=\"tooltip-box-field\">\r\n              Details of Visting Batches to the teacher.\r\n            </div>\r\n          </div>\r\n        </h2>\r\n      </div>\r\n      <div class=\"common-table\">\r\n        <div class=\"table table-responsive\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  Batch\r\n                </th>\r\n                <th>\r\n                  Total Students\r\n                </th>\r\n                <th>\r\n                  Total Classes Taken\r\n                </th>\r\n                <th>\r\n                  Total Hours\r\n                </th>\r\n                <th>\r\n                  Computed Salary\r\n                </th>\r\n                <th>\r\n                  View Details\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr id=\"row{{i}}\" *ngFor=\"let row of visitingBatchList; let i = index; trackBy: i;\">\r\n                <td>\r\n                  {{row.batch_name}}\r\n                </td>\r\n                <td>\r\n                  {{row.total_students}}\r\n                </td>\r\n                <td>\r\n                  {{row.total_teacher_classes}}\r\n                </td>\r\n                <td>\r\n                  {{row.total_hours}}\r\n                </td>\r\n                <td>\r\n                  {{row.comp_sal}}\r\n                </td>\r\n                <td>\r\n                  <a style=\"cursor: pointer;\" (click)=\"viewDetailOfVisitingBatch(row , i)\">\r\n                    <i class=\"view-icon\"></i>View\r\n                  </a>\r\n                </td>\r\n              </tr>\r\n              <tr *ngIf=\"(visitingBatchList.length > 0)\">\r\n                <td colspan=\"2\" style=\"text-align:center;\">\r\n                  Total Classes Taken : {{visitingTotalClasses}}\r\n                </td>\r\n                <td colspan=\"2\" style=\"text-align:center;\">\r\n                  Total Hours Spent : {{visitingTotalHour}}\r\n                </td>\r\n                <td colspan=\"2\">\r\n                </td>\r\n              </tr>\r\n              <tr *ngIf=\"(visitingBatchList.length == 0)\">\r\n                <td colspan=\"6\" style=\"text-align:center;\">\r\n                  <span>No Visiting Batches</span>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"marginTenPixel\" style=\"text-align: center;\">\r\n      <button class=\"btn pull-right\" (click)=\"cancelViewDetails()\">Cancel</button>\r\n    </div>\r\n  </section>\r\n\r\n</div>\r\n\r\n\r\n\r\n<!-- Common Popup for Visiting and Assigned Classes PopUp -->\r\n<!-- =============================================================================== -->\r\n<section id=\"popup\" class=\"popupWrapper fadeIn\" *ngIf=\"teacherTakenClassesPopUp\">\r\n  <div class=\"popup pos-abs popup-body-container\">\r\n    <div class=\"popup-wrapper pos-rel\">\r\n      <span class=\"closePopup pos-abs fbold show\" id=\"popupCloseBtn\" (click)=\"teacherTakenClassesPopupClose()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n          <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n            <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n              <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n              <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n            </g>\r\n            <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n            />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content teacherPopUpWrapper\">\r\n        <div *ngIf=\"(assignedOrGuestPopUp ==  'Assigned' )\">\r\n          <div>\r\n            <h2>Teacher Classes Taken</h2>\r\n          </div>\r\n          <div class=\"popUpTableDiv\">\r\n            <table>\r\n              <thead>\r\n                <tr>\r\n                  <th>\r\n                    Date\r\n                  </th>\r\n                  <th>\r\n                    Timing\r\n                  </th>\r\n                  <th>\r\n                    Class\r\n                  </th>\r\n                  <th>\r\n                    Class Taken\r\n                  </th>\r\n                </tr>\r\n              </thead>\r\n              <tbody>\r\n                <tr id=\"row{{i}}\" *ngFor=\"let row of teacherTakenClasses; let i = index; trackBy: i;\">\r\n                  <td>\r\n                    {{row.attendance_date}}\r\n                  </td>\r\n                  <td>\r\n                    {{row.start_time}} - {{row.end_time}}\r\n                  </td>\r\n                  <td>\r\n                    {{row.custom_class_type}}\r\n                  </td>\r\n                  <td>\r\n                    {{row.is_class_taken}}\r\n                  </td>\r\n                </tr>\r\n                <tr *ngIf=\"(teacherTakenClasses == undefined || teacherTakenClasses == ''  )\">\r\n                  <td colspan=\"4\">\r\n                    No data found\r\n                  </td>\r\n                </tr>\r\n              </tbody>\r\n            </table>\r\n          </div>\r\n        </div>\r\n        <div *ngIf=\"(assignedOrGuestPopUp ==  'Guest' )\">\r\n          <div>\r\n            <h2>Classes(Visiting) Taken</h2>\r\n          </div>\r\n          <div class=\"popUpTableDiv\">\r\n            <table>\r\n              <thead>\r\n                <tr>\r\n                  <th>\r\n                    Date\r\n                  </th>\r\n                  <th>\r\n                    Timing\r\n                  </th>\r\n                  <th>\r\n                    Class\r\n                  </th>\r\n                </tr>\r\n              </thead>\r\n              <tbody>\r\n                <tr id=\"row{{i}}\" *ngFor=\"let row of guestBatchList; let i = index; trackBy: i;\">\r\n                  <td>\r\n                    {{row.attendance_date}}\r\n                  </td>\r\n                  <td>\r\n                    {{row.start_time}} - {{row.end_time}}\r\n                  </td>\r\n                  <td>\r\n                    {{row.custom_class_type}}\r\n                  </td>\r\n                </tr>\r\n                <tr *ngIf=\"(guestBatchList == undefined || guestBatchList == ''  )\">\r\n                  <td colspan=\"3\">\r\n                    No data found\r\n                  </td>\r\n                </tr>\r\n              </tbody>\r\n            </table>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-view/teacher-view.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n@media screen and (max-width: 995px), screen and (max-height: 768px) {\n  .common-table {\n    margin-left: 0px !important;\n    margin-top: 15px;\n    margin-right: 15px !important;\n    max-height: 480px;\n    overflow: hidden;\n    width: 100%; }\n    .common-table .table-scroll-wrapper {\n      max-height: 430px; }\n    .common-table ::-webkit-scrollbar {\n      display: block;\n      width: 7px;\n      height: 7px; } }\n.madeDate.datePickerBox:after {\n  content: '';\n  background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n  position: absolute;\n  right: 21px;\n  top: 33px;\n  width: 21px;\n  height: 21px;\n  z-index: 0; }\n.view-icon {\n  background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%222334.5 296.5 16.854 18.966%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1 %7B%0D        fill%3A none%3B%0D%09%09stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1454%22 data-name%3D%22Group 1454%22 transform%3D%22translate(1384 -16)%22%3E%0D    %3Ccircle id%3D%22Ellipse_65%22 data-name%3D%22Ellipse 65%22 class%3D%22cls-1%22 cx%3D%222.376%22 cy%3D%222.376%22 r%3D%222.376%22 transform%3D%22translate(960.875 324.987)%22%2F%3E%0D    %3Cline id%3D%22Line_239%22 data-name%3D%22Line 239%22 class%3D%22cls-1%22 x1%3D%222.112%22 y1%3D%222.112%22 transform%3D%22translate(964.888 329)%22%2F%3E%0D    %3Cpath id%3D%22Path_561%22 data-name%3D%22Path 561%22 class%3D%22cls-1%22 d%3D%22M16.342%2C12.17V2.612A2.118%2C2.118%2C0%2C0%2C0%2C14.229.5H2.612A2.118%2C2.118%2C0%2C0%2C0%2C.5%2C2.612V16.342a2.118%2C2.118%2C0%2C0%2C0%2C2.112%2C2.112h6.97%22 transform%3D%22translate(950.5 312.5)%22%2F%3E%0D    %3Cline id%3D%22Line_240%22 data-name%3D%22Line 240%22 class%3D%22cls-1%22 x2%3D%2210.561%22 transform%3D%22translate(953.64 316.696)%22%2F%3E%0D    %3Cline id%3D%22Line_241%22 data-name%3D%22Line 241%22 class%3D%22cls-1%22 x2%3D%224.224%22 transform%3D%22translate(953.64 327.785)%22%2F%3E%0D    %3Cline id%3D%22Line_242%22 data-name%3D%22Line 242%22 class%3D%22cls-1%22 x2%3D%226.337%22 transform%3D%22translate(953.64 324.089)%22%2F%3E%0D    %3Cline id%3D%22Line_243%22 data-name%3D%22Line 243%22 class%3D%22cls-1%22 x2%3D%2210.561%22 transform%3D%22translate(953.64 320.393)%22%2F%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n  width: 13px;\n  height: 15px;\n  display: inline-block;\n  vertical-align: middle;\n  margin-right: 5px; }\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 850px;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n.teacherPopUpWrapper ::-webkit-scrollbar {\n  display: block;\n  width: 7px;\n  height: 7px; }\n.teacherPopUpWrapper .popUpTableDiv {\n  max-height: 450px;\n  overflow-x: hidden;\n  overflow-y: scroll; }\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.imageUploadWrapper {\n  margin-top: 1%;\n  margin-right: 5%; }\n.extraMargin {\n  margin-top: 20px;\n  margin-bottom: 10px;\n  margin-left: 10px;\n  margin-right: 10px; }\n.marginTenPixel {\n  margin-top: 10px;\n  margin-bottom: 10px; }\n.questionInfo {\n  margin-right: 2px;\n  height: 20px;\n  width: 20px;\n  display: inline-block;\n  vertical-align: middle; }\n.questionInfo .qInfoIcon {\n    color: #0084f6;\n    border-color: #0084f6;\n    width: 20px;\n    height: 20px;\n    border: 1px solid #ccc;\n    border-radius: 50%;\n    display: block;\n    text-align: center;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    line-height: 20px;\n    font-weight: 600;\n    font-size: 12px;\n    cursor: pointer;\n    -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n            box-shadow: 0px 0px 1px 0px #ccc inset;\n    color: #888;\n    -webkit-transition: all 0.2s linear;\n    transition: all 0.2s linear; }\n.add-edit {\n  margin-bottom: 15px;\n  margin-top: 15px; }\n.add-edit i {\n    border: 1px solid #0084f6;\n    display: inline-block;\n    width: 17px;\n    height: 17px;\n    border-radius: 50%;\n    line-height: 16px;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle;\n    margin-right: 4px; }\n.add-edit span {\n    display: inline-block; }\n.add-edit .expend-box i {\n    line-height: 12px;\n    font-size: 14px; }\n.add-edit a {\n    cursor: pointer; }\n.closeBtnClass {\n  line-height: 11px !important; }\n.create-standard-form {\n  margin: 10px 0;\n  padding: 10px 20px 20px;\n  background: #efefef;\n  border-top: 1px solid #d8d8d8; }\n.create-standard-form .form-ctrl {\n    background: transparent;\n    border-bottom: solid 1px #cccccc; }\n"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher-view/teacher-view.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TeacherViewComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_teacherService_teacherApi_service__ = __webpack_require__("./src/app/services/teacherService/teacherApi.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_utils_facade_browser__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/utils/facade/browser.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__app_component__ = __webpack_require__("./src/app/app.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var TeacherViewComponent = /** @class */ (function () {
    function TeacherViewComponent(route, ApiService, toastCtrl, routeParam) {
        var _this = this;
        this.route = route;
        this.ApiService = ApiService;
        this.toastCtrl = toastCtrl;
        this.routeParam = routeParam;
        this.selectedBatch = "";
        this.selectedFromDate = "";
        this.selectedToDate = "";
        this.assignedBatchList = [];
        this.visitingBatchList = [];
        this.totalClassesTaken = 0;
        this.totalHourSpent = 0;
        this.visitingTotalClasses = 0;
        this.visitingTotalHour = 0;
        this.teacherTakenClassesPopUp = false;
        this.assignedOrGuestPopUp = "";
        this.studentImage = '';
        this.containerWidth = "150px";
        this.containerHeight = "150px";
        this.readonly = true;
        this.advanceFilter = false;
        this.routeParam.params.subscribe(function (params) {
            _this.selectedTeacherId = params['id'];
            // console.log(this.selectedTeacherId);
        });
    }
    TeacherViewComponent.prototype.ngOnInit = function () {
        this.getTeacherViewInfo();
        this.getAllBatchesInformation();
        this.getInfoFromDashBoard({ "batch_id": -1, "from_date": "", "to_date": "" });
        this.getInfoFromGuest({ "batch_id": -1, "from_date": "", "to_date": "" });
    };
    TeacherViewComponent.prototype.getTeacherViewInfo = function () {
        var _this = this;
        this.ApiService.getViewInfoOfTeacher(this.selectedTeacherId).subscribe(function (data) {
            _this.studentImage = data.photo;
            _this.selectedTeacherInformation = data;
        }, function (error) {
            //console.log(error);
        });
    };
    TeacherViewComponent.prototype.getAllBatchesInformation = function () {
        var _this = this;
        this.ApiService.getTeacherViewBatchesInfo().subscribe(function (data) {
            _this.batchesList = data;
        }, function (error) {
            //console.log(error);
        });
    };
    TeacherViewComponent.prototype.searchTeacherInfo = function () {
        if (__WEBPACK_IMPORTED_MODULE_4_moment__() < __WEBPACK_IMPORTED_MODULE_4_moment__(this.selectedFromDate)) {
            this.messageNotifier('error', '', 'Please enter valid date');
            return;
        }
        if (__WEBPACK_IMPORTED_MODULE_4_moment__() < __WEBPACK_IMPORTED_MODULE_4_moment__(this.selectedToDate)) {
            this.messageNotifier('error', '', 'Please enter valid date');
            return;
        }
        var data = {};
        data.batch_id = this.selectedBatch;
        data.from_date = __WEBPACK_IMPORTED_MODULE_4_moment__(this.selectedFromDate).format('YYYY-MM-DD');
        data.to_date = __WEBPACK_IMPORTED_MODULE_4_moment__(this.selectedToDate).format('YYYY-MM-DD');
        this.getInfoFromDashBoard(data);
        this.getInfoFromGuest(data);
    };
    TeacherViewComponent.prototype.getInfoFromDashBoard = function (data) {
        var _this = this;
        this.assignedBatchList = [];
        this.ApiService.customizedTeacherSearchOnDashBoardView(data, this.selectedTeacherId).subscribe(function (data) {
            _this.assignedBatchList = data;
            _this.totalClassesTaken = _this.getPerticularKeyValue(data, "total_teacher_classes", '');
            _this.totalHourSpent = _this.getPerticularKeyValue(data, 'total_hours', ' ');
        }, function (error) {
            //console.log(error)
        });
    };
    TeacherViewComponent.prototype.getInfoFromGuest = function (data) {
        var _this = this;
        this.visitingBatchList = [];
        this.ApiService.customizedTeacherSearchOnGuestBatchView(data, this.selectedTeacherId).subscribe(function (data) {
            _this.visitingBatchList = data;
            _this.visitingTotalClasses = _this.getPerticularKeyValue(data, "total_teacher_classes", '');
            _this.visitingTotalHour = _this.getPerticularKeyValue(data, 'total_hours', ' ');
        }, function (error) {
            //console.log(error)
        });
    };
    TeacherViewComponent.prototype.cancelViewDetails = function () {
        this.route.navigateByUrl('/view/course/setup/teacher');
    };
    TeacherViewComponent.prototype.getPerticularKeyValue = function (data, dataKey, splitOpearator) {
        var totalCount = 0;
        for (var i = 0; i < data.length; i++) {
            if (data[i].hasOwnProperty(dataKey) && data[i][dataKey] != "" && data[i][dataKey] != null) {
                if (splitOpearator != "") {
                    totalCount += Number(data[i][dataKey].split(' ')[0]);
                }
                else {
                    totalCount += data[i][dataKey];
                }
            }
        }
        return totalCount;
    };
    TeacherViewComponent.prototype.exportDetailsInExcel = function () {
        //console.log("Excel");
    };
    TeacherViewComponent.prototype.printBtnClick = function () {
        __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_utils_facade_browser__["b" /* window */].print();
    };
    TeacherViewComponent.prototype.viewDetailOfBatch = function (row, i) {
        this.assignedOrGuestPopUp = "Assigned";
        this.teacherTakenClassesPopUp = true;
        this.getBatchDetailsInfo(row);
    };
    TeacherViewComponent.prototype.getBatchDetailsInfo = function (row) {
        var _this = this;
        var data = {};
        data.batch_id = row.batch_id;
        data.from_date = "";
        data.to_date = "";
        this.ApiService.viewBatchDetails(data, this.selectedTeacherId).subscribe(function (data) {
            _this.teacherTakenClasses = data;
            //console.log(data);
        }, function (error) {
            //console.log(error);
        });
    };
    TeacherViewComponent.prototype.teacherTakenClassesPopupClose = function () {
        this.assignedOrGuestPopUp = "";
        this.teacherTakenClassesPopUp = false;
    };
    TeacherViewComponent.prototype.viewDetailOfVisitingBatch = function (row, i) {
        var _this = this;
        this.assignedOrGuestPopUp = "Guest";
        this.teacherTakenClassesPopUp = true;
        var data = {};
        data.batch_id = row.batch_id;
        data.from_date = "";
        data.to_date = "";
        this.ApiService.viewBatchDetails(data, this.selectedTeacherId).subscribe(function (data) {
            _this.guestBatchList = data;
            //console.log(data);
        }, function (error) {
            //console.log(error);
        });
    };
    TeacherViewComponent.prototype.setImage = function (e) {
        this.studentImage = e;
    };
    TeacherViewComponent.prototype.toggleFilter = function () {
        if (this.advanceFilter == false) {
            this.advanceFilter = true;
            document.getElementById('showCloseBtn').style.display = '';
            document.getElementById('showAddBtn').style.display = 'none';
        }
        else {
            this.advanceFilter = false;
            document.getElementById('showCloseBtn').style.display = 'none';
            document.getElementById('showAddBtn').style.display = '';
        }
    };
    TeacherViewComponent.prototype.messageNotifier = function (type, title, msg) {
        var data = {
            type: type,
            title: title,
            body: msg
        };
        this.toastCtrl.popToast(data);
    };
    TeacherViewComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-teacher-view',
            template: __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-view/teacher-view.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-view/teacher-view.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_2__services_teacherService_teacherApi_service__["a" /* TeacherAPIService */],
            __WEBPACK_IMPORTED_MODULE_5__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["ActivatedRoute"]])
    ], TeacherViewComponent);
    return TeacherViewComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TeacherComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var TeacherComponent = /** @class */ (function () {
    function TeacherComponent() {
    }
    TeacherComponent.prototype.ngOnInit = function () {
        var classArray = ['lione', 'litwo', 'lithree', 'lifour', 'lifive', 'lisix', 'liseven', 'lieight', 'linine', 'lizero'];
        classArray.forEach(function (className) {
            if (document.getElementById(className)) {
                document.getElementById(className).classList.remove('active');
            }
        });
    };
    TeacherComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-teacher',
            template: __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], TeacherComponent);
    return TeacherComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/data-setup/teacher/teacher.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeacherModule", function() { return TeacherModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__teacher_component__ = __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__teacher_list_teacher_list_component__ = __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-list/teacher-list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__teacher_routing_module__ = __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_teacherService_teacherApi_service__ = __webpack_require__("./src/app/services/teacherService/teacherApi.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__teacher_add_teacher_add_component__ = __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-add/teacher-add.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__teacher_edit_teacher_edit_component__ = __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-edit/teacher-edit.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__teacher_view_teacher_view_component__ = __webpack_require__("./src/app/components/course-module/data-setup/teacher/teacher-view/teacher-view.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var TeacherModule = /** @class */ (function () {
    function TeacherModule() {
    }
    TeacherModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_10_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_3__teacher_routing_module__["a" /* TeacherRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_7__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_7__angular_forms__["FormsModule"]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_1__teacher_component__["a" /* TeacherComponent */],
                __WEBPACK_IMPORTED_MODULE_2__teacher_list_teacher_list_component__["a" /* TeacherListComponent */],
                __WEBPACK_IMPORTED_MODULE_6__teacher_add_teacher_add_component__["a" /* TeacherAddComponent */],
                __WEBPACK_IMPORTED_MODULE_8__teacher_edit_teacher_edit_component__["a" /* TeacherEditComponent */],
                __WEBPACK_IMPORTED_MODULE_9__teacher_view_teacher_view_component__["a" /* TeacherViewComponent */],
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_4__services_teacherService_teacherApi_service__["a" /* TeacherAPIService */]
            ]
        })
    ], TeacherModule);
    return TeacherModule;
}());



/***/ })

});
//# sourceMappingURL=teacher.module.0.chunk.js.map