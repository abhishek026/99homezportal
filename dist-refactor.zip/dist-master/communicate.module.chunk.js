webpackJsonp(["communicate.module"],{

/***/ "./src/app/components/communicate/communicate-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CommunicateRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2____ = __webpack_require__("./src/app/components/communicate/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__ = __webpack_require__("./src/app/guards/auth.guard.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2____["a" /* CommunicateComponent */],
        pathMatch: 'prefix',
        children: [
            {
                path: '',
                component: __WEBPACK_IMPORTED_MODULE_2____["b" /* CoummunicateHomeComponent */]
            },
            {
                path: 'ptm',
                component: __WEBPACK_IMPORTED_MODULE_2____["g" /* PtmManagementComponent */]
            },
            {
                path: 'sms',
                loadChildren: 'app/components/communicate/sms-reports/sms-reports.module#SmsReportsModule',
                pathMatch: 'prefix'
            },
            {
                path: 'exam',
                component: __WEBPACK_IMPORTED_MODULE_2____["e" /* ExamReportComponent */]
            },
            {
                path: 'email',
                component: __WEBPACK_IMPORTED_MODULE_2____["c" /* EmailReportComponent */]
            },
            {
                path: 'event',
                component: __WEBPACK_IMPORTED_MODULE_2____["d" /* EventManagmentComponent */],
                canLoad: [__WEBPACK_IMPORTED_MODULE_3__guards_auth_guard__["a" /* AuthGuard */]]
            }
        ]
    }
];
var CommunicateRoutingModule = /** @class */ (function () {
    function CommunicateRoutingModule() {
    }
    CommunicateRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]]
        })
    ], CommunicateRoutingModule);
    return CommunicateRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/communicate/communicate.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/components/communicate/communicate.component.scss":
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/components/communicate/communicate.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CommunicateComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var CommunicateComponent = /** @class */ (function () {
    function CommunicateComponent() {
    }
    CommunicateComponent.prototype.ngOnInit = function () {
    };
    CommunicateComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-communicate',
            template: __webpack_require__("./src/app/components/communicate/communicate.component.html"),
            styles: [__webpack_require__("./src/app/components/communicate/communicate.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], CommunicateComponent);
    return CommunicateComponent;
}());



/***/ }),

/***/ "./src/app/components/communicate/communicate.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommunicateModule", function() { return CommunicateModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1____ = __webpack_require__("./src/app/components/communicate/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__communicate_routing_module__ = __webpack_require__("./src/app/components/communicate/communicate-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__coummunicate_home_coummunicate_home_component__ = __webpack_require__("./src/app/components/communicate/coummunicate-home/coummunicate-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_activity_ptmservice_activity_ptm_service__ = __webpack_require__("./src/app/services/activity-ptmservice/activity-ptm.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_excel_service__ = __webpack_require__("./src/app/services/excel.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_export_to_pdf_service__ = __webpack_require__("./src/app/services/export-to-pdf.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__services_report_services_exam_service__ = __webpack_require__("./src/app/services/report-services/exam.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__services_report_services_get_email_service__ = __webpack_require__("./src/app/services/report-services/get-email.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__services_report_services_get_sms_service__ = __webpack_require__("./src/app/services/report-services/get-sms.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__services_report_services_post_sms_service__ = __webpack_require__("./src/app/services/report-services/post-sms.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__services_event_managment_service__ = __webpack_require__("./src/app/services/event-managment.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};













var CommunicateModule = /** @class */ (function () {
    function CommunicateModule() {
    }
    CommunicateModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_2__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_3__communicate_routing_module__["a" /* CommunicateRoutingModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_1____["a" /* CommunicateComponent */],
                __WEBPACK_IMPORTED_MODULE_4__coummunicate_home_coummunicate_home_component__["a" /* CoummunicateHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_1____["g" /* PtmManagementComponent */],
                __WEBPACK_IMPORTED_MODULE_1____["e" /* ExamReportComponent */],
                __WEBPACK_IMPORTED_MODULE_1____["c" /* EmailReportComponent */],
                __WEBPACK_IMPORTED_MODULE_1____["d" /* EventManagmentComponent */],
                __WEBPACK_IMPORTED_MODULE_1____["f" /* FilterPipe */]
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1____["f" /* FilterPipe */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_10__services_report_services_get_sms_service__["a" /* getSMSService */],
                __WEBPACK_IMPORTED_MODULE_11__services_report_services_post_sms_service__["a" /* postSMSService */],
                __WEBPACK_IMPORTED_MODULE_5__services_activity_ptmservice_activity_ptm_service__["a" /* ActivityPtmService */],
                __WEBPACK_IMPORTED_MODULE_6__services_excel_service__["a" /* ExcelService */],
                __WEBPACK_IMPORTED_MODULE_7__services_export_to_pdf_service__["a" /* ExportToPdfService */],
                __WEBPACK_IMPORTED_MODULE_8__services_report_services_exam_service__["a" /* ExamService */],
                __WEBPACK_IMPORTED_MODULE_9__services_report_services_get_email_service__["a" /* getEmailService */],
                __WEBPACK_IMPORTED_MODULE_5__services_activity_ptmservice_activity_ptm_service__["a" /* ActivityPtmService */],
                __WEBPACK_IMPORTED_MODULE_12__services_event_managment_service__["a" /* EventManagmentService */]
            ]
        })
    ], CommunicateModule);
    return CommunicateModule;
}());



/***/ }),

/***/ "./src/app/components/communicate/coummunicate-home/coummunicate-home.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"middle-section\">\r\n    <!-- course module -->\r\n    <section class=\"header-section\"> \r\n      <div>\r\n          <div class=\"header-title\">\r\n              <span> Communicate</span>\r\n            </div>\r\n      </div>  \r\n    </section>\r\n  <div class=\"course-menu-section-container\" >\r\n    <!-- <div class=\"course-menu-item hide\" routerLink=\"/view/communicate/manage-sms\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/communicate/manage_sms.svg\" alt=\"Manage sms\">\r\n        <span>Manage SMS</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span></span>\r\n      </div>\r\n    </div>\r\n    <div class=\"course-menu-item hide\" routerLink=\"/view/communicate/send-sms-email\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/communicate/manage_sms.svg\" alt=\"send sms / email\">\r\n        <span>Send SMS / Email</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span> </span>\r\n      </div>\r\n    </div> -->\r\n    <div class=\"course-menu-item\" routerLink=\"../sms\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/communicate/send_sms.svg\" alt=\"sms report\">\r\n        <span>SMS Report </span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>This Report depicts the daily SMS sent to prospects, students and parents</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"course-menu-item\" routerLink=\"../email\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/communicate/email_report.svg\" alt=\"email report\">\r\n        <span>Email Report </span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>Detail of emails sent to prospect, student and parent on selected date range.</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"course-menu-item\"  routerLink=\"../ptm\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/communicate/ptm.svg\" alt=\"ptm management\">\r\n        <span>PTM Management</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>Create, Organize PTM Keeping Parents And Students Updated</span>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"course-menu-item\" routerLink=\"../event\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/communicate/event_management.svg\" alt=\"event management\">\r\n        <span>Event management</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>Create and manage events, assign them their type and communicate it with students/parents via SMS or notifications.</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>\r\n"

/***/ }),

/***/ "./src/app/components/communicate/coummunicate-home/coummunicate-home.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  padding: 1%; }\n\n.course-menu-section-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  padding-top: 20px;\n  border-top: 1px solid rgba(10, 10, 10, 0.5);\n  width: 100%; }\n\n.course-menu-section-container .course-menu-item {\n    padding: 15px 10px;\n    width: 31%;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 1%;\n    -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24);\n    box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24); }\n\n.course-menu-section-container .course-menu-item .menu-title {\n      width: 100%;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start;\n      font-size: 14px;\n      font-weight: 600;\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row; }\n\n.course-menu-section-container .course-menu-item .menu-title img {\n        width: 25px;\n        height: 25px; }\n\n.course-menu-section-container .course-menu-item .menu-title span {\n        margin-left: 10px;\n        margin-top: 5px; }\n\n.course-menu-section-container .course-menu-item .menu-description {\n      padding: 10px;\n      font-size: 12px; }\n\n.header-section .header-title {\n  text-align: left;\n  font-size: 14px;\n  font-weight: 600;\n  color: #0084f6;\n  padding-bottom: 10px; }\n"

/***/ }),

/***/ "./src/app/components/communicate/coummunicate-home/coummunicate-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CoummunicateHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var CoummunicateHomeComponent = /** @class */ (function () {
    function CoummunicateHomeComponent() {
    }
    CoummunicateHomeComponent.prototype.ngOnInit = function () {
    };
    CoummunicateHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-coummunicate-home',
            template: __webpack_require__("./src/app/components/communicate/coummunicate-home/coummunicate-home.component.html"),
            styles: [__webpack_require__("./src/app/components/communicate/coummunicate-home/coummunicate-home.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], CoummunicateHomeComponent);
    return CoummunicateHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/communicate/email-report/email-report.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"clearFix sms-view-wrapper\">\r\n\r\n\r\n  <aside class=\"middle-full\">\r\n\r\n    <section class=\"middle-main clearFix\">\r\n      <div class=\"filter-box\">\r\n\r\n        <section class=\"middle-top mb0 clearFix sms-header\">\r\n\r\n          <h1 class=\"pull-left\">\r\n            <a routerLink=\"/view/communicate\">\r\n              Communicate\r\n              <!-- <i style=\"font-family: 'FontAwesome';font-size: 24px; cursor: pointer;\" class=\"fas fa-home\"></i> -->\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i> Email Report\r\n          </h1>\r\n\r\n          <aside class=\"pull-right\">\r\n            <!-- <input type=\"button\" value=\"Add Enquiry\" class=\"btn\" routerLink='/enquiry/add' />\r\n              <input type=\"button\" value=\"Upload Enquiry\" routerLink='/enquiry/upload' class=\"btn\"> -->\r\n          </aside>\r\n\r\n        </section>\r\n\r\n        <section class=\"sms-filter-wrapper\">\r\n          <div class=\"row\">\r\n            <div class=\"c-lg-5\">\r\n              <div class=\"field-wrapper datePickerBox has-value\">\r\n                  <label for=\"fromDate\">Sent From</label>\r\n                <input type=\"text\" value=\"\" id=\"fromDate\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"emailFetchForm.from_date\" (ngModelChange)=\"dateValidationForFuture($event)\" readonly=\"false\"\r\n                  name=\"fromDate\" bsDatepicker/>\r\n               \r\n              </div>\r\n              <div class=\"field-wrapper datePickerBox has-value\">\r\n                  <label for=\"toDate\">Sent To</label>\r\n                <input type=\"text\" value=\"\" id=\"updateDate\" readonly=\"false\" class=\"form-ctrl bsDatepicker\" [(ngModel)]=\"emailFetchForm.to_date\" (ngModelChange)=\"dateValidationForFuture($event)\"\r\n                  name=\"toDate\" bsDatepicker/>\r\n              \r\n              </div>\r\n            </div>\r\n            <div class=\"c-lg-2\">\r\n              <div class=\"btn-sms-search\">\r\n                <input type=\"button\"  style=\"margin-top:7%;\" class=\"normal-btn fullBlue btn\" value=\"Go\" (click)=\"fetchemailByDate()\" />\r\n              </div>\r\n            </div>\r\n            <div class=\"c-lg-5\"></div>\r\n          </div>\r\n        </section>\r\n      </div>\r\n\r\n      <section class=\"table-control\">\r\n        <div class=\"c-lg-8\">\r\n          <div *ngIf=\"emailSource.length\" class=\"c-lg-6\" style=\"padding: 15px;font-size: 16px;font-weight: 500;\">\r\n            Showing {{emailSource.length}} emails\r\n          </div>\r\n          <div *ngIf=\"emailSource.length == 0\" class=\"c-lg-6\"></div>\r\n          <div class=\"c-lg-6\"></div>\r\n        </div>\r\n        <div class=\"c-lg-4\">\r\n          <div class=\"field-wrapper\">\r\n            <input style=\"border: 1px solid #efefef;padding: 5px;width: 70%;float: right;\"  type=\"text\" placeholder=\"Search\" class=\"form-ctrl\" (keyup)=\"searchDatabase()\" [(ngModel)]=\"searchText\">\r\n          </div>\r\n        </div>\r\n      </section>\r\n\r\n      <section class=\"sms-table-wrapper\">\r\n\r\n        <div class=\"table table-responsive student-table\">\r\n          <proctur-table [dataStatus]=\"dataStatus\" [loaderState]=\"isRippleLoad\" [records]=\"emailSource\" [tableName]=\"'Email'\" [settings]=\"projectSettings\">\r\n          </proctur-table>\r\n        </div>\r\n\r\n        <!-- <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n            <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n              <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n                [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRecords\">\r\n              </pagination>\r\n            </div>\r\n          </div> -->\r\n\r\n      </section>\r\n\r\n    </section>\r\n\r\n  </aside>\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/components/communicate/email-report/email-report.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.filter-box {\n  background: #efefef;\n  -webkit-box-shadow: 1px 1px #000;\n          box-shadow: 1px 1px #000;\n  -webkit-box-shadow: 0px 1px 3px 0px #5d5d5d;\n          box-shadow: 0px 1px 3px 0px #5d5d5d;\n  border-radius: 5px; }\n.table-control {\n  height: 50px; }\n.sms-view-wrapper {\n  padding: 5px; }\n.sms-view-wrapper .row {\n    margin: 5px 15px; }\n.sms-table-wrapper ::-webkit-scrollbar {\n  display: block; }\n.sms-table-wrapper .table-responsive {\n  max-height: 340px;\n  overflow-x: hidden;\n  overflow-y: auto; }\n.sms-table-wrapper .table-responsive ::-webkit-scrollbar {\n    display: block; }\n.sms-table-wrapper .pagination {\n  width: 100%;\n  border-top: 1px solid rgba(119, 119, 119, 0.28); }\n.sms-header {\n  padding: 15px; }\n.sms-filter-wrapper .field-wrapper {\n  width: 40%;\n  padding: 15px 0px;\n  margin-left: 20px;\n  display: inline-block; }\n.sms-filter-wrapper .btn-sms-search {\n  padding: 15px 0px; }\n.sms-filter-wrapper .btn-sms-search .btn {\n    width: 100px; }\n.sms-table-controller {\n  margin: 5px; }\n.sms-table-controller ul li {\n    display: inline-block;\n    margin: 0px 20px 0px 0px; }\n.bulk-dropdown {\n  position: relative;\n  display: inline-block;\n  /* Dropdown Content (Hidden by Default) */\n  /* Links inside the dropdown */\n  /* Change color of dropdown links on hover */ }\n.bulk-dropdown .bulk-dropbtn {\n    padding: 0px 0px 3px 0px;\n    background: #fff;\n    border: none;\n    margin-left: 10px;\n    display: inline-block;\n    font-size: 14px;\n    font-weight: 600;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    height: 35px;\n    cursor: pointer; }\n.bulk-dropdown .bulk-dropbtn .caret {\n      margin-left: 5px;\n      display: inline-block;\n      width: 0;\n      height: 0;\n      vertical-align: middle;\n      border-top: 4px dashed;\n      border-right: 4px solid transparent;\n      border-left: 4px solid transparent;\n      -webkit-box-sizing: border-box;\n              box-sizing: border-box;\n      font-size: 14px;\n      font-weight: 400;\n      line-height: 1.42857143;\n      text-align: center;\n      white-space: nowrap;\n      cursor: pointer;\n      -webkit-user-select: none;\n         -moz-user-select: none;\n          -ms-user-select: none;\n              user-select: none;\n      font-family: inherit;\n      text-transform: none;\n      text-indent: 0px;\n      text-shadow: none; }\n.bulk-dropdown .bulk-dropbtn-border {\n    padding: 7px 12px;\n    background: #fff;\n    border-bottom: 1px solid #ccc;\n    border-top: none;\n    border-right: none;\n    border-left: none;\n    margin-left: 10px;\n    display: inline-block;\n    font-size: 14px;\n    font-weight: 600;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    height: 35px;\n    cursor: pointer;\n    color: #0084f6; }\n.bulk-dropdown .bulk-dropbtn-border:active {\n      -webkit-box-shadow: none;\n              box-shadow: none; }\n.bulk-dropdown .bulk-dropbtn-border::focus {\n      outline: none; }\n.bulk-dropdown .bulk-dropdown-content {\n    display: block;\n    position: absolute;\n    background-color: #f9f9f9;\n    min-width: 70px;\n    left: 75%;\n    -webkit-box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);\n            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);\n    z-index: 1;\n    text-align: left;\n    cursor: pointer; }\n.bulk-dropdown .bulk-dropdown-content a {\n    color: black;\n    padding: 12px 16px;\n    text-decoration: none;\n    display: block; }\n.bulk-dropdown .bulk-dropdown-content a:hover {\n    background-color: #f1f1f1; }\n.search {\n  text-align: right;\n  float: right; }\n"

/***/ }),

/***/ "./src/app/components/communicate/email-report/email-report.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EmailReportComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_report_services_get_email_service__ = __webpack_require__("./src/app/services/report-services/get-email.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var EmailReportComponent = /** @class */ (function () {
    function EmailReportComponent(apiService, appC) {
        this.apiService = apiService;
        this.appC = appC;
        this.pageIndex = 1;
        this.totalRecords = 0;
        this.displayBatchSize = 10;
        this.emailSource = [];
        this.emailDataSource = [];
        this.searchText = "";
        this.searchData = [];
        this.searchflag = false;
        this.dataStatus = true;
        this.isRippleLoad = false;
        this.projectSettings = [
            { primaryKey: 'sentDateTime', header: 'Sent Date' },
            { primaryKey: 'emailId', header: 'Email' },
            { primaryKey: 'message', header: 'Subject' },
            { primaryKey: 'name', header: 'Name' },
            { primaryKey: 'role', header: 'Role' },
            { primaryKey: 'func_type', header: 'Type' }
        ];
        this.emailFetchForm = {
            institution_id: parseInt(sessionStorage.getItem('institute_id')),
            from_date: __WEBPACK_IMPORTED_MODULE_3_moment__(new Date()).format('YYYY-MM-DD'),
            to_date: __WEBPACK_IMPORTED_MODULE_3_moment__(new Date()).format('YYYY-MM-DD'),
        };
        this.switchActiveView('email');
    }
    EmailReportComponent.prototype.ngOnInit = function () {
        this.pageIndex = 1;
        this.getAllEmailMessages();
    };
    EmailReportComponent.prototype.getAllEmailMessages = function () {
        var _this = this;
        this.dataStatus = true;
        this.emailSource = [];
        this.isRippleLoad = true;
        this.apiService.getEmailMessages(this.emailFetchForm).subscribe(function (res) {
            _this.isRippleLoad = false;
            _this.emailDataSource = res;
            _this.totalRecords = res.length;
            if (res.length == 0) {
                _this.dataStatus = false;
            }
            _this.emailSource = res;
            //this.fetchTableDataByPage(this.pageIndex);
        }, function (err) {
            _this.dataStatus = false;
            _this.isRippleLoad = false;
        });
    };
    EmailReportComponent.prototype.isTimeValid = function () {
        var v = __WEBPACK_IMPORTED_MODULE_3_moment__(this.emailFetchForm.from_date).diff(__WEBPACK_IMPORTED_MODULE_3_moment__(this.emailFetchForm.to_date));
        if (v <= 0) {
            return true;
        }
        else {
            return false;
        }
    };
    EmailReportComponent.prototype.fetchemailByDate = function () {
        if (this.isTimeValid()) {
            this.getAllEmailMessages();
        }
        else {
            var obj = {
                type: "error",
                title: "",
                Body: "From date cannot be greater than To date"
            };
            this.appC.popToast(obj);
        }
    };
    EmailReportComponent.prototype.dateValidationForFuture = function (e) {
        //console.log(e);
        var today = __WEBPACK_IMPORTED_MODULE_3_moment__(new Date);
        var selected = __WEBPACK_IMPORTED_MODULE_3_moment__(e);
        var diff = __WEBPACK_IMPORTED_MODULE_3_moment__(selected.diff(today))['_i'];
        if (diff <= 0) {
        }
        else {
            this.emailFetchForm.to_date = __WEBPACK_IMPORTED_MODULE_3_moment__(new Date).format('YYYY-MM-DD');
            this.emailFetchForm.from_date = __WEBPACK_IMPORTED_MODULE_3_moment__(new Date).format('YYYY-MM-DD');
            var msg = {
                type: "info",
                body: "Future date is not allowed"
            };
            this.appC.popToast(msg);
        }
    };
    // pagination functions 
    EmailReportComponent.prototype.fetchTableDataByPage = function (index) {
        this.pageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.emailSource = this.getDataFromDataSource(startindex);
    };
    EmailReportComponent.prototype.fetchNext = function () {
        this.pageIndex++;
        this.fetchTableDataByPage(this.pageIndex);
    };
    EmailReportComponent.prototype.fetchPrevious = function () {
        if (this.pageIndex != 1) {
            this.pageIndex--;
            this.fetchTableDataByPage(this.pageIndex);
        }
    };
    EmailReportComponent.prototype.getDataFromDataSource = function (startindex) {
        var t = this.emailDataSource.slice(startindex, startindex + this.displayBatchSize);
        return t;
    };
    EmailReportComponent.prototype.switchActiveView = function (id) {
        document.getElementById('email') && document.getElementById('email').classList.remove('active');
    };
    EmailReportComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            var searchData = void 0;
            searchData = this.emailSource.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.emailSource = searchData;
            this.searchflag = true;
        }
        else {
            this.isRippleLoad = true;
            this.apiService.getEmailMessages(this.emailFetchForm).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.emailSource = res;
                _this.searchflag = false;
            }, function (err) {
                _this.isRippleLoad = false;
            });
        }
    };
    EmailReportComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-email-report',
            template: __webpack_require__("./src/app/components/communicate/email-report/email-report.component.html"),
            styles: [__webpack_require__("./src/app/components/communicate/email-report/email-report.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_report_services_get_email_service__["a" /* getEmailService */],
            __WEBPACK_IMPORTED_MODULE_1__app_component__["a" /* AppComponent */]])
    ], EmailReportComponent);
    return EmailReportComponent;
}());



/***/ }),

/***/ "./src/app/components/communicate/event-managment/event-managment.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"middle-section clearFix\">\r\n\r\n  <section class=\"middle-top mb0 clearFix\">\r\n\r\n    <div class=\"row\">\r\n      <h1 class=\"pull-left marginhead\">\r\n        <a routerLink=\"/view/communicate\">\r\n       &nbsp;&nbsp; Communicate\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>   Manage Event\r\n      </h1>\r\n      <div class=\"pull-right\">\r\n        <input type=\"button\" class=\"fullBlue btn\" value=\"Add Event\" (click)=\"addPopup()\" />\r\n      </div>\r\n\r\n    </div>\r\n\r\n    <section class=\"middle-main clearFix\">\r\n\r\n      <div class=\"row filter-section-wrapper\">\r\n        <div class=\"c-sm-2 c-xs-2 c-lg-2 c-md-2\">\r\n          <div class=\"form-wrapper\">\r\n            <label>Month</label>\r\n            <select class=\"side-form-ctrl\" id=\"two\" name=\"month\" [(ngModel)]=\"list_obj.month\">\r\n              <option value=\"-1\" name=\"month\">Month</option>\r\n              <option value=\"1\">January</option>\r\n              <option value=\"2\">february</option>\r\n              <option value=\"3\">March</option>\r\n              <option value=\"4\">April</option>\r\n              <option value=\"5\">May</option>\r\n              <option value=\"6\">June</option>\r\n              <option value=\"7\">July</option>\r\n              <option value=\"8\">August</option>\r\n              <option value=\"9\">September</option>\r\n              <option value=\"10\">October</option>\r\n              <option value=\"11\">November</option>\r\n              <option value=\"12\">December</option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-sm-2 c-xs-2 c-lg-2 c-md-2\">\r\n          <div class=\"form-wrapper\">\r\n            <label>Year</label>\r\n            <select class=\"side-form-ctrl\" name=\"year\" id=\"two\" [(ngModel)]=\"list_obj.year\">\r\n              <option value=\"-1\" name=\"year\">Year</option>\r\n              <option value=\"2015\">2015</option>\r\n              <option value=\"2016\">2016</option>\r\n              <option value=\"2017\">2017</option>\r\n              <option value=\"2018\">2018</option>\r\n              <option value=\"2019\">2019</option>\r\n              <option value=\"2020\">2020</option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-sm-2 c-xs-2 c-lg-2 c-md-2\" style=\"margin-top: 25px\">\r\n          <div class=\"field-radio-wrapper\">\r\n            <input class=\"form-radio\" type=\"radio\" name=\"discount\" value=\"1\" id='r1' [(ngModel)]=\"list_obj.event_type\">\r\n            <label for=\"r1\" class=\"l1\">Holiday</label>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-sm-2 c-xs-2 c-lg-2 c-md-2\" style=\"margin-top: 25px;margin-left:-93px\">\r\n          <div class=\"field-radio-wrapper\">\r\n            <input class=\"form-radio\" type=\"radio\" name=\"discount\" value=\"2\" id='r2' [(ngModel)]=\"list_obj.event_type\" checked=\"checked\">\r\n            <label for=\"r2\" class=\"l1\">General</label>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-sm-1 c-xs-1 c-lg-1 c-md-1\" style=\"margin-top: 15px\">\r\n          <input type=\"button\" class=\"fullBlue btn\" value=\"Go\" (click)=\"getAllListData()\" />\r\n        </div>\r\n\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n          <div class=\"search-filter-wrapper\" style=\"margin-left:-20px;\">\r\n            <input #search type=\"textbox\" class=\"normal-field\" [(ngModel)]=\"searchDataFilter\" placeholder=\"Search\" (keyup)=\"searchInList()\">\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n\r\n      <div id=\"\" class=\"row\">\r\n        <div class=\"table-scroll-wrapper\">\r\n          <div class=\"table table-responsive\">\r\n            <table>\r\n              <thead>\r\n                <tr>\r\n                  <th>\r\n                    S.No.\r\n                  </th>\r\n                  <th>Event Name\r\n                  </th>\r\n                  <th>\r\n                    Event Type\r\n                  </th>\r\n                  <th>\r\n                    Description\r\n                  </th>\r\n                  <th>\r\n                    Date\r\n                  </th>\r\n                  <th>\r\n                    Edit\r\n                  </th>\r\n                  <th>Delete\r\n                  </th>\r\n                  <th>Send Push Notification\r\n                  </th>\r\n                </tr>\r\n              </thead>\r\n              <tbody *ngIf=\"pagedSourceData.length !=0\">\r\n                <tr id=\"row{{i}}\" class=\"displayComp\" *ngFor=\"let row of pagedSourceData; let i = index; trackBy: i;\">\r\n                  <td>\r\n                    {{i + 1}}\r\n                  </td>\r\n\r\n                  <td class=\"view-comp\">\r\n                    {{row.holiday_name}}\r\n                  </td>\r\n\r\n                  <td class=\"view-comp\">\r\n                    {{row.event_type_name}}\r\n                  </td>\r\n                  <td class=\"view-comp\">\r\n                    {{row.holiday_desc}}\r\n                  </td>\r\n\r\n                  <td class=\"view-comp\">\r\n                    {{row.event_date_range}}\r\n                  </td>\r\n                  <td class=\"view-comp\" (click)=\"updatePopup(row.holidayId)\">\r\n                    <span class=\"pull-right\" style=\"cursor: pointer;padding-right: 9% !important;text-align: left;\">\r\n                      <i class=\"edit-icon\" aria-hidden=\"true\" style=\"margin-right: 5px;font-family: FontAwesome\" title=\"Edit\"></i>Edit\r\n                    </span>\r\n                  </td>\r\n                  <td class=\"view-comp\" (click)=\"deleteEntryData(row.holidayId)\">\r\n                    <span class=\"pull-right\" style=\"cursor: pointer;padding-right: 9% !important;text-align: left;\">\r\n                      <i class=\"fa fa-trash-o\" aria-hidden=\"true\" style=\"margin-right: 5px;font-family: FontAwesome\" title=\"delete\"></i>Delete\r\n                    </span>\r\n\r\n                  </td>\r\n                  <td class=\"view-comp\">\r\n                    <a *ngIf=\"row.event_type==2\" (click)=\"sendNotificationAlert(row.holidayId)\">send</a>\r\n                  </td>\r\n                </tr>\r\n              </tbody>\r\n              <tbody *ngIf=\"pagedSourceData.length == 0\">\r\n                <td colspan=\"8\" style=\"text-align: center\">\r\n                  No EVents Found\r\n                </td>\r\n              </tbody>\r\n            </table>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <!-- Paginator Here -->\r\n      <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n        <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n          <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n            [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRow\">\r\n          </pagination>\r\n        </div>\r\n      </div>\r\n\r\n    </section>\r\n\r\n  </section>\r\n\r\n</div>\r\n\r\n\r\n\r\n<proctur-popup [sizeWidth]=\"'small'\" *ngIf=\"addEventPopUp\">\r\n\r\n  <span class=\"closePopup pos-abs fbold show\" (click)=\"closeReportPopup()\" close-button>\r\n    <svg class=\"artdeco-icon\" focusable=\"false\" height=\"24px\" preserveAspectRatio=\"xMinYMin meet\" viewBox=\"0 0 24 24\" width=\"24px\" x=\"0\" y=\"0\">\r\n      <path class=\"large-icon\" d=\"M20,5.32L13.32,12,20,18.68,18.66,20,12,13.33,5.34,20,4,18.68,10.68,12,4,5.32,5.32,4,12,10.69,18.68,4Z\" style=\"fill: currentColor\"></path>\r\n    </svg>\r\n  </span>\r\n  <h2 popup-header>Create Event</h2>\r\n  <div class=\"updateevents\" popup-content>\r\n    <div class=\"makeEvents\" popup-content>\r\n      <div class=\"row margin-top\">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\">\r\n          <div class=\"form-wrapper\">\r\n            <label>Event Type</label>\r\n            <select class=\"side-form-ctrl\" [(ngModel)]=\"saveDataObj.event_type\" (ngModelChange)=\"eventTypeChange()\">\r\n              <option *ngFor=\"let i of getEvent\" [value]=\"i.data_key\">{{i.data_value}}</option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\">\r\n          <div class=\"form-wrapper\" [ngClass]=\"{'has-value':saveDataObj.holiday_name != ''}\">\r\n            <label for=\"eventName\">Event Name*</label>\r\n            <input type=\"text\" class=\"side-form-ctrl\" name=\"eventName\" [(ngModel)]=\"saveDataObj.holiday_name\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n\r\n      <div class=\"row\" *ngIf=\"saveDataObj.event_type == 1\">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\">\r\n          <div class=\"form-wrapper\">\r\n            <label>Holiday Type</label>\r\n            <select class=\"side-form-ctrl\" [(ngModel)]=\"saveDataObj.holiday_type\">\r\n              <option *ngFor=\"let i of getHoliday\" [value]=\"i.data_key\">{{i.data_value}}</option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n\r\n      <div class=\"row \">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12 datenameEvent\">\r\n          <div class=\"form-wrapper datePickerBox\" [ngClass]=\"{'has-value': (saveDataObj.holiday_date != '' )}\">\r\n            <label for=\"csd\">Event Date\r\n              <span>*</span>\r\n            </label>\r\n            <input type=\"text\" value=\"\" id=\"csd\" class=\"side-form-ctrl bsDatepicker\" [(ngModel)]=\"saveDataObj.holiday_date\" readonly=\"true\"\r\n              name=\"csd\" bsDatepicker>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12 datenameEvent\" *ngIf=\"endDateBox\">\r\n          <div class=\"form-wrapper datePickerBox\" [ngClass]=\"{'has-value': (saveDataObj.event_end_date != '' )}\">\r\n            <label for=\"csd\">Event End Date\r\n              <span>*</span>\r\n            </label>\r\n            <input type=\"text\" value=\"\" id=\"csd\" class=\"side-form-ctrl bsDatepicker\" [(ngModel)]=\"saveDataObj.event_end_date\" readonly=\"true\"\r\n              name=\"csd\" bsDatepicker>\r\n\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\" *ngIf=\"saveDataObj.event_type == 2\">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\" style=\"margin-left: 20px;\">\r\n          <div class=\"field-checkbox-wrapper\">\r\n            <input class=\"form-checkbox\" name=\"enddatecheckbox\" type=\"checkbox\" (change)=\"checkChange($event.target.checked)\" />\r\n            <label for=\"enddatecheckbox\">Add End Date</label>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\">\r\n          <div class=\"form-wrapper\" [ngClass]=\"{'has-value':saveDataObj.holiday_desc!= ''}\">\r\n            <label for=\"desc\">Description*</label>\r\n            <input type=\"text\" class=\"side-form-ctrl\" name=\"desc\" [(ngModel)]=\"saveDataObj.holiday_desc\" />\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\">\r\n          <div class=\"form-wrapper\" [ngClass]=\"{'has-value':saveDataObj.holiday_long_desc!= ''}\">\r\n            <label for=\"longDesc\">Long Description</label>\r\n            <textarea style=\"height:95px; font-weight: 100\" maxlength=\"500\" class=\"side-form-ctrl\" name=\"longDesc\" [(ngModel)]=\"saveDataObj.holiday_long_desc\"></textarea>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\" *ngIf=\"saveDataObj.event_type == 2\">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\">\r\n          <div class=\"form-wrapper\">\r\n            <label for=\"helpadd\">Public Url\r\n              <div class=\"questionInfo inline-relative\">\r\n                <span class=\"qInfoIcon i-class\">?</span>\r\n                <div class=\"tooltip-box-field\">\r\n                  You can specify website URL\r\n                  <br>for the Event. This URL\r\n                  <br> will be displayed in Student\r\n                  <br> Android/iOS APP as a part of\r\n                  <br>Event Description\r\n                </div>\r\n              </div>\r\n            </label>\r\n            <input type=\"text\" name=\"helpadd\" class=\"side-form-ctrl\" [(ngModel)]=\"saveDataObj.public_url\" />\r\n          </div>\r\n        </div>\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\">\r\n\r\n          <div class=\"c-lg-8 form-wrapper\">\r\n            <label for=\"fileupload\">Upload File</label>\r\n            <input type=\"file\" id=\"fileAdd\" class=\"side-form-ctrl\" (change)=\"fileUpload('imgAdd')\" name=\"fileupload\" accept=\"image/*\">\r\n            <p style=\"margin-left: 20px\">Max Allowed Size : 1 MB\r\n              <br> File Format : jpg/jpeg/bmp/gif/png</p>\r\n          </div>\r\n\r\n          <div class=\"c-lg-4\">\r\n            <img style=\"float:right; margin-right:8%;\" alt=\"\" height=\"30\" width=\"38\" id=\"imgAdd\">\r\n          </div>\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <input type=\"button\" class=\"fullBlue btn pull-right\" style=\"margin-right: 20px;\" value=\"save\" (click)=\"saveEventData()\" />\r\n\r\n    </div>\r\n\r\n  </div>\r\n</proctur-popup>\r\n\r\n<proctur-popup [sizeWidth]=\"'small'\" *ngIf=\"closeEditPopup\">\r\n\r\n  <span class=\"closePopup pos-abs fbold show\" (click)=\"closeUpdateReportPopup()\" close-button>\r\n    <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n      <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n        <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n          <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n          <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n        </g>\r\n        <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n        />\r\n      </g>\r\n    </svg>\r\n  </span>\r\n  <h2 popup-header>Update Event</h2>\r\n  <div class=\"updateevents\" popup-content>\r\n    <div class=\"makeEvents\">\r\n      <div class=\"row margin-top\">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\">\r\n          <div class=\"form-wrapper\">\r\n            <label for=\"eventType\">Event Type*</label>\r\n            <select class=\"side-form-ctrl\" [(ngModel)]=\"newUpdateObj.event_type\" (ngModelChange)=\"eventTypeChange()\">\r\n              <option *ngFor=\"let i of getEvent\" [value]=\"i.data_key\">{{i.data_value}}</option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n\r\n\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\">\r\n          <div class=\"form-wrapper\" [ngClass]=\"{'has-value':newUpdateObj.holiday_name!= ''}\">\r\n            <label for=\"eventName\" style=\"padding-top:10px\">Event Name*</label>\r\n            <input type=\"text\" class=\"side-form-ctrl\" name=\"eventName\" [(ngModel)]=\"newUpdateObj.holiday_name\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\" *ngIf=\"newUpdateObj.event_type == 1\">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\">\r\n          <div class=\"form-wrapper\">\r\n            <label for=\"holidaytype\">Holiday Type</label>\r\n            <select class=\"side-form-ctrl\" [(ngModel)]=\"newUpdateObj.holiday_type\">\r\n              <option *ngFor=\"let i of getHoliday\" [value]=\"i.data_key\">{{i.data_value}}</option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12 datenameEvent\">\r\n          <div class=\"form-wrapper datePickerBox\" [ngClass]=\"{'has-value': (newUpdateObj.holiday_date != '' )}\">\r\n            <label for=\"csd\" style=\"display:inline-block; \">Event Date\r\n              <span style=\"display:inline-block;\">*</span>\r\n            </label>\r\n\r\n            <input type=\"text\" value=\"\" id=\"csd\" class=\"side-form-ctrl bsDatepicker\" [(ngModel)]=\"newUpdateObj.holiday_date\" readonly=\"true\"\r\n              name=\"csd\" bsDatepicker>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12 datenameEvent\" *ngIf=\"checker\">\r\n\r\n          <div class=\"form-wrapper datePickerBox\" [ngClass]=\"{'has-value':newUpdateObj.event_end_date!= ''}\">\r\n            <label for=\"eventenddate\">Event End Date\r\n              <span>*</span>\r\n            </label>\r\n            <input type=\"text\" class=\"side-form-ctrl  bsDatepicker\" name=\"eventenddate\" bsDatepicker [(ngModel)]=\"newUpdateObj.event_end_date\"\r\n            />\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n\r\n      <div class=\"row\" *ngIf=\"newUpdateObj.event_type == 2\">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\" style=\"margin-left:20px\">\r\n          <div class=\"field-checkbox-wrapper\">\r\n            <input class=\"form-checkbox\" name=\"enddatecheckbox\" [(ngModel)]=\"checker\" type=\"checkbox\" />\r\n            <label for=\"enddatecheckbox\">Add End Date</label>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\">\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\">\r\n          <div class=\"form-wrapper\" [ngClass]=\"{'has-value':newUpdateObj.holiday_desc!= ''}\">\r\n            <label for=\"Desc\">Description*</label>\r\n            <input type=\"text\" class=\"side-form-ctrl\" name=\"Desc\" [(ngModel)]=\"newUpdateObj.holiday_desc\" />\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-sm-12 c-xs-12 c-lg-12 c-md-12\">\r\n          <div class=\"form-wrapper\" [ngClass]=\"{'has-value':newUpdateObj.holiday_long_desc!= ''}\">\r\n            <label style=\"padding-top: 10px;\">Long Description*</label>\r\n            <textarea rows=\"5\" style=\"height:95px; font-weight: 100\" maxlength=\"500\" name=\"l_desc\" class=\"side-form-ctrl\" name=\"eventName\"\r\n              [(ngModel)]=\"newUpdateObj.holiday_long_desc\"></textarea>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div *ngIf=\"newUpdateObj.event_type == 2\">\r\n\r\n        <div class=\"row\">\r\n\r\n          <div class=\"c-lg-12 c-md-12 c-sm-12 c-xs-12\">\r\n            <div class=\"form-wrapper\">\r\n              <label for=\"help\">Public Url\r\n                <div class=\"questionInfo inline-relative\">\r\n                  <span class=\"qInfoIcon i-class\">?</span>\r\n                  <div class=\"tooltip-box-field\">\r\n                    You can specify website URL\r\n                    <br>for the Event. This URL\r\n                    <br> will be displayed in Student\r\n                    <br> Android/iOS APP as a part of\r\n                    <br>Event Description\r\n                  </div>\r\n                </div>\r\n              </label>\r\n              <input type=\"text\" name=\"help\" class=\"side-form-ctrl\" [(ngModel)]=\"newUpdateObj.public_url\" />\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"c-lg-12 c-md-12 c-sm-12 c-xs-12\" *ngIf=\"newUpdateObj.event_type == 2\">\r\n          <div class=\"c-lg-2\">\r\n            <img [src]=\"newUpdateObj.image\" height=\"30\" width=\"38\" id=\"imgUpdate\" style=\"text-align: right\">\r\n          </div>\r\n          <div class=\"c-lg-10 form-wrapper\">\r\n            <label for=\"filename\" style=\"width: auto\">Upload File</label>\r\n            <input type=\"file\" id=\"fileAdd\" (change)=\"fileUpload('imgUpdate')\" name=\"filename\" class=\"side-form-ctrl\" accept=\"image/*\">\r\n            <p style=\"margin-left: 20px\">Max Allowed Size : 1 MB\r\n              <br> File Format : jpg/jpeg/bmp/gif/png</p>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n\r\n      <input type=\"button\" class=\"fullBlue btn pull-right\" style=\"margin-right: 5px;\" value=\"Update\" (click)=\"updatePopupData()\"\r\n      />\r\n\r\n    </div>\r\n  </div>\r\n\r\n</proctur-popup>\r\n"

/***/ }),

/***/ "./src/app/components/communicate/event-managment/event-managment.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.middle-section {\n  padding: 10px;\n  padding-top: 0px; }\n.filter-section-wrapper {\n  padding: 10px 10px;\n  background: #efefef; }\n.row {\n  margin-top: 10px;\n  margin-left: 0px;\n  margin-right: 0px; }\n.form-wrapper {\n  background: transparent;\n  margin: 2px 0px;\n  width: 85% !important; }\n.form-wrapper .btn {\n    margin-top: 10px;\n    width: 30%; }\n.form-wrapper label {\n    padding-left: 25px;\n    font-size: 12px;\n    font-weight: 400;\n    color: 0084f6;\n    text-decoration: none;\n    -webkit-font-smoothing: antialiased;\n    width: 100%; }\n.form-wrapper label.l1 {\n      padding-left: 14px; }\n.form-wrapper .side-form-ctrl {\n    background: white;\n    border: 1px solid rgba(119, 119, 119, 0.419608);\n    width: 85%;\n    padding-left: 10px;\n    margin-left: 22px;\n    height: 30px;\n    padding: 4px 5px;\n    font-weight: 600;\n    font-size: 14px;\n    color: black; }\n.form-wrapper .side-form-ctrl.bsDatepicker {\n      width: 86%; }\n.margin-head {\n  padding-left: 8px; }\n.btn-sms-search {\n  margin-top: 35px;\n  text-align: center;\n  margin-left: 280px;\n  width: 100%; }\n.search-filter-wrapper {\n  margin-top: 10px; }\n.search-filter-wrapper .normal-field {\n    padding: 7px 10px;\n    border: 1px solid #ccc;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    margin-right: 10px;\n    margin-bottom: 5px;\n    height: 35px;\n    font-size: 14px;\n    margin-left: 229px; }\n.qInfoIcon {\n  width: 17px;\n  margin-left: 4px;\n  height: 20px;\n  border: 1px solid #ccc;\n  border-radius: 50%;\n  display: block;\n  text-align: center;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  line-height: 20px;\n  font-weight: 600;\n  font-size: 12px;\n  cursor: pointer;\n  -webkit-box-shadow: 0px 0px 1px 0px #ccc inset;\n          box-shadow: 0px 0px 1px 0px #ccc inset;\n  color: #888;\n  -webkit-transition: all 0.2s linear;\n  transition: all 0.2s linear; }\n.qInfoIcon:hover {\n    border-color: #0060A3;\n    -webkit-box-shadow: 0px 0px 1px 0px #0060A3 inset;\n            box-shadow: 0px 0px 1px 0px #0060A3 inset;\n    color: #0060A3; }\n.updateevents {\n  overflow: hidden; }\n.datenameEvent .form-wrapper {\n  position: relative; }\n.datenameEvent .form-wrapper.datePickerBox .side-form-ctrl {\n    cursor: pointer;\n    position: relative;\n    z-index: 1;\n    background: transparent; }\n.datenameEvent .form-wrapper.datePickerBox:after {\n    content: '';\n    background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n    position: absolute;\n    right: 47px;\n    top: 20px;\n    width: 21px;\n    height: 21px;\n    z-index: 0; }\n/*.dateEvent {\r\n    .form-wrapper {\r\n        position: relative;\r\n        &.datePickerBox {\r\n            .side-form-ctrl {\r\n                cursor: pointer;\r\n                position: relative;\r\n                z-index: 1;\r\n                background: transparent;\r\n            }\r\n            &:after {\r\n                content: '';\r\n                background: url('../../../assets/images/calendar.svg') no-repeat;\r\n                position: absolute;\r\n                right: 47px;\r\n                top: 20px;\r\n                width: 21px;\r\n                height: 21px;\r\n                z-index: 0;\r\n            }\r\n        }\r\n    }\r\n}\r\n*/\n.tooltip-box-field {\n  width: 170px;\n  white-space: nowrap;\n  min-height: 41px;\n  line-height: 12px;\n  padding: 5px 5px;\n  overflow: visible;\n  color: black;\n  font-weight: bold; }\n.tooltip-box-field.lg {\n    width: 200px;\n    white-space: nowrap;\n    min-height: 50px;\n    line-height: 20px;\n    padding: 5px 5px; }\n.tooltip-box-field.sm {\n    width: 100px;\n    white-space: nowrap;\n    min-height: 40px;\n    padding: 5px 5px; }\n.field-radio-wrapper .form-radio:checked + label:before {\n  content: '';\n  width: 10px;\n  height: 10px;\n  background: #0084f6;\n  border-radius: 50%;\n  left: 3px;\n  top: 3px; }\n.field-radio-wrapper label {\n  margin-left: 10px; }\n.margin-headleft {\n  margin-left: -30px;\n  margin-top: 25px; }\n.side-form-ctrl.datePickerBox {\n  content: '';\n  background: url(/./assets/images/calendar.svg) no-repeat;\n  position: absolute;\n  right: 0;\n  top: 18px;\n  width: 27px;\n  height: 21px;\n  z-index: 0; }\n.field-wrapper {\n  position: relative;\n  padding-top: 10px;\n  width: 73%;\n  margin-left: 20px; }\n"

/***/ }),

/***/ "./src/app/components/communicate/event-managment/event-managment.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EventManagmentComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_event_managment_service__ = __webpack_require__("./src/app/services/event-managment.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_common_service__ = __webpack_require__("./src/app/services/common-service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var EventManagmentComponent = /** @class */ (function () {
    function EventManagmentComponent(eve_mnge, auth, commonService) {
        this.eve_mnge = eve_mnge;
        this.auth = auth;
        this.commonService = commonService;
        this.isProfessional = false;
        this.eventRecord = [];
        this.endDatecheckbox = false;
        this.endDateBox = false;
        this.getHoliday = [];
        this.checker = false;
        this.getEvent = [];
        this.endDateofEvent = false;
        this.closeEditPopup = false;
        this.totalRow = 0;
        this.generalUpdateDataField = false;
        this.generalDataField = false;
        this.pagedSourceData = [];
        this.pageIndex = 1;
        this.searchDataFilter = "";
        this.displayBatchSize = 10;
        this.addEventPopUp = false;
        this.searchDataFlag = false;
        this.searchedData = [];
        this.list_obj = {
            year: -1,
            month: -1,
            event_type: "2",
        };
        this.searchText = "";
        this.searchflag = false;
        this.searchData = [];
        this.sendNotify_obj = {
            event_id: ""
        };
        this.saveDataObj = {
            event_end_date: "",
            event_type: "1",
            holiday_date: __WEBPACK_IMPORTED_MODULE_1_moment__().format("YYYY-MM-DD"),
            holiday_desc: "",
            holiday_long_desc: "",
            holiday_name: "",
            holiday_type: "1",
            image: null,
            public_url: ""
        };
        this.newUpdateObj = {
            event_end_date: "",
            event_type: "",
            holiday_date: __WEBPACK_IMPORTED_MODULE_1_moment__().format("YYYY-MM-DD"),
            holiday_desc: "",
            holiday_long_desc: "",
            holidayId: "",
            holiday_name: "",
            holiday_type: "",
            image: null,
            public_url: ""
        };
        this.acceptedFileFormat = {
            jpg: "0",
            jpeg: "1",
            bmp: "2",
            gif: "3",
            png: "4"
        };
        this.type = "";
        this.commonService.removeSelectionFromSideNav();
    }
    EventManagmentComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
        this.getAllListData();
    };
    /*=====================================get list of records=================================
    ============================================================================================ */
    EventManagmentComponent.prototype.getAllListData = function () {
        var _this = this;
        this.pageIndex = 1;
        this.searchDataFlag = false;
        this.searchDataFilter = "";
        this.eve_mnge.getListEventDesc(this.list_obj).subscribe(function (res) {
            _this.eventRecord = res;
            _this.totalRow = _this.eventRecord.length;
            _this.fetchTableDataByPage(_this.pageIndex);
        }),
            function (error) {
                _this.errorMessage(error);
            };
    };
    /*================================================get events==============================
    ============================================================================================= */
    EventManagmentComponent.prototype.getEvents = function () {
        var _this = this;
        this.eve_mnge.getEventdata().subscribe(function (res) {
            _this.getEvent = res;
        }, function (error) {
            _this.errorMessage(error);
        });
    };
    /*=====================================get holidays============================================
   =============================================================================================== */
    EventManagmentComponent.prototype.getHolidays = function () {
        var _this = this;
        this.eve_mnge.getHolidayData().subscribe(function (res) {
            _this.getHoliday = res;
        }, function (error) {
            _this.errorMessage(error);
        });
    };
    EventManagmentComponent.prototype.isTimeValid = function () {
        var v = __WEBPACK_IMPORTED_MODULE_1_moment__(this.saveDataObj.holiday_date).diff(__WEBPACK_IMPORTED_MODULE_1_moment__(this.saveDataObj.event_end_date));
        if (v <= 0) {
            return true;
        }
        else {
            return false;
        }
    };
    EventManagmentComponent.prototype.RunisTimeValid = function () {
        if (this.saveDataObj.event_type !== "" && this.saveDataObj.holiday_name !== "" && this.saveDataObj.holiday_type !== "") {
            this.isTimeValid();
        }
        else {
            this.commonService.showErrorMessage('error', 'Field is empty', 'Invalid Data');
        }
    };
    EventManagmentComponent.prototype.fileUpload = function (imgId) {
        var file = document.getElementById('fileAdd').files[0];
        this.type = file.name.split('.')[1];
        if (file.size > 1048576) {
            this.commonService.showErrorMessage('error', '', 'Uploaded File Exceeds 1Mb');
            document.getElementById('fileAdd').value = "";
            return;
        }
        var fileReader = new FileReader();
        fileReader.readAsDataURL(file);
        fileReader.onload = function () {
            var ele = document.getElementById(imgId);
            ele.src = fileReader.result;
        };
        fileReader.onerror = function (error) {
        };
    };
    EventManagmentComponent.prototype.saveEventData = function () {
        var _this = this;
        if (this.saveDataObj.holiday_name == "" || this.saveDataObj.holiday_desc == "") {
            this.commonService.showErrorMessage('error', '', 'Please Provide Mandatory Fields');
            return;
        }
        if (this.saveDataObj.event_end_date != "") {
            if (!this.isTimeValid()) {
                this.commonService.showErrorMessage('error', '', 'Please check date provided');
                return;
            }
            this.saveDataObj.event_end_date = __WEBPACK_IMPORTED_MODULE_1_moment__(this.saveDataObj.event_end_date).format('YYYY-MM-DD');
        }
        if (this.saveDataObj.holiday_desc.length > 80) {
            this.commonService.showErrorMessage('error', '', 'Description should not be greater than 80');
            return;
        }
        if (this.saveDataObj.holiday_long_desc.length > 300) {
            this.commonService.showErrorMessage('error', '', 'Long Description should not be greater than 300');
            return;
        }
        this.saveDataObj.holiday_date = __WEBPACK_IMPORTED_MODULE_1_moment__(this.saveDataObj.holiday_date).format('YYYY-MM-DD');
        if (this.saveDataObj.event_type == "2") {
            this.saveDataObj.image = document.getElementById('imgAdd').src.split(',')[1];
        }
        this.eve_mnge.saveEventDescData(this.saveDataObj).subscribe(function (res) {
            _this.commonService.showErrorMessage('success', 'Saved', 'Event Created Successfully');
            _this.getAllListData();
            _this.addEventPopUp = false;
        }, function (error) {
            _this.errorMessage(error);
        });
    };
    /*==========================================get update data================================
    ========================================================================================== */
    EventManagmentComponent.prototype.isTimeValidData = function () {
        var v = __WEBPACK_IMPORTED_MODULE_1_moment__(this.saveDataObj.holiday_date).diff(__WEBPACK_IMPORTED_MODULE_1_moment__(this.saveDataObj.event_end_date));
        if (v <= 0) {
            return true;
        }
        else {
            return false;
        }
    };
    /*=============================validate Date==============================================*/
    EventManagmentComponent.prototype.validateDate = function (start, end) {
        if (__WEBPACK_IMPORTED_MODULE_1_moment__(start).format('YYYY-MM-DD') == __WEBPACK_IMPORTED_MODULE_1_moment__(end).format('YYYY-MM-DD')) {
            return true;
        }
        var v = __WEBPACK_IMPORTED_MODULE_1_moment__(start).diff(__WEBPACK_IMPORTED_MODULE_1_moment__(end));
        if (v <= 0) {
            return true;
        }
        else {
            return false;
        }
    };
    EventManagmentComponent.prototype.updatePopupData = function () {
        var _this = this;
        if (this.newUpdateObj.holiday_name == "" || this.newUpdateObj.holiday_desc == "") {
            this.commonService.showErrorMessage('error', '', 'Please Provide Mandatory Fields');
            return;
        }
        if (this.newUpdateObj.event_end_date != "") {
            this.newUpdateObj.event_end_date = __WEBPACK_IMPORTED_MODULE_1_moment__(this.newUpdateObj.event_end_date).format('YYYY-MM-DD');
            if (!this.validateDate(this.newUpdateObj.holiday_date, this.newUpdateObj.event_end_date)) {
                this.commonService.showErrorMessage('error', '', 'Please check date provided');
                return;
            }
        }
        if (this.newUpdateObj.holiday_desc.length > 80) {
            this.commonService.showErrorMessage('error', '', 'Description should not be greater than 80');
            return;
        }
        if (this.newUpdateObj.holiday_long_desc.length > 300) {
            this.commonService.showErrorMessage('error', '', 'Long description should not be greater than 300');
            return;
        }
        this.newUpdateObj.holiday_date = __WEBPACK_IMPORTED_MODULE_1_moment__(this.newUpdateObj.holiday_date).format('YYYY-MM-DD');
        if (this.newUpdateObj.event_type == "2") {
            this.newUpdateObj.image = document.getElementById('imgUpdate').src.split(',')[1];
        }
        this.eve_mnge.getUpdateEventData(this.newUpdateObj).subscribe(function (res) {
            _this.commonService.showErrorMessage('success', 'Saved', 'Event Updated Successfully');
            _this.closeEditPopup = false;
            _this.getAllListData();
        }, function (error) {
            _this.errorMessage(error);
        });
    };
    EventManagmentComponent.prototype.checkChange = function (para) {
        if (para == true) {
            this.endDatecheckbox = true;
            this.endDateBox = true;
            this.endDateofEvent = true;
        }
        else {
            this.endDatecheckbox = false;
            this.endDateBox = false;
            this.endDateofEvent = false;
        }
    };
    /*=============================================edit update=========================
    ===================================================================================== */
    EventManagmentComponent.prototype.updateEventForm = function (holidayId) {
        var _this = this;
        this.eve_mnge.updateEventData(holidayId).subscribe(function (res) {
            _this.updateListObj = res;
            _this.newUpdateObj.event_type = res.event_type;
            _this.newUpdateObj.holiday_date = __WEBPACK_IMPORTED_MODULE_1_moment__(res.holiday_date).format("YYYY-MM-DD");
            _this.newUpdateObj.holiday_desc = res.holiday_desc;
            _this.newUpdateObj.holiday_long_desc = res.holiday_long_desc;
            _this.newUpdateObj.holiday_name = res.holiday_name;
            _this.newUpdateObj.holiday_type = res.holiday_type;
            _this.newUpdateObj.holidayId = res.holidayId;
            if (res.image != null) {
                _this.newUpdateObj.image = "data:image/png;base64," + res.image;
            }
            _this.newUpdateObj.public_url = res.public_url;
            if (res.event_type == "1") {
                _this.checker = false;
                _this.newUpdateObj.event_end_date = "";
            }
            else {
                _this.checker = true;
                _this.newUpdateObj.event_end_date = __WEBPACK_IMPORTED_MODULE_1_moment__(res.event_end_date).format("YYYY-MM-DD");
            }
        }, function (error) {
            _this.errorMessage(error);
        });
    };
    /*===================================================delete event data========================
    ============================================================================================== */
    EventManagmentComponent.prototype.deleteEventDataFromList = function (holidayId) {
        var _this = this;
        this.eve_mnge.deleteEventData(holidayId).subscribe(function (res) {
            _this.getAllListData();
        }, function (error) {
            _this.errorMessage(error);
        });
    };
    /*==================================send notification to EventType="GENERAL"======================
    ============================================================================================== */
    EventManagmentComponent.prototype.sendNotificationAlert = function (e) {
        var _this = this;
        var prompt = confirm("Are you sure,you want to Send Push Notification?");
        if (prompt) {
            this.sendNotify_obj.event_id = e;
            this.eve_mnge.sendNotifiation(this.sendNotify_obj).subscribe(function (res) {
                _this.commonService.showErrorMessage('success', 'Saved', 'Notification Sent Successfully');
            }, function (error) {
                _this.errorMessage(error);
            });
        }
    };
    EventManagmentComponent.prototype.addPopup = function () {
        this.addEventPopUp = true;
        this.getEvents();
        this.getHolidays();
        this.saveDataObj = {
            event_end_date: "",
            event_type: "1",
            holiday_date: __WEBPACK_IMPORTED_MODULE_1_moment__().format("YYYY-MM-DD"),
            holiday_desc: "",
            holiday_long_desc: "",
            holiday_name: "",
            holiday_type: "1",
            image: null,
            public_url: ""
        };
    };
    EventManagmentComponent.prototype.updatePopup = function (holidayId) {
        this.closeEditPopup = true;
        this.getEvents();
        this.getHolidays();
        this.updateEventForm(holidayId);
    };
    EventManagmentComponent.prototype.deleteEntryData = function (holidayId) {
        if (confirm("Are you sure, you want to delete the Event?")) {
            this.deleteEventDataFromList(holidayId);
        }
    };
    EventManagmentComponent.prototype.closeReportPopup = function () {
        this.addEventPopUp = false;
    };
    EventManagmentComponent.prototype.closeUpdateReportPopup = function () {
        this.closeEditPopup = false;
    };
    /*====================================================pagination========================
    ======================================================================================== */
    EventManagmentComponent.prototype.fetchTableDataByPage = function (index) {
        this.pageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.pagedSourceData = this.getClassRoomTableFromSource(startindex);
    };
    EventManagmentComponent.prototype.fetchNext = function () {
        this.pageIndex++;
        this.fetchTableDataByPage(this.pageIndex);
    };
    EventManagmentComponent.prototype.fetchPrevious = function () {
        if (this.pageIndex != 1) {
            this.pageIndex--;
            this.fetchTableDataByPage(this.pageIndex);
        }
    };
    EventManagmentComponent.prototype.eventTypeChange = function () {
        if (this.saveDataObj.event_type != "2") {
            this.saveDataObj.event_end_date = "";
            this.endDateBox = false;
        }
        if (this.newUpdateObj.event_type != "2") {
            this.newUpdateObj.event_end_date = "";
            this.checker = false;
        }
    };
    EventManagmentComponent.prototype.getClassRoomTableFromSource = function (startindex) {
        var data = [];
        if (this.searchDataFlag == true) {
            data = this.searchedData.slice(startindex, startindex + this.displayBatchSize);
        }
        else {
            data = this.eventRecord.slice(startindex, startindex + this.displayBatchSize);
        }
        return data;
    };
    EventManagmentComponent.prototype.searchInList = function () {
        var _this = this;
        if (this.searchDataFilter != "" && this.searchDataFilter != null) {
            var searchData = this.eventRecord.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchDataFilter.toLowerCase()); });
            });
            this.searchedData = searchData;
            this.totalRow = searchData.length;
            this.searchDataFlag = true;
            this.fetchTableDataByPage(this.pageIndex);
        }
        else {
            this.searchDataFlag = false;
            this.fetchTableDataByPage(this.pageIndex);
            this.totalRow = this.eventRecord.length;
        }
    };
    EventManagmentComponent.prototype.errorMessage = function (error) {
        this.commonService.showErrorMessage('error', '', error);
    };
    EventManagmentComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-event-managment',
            template: __webpack_require__("./src/app/components/communicate/event-managment/event-managment.component.html"),
            styles: [__webpack_require__("./src/app/components/communicate/event-managment/event-managment.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__services_event_managment_service__["a" /* EventManagmentService */],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__services_common_service__["a" /* CommonServiceFactory */]])
    ], EventManagmentComponent);
    return EventManagmentComponent;
}());



/***/ }),

/***/ "./src/app/components/communicate/exam-report/exam-report.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"middle-section clear-fix\">\r\n    <aside class=\"middle-full\">\r\n        <section class=\"middle-main clearFix attendance-container\">\r\n            <section class=\"middle-top mb0 clearFix sms-header\">\r\n                <h2 class=\"pull-left\" style=\"font-weight: bold;\">\r\n                    <a routerLink=\"/view/communicate\" style=\"padding:0px; \">\r\n                        Communicate\r\n                        <!-- <i style=\"font-family: 'FontAwesome';font-size: 24px; cursor: pointer;\" class=\"fas fa-home\"></i> -->\r\n                    </a>\r\n                    <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n                    Exam Report\r\n                </h2>\r\n                <aside class=\"pull-right\">\r\n                </aside>\r\n            </section>\r\n            <section class=\"filter-form\">\r\n                <div class=\"row\">\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3 field-wrapper\" *ngIf=\"!isProfessional\">\r\n                        <label>Master Course</label>\r\n                        <select class=\"form-ctrl\" id=\"one\" [(ngModel)]=\"fetchFieldData.standard_id\" (ngModelChange)=\"getCourseData($event)\" name=\"masterCourse\">\r\n                            <option></option>\r\n                            <option *ngFor=\"let i of masterCourses\" [value]=\"i.master_course\">{{i.master_course}}</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3 field-wrapper\" *ngIf=\"isProfessional\">\r\n                        <label>Master Course</label>\r\n                        <select class=\"form-ctrl\" id=\"one\" [(ngModel)]=\"queryParam.standard_id\" (ngModelChange)=\"getCourseData($event)\" name=\"masterCourse\">\r\n                            <option value=\"-1\"></option>\r\n                            <option *ngFor=\"let i of batchExamRepo\" [value]=\"i.standard_id\">{{i.standard_name}}</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3 field-wrapper\" *ngIf=\"!isProfessional\">\r\n                        <label> Course</label>\r\n                        <select class=\"form-ctrl\" id=\"two\" [(ngModel)]=\"fetchFieldData.subject_id\" (ngModelChange)=\"getSubData($event)\">\r\n                            <option></option>\r\n                            <option *ngFor=\"let i of courseData\" [value]=\"i.course_id\" name=\"Course\">{{i.course_name}}</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3 field-wrapper\" *ngIf=\"isProfessional\">\r\n                        <label> Course</label>\r\n                        <select class=\"form-ctrl\" id=\"two\" [(ngModel)]=\"queryParam.subject_id\">\r\n                            <option value=\"-1\"></option>\r\n                            <option *ngFor=\"let i of batchCourseData\" [value]=\"i.subject_id\" name=\"Course\">{{i.subject_name}}</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3 field-wrapper\" *ngIf=\"!isProfessional\">\r\n                        <label>Subject</label>\r\n                        <select class=\"form-ctrl\" id=\"three\" [(ngModel)]=\"fetchFieldData.batch_id\" (ngModelChange)=\"getExamScheduleData($event)\">\r\n                            <option></option>\r\n                            <option *ngFor=\"let i of subjectData\" [value]=\"i.batch_id\" name=\"Subject\">{{i.subject_name}}</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3  field-wrapper\" *ngIf=\"isProfessional\">\r\n                        <label>Batch</label>\r\n                        <select class=\"form-ctrl\" id=\"three\" [(ngModel)]=\" fetchFieldData.batch_id\" (ngModelChange)=\"getExamScheduleData($event)\">\r\n                            <option></option>\r\n                            <option *ngFor=\"let i of getSubjectData\" [value]=\"i.batch_id\" name=\"Subject\">{{i.batch_name}}</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"c-sm-3 c-xs-3 c-lg-3 c-md-3 field-wrapper\">\r\n                        <label>Exam Schedule</label>\r\n                        <select class=\"form-ctrl\" id=\"four\" [(ngModel)]=\"fetchFieldData.exam_schd_id\">\r\n                            <option></option>\r\n                            <option *ngFor=\"let i of exam_Sch_Data\" [value]=\"i.schd_id\" name=\"Exam Schedule\">{{i.exam_date}}({{i.start_time}}-{{i.end_time}})</option>\r\n                        </select>\r\n                    </div>\r\n\r\n                    <div class=\"master\" *ngIf=\"!isProfessional\">\r\n                        <input type=\"button\" class=\"normal-btn fullBlue btn\" value=\"View\" (click)=\"fetchExamReport()\" />\r\n                        <input type=\"button\" class=\"normal-btn fullBlue btn\" value=\"DetailReport\" (click)=\"fetchDetailReport()\" />\r\n                    </div>\r\n\r\n                    <div class=\"master\" *ngIf=\"isProfessional\">\r\n                        <input type=\"button\" class=\"normal-btn fullBlue btn\" value=\"View\" (click)=\"fetchExamReport()\" />\r\n                        <input type=\"button\" class=\"normal-btn fullBlue btn\" value=\"DetailReport\" (click)=\"fetchDetailReport()\" />\r\n                    </div>\r\n\r\n                </div>\r\n            </section>\r\n            <div class=\"table table-responsive student-table stdnt-table table-overflow\" *ngIf=\"!isProfessional && Tdata\">\r\n                <div class=\"search-filter-wrapper\" id=\"adFilterExitVisible\">\r\n                    <input #search type=\"text\" class=\"normal-field\" [(ngModel)]=\"searchText\" style=\"font-size:12px\" placeholder=\"Search\" (keyup)=\"searchDatabase()\">\r\n                </div>\r\n\r\n                <div class=\"poor\">\r\n\r\n                    <proctur-table [records]=\"pagedExamSource | filter:pagedExamSource.student_name :pagedExamSource.student_id:pagedExamSource.student_phone:pagedExamSource.doj\"\r\n                        [tableName]=\"'Exam'\" [settings]=\"projectSettings\" (sortData)=\"sortedData($event)\" [direction]=\"direction\"\r\n                        [sortingEnabled]=\"sortingEnabled\" [loaderState]=\"isRippleLoad\">\r\n                    </proctur-table>\r\n                </div>\r\n                <div class=\"row filter-res pagination\" style=\"width: 100%;\" *ngIf=\"!isProfessional\">\r\n                    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                        <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n                            [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRecords\">\r\n                        </pagination>\r\n                    </div>\r\n                </div>\r\n                <ul style=\"list-style-type:none; text-align:center; font-weight:bold;\" *ngIf=\"!isProfessional && examSource.length !=0 && examSource[0].grade==''\">\r\n                    <li>\r\n                        Highest Marks : {{HighestMarks}}\r\n                    </li>\r\n                    <li>\r\n                        Lowest Marks : {{LowestMarks}}\r\n                    </li>\r\n                    <li>\r\n                        Average Marks : {{AverageMarks}}\r\n                    </li>\r\n                </ul>\r\n            </div>\r\n\r\n\r\n            <div class=\"table table-responsive student-table stdnt-table \" *ngIf=\"isProfessional && Tdata\">\r\n                <div class=\"search-filter-wrapper\" id=\"adFilterExitVisible\">\r\n                    <input #search type=\"text\" class=\"normal-field\" [(ngModel)]=\"searchText\" style=\"font-size:12px\" placeholder=\"Search\" (keyup)=\"searchDatabase()\">\r\n                </div>\r\n\r\n                <div class=\"poor\">\r\n                    <proctur-table [records]=\"pagedExamSource | filter:pagedExamSource.student_name:pagedExamSource.student_id:pagedExamSource.student_phone:pagedExamSource.doj\"\r\n                        [tableName]=\"'Exam'\" [settings]=\"projectSettings\" [text]=\"examDesc\" [viewText]=\"showTitle\" (sortData)=\"sortedData($event)\"\r\n                        [direction]=\"direction\" [sortingEnabled]=\"sortingEnabled\" [loaderState]=\"isRippleLoad\">\r\n                    </proctur-table>\r\n                </div>\r\n\r\n                <div class=\"row filter-res pagination\" style=\"width: 100%;\" *ngIf=\"isProfessional\">\r\n                    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                        <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n                            [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRecords\">\r\n                        </pagination>\r\n                    </div>\r\n                </div>\r\n\r\n                <ul style=\"list-style-type:none; text-align:center; font-weight:bold;\" *ngIf=\" isProfessional && examSource.length !=0 && examSource[0].grade==''\">\r\n                    <li>\r\n                        Highest Marks : {{HighestMarks}}\r\n                    </li>\r\n                    <li>\r\n                        Lowest Marks : {{LowestMarks}}\r\n                    </li>\r\n                    <li>\r\n                        Average Marks : {{AverageMarks}}\r\n                    </li>\r\n                </ul>\r\n\r\n            </div>\r\n\r\n        </section>\r\n\r\n    </aside>\r\n</div>\r\n\r\n<proctur-popup [sizeWidth]=\"'large'\" *ngIf=\"addReportPopup\">\r\n    <span class=\"closePopup pos-abs fbold show\" (click)=\"closeReportPopup()\" close-button>\r\n        <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"9310 2185 16 16\">\r\n            <g id=\"Group_1228\" data-name=\"Group 1228\" transform=\"translate(8298 1888)\">\r\n                <g id=\"Group_1213\" data-name=\"Group 1213\" transform=\"translate(34.189 -7.77)\">\r\n                    <line id=\"Line_274\" data-name=\"Line 274\" class=\"cls-1\" y2=\"19.798\" transform=\"translate(992.81 305.77) rotate(45)\" />\r\n                    <line id=\"Line_275\" data-name=\"Line 275\" class=\"cls-1\" x1=\"19.798\" transform=\"translate(978.81 305.77) rotate(45)\" />\r\n                </g>\r\n                <rect id=\"Rectangle_686\" data-name=\"Rectangle 686\" style=\"stroke:none;\" class=\"cls-2\" width=\"16\" height=\"16\" transform=\"translate(1012 297)\"\r\n                />\r\n            </g>\r\n        </svg>\r\n    </span>\r\n\r\n    <h2 popup-header>DateWise Exam Report ({{selectedSubject}})</h2>\r\n    <div class=\"stu-table\" popup-content>\r\n\r\n        <div *ngIf=\"!isProfessional\" style=\"height:402px;\">\r\n            <i class=\"fa fa-file-excel-o\" (click)=\" downloadJsonToCSV()\" style=\"color:blue; height:39px; float:right; font-size:31px\"></i>\r\n            <a class=\"hide\" #xlsDownloader></a>\r\n\r\n            <div class=\"table table-responsive student-table made\" style=\"overflow:Hidden\">\r\n                <table #examTable>\r\n                    <thead>\r\n                        <tr>\r\n                            <th style=\"text-align:right;\">\r\n                                Student Id\r\n                            </th>\r\n                            <th style=\"text-align:left;\">\r\n                                Student Name\r\n                            </th>\r\n                            <th class=\"marks\" *ngFor=\"let date of dateStore\">\r\n                                {{date.exam_date}}\r\n                                <br>\r\n                                <span style=\"font-size:12px;\">{{date.start_time}}</span>\r\n                            </th>\r\n\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                        <tr *ngFor='let det of detailSource'>\r\n                            <td style=\"text-align:right;\">{{det.student_display_id}}</td>\r\n                            <td style=\"text-align:left;\">{{det.student_name}}</td>\r\n\r\n                            <td class=\"marks\" *ngFor=\"let marks of det.detailExamReportList\" [style.color]=\"getColor(marks.student_marks_obtained)\">\r\n                                <!-- <label *ngIf=\"marks.grade == 'Leave'||(marks.grade=='Absent' && marks.isBatchExamGrade == 1)\">{{marks.grade | uppercase}}</label> -->\r\n                                <!-- <label *ngIf=\"marks.grade != 'Leave'&& marks.grade!='Absent' && marks.isBatchExamGrade == 1\">{{marks.grade | uppercase}}</label>\r\n                                <label *ngIf=\"marks.grade != 'Leave'&& marks.grade!='Absent' && marks.isBatchExamGrade == 0\">{{getMark(marks.student_marks_obtained)}}\r\n                                    <span *ngIf=\"marks.student_marks_obtained!=null\">/&nbsp;{{marks.total_marks}}</span>\r\n                                </label> -->\r\n                                <label *ngIf=\"marks.isBatchExamGrade == 1\">{{marks.grade | uppercase}}</label>\r\n                                <label *ngIf=\"marks.isBatchExamGrade == 0\">{{getMark(marks.student_marks_obtained)}}\r\n                                    <label *ngIf=\"marks.student_marks_obtained!=null && marks.student_marks_obtained!='Absent' &&marks.student_marks_obtained!='Leave' && marks.student_marks_obtained!=0\">\r\n                                        <span *ngIf=\"marks.student_marks_obtained!=null\">/&nbsp;{{marks.total_marks}}</span>\r\n                                    </label>\r\n                                </label>\r\n                            </td>\r\n\r\n                        </tr>\r\n                        <tr *ngIf='detailSource.length==0'>No Students Founds</tr>\r\n                    </tbody>\r\n\r\n                </table>\r\n                <!--   <div class=\"row filter-res pagination\" style=\"width: 100%;\" *ngIf=\"!isProfessional\">\r\n                    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                        <pagination (goPage)=\"fetchTableDataByPagePopup($event)\" (goNext)=\"fetchNextPopup()\" (goPrev)=\"fetchPreviousPopup()\" [pagesToShow]=\"10\"\r\n                            [page]=\"pageIndexPopup\" [perPage]=\"displayBatchSize\" [count]=\"totalRecords\">\r\n                        </pagination>\r\n                    </div>\r\n                </div>-->\r\n            </div>\r\n        </div>\r\n\r\n        <div *ngIf=\"isProfessional\">\r\n            <i class=\"fa fa-file-excel-o\" (click)=\" downloadJsonToCSV()\" style=\"color:blue; height:39px; float:right; font-size:31px\"></i>\r\n\r\n            <a class=\"hide\" #xlsDownloader></a>\r\n            <div class=\"table table-responsive student-table stu-table made\">\r\n                <table #examTable>\r\n                    <thead>\r\n                        <tr>\r\n                            <th style=\"text-align:right;\">\r\n                                Student Id\r\n                            </th>\r\n                            <th style=\"text-align:left;\">\r\n                                Student Name\r\n                            </th>\r\n                            <th class=\"marks\" *ngFor=\"let date of dateStore\">\r\n                                {{date.exam_date}}\r\n                                <br>\r\n                                <span style=\"font-size:12px;\">{{date.start_time}}</span>\r\n                            </th>\r\n\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n                        <tr *ngFor='let det of detailSource'>\r\n\r\n                            <td style=\"text-align:right;\">{{det.student_display_id}}</td>\r\n                            <td style=\"text-align:left;\">{{det.student_name}}</td>\r\n\r\n                            <td class=\"marks\" *ngFor=\"let marks of det.detailExamReportList\" [style.color]=\"getColor(marks.student_marks_obtained)\">\r\n                                <!-- <label *ngIf=\"marks.grade == 'Leave'||marks.grade=='Absent' || isExamGrade == '1'\">{{marks.grade | uppercase}}</label>\r\n                                <label *ngIf=\"marks.grade == 'Leave'||marks.grade=='Absent' || isExamGrade == '1'\">{{marks.grade | uppercase}}</label>\r\n                                <label *ngIf=\"marks.grade != 'Leave' && marks.grade!='Absent' \">{{marks.grade | uppercase}}</label>\r\n                                <label *ngIf=\"marks.grade == '' || isExamGrade == '0'\">{{marks.student_marks_obtained}}</label> -->\r\n                                <label *ngIf=\"marks.isBatchExamGrade == 1\">{{marks.grade | uppercase}}</label>\r\n                                <label *ngIf=\"marks.isBatchExamGrade == 0\">{{getMark(marks.student_marks_obtained)}}\r\n                                    <label *ngIf=\"marks.student_marks_obtained!=null && marks.student_marks_obtained!='Absent' &&marks.student_marks_obtained!='Leave' && marks.student_marks_obtained!=0\">\r\n                                        <span *ngIf=\"marks.student_marks_obtained!=null\">/&nbsp;{{marks.total_marks}}</span>\r\n                                    </label>\r\n                                </label>\r\n\r\n                            </td>\r\n\r\n                        </tr>\r\n                        <tr *ngIf='detailSource.length==0'>No Students Founds</tr>\r\n                    </tbody>\r\n                </table>\r\n                <!--  <div class=\"row filter-res pagination\" style=\"width: 100%;\" *ngIf=\"isProfessional\">\r\n                    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n                        <pagination (goPage)=\"fetchTableDataByPagePopup($event)\" (goNext)=\"fetchNextPopup()\" (goPrev)=\"fetchPreviousPopup()\" [pagesToShow]=\"10\"\r\n                            [page]=\"pageIndexPopup\" [perPage]=\"displayBatchSize\" [count]=\"totalRecords\">\r\n                        </pagination>\r\n                    </div>\r\n                </div>-->\r\n            </div>\r\n        </div>\r\n\r\n    </div>\r\n\r\n    <div class=\"\" popup-footer>\r\n        <div class=\"clearfix\">\r\n            <aside class=\"pull-right popup-btn\">\r\n                <input type=\"button\" value=\"Close\" class=\"btn\" style=\"margin-right:10px;margin-top:0px\" (click)=\"closeReportPopup()\">\r\n            </aside>\r\n        </div>\r\n    </div>\r\n\r\n</proctur-popup>"

/***/ }),

/***/ "./src/app/components/communicate/exam-report/exam-report.component.scss":
/***/ (function(module, exports) {

module.exports = "body {\n  background: #EEEEF4;\n  color: #999; }\n\nh1 {\n  font-weight: 100;\n  font-size: 27pt;\n  color: #E43; }\n\np {\n  font-weight: 300; }\n\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n\n.middle-section .middle-top h2 {\n    color: black;\n    font-weight: unset;\n    padding-top: 20px; }\n\n.middle-section .form-wrapper {\n    background: transparent;\n    margin: 25px 0px; }\n\n.middle-section .form-wrapper .btn {\n      margin-top: 10px;\n      width: 30%; }\n\n.middle-section .form-wrapper label {\n      padding-left: 25px;\n      font-size: 12px;\n      font-weight: 400;\n      color: 0084f6;\n      text-decoration: none;\n      text-transform: uppercase;\n      -webkit-font-smoothing: antialiased;\n      width: 100%; }\n\n.middle-section .form-wrapper .side-form-ctrl {\n      background: white;\n      border: 1px solid rgba(119, 119, 119, 0.419608);\n      width: 85%;\n      padding-left: 10px;\n      margin-left: 10px;\n      height: 30px;\n      padding: 0px 5px;\n      font-weight: 600;\n      font-size: 14px;\n      color: black; }\n\n.middle-section .form-wrapper .side-form-ctrl.bsDatepicker {\n        padding-left: 10px;\n        margin-left: 25px;\n        width: 60%; }\n\n.master {\n  margin-top: 10px;\n  float: right;\n  margin-bottom: 10px;\n  margin-right: 16px; }\n\n.attendance-container {\n  background: #efefef;\n  padding: 5px;\n  overflow: auto; }\n\n.filter-form {\n  background: #fff;\n  -webkit-box-shadow: 0px 0px 2px 2px #dadada;\n          box-shadow: 0px 0px 2px 2px #dadada;\n  border-radius: 10px;\n  /*popup scss*/ }\n\n.filter-form .row {\n    margin: 5px 15px; }\n\n.filter-form .form-wrapper {\n    position: relative; }\n\n.filter-form .form-wrapper.datePickerBox .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent; }\n\n.filter-form .form-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 0;\n      top: 20px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n\n.filter-form .form-wrapper {\n    padding: 10px 5px; }\n\n.filter-form .form-wrapper label {\n      width: 100%;\n      display: block; }\n\n.filter-form .form-wrapper .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent;\n      width: 100%;\n      padding: 3px;\n      display: block;\n      border: 1px solid #dadada; }\n\n.filter-form .form-wrapper {\n    padding: 10px 5px;\n    position: relative; }\n\n.filter-form .form-wrapper.datePickerBox .side-form-ctrl {\n      cursor: pointer;\n      position: relative;\n      z-index: 1;\n      background: transparent;\n      width: 100%;\n      padding: 5px;\n      display: block;\n      border: 1px solid #dadada; }\n\n.filter-form .form-wrapper.datePickerBox:after {\n      content: '';\n      background: url(\"data:image/svg+xml,%3Csvg xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22 viewBox%3D%221165 207 18 18%22%3E%0D  %3Cdefs%3E%0D    %3Cstyle%3E%0D      .cls-1%2C .cls-2 %7B%0D        fill%3A none%3B%0D      %7D%0D%0D      .cls-2 %7B%0D        stroke%3A %230084f6%3B%0D        stroke-miterlimit%3A 10%3B%0D      %7D%0D    %3C%2Fstyle%3E%0D  %3C%2Fdefs%3E%0D  %3Cg id%3D%22Group_1205%22 data-name%3D%22Group 1205%22 transform%3D%22translate(-46 -16)%22%3E%0D    %3Crect id%3D%22Rectangle_684%22 data-name%3D%22Rectangle 684%22 class%3D%22cls-1%22 width%3D%2218%22 height%3D%2218%22 transform%3D%22translate(1211 223)%22%2F%3E%0D    %3Cg id%3D%22Group_1200%22 data-name%3D%22Group 1200%22%3E%0D      %3Cpath id%3D%22Path_20%22 data-name%3D%22Path 20%22 class%3D%22cls-2%22 d%3D%22M14.333%2C18.222H2.778A1.783%2C1.783%2C0%2C0%2C1%2C1%2C16.444V5.778A1.783%2C1.783%2C0%2C0%2C1%2C2.778%2C4H14.333a1.783%2C1.783%2C0%2C0%2C1%2C1.778%2C1.778V16.444A1.783%2C1.783%2C0%2C0%2C1%2C14.333%2C18.222Z%22 transform%3D%22translate(1211 221.778)%22%2F%3E%0D      %3Cline id%3D%22Line_2%22 data-name%3D%22Line 2%22 class%3D%22cls-2%22 x2%3D%2215.111%22 transform%3D%22translate(1212.444 229.333)%22%2F%3E%0D      %3Cline id%3D%22Line_3%22 data-name%3D%22Line 3%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1215.556 224)%22%2F%3E%0D      %3Cline id%3D%22Line_4%22 data-name%3D%22Line 4%22 class%3D%22cls-2%22 y2%3D%223.111%22 transform%3D%22translate(1223.556 224)%22%2F%3E%0D      %3Cpath id%3D%22Path_21%22 data-name%3D%22Path 21%22 class%3D%22cls-2%22 d%3D%22M7.222%2C18.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C5.444%2C16H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C18.667Z%22 transform%3D%22translate(1208.778 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_22%22 data-name%3D%22Path 22%22 class%3D%22cls-2%22 d%3D%22M17.222%2C18.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C15.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C18.667Z%22 transform%3D%22translate(1203.222 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_23%22 data-name%3D%22Path 23%22 class%3D%22cls-2%22 d%3D%22M27.222%2C18.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C18.222V16.444A.42.42%2C0%2C0%2C1%2C25.444%2C16h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C18.667Z%22 transform%3D%22translate(1197.667 215.111)%22%2F%3E%0D      %3Cpath id%3D%22Path_24%22 data-name%3D%22Path 24%22 class%3D%22cls-2%22 d%3D%22M7.222%2C28.667H5.444A.42.42%2C0%2C0%2C1%2C5%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C5.444%2C26H7.222a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C7.222%2C28.667Z%22 transform%3D%22translate(1208.778 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_25%22 data-name%3D%22Path 25%22 class%3D%22cls-2%22 d%3D%22M17.222%2C28.667H15.444A.42.42%2C0%2C0%2C1%2C15%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C15.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C17.222%2C28.667Z%22 transform%3D%22translate(1203.222 209.556)%22%2F%3E%0D      %3Cpath id%3D%22Path_26%22 data-name%3D%22Path 26%22 class%3D%22cls-2%22 d%3D%22M27.222%2C28.667H25.444A.42.42%2C0%2C0%2C1%2C25%2C28.222V26.444A.42.42%2C0%2C0%2C1%2C25.444%2C26h1.778a.42.42%2C0%2C0%2C1%2C.444.444v1.778A.42.42%2C0%2C0%2C1%2C27.222%2C28.667Z%22 transform%3D%22translate(1197.667 209.556)%22%2F%3E%0D    %3C%2Fg%3E%0D  %3C%2Fg%3E%0D%3C%2Fsvg%3E%0D\") no-repeat;\n      position: absolute;\n      right: 10px;\n      top: 30px;\n      width: 21px;\n      height: 21px;\n      z-index: 0; }\n\n.filter-form .popup-content {\n    position: relative;\n    left: 5%;\n    overflow-x: hidden; }\n\n.filter-form .popup-content table {\n      overflow-y: auto;\n      overflow-x: auto;\n      width: 95%; }\n\n.filter-form .popup-content h5 {\n      font-weight: 200px;\n      text-align: center; }\n\n.filter-form .popup-content h2 {\n      text-align: center; }\n\n.filter-form .main-student-table ::-webkit-scrollbar {\n    display: block; }\n\n.filter-form .main-student-table .student-table {\n    overflow-x: auto;\n    height: 400px; }\n\n.filter-form .btn {\n    display: inline-block; }\n\n.filter-form .inner-main {\n    display: inline;\n    padding: 20px 0px 12px 0px; }\n\n.filter-form .inner-main .inner-btn {\n      display: inline-block; }\n\n.filter-form .inner-main .outer-btn {\n      display: inline-block; }\n\n.filter-form .records {\n    font-size: 20px;\n    font-weight: bold;\n    text-align: center; }\n\n.filter-form .form-field {\n    display: inline-block;\n    width: 80%; }\n\n.filter-form .form-date {\n    display: inline-block;\n    width: 100%; }\n\n.filter-form .table-content {\n    height: 350px; }\n\n.filter-form .table-content ::-webkit-scrollbar {\n      display: block; }\n\n.filter-form .table-content .table-heading {\n      overflow-x: auto;\n      height: 350px; }\n\n.filter-form .filter-box {\n    padding: 10px 0px;\n    margin-bottom: 5px;\n    background: #efefef; }\n\n.filter-form .form-wrapper .datePickerBox {\n    padding-right: 10px;\n    padding-bottom: 10px;\n    width: 10%; }\n\n.filter-form .popup-header-content h2 {\n    text-align: center;\n    margin-top: 10px;\n    margin-bottom: 10px; }\n\n.filter-form .popup-header-content h5 {\n    text-align: center;\n    margin-top: 10px;\n    margin-bottom: 10px; }\n\n.filter-form .middle-section {\n    padding: 5px 15px;\n    width: 100%;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box; }\n\n.filter-form .middle-section .middle-top h2 {\n      color: black;\n      font-weight: unset;\n      padding-top: 20px; }\n\n.filter-form .middle-section .form-wrapper {\n      background: transparent;\n      margin: 25px 0px;\n      -ms-flex-line-pack: center;\n          align-content: center; }\n\n.filter-form .middle-section .form-wrapper .btn {\n        margin-top: -3px;\n        width: 70%; }\n\n.filter-form .middle-section .form-wrapper label {\n        padding-left: 10px;\n        font-size: 12px;\n        font-weight: 400;\n        color: 0084f6;\n        text-decoration: none;\n        text-transform: uppercase;\n        -webkit-font-smoothing: antialiased;\n        width: 100%; }\n\n.filter-form .middle-section .form-wrapper .side-form-ctrl {\n        background: white;\n        border: 1px solid rgba(119, 119, 119, 0.419608);\n        width: 100%;\n        padding-left: 10px;\n        margin-left: 10px;\n        height: 30px;\n        padding: 0px 5px;\n        font-weight: 600;\n        font-size: 14px;\n        color: black; }\n\n.filter-form .middle-section .form-wrapper .side-form-ctrl.bsDatepicker {\n          padding-left: 10px;\n          margin-left: 10px;\n          width: 100%; }\n\n.filter-form .popupWrapper {\n    position: fixed;\n    width: 100%;\n    height: 100%;\n    bottom: 0;\n    top: 0px;\n    right: 0;\n    left: 0px;\n    background: rgba(230, 230, 230, 0.5);\n    z-index: 100;\n    visibility: hidden;\n    opacity: 0;\n    -webkit-transition: all 0.5s ease-in;\n    transition: all 0.5s ease-in; }\n\n.filter-form .popupWrapper .popup {\n      max-width: 100%;\n      width: 100%;\n      height: auto;\n      left: 0;\n      right: 0;\n      top: 5%;\n      bottom: 0;\n      margin: auto; }\n\n.filter-form .popup-wrapper {\n    padding: 32px 15px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n            box-shadow: 1px 8px 20px 5px #9c9c9c;\n    -webkit-transition: unset;\n    transition: unset;\n    background: #fff; }\n\n.filter-form .popup-wrapper span {\n      font-weight: 300;\n      display: inline-block; }\n\n.filter-form .popup-wrapper h2 {\n      margin-bottom: 15px;\n      font-size: 22px; }\n\n.filter-form .popup-wrapper h4 {\n      margin: 25px 0 15px;\n      font-weight: 600; }\n\n.filter-form .closePopup {\n    right: 10px;\n    top: 10px;\n    font-size: 18px;\n    cursor: pointer;\n    line-height: 20px;\n    width: 26px;\n    height: 26px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    text-align: center;\n    padding-top: 3px;\n    display: none; }\n\n.filter-form .closePopup.bottomRight {\n      bottom: 2px;\n      top: auto;\n      left: auto;\n      right: 0; }\n\n.filter-form .closePopup.topLeft {\n      left: 0;\n      right: auto;\n      top: 1px;\n      bottom: auto; }\n\n.filter-form .closePopup.bottomLeft {\n      left: 0;\n      right: auto;\n      bottom: 2px;\n      top: auto; }\n\n.filter-form .closePopup svg {\n      width: 16px; }\n\n.filter-form .closePopup svg .cls-1 {\n        stroke: #c1c1c1;\n        stroke-width: 2px; }\n\n.filter-form .popup-content {\n    height: 100%;\n    overflow: hidden;\n    visibility: visible; }\n\n.filter-form .fadeIn {\n    opacity: 1;\n    visibility: visible; }\n\n.filter-form .popupWrapperMob {\n    position: fixed;\n    width: 100%;\n    height: 100%;\n    bottom: 0;\n    top: 0;\n    right: 0;\n    left: 0;\n    z-index: 100;\n    background: rgba(0, 0, 0, 0.5);\n    visibility: hidden;\n    -webkit-transition: all 0.5s ease-in;\n    transition: all 0.5s ease-in; }\n\n.filter-form .popupWrapperMob .closePopup {\n      right: -25px;\n      top: -27px;\n      display: block; }\n\n.filter-form .popup-mob {\n    left: 0;\n    width: 100%;\n    max-height: 70%;\n    background: #fff;\n    padding: 30px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    height: 100%;\n    overflow: auto;\n    z-index: 1;\n    bottom: -70%;\n    -webkit-transition: all 0.5s ease-in;\n    transition: all 0.5s ease-in; }\n\n.filter-form .popupWrapperMob.showPopupMob {\n    z-index: 100;\n    visibility: visible;\n    opacity: 1; }\n\n.filter-form .popupWrapperMob.showPopupMob .popup-mob {\n    bottom: 0; }\n\n.filter-form .popup-content ::-webkit-scrollbar {\n    display: block;\n    width: 7px;\n    height: 7px; }\n\n.details-wrapper {\n  max-height: 450px;\n  overflow-x: auto;\n  overflow-y: auto; }\n\n.details-wrapper ::-webkit-scrollbar {\n    display: block; }\n\n.details-wrapper tr th {\n    padding: 10px; }\n\n.details-wrapper tr th.marks {\n      min-width: 185px;\n      height: 83px; }\n\n.details-wrapper tr td.marks {\n    min-width: 185px; }\n\n.btn-sms-search {\n  margin-top: 35px;\n  text-align: center;\n  margin-left: 280px;\n  width: 100%; }\n\n.search-filter-wrapper .normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  width: 15%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin-right: 10px;\n  margin-bottom: 5px;\n  float: right;\n  height: 35px;\n  font-size: 14px; }\n\n.pop-header {\n  padding-bottom: 12px; }\n\n.pull-right {\n  margin-right: 12px;\n  padding-bottom: 10px; }\n\n.stdnt-table {\n  height: 500px;\n  overflow: hidden !important; }\n\n.stdnt-table ::-webkit-scrollbar {\n    display: block; }\n\n.stdnt-table .poor {\n    background: white;\n    margin-top: 41px;\n    margin-left: 5px;\n    margin-right: 5px;\n    height: 300px;\n    overflow-y: auto;\n    overflow-x: auto; }\n\n.stu-table {\n  height: 500px; }\n\n.stu-table ::-webkit-scrollbar {\n    display: block; }\n\n.stu-table table tbody {\n    height: 450px;\n    overflow-x: auto;\n    overflow-y: auto; }\n\n.table-overflow {\n  overflow: hidden; }\n"

/***/ }),

/***/ "./src/app/components/communicate/exam-report/exam-report.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ExamReportComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_report_services_exam_service__ = __webpack_require__("./src/app/services/report-services/exam.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ExamReportComponent = /** @class */ (function () {
    function ExamReportComponent(examdata, appC, auth) {
        this.examdata = examdata;
        this.appC = appC;
        this.auth = auth;
        this.isProfessional = true;
        this.pageIndex = 1;
        this.getSubjectData = [];
        this.batchExamRepo = [];
        this.totalRecords = 0;
        this.dateSource = [];
        this.dateStore = [];
        this.displayBatchSize = 10;
        this.Tdata = false;
        this.courseData = [];
        this.pagedDetailExamSource = [];
        this.batchCourseData = [];
        this.isRippleLoad = false;
        this.selectedSubject = '';
        this.subjectData = [];
        this.masterCourses = [];
        this.addReportPopup = false;
        this.examTypeEntry = [];
        this.showTitle = false;
        this.exam_Sch_Data = [];
        this.examSource = [];
        this.detailSource = [];
        this.pagedExamSource = [];
        this.pageIndexPopup = 1;
        this.fetchApiData = [];
        this.dataExamIndex = [];
        this.typeDataForm = [];
        this.projectSettings = [
            { primaryKey: 'student_disp_id', header: 'Student ID' },
            { primaryKey: 'student_name', header: 'Student Name' },
            { primaryKey: 'student_phone', header: 'Contact No.' },
            { primaryKey: 'doj', header: 'Joining Date' },
            { primaryKey: 'grade', header: 'Grade' }
        ];
        this.HighestMarks = "";
        this.LowestMarks = "";
        this.AverageMarks = "";
        this.queryParam = {
            standard_id: -1,
            subject_id: -1,
            assigned: "N",
        };
        this.fetchFieldData = {
            institution_id: parseInt(sessionStorage.getItem('institute_id')),
            standard_id: '',
            subject_id: '',
            batch_id: '',
            exam_schd_id: ''
        };
        this.searchText = "";
        this.searchflag = false;
        this.searchData = [];
        this.property = "";
        this.direction = 0;
        this.sortingEnabled = true;
        this.switchActiveView('exam');
    }
    ExamReportComponent.prototype.professionalChecker = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isProfessional = true;
            }
            else {
                _this.isProfessional = false;
            }
        });
    };
    ExamReportComponent.prototype.ngOnInit = function () {
        this.isExamGrade = sessionStorage.getItem('is_exam_grad_feature');
        this.professionalChecker();
        if (this.isProfessional) {
            this.showTitle = true;
            this.projectSettings = [
                { primaryKey: 'student_disp_id', header: 'Student ID' },
                { primaryKey: 'student_name', header: 'Student Name' },
                { primaryKey: 'student_phone', header: 'Contact No.' },
                { primaryKey: 'doj', header: 'Joining Date' },
                { primaryKey: 'grade', header: 'Grade' }
            ];
        }
        else {
            this.showTitle = false;
            this.projectSettings = [
                { primaryKey: 'student_disp_id', header: 'Student Id' },
                { primaryKey: 'student_name', header: 'Student Name' },
                { primaryKey: 'student_phone', header: 'Contact No.' },
                { primaryKey: 'doj', header: 'Joining Date' },
                { primaryKey: 'total_marks', header: 'Total Marks' },
                { primaryKey: 'marks_obtained', header: 'Marks Obtained' },
                { primaryKey: 'rank', header: 'Rank' },
            ];
        }
        this.fetchExamData();
        this.pageIndex = 1;
    };
    ExamReportComponent.prototype.closeReportPopup = function () {
        this.addReportPopup = false;
    };
    /* select exam repo fill master courses==================================================================================
    ================================================================================== */
    ExamReportComponent.prototype.fetchExamData = function () {
        var _this = this;
        this.isRippleLoad = true;
        if (this.isProfessional) {
            this.isRippleLoad = false;
            this.batchExamRepo = [];
            this.subjectData = [];
            this.queryParam.subject_id = -1;
            this.queryParam.standard_id = -1;
            this.examdata.batchExamReport(this.queryParam).subscribe(function (res) {
                {
                    _this.batchExamRepo = res.standardLi;
                    _this.getSubjectData = res.batchLi;
                }
            });
        }
        else {
            this.examdata.ExamReport().subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.masterCourses = data;
                console.log(_this.masterCourses);
            });
        }
    };
    /*======================================================================================================
  ======================================================================================================== */
    ExamReportComponent.prototype.getCourseData = function (i) {
        var _this = this;
        this.isRippleLoad = true;
        if (this.isProfessional) {
            this.batchCourseData = [];
            this.fetchFieldData.exam_schd_id = "";
            this.queryParam.subject_id = -1;
            this.examdata.batchExamReport(this.queryParam).subscribe(function (res) {
                _this.isRippleLoad = false;
                console.log(res.subjectLi);
                _this.batchCourseData = res.subjectLi;
                _this.getSubjectData = res.batchLi;
                if (_this.batchCourseData == null) {
                    var obj = {
                        type: "info",
                        title: "",
                        body: "No exam schedule found"
                    };
                    _this.appC.popToast(obj);
                    _this.isRippleLoad = false;
                }
            });
        }
        else {
            this.fetchFieldData.exam_schd_id = "";
            this.fetchFieldData.batch_id = "";
            this.fetchFieldData.subject_id = "";
            this.examdata.getCourses(i).subscribe(function (data) {
                _this.isRippleLoad = false;
                _this.courseData = data.coursesList;
                if (_this.courseData == null) {
                    var obj = {
                        type: "info",
                        title: "",
                        body: "No exam schedule found"
                    };
                    _this.appC.popToast(obj);
                    _this.isRippleLoad = false;
                }
            }, function (error) {
                _this.isRippleLoad = false;
                var obj = {
                    type: "error",
                    title: "",
                    body: "Please check your internet connection and if the issue persists then please contact to support@proctur.com"
                };
                _this.appC.popToast(obj);
            });
        }
    };
    /*==================================================================================================
    ===================================================================================================== */
    ExamReportComponent.prototype.getSubData = function (i) {
        var _this = this;
        this.isRippleLoad = true;
        console.log(i);
        if (this.isProfessional) {
            this.fetchFieldData.exam_schd_id = "";
            this.examdata.batchExamReport(this.queryParam).subscribe(function (res) {
                _this.isRippleLoad = false;
                _this.getSubjectData = res.batchLi;
                if (_this.getSubjectData == null) {
                    var obj = {
                        type: "info",
                        title: "",
                        body: "No exam schedule found"
                    };
                    _this.appC.popToast(obj);
                    _this.isRippleLoad = false;
                }
            });
        }
        else {
            this.fetchFieldData.exam_schd_id = "";
            this.fetchFieldData.batch_id = "";
            this.examdata.getSubject(i).subscribe(function (data) {
                _this.subjectData = data.batchesList;
                _this.isRippleLoad = false;
                if (_this.subjectData == null) {
                    var obj = {
                        type: "info",
                        title: "",
                        body: "No exam schedule found"
                    };
                    _this.appC.popToast(obj);
                    _this.isRippleLoad = false;
                }
            });
        }
    };
    /*=======================================================================================
    ========================================================================================== */
    ExamReportComponent.prototype.getExamScheduleData = function (i) {
        var _this = this;
        console.log(i);
        if (this.isProfessional) {
            this.selectedSubject = this.getSubjectData.filter(function (item) { return item.batch_id == i; })[0].batch_name;
        }
        else {
            this.selectedSubject = this.subjectData.filter(function (item) { return item.batch_id == i; })[0].subject_name;
        }
        this.isRippleLoad = true;
        this.fetchFieldData.exam_schd_id = "";
        console.log(i);
        this.examdata.getExamSchedule(i).subscribe(function (data) {
            _this.isRippleLoad = false;
            _this.exam_Sch_Data = data.otherSchd;
            if (_this.exam_Sch_Data == null) {
                var obj = {
                    type: "info",
                    title: "",
                    body: "No exam schedule found"
                };
                _this.appC.popToast(obj);
                _this.isRippleLoad = false;
            }
        });
    };
    ExamReportComponent.prototype.getData = function (i) {
        console.log(i);
    };
    ExamReportComponent.prototype.fetchExamReport = function () {
        var _this = this;
        this.isRippleLoad = true;
        this.examSource = [];
        if (this.isProfessional) {
            if (this.fetchFieldData.batch_id == "" || this.fetchFieldData.exam_schd_id == "") {
                var msg = {
                    type: "error",
                    title: "",
                    body: "All field(s) are required"
                };
                this.appC.popToast(msg);
                this.isRippleLoad = false;
            }
            else {
                var o = {
                    batch_id: this.fetchFieldData.batch_id,
                    exam_schd_id: this.fetchFieldData.exam_schd_id,
                    institution_id: this.fetchFieldData.institution_id,
                    standard_id: '',
                    subject_id: ''
                };
                this.examdata.viewExamData(o).subscribe(function (res) {
                    if (res.length) {
                        _this.examSource = res;
                        _this.Tdata = true;
                        _this.HighestMarks = _this.examSource[0].highest_marks;
                        _this.LowestMarks = _this.examSource[0].lowest_marks;
                        _this.AverageMarks = _this.examSource[0].average_marks;
                        _this.totalRecords = _this.examSource.length;
                        _this.fetchTableDataByPage(_this.pageIndex);
                        _this.isRippleLoad = false;
                        if (_this.examSource[0].isBatchExamGrade == 0) {
                            _this.projectSettings = [
                                { primaryKey: 'student_disp_id', header: 'Student Id' },
                                { primaryKey: 'student_name', header: 'Student Name' },
                                { primaryKey: 'student_phone', header: 'Contact No.' },
                                { primaryKey: 'doj', header: 'Joining Date' },
                                { primaryKey: 'total_marks', header: 'Total Marks' },
                                { primaryKey: 'student_marks_obtained', header: 'Marks Obtained' },
                                { primaryKey: 'student_rank', header: 'Rank' },
                            ];
                        }
                        else {
                            _this.projectSettings =
                                [{ primaryKey: 'student_disp_id', header: 'Student Id' },
                                    { primaryKey: 'student_name', header: 'Student Name' },
                                    { primaryKey: 'student_phone', header: 'Contact No.' },
                                    { primaryKey: 'doj', header: 'Joining Date' },
                                    { primaryKey: 'grade', header: 'Grade' },
                                ];
                        }
                    }
                    else {
                        var msg = {
                            type: "info",
                            body: "No data found"
                        };
                        _this.examSource = [];
                        _this.totalRecords = _this.examSource.length;
                        _this.fetchTableDataByPage(_this.pageIndex);
                        _this.appC.popToast(msg);
                        _this.isRippleLoad = false;
                    }
                }, function (err) {
                    _this.isRippleLoad = false;
                    console.log(err);
                });
            }
        }
        else {
            if (this.fetchFieldData.subject_id == "" || this.fetchFieldData.standard_id == "" || this.fetchFieldData.batch_id == "" ||
                this.fetchFieldData.exam_schd_id == "") {
                var msg = {
                    type: "error",
                    title: "",
                    body: "All field(s) are required"
                };
                this.appC.popToast(msg);
                this.isRippleLoad = false;
            }
            else {
                var o = {
                    batch_id: this.fetchFieldData.batch_id,
                    exam_schd_id: this.fetchFieldData.exam_schd_id,
                    institution_id: this.fetchFieldData.institution_id,
                    standard_id: '',
                    subject_id: ''
                };
                this.examdata.viewExamData(o).subscribe(function (res) {
                    if (res.length) {
                        console.log(res);
                        _this.examSource = res;
                        _this.Tdata = true;
                        _this.HighestMarks = _this.examSource[0].highest_marks;
                        _this.LowestMarks = _this.examSource[0].lowest_marks;
                        _this.AverageMarks = _this.examSource[0].average_marks;
                        _this.totalRecords = _this.examSource.length;
                        _this.fetchTableDataByPage(_this.pageIndex);
                        _this.isRippleLoad = false;
                        if (_this.examSource[0].grade == "" || _this.examSource[0].isBatchExamGrade == 0) {
                            _this.projectSettings = [
                                { primaryKey: 'student_disp_id', header: 'Student Id' },
                                { primaryKey: 'student_name', header: 'Student Name' },
                                { primaryKey: 'student_phone', header: 'Contact No.' },
                                { primaryKey: 'doj', header: 'Joining Date' },
                                { primaryKey: 'total_marks', header: 'Total Marks' },
                                { primaryKey: 'student_marks_obtained', header: 'Marks Obtained' },
                                { primaryKey: 'student_rank', header: 'Rank' },
                            ];
                        }
                        else {
                            _this.projectSettings =
                                [{ primaryKey: 'student_disp_id', header: 'Student Id' },
                                    { primaryKey: 'student_name', header: 'Student Name' },
                                    { primaryKey: 'student_phone', header: 'Contact No.' },
                                    { primaryKey: 'doj', header: 'Joining Date' },
                                    { primaryKey: 'grade', header: 'Grade' },
                                ];
                        }
                        console.log(res);
                    }
                    else {
                        var msg = {
                            type: "info",
                            body: "No data found"
                        };
                        _this.examSource = [];
                        _this.totalRecords = _this.examSource.length;
                        _this.fetchTableDataByPage(_this.pageIndex);
                        _this.appC.popToast(msg);
                        _this.isRippleLoad = false;
                    }
                }, function (err) {
                    _this.isRippleLoad = false;
                    console.log(err);
                });
            }
        }
    };
    ExamReportComponent.prototype.fetchDetailReport = function () {
        var _this = this;
        this.isRippleLoad = true;
        if (this.isProfessional) {
            if (this.fetchFieldData.batch_id == "") {
                var msg = {
                    type: "error",
                    body: "All field(s) are required "
                };
                this.appC.popToast(msg);
                this.isRippleLoad = false;
            }
            else {
                this.examdata.viewDetailData(this.fetchFieldData.batch_id)
                    .subscribe(function (res) {
                    if (res.length) {
                        _this.detailSource = res;
                        _this.dateSource = _this.detailSource.map(function (store) {
                            _this.dateStore = store.detailExamReportList;
                            _this.isRippleLoad = false;
                            //   this.totalRecords = this.detailSource.length;
                            //  this.fetchTableDataByPagePopup(this.pageIndexPopup);
                        });
                        _this.addReportPopup = true;
                    }
                    else {
                        var msg = {
                            type: "info",
                            title: "No data found",
                            body: ""
                        };
                        _this.appC.popToast(msg);
                        _this.isRippleLoad = false;
                    }
                }, function (err) {
                    _this.isRippleLoad = false;
                });
            }
        }
        else {
            if (this.fetchFieldData.standard_id == "" || this.fetchFieldData.subject_id == "" || this.fetchFieldData.batch_id == "") {
                var msg = {
                    type: "error",
                    body: "All Field must be filled"
                };
                this.isRippleLoad = false;
                this.appC.popToast(msg);
            }
            else {
                this.examdata.viewDetailData(this.fetchFieldData.batch_id)
                    .subscribe(function (res) {
                    if (res.length) {
                        _this.detailSource = res;
                        _this.dateSource = _this.detailSource.map(function (store) {
                            _this.dateStore = store.detailExamReportList;
                            _this.isRippleLoad = false;
                            // this.totalRecords = this.detailSource.length;
                            //this.fetchTableDataByPagePopup(this.pageIndexPopup);
                        });
                        _this.addReportPopup = true;
                    }
                    else {
                        var msg = {
                            type: "info",
                            title: "No data found",
                            body: ""
                        };
                        _this.appC.popToast(msg);
                        _this.isRippleLoad = false;
                    }
                }, function (err) {
                    _this.isRippleLoad = false;
                });
            }
        }
    };
    ExamReportComponent.prototype.getColor = function (status) {
        switch (status) {
            case 'Leave': return 'blue';
            case 'Absent': return 'red';
        }
    };
    ExamReportComponent.prototype.getMark = function (value) {
        if (value == null || value == "" || value == "0") {
            return '-';
        }
        else {
            return value;
        }
    };
    ExamReportComponent.prototype.fetchTableDataByPage = function (index) {
        this.pageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.pagedExamSource = this.getDataFromDataSource(startindex);
    };
    ExamReportComponent.prototype.fetchNext = function () {
        this.pageIndex++;
        this.fetchTableDataByPage(this.pageIndex);
    };
    ExamReportComponent.prototype.fetchPrevious = function () {
        if (this.pageIndex != 1) {
            this.pageIndex--;
            this.fetchTableDataByPage(this.pageIndex);
        }
    };
    ExamReportComponent.prototype.getDataFromDataSource = function (startindex) {
        if (this.searchflag) {
            var t = this.searchData.slice(startindex, startindex + this.displayBatchSize);
            return t;
        }
        else {
            var t = this.examSource.slice(startindex, startindex + this.displayBatchSize);
            return t;
        }
    };
    ExamReportComponent.prototype.fetchTableDataByPagePopup = function (index) {
        this.pageIndexPopup = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.pagedDetailExamSource = this.getDataFromDataSourcePopup(startindex);
    };
    ExamReportComponent.prototype.fetchNextPopup = function () {
        this.pageIndexPopup++;
        this.fetchTableDataByPagePopup(this.pageIndexPopup);
    };
    ExamReportComponent.prototype.fetchPreviousPopup = function () {
        if (this.pageIndexPopup != 1) {
            this.pageIndexPopup--;
            this.fetchTableDataByPagePopup(this.pageIndexPopup);
        }
    };
    ExamReportComponent.prototype.getDataFromDataSourcePopup = function (startindex) {
        var t = this.detailSource.slice(startindex, startindex + this.displayBatchSize);
        return t;
    };
    ExamReportComponent.prototype.closeExamReport = function () {
        this.addReportPopup = false;
    };
    ExamReportComponent.prototype.downloadJsonToCSV = function () {
        console.log(this.xlsDownloader);
        var link = this.xlsDownloader.nativeElement;
        var outer = this.examTable.nativeElement.outerHTML.replace(/ /g, '%20');
        var data_type = 'data:application/vnd.ms-excel';
        link.setAttribute('href', data_type + ',' + outer);
        link.setAttribute('download', 'ExamReport.xls');
        link.click();
    };
    // changed by laxmi
    ExamReportComponent.prototype.switchActiveView = function (id) {
        var classArray = ['home', 'attendance', 'sms', 'fee', 'exam', 'report', 'time', 'email', 'profit'];
        classArray.forEach(function (classname) {
            document.getElementById(classname) && document.getElementById(classname).classList.remove('active');
        });
        document.getElementById(id) && document.getElementById(id).classList.add('active');
    };
    ExamReportComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            this.pageIndex = 1;
            var searchRes = void 0;
            searchRes = this.examSource.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.searchData = searchRes;
            this.totalRecords = searchRes.length;
            this.searchflag = true;
            this.fetchTableDataByPage(this.pageIndex);
        }
        else {
            this.searchflag = false;
            this.fetchTableDataByPage(this.pageIndex);
            this.totalRecords = this.examSource.length;
        }
    };
    ExamReportComponent.prototype.sortedData = function (ev) {
        var _this = this;
        this.sortingEnabled = true;
        (this.direction == 0 || this.direction == -1) ? (this.direction = 1) : (this.direction = -1);
        {
            this.examSource = this.examSource.sort(function (a, b) {
                if (a[ev] < b[ev]) {
                    return -1 * _this.direction;
                }
                else if (a[ev] > b[ev]) {
                    return _this.direction;
                }
                else {
                    return 0;
                }
            });
        }
        this.pageIndex = 1;
        this.fetchTableDataByPage(this.pageIndex);
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('examTable'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], ExamReportComponent.prototype, "examTable", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["ViewChild"])('xlsDownloader'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["ElementRef"])
    ], ExamReportComponent.prototype, "xlsDownloader", void 0);
    ExamReportComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-exam-report',
            template: __webpack_require__("./src/app/components/communicate/exam-report/exam-report.component.html"),
            styles: [__webpack_require__("./src/app/components/communicate/exam-report/exam-report.component.scss")],
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_report_services_exam_service__["a" /* ExamService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], ExamReportComponent);
    return ExamReportComponent;
}());



/***/ }),

/***/ "./src/app/components/communicate/exam-report/filter.pipe.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FilterPipe; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var FilterPipe = /** @class */ (function () {
    function FilterPipe() {
    }
    FilterPipe.prototype.transform = function (value, args) {
        if (!value)
            return null;
        if (!args)
            return value;
        args = args.toLowerCase();
        return value.filter(function (item) {
            return JSON.stringify(item).toLowerCase().includes(args);
        });
    };
    FilterPipe = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Pipe"])({ name: 'filter' })
    ], FilterPipe);
    return FilterPipe;
}());



/***/ }),

/***/ "./src/app/components/communicate/index.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__communicate_component__ = __webpack_require__("./src/app/components/communicate/communicate.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_0__communicate_component__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__coummunicate_home_coummunicate_home_component__ = __webpack_require__("./src/app/components/communicate/coummunicate-home/coummunicate-home.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "b", function() { return __WEBPACK_IMPORTED_MODULE_1__coummunicate_home_coummunicate_home_component__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__ptm_management_ptm_management_component__ = __webpack_require__("./src/app/components/communicate/ptm-management/ptm-management.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "g", function() { return __WEBPACK_IMPORTED_MODULE_2__ptm_management_ptm_management_component__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__exam_report_exam_report_component__ = __webpack_require__("./src/app/components/communicate/exam-report/exam-report.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "e", function() { return __WEBPACK_IMPORTED_MODULE_3__exam_report_exam_report_component__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__exam_report_filter_pipe__ = __webpack_require__("./src/app/components/communicate/exam-report/filter.pipe.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "f", function() { return __WEBPACK_IMPORTED_MODULE_4__exam_report_filter_pipe__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__email_report_email_report_component__ = __webpack_require__("./src/app/components/communicate/email-report/email-report.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "c", function() { return __WEBPACK_IMPORTED_MODULE_5__email_report_email_report_component__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__event_managment_event_managment_component__ = __webpack_require__("./src/app/components/communicate/event-managment/event-managment.component.ts");
/* harmony namespace reexport (by used) */ __webpack_require__.d(__webpack_exports__, "d", function() { return __WEBPACK_IMPORTED_MODULE_6__event_managment_event_managment_component__["a"]; });









/***/ }),

/***/ "./src/app/components/communicate/ptm-management/ptm-management.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"jsonFlag.isRippleLoad\">\r\n</loaders-css>\r\n\r\n<!-- Create PTM Model -->\r\n<!-- Modal -->\r\n<div id=\"createPTM\" class=\"modal\" role=\"dialog\" *ngIf=\"createPTMShow\">\r\n  <div class=\"modal-dialog modal-lg\">\r\n\r\n    <!-- Modal content-->\r\n    <div class=\"modal-content\">\r\n      <div class=\"modal-header\">\r\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\r\n        <h4 class=\"modal-title\">Create PTM Schedule</h4>\r\n      </div>\r\n      <div class=\"modal-body\">\r\n        <div class=\"cal-outer-container\">\r\n          <span style=\"margin-top: 10px; margin-right: 10px;\">PTM Schedule Date<span class=\"danger\">*</span></span>\r\n          <div class=\"form-wrapper ptm-schedule-date-container\">\r\n            <span id=\"changeDate\">{{today | date: 'dd MMM yyyy'}}</span> &nbsp;&nbsp;\r\n            <input  type=\"text\" value=\"\" id=\"ptmScheduleDate\" class=\"widgetDatepicker bsDatepicker\" name=\"ptmScheduleDate\"\r\n             [(ngModel)]=\"ptmScheduleDate\" (ngModelChange)=\"addNewDate($event)\" readonly=\"true\" bsDatepicker  style=\"width:0px;margin-right: 10px;\"/>\r\n            <i class=\"fa fa-calendar\" style=\"cursor: pointer;color: #1283f4;\" (click)=\"openCalendar('ptmScheduleDate')\"></i>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"ptm-batch-table-container\">\r\n          <div class=\"ptm-heading-container\">\r\n            <div class=\"ptm-heading-item small-item field-checkbox-wrapper\">\r\n              <input type=\"checkbox\" id=\"checkall\" name=\"checkall\" class=\"form-checkbox\" [(ngModel)]=\"ptmSelectAll\" (ngModelChange)=\"checkAllBatch()\">\r\n              <label for=\"checkall\"></label>\r\n            </div>\r\n            <div class=\"ptm-heading-item large-item\">\r\n              <span>Select Batch(s)</span>\r\n            </div>\r\n            <div class=\"ptm-heading-item medium-item\">\r\n              <span>Start Time</span>\r\n            </div>\r\n            <div class=\"ptm-heading-item medium-item\">\r\n              <span>End Time</span>\r\n            </div>\r\n          </div>\r\n          <div class=\"ptm-value-outer-container\">\r\n            <div class=\"ptm-value-container\" *ngFor=\"let batch of createPTMAllBatches\">\r\n              <div class=\"ptm-value-item small-item field-checkbox-wrapper\">\r\n                <input type=\"checkbox\" id=\"{{batch.batch_id}}\" name=\"\" class=\"form-checkbox\"\r\n                  [(ngModel)]=\"batch.isSelected\" (ngModelChange)=\"checkBatch(batch, $event)\">\r\n                <label for=\"\"></label>\r\n              </div>\r\n              <div class=\"ptm-value-item large-item\" style=\"margin-top: 3px;\">\r\n                <span>{{batch.batch_name}}</span>\r\n              </div>\r\n              <div class=\"ptm-value-item medium-item\" style=\"margin-right: 4%;\">\r\n                <select class=\"ptm-time\" name=\"\" [(ngModel)]=\"batch.startHH\" (ngModelChange)=\"changeTime(batch)\">\r\n                  <option [value]=\"hr\" *ngFor=\"let hr of hrs\">{{hr}}</option>\r\n                </select>\r\n                <select class=\"ptm-time\" name=\"\" [(ngModel)]=\"batch.startMM\" (ngModelChange)=\"changeTime(batch)\">\r\n                  <option [value]=\"min\" *ngFor=\"let min of mins\">{{min}}</option>\r\n                </select>\r\n                <select class=\"ptm-time\" name=\"\" [(ngModel)]=\"batch.startMed\" (ngModelChange)=\"changeTime(batch)\">\r\n                  <option value=\"AM\">AM</option>\r\n                  <option value=\"PM\">PM</option>\r\n                </select>\r\n              </div>\r\n              <div class=\"ptm-value-item medium-item\" style=\"\">\r\n                <select class=\"ptm-time\" name=\"\" [(ngModel)]=\"batch.endHH\" (ngModelChange)=\"changeTime(batch)\">\r\n                  <option [value]=\"hr\" *ngFor=\"let hr of hrs\">{{hr}}</option>\r\n                </select>\r\n                <select class=\"ptm-time\" name=\"\" [(ngModel)]=\"batch.endMM\" (ngModelChange)=\"changeTime(batch)\">\r\n                  <option [value]=\"min\" *ngFor=\"let min of mins\">{{min}}</option>\r\n                </select>\r\n                <select class=\"ptm-time\" name=\"\" [(ngModel)]=\"batch.endMed\" (ngModelChange)=\"changeTime(batch)\">\r\n                  <option value=\"AM\">AM</option>\r\n                  <option value=\"PM\">PM</option>\r\n                </select>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"modal-footer\">\r\n        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" >Close</button>\r\n        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\" (click)=\"scheduleNewPTM()\">Create</button>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n</div>\r\n\r\n\r\n<div class=\"middle-section clear-fix\">\r\n\r\n  <section class=\"middle-top clearFix bulk-header\">\r\n    <div>\r\n      <h1 class=\"pull-left\">\r\n        <a routerLink=\"/view/communicate\" style=\"padding:0px; \">\r\n          Communicate\r\n        </a>\r\n        <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\"></i>\r\n         <span>Manage PTM</span>\r\n      </h1>\r\n    </div>\r\n  </section>\r\n\r\n<!-- Add PTM and Filter PTM Section -->\r\n  <section>\r\n    <div class=\"header-container\">\r\n      <div class=\"left-container\">\r\n        <!-- FOR COURSE MODEL -->\r\n        <div class=\"header-item\" *ngIf=\"!jsonFlag.isProfessional\">\r\n          <span>Master Course <span class=\"danger\">*</span></span>\r\n          <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.masterCourse\" (ngModelChange)=\"updateCoursesList()\">\r\n            <option value=\"-1\">Select Master Course</option>\r\n            <option [value]=\"masterCourse.master_course\" *ngFor=\"let masterCourse of masterCourseList\">{{masterCourse.master_course}}</option>\r\n          </select>\r\n        </div>\r\n        <div class=\"header-item\" *ngIf=\"!jsonFlag.isProfessional\">\r\n          <span>Course <span class=\"danger\">*</span></span>\r\n          <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.course\" (ngModelChange)=\"updateSubjectsList()\">\r\n            <option value=\"-1\">Select Course</option>\r\n            <option [value]=\"course.course_id\" *ngFor=\"let course of courseList\">{{course.course_name}}</option>\r\n          </select>\r\n        </div>\r\n        <div class=\"header-item\" *ngIf=\"!jsonFlag.isProfessional\">\r\n          <span>Subject <span class=\"danger\">*</span></span>\r\n          <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.subject\" (ngModelChange)=\"loadPtmDates()\">\r\n            <option value=\"-1\">Select Subject</option>\r\n            <option [value]=\"subject.batch_id\" *ngFor=\"let subject of subjectList\">{{subject.subject_name}}</option>\r\n          </select>\r\n        </div>\r\n\r\n        <!-- FOR BATCH MODEL -->\r\n        <div class=\"header-item\" *ngIf=\"jsonFlag.isProfessional\">\r\n          <span>Batch <span class=\"danger\">*</span></span>\r\n          <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.batch_id\" (ngModelChange)=\"loadPtmDates()\">\r\n            <option value=\"-1\">Select Batch</option>\r\n            <option [value]=\"batch.batch_id\" *ngFor=\"let batch of getAllBatches\">{{batch.batch_name}}</option>\r\n          </select>\r\n        </div>\r\n\r\n        <div class=\"header-item\">\r\n          <span>PTM Schedules <span class=\"danger\">*</span></span>\r\n          <select class=\"header-select-box\" name=\"\" [(ngModel)]=\"inputElements.ptmId\">\r\n            <option value=\"-1\">Select PTM Schedule</option>\r\n            <option [value]=\"ptmDate.ptm_id\" *ngFor=\"let ptmDate of fetchPtmDates\">{{ptmDate.ptm_date}}</option>\r\n          </select>\r\n        </div>\r\n\r\n        <div class=\"header-item\">\r\n          <button type=\"button\" name=\"button\" class=\"view-ptm-btn\" (click)=\"viewStudentsData()\">View</button>\r\n        </div>\r\n\r\n      </div>\r\n      <div class=\"right-container\">\r\n        <button type=\"button\" name=\"button\" class=\"act-btn\" (click)=\"cancelPTM()\" *ngIf=\"!illustration\">Cancel PTM</button>\r\n        <button type=\"button\" name=\"button\" class=\"create-ptm-btn\" (click)=\"showCreateNewPTM()\" data-toggle=\"modal\" data-target=\"#createPTM\">Create PTM</button>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <!-- Send Notification and Search fun -->\r\n  <section *ngIf=\"!illustration\">\r\n    <div class=\"search-and-send-container\">\r\n      <div class=\"search-container\">\r\n        <div class=\"search-filter-wrapper\">\r\n            <input type=\"text\" class=\"normal-field\" placeholder=\"Search\" name=\"searchData\" (keyup)=\"searchInList($event)\" [(ngModel)]=\"searchInput\">\r\n        </div>\r\n      </div>\r\n      <div class=\"send-notification-container\">\r\n        <button type=\"button\" name=\"button\" class=\"send-btn\" (click)=\"sendNotification()\">Send Notification</button>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n  <!-- PTM Result -->\r\n  <section *ngIf=\"!illustration\">\r\n    <div class=\"table-container\">\r\n      <div class=\"heading-container\">\r\n        <div class=\"heading-item small-item\">\r\n          <span>Student Id</span>\r\n        </div>\r\n        <div class=\"heading-item medium\">\r\n          <span>Student Name</span>\r\n        </div>\r\n        <div class=\"heading-item medium\">\r\n          <span>Attendence </span>\r\n        </div>\r\n        <div class=\"heading-item medium\">\r\n          <span>Parent Remarks</span>\r\n        </div>\r\n        <div class=\"heading-item medium\">\r\n          <span>Teacher/Institute Remarks</span>\r\n        </div>\r\n        <div class=\"heading-item medium align-center\">\r\n          <span>Action</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"\" *ngIf=\"viewStudents.length == 0\">\r\n        <h4 style=\"text-align: center; margin: 20px 0px; font-weight: 600;\">No Result Found!</h4>\r\n      </div>\r\n      <div class=\"outer-value-container\">\r\n        <div class=\"value-container\" *ngFor=\"let student of viewStudents\">\r\n          <div class=\"value-item small-item\">\r\n            <span>{{student.student_disp_id}}</span>\r\n          </div>\r\n          <div class=\"value-item medium\">\r\n            <span>{{student.student_name}}</span>\r\n          </div>\r\n          <div class=\"value-item medium\">\r\n            <select class=\"action-dropdown\" [(ngModel)]=\"student.attendance\" (ngModelChange)=\"attendanceChange(student)\"\r\n             [ngClass]=\"{'absent-student': student.attendance == 'A',\r\n                         'present-student': student.attendance == 'P'}\">\r\n              <option value=\"A\" style=\"background: #ff5e5e;\">A</option>\r\n              <option value=\"P\" style=\"background: #77f080;\">P</option>\r\n            </select>\r\n          </div>\r\n          <div class=\"value-item medium\">\r\n            <input type=\"text\" name=\"\" value=\"\" class=\"value-input\" [(ngModel)]=\"student.parent_remark\" style=\"width: 150px;\">\r\n          </div>\r\n          <div class=\"value-item medium\">\r\n            <input type=\"text\" name=\"\" value=\"\" class=\"value-input\" [(ngModel)]=\"student.teacher_remark\" style=\"width: 150px;\">\r\n          </div>\r\n          <div class=\"value-item medium align-center flex-item\">\r\n            <select class=\"action-dropdown\" name=\"\" [(ngModel)]=\"student.status\">\r\n              <option value=\"pending\">Pending</option>\r\n              <option value=\"in progress\">In Progress</option>\r\n              <option value=\"resolved\">Resolved</option>\r\n            </select>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n<!-- Action button -->\r\n  <section *ngIf=\"!illustration\">\r\n    <div class=\"action-container\">\r\n      <!-- <div class=\"action-btn-container\">\r\n        <button type=\"button\" name=\"button\" class=\"act-btn\" style=\"margin-right: 20px;\" (click)=\"cancelPTM()\">Cancel PTM</button>\r\n      </div> -->\r\n      <div class=\"action-btn-container\">\r\n        <button type=\"button\" name=\"button\" class=\"act-btn full\" (click)=\"updatePTM()\">Update PTM</button>\r\n      </div>\r\n    </div>\r\n  </section>\r\n\r\n\r\n<!-- Illustration container -->\r\n<section *ngIf=\"illustration\">\r\n  <div class=\"illustration-container\">\r\n    <img src=\"./assets/images/blank-illustration.svg\" alt=\"illustration\" class=\"illustration-img\">\r\n  </div>\r\n</section>\r\n\r\n\r\n<!-- Pagination -->\r\n  <div class=\"row filter-res pagination\" #pager id=\"pager\" style=\"width: 100%;\">\r\n    <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n      <pagination (goPage)=\"fectchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\"\r\n        [pagesToShow]=\"10\" [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [sizeArr]=\"sizeArr\"\r\n        (sizeChange)=\"updateTableBatchSize($event)\" [count]=\"totalCount\">\r\n      </pagination>\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/components/communicate/ptm-management/ptm-management.component.scss":
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n.middle-section {\n  padding: 1%; }\n.header-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  width: 100%;\n  padding: 10px 0px;\n  border-bottom: 1px solid #ccc; }\n.header-container .left-container {\n    width: 70%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    -webkit-box-pack: start;\n        -ms-flex-pack: start;\n            justify-content: flex-start; }\n.header-container .left-container .header-item {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: vertical;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: column;\n              flex-direction: column;\n      font-size: 12px;\n      color: #3e3d4a;\n      width: 18%;\n      position: relative;\n      margin-right: 3%; }\n.header-container .left-container .header-item .header-select-box {\n        border-radius: 4px;\n        border: 1px solid #d4d4d4;\n        margin: 5px 0px;\n        padding: 5px 0px; }\n.header-container .left-container .header-item .input-container {\n        position: relative; }\n.header-container .left-container .header-item .input-container .fa-filter {\n          position: absolute;\n          left: 2px;\n          background: white;\n          padding: 8px 10px;\n          top: 6px;\n          border-right: 1px solid #ccc; }\n.header-container .left-container .header-item .input-container .fa-caret-down, .header-container .left-container .header-item .input-container .fa-caret-up {\n          position: absolute;\n          right: 2px;\n          background: white;\n          padding: 7px 10px;\n          top: 7px;\n          z-index: 1;\n          cursor: pointer; }\n.header-container .left-container .header-item .filer-input {\n        margin: 5px 0px;\n        border-radius: 4px;\n        border: 1px solid #d4d4d4;\n        padding: 8px 5px;\n        width: 100%;\n        padding-left: 35px;\n        height: 30px; }\n.header-container .left-container .header-item .view-ptm-btn {\n        border: 1px solid #3a66fa;\n        border-radius: 4px;\n        -webkit-box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n                box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n        padding: 4px 10px;\n        background: #3a66fa;\n        color: #ffffff;\n        font-weight: 600;\n        height: 30px;\n        margin-top: 20px;\n        width: 40%; }\n.header-container .right-container {\n    width: 25%;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: end;\n        -ms-flex-pack: end;\n            justify-content: flex-end; }\n.header-container .right-container .create-ptm-btn {\n      border-radius: 4px;\n      background: #3a66fa;\n      color: #ffffff;\n      -webkit-box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n              box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n      text-align: center;\n      padding: 4px 10px;\n      font-weight: 600;\n      margin-top: 20px;\n      height: 30px; }\n.header-container .right-container .act-btn {\n      border-radius: 4px;\n      padding: 4px 10px;\n      color: #3a66fa;\n      text-align: center;\n      background: #ffffff;\n      height: 30px;\n      font-weight: 600;\n      border: 1px solid #3a66fa;\n      margin-top: 20px;\n      margin-right: 20px; }\n.search-and-send-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n  width: 100%;\n  padding: 10px 0px;\n  border-bottom: 1px solid #ccc; }\n.search-and-send-container .search-container {\n    width: 15%;\n    margin-right: 2%; }\n.search-and-send-container .search-container .search-filter-wrapper .normal-field {\n      padding: 7px 10px;\n      border: 1px solid #ccc;\n      height: 30px;\n      font-size: 14px;\n      border-radius: 4px; }\n.search-and-send-container .send-notification-container {\n    width: auto; }\n.search-and-send-container .send-notification-container .send-btn {\n      border-radius: 4px;\n      background: #3a66fa;\n      color: #ffffff;\n      -webkit-box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n              box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n      text-align: center;\n      padding: 4px 10px;\n      font-weight: 600;\n      height: 30px; }\n.table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%; }\n.table-container .heading-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    width: 100%;\n    padding: 10px;\n    border-bottom: 1px solid #ccc; }\n.table-container .heading-container .heading-item {\n      font-weight: 600;\n      text-align: left; }\n.table-container .outer-value-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    max-height: 50vh;\n    min-height: 45vh;\n    overflow-y: auto; }\n.table-container .outer-value-container .value-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      -webkit-box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n              box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.16);\n      margin-bottom: 10px;\n      border-radius: 4px;\n      padding: 10px; }\n.table-container .outer-value-container .value-container .value-item {\n        font-weight: 400;\n        text-align: left;\n        font-size: 12px;\n        display: -webkit-box;\n        -webkit-box-align: center; }\n.table-container .outer-value-container .value-container .value-item .value-input, .table-container .outer-value-container .value-container .value-item .action-dropdown {\n          border: 1px solid #ccc;\n          padding: 2px;\n          border-radius: 4px;\n          height: 25px; }\n.table-container .outer-value-container .value-container .value-item .action-dropdown.decorated option:hover {\n          -webkit-box-shadow: 0 0 10px 100px #1882A8 inset;\n                  box-shadow: 0 0 10px 100px #1882A8 inset; }\n.table-container .small-item {\n    width: 10%; }\n.table-container .medium {\n    width: 18%; }\n.table-container .align-center {\n    text-align: center !important; }\n.table-container .flex-item {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center; }\n.table-container .absent-student {\n    background: #ff5e5e;\n    color: white;\n    border: 1px solid #ff5e5e !important;\n    margin-left: 20px; }\n.table-container .present-student {\n    background: #77f080;\n    color: white;\n    border: 1px solid #77f080 !important;\n    margin-left: 20px; }\n.action-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n  padding: 10px 0px;\n  border-top: 1px solid #ccc; }\n.action-container .action-btn-container {\n    width: auto; }\n.action-container .action-btn-container .act-btn {\n      border-radius: 4px;\n      padding: 4px 10px;\n      color: #3a66fa;\n      text-align: center;\n      background: #ffffff;\n      height: 30px;\n      font-weight: 600;\n      border: 1px solid #3a66fa; }\n.action-container .action-btn-container .full {\n      color: #ffffff;\n      background: #3a66fa; }\n.illustration-container {\n  display: block; }\n.illustration-container .illustration-img {\n    width: 40%;\n    /* height: 34%; */\n    margin-left: 10%;\n    margin-top: -1%; }\n.filter-res.pagination {\n  width: 100%; }\n.pagination {\n  margin: 0px; }\n.pagination .first:before {\n    content: \"� \";\n    font-size: 16px;\n    font-weight: 800; }\n.pagination .last:after {\n    content: \" �\";\n    font-size: 16px;\n    font-weight: 800; }\n.pagination .batch-size {\n    font-size: 16px;\n    font-weight: 800; }\n.pagination li {\n    border-right: 1px solid #ccc;\n    padding: 0px 7px;\n    margin: 0;\n    line-height: 10px;\n    font-weight: 800;\n    cursor: pointer; }\n.pagination li a {\n      line-height: 10px;\n      font-size: 16px;\n      font-weight: 800;\n      border: none;\n      padding: 0px 14px; }\n.pagination li :hover {\n      background-color: transparent !important; }\n.pagination li:last-child {\n  border-right: 0;\n  padding-right: 0; }\n.modal-title {\n  font-weight: 600; }\n.cal-outer-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row; }\n.ptm-schedule-date-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  padding-top: 10px;\n  background: white;\n  border: 1px solid #87c0f9;\n  padding: 8px 5px;\n  font-size: 14px;\n  color: black;\n  border-radius: 3px;\n  width: 125px; }\n.ptm-batch-table-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%; }\n.ptm-batch-table-container .ptm-heading-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    padding: 10px 0px;\n    padding-bottom: 0px;\n    border-bottom: 1px solid #ccc; }\n.ptm-batch-table-container .ptm-heading-container .ptm-heading-item {\n      font-size: 14px;\n      font-weight: 600; }\n.ptm-batch-table-container .ptm-value-outer-container {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    width: 100%;\n    padding: 10px 0px;\n    max-height: 50vh;\n    min-height: 50vh;\n    overflow-y: auto; }\n.ptm-batch-table-container .ptm-value-outer-container .ptm-value-container {\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row;\n      width: 100%;\n      margin-bottom: 10px; }\n.ptm-batch-table-container .ptm-value-outer-container .ptm-value-container .ptm-value-item {\n        font-size: 12px;\n        font-weight: 400;\n        display: -webkit-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-orient: horizontal;\n        -webkit-box-direction: normal;\n            -ms-flex-direction: row;\n                flex-direction: row; }\n.ptm-batch-table-container .ptm-value-outer-container .ptm-value-container .ptm-value-item .ptm-time {\n          border: 1px solid #ccc;\n          padding: 2px;\n          height: 25px; }\n.ptm-batch-table-container .small-item {\n    width: 5%; }\n.ptm-batch-table-container .medium-item {\n    width: 20.5%;\n    text-align: center; }\n.ptm-batch-table-container .large-item {\n    width: 50%; }\n.widgetDatepicker {\n  position: absolute;\n  margin-left: 10%;\n  width: 1px;\n  visibility: hidden;\n  opacity: 0; }\n.bsDatepicker {\n  padding: 5px;\n  width: 100%;\n  position: absolute; }\ninput[type=checkbox], input[type=radio] {\n  margin: 0;\n  line-height: normal; }\n.field-checkbox-wrapper .form-checkbox {\n  opacity: 0;\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 15px;\n  height: 15px;\n  z-index: 1;\n  cursor: pointer; }\n.field-checkbox-wrapper .form-checkbox + label {\n  vertical-align: middle;\n  font-size: 14px;\n  display: inline-block; }\n.field-checkbox-wrapper .form-checkbox + label:after {\n  content: '';\n  width: 16px;\n  height: 16px;\n  border: 2px solid #ccc;\n  border-radius: 2px;\n  position: absolute;\n  left: 0;\n  top: 0; }\n.field-checkbox-wrapper .form-checkbox:checked + label:after {\n  border: 2px solid #0084f6; }\n.field-checkbox-wrapper .form-checkbox + label:before {\n  width: 1px;\n  height: 1px;\n  left: 8px;\n  top: 9px;\n  position: absolute;\n  content: '';\n  border-top: 0;\n  border-right: 0;\n  border-left: 2px solid transparent;\n  border-bottom: 2px solid transparent;\n  -webkit-transform: rotate(-45deg);\n          transform: rotate(-45deg); }\n.field-checkbox-wrapper .form-checkbox:checked + label:before {\n  border-left: 2px solid #0084f6;\n  border-bottom: 2px solid #0084f6;\n  width: 12px;\n  height: 5px;\n  left: 2px;\n  top: 5px; }\n.field-checkbox-wrapper .form-checkbox:checked + label {\n  color: #0084f6; }\n"

/***/ }),

/***/ "./src/app/components/communicate/ptm-management/ptm-management.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PtmManagementComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment__ = __webpack_require__("./node_modules/moment/moment.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__services_activity_ptmservice_activity_ptm_service__ = __webpack_require__("./src/app/services/activity-ptmservice/activity-ptm.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var PtmManagementComponent = /** @class */ (function () {
    function PtmManagementComponent(router, auth, ptmService, msgService) {
        this.router = router;
        this.auth = auth;
        this.ptmService = ptmService;
        this.msgService = msgService;
        this.jsonFlag = {
            isRippleLoad: false,
            isProfessional: false
        };
        // apis variables to send
        this.inputElements = {
            masterCourse: "-1",
            course: "-1",
            subject: "-1",
            batch_id: "-1",
            ptmId: "-1"
        };
        this.hrs = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
        this.mins = ["00", "15", "30", "45"];
        this.startTime = {
            startHH: "12",
            startMM: "00",
            startMed: "PM"
        };
        this.endTime = {
            endHH: "01",
            endMM: "00",
            endMed: "PM"
        };
        this.batchQueryParam = {
            is_active: 1
        };
        this.getptmDates = {
            batch_id: "-1"
        };
        this.searchInput = '';
        // Create PTM variables
        this.createPTMShow = false;
        this.createPTMAllBatches = [];
        this.today = Date.now();
        this.ptmSelectAll = false;
        this.createPTM = {
            batchArray: [],
            startTimeArray: [],
            endTimeArray: [],
            ptm_date: __WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-DD")
        };
        this.courseList = [];
        this.subjectList = [];
        this.getAllBatches = [];
        this.fetchPtmDates = [];
        this.viewStudents = [];
        this.tempStudents = [];
        // FOR PAGINATION
        this.pageIndex = 1;
        this.displayBatchSize = 20;
        this.totalCount = 0;
        this.sizeArr = [20, 50, 100, 150, 200, 500];
        this.illustration = true;
    }
    PtmManagementComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.jsonFlag.isProfessional = true;
            }
            else {
                _this.jsonFlag.isProfessional = false;
            }
        });
        if (this.jsonFlag.isProfessional) {
            this.fetchBatchesList();
        }
        else {
            this.fetchPreFillData();
        }
    };
    PtmManagementComponent.prototype.fetchPreFillData = function () {
        var _this = this;
        this.jsonFlag.isRippleLoad = true;
        //get master course - course - subject data  for course model
        this.ptmService.getAllMasterCourse().subscribe(function (res) {
            _this.masterCourseList = res;
            _this.jsonFlag.isRippleLoad = false;
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err);
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    PtmManagementComponent.prototype.updateCoursesList = function () {
        for (var i = 0; i < this.masterCourseList.length; i++) {
            if (this.masterCourseList[i].master_course == this.inputElements.masterCourse) {
                this.courseList = this.masterCourseList[i].coursesList;
                this.inputElements.course = "-1";
                this.subjectList = [];
                this.fetchPtmDates = [];
                return;
            }
        }
    };
    PtmManagementComponent.prototype.updateSubjectsList = function () {
        for (var i = 0; i < this.courseList.length; i++) {
            if (this.courseList[i].course_id == this.inputElements.course) {
                this.subjectList = this.courseList[i].batchesList;
                this.inputElements.subject = "-1";
                return;
            }
        }
    };
    PtmManagementComponent.prototype.fetchBatchesList = function () {
        var _this = this;
        this.jsonFlag.isRippleLoad = true;
        this.ptmService.getBatches(this.batchQueryParam).subscribe(function (data) {
            _this.getAllBatches = data;
            _this.jsonFlag.isRippleLoad = false;
        }, function (error) {
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    PtmManagementComponent.prototype.loadPtmDates = function () {
        var _this = this;
        this.inputElements.ptmId = "-1";
        if (!this.jsonFlag.isProfessional) {
            this.getptmDates = {
                batch_id: this.inputElements.subject
            };
        }
        else {
            this.getptmDates = {
                batch_id: this.inputElements.batch_id
            };
        }
        this.jsonFlag.isRippleLoad = true;
        this.ptmService.loadPtm(this.getptmDates).subscribe(function (data) {
            _this.jsonFlag.isRippleLoad = false;
            _this.fetchPtmDates = data;
            if (_this.fetchPtmDates.length == 0) {
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.info, 'Info', 'No PTM schedule found');
            }
        }, function (error) {
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    PtmManagementComponent.prototype.viewStudentsData = function () {
        var _this = this;
        var validation = true;
        if (this.jsonFlag.isProfessional) {
            if (this.inputElements.batch_id == "-1") {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please select all mandatory field(s)');
                validation = false;
            }
            else if (this.inputElements.ptmId == "-1") {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please select PTM schedule');
                validation = false;
            }
        }
        else {
            if (this.inputElements.masterCourse == "-1" || this.inputElements.course == "-1" || this.inputElements.subject == "-1") {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please select all mandatory field(s)');
                validation = false;
            }
            else if (this.inputElements.ptmId == "-1") {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please select PTM schedule');
                validation = false;
            }
        }
        if (validation) {
            this.jsonFlag.isRippleLoad = true;
            this.ptmService.viewStudents(this.inputElements.ptmId).subscribe(function (data) {
                _this.jsonFlag.isRippleLoad = false;
                _this.viewStudents = data;
                for (var j = 0; j < _this.viewStudents.length; j++) {
                    _this.viewStudents[j].isAttendanceChanged = "N";
                    _this.viewStudents[j].defaultAtt = _this.viewStudents[j].attendance;
                }
                _this.tempStudents = data;
                _this.illustration = false;
                _this.totalCount = _this.viewStudents.length;
                _this.pageIndex = 1;
                _this.fectchTableDataByPage(_this.pageIndex);
            }, function (error) {
                _this.jsonFlag.isRippleLoad = false;
            });
        }
    };
    PtmManagementComponent.prototype.searchInList = function (search_string) {
        var _this = this;
        this.viewStudents = this.tempStudents;
        var temp = this.viewStudents;
        if (this.searchInput != '' && this.searchInput != null) {
            temp = this.viewStudents.filter(function (element) { return element.student_name.toLocaleLowerCase().includes(_this.searchInput.toLocaleLowerCase()) || element.student_disp_id.toLocaleLowerCase().includes(_this.searchInput.toLocaleLowerCase()); });
        }
        this.viewStudents = temp;
        this.totalCount = this.viewStudents.length;
        this.pageIndex = 1;
        this.fectchTableDataByPage(this.pageIndex);
    };
    PtmManagementComponent.prototype.sendNotification = function () {
        var _this = this;
        if (this.inputElements.ptmId != "-1") {
            console.log(this.inputElements.ptmId);
            this.jsonFlag.isRippleLoad = true;
            this.ptmService.sendNotification(this.inputElements.ptmId).subscribe(function (data) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Success', 'Notification has been sent successfully');
            }, function (error) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', error);
            });
        }
        else {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please select PTM schedule');
        }
    };
    PtmManagementComponent.prototype.cancelPTM = function () {
        var _this = this;
        if (confirm('Are you sure, you want to cancel PTM Schedule ??')) {
            var obj = {
                batch_id: this.getptmDates.batch_id,
                ptm_reminder: true,
                ptm_id: this.inputElements.ptmId
            };
            this.jsonFlag.isRippleLoad = true;
            this.ptmService.cancelPTM(obj).subscribe(function (res) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Success', 'Cancelled Successfully');
                _this.inputElements.ptmId = "-1";
                _this.viewStudents = [];
                _this.tempStudents = [];
                _this.totalCount = _this.viewStudents.length;
                _this.loadPtmDates();
                _this.illustration = true;
            }, function (err) {
                _this.jsonFlag.isRippleLoad = false;
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            });
        }
    };
    PtmManagementComponent.prototype.showCreateNewPTM = function () {
        var _this = this;
        this.createPTMShow = true;
        this.jsonFlag.isRippleLoad = true;
        this.createPTMAllBatches = [];
        this.ptmService.getBatches(this.batchQueryParam).subscribe(function (data) {
            _this.createPTMAllBatches = data;
            _this.createPTM.batchArray = [];
            _this.createPTM.startTimeArray = [];
            _this.createPTM.endTimeArray = [];
            for (var j = 0; j < _this.createPTMAllBatches.length; j++) {
                _this.createPTMAllBatches[j].isSelected = false;
                _this.createPTMAllBatches[j].startHH = "12";
                _this.createPTMAllBatches[j].startMM = "00";
                _this.createPTMAllBatches[j].startMed = "PM";
                _this.createPTMAllBatches[j].endHH = "01";
                _this.createPTMAllBatches[j].endMM = "00";
                _this.createPTMAllBatches[j].endMed = "PM";
            }
            _this.jsonFlag.isRippleLoad = false;
        }, function (error) {
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    PtmManagementComponent.prototype.checkAllBatch = function () {
        if (this.ptmSelectAll) {
            for (var j = 0; j < this.createPTMAllBatches.length; j++) {
                this.createPTMAllBatches[j].isSelected = true;
                this.createPTM.batchArray.push(this.createPTMAllBatches[j].batch_id);
                this.createPTM.startTimeArray.push(this.createPTMAllBatches[j].startHH + ":" + this.createPTMAllBatches[j].startMM + " " + this.createPTMAllBatches[j].startMed);
                this.createPTM.endTimeArray.push(this.createPTMAllBatches[j].endHH + ":" + this.createPTMAllBatches[j].endMM + " " + this.createPTMAllBatches[j].endMed);
            }
        }
        else {
            for (var j = 0; j < this.createPTMAllBatches.length; j++) {
                this.createPTMAllBatches[j].isSelected = false;
                this.createPTM.batchArray = [];
                this.createPTM.startTimeArray = [];
                this.createPTM.endTimeArray = [];
            }
        }
    };
    PtmManagementComponent.prototype.checkBatch = function (batch, e) {
        if (batch.isSelected) {
            this.createPTM.batchArray.push(batch.batch_id);
            this.createPTM.startTimeArray.push(batch.startHH + ":" + batch.startMM + " " + batch.startMed);
            this.createPTM.endTimeArray.push(batch.endHH + ":" + batch.endMM + " " + batch.endMed);
        }
        else {
            for (var j = 0; j < this.createPTM.batchArray.length; j++) {
                if (batch.batch_id == this.createPTM.batchArray[j]) {
                    this.createPTM.batchArray.splice(j, 1);
                    this.createPTM.startTimeArray.splice(j, 1);
                    this.createPTM.endTimeArray.splice(j, 1);
                }
            }
        }
    };
    PtmManagementComponent.prototype.changeTime = function (batch) {
        for (var j = 0; j < this.createPTM.batchArray.length; j++) {
            if (batch.batch_id == this.createPTM.batchArray[j]) {
                var time1 = batch.startHH;
                var time2 = batch.endHH;
                if (batch.startMed == "PM" && batch.startHH != "12") {
                    time1 = Number(batch.startHH) + 12;
                }
                if (batch.endMed == "PM" && batch.endHH != "12") {
                    time2 = Number(batch.endHH) + 12;
                }
                var startTime = __WEBPACK_IMPORTED_MODULE_3_moment__(time1 + ":" + batch.startMM, "HH:mm");
                var endTime = __WEBPACK_IMPORTED_MODULE_3_moment__(time2 + ":" + batch.endMM, "HH:mm");
                if (startTime.isAfter(endTime)) {
                    this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Start time should not be greater than end time');
                }
                else if (endTime.isBefore(startTime)) {
                    this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'End time should not be lesser than start time');
                }
                else if (startTime == endTime) {
                    this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Start time and end time should not be same');
                }
                this.createPTM.startTimeArray[j] = batch.startHH + ":" + batch.startMM + " " + batch.startMed;
                this.createPTM.endTimeArray[j] = batch.endHH + ":" + batch.endMM + " " + batch.endMed;
                return;
            }
        }
    };
    PtmManagementComponent.prototype.scheduleNewPTM = function () {
        var _this = this;
        var validation = true;
        for (var j = 0; j < this.createPTM.startTimeArray.length; j++) {
            var startTime = __WEBPACK_IMPORTED_MODULE_3_moment__(this.createPTM.startTimeArray[j], "HH:mm A");
            var endTime = __WEBPACK_IMPORTED_MODULE_3_moment__(this.createPTM.endTimeArray[j], "HH:mm A");
            if (startTime.isAfter(endTime)) {
                validation = false;
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Start time should not be greater than end time');
            }
            else if (endTime.isBefore(startTime)) {
                validation = false;
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'End time should not be lesser than start time');
            }
        }
        if (validation) {
            this.jsonFlag.isRippleLoad = true;
            this.ptmService.scheduleNewPTM(this.createPTM).subscribe(function (res) {
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Success', 'Created Successfully');
                _this.jsonFlag.isRippleLoad = false;
                _this.createPTMShow = false;
            }, function (err) {
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
                _this.jsonFlag.isRippleLoad = false;
            });
        }
    };
    PtmManagementComponent.prototype.openCalendar = function (id) {
        document.getElementById(id).click();
    };
    PtmManagementComponent.prototype.addNewDate = function () {
        var currentDate = __WEBPACK_IMPORTED_MODULE_3_moment__().format("YYYY-MM-DD");
        var scheDate = __WEBPACK_IMPORTED_MODULE_3_moment__(this.ptmScheduleDate).format("YYYY-MM-DD");
        if (__WEBPACK_IMPORTED_MODULE_3_moment__(scheDate).isBefore(currentDate)) {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'PTM schedule date can not be past date');
        }
        else {
            document.getElementById("changeDate").innerHTML = __WEBPACK_IMPORTED_MODULE_3_moment__(this.ptmScheduleDate).format("DD MMM YYYY");
            this.createPTM.ptm_date = __WEBPACK_IMPORTED_MODULE_3_moment__(this.ptmScheduleDate).format("YYYY-MM-DD");
        }
    };
    PtmManagementComponent.prototype.attendanceChange = function (student) {
        if (student.defaultAtt == student.attendance) {
            student.isAttendanceChanged = "N";
        }
        else {
            student.isAttendanceChanged = "Y";
        }
    };
    PtmManagementComponent.prototype.updatePTM = function () {
        var _this = this;
        var studentArray = [];
        for (var j = 0; j < this.viewStudents.length; j++) {
            var studentObj = {
                "attendance": this.viewStudents[j].attendance,
                "isAttendanceChanged": this.viewStudents[j].isAttendanceChanged,
                "parent_remark": this.viewStudents[j].parent_remark,
                "status": this.viewStudents[j].status,
                "student_id": this.viewStudents[j].student_id,
                "student_ptm_id": this.viewStudents[j].student_ptm_id,
                "teacher_remark": this.viewStudents[j].teacher_remark
            };
            studentArray.push(studentObj);
        }
        this.jsonFlag.isRippleLoad = true;
        this.ptmService.updatePTM(studentArray, this.inputElements.ptmId).subscribe(function (res) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, 'Success', 'Updated Successfully');
            _this.jsonFlag.isRippleLoad = false;
            _this.viewStudentsData();
        }, function (err) {
            _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', err.error.message);
            _this.jsonFlag.isRippleLoad = false;
        });
    };
    /*** pagination functions */
    /* Fetch next set of data from server and update table */
    PtmManagementComponent.prototype.fetchNext = function () {
        this.pageIndex++;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch previous set of data from server and update table */
    PtmManagementComponent.prototype.fetchPrevious = function () {
        this.pageIndex--;
        this.fectchTableDataByPage(this.pageIndex);
    };
    /* Fetch table data by page index */
    PtmManagementComponent.prototype.fectchTableDataByPage = function (index) {
        this.pageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.viewStudents = this.getDataFromDataSource(startindex);
    };
    PtmManagementComponent.prototype.getDataFromDataSource = function (startindex) {
        if (this.searchInput != '' && this.searchInput != null) {
            var t = this.viewStudents.slice(startindex, startindex + this.displayBatchSize);
            return t;
        }
        else {
            var t = this.tempStudents.slice(startindex, startindex + this.displayBatchSize);
            return t;
        }
    };
    /* Fetches Data as per the user selected batch size */
    PtmManagementComponent.prototype.updateTableBatchSize = function (num) {
        this.pageIndex = 1;
        this.displayBatchSize = parseInt(num);
        this.viewStudentsData();
    };
    PtmManagementComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-ptm-management',
            template: __webpack_require__("./src/app/components/communicate/ptm-management/ptm-management.component.html"),
            styles: [__webpack_require__("./src/app/components/communicate/ptm-management/ptm-management.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_2__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_5__services_activity_ptmservice_activity_ptm_service__["a" /* ActivityPtmService */],
            __WEBPACK_IMPORTED_MODULE_4__services_message_show_service__["a" /* MessageShowService */]])
    ], PtmManagementComponent);
    return PtmManagementComponent;
}());



/***/ }),

/***/ "./src/app/services/activity-ptmservice/activity-ptm.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ActivityPtmService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ActivityPtmService = /** @class */ (function () {
    function ActivityPtmService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    ActivityPtmService.prototype.getAllMasterCourse = function () {
        var url = this.baseUrl + "/api/v1/courseMaster/fetch/" + this.institute_id + "/all";
        return this.http.get(url, { headers: this.headers }).map(function (res) {
            return res;
        }, function (error) {
            return error;
        });
    };
    ActivityPtmService.prototype.getStandardSubjectList = function (stdId, subId, isAssigned) {
        var url = this.baseUrl + "/api/v1/batches/fetchCombinedBatchData/" + this.institute_id + "?standard_id=" + stdId + "&subject_id=" + subId + "&assigned=" + isAssigned;
        return this.http.get(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    ActivityPtmService.prototype.getBatches = function (obj) {
        var isActive = obj.is_active == 1 ? "Y" : "N";
        var url = this.baseUrl + "/api/v1/batches/all/" + this.institute_id + "?" + isActive;
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    ActivityPtmService.prototype.loadPtm = function (obj) {
        var url = this.baseUrl + "/api/v1/ptm/batch/" + obj.batch_id + "/schedules";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    ActivityPtmService.prototype.viewStudents = function (ptm_id) {
        var url = this.baseUrl + "/api/v1/ptm/" + ptm_id + "/details";
        return this.http.get(url, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    ActivityPtmService.prototype.sendNotification = function (ptm_id) {
        var obj = {};
        var url = this.baseUrl + "/api/v1/ptm/ptmAlert/" + ptm_id + "/alerts";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    ActivityPtmService.prototype.cancelPTM = function (obj) {
        var url = this.baseUrl + "/api/v1/ptm/cancel/" + obj.ptm_id;
        return this.http.put(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    ActivityPtmService.prototype.scheduleNewPTM = function (obj) {
        var url = this.baseUrl + "/api/v1/ptm/create/" + this.institute_id;
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    ActivityPtmService.prototype.updatePTM = function (obj, ptmId) {
        var url = this.baseUrl + "/api/v1/ptm/" + ptmId + "/details/record";
        return this.http.post(url, obj, { headers: this.headers }).map(function (data) {
            return data;
        }, function (error) {
            return error;
        });
    };
    ActivityPtmService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */],
            __WEBPACK_IMPORTED_MODULE_2__authenticator_service__["a" /* AuthenticatorService */]])
    ], ActivityPtmService);
    return ActivityPtmService;
}());



/***/ }),

/***/ "./src/app/services/report-services/get-email.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getEmailService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var getEmailService = /** @class */ (function () {
    /* set default value for each url, header and autherization on service creation */
    function getEmailService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    getEmailService.prototype.getEmailMessages = function (obj) {
        var url = this.baseUrl + "/api/v1/alerts/config/emailReport";
        return this.http.post(url, obj, { headers: this.headers }).map(function (res) {
            return res;
        }, function (err) {
            return err;
        });
    };
    getEmailService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */], __WEBPACK_IMPORTED_MODULE_2__authenticator_service__["a" /* AuthenticatorService */]])
    ], getEmailService);
    return getEmailService;
}());



/***/ }),

/***/ "./src/app/services/report-services/post-sms.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return postSMSService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_http__ = __webpack_require__("./node_modules/@angular/http/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var postSMSService = /** @class */ (function () {
    /* set default value for each url, header and autherization on service creation */
    function postSMSService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_http__["a" /* Headers */]();
            _this.headers.append("Content-Type", "application/json");
            _this.headers.append("Authorization", _this.Authorization);
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    postSMSService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_http__["b" /* Http */], __WEBPACK_IMPORTED_MODULE_2__authenticator_service__["a" /* AuthenticatorService */]])
    ], postSMSService);
    return postSMSService;
}());



/***/ })

});
//# sourceMappingURL=communicate.module.chunk.js.map