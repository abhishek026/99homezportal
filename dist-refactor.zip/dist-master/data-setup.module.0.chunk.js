webpackJsonp(["data-setup.module.0"],{

/***/ "./src/app/components/course-module/data-setup/class-room/class-room.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"middle-section clearFix\">\r\n\r\n  <section class=\"middle-top mb0 clearFix\" style=\"padding-bottom:0px;\">\r\n    <h1 class=\"pull-left marginhead\">\r\n        <div class=\"header-title\">        \r\n            <h2>\r\n                <a routerLink=\"/view/{{type}}\" style=\"color: #0084f6;\">\r\n                  {{ type | titlecase }}\r\n                </a>\r\n                <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" ></i> \r\n                <a routerLink=\"/view/{{type}}/setup\" style=\"color: #0084f6;\">\r\n                  Data Setup\r\n                </a>\r\n                <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" ></i>Classroom\r\n            </h2>\r\n          </div> \r\n    </h1>\r\n   \r\n  </section>\r\n\r\n  <section class=\"middle-main clearFix\">\r\n\r\n    <div class=\"clearFix add-edit\">\r\n      <a (click)=\"toggleCreateNewList()\">\r\n        <i id=\"showAddBtn\" class=\"addBtnClass\" style=\"border:none;\">+</i>\r\n        <i id=\"showCloseBtn\" style=\"display:none;border:none;\" class=\"closeBtnClass\">-</i>\r\n        <span>Add Classroom</span>\r\n      </a>\r\n      <div class=\"pull-right\">\r\n          <div class=\"search-filter-wrapper\">\r\n            <input #search type=\"textbox\" class=\"normal-field\" placeholder=\"Search\" [(ngModel)]=\"searchText\" name=\"searchData\" (keyup)=\"searchDatabase()\">\r\n          </div>\r\n        </div> \r\n    \r\n    </div>\r\n  \r\n    \r\n    <section class=\"clearFix create-standard-form\" *ngIf=\"CreateNewList\">\r\n      <form action=\"\">\r\n        <div class=\"row \">\r\n          <div class=\"c-lg-3 c-md-3 c-sm-3 c-sx-3 \">\r\n\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value': enterclassdata!= ''}\">\r\n              <label for=\"Classroom_Name\">Classroom Name<span class=\"text-danger\">*</span></label>\r\n              <input type=\"text\" #idAddRoom class=\"form-ctrl\" [(ngModel)]=\"enterclassdata\" name=\"Classroom_Name\" id=\"Classroom_Name\">\r\n\r\n            </div>\r\n          </div>\r\n          <div class=\"c-lg-3 c-md-3 c-sm-3 c-sx-3\">\r\n            <div class=\"field-wrapper\" [ngClass]=\"{'has-value': enterclassdataDesc!= ''}\">\r\n              <label for=\"ClassroomDesc\">Classroom Description<span class=\"text-danger\">*</span></label>\r\n              <input type=\"text\" #idAddDesc class=\"form-ctrl\" [(ngModel)]=\"enterclassdataDesc\" name=\"ClassroomDesc\" id=\"ClassroomDesc\">\r\n\r\n            </div>\r\n          </div>\r\n          <div class=\"c-lg-6 c-md-6 c-sm-6 c-sx-6\" style=\"margin-top:1%;\">\r\n              <button class=\"btn fullBlue btnclass pull-right\" (click)=\"addNewclassRoom(idAddRoom.value,idAddDesc.value)\">Save</button>\r\n          </div>\r\n        </div>\r\n\r\n  </form>\r\n      </section>\r\n\r\n      <div id=\"divSlotTable\">\r\n          <div class=\"table-scroll-wrapper\">\r\n            <div class=\"table table-responsive\">\r\n              <table>\r\n                <thead>\r\n                  <tr>\r\n                    <th>\r\n                      S No.\r\n                    </th>\r\n                    <th>\r\n                      Room Name\r\n                    </th>\r\n                    <th>\r\n                      Description\r\n                    </th>\r\n                    <th>\r\n                      Edit\r\n                    </th>\r\n                  </tr>\r\n                </thead>\r\n  \r\n                <tbody *ngIf=\"classRoomData.length !=0\">\r\n  \r\n                  <tr id=\"row{{i}}\" class=\"displayComp\" *ngFor=\"let row of pagedclassRoomData; let i = index; trackBy: i;\">\r\n  \r\n                    <td>\r\n                      {{i + 1}}\r\n                    </td>\r\n    \r\n                    <td class=\"view-comp\">\r\n                      {{row.class_room_name}}\r\n                    </td>\r\n  \r\n                    <td class=\"edit-comp\">\r\n                      <div class=\"field-wrapper\">\r\n                        <textarea id=\"\" class=\"form-ctrl editCellInput\" [(ngModel)]=\"row.class_room_name\" style=\"overflow: hidden;\" name=\"label\" cols=\"1\" rows=\"1\"></textarea>\r\n                        <!-- <input type=\"text\" class=\"form-ctrl editCellInput\" [(ngModel)]=\"row.class_room_name\" name=\"label\"> -->\r\n                      </div>\r\n                    </td>\r\n    \r\n                    <td class=\"view-comp\">\r\n                      {{row.class_room_desc}}\r\n                    </td>\r\n    \r\n                    <td class=\"edit-comp\">\r\n                      <div class=\"field-wrapper\">\r\n                        <input type=\"text\" class=\"form-ctrl editCellInput\" [(ngModel)]=\"row.class_room_desc\" style=\"overflow: hidden;\"  name=\"label\">\r\n                      </div>\r\n                    </td>\r\n    \r\n                    <td class=\"view-comp\">\r\n                      <a class=\"anchorTagCursor\" (click)=\"editRowTable(row , i)\">Edit</a>\r\n                    </td>\r\n  \r\n                    <td class=\"edit-comp\">\r\n                      <a class=\"anchorTagCursor\" (click)=\"saveclassRoomInfo(row , i)\">Update</a>\r\n                    </td>\r\n    \r\n                  </tr>\r\n                </tbody>\r\n                <tbody *ngIf=\"classRoomData.length ==0\">\r\n                  <td colspan=\"4\" style=\"text-align: center\">\r\n                     No ClassList Record Found\r\n                  </td>\r\n                </tbody>\r\n              </table>\r\n            </div>\r\n          </div>\r\n        </div>\r\n    \r\n        <!-- Paginator Here -->\r\n        <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n          <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n            <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n              [page]=\"pageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRow\">\r\n            </pagination>\r\n          </div>\r\n        </div>\r\n      </section>\r\n    </div>\r\n      \r\n  "

/***/ }),

/***/ "./src/app/components/course-module/data-setup/class-room/class-room.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\ntable thead tr th {\n  padding-bottom: 10px;\n  padding-top: 10px; }\ntable tbody tr td {\n  padding-bottom: 10px;\n  padding-top: 10px; }\ntable tbody tr td .editOptions li {\n    display: inline-block; }\ntable tbody tr .field-wrapper {\n  padding: 0px !important; }\ntable tbody tr .field-wrapper .form-ctrl {\n    display: block;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 0px 0px 0px 5px;\n    outline: none;\n    border: 0;\n    height: 26px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 25px;\n    background: transparent;\n    width: 60%;\n    text-align: center;\n    border-bottom: 1px solid #ccc; }\ntable tbody .displayComp .edit-comp {\n  display: none; }\ntable tbody .editComp .view-comp {\n  display: none; }\n.anchorTagCursor {\n  cursor: pointer; }\n.astrick {\n  color: red; }\n@media screen and (max-width: 995px), screen and (max-height: 768px) {\n  #divSlotTable {\n    margin-left: 0px !important;\n    margin-top: 15px;\n    margin-right: 15px !important;\n    max-height: 480px;\n    overflow: hidden;\n    width: 100%; }\n    #divSlotTable .table-scroll-wrapper {\n      max-height: 430px; }\n    #divSlotTable ::-webkit-scrollbar {\n      display: block;\n      width: 7px;\n      height: 7px; } }\n.middle-section {\n  padding: 1%;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.add-edit {\n  margin-bottom: 15px;\n  margin-top: 25px; }\n.add-edit i {\n    border: 1px solid #0084f6;\n    display: inline-block;\n    width: 17px;\n    height: 17px;\n    border-radius: 50%;\n    line-height: 16px;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle;\n    margin-right: 4px; }\n.add-edit span {\n    display: inline-block;\n    margin-bottom: 0px; }\n.add-edit .expend-box i {\n    line-height: 12px;\n    font-size: 14px; }\n.add-edit a {\n    cursor: pointer; }\n.create-standard-form {\n  margin: -18px 0;\n  padding-left: 20px;\n  margin-bottom: -10px;\n  background: #efefef;\n  border-top: 1px solid #d8d8d8; }\n.create-standard-form .form-ctrl {\n    background: transparent;\n    border-bottom: solid 1px #cccccc; }\n.closeBtnClass {\n  line-height: 11px !important; }\n.editCellInput {\n  margin: auto;\n  display: block; }\n.pull-right {\n  margin-left: 122px; }\n.grid-container {\n  display: -ms-grid;\n  display: grid;\n  grid-column-gap: -80px;\n  -ms-grid-columns: auto auto auto;\n      grid-template-columns: auto auto auto;\n  padding: 10px; }\n.btnclass {\n  margin-top: 13px;\n  margin-bottom: 10px;\n  margin-right: 74%; }\n.marginhead {\n  margin-bottom: -16px; }\n.row.field {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  margin-bottom: 1em; }\nform {\n  margin: 0.9em 0; }\n.search-filter-wrapper {\n  margin: 10px 5px 10px 5px;\n  float: right; }\n.search-filter-wrapper .search-field {\n    font-size: 12px;\n    padding: 7px 10px;\n    width: 200px;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    float: right;\n    height: 35px;\n    font-size: 14px; }\n.filter-box {\n  padding: 0px 0px;\n  margin-bottom: 5px; }\n.btn-sms-search {\n  margin-top: 35px;\n  text-align: center;\n  margin-left: 280px;\n  width: 100%; }\n.search-filter-wrapper .normal-field {\n  padding: 7px 10px;\n  border: 1px solid #ccc;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin-right: 10px;\n  margin-bottom: 5px;\n  height: 35px;\n  font-size: 14px;\n  margin-left: 229px; }\n.btn-sms-search {\n  margin-top: 35px;\n  text-align: center;\n  margin-left: 280px;\n  width: 100%; }\n"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/class-room/class-room.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ClassRoomComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_class_roomService_class_roomlist_service__ = __webpack_require__("./src/app/services/class-roomService/class-roomlist.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_login_services_login_service__ = __webpack_require__("./src/app/services/login-services/login.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_message_show_service__ = __webpack_require__("./src/app/services/message-show.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var ClassRoomComponent = /** @class */ (function () {
    function ClassRoomComponent(ClassList, login, auth, msgService) {
        this.ClassList = ClassList;
        this.login = login;
        this.auth = auth;
        this.msgService = msgService;
        this.pagedclassRoomData = [];
        this.addClasslistData = [];
        this.saveclassListData = [];
        this.updateclassListData = [];
        this.classRoomData = [];
        this.searchData = [];
        this.enterclassdataDesc = "";
        this.enterclassdata = "";
        this.searchText = "";
        this.tempIndex = "";
        this.pageIndex = 1;
        this.displayBatchSize = 10;
        this.totalRow = 0;
        this.updateFlag = false;
        this.CreateNewList = false;
        this.searchflag = false;
        this.editFlag = false;
        this.type = '';
        this.removeFullscreen();
        this.removeSelectionFromSideNav();
        this.login.changeInstituteStatus(sessionStorage.getItem('institute_name'));
        this.login.changeNameStatus(sessionStorage.getItem('name'));
    }
    ClassRoomComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.isProfessional = true;
                _this.type = 'batch';
            }
            else {
                _this.isProfessional = false;
                _this.type = 'course';
            }
        });
        this.getClassList();
    };
    /*=========================fetching class list========================================
    ====================================================================================== */
    ClassRoomComponent.prototype.getClassList = function () {
        var _this = this;
        this.ClassList.fetchClassList().subscribe(function (res) {
            _this.classRoomData = res;
            _this.totalRow = res.length;
            _this.fetchTableDataByPage(_this.pageIndex);
        }),
            function (err) {
            };
    };
    /*=====================================================================================
    ======================================================================================*/
    ClassRoomComponent.prototype.editRowTable = function (row, index) {
        if (this.editFlag) {
            this.pagedclassRoomData[this.tempIndex] = this.tempObj;
            console.log(this.pagedclassRoomData[this.tempIndex]);
            document.getElementById(("row" + this.tempIndex).toString()).classList.remove('editComp');
            document.getElementById(("row" + this.tempIndex).toString()).classList.add('displayComp');
        }
        else {
            this.editFlag = true;
        }
        this.tempIndex = index;
        console.log(this.tempIndex);
        this.tempObj = Object.assign({}, row);
        console.log(this.tempObj);
        document.getElementById(("row" + index).toString()).classList.remove('displayComp');
        document.getElementById(("row" + index).toString()).classList.add('editComp');
    };
    /*===================================(+)(-)====================================
    =============================================================================== */
    ClassRoomComponent.prototype.toggleCreateNewList = function () {
        if (this.CreateNewList == false) {
            this.CreateNewList = true;
            document.getElementById('showCloseBtn').style.display = '';
            document.getElementById('showAddBtn').style.display = 'none';
        }
        else {
            this.CreateNewList = false;
            document.getElementById('showCloseBtn').style.display = 'none';
            document.getElementById('showAddBtn').style.display = '';
        }
    };
    /*====================================adding new class room=======================
    ================================================================================= */
    ClassRoomComponent.prototype.addNewclassRoom = function (Room_ele, Desc_ele) {
        var _this = this;
        if (Room_ele != "" && Desc_ele != "" && Room_ele != null && Desc_ele != null) {
            var classRoomobj = {
                class_room_desc: Desc_ele,
                class_room_name: Room_ele
            };
            for (var i = 0; i < this.classRoomData.length; i++) {
                if (this.classRoomData[i].class_room_name == classRoomobj.class_room_name) {
                    this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Duplicate Entries are not Allowed');
                    return;
                }
            }
            if (Desc_ele.length > 500) {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Description should not be greater than 500 Characters');
                return;
            }
            this.ClassList.saveClassroomDetail(classRoomobj).subscribe(function (data) {
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, "Added", 'ClassRoom Added Successfully');
                _this.getClassList();
                _this.enterclassdata = "";
                _this.enterclassdataDesc = "";
                _this.toggleCreateNewList();
            }, function (error) {
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.error, '', error.error.message);
            });
        }
        else {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please fill Mandatory Fields');
            this.enterclassdata = "";
            this.enterclassdataDesc = "";
            return;
        }
    };
    /*===================================saving classroom info========================
    ================================================================================= */
    ClassRoomComponent.prototype.saveclassRoomInfo = function (row, index) {
        var _this = this;
        var data = {
            class_room_name: row.class_room_name,
            class_room_desc: row.class_room_desc,
            class_room_id: row.class_room_id,
        };
        for (var j = 0; j < this.classRoomData.length; j++) {
            if (j == index) {
                continue;
            }
            else if (this.classRoomData[j].class_room_name === row.class_room_name) {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Duplicate Entries are not Allowed');
                return;
            }
        }
        if (data.class_room_name != "" && data.class_room_name != null && data.class_room_desc != "" && data.class_room_desc != null) {
            if (data.class_room_desc.length > 500) {
                this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Description should not be greater than 500');
                return;
            }
            this.ClassList.updateclassListData(data).subscribe(function (res) {
                _this.msgService.showErrorMessage(_this.msgService.toastTypes.success, "Updated", 'ClassRoom Updated Successfully');
                _this.editFlag = false;
                _this.tempIndex = "";
                _this.tempObj = null;
                _this.getClassList();
            }, function (err) {
            });
        }
        else {
            this.msgService.showErrorMessage(this.msgService.toastTypes.error, '', 'Please fill classRoom name and Description');
        }
    };
    /*===================================Search============================================ */
    ClassRoomComponent.prototype.searchDatabase = function () {
        var _this = this;
        if (this.searchText != "" && this.searchText != null) {
            this.pageIndex = 1;
            var searchRes = void 0;
            searchRes = this.classRoomData.filter(function (item) {
                return Object.keys(item).some(function (k) { return item[k] != null && item[k].toString().toLowerCase().includes(_this.searchText.toLowerCase()); });
            });
            this.searchData = searchRes;
            this.totalRow = searchRes.length;
            this.searchflag = true;
            this.fetchTableDataByPage(this.pageIndex);
        }
        else {
            this.searchflag = false;
            this.fetchTableDataByPage(this.pageIndex);
            this.totalRow = this.classRoomData.length;
        }
    };
    /*====================update for vaid field==================================================== */
    // updateValidDataField() {
    //   if (this.updateFlag == false) {
    //   }
    // }
    /*==================pagination================================================================*/
    ClassRoomComponent.prototype.fetchTableDataByPage = function (index) {
        this.pageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.pagedclassRoomData = this.getClassRoomTableFromSource(startindex);
    };
    ClassRoomComponent.prototype.fetchNext = function () {
        this.pageIndex++;
        this.fetchTableDataByPage(this.pageIndex);
    };
    ClassRoomComponent.prototype.fetchPrevious = function () {
        if (this.pageIndex != 1) {
            this.pageIndex--;
            this.fetchTableDataByPage(this.pageIndex);
        }
    };
    ClassRoomComponent.prototype.getClassRoomTableFromSource = function (startindex) {
        if (this.searchflag) {
            var t = this.searchData.slice(startindex, startindex + this.displayBatchSize);
            return t;
        }
        else {
            var t = this.classRoomData.slice(startindex, startindex + this.displayBatchSize);
            return t;
        }
    };
    /*==================================================================================
    ====================================================================================== */
    ClassRoomComponent.prototype.removeFullscreen = function () {
        var header = document.getElementsByTagName('core-header');
        var sidebar = document.getElementsByTagName('core-sidednav');
        [].forEach.call(header, function (el) {
            el.classList.remove('hide');
        });
        [].forEach.call(sidebar, function (el) {
            el.classList.remove('hide');
        });
    };
    ClassRoomComponent.prototype.removeSelectionFromSideNav = function () {
        // let classArray = ['lione', 'litwo', 'lithree', 'lifour', 'lifive', 'lisix', 'liseven', 'lieight', 'linine', 'lizero'];
        // classArray.forEach(function (className) {
        //   console.log(className);
        //   document.getElementById(className).classList.remove('active');
        // });
        /* document.getElementById('liten').classList.remove('active');
        document.getElementById('lieleven').classList.remove('active'); */
    };
    ClassRoomComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-class-room',
            template: __webpack_require__("./src/app/components/course-module/data-setup/class-room/class-room.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/data-setup/class-room/class-room.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_class_roomService_class_roomlist_service__["a" /* ClassRoomService */],
            __WEBPACK_IMPORTED_MODULE_2__services_login_services_login_service__["a" /* LoginService */],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */],
            __WEBPACK_IMPORTED_MODULE_4__services_message_show_service__["a" /* MessageShowService */]])
    ], ClassRoomComponent);
    return ClassRoomComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/data-setup/data-setup-home/data-setup-home.component.html":
/***/ (function(module, exports) {

module.exports = "<section class=\"middle-section\">\r\n  <section class=\"header-section\">\r\n    <div>\r\n      <div class=\"header-title\">        \r\n        <h2>\r\n            <a routerLink=\"/view/course\" style=\"color: #0084f6;\">\r\n              {{ type | titlecase }}\r\n            </a>\r\n            <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" ></i> Data Setup\r\n        </h2>\r\n      </div>\r\n    </div>\r\n  </section>\r\n  <div class=\"course-menu-section-container\">\r\n    <div class=\"course-menu-item\" routerLink=\"/view/course/setup/academic\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/course/create-course.svg\" alt=\"create course\">\r\n        <span>Academic Year</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>Add academic year according to your courses.</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"course-menu-item\" routerLink=\"/view/course/setup/teacher\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/course/data-setup.svg\" alt=\"data setup\">\r\n        <span>Faculty</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>Add/Update details of faculties of your Institute. Also, view daily activity of faculty.</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"course-menu-item\" routerLink=\"/view/course/setup/manage-exam-grades\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/course/class-planner.svg\" alt=\"class planner\">\r\n        <span>Exam Grades</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>Create grades and link description to it of your choice.</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"course-menu-item\" routerLink=\"/view/course/setup/classroom\">\r\n      <div class=\"menu-title\">\r\n        <img src=\"./assets/images/course/exam-planner.svg\" alt=\"exam planner\">\r\n        <span>Classroom</span>\r\n      </div>\r\n      <div class=\"menu-description\">\r\n        <span>Add classrooms of your Institute so that you can assign them to batches/courses later.</span>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n</section>"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/data-setup-home/data-setup-home.component.scss":
/***/ (function(module, exports) {

module.exports = ".middle-section {\n  padding: 1%; }\n\n.header-section .header-title {\n  text-align: left;\n  font-size: 14px;\n  font-weight: 600; }\n\n.course-menu-section-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n  padding-top: 10px;\n  margin-top: 10px;\n  border-top: 1px solid rgba(10, 10, 10, 0.5);\n  width: 100%; }\n\n.course-menu-section-container .course-menu-item {\n    padding: 15px 10px;\n    width: 31%;\n    background: #fff;\n    height: 120px;\n    border-radius: 4px;\n    cursor: pointer;\n    text-align: left;\n    margin: 1%;\n    -webkit-box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24);\n    box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.24); }\n\n.course-menu-section-container .course-menu-item .menu-title {\n      width: 100%;\n      -webkit-box-pack: start;\n          -ms-flex-pack: start;\n              justify-content: flex-start;\n      font-size: 14px;\n      font-weight: 600;\n      display: -webkit-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-orient: horizontal;\n      -webkit-box-direction: normal;\n          -ms-flex-direction: row;\n              flex-direction: row; }\n\n.course-menu-section-container .course-menu-item .menu-title img {\n        width: 25px;\n        height: 25px; }\n\n.course-menu-section-container .course-menu-item .menu-title span {\n        margin-left: 10px;\n        margin-top: 5px; }\n\n.course-menu-section-container .course-menu-item .menu-description {\n      padding: 10px;\n      font-size: 12px; }\n"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/data-setup-home/data-setup-home.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DataSetupHomeComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var DataSetupHomeComponent = /** @class */ (function () {
    function DataSetupHomeComponent(auth) {
        this.auth = auth;
        this.type = '';
    }
    DataSetupHomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.type = 'batch';
            }
            else {
                _this.type = 'course';
            }
        });
    };
    DataSetupHomeComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-data-setup-home',
            template: __webpack_require__("./src/app/components/course-module/data-setup/data-setup-home/data-setup-home.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/data-setup/data-setup-home/data-setup-home.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], DataSetupHomeComponent);
    return DataSetupHomeComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/data-setup/data-setup-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DataSetupRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__data_setup_component__ = __webpack_require__("./src/app/components/course-module/data-setup/data-setup.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__data_setup_home_data_setup_home_component__ = __webpack_require__("./src/app/components/course-module/data-setup/data-setup-home/data-setup-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__manage_exam_grades_manage_exam_grades_component__ = __webpack_require__("./src/app/components/course-module/data-setup/manage-exam-grades/manage-exam-grades.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__class_room_class_room_component__ = __webpack_require__("./src/app/components/course-module/data-setup/class-room/class-room.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var DataSetupRoutingModule = /** @class */ (function () {
    function DataSetupRoutingModule() {
    }
    DataSetupRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__data_setup_component__["a" /* DataSetupComponent */],
                        pathMatch: 'prefix',
                        children: [
                            {
                                path: '',
                                component: __WEBPACK_IMPORTED_MODULE_3__data_setup_home_data_setup_home_component__["a" /* DataSetupHomeComponent */],
                            },
                            {
                                path: 'home',
                                component: __WEBPACK_IMPORTED_MODULE_3__data_setup_home_data_setup_home_component__["a" /* DataSetupHomeComponent */],
                                pathMatch: 'prefix',
                            },
                            {
                                path: 'academic',
                                loadChildren: 'app/components/course-module/data-setup/academic-year/academic-year.module#AcademicYearModule',
                            },
                            {
                                path: 'teacher',
                                loadChildren: 'app/components/course-module/data-setup/teacher/teacher.module#TeacherModule',
                            },
                            {
                                path: 'manage-exam-grades',
                                component: __WEBPACK_IMPORTED_MODULE_4__manage_exam_grades_manage_exam_grades_component__["a" /* ManageExamGradesComponent */],
                                pathMatch: 'prefix',
                            },
                            {
                                path: 'classroom',
                                component: __WEBPACK_IMPORTED_MODULE_5__class_room_class_room_component__["a" /* ClassRoomComponent */],
                            }
                        ]
                    }
                ])],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]]
        })
    ], DataSetupRoutingModule);
    return DataSetupRoutingModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/data-setup/data-setup.component.html":
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/data-setup.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DataSetupComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var DataSetupComponent = /** @class */ (function () {
    function DataSetupComponent() {
    }
    DataSetupComponent.prototype.ngOnInit = function () {
    };
    DataSetupComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-data-setup',
            template: __webpack_require__("./src/app/components/course-module/data-setup/data-setup.component.html")
        }),
        __metadata("design:paramtypes", [])
    ], DataSetupComponent);
    return DataSetupComponent;
}());



/***/ }),

/***/ "./src/app/components/course-module/data-setup/data-setup.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataSetupModule", function() { return DataSetupModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__data_setup_component__ = __webpack_require__("./src/app/components/course-module/data-setup/data-setup.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_examgradeservice_exam_grade_service_service__ = __webpack_require__("./src/app/services/examgradeservice/exam-grade-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__services_class_roomService_class_roomlist_service__ = __webpack_require__("./src/app/services/class-roomService/class-roomlist.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__data_setup_routing_module__ = __webpack_require__("./src/app/components/course-module/data-setup/data-setup-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__data_setup_home_data_setup_home_component__ = __webpack_require__("./src/app/components/course-module/data-setup/data-setup-home/data-setup-home.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__manage_exam_grades_manage_exam_grades_component__ = __webpack_require__("./src/app/components/course-module/data-setup/manage-exam-grades/manage-exam-grades.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__class_room_class_room_component__ = __webpack_require__("./src/app/components/course-module/data-setup/class-room/class-room.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var DataSetupModule = /** @class */ (function () {
    function DataSetupModule() {
    }
    DataSetupModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_6__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_5__data_setup_routing_module__["a" /* DataSetupRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_7__shared_shared_module__["a" /* SharedModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_2__data_setup_component__["a" /* DataSetupComponent */],
                __WEBPACK_IMPORTED_MODULE_8__data_setup_home_data_setup_home_component__["a" /* DataSetupHomeComponent */],
                __WEBPACK_IMPORTED_MODULE_9__manage_exam_grades_manage_exam_grades_component__["a" /* ManageExamGradesComponent */],
                __WEBPACK_IMPORTED_MODULE_10__class_room_class_room_component__["a" /* ClassRoomComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_3__services_examgradeservice_exam_grade_service_service__["a" /* ExamGradeServiceService */],
                __WEBPACK_IMPORTED_MODULE_4__services_class_roomService_class_roomlist_service__["a" /* ClassRoomService */]
            ]
        })
    ], DataSetupModule);
    return DataSetupModule;
}());



/***/ }),

/***/ "./src/app/components/course-module/data-setup/manage-exam-grades/manage-exam-grades.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n<div class=\"clear-fix\">\r\n  <aside class=\"middle-full \">\r\n    <section class=\"middle-main clearFix \">\r\n      <section class=\"middle-top mb0 clearFix sms-header\">\r\n          <div class=\"header-title\">        \r\n              <h2>\r\n                  <a routerLink=\"/view/{{type}}\" style=\"color: #0084f6;\">\r\n                    {{ type | titlecase }}\r\n                  </a>\r\n                  <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" ></i> \r\n                  <a routerLink=\"/view/{{type}}/setup\" style=\"color: #0084f6;\">\r\n                    Data Setup\r\n                  </a>\r\n                  <i style=\"font-family: 'FontAwesome';\" class=\"fas fa-angle-right\" ></i>Manage Grades\r\n              </h2>\r\n            </div> \r\n      </section>\r\n      <section class=\"filter-form attendance-container\">\r\n        <div class=\"clearFix add-edit\">\r\n          <a (click)=\"toggleCreateNewgrade()\">\r\n            <i id=\"showAddBtn\" class=\"addBtnClass\">+</i>\r\n            <i id=\"showCloseBtn\" class=\"closeBtnClass\" style=\"display:none;\">-</i>\r\n            <span>Create Grade</span>\r\n          </a>\r\n        </div>\r\n        <div class=\"row create-standard-field\" *ngIf=showToggle>\r\n\r\n          <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n            <div class=\"field-wrapper\">\r\n              <label for=\"Create Grade\">Create Grade\r\n                <span class=\"text-danger\">*</span>\r\n              </label>\r\n              <input type=\"text\" class=\"form-ctrl\" name=\"grade\" id=\"grade\" [(ngModel)]=\"addData.grade\">\r\n\r\n            </div>\r\n          </div>\r\n          <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n            <div class=\"field-wrapper\">\r\n              <label for=\"Description\">Description\r\n                <span class=\"text-danger\">*</span>\r\n              </label>\r\n              <input type=\"text\" class=\"form-ctrl\" name=\"Description\" id=\"Description\" [(ngModel)]=\"addData.description\">\r\n\r\n            </div>\r\n          </div>\r\n          <div class=\"c-lg-3 c-md-3 c-sm-3\">\r\n            <div class=\"pull-left create-cancel-small\">\r\n              <aside class=\"pull-left create-cancel-small\">\r\n                <button class=\"btn fullBlue\" style=\"margin-top:26px;\" (click)=\"addDataToTable()\">Add</button>\r\n              </aside>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"table table-responsive\" style=\"margin-top:10px;\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>\r\n                  Id\r\n                </th>\r\n                <th>\r\n                  Grade\r\n                </th>\r\n                <th>\r\n                  Description\r\n                </th>\r\n                <th>\r\n                  Create Date\r\n                </th>\r\n                <th>\r\n                  Edit\r\n                </th>\r\n                <th>\r\n                  Delete\r\n                </th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr *ngFor=\"let row of gotGrades; let i = index; trackBy: i;\" class=\"displayComp\" id=\"row{{i}}\">\r\n                <td>\r\n                  {{i + 1}}\r\n                </td>\r\n\r\n                <td class=\"view-comp\">\r\n                  {{row.grade}}\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper\">\r\n                    <input type=\"text\" class=\"form-ctrl editCellInput\" name=\"label\" [(ngModel)]=\"row.grade\" [value]=\"row.grade_id\">\r\n                  </div>\r\n                </td>\r\n                <td class=\"view-comp\">\r\n                  {{row.description}}\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <div class=\"field-wrapper\">\r\n                    <input type=\"text\" class=\"form-ctrl editCellInput\" name=\"label\" [(ngModel)]=\"row.description\">\r\n                  </div>\r\n                </td>\r\n                <td disabled>\r\n                  {{row.created_date}}\r\n                </td>\r\n                \r\n                <td class=\"view-comp\">\r\n                  <a class=\"anchorTagCursor\" (click)=\"editRowTable(row, i)\">Edit</a>\r\n                </td>\r\n                <td class=\"edit-comp\">\r\n                  <a class=\"anchorTagCursor\" (click)=\"saveInformation(row, i)\"> Save </a>\r\n                  <a class=\"anchorTagCursor anchorTag\" (click)=\"cancelEditRow(i)\"> Cancel </a>\r\n                </td>\r\n                <td>\r\n                    <a class=\"anchorTagCursor\" (click)=\"deletingGrade(row , index)\"> Delete </a>\r\n                </td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </section>\r\n\r\n    </section>\r\n  </aside>\r\n</div>"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/manage-exam-grades/manage-exam-grades.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.create-standard-field {\n  background-color: #efefef;\n  height: 92px;\n  margin-left: 10px;\n  width: 99%; }\ntable thead tr th {\n  padding-bottom: 10px;\n  padding-top: 10px; }\ntable tbody td .col-new {\n  text-align: center; }\ntable tbody tr td {\n  padding-bottom: 10px;\n  padding-top: 10px; }\ntable tbody tr td .edit {\n    cursor: pointer; }\ntable tbody tr td .anchorTag {\n    margin-left: 10px; }\ntable tbody tr td .editOptions li {\n    display: inline-block; }\ntable tbody tr .field-wrapper {\n  padding: 0px !important; }\ntable tbody tr .field-wrapper .form-ctrl {\n    display: block;\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n    padding: 0px 0px 0px 5px;\n    outline: none;\n    border: 0;\n    height: 26px;\n    -webkit-box-shadow: none;\n            box-shadow: none;\n    border-radius: 0;\n    line-height: 25px;\n    background: transparent;\n    width: 80px;\n    text-align: center;\n    border-bottom: 1px solid #ccc; }\ntable tbody tr .datePickerBox {\n  padding-right: 10px;\n  padding-bottom: 10px; }\ntable tbody .displayComp .edit-comp {\n  display: none; }\ntable tbody .editComp .view-comp {\n  display: none; }\n.anchorTagCursor {\n  cursor: pointer; }\n@media screen and (max-width: 995px), screen and (max-height: 768px) {\n  #divSlotTable {\n    margin-left: 0px !important;\n    margin-top: 15px;\n    margin-right: 15px !important;\n    max-height: 480px;\n    overflow: hidden;\n    width: 100%; }\n    #divSlotTable .table-scroll-wrapper {\n      max-height: 430px; }\n    #divSlotTable ::-webkit-scrollbar {\n      display: block;\n      width: 7px;\n      height: 7px; } }\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.astrick {\n  color: red; }\n.add-edit {\n  margin-bottom: 15px;\n  margin-top: 15px; }\n.add-edit i {\n    border: none;\n    display: inline-block;\n    width: 17px;\n    height: 17px;\n    border-radius: 50%;\n    line-height: 16px;\n    text-align: center;\n    font-size: 17px;\n    vertical-align: middle;\n    margin-right: 4px; }\n.add-edit span {\n    display: inline-block; }\n.add-edit .expend-box i {\n    line-height: 12px;\n    font-size: 22px; }\n.add-edit a {\n    cursor: pointer; }\n.create-standard-form {\n  margin: 10px 0;\n  padding: 10px 20px 20px;\n  background: #efefef;\n  border-top: 1px solid #d8d8d8; }\n.create-standard-form .form-ctrl {\n    background: transparent;\n    border-bottom: solid 1px #cccccc; }\n.closeBtnClass {\n  line-height: 11px !important; }\n.editCellInput {\n  margin: auto;\n  display: block; }\n.middle-section .middle-top {\n  margin-bottom: 10px; }\n.middle-section .middle-main .addBtnClass {\n  border: none; }\n.middle-section .middle-main .closeBtnClass {\n  border: none; }\n.middle-section .middle-main .row .btn {\n  margin-left: 0px;\n  margin-top: 10px; }\n.middle-section .middle-main .row .field-wrapper {\n  display: inline-block;\n  margin-left: 5px; }\n.middle-section .middle-main .row .field-wrapper label {\n    font-size: 12px; }\n.middle-section .middle-main .row .field-wrapper span {\n    color: red;\n    display: inline-block; }\n"

/***/ }),

/***/ "./src/app/components/course-module/data-setup/manage-exam-grades/manage-exam-grades.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ManageExamGradesComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_examgradeservice_exam_grade_service_service__ = __webpack_require__("./src/app/services/examgradeservice/exam-grade-service.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ManageExamGradesComponent = /** @class */ (function () {
    function ManageExamGradesComponent(gradeService, appC, auth) {
        this.gradeService = gradeService;
        this.appC = appC;
        this.auth = auth;
        this.showToggle = false;
        this.addData = {
            grade: "",
            description: "",
            institution_id: sessionStorage.getItem('institute_id')
        };
        this.editData = {
            description: "",
            grade: "",
            grade_id: "",
            institution_id: sessionStorage.getItem('institute_id')
        };
        this.deleteData = {
            grade_id: ""
        };
        this.gotGrades = [];
        this.addArray = [];
        this.dummyArr = [0, 1, 2, 0, 1, 2];
        this.columnMaps = [0, 1, 2];
        this.dataStatus = false;
        this.type = '';
    }
    ManageExamGradesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.fetchGrades();
        this.auth.institute_type.subscribe(function (res) {
            if (res == "LANG") {
                _this.type = 'batch';
            }
            else {
                _this.type = 'course';
            }
        });
    };
    // toggle for add grade div
    ManageExamGradesComponent.prototype.toggleCreateNewgrade = function () {
        if (this.showToggle == false) {
            this.showToggle = true;
            document.getElementById('showCloseBtn').style.display = '';
            document.getElementById('showAddBtn').style.display = 'none';
        }
        else {
            this.showToggle = false;
            document.getElementById('showCloseBtn').style.display = 'none';
            document.getElementById('showAddBtn').style.display = '';
        }
    };
    // fetchGrades while api hits first time
    ManageExamGradesComponent.prototype.fetchGrades = function () {
        var _this = this;
        this.gradeService.fetchAllData().subscribe(function (data) {
            //console.log(data);
            _this.gotGrades = data;
        }, function (error) {
            return error;
        });
    };
    // data added to table
    ManageExamGradesComponent.prototype.addDataToTable = function () {
        var _this = this;
        if (this.addData.description == "" || this.addData.grade == "" || this.addData.description == null || this.addData.grade == null) {
            var msg = {
                type: "error",
                title: "Incorrect Details",
                body: "All fields Are required"
            };
            this.appC.popToast(msg);
        }
        else if (this.addData.description != " " || this.addData.grade != " ") {
            this.gradeService.addData(this.addData).subscribe(function (data) {
                var msg = {
                    type: "success",
                    body: "Grade added successfully"
                };
                _this.appC.popToast(msg);
                _this.addData = {
                    institution_id: sessionStorage.getItem('institute_id'),
                    description: "",
                    grade: ""
                };
                _this.toggleCreateNewgrade();
                _this.fetchGrades();
            }, function (error) {
                var msg = {
                    type: "error",
                    body: error.error.message
                };
                _this.appC.popToast(msg);
            });
        }
    };
    // editing rows
    ManageExamGradesComponent.prototype.editRowTable = function (row, index) {
        document.getElementById(("row" + index).toString()).classList.remove('displayComp');
        document.getElementById(("row" + index).toString()).classList.add('editComp');
    };
    // put data for edited request
    ManageExamGradesComponent.prototype.saveInformation = function (row, index) {
        var _this = this;
        var data = {
            description: row.description,
            grade: row.grade,
            grade_id: row.grade_id,
            institution_id: sessionStorage.getItem('institute_id')
        };
        this.gradeService.saveEdited(data).subscribe(function (data) {
            _this.cancelEditRow(index);
            _this.fetchGrades();
            var msg = {
                type: "success",
                body: "Grade updated successfully"
            };
            _this.appC.popToast(msg);
        }, function (error) {
            var acad = {
                type: "error",
                title: "Incorrect Details",
                body: error.error.message
            };
            _this.appC.popToast(acad);
            _this.fetchGrades();
        });
    };
    ManageExamGradesComponent.prototype.cancelEditRow = function (index) {
        document.getElementById(("row" + index).toString()).classList.add('displayComp');
        document.getElementById(("row" + index).toString()).classList.remove('editComp');
    };
    // delete particular grade
    ManageExamGradesComponent.prototype.deletingGrade = function (row, index) {
        var _this = this;
        var data = {
            grade_id: row.grade_id,
        };
        if (confirm('Are you sure, you want to delete?')) {
            this.gradeService.deleteRow(data).subscribe(function (data) {
                _this.fetchGrades();
                var msg = {
                    type: "success",
                    body: "Grade deleted successfully"
                };
                _this.appC.popToast(msg);
            }, function (error) {
                var acad = {
                    type: "error",
                    title: "Incorrect Details",
                    body: error.error.message
                };
                _this.appC.popToast(acad);
                _this.fetchGrades();
            });
        }
    };
    ManageExamGradesComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-manage-exam-grades',
            template: __webpack_require__("./src/app/components/course-module/data-setup/manage-exam-grades/manage-exam-grades.component.html"),
            styles: [__webpack_require__("./src/app/components/course-module/data-setup/manage-exam-grades/manage-exam-grades.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_examgradeservice_exam_grade_service_service__["a" /* ExamGradeServiceService */], __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */],
            __WEBPACK_IMPORTED_MODULE_3__services_authenticator_service__["a" /* AuthenticatorService */]])
    ], ManageExamGradesComponent);
    return ManageExamGradesComponent;
}());



/***/ })

});
//# sourceMappingURL=data-setup.module.0.chunk.js.map