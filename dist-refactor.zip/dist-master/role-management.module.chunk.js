webpackJsonp(["role-management.module"],{

/***/ "./src/app/components/users-management/role-management/add-edit-role/add-edit-role.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n<section class=\"middle-section clearFix\">\r\n  <div class=\"content-container\">\r\n\r\n    <div class=\"header\">\r\n      <h2 *ngIf=\"roleId == '-1'\">Add Role</h2>\r\n      <h2 *ngIf=\"roleId != '-1'\">Edit Role</h2>\r\n    </div>\r\n\r\n    <div class=\"addEditRole\">\r\n      <div class=\"row\" *ngIf=\"roleId == '-1'\">\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"role_name\">Role Name</label>\r\n            <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"roleName\" id=\"role_name\" name=\"role_name\">\r\n          </div>\r\n        </div>\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"role_name\">Role Description</label>\r\n            <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"roleDesc\" id=\"role_desc\" name=\"role_desc\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"row\" *ngIf=\"roleId != '-1'\">\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3\" style=\"margin-top: 30px;\">\r\n          <span>Role Name : {{userData.role_name}}</span>\r\n        </div>\r\n        <div class=\"c-sm-3 c-md-3 c-lg-3\">\r\n          <div class=\"field-wrapper\">\r\n            <label for=\"role_name\">Role Description</label>\r\n            <input type=\"text\" class=\"form-ctrl\" [(ngModel)]=\"userData.role_desc\" id=\"role_desc\" name=\"role_desc\">\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n    </div>\r\n\r\n\r\n    <div class=\"picklist-wrapper\">\r\n      <p-pickList [source]=\"cloneFeatureArray\" [target]=\"targetFeatures\" [showSourceControls]=\"false\" [showTargetControls]=\"false\"\r\n        [responsive]=\"true\" filterBy=\"feature_name,description\" dragdrop=\"true\">\r\n        <ng-template let-car pTemplate=\"item\">\r\n          <div class=\"ui-helper-clearfix\">\r\n            <!-- <img src=\"assets/showcase/images/demo/car/{{car.brand}}.png\" style=\"display:inline-block;margin:2px 0 2px 2px\" width=\"48\"> -->\r\n            <div>{{car.feature_name}}</div>\r\n          </div>\r\n        </ng-template>\r\n      </p-pickList>\r\n    </div>\r\n\r\n    <div class=\"btn-section pull-right\">\r\n      <button routerLink='/view/manage/role' class=\"btn\">Cancel</button>\r\n      <button class=\"btn fullBlue\" *ngIf=\"roleId == '-1'\" (click)=\"createNewRole()\">Save</button>\r\n      <button class=\"btn fullBlue\" *ngIf=\"roleId != '-1'\" (click)=\"updateRole()\">Update</button>\r\n    </div>\r\n\r\n  </div>\r\n</section>"

/***/ }),

/***/ "./src/app/components/users-management/role-management/add-edit-role/add-edit-role.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.middle-section {\n  padding: 5px 15px;\n  width: 100%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; }\n.picklist-wrapper {\n  margin-top: 40px;\n  width: 80%; }\n.btn-section {\n  margin-top: 20px; }\n.picklist-wrapper ui-picklist-buttons {\n  color: #0083f6 !important;\n  background: #f4f4f4 !important; }\n.picklist-wrapper ui-picklist-buttons.ui-button-icon-left .picklist-wrapper ui-picklist-buttons.ui-clickable {\n    font-weight: 800 !important;\n    font-size: 20px !important; }\n"

/***/ }),

/***/ "./src/app/components/users-management/role-management/add-edit-role/add-edit-role.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AddEditRoleComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__services_user_management_role_service__ = __webpack_require__("./src/app/services/user-management/role.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__app_component__ = __webpack_require__("./src/app/app.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AddEditRoleComponent = /** @class */ (function () {
    function AddEditRoleComponent(activatedRoute, route, apiService, toastCtrl) {
        this.activatedRoute = activatedRoute;
        this.route = route;
        this.apiService = apiService;
        this.toastCtrl = toastCtrl;
        this.roleId = "-1";
        this.featuresArray = [];
        this.userData = "";
        this.targetFeatures = [];
        this.cloneFeatureArray = [];
        this.roleName = "";
        this.roleDesc = "";
    }
    AddEditRoleComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.instituteId = sessionStorage.getItem('institute_id');
        this.libraryRoleInstituteId = 101077;
        this.kakadeRoleInstituteId = 100767;
        this.activatedRoute.params.subscribe(function (res) {
            _this.getAllRolesList();
            if (res.hasOwnProperty('id')) {
                _this.roleId = res.id;
            }
            else {
                _this.targetFeatures = [];
            }
        });
    };
    AddEditRoleComponent.prototype.getAllRolesList = function () {
        var _this = this;
        this.apiService.getAllFeature().subscribe(function (res) {
            _this.featuresArray = res;
            if (_this.instituteId != _this.libraryRoleInstituteId) {
                if (_this.instituteId != 100127) {
                    for (var t = 0; t < _this.featuresArray.length; t++) {
                        if (_this.featuresArray[t].feature_id == 721) {
                            _this.featuresArray.splice(t, 1);
                        }
                    }
                }
            }
            if (_this.instituteId != _this.kakadeRoleInstituteId || _this.instituteId != 100127) {
                if (_this.instituteId != 100767 && _this.instituteId != 100127) {
                    for (var t = 0; t < _this.featuresArray.length; t++) {
                        if (_this.featuresArray[t].feature_id == 718) {
                            _this.featuresArray.splice(t, 1);
                        }
                    }
                }
            }
            _this.cloneFeatureArray = _this.keepCloning(res);
            if (_this.roleId != "-1") {
                _this.getRolesOfUser(_this.roleId);
            }
        }, function (err) {
            console.log(err);
        });
    };
    AddEditRoleComponent.prototype.getRolesOfUser = function (id) {
        var _this = this;
        this.apiService.getPerticularRoles(id).subscribe(function (res) {
            _this.userData = res;
            var role = _this.keepCloning(res);
            _this.makeTargetArray(role.feautreList);
        }, function (err) {
            console.log(err);
        });
    };
    AddEditRoleComponent.prototype.makeTargetArray = function (arr) {
        this.targetFeatures = [];
        if (arr.length > 0) {
            //console.log(this.featuresArray);
            for (var i = 0; i < arr.length; i++) {
                for (var t = 0; t < this.cloneFeatureArray.length; t++) {
                    if (arr[i] == this.cloneFeatureArray[t].feature_id) {
                        this.targetFeatures.push(this.cloneFeatureArray[t]);
                        this.cloneFeatureArray.splice(t, 1);
                    }
                }
            }
        }
        else {
            this.targetFeatures = [];
        }
        //console.log(this.targetFeatures);
    };
    AddEditRoleComponent.prototype.createNewRole = function () {
        var _this = this;
        var data = this.makeJsonTOSend();
        if (data.role_name == "" || data.role_name == null) {
            this.messageNotifier('error', '', 'Please Provide Role Name');
            return;
        }
        else if (data.feautreList.length == 0) {
            this.messageNotifier('error', '', 'Please Select Role');
            return;
        }
        else {
            this.apiService.createRole(data).subscribe(function (res) {
                _this.messageNotifier('success', 'Success', 'Role Added Successfully');
                _this.route.navigateByUrl('/view/manage/role');
            }, function (err) {
                _this.messageNotifier('error', 'error', err.error.message);
            });
        }
    };
    AddEditRoleComponent.prototype.updateRole = function () {
        var _this = this;
        var data = this.makeJsonTOSend();
        if (data.feautreList.length == 0) {
            this.messageNotifier('error', '', 'Please Select Role');
            return;
        }
        else {
            this.apiService.updateRole(data, this.userData.role_id).subscribe(function (res) {
                _this.messageNotifier('success', 'Success', 'Role Updated Successfully');
                _this.route.navigateByUrl('/view/manage/role');
            }, function (err) {
                console.log(err);
                _this.messageNotifier('error', 'error', err.error.message);
            });
        }
    };
    AddEditRoleComponent.prototype.makeJsonTOSend = function () {
        var obj = {
            feautreList: []
        };
        if (this.roleId == '-1') {
            obj.role_name = this.roleName;
            obj.role_desc = this.roleDesc;
        }
        else {
            obj.role_id = this.userData.role_id;
            obj.role_desc = this.userData.role_desc;
        }
        for (var i = 0; i < this.targetFeatures.length; i++) {
            obj.feautreList.push(this.targetFeatures[i].feature_id);
        }
        return obj;
    };
    AddEditRoleComponent.prototype.messageNotifier = function (type, title, msg) {
        var data = {
            type: type,
            title: title,
            body: msg
        };
        this.toastCtrl.popToast(data);
    };
    AddEditRoleComponent.prototype.keepCloning = function (objectpassed) {
        if (objectpassed === null || typeof objectpassed !== 'object') {
            return objectpassed;
        }
        var temporaryStorage = objectpassed.constructor();
        for (var key in objectpassed) {
            temporaryStorage[key] = this.keepCloning(objectpassed[key]);
        }
        return temporaryStorage;
    };
    AddEditRoleComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-add-edit-role',
            template: __webpack_require__("./src/app/components/users-management/role-management/add-edit-role/add-edit-role.component.html"),
            styles: [__webpack_require__("./src/app/components/users-management/role-management/add-edit-role/add-edit-role.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_router__["ActivatedRoute"],
            __WEBPACK_IMPORTED_MODULE_1__angular_router__["Router"],
            __WEBPACK_IMPORTED_MODULE_2__services_user_management_role_service__["a" /* RoleService */],
            __WEBPACK_IMPORTED_MODULE_3__app_component__["a" /* AppComponent */]])
    ], AddEditRoleComponent);
    return AddEditRoleComponent;
}());



/***/ }),

/***/ "./src/app/components/users-management/role-management/role-management.component.html":
/***/ (function(module, exports) {

module.exports = "<loaders-css [loader]=\"'ball-scale-ripple-multiple'\" class=\"app-loader-wrapper\" [loaderClass]=\"'blueRipple'\" *ngIf=\"isRippleLoad\">\r\n</loaders-css>\r\n\r\n\r\n<section class=\"middle-section clearFix\">\r\n  <div class=\"content-contaioner\">\r\n\r\n    <div class=\"head\">\r\n      <div class=\"row\">\r\n        <div class=\"pull-left\" style=\"display: inline-flex;\">\r\n          <h3>Roles</h3>\r\n          <div style=\"margin-top: -8px\">\r\n            <rob-tooltip [textMessage]=\"'?'\" [message]=\"toottip\" [placement]=\"'left'\" [customClass]=\"'left'\">\r\n            </rob-tooltip>\r\n          </div>\r\n        </div>\r\n        <div class=\"btnWrapper\">\r\n          <button type=\"button\" class=\"btn pull-right\" name=\"button\" routerLink='./addedit'>\r\n            <i class=\"fa fa-plus\" aria-hidden=\"true\"></i>\r\n            &nbsp; Add Role\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"roles-table-wrapper\">\r\n      <div>\r\n        <table>\r\n          <thead>\r\n            <tr>\r\n              <th>S No.</th>\r\n              <th>Role</th>\r\n              <th>Description</th>\r\n              <th>Assigned User</th>\r\n              <th>Action</th>\r\n            </tr>\r\n          </thead>\r\n          <tbody>\r\n            <tr *ngFor=\"let data of rolesList; let i = index; trackBy: i\">\r\n              <td>{{i + 1}}</td>\r\n              <td>{{data.role_name}}</td>\r\n              <td>{{data.role_desc}}</td>\r\n              <td>\r\n                <a class=\"viewTag\" (click)=\"showAssignedUserList(data)\" title=\"Click here to see assigned user list\">{{data.total_user_count}}</a>\r\n              </td>\r\n              <td>\r\n                <div class=\"action-menu\">\r\n                  <a [routerLink]='[\"./addedit\" , data.role_id]'>Edit</a>\r\n                  <a (click)=\"deleteRole(data)\">Delete</a>\r\n                </div>\r\n              </td>\r\n            </tr>\r\n            <tr *ngIf=\"rolesList.length == 0\">\r\n              <td colspan=\"5\">\r\n                No Role List Found\r\n              </td>\r\n            </tr>\r\n          </tbody>\r\n        </table>\r\n      </div>\r\n    </div>\r\n\r\n    <!-- Paginator Here -->\r\n    <div class=\"row filter-res pagination\" style=\"width: 100%;\">\r\n      <div class=\"c-lg-12 c-md-12 c-sm-12 align-right\">\r\n        <pagination (goPage)=\"fetchTableDataByPage($event)\" (goNext)=\"fetchNext()\" (goPrev)=\"fetchPrevious()\" [pagesToShow]=\"10\"\r\n          [page]=\"PageIndex\" [perPage]=\"displayBatchSize\" [count]=\"totalRow\">\r\n        </pagination>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n</section>\r\n\r\n\r\n\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n<!-- ///////// POPUP/////////////////////////////////// -->\r\n\r\n<section id=\"popup \" class=\"popupWrapper fadeIn \" *ngIf=\"showUserListPopUp\">\r\n  <div class=\"popup pos-abs popup-body-container \">\r\n    <div class=\"popup-wrapper pos-rel \">\r\n      <span class=\"closePopup pos-abs fbold show \" id=\"popupCloseBtn \" (click)=\"closePopUp()\">\r\n        <svg xmlns=\"http://www.w3.org/2000/svg \" viewBox=\"9310 2185 16 16 \">\r\n          <g id=\"Group_1228 \" data-name=\"Group 1228 \" transform=\"translate(8298 1888) \">\r\n            <g id=\"Group_1213 \" data-name=\"Group 1213 \" transform=\"translate(34.189 -7.77) \">\r\n              <line id=\"Line_274 \" data-name=\"Line 274 \" class=\"cls-1 \" y2=\"19.798 \" transform=\"translate(992.81 305.77)\r\n                      rotate(45) \" />\r\n              <line id=\"Line_275 \" data-name=\"Line 275 \" class=\"cls-1 \" x1=\"19.798 \" transform=\"translate(978.81 305.77)\r\n                      rotate(45) \" />\r\n            </g>\r\n            <rect id=\"Rectangle_686 \" data-name=\"Rectangle 686 \" style=\"stroke:none; \" class=\"cls-2 \" width=\"16\r\n                      \" height=\"16 \" transform=\"translate(1012 297) \" />\r\n          </g>\r\n        </svg>\r\n      </span>\r\n      <div class=\"popup-content\">\r\n        <h2>Assigned User list</h2>\r\n        <div class=\"roles-table-wrapper\">\r\n          <table>\r\n            <thead>\r\n              <tr>\r\n                <th>Name</th>\r\n                <th>Email Id</th>\r\n                <th>Contact Number</th>\r\n                <th>Username</th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr *ngFor=\"let s of userList\">\r\n                <td>{{s.name}}</td>\r\n                <td>{{s.email_id}}</td>\r\n                <td>{{s.phone}}</td>\r\n                <td>{{s.username}}</td>\r\n              </tr>\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</section>"

/***/ }),

/***/ "./src/app/components/users-management/role-management/role-management.component.scss":
/***/ (function(module, exports) {

module.exports = "/* ===============================header colors=======================*/\n.table-format-first .table-responsive table th,\n.table-format-first .table-responsive table td {\n  text-align: center;\n  padding: 10px 5px; }\n.table-format-first .table-responsive table th {\n  text-transform: capitalize;\n  font-size: 14px; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper {\n  display: inline-block;\n  overflow: initial;\n  margin-left: 0;\n  width: auto;\n  position: relative;\n  background: transparent; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox {\n    z-index: 2; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label {\n    font-size: 16px;\n    margin-left: 7px;\n    font-weight: 600;\n    vertical-align: middle; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:after, .table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper .form-checkbox + label:before {\n      z-index: 1; }\n.table-format-first .table-responsive table tbody tr td .field-checkbox-wrapper:after {\n    content: '';\n    width: 20px;\n    height: 20px;\n    background: #fff;\n    left: 0;\n    top: 0;\n    position: absolute; }\n.table-format-first .table-responsive table tbody tr td .fa-trash-o {\n  color: #f44336;\n  font-size: 20px; }\n.middle-section {\n  padding: 10px 10px; }\n.row {\n  margin: 5px 0px; }\n.btnWrapper .btn .tooltip {\n  position: relative;\n  top: -30px;\n  right: -30px;\n  min-width: 100px;\n  font-size: 12px;\n  padding: 6px;\n  height: 35px;\n  border-radius: 5px;\n  background: rgba(0, 0, 0, 0.541);\n  color: white;\n  visibility: hidden;\n  opacity: 0; }\n.btnWrapper .btn:hover {\n  background: #d8d6d6; }\n.btnWrapper .btn:hover .tooltip {\n    position: relative;\n    top: -20px;\n    right: 120px;\n    min-width: 100px;\n    padding: 6px;\n    border-radius: 5px;\n    font-size: 12px;\n    height: 30px;\n    background: rgba(0, 0, 0, 0.541);\n    color: white;\n    visibility: visible;\n    opacity: 1;\n    -webkit-transition: all 0.2s;\n    transition: all 0.2s; }\n.btnWrapper .btn:focus {\n  outline: none; }\n.btnWrapper .btn:active {\n  -webkit-box-shadow: none;\n          box-shadow: none; }\n/* popUp Scss */\n.popupWrapper {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0px;\n  right: 0;\n  left: 0px;\n  background: rgba(230, 230, 230, 0.5);\n  z-index: 100;\n  visibility: hidden;\n  opacity: 0;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapper .popup {\n    max-width: 65%;\n    width: 100%;\n    height: auto;\n    left: 0;\n    right: 0;\n    top: 5%;\n    bottom: 0;\n    margin: auto; }\n.popup-wrapper {\n  padding: 20px 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-box-shadow: 1px 8px 20px 5px #9c9c9c;\n          box-shadow: 1px 8px 20px 5px #9c9c9c;\n  -webkit-transition: unset;\n  transition: unset;\n  background: #fff; }\n.popup-wrapper h2 {\n    margin-bottom: 15px;\n    font-size: 14px; }\n.popup-wrapper h4 {\n    margin: 25px 0 15px;\n    font-weight: 600; }\n.closePopup {\n  right: 10px;\n  top: 10px;\n  font-size: 18px;\n  cursor: pointer;\n  line-height: 20px;\n  width: 26px;\n  height: 26px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  text-align: center;\n  padding-top: 3px;\n  display: none; }\n.closePopup.bottomRight {\n    bottom: 2px;\n    top: auto;\n    left: auto;\n    right: 0; }\n.closePopup.topLeft {\n    left: 0;\n    right: auto;\n    top: 1px;\n    bottom: auto; }\n.closePopup.bottomLeft {\n    left: 0;\n    right: auto;\n    bottom: 2px;\n    top: auto; }\n.closePopup svg {\n    width: 16px; }\n.closePopup svg .cls-1 {\n      stroke: #c1c1c1;\n      stroke-width: 2px; }\n.closePopup:hover .cls-1 {\n    stroke: #0084f6; }\n.popup-content {\n  height: 100%;\n  overflow: hidden;\n  visibility: visible; }\n.fadeIn {\n  opacity: 1;\n  visibility: visible; }\n.popupWrapperMob {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  bottom: 0;\n  top: 0;\n  right: 0;\n  left: 0;\n  z-index: 100;\n  background: rgba(0, 0, 0, 0.5);\n  visibility: hidden;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob .closePopup {\n    right: -25px;\n    top: -27px;\n    display: block; }\n.popup-mob {\n  left: 0;\n  width: 100%;\n  max-height: 70%;\n  background: #fff;\n  padding: 30px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  height: 100%;\n  overflow: auto;\n  z-index: 1;\n  bottom: -70%;\n  -webkit-transition: all 0.5s ease-in;\n  transition: all 0.5s ease-in; }\n.popupWrapperMob.showPopupMob {\n  z-index: 100;\n  visibility: visible;\n  opacity: 1; }\n.popupWrapperMob.showPopupMob .popup-mob {\n  bottom: 0; }\n.spanText {\n  font-size: 12px; }\n.roles-table-wrapper {\n  max-height: 385px;\n  overflow-x: hidden;\n  overflow-y: auto; }\n.action-menu a {\n  margin-left: 10px;\n  cursor: pointer; }\n"

/***/ }),

/***/ "./src/app/components/users-management/role-management/role-management.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RoleManagementComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__services_user_management_role_service__ = __webpack_require__("./src/app/services/user-management/role.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__app_component__ = __webpack_require__("./src/app/app.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var RoleManagementComponent = /** @class */ (function () {
    function RoleManagementComponent(apiService, toastCtrl) {
        this.apiService = apiService;
        this.toastCtrl = toastCtrl;
        this.rolesList = [];
        this.userList = [];
        this.showUserListPopUp = false;
        this.rolesListDataSource = [];
        this.PageIndex = 1;
        this.displayBatchSize = 10;
        this.searchDataFlag = false;
        this.totalRow = 0;
        this.searchedData = [];
        this.toottip = "We can customize roles by defining multiple activities to a user";
    }
    RoleManagementComponent.prototype.ngOnInit = function () {
        this.getRolesList();
    };
    RoleManagementComponent.prototype.getRolesList = function () {
        var _this = this;
        this.PageIndex = 1;
        this.apiService.getRoles().subscribe(function (res) {
            _this.rolesListDataSource = res;
            _this.totalRow = res.length;
            _this.fetchTableDataByPage(_this.PageIndex);
        }, function (err) {
            console.log(err);
        });
    };
    RoleManagementComponent.prototype.deleteRole = function (data) {
        var _this = this;
        if (confirm('Are you sure, you want to delete the role?')) {
            this.apiService.deleteRole(data.role_id).subscribe(function (res) {
                _this.messageNotifier('success', 'Deleted Successfully', 'Role deleted successfully');
                _this.getRolesList();
            }, function (err) {
                //console.log(err);
                _this.messageNotifier('error', '', err.error.message);
            });
        }
    };
    RoleManagementComponent.prototype.showAssignedUserList = function (data) {
        var _this = this;
        if (data.total_user_count > 0) {
            this.apiService.getAssignedUserList(data.role_id).subscribe(function (res) {
                _this.showUserListPopUp = true;
                _this.userList = res;
            }, function (err) {
                //console.log(err);
                _this.messageNotifier('error', '', err.error.message);
            });
        }
        else {
            this.messageNotifier('error', '', 'No user is assigned to this role');
        }
    };
    RoleManagementComponent.prototype.closePopUp = function () {
        this.showUserListPopUp = false;
        this.userList = [];
    };
    // pagination functions 
    RoleManagementComponent.prototype.fetchTableDataByPage = function (index) {
        this.PageIndex = index;
        var startindex = this.displayBatchSize * (index - 1);
        this.rolesList = this.getDataFromDataSource(startindex);
    };
    RoleManagementComponent.prototype.fetchNext = function () {
        this.PageIndex++;
        this.fetchTableDataByPage(this.PageIndex);
    };
    RoleManagementComponent.prototype.fetchPrevious = function () {
        if (this.PageIndex != 1) {
            this.PageIndex--;
            this.fetchTableDataByPage(this.PageIndex);
        }
    };
    RoleManagementComponent.prototype.getDataFromDataSource = function (startindex) {
        var data = [];
        if (this.searchDataFlag == true) {
            data = this.searchedData.slice(startindex, startindex + this.displayBatchSize);
        }
        else {
            data = this.rolesListDataSource.slice(startindex, startindex + this.displayBatchSize);
        }
        return data;
    };
    RoleManagementComponent.prototype.messageNotifier = function (type, title, msg) {
        var data = {
            type: type,
            title: title,
            body: msg
        };
        this.toastCtrl.popToast(data);
    };
    RoleManagementComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-role-management',
            template: __webpack_require__("./src/app/components/users-management/role-management/role-management.component.html"),
            styles: [__webpack_require__("./src/app/components/users-management/role-management/role-management.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__services_user_management_role_service__["a" /* RoleService */],
            __WEBPACK_IMPORTED_MODULE_2__app_component__["a" /* AppComponent */]])
    ], RoleManagementComponent);
    return RoleManagementComponent;
}());



/***/ }),

/***/ "./src/app/components/users-management/role-management/role-management.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RoleManagementModule", function() { return RoleManagementModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_datepicker__ = __webpack_require__("./node_modules/ngx-bootstrap-custome/datepicker/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_shared_module__ = __webpack_require__("./src/app/components/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__role_management_component__ = __webpack_require__("./src/app/components/users-management/role-management/role-management.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__role_management_routing__ = __webpack_require__("./src/app/components/users-management/role-management/role-management.routing.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__services_user_management_role_service__ = __webpack_require__("./src/app/services/user-management/role.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__add_edit_role_add_edit_role_component__ = __webpack_require__("./src/app/components/users-management/role-management/add-edit-role/add-edit-role.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_primeng_primeng__ = __webpack_require__("./node_modules/primeng/primeng.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_primeng_primeng___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9_primeng_primeng__);
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var RoleManagementModule = /** @class */ (function () {
    function RoleManagementModule() {
    }
    RoleManagementModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            declarations: [
                __WEBPACK_IMPORTED_MODULE_5__role_management_component__["a" /* RoleManagementComponent */],
                __WEBPACK_IMPORTED_MODULE_8__add_edit_role_add_edit_role_component__["a" /* AddEditRoleComponent */]
            ],
            exports: [],
            imports: [
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["FormsModule"],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["ReactiveFormsModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap_custome_datepicker__["a" /* BsDatepickerModule */],
                __WEBPACK_IMPORTED_MODULE_4__shared_shared_module__["a" /* SharedModule */],
                __WEBPACK_IMPORTED_MODULE_6__role_management_routing__["a" /* RoleManagementRouting */],
                __WEBPACK_IMPORTED_MODULE_9_primeng_primeng__["PickListModule"]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_7__services_user_management_role_service__["a" /* RoleService */]
            ]
        })
    ], RoleManagementModule);
    return RoleManagementModule;
}());



/***/ }),

/***/ "./src/app/components/users-management/role-management/role-management.routing.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RoleManagementRouting; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__role_management_component__ = __webpack_require__("./src/app/components/users-management/role-management/role-management.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__add_edit_role_add_edit_role_component__ = __webpack_require__("./src/app/components/users-management/role-management/add-edit-role/add-edit-role.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var RoleManagementRouting = /** @class */ (function () {
    function RoleManagementRouting() {
    }
    RoleManagementRouting = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"].forChild([
                    {
                        path: '',
                        component: __WEBPACK_IMPORTED_MODULE_2__role_management_component__["a" /* RoleManagementComponent */],
                        pathMatch: 'prefix',
                    },
                    {
                        path: 'addedit',
                        component: __WEBPACK_IMPORTED_MODULE_3__add_edit_role_add_edit_role_component__["a" /* AddEditRoleComponent */]
                    },
                    {
                        path: 'addedit/:id',
                        component: __WEBPACK_IMPORTED_MODULE_3__add_edit_role_add_edit_role_component__["a" /* AddEditRoleComponent */]
                    }
                ])
            ],
            exports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_router__["RouterModule"]
            ]
        })
    ], RoleManagementRouting);
    return RoleManagementRouting;
}());



/***/ }),

/***/ "./src/app/services/user-management/role.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RoleService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__authenticator_service__ = __webpack_require__("./src/app/services/authenticator.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var RoleService = /** @class */ (function () {
    function RoleService(http, auth) {
        var _this = this;
        this.http = http;
        this.auth = auth;
        this.baseUrl = '';
        this.auth.currentAuthKey.subscribe(function (key) {
            _this.Authorization = key;
            _this.headers = new __WEBPACK_IMPORTED_MODULE_1__angular_common_http__["c" /* HttpHeaders */]({ "Content-Type": "application/json", "Authorization": _this.Authorization });
        });
        this.auth.currentInstituteId.subscribe(function (id) {
            _this.institute_id = id;
        });
        this.baseUrl = this.auth.getBaseUrl();
    }
    RoleService.prototype.getRoles = function () {
        var url = this.baseUrl + "/api/v1/roleApi/allRoles/" + this.institute_id;
        return this.http.get(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    RoleService.prototype.getAssignedUserList = function (id) {
        var url = this.baseUrl + "/api/v1/roleApi/" + id;
        return this.http.get(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    RoleService.prototype.deleteRole = function (id) {
        var url = this.baseUrl + "/api/v1/roleApi/" + id;
        return this.http.delete(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    // Add Edit 
    RoleService.prototype.getAllFeature = function () {
        var url = this.baseUrl + "/api/v1/roleApi/allFeatures";
        return this.http.get(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    RoleService.prototype.getPerticularRoles = function (id) {
        var url = this.baseUrl + "/api/v1/roleApi/role/" + id;
        return this.http.get(url, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    RoleService.prototype.createRole = function (obj) {
        var url = this.baseUrl + "/api/v1/roleApi/addRole";
        return this.http.post(url, obj, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    RoleService.prototype.updateRole = function (obj, id) {
        var url = this.baseUrl + "/api/v1/roleApi/editRole/" + id;
        return this.http.put(url, obj, { headers: this.headers }).map(function (res) { return res; }, function (err) { return err; });
    };
    RoleService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["a" /* HttpClient */],
            __WEBPACK_IMPORTED_MODULE_2__authenticator_service__["a" /* AuthenticatorService */]])
    ], RoleService);
    return RoleService;
}());



/***/ })

});
//# sourceMappingURL=role-management.module.chunk.js.map